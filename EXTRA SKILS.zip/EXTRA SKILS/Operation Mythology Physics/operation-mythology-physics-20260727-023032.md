# Operation Mythology Physics & Collisions Research

**Timestamp:** 2026-07-27 02:30:32 America/Los_Angeles  
**New subject batch:** Wheeled and tracked vehicle physics, suspension queries, tire forces, drivetrain, stability, damage, networking, and ECS integration

## 1. Feature Overview

This report defines a backend-neutral vehicle simulation layer for cars, trucks, motorcycles, trailers, and tracked vehicles. The launch baseline uses:

- One authoritative rigid chassis plus query-driven wheels.
- Per-wheel suspension ray or shape casts.
- Spring/damper suspension, sprung-mass distribution, anti-roll coupling, and contact load.
- Longitudinal/lateral slip tire forces bounded by surface friction and normal load.
- Engine torque curve, clutch, transmission, differentials, braking, steering, and assists.
- Fixed-tick inputs/state, damage/profile changes, deterministic events, interpolation, networking, replay, and telemetry.

The interfaces must support both first-person cockpit and third-person chase presentation without changing the authoritative chassis/wheel state.

## 2. Existing Coverage and Identified Gap

The recursive scan found broad physics, streaming, animation, and unified character-controller coverage. Indexed physics reports cover rigid bodies, collision/query architecture, CCD, combat, character controllers, and ragdolls/constraints. None defines vehicle-specific suspension contact, tire slip/load, drivetrain, wheel collision representation, low-speed stabilization, anti-roll behavior, vehicle damage, or network state.

This batch fills the vehicle gap while reusing established body/material/query/filter/constraint/event contracts.

## 3. Sourced Facts

### Sourced facts

1. PhysX Vehicle SDK 5.6 models a vehicle as sprung masses. Every suspension performs a scene query, computes suspension force and tire load, computes tire forces from steer/camber/friction/wheel speed/chassis momentum, and applies aggregated forces to a rigid body.
2. PhysX recommends that the set of sprung masses match chassis mass and center of mass for stability at the intended rest pose.
3. PhysX supports suspension raycasts and cylindrical sweeps; sweeps better represent wheel volume but cost more.
4. PhysX limits combined longitudinal and lateral tire force by normal load multiplied by friction. It also documents a low-speed “sticky tire” constraint mode because ordinary tire forces can oscillate near rest at larger timesteps.
5. Jolt exposes a `VehicleConstraint`, ray/sphere/cylinder wheel collision testers, per-wheel longitudinal/lateral friction combination, engine, transmission, differentials, limited-slip ratio, and tire-impulse callback.
6. Jolt can reduce wheel collision-query frequency separately for active and inactive vehicles. Its wheel settings note that applying suspension/tire forces at the actual contact point improves dynamic-object interaction but can reduce stability relative to a fixed chassis force point.
7. Unity 6 WheelCollider uses a suspension spring/damper and slip-based tire model. Its wheel collision is a downward ray, and its tire friction is calculated separately from ordinary physics materials.
8. Unreal Chaos Vehicles is a lightweight vehicle system with arbitrary wheel count, gearing, aerofoil, thrust, and asynchronous physics support. Chaos Modular Vehicles decomposes vehicle behavior into wheel, suspension, engine, clutch, transmission, thruster, and aerofoil modules; suspension uses ray traces.
9. Unreal's vehicle setup separates chassis physics asset, wheel/suspension/brake configuration, torque curve, animation, and controls.

### Interpretation

Modern game vehicles generally do not simulate visible wheel mesh contact as ordinary rolling rigid bodies. They query road support, compute load/slip forces in a vehicle model, and apply those forces to a rigid chassis. Wheel visuals then follow authoritative suspension/rotation state.

## 4. Industry-Standard Physics API or Pattern

Use this fixed-tick pipeline:

1. Consume one `VehicleInputCommand`: steering, throttle, service brake, handbrake, clutch, gear request, assist toggles.
2. Resolve configuration/profile changes and damage state at the tick barrier.
3. For each enabled wheel, build a suspension ray or shape cast from maximum compression to maximum droop, using an explicit road query profile and self-filter.
4. Select a deterministic support hit and compute suspension compression/jounce, spring velocity, normal, contact point, surface velocity, material, and load.
5. Compute wheel-frame ground velocity and wheel angular speed; derive longitudinal slip ratio and lateral slip angle with bounded low-speed denominators.
6. Evaluate tire curves and combine longitudinal/lateral demand inside a friction/load limit.
7. Evaluate engine torque curve, clutch coupling, gear ratio, final drive, differential distribution, brake torque, and wheel angular integration.
8. Compute suspension, tire, anti-roll, aerodynamic, and assist forces; apply them at authored or measured points to the chassis and contacted dynamic body.
9. Solve/integrate chassis contacts and any trailer/articulation constraints.
10. Publish chassis and wheel state, contact telemetry, gear/RPM, and stable events.

Use ray wheels as the portable baseline. Enable sphere/cylinder/convex sweeps for large tires, curbs, rocks, and off-road classes after measured testing. Visible wheels never become collision authority.

Low-speed stabilization should be an explicit bounded mode: below speed/slip thresholds for a dwell time, replace unstable tire-force behavior with velocity constraints or stronger damping/brake behavior. Exit with hysteresis.

## 5. Performance and Determinism Considerations

- **Broad phase:** Each active wheel performs a road query; cost is vehicle count × wheel count × query-tree traversal plus candidates. Shape casts have larger swept bounds and more candidates than rays.
- **Narrow phase:** Ray-triangle tests are cheap; sphere/cylinder/convex sweeps and detailed road meshes cost more. Restrict road queries to simplified collision and request only point, normal, distance, material, body, and subshape.
- **Solver iterations:** Chassis contacts, trailers, anti-roll/joint constraints, and low-speed sticky constraints add solver rows. Query-derived tire forces do not add ordinary wheel contact manifolds unless encoded as constraints.
- **Allocations:** Preallocate wheel queries/results, tire scratch, drivetrain state, deferred forces, contact events, and telemetry. No warm-tick heap allocation.
- **Spatial locality/cache behavior:** Store vehicle and wheel state SoA; group wheels contiguously by vehicle; batch road queries by spatial cell/profile; use table/curve data in compact immutable assets.
- **Sleeping:** A parked vehicle should sleep as one chassis/constraint island. Stop engine/assist/tire churn and reduce suspension-query frequency while inactive. Wake on input, support movement, collision, damage, or replicated correction.
- **Island parallelism:** Independent vehicles solve in parallel. Trailers, collisions, pileups, ferry/platform contact, and jointed machinery can merge islands. Avoid unnecessary wheel rigid bodies that enlarge islands.
- **Query batching:** Batch independent wheel queries, but drivetrain/tire forces depend on their results. Active wheels may query every tick; sleeping/distant vehicles may query less often only when gameplay authority permits.
- **Fixed-step cost:** Vehicle forces are timestep-sensitive. Use the same fixed step as authoritative physics and tier local vehicle substeps by speed/stiffness rather than global render rate.
- **Substeps:** Substeps improve suspension/tire/drivetrain stability but multiply wheel queries unless road planes are safely reused. Interpolate input/targets and deduplicate outer-tick events.
- **Determinism:** Canonicalize support-hit ties, surface lookup, curve evaluation, differential order, force accumulation, gear shifts, assists, and events. Avoid raw multithreaded query order and unversioned curve edits.
- **Rollback memory:** Snapshot chassis transform/velocities/sleep, wheel compression/contact/spin, engine RPM, clutch, gear/shift timer, differentials, assists, damage/config generation, and constraint continuation. Re-execute road queries. Full remote-vehicle rollback is expensive; server authority plus prediction for the controlled vehicle is the practical default.

## 6. Pros and Cons

### Raycast wheels

**Pros:** cheap, stable, simple, and easy to batch.  
**Cons:** point contact can miss curb/edge volume and allows visually implausible support.

### Shape-cast wheels

**Pros:** better curb, rock, gap, and wide-tire behavior.  
**Cons:** more broad/narrow work, ambiguous multiple contacts, and harder deterministic selection.

### Query-driven wheels

**Pros:** efficient, tunable, and avoids many small rigid bodies/constraints.  
**Cons:** cannot reproduce every wheel-obstacle interaction and needs bespoke force logic.

### Fully physical wheels

**Pros:** emergent rolling/contact and mechanical damage.  
**Cons:** solver-heavy, jitter-prone, mass-ratio sensitive, and difficult to network.

## 7. ECS Architectural Integration

Assets:

- `VehicleAsset`: chassis collider/mass/COM/inertia, wheel layout, drivetrain graph, aero, assists, LOD, and damage mappings.
- `WheelProfile`: radius/width, suspension axis/travel/spring/damper/preload, tire curves, brake, steer, query shape/profile, force application point.
- `SurfaceTirePair`: longitudinal/lateral grip, rolling resistance, sink/roughness modifiers, effects tags.
- `PowertrainProfile`: engine torque curve/inertia/idle/redline, clutch, gears, final drive, differential topology.

Components:

- `VehicleState`, `VehicleInput`, `VehiclePowertrainState`, `VehicleWheelRange`, `VehicleDamageState`, and `VehicleNetworkState`.
- Wheel runtime data stays in a dense physics-owned pool referenced by a generation-checked range rather than one ECS entity per wheel.

Systems:

1. Gather tick-addressed player/AI inputs.
2. Publish kinematic road/platform state and query snapshot.
3. Batch suspension queries.
4. Simulate suspension, tires, drivetrain, assists, and aero in jobs.
5. Deterministically reduce/apply forces and step physics.
6. Commit vehicle/wheel state and events.
7. Interpolate cockpit, chase camera, wheel mesh, suspension, audio, and effects.

FP/TP presentation consumes the same authoritative seat, chassis, and wheel state. Camera shake and wheel animation cannot feed back into physics.

## 8. Body, Collider, Query, Constraint, and Event Interfaces

```text
VehicleInputCommand {
  tick, vehicleId, inputSequence,
  steering, throttle, brake, handbrake, clutch,
  requestedGear?, assistFlags
}

WheelQueryRequest {
  tick, snapshotId, vehicleId, wheelId,
  startPose, direction, distance,
  shape: Ray | Sphere | Cylinder | Convex,
  queryProfile, capacity
}

WheelContactState {
  tick, wheelId, grounded,
  body, bodyGeneration, subshape,
  point, normal, surfaceVelocity, materialId,
  suspensionLength, jounce, jounceSpeed,
  normalLoad, longitudinalSlip, lateralSlip
}

VehiclePowertrainState {
  engineRPM, engineOmega, clutchSlip,
  currentGear, targetGear, shiftTimer,
  wheelDriveTorque[], differentialState[]
}

VehicleForceCommand {
  tick, vehicleId, wheelId?,
  targetBody, targetGeneration,
  point, force, torque, sourceKind,
  stableCommandId
}

VehicleState {
  tick, chassisBody, pose, linearVelocity, angularVelocity,
  powertrain, wheelRange, sleepState,
  configGeneration, damageGeneration, stateHash
}

VehicleEvent {
  tick, vehicleId,
  kind: Grounded | Airborne | GearChanged | BottomedOut |
        TireSlip | Impact | PartBroken | RolledOver |
        Slept | Woke | InvalidSetup,
  wheelId?, body?, magnitude?, stableEventId
}
```

Trailers, axles, tracks, and breakable parts use the generic constraint interface. Vehicle tire/suspension output is not exposed as arbitrary contact callbacks; it is an ordered force/result stream.

## 9. Integration Plan

1. Establish SI units, coordinate/frame conventions, fixed-step phase order, deterministic curves, and vehicle/wheel asset validation.
2. Implement a four-wheel raycast chassis with spring/damper suspension and static friction-limited tire forces.
3. Add sprung-mass/COM calculation, anti-roll, force application points, surface pairing, and dynamic-road velocity.
4. Add wheel angular state, longitudinal/lateral slip, braking, steering, engine, clutch, gears, and differentials.
5. Add low-speed stabilization, traction control, ABS, stability control, and telemetry.
6. Add optional sphere/cylinder sweeps for off-road/large-wheel classes.
7. Add moving platforms, dynamic ground reaction, trailers, motorcycles, and tracked vehicles as measured extensions.
8. Add damage/profile swaps: puncture, missing wheel, bent suspension, engine/drivetrain degradation, and detached parts.
9. Add sleep/LOD, networking, prediction/rollback, replay hashes, visual debugger, stress scenes, and automated handling tests.

## 10. Verification Strategy

- Static setup: weight balance, ride height, wheel load sum, COM shift, suspension travel, bottom-out/top-out, and no-input rest.
- Road geometry: planes, slopes, banks, curbs, steps, gaps, mesh seams, rocks, moving platforms, rotating ferries, and dynamic debris.
- Tire tests: acceleration, braking distance, skidpad, slalom, split-friction braking, combined braking/turning, low-speed creep, reverse, handbrake, and airborne spin.
- Drivetrain: torque curve, stall/idle/redline, shift timing, clutch slip, open/limited-slip/locked differential, driven-wheel loss, and numerical energy checks.
- Stability: tick-rate/substep matrix, spring/damper sweep, mass/COM extremes, high speed, rollover, landing, pileups, and trailer jackknife.
- Damage: puncture, wheel removal, suspension collapse, chassis collider swap, break events, rollback, and replication.
- Determinism: worker count, query structure rebuild, equal-distance supports, surface table order, gear shifts, sleep/wake, origin rebase, and state hashes.
- Networking: latency/jitter/loss, controlled-vehicle prediction, remote interpolation, collision correction, platform transitions, and exploit input timestamps.
- Performance: thousands of parked vehicles, dense traffic, off-road shape casts, large wheel counts, articulated convoys, and pileups; record all query/solver/job/memory metrics.
- Visualization: suspension line/volume, selected and rejected hits, wheel basis, compression/load, tire-force ellipse, slip, force application point, COM/inertia, drivetrain flow, assists, island/sleep/LOD, and correction history.

## 11. Risks and Open Decisions

- Target handling model: arcade, semi-realistic, simulation, or per-profile range.
- Ray versus sphere/cylinder/convex wheel query by class/platform.
- Suspension parameter units, sprung-mass solver, anti-roll, and expansion-rate limit.
- Tire model/curve format, combined-slip rule, load sensitivity, camber, temperature/wear, and surface pairing.
- Low-speed sticky constraint versus damping/brake approximation.
- Force application at contact versus fixed chassis point.
- Engine/clutch/transmission/differential fidelity and deterministic curve evaluation.
- Assist policies and whether they are authoritative inputs or derived controls.
- Motorcycle balance, tracked-vehicle model, trailers, hovercraft, and aircraft scope.
- Vehicle-to-dynamic-road reaction and unsprung/full-wheel rigid bodies.
- Per-vehicle iterations/substeps and wheel-query reuse across substeps.
- Damage topology, missing wheel, breakage, and collider/mass recook policy.
- Server authority, local prediction history, remote collision, and rollback tier.
- Sleep/LOD behavior for traffic and streamed vehicles.

## 12. Engineering Recommendations

### Engineering recommendations

1. Ship a rigid chassis with query-driven wheels; do not use visible wheel meshes as physical rolling bodies by default.
2. Start with ray wheels and add sphere/cylinder sweeps only for asset classes whose curb/off-road tests show a meaningful benefit.
3. Derive or validate sprung masses so their total and moment match chassis mass/COM; make ride-height/load checks cook-time gates.
4. Compute suspension, tire, and drivetrain in fixed-tick jobs, then apply forces through one deterministic reduction.
5. Model longitudinal and lateral slip separately but clamp their combined force by surface grip and normal load.
6. Store surface-tire interaction in a project-owned versioned table; do not assume general rigid-body material friction is the tire model.
7. Add an explicit low-speed stabilization state with thresholds, dwell, and hysteresis.
8. Keep force application point configurable; favor stable chassis points for arcade profiles and measured contacts for dynamic-ground fidelity.
9. Preallocate wheel/query/force/event data, batch suspension queries, and reduce query frequency only for sleeping or non-authoritative LOD vehicles.
10. Use per-vehicle substep/quality tiers before raising global physics cost; instrument load, slip, motor torque, solver saturation, and energy.
11. Predict only the locally controlled vehicle by default; keep remote vehicles server-authoritative and interpolated.
12. Treat vehicle damage as tick-boundary profile/topology changes with stable IDs and rollback records.
13. Maintain backend-neutral handling fixtures and replay hashes before choosing Jolt, PhysX Vehicle2, or Chaos-specific acceleration.

## 13. Source Links

- NVIDIA PhysX 5.6, *Vehicles*: https://nvidia-omniverse.github.io/PhysX/physx/5.6.1/docs/Vehicles.html
- NVIDIA PhysX 5.4, *Scene Queries*: https://nvidia-omniverse.github.io/PhysX/physx/5.4.1/docs/SceneQueries.html
- Jolt Physics 5.5 architecture and `VehicleConstraint`: https://jrouwe.github.io/JoltPhysicsDocs/5.5.0/index.html
- Jolt Physics, `VehicleConstraint`: https://jrouwe.github.io/JoltPhysicsDocs/5.2.0/class_vehicle_constraint.html
- Jolt Physics, `WheeledVehicleController`: https://jrouwe.github.io/JoltPhysics/class_wheeled_vehicle_controller.html
- Jolt Physics, `WheelSettings`: https://jrouwe.github.io/JoltPhysicsDocs/5.3.0/class_wheel_settings.html
- Epic Games, *Chaos Vehicles* (UE 5.8): https://dev.epicgames.com/documentation/en-us/unreal-engine/chaos-vehicles
- Epic Games, *Chaos Modular Vehicles Quickstart* (UE 5.8): https://dev.epicgames.com/documentation/en-us/unreal-engine/chaos-modular-vehicles-quickstart
- Epic Games, *How to Set up Vehicles* (UE 5.8): https://dev.epicgames.com/documentation/en-us/unreal-engine/how-to-set-up-vehicles-in-unreal-engine
- Unity Technologies, `WheelCollider` (Unity 6): https://docs.unity3d.com/6000.0/Documentation/ScriptReference/WheelCollider.html
- Unity Technologies, *Wheel collider friction* (Unity 6): https://docs.unity3d.com/6000.0/Documentation/Manual/wheel-colliders-friction.html
