# Operation Mythology Physics Research Index

This physics-only index records new reports created after 2026-07-27 02:00 America/Los_Angeles.

Before every research batch:

1. Recursively scan `C:\Users\steve\Desktop\GAME SKILLS`.
2. Inspect the legacy shared index and physics reports in `C:\Users\steve\Documents\BACKUP`.
3. Inspect this index and every report in this folder.
4. Research only genuinely uncovered subjects, unresolved decisions, corrections, or meaningful updates.

## Legacy physics corpus

- `C:\Users\steve\Documents\BACKUP\operation-mythology-physics-20260727-012854.md`
- `C:\Users\steve\Documents\BACKUP\operation-mythology-physics-20260727-013905.md`
- `C:\Users\steve\Documents\BACKUP\operation-mythology-physics-20260727-014521.md`
- `C:\Users\steve\Documents\BACKUP\operation-mythology-physics-20260727-015044.md`
- `C:\Users\steve\Documents\BACKUP\operation-mythology-physics-20260727-015548.md`

New entries must be appended only after the corresponding report has been saved and validated. Each entry records the exact path, timestamp, subjects, major claims, engineering recommendations, sources, and remaining open decisions.

## 2026-07-27 02:07:17 America/Los_Angeles — Physics & Collisions

**Report path:** `C:\Users\steve\Desktop\EXTRA SKILS\Operation Mythology Physics\operation-mythology-physics-20260727-020717.md`

**Timestamp:** `20260727-020717`

**Subjects covered:**

- Combat proxy separation: movement/physics colliders, hurtboxes, hitboxes, interaction volumes, and cosmetic geometry
- Fixed-tick swept melee, bounded angular/distance subdivision, per-attack duplicate suppression, and multi-target rules
- Hitscan, query-driven projectiles, physical projectiles, penetration, ricochet, and stable impact identity
- Explosion overlap, deterministic target reduction, exposure/occlusion traces, damage falloff, and separate impulse commands
- Immutable hit candidates, authoritative damage requests/resolution, rollback-safe events, and FP/TP compatibility
- Historical hurtbox snapshots, server-side rewind, timestamp validation, memory limits, fairness, and anti-abuse boundaries
- Combat-specific performance, determinism, telemetry, stress tests, and regression fixtures

**Major claims:**

- Collision discovery and damage mutation should be separate stages; query/contact results are geometric facts, while an authoritative gameplay system decides whether and how much damage is applied.
- Melee needs swept volumes between fixed-tick poses because frame-local overlap can miss fast arcs.
- Hitscan, projectiles, melee, and explosions require different acquisition policies but can share one normalized candidate and damage pipeline.
- Query-driven projectiles are preferable when continuous impact detection matters but emergent solver interaction does not.
- Explosion processing is a bounded overlap followed by deterministic exposure/occlusion queries rather than damage to every raw overlap.
- Server rewind should query compact historical hurtbox data without mutating the live simulation world.
- Authoritative result ordering and stable hit identity are required to prevent duplicate damage/effects during rollback and replay.

**Engineering recommendations:**

- Use authored primitive combat proxies with stable hurtbox IDs and body-region/material metadata; neither the render mesh nor first-person viewmodel is authoritative.
- Sweep melee shapes between authoritative poses with bounded subdivision and deduplicate by attack, target generation, and authored repeat policy.
- Normalize all combat hits into immutable candidates, then validate and commit damage in a separate fixed-tick system.
- Default fast bullets/projectiles to ray or shape-swept query simulation; use rigid bodies only for materially relevant physical interaction.
- Resolve explosions with capped overlaps, deterministic reduction, exposure rays, and separate damage/impulse commands.
- Start server rewind with players and hitscan, a short capped history, strict timestamp validation, and a separate read-only query dataset.
- Preallocate combat buffers, expose overflow, canonicalize candidate order, and ship visualization/rejection telemetry from the first milestone.

**Sources:**

- Epic Games UE 5.8 traces, multi-sphere traces, point damage, radial damage, and `TakeDamage` documentation
- Unity 6 caller-buffered non-allocating overlap and box-cast APIs
- Valve Developer Community lag compensation, Source multiplayer networking, and weapon authoring documentation
- Godot Engine stable ray-casting documentation

**Remaining open decisions:**

- Gameplay-skeleton versus full-pose versus hybrid hurtbox updates and hurtbox LOD budgets
- Melee primitive set, subdivision limits, multi-hit cadence, and pose authority
- Hitscan penetration/ricochet/pellet policy and deterministic spread
- Query-driven versus physical projectile classes
- Explosion exposure samples, cover semantics, destructible ordering, and impulse falloff
- Rewind duration, history representation, interpolation accounting, and accepted command-age bounds
- Historical scope for shields, vehicles, doors, moving cover, destructibles, and melee
- Predicted impact reconciliation, ragdoll hurtbox policy, and friendly/self-damage rules

## 2026-07-27 02:13:35 America/Los_Angeles — Physics & Collisions

**Report path:** `C:\Users\steve\Desktop\EXTRA SKILS\Operation Mythology Physics\operation-mythology-physics-20260727-021335.md`

**Timestamp:** `20260727-021335`

**Subjects covered:**

- Query-driven capsule controllers for first- and third-person gameplay
- Fixed-tick sweep-and-slide, deterministic corners, floors, slopes, steep sliding, ground snap, and ledges
- Explicit up-forward-down stair stepping with clearance, walkability, rise, and progress validation
- Moving-platform identity, local anchors, surface velocity, update order, detach, inherited velocity, and crush policies
- Gameplay-governed dynamic-body pushing and character-character interaction
- Crouch/stand resizing, penetration recovery, last-valid-state fallback, prediction, rollback, and interpolation
- Controller performance, allocations, locality, sleeping, island effects, query batching, telemetry, and adversarial tests

**Major claims:**

- Responsive player movement is better modeled as a guarded gameplay query solver than an ordinary unconstrained rigid body.
- Production controllers converge on capsule sweeps, contact tolerance, floor classification, explicit step logic, and application-owned state.
- Moving platforms require stable support identity, local contact anchors, surface motion, and a fixed platform/controller/presentation order.
- Raw physics reaction is insufficient for convincing dynamic-body pushing; the interaction needs gameplay-authored impulse policy.
- Penetration recovery must be bounded and separated for static/kinematic versus dynamic geometry.
- Presentation interpolation and FP/TP rig differences must not alter authoritative collision state.

**Engineering recommendations:**

- Use a query-driven authoritative capsule with bounded sweep-and-slide iterations and deterministic hit sorting.
- Separate slope classification, steep sliding, snap, stair, and ledge policies.
- Track platforms with generation-checked body/subshape IDs plus a local anchor; explicitly define inherited velocity and crush/teleport behavior.
- Apply capped dynamic-body push commands after movement instead of allowing solver reaction to drive the player.
- Preserve capsule bottom during stance changes and require clearance before expansion.
- Snapshot compact continuation state and re-execute queries during rollback.
- Preallocate scratch/results, instrument iteration caps and recovery, and maintain backend-neutral golden fixtures.

**Sources:**

- Jolt Physics 5.5 `CharacterVirtual`, character-controller overview, and character contact listener
- NVIDIA PhysX character-controller documentation
- Epic Games UE 5.8 Character Movement Component and experimental Mover documentation
- Unity 6 Character Controller component reference

**Remaining open decisions:**

- Query, rigid-body, or hybrid controller classes and capsule/contact-offset values
- Slope speed, sliding, stair, snap, and ledge policies
- Platform update order, rotation transfer, inherited velocity, crush, teleport, and despawn behavior
- Dynamic push limits, torque suppression, wake policy, and multiplayer authority
- Character-character collision/avoidance and recovery fallback
- Arbitrary gravity, local movement subdivisions, backend query snapshots, and replay compatibility
- FP camera collision/step smoothing and dedicated-server movement-pose requirements

## 2026-07-27 02:23:01 America/Los_Angeles — Physics & Collisions

**Report path:** `C:\Users\steve\Desktop\EXTRA SKILS\Operation Mythology Physics\operation-mythology-physics-20260727-022301.md`

**Timestamp:** `20260727-022301`

**Subjects covered:**

- Passive, partial, and powered ragdolls plus physical-animation transitions and recovery
- Fixed, distance, point, hinge, cone, slider, swing-twist, and six-DOF constraints
- Joint-local frames, limits, friction, compliance, motors, projection, breakage, and warm-start invalidation
- Maximal-coordinate rigid-body chains versus reduced-coordinate articulations
- Self-collision filtering, mass/inertia validation, character-capsule interaction, sleep, LOD, and corpse handling
- Solver/island cost, allocations, locality, substeps, determinism, networking, rollback memory, telemetry, and stress testing

**Major claims:**

- A production ragdoll is an offline-authored body/constraint tree with stable local frames, bounded limits, deliberate mass/inertia, and explicit self-collision exclusions.
- Stability depends on topology, mass ratios, timestep, target continuity, and filtering as well as solver iterations.
- Reduced-coordinate articulations eliminate locked-axis separation and handle tree mass ratios well, but constrain topology and direct link mutation.
- Powered ragdolls require force/torque-limited, rate-limited joint-space targets rather than per-link teleports.
- Ragdoll activation and recovery are ticked authority transitions with pose/velocity seeding and clearance/root-alignment checks.
- Exact ragdoll rollback is materially more expensive than rigid-body transform snapshots because constraint continuation, warm start, sleep, breaks, and structural history matter.

**Engineering recommendations:**

- Use a reduced semantic body set with primitive/convex shapes; prefer hinge and swing-twist/cone joints over generic six-DOF.
- Start with portable maximal-coordinate constraints and benchmark reduced-coordinate articulations for powered trees/mechanisms.
- Bound motor targets and forces, record saturation, and use per-ragdoll/island quality tiers before global iteration increases.
- Disable adjacent self-collision by default and prevent the character capsule from fighting active ragdoll bodies.
- Buffer constraint/profile/break mutation outside the step and reset warm start only after discontinuities.
- Sleep/freeze whole stable ragdolls, add corpse LOD early, and default multiplayer ragdolls to server-authoritative or cosmetic tiers.

**Sources:**

- Jolt Physics 5.5 constraint, motor, breakage, island, and swing-twist documentation
- NVIDIA PhysX reduced-coordinate articulation and stability documentation
- Epic Games UE 5.8 physics constraints, physical animation, and substepping documentation
- Godot Engine stable ragdoll and `PhysicalBone3D` documentation

**Remaining open decisions:**

- Maximal constraints versus reduced-coordinate articulations by asset
- Joint-frame convention, body count, self-collision matrix, mass/inertia ratios, and LOD tiers
- Motor/compliance units, target timing, solver iterations, and substeps
- Passive/partial/powered launch scope and breakage policy
- Character capsule, damage hurtbox, recovery, and gameplay-authority boundaries
- Server-authoritative, replicated, cosmetic, or predicted network tiers
- Snapshot coverage, corpse lifetime, streaming, save/load, and backend-upgrade compatibility

## 2026-07-27 02:30:32 America/Los_Angeles — Physics & Collisions

**Report path:** `C:\Users\steve\Desktop\EXTRA SKILS\Operation Mythology Physics\operation-mythology-physics-20260727-023032.md`

**Timestamp:** `20260727-023032`

**Subjects covered:**

- Wheeled/tracked vehicle architecture using a rigid chassis and query-driven wheels
- Suspension rays/sweeps, sprung mass, spring/damper, anti-roll, contact load, moving/dynamic road surfaces
- Longitudinal/lateral slip, combined tire-force limits, surface pairing, and low-speed stabilization
- Engine, clutch, transmission, gearing, differentials, brakes, steering, and assists
- Wheel-query batching, solver/island cost, substeps, allocations, locality, sleep/LOD, determinism, rollback, and networking
- Vehicle damage/profile changes, trailers, motorcycles, tracks, telemetry, debugging, and handling regression tests

**Major claims:**

- Game vehicles generally query road support and apply computed suspension/tire forces to one chassis rather than simulate visual wheels as ordinary rolling bodies.
- Sprung masses should match chassis mass and center of mass for the intended rest pose.
- Shape-cast wheels improve curb/off-road volume at higher query cost; ray wheels are the portable baseline.
- Longitudinal and lateral tire demand must share a load/friction limit, and low-speed tire behavior needs explicit stabilization.
- Vehicle simulation is fixed-step sensitive and requires snapshotting wheel/drivetrain continuation state, not chassis transforms alone.

**Engineering recommendations:**

- Ship a rigid chassis with raycast wheels; add sphere/cylinder sweeps only from measured class-specific need.
- Validate sprung mass/COM, suspension travel/load, and tire/surface tables offline.
- Compute queries and vehicle forces in jobs, then apply one deterministic reduction.
- Add bounded low-speed stabilization with dwell/hysteresis and per-vehicle quality/substep tiers.
- Keep wheel/query/state storage dense and preallocated; reduce query frequency only for sleeping/non-authoritative LOD.
- Predict the locally controlled vehicle and interpolate remote server-authoritative vehicles by default.
- Treat damage as tick-boundary profile/topology changes and maintain backend-neutral handling fixtures.

**Sources:**

- NVIDIA PhysX 5.6 Vehicle SDK and PhysX 5.4 scene-query documentation
- Jolt Physics vehicle constraint, wheel, controller, engine/transmission/differential documentation
- Epic Games UE 5.8 Chaos Vehicles and Chaos Modular Vehicles documentation
- Unity 6 WheelCollider and wheel-friction documentation

**Remaining open decisions:**

- Arcade-to-simulation target and wheel query type by vehicle class
- Suspension, anti-roll, expansion limit, tire/load/camber/wear, surface-pair, and low-speed models
- Force application points, drivetrain fidelity, assist authority, and deterministic curves
- Motorcycles, tracks, trailers, hover/air vehicles, and dynamic-road reaction scope
- Per-vehicle iterations/substeps and query reuse
- Damage topology, missing wheels, server authority, prediction/rollback, sleep/LOD, streaming, and replay compatibility

## 2026-07-27 02:40:06 America/Los_Angeles — Physics & Collisions

**Report path:** `C:\Users\steve\Desktop\EXTRA SKILS\Operation Mythology Physics\operation-mythology-physics-20260727-024006.md`

**Timestamp:** `20260727-024006`

**Subjects covered:**

- Cloth, ropes, cables, chains, nets, hair/strap chains, flags, and soft secondary motion
- XPBD particles, compliance, persistent multipliers, stretch/bend/shear/area/volume/attachment/backstop/contact constraints
- Skinned anchors, collision proxies, self-collision pruning/layers, friction, one-/two-way rigid coupling, tearing, cutting, tension, and winches
- CPU-authoritative gameplay ropes, CPU/GPU cosmetic cloth, rigid-link alternatives, LOD, freeze/wake, and render deformation output
- Broad/narrow cost, constraint coloring/iterations, allocations, locality, batching, substeps, determinism, rollback memory, telemetry, and stress tests

**Major claims:**

- XPBD reduces timestep/iteration dependence of authored compliance and supplies useful constraint-force estimates.
- Secondary simulation should use a low-resolution cooked topology separate from render geometry.
- Self-collision and two-way coupling dominate cost and must be deliberately pruned and budgeted.
- Cosmetic GPU cloth is not a suitable exact gameplay/rollback authority.
- Gameplay ropes require fixed-tick bounded state including particles, persistent multipliers, attachments, winch/tension, topology generation, and breaks.

**Engineering recommendations:**

- Use XPBD as the common cloth/rope model with cooked constraint batches/colors, stable IDs, exclusions, mappings, and LODs.
- Default cloth to one-way collision against simple proxies and enable selected self-collision only where visible.
- Use CPU fixed-tick XPBD for gameplay ropes and GPU simulation only for cosmetic tiers without authoritative readback.
- Use rigid links only when torque/visible links/two-way contact justify solver-island cost.
- Buffer attachment/winch/cut/tear/profile changes at tick boundaries and bound every force, pair, iteration, substep, and topology capacity.
- Publish current/previous deformation data for temporal rendering and snapshot continuation state only for authoritative instances.

**Sources:**

- Macklin, Müller, and Chentanez XPBD paper
- Bender, Müller, and Macklin Position-Based Dynamics survey
- Epic Games UE 5.8 Chaos Cloth/Dataflow/self-collision documentation
- Jolt Physics soft-body and skinned-constraint documentation
- NVIDIA PhysX 5.7 GPU/PBD simulation documentation
- Unity Cloth manual

**Remaining open decisions:**

- Project-owned XPBD versus backend cloth/soft-body solvers and CPU/GPU platform tiers
- Compliance calibration, simulation mesh/LOD, proxy type, CCD, self-collision, and friction
- One-/two-way coupling, gameplay-rope particle/wrapping/winch/break rules, and rigid-link scope
- Preauthored tearing versus runtime topology, wind/aerodynamics, and freeze/significance policy
- GPU synchronization, network authority, rollback/save memory, and FP/TP cosmetic duplication

---

## 2026-07-27 02:50:06 America/Los_Angeles — Physics & Collisions

**Report path:** `C:\Users\steve\Desktop\EXTRA SKILS\Operation Mythology Physics\operation-mythology-physics-20260727-025006.md`

**Timestamp:** `20260727-025006`

**Subjects covered:**

- Physics-specific health counters, phase traces, debug drawing, selective capture, and offline playback
- Stable schema across world/tick/substep/stage, rollback timeline, origin epoch, and generation-checked object IDs
- Executable snapshot-plus-command repro bundles, state/topology/config/continuation hashes, and first-divergence reports
- Broad/narrow, solver, allocation, locality, sleep, islands, queries, substeps, rollback-memory telemetry
- Adversarial generators, invariant checks, deterministic fixtures, performance regression gates, and artifact retention
- Client/server multi-source correlation and backend-native Chaos/Jolt/PhysX diagnostic extensions

**Major claims:**

- General profiling is insufficient without physics-specific causal IDs, stage semantics, and continuation-state visibility.
- Mature engines combine bounded statistics, debug visualization, profiler spans, and opt-in state capture.
- Reproducibility requires ordered inputs plus a sufficient initial/internal state, not transforms alone.
- Full capture must be selective because its volume and overhead can perturb the failure.
- Separate hashes for state, topology, configuration, and continuation localize first divergence.
- Multithreaded callback data must be copied into stable bounded records rather than retaining backend pointers.

**Engineering recommendations:**

- Reuse engine telemetry transport but define a versioned physics schema keyed by tick/substep/stage/world/rollback/origin.
- Keep bounded health counters always available; make per-object/full state trigger-driven.
- Render debug data from immutable post-step snapshots with batched geometry.
- Make snapshot-plus-ordered-command bundles the primary executable repro artifact.
- Add double-step determinism and worker/order variants to CI; make every overflow visible.
- Maintain adversarial fixture families and randomized valid structural streams with minimization.
- Gate releases on absolute budgets plus matched performance statistics and preserve all failing artifacts.
- Integrate Chaos Visual Debugger, Jolt state/debug tools, and PhysX/OmniPVD behind the portable schema.

**Sources:**

- Epic Games UE 5.8 Chaos Visual Debugger capture/playback documentation
- Jolt Physics 5.5 determinism and debug-rendering documentation
- NVIDIA PhysX simulation statistics/profiling and OmniPVD documentation
- Box2D 3.1 simulation and debug-draw documentation

**Remaining open decisions:**

- Schema breadth/overhead, capture file format/compression/versioning/retention
- Canonical hash fields and bitwise versus quantized comparison
- Backend continuation-state exposure and divergence granularity
- Trigger thresholds, pre/post window, crash-safe flush, and privacy/redaction
- Platform/backend/compiler/SIMD/worker-count matrix and statistics gates
- Fuzz minimization, GPU physics observability, and required native capture tools

---

## 2026-07-27 02:55:44 America/Los_Angeles — Physics & Collisions

**Report path:** `C:\Users\steve\Desktop\EXTRA SKILS\Operation Mythology Physics\operation-mythology-physics-20260727-025544.md`

**Timestamp:** `20260727-025544`

**Subjects covered:**

- Offline-prefractured chunk hierarchies, support/bond graphs, structural damage, strain, and stress
- Atomic aggregate splitting, inherited motion, collider/body replacement, topology revisions, and cache invalidation
- Authoritative fragments, bounded debris tiers, sleeping, retirement, collision LOD, and streaming/persistence
- Deterministic damage commands, canonical topology deltas, rollback checkpoints, late join, and replay
- Broad/narrow, solver/island, allocation, locality, query, fixed-step, substep, and rollback-memory costs
- Destruction asset, invariant, conservation, networking, stress, and adversarial rubble verification

**Major claims:**

- Collision damage and physics topology are separate responsibilities joined by explicit commands and split events.
- NVIDIA Blast is physics/graphics agnostic and separates immutable assets, mutable family state, damage evaluation, and split reporting.
- Runtime topology changes invalidate compound subshape identities, contact caches, constraints, and query results.
- Prefractured assets provide stable IDs and bounded runtime behavior that arbitrary cutting does not.
- Full per-shard rollback is impractical; immutable topology plus checkpoints and ordered deltas is the scalable pattern.
- Fragment activation can spike broad-phase pairs, cold manifolds, islands, solver work, and allocations simultaneously.

**Engineering recommendations:**

- Use offline-prefractured assets with stable chunk/bond IDs and project-owned topology state.
- Commit deterministic topology change sets only at a fixed structural phase outside callbacks.
- Replicate authoritative broken-bond/component deltas and exclude cosmetic shards from rollback.
- Carry topology revision on every cached subshape, query, manifold-derived event, and structural anchor.
- Preserve parent motion at split and represent cinematic separation as an explicit replicated impulse.
- Budget authoritative fragments separately from pooled cosmetic debris and degrade in stable order.
- Preallocate structural work buffers, surface overflow, batch backend mutations, and gate content with rubble stress tests.

**Sources:**

- NVIDIA Blast SDK 5.0.6, fracture API, and stress-solver documentation
- Epic Games Unreal Engine 5.8 Chaos Destruction, Geometry Collections, Fields, and Dataflow documentation
- Jolt Physics mutable-compound and subshape-identity documentation

**Remaining open decisions:**

- Destruction-graph backend, chunk/body budgets, damage units, and bond material model
- Stress cadence/iterations/authority and immutable replacement versus mutable compounds
- Collision LOD, sibling grace, CCD, fragment filtering, momentum, and mass-loss policies
- Replication payload/checkpoints, rollback bytes, late join, persistence, and settled debris
- Cross-cell structures, runtime cutting, repair, authoring workflow, and competitive collision policy

---

## 2026-07-27 03:04:41 America/Los_Angeles — Physics & Collisions

**Report path:** `C:\Users\steve\Desktop\EXTRA SKILS\Operation Mythology Physics\operation-mythology-physics-20260727-030441.md`

**Timestamp:** `20260727-030441`

**Subjects covered:**

- Explicit force, acceleration, impulse, velocity-change, torque, and angular-impulse semantics
- World and local gravity fields, priorities, blending, per-body response, wake policy, and fixed-step application
- Water snapshots, pontoons, submerged convex volume, triangle/patch forces, buoyancy, drag, lift, and currents
- Water enter/exit state, characters, boats/platforms, projectiles, compounds/destruction, and constraints
- Broad/narrow, solver, allocation, locality, sleep, islands, batching, substeps, determinism, and rollback costs
- Analytical, adversarial, performance, networking, and first-divergence verification

**Major claims:**

- Explicit force modes prevent mass/timestep ambiguity at the gameplay/physics boundary.
- Mature engines expose both low-cost pontoon and higher-fidelity submerged-volume/triangle buoyancy patterns.
- Physics water must use solver-safe snapshots rather than rendered surface or scene-object access during jobs.
- Buoyancy is generally an external wrench, but floating contact piles can still increase island and solver cost.
- Applying a tick-sized impulse per substep is erroneous; continuous forces must follow the actual substep schedule.
- Derived per-probe forces need not be snapshotted when body state, water revisions, commands, and transition state are preserved.

**Engineering recommendations:**

- Adopt one SI-unit force-command API with explicit modes and deterministic source ordering.
- Use bounded primitive gravity fields and versioned physics-facing water surface/flow snapshots.
- Ship pontoons by default, convex submerged volume for important objects, and triangle forces only when justified.
- Batch samples by region, preallocate buffers, accumulate one wrench/body, and expose every clamp/overflow.
- Keep query-driven characters authoritative in water and consume current through controller policy.
- Avoid waking stable floating bodies every tick; replicate authoritative important boats and snapshot water revisions.

**Sources:**

- NVIDIA PhysX rigid-body dynamics and custom-gravity documentation
- Jolt Physics body/body-interface buoyancy and submerged-volume documentation
- Epic Games Unreal Engine 5.8 Water/Buoyancy component and runtime API documentation
- Unity official `Rigidbody.AddForce` force-mode documentation

**Remaining open decisions:**

- Force limits/wake defaults and gravity-field overlap/orientation rules
- Water representation, authority, wave/current fidelity, pontoon authoring, and convex clipping backend
- Density versus gameplay coefficients, drag/lift/planing, high-speed impact, and force clamps
- Transition hysteresis/events, sleeping cadence, characters/boats, and destruction/rope integration
- Replication/correction, rollback bytes, late join, cross-platform wave evaluation, streaming, and origin shifts

---

## 2026-07-27 03:12:38 America/Los_Angeles — Physics & Collisions

**Report path:** `C:\Users\steve\Desktop\EXTRA SKILS\Operation Mythology Physics\operation-mythology-physics-20260727-031238.md`

**Timestamp:** `20260727-031238`

**Subjects covered:**

- Material-pair friction/restitution combination, thresholds, rolling resistance, and cooked lookup
- Solver-safe contact modification, canonical pair orientation, threading, persistence, and capability validation
- One-way surfaces, drop-through tokens, conveyors, surface velocity, impulse caps, and local mass scaling
- Controller/query parity, CCD/substeps, sleeping, islands, rollback, debugging, and event interfaces
- Broad/narrow, solver-iteration, allocation, locality, batching, fixed-step, and pair-state memory costs
- Pair-order, worker-order, CCD, pile, controller, conveyor, one-way, and rollback regression fixtures

**Major claims:**

- Backend pair/shape ordering is not guaranteed, so asymmetric contact rules require canonical role mapping.
- Contact callbacks are concurrent hot-path code and must be thread-safe, reentrant, allocation-free, and world-read-free.
- Target tangent velocity is the established conveyor pattern in PhysX, Jolt, and Box2D.
- Maximum impulse can increase penetration; local mass scaling changes reported impulses and damage thresholds.
- One-way behavior requires persistent side/drop state and matching controller/query predicates.
- CPU contact modification may be unavailable in GPU-oriented backend paths, requiring capability validation.

**Engineering recommendations:**

- Keep categories in filters and ordinary response in a dense cooked material table; modify contacts only exceptionally.
- Canonicalize pairs before any asymmetric policy and use tangential target velocity for conveyors.
- Implement one-way contacts from pre-step geometry, hysteresis, relative velocity, persistent pass state, and deep-overlap policy.
- Make drop-through rollback-aware and require both minimum duration and clearance before re-enabling.
- Share pure surface predicates with controller/query systems, preallocate bounded pair state, and expose overflow.
- Exclude normal/separation edits from the portable baseline and gate every backend/platform capability.

**Sources:**

- NVIDIA PhysX advanced collision-detection/contact-modification and Direct GPU API documentation
- Jolt Physics `ContactSettings`, friction/restitution, and solver-settings documentation
- Box2D 3.1 simulation, surface-material, tangent-speed, pre-solve, and release documentation

**Remaining open decisions:**

- Material combine precedence, dynamic/anisotropic friction, rolling resistance, and restitution thresholds
- One-way tolerances, deep-overlap handling, controller parity, and drop-through targeting/clearance
- Conveyor linear/angular semantics, clamps, sleep behavior, and moving-platform interaction
- Impulse/mass scaling scope, damage interpretation, pair-state capacity/purge, and rollback bytes
- CCD/backend/GPU fallbacks and whether authoritative gameplay may use backend-specific contact edits
