# Operation Mythology Physics & Collisions Research

**Topic:** Runtime destruction, fracture graphs, structural damage, debris, and topology-safe ECS integration  
**Timestamp:** 2026-07-27 02:55:44 America/Los_Angeles  
**Assumptions:** Modular generic ECS; data-oriented memory; selectable physics backend; meter-kilogram-second units; fixed-step simulation; first- and third-person gameplay; prefractured assets as the production baseline; no production-code implementation.

## 1. Feature Overview

This batch closes a previously uncovered boundary between collision damage and runtime body topology: destructible structures that split into independently simulated pieces. It covers authored fracture hierarchies, support/bond graphs, accumulated damage and strain, activation and splitting, collision representation, debris budgets, replication, rollback, persistence, and safe invalidation of contacts and subshape identities.

The recommended baseline is not arbitrary runtime mesh cutting. Assets are fractured and collision-cooked offline into immutable chunks plus a support graph. Runtime damage produces deterministic commands against stable chunk or bond identifiers. A structural service evaluates those commands at a fixed-tick boundary, emits a canonical split result, and asks the physics adapter to replace the old aggregate with a bounded set of new aggregates or rigid bodies. Cosmetic dust and tiny debris remain outside authoritative simulation.

## 2. Existing Coverage and Identified Gap

The required corpus was rescanned before research:

- The legacy physics reports already define fixed-step simulation and rollback boundaries; rigid-body and collider ownership; collider cooking and filtering; broad phase, narrow phase, contact solving, and CCD; and snapshot-safe scene queries.
- The newer physics reports cover combat hit generation and physical damage requests, character control, ragdolls and constraints, vehicles, cloth and ropes, and physics observability/testing.
- The general GAME SKILLS corpus covers ECS/job scheduling, open-world streaming/origin shifts, networking/rollback, asset cooking, and generic telemetry.

The uncovered decision was how physical damage changes collision topology without violating those contracts. Prior work could identify an impact or explosion and apply damage, but did not specify:

- a destructible asset’s chunk hierarchy, bond/support graph, collision proxies, and stable IDs;
- the boundary between gameplay health, structural strain, fracture, and cosmetic effects;
- atomic replacement of a compound body after a split;
- invalidation of manifolds, query hits, subshape IDs, joints, and cached references;
- authoritative networking, rollback memory, save persistence, and late join;
- debris count, broad-phase pair, island, solver, allocation, and streaming budgets.

This is therefore genuinely new coverage rather than a restatement of combat damage or collider cooking.

## 3. Sourced Facts

### Official documentation facts

1. NVIDIA Blast 5.0.6 separates low-level stateless fracture functions, a higher-level toolkit, and extensions. Its low-level functions do not create tasks or allocate/deallocate memory; damage behavior is supplied by user-defined shader functions. Blast assets can contain support structures and multiple chunk hierarchies. The low-level and toolkit layers provide neither physics/collision nor graphics representation; the application must create and update those representations when actors split. The toolkit can process work through worker objects and reports splits/fractures through events.

2. Blast’s portable asset/family layout supports copying and direct binary serialization on platforms with matching endianness. Its serialization extensions add a portable Cap’n Proto path. This supports the architectural separation between immutable cooked topology, mutable family state, and engine-owned bodies.

3. Blast’s stress extension operates on the support graph, propagating forces across bonds with separate tension, compression, and shear limits. It supports static and dynamic actors, linear and angular momentum, configurable graph reduction, and debug rendering. Its documented compute time is linear in the maximum solver iterations per frame. It requires mass, volume, and position for graph nodes and must be notified when actors are created or destroyed.

4. Blast’s fracture API applies ordered fracture commands to an actor and can output chunk/bond fracture events. The caller supplies event buffers; undersizing can lose event data. This is evidence for preallocated, overflow-visible command/result buffers rather than allocation inside the physics step.

5. Unreal Engine 5.8 Chaos Destruction represents destructible assets as Geometry Collections created from meshes and fractured into pieces. Chaos Fields can anchor pieces, activate them, and apply strain. Epic’s field documentation distinguishes damage thresholds from strain magnitude and notes that internal strain can decay thresholds over time. Epic also specifically recommends avoiding falloff with external strain for performance unless its behavior is needed.

6. Jolt’s mutable compound shape permits adding, removing, and moving child shapes, but it is explicitly not thread-safe to mutate. Bodies using it must be write-locked, and shape changes require notification so the broad phase and collision caches are updated. Batched child modification avoids repeated bounds calculation.

7. Jolt documents that mutable compound shapes trade query performance for mutation convenience. Recomputing center of mass is required when child removal materially changes it; bodies and constraints then need shape-change notification. Jolt also warns that subshape IDs become invalid when a compound hierarchy changes.

### Interpretation

These facts support a common pattern across specialized and general-purpose engines: fracture topology is a distinct system that owns graph state; physics owns collision bodies; the two synchronize through explicit commands and split events. They do not establish Operation Mythology’s exact thresholds, budgets, replication policy, or rollback representation. Those remain engineering decisions below.

## 4. Industry-Standard Physics API or Pattern

### Cooked asset

`DestructibleAsset`

- asset/version/content hashes;
- hierarchy of stable `ChunkId` values;
- parent/child and support depth;
- stable `BondId` edges with endpoint chunks, centroid, normal, area, and material class;
- render-piece references kept outside physics;
- per-chunk volume, centroid, mass contribution, inertia contribution, collision shape handle, and bounds;
- support/world anchors;
- precomputed aggregate variants or collision LODs;
- authoring metadata and validation results.

Chunks and bonds use content-stable IDs, never array positions exposed to gameplay. Runtime dense indices are permitted inside a loaded instance.

### Runtime family

`DestructibleFamilyState`

- asset handle and instance generation;
- active chunk and bond bitsets;
- remaining bond health or accumulated strain;
- connected-component/actor membership;
- current aggregate/body handle per component;
- activation, sleep, significance, and debris class;
- deterministic damage sequence counter;
- topology revision;
- rollback/persistence dirty ranges.

### Fixed-tick transaction

1. Combat, explosions, contacts, scripted events, and stress solvers enqueue `StructuralDamageCommand` values.
2. Commands are validated, quantized where needed, and stably sorted by tick, target generation, source priority, source entity, and sequence.
3. A damage shader maps each command to bounded bond/chunk deltas without mutating physics.
4. The structural graph applies deltas and finds affected connected components.
5. It builds a `TopologyChangeSet`: deactivated aggregate, surviving components, activated chunks, body mass properties, velocities, filters, joints, and stable split-event IDs.
6. At the structural-change phase, after callbacks are copied and before the next broad-phase update, the physics adapter atomically removes/replaces bodies.
7. It invalidates manifolds, subshape/query tokens, and constraint references tied to the old topology revision.
8. New bodies inherit rigid velocity at each new center of mass:
   `v_child = v_parent + omega_parent × (x_child_COM - x_parent_COM)`.
9. Optional fracture impulses are applied as separately budgeted commands; topology change itself must not manufacture momentum.
10. Canonical events are committed only after the transaction succeeds.

### Damage channels

- **Gameplay damage:** affects hit points or scripted state and need not fracture.
- **Impact fracture:** derives a bounded structural command from contact impulse/energy after material and cooldown rules.
- **Radial fracture:** evaluates candidate chunks/bonds using deterministic spatial reduction and optional occlusion.
- **Internal strain/decay:** weakens bonds over time.
- **Stress damage:** evaluates support loads at a lower configurable frequency.
- **Authored/scripted break:** names exact bonds/chunks for set pieces.

Never feed raw solver callbacks directly into topology mutation. Contacts may repeat, reorder, or be generated speculatively. Convert them to immutable candidates, deduplicate by contact/event identity, and resolve structural commands in a later deterministic phase.

### Representation tiers

- Intact/far: one static or kinematic proxy.
- Damaged but connected: one aggregate compound body.
- Important separated components: independent authoritative rigid bodies.
- Small debris: non-authoritative pooled bodies with simplified convex shapes and short lifetime.
- Dust/splinters: cosmetic particles with no gameplay collision.
- Settled debris: sleep, merge into a static proxy, convert to instance data, or retire according to persistence policy.

## 5. Performance and Determinism Considerations

### Broad phase

Splitting one aggregate into `k` bodies creates `k` broad-phase proxies and may generate many candidate pairs against nearby geometry and sibling debris. Tree insertion is typically logarithmic per proxy, but a dense explosion can still approach quadratic sibling/environment overlap in practice. Stage proxy creation over a bounded queue, disable sibling collision for an initial grace interval when design permits, and cap authoritative components per event and per cell.

### Narrow phase and contacts

Prefractured convex chunks are predictable but may contain many faces. Use collision LODs and low-hull-count proxies; do not use render shards as colliders. A topology change invalidates persistent manifolds involving the old compound. Expect a cold-contact spike after splitting. Track candidate pairs, generated contacts, rejected sibling pairs, manifold rebuilds, and contact-cache misses by destruction event.

### Solver iterations and islands

New fragments can form one large contact island or many tiny islands. Large rubble piles increase contact constraints and solver iterations; numerous small islands add scheduling overhead. Use per-class iteration caps, sleep stabilization, debris collision simplification, and island-aware work batching. Stress-graph iterations are a separate budget from rigid-body solver iterations and should run at a lower rate or only for significant structures.

### Allocations and topology churn

Damage, fracture results, component discovery, body creation, and events require bounded scratch. Preallocate per-world command/result arenas, body-handle pools, component work queues, and event rings. Overflow is a deterministic policy decision: postpone, coarsen, or reject excess fracture in stable order and emit telemetry. Never silently drop only on one peer.

### Spatial locality and cache behavior

Store bond endpoints, health, flags, and adjacency in dense structure-of-arrays blocks keyed by runtime index. Group active chunks by current component and streaming cell. Process damage commands sorted by family to reuse graph and asset data. Generate body descriptors into contiguous arrays, then batch create/remove through the backend. Keep large immutable render metadata out of the hot structural state.

### Sleeping

Fracture wakes the affected parent, new components, touching bodies, and constraints only as necessary. Tiny fragments receive aggressive sleep thresholds and lifetime policies. A sleeping structure should not run stress iterations unless a force, support change, streaming event, or explicit wake marks it dirty. Sleep state is part of authoritative snapshots if it affects subsequent event ordering.

### Island parallelism

Independent families and post-split components can run in parallel after stable command partitioning. Do not parallel-write a shared graph or backend scene. Produce per-job result buffers, concatenate in deterministic family order, then commit structural mutations in one controlled phase. Worker count must not affect canonical event IDs or body creation order.

### Query batching

Radial damage exposure, fragment clearance, and spawn validation can explode into many scene queries. Broad-phase overlap once per event, reduce to bounded candidates, then batch occlusion or shape queries. Execute against a named immutable snapshot. Results whose target topology revision changed before commit are stale and must be discarded or revalidated.

### Fixed-step cost and substeps

Damage is collected during a tick and committed at a defined boundary. Do not fracture separately in each solver substep unless the backend and replication contract explicitly support it. Contacts across substeps should reduce into one stable maximum/accumulated measure with a documented rule. Newly created components normally enter the next substep/tick; immediate mid-step activation is more responsive but much harder to reproduce.

### Determinism

Prefracture topology, stable IDs, quantized command inputs, stable sorting, fixed thresholds, explicit tie-breakers, deterministic connected-component traversal, and fixed body-creation ordering are required. Floating-point stress propagation may still diverge across platforms. For authoritative multiplayer, replicate canonical broken-bond or split results rather than assuming independently evaluated stress will match bitwise.

### Rollback memory

Full per-tick copies of all chunk transforms are prohibitive. Store immutable asset topology once; snapshot active-bond/chunk bitsets, quantized health deltas, component membership or a reconstruction checkpoint, body states for authoritative components, topology revision, and command sequence. Use periodic full structural checkpoints plus per-tick ordered fracture deltas. Debris that is cosmetic is excluded. Bound maximum rollback-active destructible families and bytes per tick.

## 6. Pros and Cons

### Prefractured graph baseline

**Pros**

- deterministic identifiers and bounded runtime work;
- offline collision validation and LOD generation;
- straightforward replication, replay, persistence, and tests;
- supports authored weak points and progressive activation.

**Cons**

- higher asset size and cook complexity;
- fracture patterns can become visually recognizable;
- authoring and validation burden;
- topology is limited to prepared cuts.

### Arbitrary runtime cutting

**Pros**

- impact-aligned cuts and high visual variety;
- useful for a small number of signature objects.

**Cons**

- expensive mesh, convex, mass-property, UV, and collision generation;
- allocation and latency spikes;
- difficult deterministic replay and network synchronization;
- produces degenerate geometry and unstable tiny pieces.

**Recommendation:** exclude arbitrary runtime cutting from the baseline. Treat any future implementation as a separately budgeted, server-authored feature with cached outcomes.

### Replicating damage commands versus split results

- Commands are compact and replayable but require deterministic evaluation.
- Canonical split results cost more bandwidth but tolerate backend/platform differences.
- Hybrid replication is preferred: send command identity plus authoritative broken-bond/component delta and periodic checkpoints.

## 7. ECS Architectural Integration

### Components

- `DestructibleInstance`: asset handle, family ID, generation, topology revision.
- `StructuralState`: active bitsets, health/strain ranges, dirty flags.
- `StructuralPolicy`: authority, thresholds, budgets, LOD, persistence, collision grace.
- `PhysicsAggregateLink`: component-to-body mapping and backend generation.
- `DebrisState`: class, birth tick, importance, sleep/retire policy.
- `StructuralReplication`: baseline revision, acknowledged delta, checkpoint age.

Large graph arrays live in a structural-state pool, not inline in archetype chunks. ECS components hold compact handles and hot flags.

### Systems and order

1. collect collision/combat/script damage candidates;
2. canonicalize and deduplicate commands;
3. evaluate damage shaders in parallel by family;
4. apply graph deltas and discover components;
5. enforce per-event/world/cell budgets;
6. build immutable topology change sets;
7. commit backend body/constraint/filter mutations;
8. publish fracture, activation, and retirement events;
9. capture rollback delta and replication output;
10. update debug/telemetry views.

Structural changes use an ECS command buffer. Entity destruction or creation never occurs from a physics callback. A chunk becoming an independent body does not require an entity per visual shard; only gameplay-relevant components receive entities.

### Streaming and origins

The structure’s stable family and chunk IDs survive unload/reload and origin rebasing. Persist structural state in cell-local coordinates and asset-relative topology. Cross-cell structures require a single owning cell or an explicit cross-cell support service; duplicating graph authority across cells is prohibited.

## 8. Body, Collider, Query, Constraint, and Event Interfaces

### Body

`CreateFractureBodies(changeSet, bodyBudget) -> FractureCommitResult`

- consumes deterministic component descriptors;
- computes/validates mass, center of mass, inertia, pose, linear/angular velocity;
- assigns collision filters and CCD class;
- returns generation-checked handles in input order;
- reports deferred/coarsened components explicitly.

### Collider

`ResolveChunkCollider(asset, chunkId, collisionLod) -> ShapeHandle`

`ReplaceAggregate(oldHandle, newDescriptors, topologyRevision)`

Collider data is immutable and cached. Runtime compound mutation occurs only in the structural phase under backend locks, followed by required broad-phase/cache notifications. Cached subshape IDs always carry family generation and topology revision.

### Query

`QueryStructuralTarget(hit) -> {familyId, chunkId, bondHint, revision}`

`BatchStructuralExposure(snapshotId, requests) -> results`

Any query result referencing a changed revision is stale. Gameplay may retry against the new snapshot; it must never reinterpret an old dense subshape index.

### Constraint

`RebindStructuralConstraints(changeSet) -> ConstraintDelta`

Joints to world or other actors identify stable chunk anchors. When a component splits, constraints are rebound to the owning new body with the same world anchor and rest state, or deterministically broken if the anchor chunk is inactive. Constraint warm-start data involving removed bodies is invalidated.

### Events

- `StructuralDamageAccepted`
- `BondBroken`
- `ChunkActivated`
- `StructureSplit`
- `DebrisBudgetCoarsened`
- `StructuralConstraintBroken`
- `DebrisRetired`

Events include world, tick, rollback timeline, family ID/generation, topology before/after, source event ID, ordered affected IDs, and authority status. Predicted events are retractable; presentation subscribes only through rollback-aware delivery.

## 9. Integration Plan

1. Define cooked asset schema, stable ID generation, asset hashing, and validation.
2. Implement immutable chunk/bond data plus pooled family state and deterministic graph traversal.
3. Add structural damage commands fed by the existing combat/collision event pipeline.
4. Implement intact-to-component split transactions with inherited velocity and topology revisions.
5. Add manifold/query/subshape/constraint invalidation tests for replacement.
6. Add collision LODs, sibling filters, debris pools, sleeping, and retirement budgets.
7. Add authoritative split deltas, rollback checkpoints/deltas, late-join state, and persistence.
8. Add stress propagation only after direct damage/split behavior is stable; run it at an independent budgeted cadence.
9. Add native backend adapters: immutable replacement first, mutable compounds only where measured advantageous.
10. Gate feature expansion—runtime cutting, cross-cell structures, GPU debris—behind profiled prototypes and explicit network contracts.

## 10. Verification Strategy

### Asset tests

- stable chunk/bond IDs across deterministic recooks;
- closed valid collision hulls, positive volumes, finite centers/inertias;
- connected support graph and valid hierarchy;
- no orphaned gameplay anchors;
- collision LOD error and hull-count budgets;
- identical asset/content hashes on build workers.

### Functional fixtures

- single supported wall, arch, bridge, hanging sign, tower, door frame, and clustered rubble pile;
- point, radial, repeated low damage, support removal, gravity stress, centrifugal stress, and scripted break;
- jointed fixtures spanning a split;
- moving parent, rotating parent, sleeping parent, kinematic contact, and origin shift;
- split during query batch, rollback replay, streaming unload/reload, save/load, and late join.

### Invariants

- total mass and linear/angular momentum remain within tolerance absent explicit fracture impulse;
- every active chunk belongs to exactly one component;
- no active bond crosses disconnected components;
- body/component maps are bijective for authoritative components;
- no stale handle, manifold, constraint, or subshape revision survives commit;
- event order and IDs are identical on replay;
- all buffers expose overflow and apply the documented deterministic fallback.

### Performance tests

Record p50/p95/p99 and worst-case fixed-tick time for graph evaluation, component discovery, body replacement, broad phase, narrow phase, solver, queries, and serialization. Sweep chunk count, bond degree, simultaneous families, debris density, worker count, solver iterations, stress iterations, and substeps. Track allocations, working-set bytes, cache misses where supported, proxies, candidate/contact pairs, islands, awake bodies, time-to-sleep, query batch size, and rollback bytes/tick.

### Determinism and networking

Run the same capture twice, with alternate worker counts/order perturbations, and on the supported compiler/SIMD matrix. Compare command, broken-bond, topology, component, body-state, and continuation hashes separately. Test packet loss/reordering, prediction correction, checkpoint recovery, and event retraction. Preserve the first-divergence repro bundle.

## 11. Risks and Open Decisions

- Backend choice for destruction graph: project-owned, Blast, Chaos-only integration, or another library.
- Maximum chunks per asset, active components per event, and simultaneous authoritative debris per cell/world.
- Damage units and mapping from contact impulse/energy, explosions, weapons, and scripted values.
- Bond material model: scalar health only versus tension/compression/shear and stress propagation.
- Stress update rate, iteration cap, graph reduction, and cross-platform authority.
- Immutable aggregate replacement versus backend mutable compounds.
- Collision LOD generation, sibling-collision grace, CCD eligibility, and debris filter matrix.
- Momentum treatment, optional separation impulse, and whether mass loss is allowed for retired dust.
- Hybrid replication payload, checkpoint cadence, late-join encoding, and rollback byte budget.
- Persistence lifetime and whether settled debris is saved, reconstructed, or retired.
- Cross-cell support graphs and behavior during streaming/origin shifts.
- Runtime cutting, repair/reassembly, reversible damage, and editor authoring workflow.
- Competitive-gameplay policy: which fragments block movement, bullets, visibility, or navigation.

## 12. Engineering Recommendations

The following are recommendations, not claims from the cited sources:

1. Adopt offline prefractured chunk hierarchies plus stable support/bond graphs as the production baseline.
2. Keep structural topology state separate from backend physics bodies; synchronize through deterministic damage commands and atomic topology change sets.
3. Make the server authoritative over broken bonds and component membership. Replicate command identity plus canonical topology deltas, not raw debris transforms for every shard.
4. Commit splits only at a fixed structural phase. Copy contact data first; never mutate topology inside callbacks or jobs reading the scene.
5. Treat topology revision as part of every subshape hit, manifold-derived event, constraint anchor, and cached query result.
6. Preserve parent motion at split using rigid velocity at each child center of mass. Apply any cinematic separation as an explicit, replicated impulse.
7. Use immutable cooked convex collision and replacement aggregates first. Use mutable compounds only after measuring mutation/query tradeoffs and implementing locks/cache notifications.
8. Budget authoritative fragments separately from cosmetic debris. Degrade deterministically by stable importance order, never by thread completion order.
9. Keep damage/stress work allocation-free during the step with bounded command, result, component, and event buffers; surface every overflow.
10. Run stress propagation less frequently than rigid simulation, only for dirty/significant structures, with an iteration budget and authoritative results.
11. Store rollback as immutable topology plus periodic structural checkpoints and ordered deltas; exclude cosmetic shards.
12. Require conservation, topology, invalidation, deterministic replay, networking, streaming, and adversarial rubble benchmarks before enabling destruction in production content.

## 13. Source Links

- NVIDIA Blast SDK 5.0.6 documentation: https://nvidia-omniverse.github.io/PhysX/blast/index.html
- NVIDIA Blast fracture application API: https://nvidia-omniverse.github.io/PhysX/blast/_build/docs/blast-sdk/latest/function__nv_blast_8h_1a6a3d0ae6f5c5efb65699140897adb8c0.html
- NVIDIA Blast stress solver extension: https://nvidia-omniverse.github.io/PhysX/blast/docs/api/extensions/ext_stress.html
- Epic Games, Chaos Destruction in Unreal Engine 5.8: https://dev.epicgames.com/documentation/en-us/unreal-engine/chaos-destruction-in-unreal-engine
- Epic Games, Geometry Collections User Guide: https://dev.epicgames.com/documentation/unreal-engine/geometry-collections-user-guide
- Epic Games, Chaos Fields User Guide: https://dev.epicgames.com/documentation/en-us/unreal-engine/chaos-fields-user-guide-in-unreal-engine
- Epic Games, Dataflow for Destruction Quickstart: https://dev.epicgames.com/documentation/en-us/unreal-engine/dataflow-for-destruction-quickstart
- Jolt Physics, MutableCompoundShape reference: https://jrouwe.github.io/JoltPhysicsDocs/5.5.0/class_mutable_compound_shape.html
- Jolt Physics architecture and subshape identity notes: https://jrouwe.github.io/JoltPhysics/
