# Operation Mythology Physics & Collisions Research

**Timestamp:** 2026-07-27 02:07:17 America/Los_Angeles  
**New subject batch:** Combat collision: hitboxes, hurtboxes, melee traces, hitscan and physical projectiles, explosions, authoritative damage events, and multiplayer rewind

## 1. Feature Overview

This report defines a backend-neutral combat-collision layer above the general physics query and contact systems already covered in the legacy corpus. It covers:

- Distinct movement colliders, physics colliders, hurtboxes, hitboxes, interaction volumes, and cosmetic contact geometry.
- Melee detection from swept weapon volumes rather than frame-local overlap alone.
- Hitscan weapons, query-driven projectiles, simulated rigid-body projectiles, penetration, ricochet, and explosion exposure.
- Stable hit identity, duplicate suppression, body-region/material attribution, damage requests, authoritative resolution, and presentation events.
- Server-side rewind of historical target hurtboxes for latency-compensated attacks.
- First-person and third-person presentation compatibility without allowing either visual rig to become gameplay authority.

The collision system detects candidates and geometric facts. A separate gameplay damage system validates rules and applies health, armor, poise, status, impulse, and destruction effects.

## 2. Existing Coverage and Identified Gap

The recursive `GAME SKILLS` scan contained renderer and ECS/job-system research but no combat-collision report. The five indexed legacy physics reports already cover fixed-step/determinism, body/material semantics, collider cooking/filtering, broad/narrow phase and CCD, and the generic query service. They do not yet define:

- Ownership and update rules for hurtboxes attached to animated characters.
- Attack-window sampling and swept melee traces.
- Per-swing duplicate suppression and multi-target rules.
- A common contract for hitscan, query projectile, physical projectile, and explosion hits.
- The boundary between a physics hit and authoritative damage.
- Historical hurtbox snapshots, rewind queries, and anti-abuse limits.
- Combat-specific telemetry and regression fixtures.

This batch fills that gap without repeating the underlying query, collider, or solver designs.

## 3. Sourced Facts

### Sourced facts

1. Unreal Engine 5.8 traces can query by channel or object type, return one or multiple hits, and use line, box, capsule, or sphere shapes. Multi-trace-by-channel returns overlaps up to the first blocking hit. Trace results can include actor, component, bone, physical material, face, impact point, and normals.
2. Unreal's multi-sphere trace sweeps a sphere from start to end, returns initial overlaps and overlapping hits, stops after the closest blocking hit, and provides results sorted along the trace.
3. Unity 6 exposes caller-buffered non-allocating overlap and box-cast APIs. Their capacity is fixed by the caller-provided result array, and filters include layer masks and trigger policy.
4. Unreal separates collision discovery from damage application: point-damage input carries a hit result plus instigator and damage causer, while the receiving point-damage event is authority-only. `TakeDamage` returns the amount actually applied.
5. Unreal radial damage with falloff distinguishes inner and outer radii, supports a minimum value and falloff exponent, and can perform occlusion using a damage-prevention collision channel.
6. Valve Source lag compensation stores recent target state and temporarily rewinds targets when processing an attacker command. Its documented modes distinguish bounds-only rewind, full hitbox rewind, and hitbox rewind only along a weapon ray.
7. Valve's weapon documentation treats hitscan fire and visible projectiles differently: hitscan may be predicted and lag compensated, while rockets and grenades exist as independent entities and should not simply be spawned through the same lag-compensated path.
8. Godot's ray-casting documentation distinguishes explicit self-exclusion from collision-mask filtering and notes masks are more efficient for large or dynamic exclusion sets.

### Interpretation

These APIs converge on a reusable pattern: filtered physics observation produces structured hit facts; gameplay authority then decides whether those facts create damage. They also show that melee sweeps, hitscan, projectile contacts, and explosions need different acquisition policies even when they feed one damage-resolution pipeline.

## 4. Industry-Standard Physics API or Pattern

Use four acquisition paths feeding one normalized `HitCandidate` stream:

1. **Melee:** During authored attack windows, sample weapon/hit-volume transforms at fixed ticks. Sweep each primitive from its previous authoritative pose to its current pose. If animation or motion crosses too far in one tick, subdivide by a bounded distance/angle rule. Merge results by stable target hurtbox identity and per-attack policy.
2. **Hitscan:** Execute a closest or ordered multi-hit ray/shape query from an authoritative muzzle/aim state. For network play, query a bounded historical hurtbox snapshot rather than moving the live physics world backward.
3. **Query projectile:** Integrate a lightweight projectile state at the fixed tick and sweep its collision shape over the traveled segment. Resolve impact, penetration, ricochet, or termination from deterministic material and projectile data.
4. **Physical projectile:** Use a rigid body only when contacts, stacking, deflection, rolling, or constraint interaction are gameplay-relevant. Convert post-step contact facts into candidates; do not mutate gameplay state inside the physics callback.

Explosions use a two-stage pattern:

- Broad candidate collection with a bounded sphere overlap.
- One or more exposure/occlusion traces to selected target sample points, followed by deterministic distance and exposure falloff.

All acquisition paths normalize into immutable candidate records. A fixed-tick damage resolver validates team, invulnerability, attack lifetime, ownership, occlusion, duplicate policy, and target generation before producing committed damage and presentation events.

## 5. Performance and Determinism Considerations

- **Broad phase:** Melee sweeps, projectile sweeps, and explosion overlaps first traverse the scene-query broad phase. Expected traversal is sublinear in well-balanced spatial structures plus returned candidates; dense overlap remains output-sensitive and can approach quadratic behavior across many simultaneous attackers/targets.
- **Narrow phase:** Cost scales with candidate count, collider complexity, requested hit fields, number of melee sub-sweeps, projectile penetration passes, and explosion exposure rays. Use simple combat proxies and request triangle/face data only when required.
- **Solver iterations:** Query-only hitboxes and hurtboxes add no solver rows. Physical projectiles and impact impulses do. Damage should not be inferred from solver impulse alone because iteration count, substeps, mass ratios, and warm starting can change it.
- **Allocations:** Use fixed-capacity command, candidate, deduplication, exposure, and event buffers. Every overflow must be counted and resolved by an explicit priority rule; silent truncation is forbidden.
- **Spatial locality and cache behavior:** Store active hurtbox world shapes in SoA arrays grouped by collision profile and character. Batch attacks by snapshot, query type, and nearby cell. Use compact stable IDs instead of object pointers in result streams.
- **Sleeping:** Query hurtboxes must remain query-visible even when their movement body sleeps. Physical-projectile contacts can wake islands; cosmetic impacts should not.
- **Island parallelism:** Query-only combat runs outside solver islands and can be job-batched. Physical projectiles may connect islands and reduce parallelism, so reserve them for interactions that need simulation response.
- **Query batching:** Batch AI volleys, pellet groups, explosion exposure rays, and crowd melee sweeps. Preserve an authoritative deterministic reduction order after parallel collection.
- **Fixed-step cost:** Sample combat geometry and resolve authoritative hits on fixed ticks. Presentation interpolation must not change hit authority. Cap attacks, sub-sweeps, pellets, penetrations, exposure rays, and candidates per tick.
- **Substeps:** Physics substeps improve physical-projectile contact opportunities but should coalesce into one outer-tick hit identity. Melee sub-sweeps are query subdivisions, not global physics substeps.
- **Determinism:** Canonicalize candidates by attack ID, target entity ID, target generation, hurtbox ID, quantized fraction/distance, and sub-hit index. Use authored or quantized damage curves and deterministic tie rules. Never depend on backend callback order.
- **Rollback memory:** Store attack commands, projectile states, committed hit IDs, and compact historical hurtbox poses. Do not snapshot render skeletons or full triangle meshes. Memory is approximately `history_ticks × rewindable_entities × (root pose + active hurtbox local/world transforms + generations)`, so use LOD/bounds-first history and hard rewind limits.

## 6. Pros and Cons

### Separate combat proxies

**Pros:** stable gameplay silhouettes, inexpensive queries, explicit body-region data, independence from render topology and animation LOD.  
**Cons:** authoring and validation burden; visible mismatches require tooling.

### Swept melee

**Pros:** resists between-tick tunneling and supports fast weapon arcs.  
**Cons:** more queries, duplicate candidates, and ambiguity for large rotations; requires bounded subdivision.

### Query-driven projectiles

**Pros:** cheap, deterministic, easy to rewind/replay, and avoids solver noise.  
**Cons:** does not naturally bounce, roll, push, or join constraint islands.

### Physical projectiles

**Pros:** emergent contact response and environmental interaction.  
**Cons:** higher solver/island cost, greater backend sensitivity, and harder rollback.

### Historical hurtbox rewind

**Pros:** validates attacks against what the attacker plausibly saw.  
**Cons:** history memory, fairness paradoxes, anti-cheat surface, and special handling for doors, shields, moving cover, and projectiles.

## 7. ECS Architectural Integration

Authoring assets:

- `HurtboxRigAsset`: stable hurtbox IDs, parent semantic bone/socket, primitive, local pose, body region, material/armor surface, LOD tier.
- `AttackCollisionAsset`: attack phases, one or more swept shapes, source sockets, sampling/subdivision limits, channel/profile, duplicate and multi-target rules.
- `ProjectileProfile`: acquisition mode, shape, speed/gravity/drag, lifetime, penetration/ricochet limits, CCD tier, damage payload.
- `ExplosionProfile`: radii, falloff, candidate cap, sample-point policy, occlusion channel, impulse policy.
- `DamageProfile`: tags, base values, falloff, critical/body-region multipliers, friendly-fire and armor rules.

Runtime components:

- `CombatHurtboxSet`, `AttackInstance`, `ProjectileState`, `DamageReceiver`, `DamageInstigator`, and optional `RewindableCombatPose`.
- Presentation rigs publish semantic socket poses into a fixed-tick combat-pose buffer. First-person and third-person meshes may differ, but both resolve to the same authoritative attack asset and gameplay pose.
- Physics/query systems output immutable candidates. `CombatHitResolveSystem` owns deduplication and validation. `DamageResolveSystem` owns gameplay mutation. `CombatPresentationSystem` consumes confirmed/predicted presentation events.
- Creation, removal, profile swaps, death/ragdoll transition, and rewind-history eligibility are tick-boundary structural commands.

## 8. Body, Collider, Query, Constraint, and Event Interfaces

```text
BodyHandle       = { index, generation }
ColliderKey      = { colliderAssetId, subshapeId }
HurtboxKey       = { entityId, entityGeneration, hurtboxId }
AttackId         = { instigatorId, abilitySequence, activationTick }
ProjectileId     = { ownerId, spawnSequence, spawnTick }

CombatQueryCommand {
  tick, snapshotId, attackId, sourceEntity,
  kind: MeleeSweep | Hitscan | ProjectileSweep | ExplosionOverlap | ExposureRay,
  startPose, endPose, shape, filterProfile,
  resultMode, capacity, requestedFields
}

HitCandidate {
  tick, attackId, projectileId?, sourceEntity,
  targetEntity, targetGeneration, hurtboxId,
  colliderKey, fraction, point, normal,
  sourceVelocity, relativeVelocity,
  physicalMaterialId?, bodyRegionId?,
  initialOverlap, blocking, snapshotId
}

DamageRequest {
  tick, stableHitId, attackId, sourceEntity, instigatorEntity,
  targetEntity, targetGeneration,
  damageProfileId, bodyRegionId, physicalMaterialId,
  point, normal, direction, distance,
  exposure, penetrationIndex, tags
}

DamageAppliedEvent {
  tick, stableHitId, sourceEntity, targetEntity,
  requestedAmount, appliedAmount, absorbedAmount,
  resultTags, point, normal
}

CombatPresentationEvent {
  tick, stableHitId, confirmedState,
  impactClass, point, normal, targetEntity, surfaceId
}
```

Constraints remain physics-owned. A melee hit must not create a persistent physics constraint unless the gameplay action explicitly requests a grab, pin, tether, or joint command. Impact impulses are separate ordered commands so damage can be accepted, reduced, or rejected independently of physical response.

## 9. Integration Plan

1. Define stable combat IDs, profiles, candidate records, overflow rules, and fixed-tick phases.
2. Add authored primitive hurtbox rigs with visualization and validation against both FP and TP gameplay poses.
3. Implement hitscan and one-shape melee sweep on the existing typed query service.
4. Add per-attack deduplication, target-generation validation, body-region attribution, and normalized damage requests.
5. Implement query-driven projectiles, then opt-in physical projectiles.
6. Add explosion overlap, deterministic target reduction, exposure traces, falloff, and separate impulse commands.
7. Add compact historical hurtbox snapshots and a read-only rewind query scene; start with hitscan only.
8. Extend rewind to selected melee attacks only after fairness and memory tests. Do not rewind visible physical projectiles by default.
9. Add authoring/cook checks, telemetry dashboards, recorded fixtures, rollback replay, and network impairment tests.

## 10. Verification Strategy

- Unit-test stable hit IDs, candidate sorting, target generation, per-swing deduplication, falloff, armor/body-region rules, and overflow priority.
- Golden-test swept melee across low tick rates, fast arcs, large rotations, initial overlap, target teleport, and animation LOD changes.
- Verify a target is hit once per attack unless an authored multi-hit cadence permits repeats.
- Test hitscan blockers, overlaps-before-block, penetration order, backfaces, self-ignore, friendly-fire, and equal-fraction ties.
- Test projectiles against thin walls, moving targets, moving platforms, dynamic shields, ricochets, penetration limits, and substep coalescing.
- Test explosions with no cover, full cover, partial cover, multiple sample points, targets larger than the blast origin, candidate overflow, and destructible cover.
- Replay identical command streams with worker-count variation and compare candidate, damage, and state hashes.
- Roll back across attack start, target death/despawn, collider/profile swap, projectile spawn/impact, and explosion commit.
- Network-test latency, jitter, loss, malicious old timestamps, clock drift, interpolation changes, and maximum rewind clamping.
- Visualize current and rewound hurtboxes, melee sweep segments, query filters, candidate order, occlusion rays, rejected-hit reasons, and confirmed versus predicted impacts.
- Stress-test simultaneous crowd melee, shotgun pellets, projectile storms, and chained explosions while tracking query counts, node/leaf visits, narrow tests, buffer high-water marks, dedup time, exposure-ray count, and damage-resolution time.

## 11. Risks and Open Decisions

- Whether hurtboxes follow a minimal gameplay skeleton, full animation pose, or hybrid semantic sockets.
- Hurtbox count and LOD policy by player, boss, crowd, and dedicated-server tiers.
- Melee sweep primitive set, angular-subdivision rule, maximum sub-sweeps, and multi-hit cadence.
- Whether animation root motion, movement simulation, or an ability timeline owns attack pose authority.
- Hitscan penetration and ricochet policy, pellet reduction, and deterministic spread generation.
- Query-driven versus physical projectile classification by weapon.
- Explosion occlusion sampling count, cover semantics, destructible-cover ordering, and impulse falloff.
- Server rewind duration, bounds-only versus full-hurtbox history, interpolation accounting, and maximum accepted client age.
- Which world elements are historical: characters only, shields, vehicles, doors, moving cover, or destructibles.
- Whether rewind uses a separate query scene, immutable snapshots, or temporary transformed-shape collections.
- Predicted impact presentation and correction behavior.
- Whether ragdoll hurtboxes remain damage-authoritative or switch to a reduced proxy.
- Friendly-fire, self-damage, team transition, invulnerability, and late-event rules.

## 12. Engineering Recommendations

### Engineering recommendations

1. Keep physics observation and damage mutation separate. Physics produces immutable candidates; authoritative gameplay systems validate and commit damage.
2. Use authored primitive combat proxies with stable hurtbox IDs and body-region metadata. Never make render mesh triangles or the first-person viewmodel authoritative.
3. Sweep melee volumes between fixed-tick poses and use bounded angular/distance subdivision. Deduplicate by `AttackId + target generation + hurtbox/target policy`.
4. Normalize melee, hitscan, projectile, contact, and explosion results into one candidate schema, but retain distinct acquisition policies.
5. Default bullets and fast gameplay projectiles to ray/shape-swept query simulation. Use rigid bodies only when emergent physical interaction materially matters.
6. Resolve explosions as bounded overlap plus deterministic occlusion/exposure sampling. Separate damage from physics impulse.
7. Make damage server-authoritative. Predict only presentation and clearly reconcile rejected or corrected hits.
8. Implement historical hurtbox rewind as a separate read-only query dataset; never mutate the live simulation world for an attack test.
9. Begin rewind with players and hitscan, a short capped history, and strict timestamp validation. Expand to melee, vehicles, shields, or moving cover only after explicit fairness tests.
10. Preallocate combat query/result/event memory, expose overflow, and enforce budgets per attack, actor, cell, and tick.
11. Canonicalize authoritative result order and stable hit identity so rollback can re-execute without double damage or duplicate effects.
12. Ship combat-collision visualization and rejected-hit telemetry with the first implementation milestone.

## 13. Source Links

- Epic Games, *Traces in Unreal Engine — Overview* (UE 5.8): https://dev.epicgames.com/documentation/unreal-engine/traces-in-unreal-engine---overview
- Epic Games, *Multi Sphere Trace By Profile* (UE 5.8): https://dev.epicgames.com/documentation/en-us/unreal-engine/BlueprintAPI/Collision/MultiSphereTraceByProfile
- Epic Games, *Apply Point Damage* (UE 5.8): https://dev.epicgames.com/documentation/unreal-engine/BlueprintAPI/Game/Damage/ApplyPointDamage
- Epic Games, *Event PointDamage* (UE 5.8): https://dev.epicgames.com/documentation/en-us/unreal-engine/BlueprintAPI/AddEvent/Game/Damage/EventPointDamage
- Epic Games, *Apply Radial Damage with Falloff* (UE 5.8): https://dev.epicgames.com/documentation/en-us/unreal-engine/BlueprintAPI/Game/Damage/ApplyRadialDamagewithFalloff
- Epic Games, `APawn::TakeDamage` API (UE 5.8): https://dev.epicgames.com/documentation/en-us/unreal-engine/API/Runtime/Engine/APawn/TakeDamage
- Unity Technologies, `Physics.OverlapBoxNonAlloc` (Unity 6): https://docs.unity3d.com/6000.0/Documentation/ScriptReference/Physics.OverlapBoxNonAlloc.html
- Unity Technologies, `Physics.BoxCastNonAlloc` (Unity 6): https://docs.unity3d.com/6000.0/Documentation/ScriptReference/Physics.BoxCastNonAlloc.html
- Valve Developer Community, *Lag Compensation*: https://developer.valvesoftware.com/wiki/Lag_compensation
- Valve Developer Community, *Source Multiplayer Networking*: https://developer.valvesoftware.com/wiki/Source_Multiplayer_Networking
- Valve Developer Community, *Authoring a weapon entity*: https://developer.valvesoftware.com/wiki/Authoring_a_weapon_entity
- Godot Engine, *Ray-casting*: https://docs.godotengine.org/en/stable/tutorials/physics/ray-casting.html
