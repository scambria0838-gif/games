# Operation Mythology Physics & Collisions Research

**Timestamp:** 2026-07-27 02:23:01 America/Los_Angeles  
**New subject batch:** Ragdolls, joint constraints, motors, physical animation, breakage, sleep/LOD, recovery, and rollback boundaries

## 1. Feature Overview

This report defines a backend-neutral constrained-body system for:

- Passive death/stun ragdolls.
- Partial physical animation and hit reactions.
- Powered ragdolls driven toward an animation-derived target pose.
- General fixed, point, hinge, cone, slider, distance, swing-twist, and six-degree-of-freedom joints.
- Position/velocity motors, limits, friction, damping/compliance, projection/recovery, breakage, and telemetry.
- Ragdoll activation, animation-to-physics pose transfer, physical simulation, sleep/LOD, and physics-to-animation recovery.

Ragdoll physics is presentation-sensitive but can also affect gameplay through blocking, hit proxies, carried bodies, traps, and vehicles. The architecture therefore separates authoritative gameplay state from cosmetic or server-authoritative-only articulated simulation.

## 2. Existing Coverage and Identified Gap

The recursive `GAME SKILLS` scan and indexed reports cover general rigid bodies, mass/inertia, collision/filtering, manifolds/solvers, queries, combat hit detection, and character controllers. Animation research identifies ragdoll recovery/replication as open, but does not define physical bodies, joint frames, motors, transition state, or solver budgets.

Uncovered decisions include:

- Maximal-coordinate rigid-body chains versus reduced-coordinate articulations.
- Joint type/limit authoring and stable constraint frames.
- Active-ragdoll motor semantics and target-pose timing.
- Self-collision, adjacent-body filtering, and character-capsule interaction.
- Breakage thresholds, projection, recovery, and warm-start invalidation.
- Ragdoll LOD, sleeping, island cost, networking, rollback, and get-up handoff.

## 3. Sourced Facts

### Sourced facts

1. Jolt 5.5 exposes fixed, distance, point, hinge, cone, slider, swing-twist, and six-DOF constraints. It identifies swing-twist as suitable for shoulder-like motion.
2. Jolt constraints can be added/removed from multiple threads, but individual constraint mutation is not internally protected and must not occur during the physics step.
3. Jolt motors drive relative position/orientation by applying force or torque each step, with explicit force/torque limits and damping. Jolt describes damping ratio 1 as critical damping for its motor model.
4. Jolt documents breakable constraints by reading the total per-step constraint impulse (“lambda”) and disabling when an authored threshold is exceeded.
5. Jolt rebuilds islands from non-contact constraints every step in lock-free O(N) work over constraints; connecting an active and sleeping body wakes the sleeping body.
6. Jolt swing-twist constraints expose replay state and advise resetting warm-start impulses after a large ragdoll pose change; resetting every frame makes chains softer.
7. PhysX reduced-coordinate articulations represent a tree through root pose plus joint coordinates. Locked axes have no separation error by design, and articulations handle large link mass ratios better than ordinary jointed rigid bodies.
8. PhysX articulations require a tree topology; unsupported joints and loops must be resolved. Non-root link poses cannot be arbitrarily set because that can violate generalized coordinates.
9. Current PhysX articulation stability guidance recommends reducing timestep to diagnose instability, limiting/rate-limiting drive force and targets, and avoiding unreasonable mass/inertia ratios.
10. Unreal Engine 5.8 Physical Animation applies physics simulation on top of skeletal animation and supports body/constraint profiles.
11. Unreal documents that substepping can improve ragdoll and complex-asset stability at CPU/memory cost; forces/targets require substep bookkeeping and collision callbacks may be queued multiple times across substeps.
12. Godot's stable ragdoll workflow uses physical bones, collision shapes, and joints; it recommends removing tiny/utility physical bones, using hinge/cone joints for most limbs, supporting partial ragdoll influence, and configuring filters so the character capsule does not interfere.

### Interpretation

The common production pattern is an offline-authored rigid-body tree with explicit local joint frames, bounded limits, optional drives, self-collision filtering, and runtime profiles. Stability depends as much on mass/inertia, topology, target continuity, timestep, and collision filtering as on iteration count.

## 4. Industry-Standard Physics API or Pattern

### Authored asset

Create a versioned `RagdollAsset` containing:

- A reduced semantic body set, each mapped to a skeleton bone/socket.
- Primitive/convex collider, density or mass override, center of mass, inertia policy, material, collision group, and LOD tier.
- Parent-child joint, stable local frames on both bodies, joint type, locked/free/limited axes, angular/linear limits, friction, compliance, and break policy.
- Adjacent and authored non-adjacent self-collision exclusions.
- Named passive, stiff, limp, stunned, carried, recovery, and platform-specific profiles.

### Runtime state machine

1. `Animated`: gameplay controller owns root; ragdoll bodies are absent, query-only, or sleeping followers.
2. `BlendToPhysical`: sample one authoritative pose; create/activate bodies at matching transforms; seed linear/angular velocities from pose history and controller/platform velocity; clear invalid warm-start state.
3. `Physical` or `Powered`: simulate constraints. Powered mode writes rate-limited joint-space motor targets before the step.
4. `Settling`: reduce motor/contact work using velocity, constraint-error, and contact stability tests.
5. `RecoveryCandidate`: choose a deterministic get-up orientation/clip from pelvis/up/ground queries; verify clearance.
6. `BlendToAnimated`: drive toward the recovery entry pose or align the animation root to the physical pelvis; gradually transfer authority while collision remains valid.
7. `Animated`: destroy/disable bodies at a tick boundary and restore the character controller.

### Constraint policy

- Use hinge for strongly single-axis joints, cone or swing-twist for shoulders/hips, and six-DOF only where simpler joints cannot express the required motion.
- Express all targets and limits in stable constraint-local frames.
- Prefer impulse/force-limited drives with bounded target change. Never teleport individual links to follow animation.
- Use projection/depenetration only as a bounded emergency repair, not continuous enforcement.
- Evaluate breakage from constraint impulses filtered over time and separate “visual dislocation” from permanent gameplay break.

## 5. Performance and Determinism Considerations

- **Broad phase:** A ragdoll multiplies one character into many moving proxies. Broad-phase update cost grows with active links; candidate pairs can grow quadratically when self-collision or dense piles are enabled.
- **Narrow phase:** Cost scales with colliding link pairs, compound complexity, pile contacts, and speculative/CCD settings. Primitive limb colliders and explicit adjacent-body exclusions are essential.
- **Solver iterations:** Each joint contributes rows for locked/limited axes plus active motors; contacts add more. Long chains, loops, high mass ratios, stiff drives, and small links converge slowly. Apply per-island or per-constraint quality tiers before raising global iterations.
- **Allocations:** Ragdoll instantiation must use pools for bodies, constraints, collision exclusions, motor targets, contacts, and events. Avoid per-link ECS entity churn during activation where stable pooled handles suffice.
- **Spatial locality/cache behavior:** Store body states, constraint rows, motor targets, and profile parameters densely per ragdoll. Keep joint parent/child indices and solver order contiguous. Batch profile updates instead of scattered property writes.
- **Sleeping:** Sleep the complete stable island, not arbitrary individual links. Motors, animation targets, or gameplay queries must not continuously wake a visually settled ragdoll. Disable or lower drive updates before sleep.
- **Island parallelism:** Each connected ragdoll is one solver island; piles or grabs can merge many ragdolls and props into a large island. Parallelism exists across isolated ragdolls, while a giant pile requires solver-specific large-island parallelism.
- **Query batching:** Batch ground/clearance/get-up queries and ragdoll hit-proxy updates. Physics contacts still belong to the step and should be reduced into bounded post-step records.
- **Fixed-step cost:** Cost is roughly active bodies + broad/narrow candidates + (constraint/contact rows × iterations). Powered ragdolls add target preparation and more consistently active islands.
- **Substeps:** Local/global substeps improve stiff-drive and high-impact stability but multiply collision and solve work. Motor targets must be interpolated per substep and outer-tick events deduplicated.
- **Determinism:** Canonicalize structural commands, body/constraint creation order, profile changes, target pose sampling, break evaluation, and post-step events. Backend SIMD/compiler/platform differences still make exact cross-platform ragdoll determinism a separate tier.
- **Rollback memory:** Exact rollback requires all link transforms/velocities, sleep state, constraint/motor continuation and warm-start state, break flags, profile generation, and structural history. Full player-ragdoll rollback is expensive; prefer server-authoritative ragdolls or short local prediction with correction.

## 6. Pros and Cons

### Maximal-coordinate jointed rigid bodies

**Pros:** general topology, loops and breakable joints, ordinary body/contact integration, broad engine support.  
**Cons:** joint drift/error, mass-ratio sensitivity, more solver iterations, and harder stiff motor tuning.

### Reduced-coordinate articulations

**Pros:** zero locked-axis joint separation, strong tree stability, efficient generalized coordinates, and better large-mass-ratio behavior.  
**Cons:** tree-only topology, restricted direct link mutation, backend-specific APIs, and more difficult break/reparent workflows.

### Powered ragdolls

**Pros:** reactive physical animation, continuous collisions, procedural balance/hit response.  
**Cons:** high tuning/CPU cost, drive instability, animation/physics mismatch, and increased network state.

### Passive ragdolls

**Pros:** simpler, cheaper after sleeping, and robust for death/stun presentation.  
**Cons:** less controllable silhouettes and difficult deterministic recovery.

## 7. ECS Architectural Integration

Assets:

- `RagdollAsset`, `ConstraintProfile`, `MotorProfile`, `SelfCollisionProfile`, and `RecoveryProfile`.
- Cooking validates bone mappings, joint frames, limit ranges, mass/inertia ratios, collider overlap, scale, topology, and backend capability.

Components:

- `RagdollInstance`: asset/profile IDs, state, generation, root/pelvis mapping, body/constraint pool range, authority tier.
- `RagdollMotorTarget`: tick, joint ID, target orientation/position/velocity, strength, maximum impulse/torque.
- `RagdollTransition`: source/target state, start tick, duration, sampled pose/velocity source, recovery selection.
- `ConstraintBreakState`: accumulated/filtered impulse, threshold, broken tick, replication state.

Systems:

1. Sample animation/gameplay target pose into a fixed-tick semantic pose buffer.
2. Apply structural activation/profile/break commands at the safe barrier.
3. Prepare rate-limited joint-space motor targets in dense arrays.
4. Step physics.
5. Gather body poses, constraint impulses/errors, contacts, sleep, and break candidates.
6. Deterministically resolve breaks and gameplay events.
7. Publish a physics pose for animation/presentation and update recovery state.

FP arms and TP body may use separate visual rigs, but physical authority is one gameplay ragdoll. First-person presentation may hide or replace physical bodies without duplicating simulation.

## 8. Body, Collider, Query, Constraint, and Event Interfaces

```text
RagdollBodyDef {
  bodyId, semanticBoneId, parentBodyId?,
  colliderAssetId, localBodyFromBone,
  massPolicy, materialId, collisionGroup, lodTier
}

ConstraintDef {
  constraintId, parentBodyId, childBodyId,
  type, parentFrame, childFrame,
  linearAxes[3], angularAxes[3],
  limits, compliance, friction,
  motorProfileId?, breakProfileId?
}

ConstraintMotorCommand {
  tick, ragdollId, constraintId,
  mode: Off | Velocity | Position,
  targetPosition?, targetOrientation?,
  targetLinearVelocity?, targetAngularVelocity?,
  maxForce, maxTorque, frequency, dampingRatio,
  stableCommandId
}

RagdollTransitionCommand {
  tick, ragdollId,
  fromState, toState, profileId,
  seedPoseId?, seedVelocityId?,
  authorityTier, stableCommandId
}

ConstraintResult {
  tick, ragdollId, constraintId,
  linearError, angularError,
  linearImpulse, angularImpulse,
  limitState, motorSaturated, broken
}

RagdollEvent {
  tick, ragdollId,
  kind: Activated | ProfileChanged | Slept | Woke |
        ConstraintBroken | RecoveryReady | Recovered |
        Teleported | InvalidState,
  bodyId?, constraintId?, impulse?, stableEventId
}
```

Queries target ragdoll bodies using stable ragdoll/body/subshape IDs. Damage events remain separate from contact/constraint results. Constraint mutation is command-buffered and never performed inside solver callbacks.

## 9. Integration Plan

1. Define backend-neutral joint axes/frames, limit conventions, motor units, profile schema, and stable IDs.
2. Cook and validate a reduced humanoid ragdoll using primitives, adjacent self-collision exclusions, hinge and swing-twist joints.
3. Implement passive activation with pose/velocity seeding, contact filtering, post-step pose extraction, and whole-island sleep.
4. Add deterministic profile changes and partial-ragdoll body subsets.
5. Add force/torque-limited joint-space motors with target rate limits and saturation telemetry.
6. Implement bounded breakage and replicated structural events.
7. Add pelvis/root-aligned recovery selection, clearance tests, and physics-to-animation handoff.
8. Add LOD: full near-field, reduced bodies/contacts, passive-only, frozen pose, and despawn/corpse proxy.
9. Evaluate reduced-coordinate articulation versus ordinary constraints on representative humanoid, creature, rope-like, and mechanical assets.
10. Add networking, snapshot policy, replay hashes, debug visualization, stress scenes, and regression gates.

## 10. Verification Strategy

- Asset validation: missing/duplicate bones, invalid frames, inverted limits, overlapping connected colliders, mass/inertia extremes, unsupported loops, and nonuniform scale.
- Joint fixtures: each joint type at limits, free motion, motor targets, unilateral force limits, friction, projection, and break threshold.
- Ragdoll transitions: idle/run/jump/fall/platform motion to ragdoll with velocity continuity; repeated activation; teleport; scale/profile swap.
- Self-collision: adjacent exclusions, hands/head/torso authored pairs, character capsule disabled/enabled, pileups, carried body, and narrow spaces.
- Motors: step/ramp target changes, saturation, overshoot, target discontinuity, solver iteration tiers, timestep/substeps, and mass-ratio sweep.
- Breakage: impulse duration/filtering, substep deduplication, rollback, replication, save/load, and reconnection prohibition.
- Recovery: face-up/down/side, slope/stairs, low ceiling, moving platform, dynamic obstruction, pelvis penetration, and failed-clearance fallback.
- Determinism: creation order, worker count, sleep/wake, break ordering, profile changes, rollback around activation and recovery, and state hashes.
- Performance: hundreds of isolated ragdolls, dense corpse piles, powered crowds, jointed props, and one giant connected island; capture all stage costs and worker utilization.
- Telemetry/visualization: body shapes/COM/inertia, joint frames/axes/limits, errors, impulses, motor target/error/saturation, self-collision matrix, island ID, sleep state, LOD, and recovery root.

## 11. Risks and Open Decisions

- Maximal constraints, reduced-coordinate articulations, or per-asset hybrid.
- Canonical joint-frame/axis convention and authoring tool representation.
- Body count, collider detail, self-collision matrix, and LOD tiers by platform.
- Mass distribution, inertia clamping, and permitted parent/child ratios.
- Hard versus compliant limits and motor frequency/damping/max-force semantics.
- Global versus per-ragdoll solver iteration/substep tiers.
- Passive, partial, powered, or active-balance scope for launch.
- Animation target sampling and motor target interpolation timing.
- Break impulse definition, temporal filtering, gameplay consequences, and replication.
- Character capsule replacement, damage hurtbox ownership, and ragdoll collision authority.
- Recovery clip selection, root alignment, clearance, invulnerability, and interruption.
- Server-authoritative, replicated-pose, client-cosmetic, or rollback-predicted ragdolls.
- Snapshot coverage for warm start/constraint state and replay compatibility across backend upgrades.
- Corpse lifetime, sleep/freeze, streaming, save/load, and world-origin behavior.

## 12. Engineering Recommendations

### Engineering recommendations

1. Build ragdolls from a reduced semantic body set with primitive/convex colliders, stable joint-local frames, and validated mass/inertia.
2. Prefer hinge and swing-twist/cone constraints; use six-DOF only when simpler constraints cannot express the motion.
3. Start with ordinary constrained rigid bodies for portability, then benchmark reduced-coordinate articulations for tree-structured powered ragdolls and mechanisms.
4. Drive active ragdolls in joint space with rate-limited targets and explicit maximum force/torque. Record saturation instead of hiding it with extreme gains.
5. Treat animation-to-physics and physics-to-animation as explicit ticked state transitions with pose/velocity seeding, clearance tests, and root/pelvis alignment.
6. Disable adjacent self-collision by default and author only meaningful non-adjacent pairs. Keep the character capsule from fighting active ragdoll bodies.
7. Use per-ragdoll/island quality tiers before increasing global iterations or substeps.
8. Sleep/freeze whole stable ragdolls and stop motor target churn before sleep. Add corpse LOD from the first milestone.
9. Buffer structural mutation and break decisions outside the solver; canonicalize multiple break candidates and substep events.
10. Use bounded projection/depenetration only for exceptional error recovery and reset warm start only after discontinuous pose/topology changes.
11. Keep player combat authority separate from cosmetic ragdoll pose unless the design explicitly requires physical-body blocking/hits.
12. Default multiplayer ragdolls to server-authoritative or cosmetic tiers; require a measured reason before full rollback prediction.
13. Ship asset validation, joint/motor visualization, solver telemetry, pile stress tests, and replay fixtures with the system.

## 13. Source Links

- Jolt Physics 5.5, constraints, motors, breakage, and island construction: https://jrouwe.github.io/JoltPhysicsDocs/5.5.0/index.html
- Jolt Physics, `SwingTwistConstraint`: https://jrouwe.github.io/JoltPhysicsDocs/5.1.0/class_swing_twist_constraint.html
- NVIDIA PhysX, reduced-coordinate articulations: https://nvidia-omniverse.github.io/PhysX/physx/5.6.0/docs/Articulations.html
- NVIDIA PhysX/Omniverse, articulation stability guide: https://nvidia-omniverse.github.io/PhysX/ovphysx/latest/guides/articulation_stability.html
- Epic Games, *Physics Constraints in Unreal Engine* (UE 5.8): https://dev.epicgames.com/documentation/en-us/unreal-engine/physics-constraints-in-unreal-engine
- Epic Games, *Physics Components in Unreal Engine* (UE 5.8): https://dev.epicgames.com/documentation/en-us/unreal-engine/physics-components-in-unreal-engine
- Epic Games, *Creating a Physical Animation Profile* (UE 5.8): https://dev.epicgames.com/documentation/en-us/unreal-engine/creating-a-physical-animation-profile-in-unreal-engine
- Epic Games, *Physics Sub-Stepping* (UE 5.8): https://dev.epicgames.com/documentation/en-us/unreal-engine/physics-sub-stepping-in-unreal-engine
- Godot Engine, *Ragdoll system* (stable): https://docs.godotengine.org/en/stable/tutorials/physics/ragdoll_system.html
- Godot Engine, `PhysicalBone3D` (stable): https://docs.godotengine.org/en/stable/classes/class_physicalbone3d.html
