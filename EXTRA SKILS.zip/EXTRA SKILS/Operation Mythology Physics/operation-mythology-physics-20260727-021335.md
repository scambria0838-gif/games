# Operation Mythology Physics & Collisions Research

**Timestamp:** 2026-07-27 02:13:35 America/Los_Angeles  
**New subject batch:** Deterministic first-/third-person character-controller interaction with slopes, stairs, ledges, moving platforms, dynamic bodies, crouch/resize, and penetration recovery

## 1. Feature Overview

This report defines a backend-neutral swept character controller for responsive first-person and third-person play. The controller is a gameplay movement solver, not an ordinary dynamic rigid body. It consumes a fixed-tick movement command, queries the collision world, classifies contacts, and produces a guarded movement state.

Required behavior includes:

- Capsule-based sweep-and-slide with stable wall and corner handling.
- Walkable-slope classification, steep-slope rejection/sliding, ground snapping, and ledge policy.
- Explicit up-forward-down stair stepping.
- Moving-platform support using stable ground identity, contact point, and surface velocity.
- Controlled interaction with dynamic bodies through gameplay-governed impulses.
- Crouch/stand shape changes with clearance tests.
- Spawn, teleport, streaming, rollback, and numerical penetration recovery.
- Prediction, rollback, state snapshots, interpolation, telemetry, and deterministic regression tests.

The same authoritative controller state drives both first-person and third-person presentation. Camera, mesh offsets, view bob, and animation do not alter collision authority.

## 2. Existing Coverage and Identified Gap

The recursive `GAME SKILLS` scan contained no character-controller research. The indexed physics corpus covers fixed-step simulation, bodies/materials, collider/filter design, collision pipeline/CCD, generic queries, and combat collision. It does not yet define the controller-specific iterative movement algorithm, floor state, stair sequence, moving-base contract, ledge behavior, resize/clearance policy, or recovery rules.

This report fills that uncovered subject. It reuses the existing typed query service, stable body/subshape IDs, tick-addressed commands, deterministic sorting, and rollback tiers rather than redefining them.

## 3. Sourced Facts

### Sourced facts

1. Jolt 5.5 distinguishes a rigid-body `Character` from query-driven `CharacterVirtual`. The latter is updated explicitly, can be scheduled at a chosen point, and is not automatically saved by the physics world's state recorder.
2. Jolt documents `WalkStairs` as an up, forward, and down sequence. It also exposes ground body/subshape identity, ground position, normal, velocity, material, and user data.
3. Jolt notes that a virtual character is invisible to ordinary rigid-body simulation unless an optional inner rigid body is created. Its character-contact listener can observe contact-point velocity and customize resulting character velocity.
4. PhysX's character-controller documentation recommends a capsule as the default volume, uses a contact-offset skin for numerical robustness, and caches nearby geometry around a temporal AABB.
5. PhysX auto-step behavior is governed by step offset; it advises keeping that offset as small as possible. Capsule curvature can otherwise make maximum climb height difficult to predict, motivating constrained climbing behavior.
6. PhysX slope limits mark polygons non-walkable and can prevent climbing or force sliding. Its up direction may be arbitrary, but changing it can create overlap requiring recovery.
7. PhysX overlap recovery handles reasonable penetration against static geometry, including spawn/teleport and numerical-error cases, but its documented recovery module ignores dynamic objects.
8. PhysX warns that update order matters for a third-person character on a dynamic platform: platform first, controller second, camera third.
9. PhysX states that convincing character-to-dynamic-body pushing is gameplay-specific because a capsule is an artificial volume and raw contact forces can look wrong; it recommends application logic through hit reports.
10. Unity 6 describes its Character Controller as a non-rigidbody solution for first- or third-person control. It exposes slope limit, step offset, skin width, and minimum move distance; its documentation warns that too-small skin width causes sticking/jitter.
11. Unreal's Character Movement Component supports non-rigidbody walking/falling/swimming/flying and includes explicit floor, step-up, ledge, moving-base, imparted-base-velocity, slide, two-wall, and network-prediction behavior.
12. Unreal Mover's fixed-timeline model combines inputs into simulation-tick commands and guards state changes through modes/effects rather than arbitrary direct velocity mutation. Epic labels Mover experimental in UE 5.8.

### Interpretation

Production controllers converge on a capsule plus swept queries, contact tolerance, floor classification, explicit step logic, and application-owned movement state. Platform motion, dynamic-body pushing, penetration recovery, and networking are not incidental collision callbacks; they require deliberate policies and update phases.

## 4. Industry-Standard Physics API or Pattern

Use this fixed-tick sequence:

1. **Consume input:** Build one `CharacterMoveCommand` containing desired planar direction/speed, jump/crouch intent, mode requests, and tick.
2. **Apply platform delta:** Resolve the previous stable ground handle. Apply its authoritative translation/rotation delta at the saved local anchor, with collision checks. If invalid, detach deterministically.
3. **Refresh ground:** Perform a short downward shape cast/contact refresh. Classify support from the contact normal, up vector, separation, relative vertical velocity, surface policy, and stability rules.
4. **Build velocity:** Combine movement-mode acceleration, gravity, braking/friction, jump, external impulses, and inherited base velocity.
5. **Sweep and slide:** Cast the capsule along displacement; advance to a skin/contact offset; clip or project remaining displacement; repeat with a bounded iteration count. Use deterministic two-plane/corner handling.
6. **Attempt step:** When a lower obstruction blocks grounded forward motion, test upward clearance, forward travel, then downward landing. Accept only if the landing is walkable, the actual rise is within the authored limit, clearance remains valid, and progress exceeds the non-step result.
7. **Ground snap:** If grounded and not jumping upward, cast down by a bounded snap distance to follow descending stairs/slopes without artificial airborne frames. Never snap onto a steep/non-supporting surface.
8. **Resolve penetration:** Use bounded minimum-translation/depenetration iterations against static/kinematic geometry. For dynamic overlaps, prefer rollback to last valid state, safe teleport, or explicit gameplay displacement rather than unbounded solver impulses.
9. **Push dynamics:** Convert qualified controller hits into capped, mass-aware gameplay impulse commands after movement. Do not let arbitrary solver reaction control the player.
10. **Commit state:** Publish transform, velocity, mode, support state, stable ground identity/anchor, flags, and query diagnostics atomically at the tick boundary.

Ledge behavior is an explicit mode policy:

- `AllowFall`: accept unsupported motion.
- `PreventWalkOff`: clamp or redirect planar motion to remain supported.
- `RequireJump`: prevent voluntary traversal but allow impulses/forced motion.
- `AutoMantleCandidate`: emit a query result for a separate traversal system; do not silently mantle inside collision resolution.

## 5. Performance and Determinism Considerations

- **Broad phase:** Each movement tick performs multiple capsule casts/overlaps. Expected cost is query-tree traversal plus returned candidates; crowd pileups and dense clutter can make candidates output-heavy. Controller proxies should use a dedicated measured query profile.
- **Narrow phase:** Cost scales with sweep iterations, stair branches, floor probes, penetration contacts, compound/mesh complexity, and requested hit fields. Prefer simplified movement collision and bounded iteration counts.
- **Solver iterations:** A query-driven controller adds no ordinary contact-solver rows. Optional inner bodies, dynamic push impulses, and platform bodies do. Gameplay movement must not depend on global solver iteration count.
- **Allocations:** Preallocate per-worker cast collectors, contact arrays, step scratch, recovery scratch, movement results, and event rings. No steady-state heap allocation; expose overflow and iteration-cap flags.
- **Spatial locality/cache behavior:** Store controller state SoA by movement mode and update nearby controllers in spatial batches. Reuse coherent query caches only as hints; never make cache presence alter authoritative results.
- **Sleeping:** A character standing on a sleeping platform should not wake it merely to refresh support. A platform movement or accepted push impulse may wake the affected body. Query-driven controllers themselves do not sleep, but distant AI controllers may use explicit update-rate LOD outside player authority.
- **Island parallelism:** Virtual controllers can run as query jobs, but concurrent character-versus-character and push interactions require a deterministic gather/reduce/apply phase. Inner bodies and push impulses may connect or wake solver islands.
- **Query batching:** Batch floor probes and independent controller casts by spatial cell/profile. Iterative casts within one controller remain dependent and cannot all be issued upfront.
- **Fixed-step cost:** Controller cost is approximately controllers × (base sweep iterations + floor probes + conditional step/recovery work). Enforce per-mode caps and measure P95/P99 queries and narrow tests per controller tick.
- **Substeps:** Use controller-local movement subdivisions only when displacement/rotation exceeds configured thresholds. Do not increase global physics substeps to repair controller tuning. Coalesce contacts/events at the outer fixed tick.
- **Determinism:** Canonicalize equal-fraction hits by stable body, subshape, and feature keys; quantize thresholds consistently; store branch-relevant flags; forbid backend traversal order from selecting support or step results.
- **Rollback memory:** Snapshot transform, velocity, up vector, mode, stance, support handle/subshape/local anchor, external impulse accumulators, jump/ledge flags, and controller-local continuation data. Re-execute queries during resimulation. Memory scales linearly with predicted controllers × history ticks and is far smaller than storing query results or nearby geometry.

## 6. Pros and Cons

### Query-driven capsule controller

**Pros:** responsive, predictable, scheduleable, rollback-friendly, and independent of rigid-body instability.  
**Cons:** requires custom platform, pushing, character-character, and recovery behavior.

### Rigid-body controller

**Pros:** naturally participates in contacts, impulses, islands, and constraints.  
**Cons:** solver-sensitive, harder to make responsive, vulnerable to tipping/jitter/mass ratios, and more expensive to predict.

### Explicit stair stepping

**Pros:** bounded authored climb height and stable results across mesh tessellation.  
**Cons:** additional casts and edge cases around ceilings, moving stairs, and narrow landings.

### Ground snapping

**Pros:** smooth descent over stairs and uneven ground.  
**Cons:** excessive snap distance can glue characters to descending surfaces or suppress intended airborne motion.

### Gameplay-governed pushing

**Pros:** predictable player feel and tunable mass/strength limits.  
**Cons:** less physically pure and requires anti-exploit constraints.

## 7. ECS Architectural Integration

Authoring/data assets:

- `CharacterControllerProfile`: capsule dimensions by stance, skin/contact offset, max slope, step up/down, snap distance, sweep/recovery iteration caps, max depenetration, movement-mode parameters, ledge policy, push policy, and collision profiles.
- `SurfaceMovementPolicy`: walkable override, friction/braking class, conveyor velocity, one-way support, no-step/no-snap flags, damage/hazard tags.

Runtime components:

- `CharacterControllerState`: authoritative pose/velocity, up, movement mode, stance, stable support, and branch flags.
- `CharacterMoveInput`: tick-addressed player/AI command.
- `CharacterExternalMotion`: queued impulses, launches, teleports, root-motion/layered deltas, and scripted displacement.
- `CharacterGroundState`: body/subshape generation, local anchor, point, normal, velocity, material, walkability, and support age.
- `CharacterMoveResult`: committed delta, contacts, iteration counts, blocked/stepped/snapped/recovered flags, and failure reason.

Systems and order:

1. Apply tick-boundary world/body structural changes.
2. Advance kinematic platforms and publish transforms/velocities.
3. Build/update query acceleration structures.
4. Simulate character controllers in jobs, reading immutable physics state.
5. Deterministically reduce character-character conflicts and push commands.
6. Step/apply dynamic physics response according to the chosen backend schedule.
7. Commit controller state and movement events.
8. Interpolate separate FP camera/arms and TP mesh presentation.

The exact physics-versus-controller order is a backend decision, but it must be fixed, documented, and included in replay compatibility.

## 8. Body, Collider, Query, Constraint, and Event Interfaces

```text
CharacterMoveCommand {
  tick, characterId, inputSequence,
  desiredMove, desiredFacing,
  jumpPressed, crouchHeld,
  requestedMode?, clientFlags
}

CharacterControllerState {
  tick, characterId, pose, velocity, up,
  mode, stance,
  groundBody, groundSubshape, groundGeneration,
  groundLocalAnchor, groundNormal, groundVelocity,
  supported, walkable, jumpedThisTick,
  lastValidPose, stateHash
}

CharacterSweepRequest {
  snapshotId, pose, shapeId, displacement,
  filterProfile, skin, maxHits,
  initialOverlapPolicy, requestedFields
}

CharacterContact {
  body, bodyGeneration, subshape,
  fraction, point, normal, separation,
  surfaceVelocity, materialId,
  walkable, blocking, dynamic
}

CharacterMoveResult {
  finalPose, finalVelocity, finalMode,
  groundState, contacts,
  iterations, stepAttempts, recoveryIterations,
  flags, overflow
}

CharacterPushCommand {
  tick, characterId, targetBody, targetGeneration,
  point, impulse, policyId, stableCommandId
}

CharacterMovementEvent {
  tick, characterId,
  kind: Landed | LeftGround | Stepped | HitWall |
        HitCeiling | BeganSlide | PlatformChanged |
        Recovered | RecoveryFailed | StanceBlocked,
  body?, subshape?, point?, normal?, relativeSpeed?,
  stableEventId
}
```

Body handles and subshape IDs are generation-checked. A support relationship is not a physics constraint by default. Explicit grabs, ladders, ziplines, magnetic boots, or vehicle seats may create separate gameplay constraints or modes.

## 9. Integration Plan

1. Establish units, capsule/skin conventions, fixed-tick phase order, stable contact ordering, and movement-state schema.
2. Implement sweep-and-slide against static geometry with wall, corner, ceiling, and initial-overlap fixtures.
3. Add floor classification, slope limits, steep sliding, ground snap, ledge policy, and deterministic landing.
4. Add explicit up-forward-down step logic with clearance and progress validation.
5. Add kinematic moving platforms using ground body/subshape generations, local anchors, contact velocity, and detach/inherited-velocity rules.
6. Add capped gameplay pushing for selected dynamic bodies through deferred impulses.
7. Add crouch/stand resize with bottom-preserving pose adjustment and stand-clearance queries.
8. Add bounded recovery, last-valid-state fallback, safe teleport, and streaming/origin-change handling.
9. Add character-character policy and crowd batching.
10. Add client prediction, snapshots, rollback/resimulation, proxy interpolation, hashes, telemetry, and automated adversarial tests.

## 10. Verification Strategy

- Sweep fixtures: single wall, acute/obtuse corners, thin obstacles, ceiling, start overlap, zero motion, tiny motion, high speed, and changing up vector.
- Slopes: exact threshold ± epsilon, convex/concave seams, triangles with different tessellation, uphill speed policy, downhill snap, steep sliding, and slope-to-air transitions.
- Stairs: isolated curb, regular staircase, alternating heights, shallow ramps, low ceiling, moving stair, narrow tread, edge approach, and high fixed-tick frequency.
- Ledges: approach angles, prevent/allow policy, external impulse, jump, ground snap near edge, and landing on a lower platform.
- Platforms: translating, rotating, accelerating, reversing, sleeping/waking, teleporting, despawning, streamed migration, elevator ceiling crush, and jumping with/without inherited velocity.
- Dynamic bodies: mass thresholds, off-center contact, pileups, pinned objects, one-way push, rollback repeat, and anti-launch caps.
- Resize/recovery: crouch under ceiling, blocked stand, bottom preservation, spawn inside wall, teleport into static/dynamic geometry, platform penetration, and recovery failure.
- Networking: latency/jitter/loss, correction on steps/platforms, replay after platform destruction, stance changes, changing gravity, and malicious move timestamps.
- Determinism: worker counts, insertion orders, broad-phase rebuilds, equal-fraction contacts, replay hashes, and rollback across every branch.
- Performance: thousands of controllers in sparse/dense scenes; record casts, candidate pairs, narrow tests, iterations, cache hit rate, allocations, job imbalance, and P50/P95/P99 time.
- Visual debugging: capsule plus skin, desired/actual displacement, cast path, contact normals, walkable classification, step rays/shapes, snap range, ground anchor/velocity, recovery vectors, iteration cap, and network correction.

## 11. Risks and Open Decisions

- Query-driven, rigid-body, or hybrid controller by player/AI class.
- Capsule dimensions, contact offset, scale rules, and stance variants.
- Maximum slope, uphill speed preservation, steep-slide acceleration, and material overrides.
- Step height/down distance, progress threshold, angular subdivision, and stair rejection rules.
- Ledge allow/prevent/require-jump policies per movement mode.
- Platform update order, rotation transfer, inherited velocity, teleport/despawn behavior, and crush policy.
- Whether support may be dynamic, kinematic only, or tagged surfaces.
- Dynamic push strength, mass ratios, torque suppression, wake policy, and multiplayer authority.
- Character-character blocking, soft avoidance, ghosting, priority, and depenetration.
- Recovery iteration/vector caps and fallback destination selection.
- Arbitrary gravity/up direction and orientation interpolation.
- Controller-local subdivisions versus fixed tick rate.
- Backend query snapshot strategy and replay compatibility across cooking/backend upgrades.
- First-person camera collision and step smoothing versus authoritative capsule motion.
- Dedicated-server movement-pose needs for crouch, root motion, and traversal.

## 12. Engineering Recommendations

### Engineering recommendations

1. Use a query-driven capsule controller for authoritative player movement; reserve rigid-body characters for modes whose physical response is the feature.
2. Treat controller state as guarded fixed-tick simulation state modified only by commands, movement modes, and ordered external-motion records.
3. Implement movement as bounded sweep-and-slide plus deterministic contact sorting and explicit two-plane/corner rules.
4. Make stairs an up-forward-down query sequence with hard actual-rise, clearance, walkability, and progress checks.
5. Separate slope classification, steep sliding, ground snap, and ledge policy; avoid one overloaded normal threshold.
6. Track moving support with generation-checked body/subshape IDs and a local anchor. Apply platform motion before character motion and presentation after.
7. Define inherited platform velocity, rotating-base behavior, crush limits, and platform teleport/despawn as explicit policies.
8. Push dynamic bodies through deferred capped gameplay impulses; never let raw solver reaction determine player movement.
9. Preserve the capsule bottom during crouch/stand changes and require a clearance query before expansion.
10. Use bounded static/kinematic depenetration, last-valid-state rollback, and a deterministic safe fallback. Treat dynamic penetration separately.
11. Preallocate controller scratch/results, batch independent probes, expose every cap/overflow, and instrument per-branch costs.
12. Snapshot compact controller continuation state and re-execute queries during rollback; do not snapshot transient hit arrays.
13. Keep FP camera/arms and TP mesh smoothing presentation-only, driven from the same authoritative movement state.
14. Benchmark backend-native controllers but retain a project-owned interface and golden fixture suite so backend behavior changes are visible.

## 13. Source Links

- Jolt Physics 5.5, `CharacterVirtual`: https://jrouwe.github.io/JoltPhysicsDocs/5.5.0/class_character_virtual.html
- Jolt Physics 5.5, character-controller overview: https://jrouwe.github.io/JoltPhysicsDocs/5.5.0/index.html#character-controllers
- Jolt Physics 5.5, `CharacterContactListener`: https://jrouwe.github.io/JoltPhysicsDocs/5.5.0/class_character_contact_listener.html
- NVIDIA PhysX, *Character Controllers*: https://nvidia-omniverse.github.io/PhysX/physx/5.3.0/docs/CharacterControllers.html
- Epic Games, *Movement Components in Unreal Engine* (UE 5.8): https://dev.epicgames.com/documentation/en-us/unreal-engine/movement-components-in-unreal-engine
- Epic Games, `UCharacterMovementComponent` API (UE 5.8): https://dev.epicgames.com/documentation/en-us/unreal-engine/API/Runtime/Engine/UCharacterMovementComponent
- Epic Games, *Mover in Unreal Engine* (UE 5.8): https://dev.epicgames.com/documentation/en-us/unreal-engine/mover-in-unreal-engine
- Epic Games, *Comparing Mover and Character Movement Component* (UE 5.8): https://dev.epicgames.com/documentation/en-us/unreal-engine/comparing-mover-and-character-movement-component-in-unreal-engine
- Unity Technologies, *Character Controller component reference* (Unity 6): https://docs.unity3d.com/6000.0/Documentation/Manual/class-CharacterController.html
