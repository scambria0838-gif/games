# Operation Mythology Physics & Collisions Research

**Timestamp:** 2026-07-27 02:50:06 America/Los_Angeles  
**New subject batch:** Physics observability, visual debugging, failure capture, telemetry schemas, adversarial stress suites, determinism audits, and regression gates

## 1. Feature Overview

This report defines a physics-specific observability and verification layer that complements the existing engine-wide profiling/telemetry architecture. It covers:

- Live debug drawing of bodies, colliders, broad-phase bounds, contacts, manifolds, impulses, constraints, islands, queries, CCD, sleep, and authority state.
- Selective capture and offline playback of local, remote, client, and server physics state.
- Always-on bounded health counters, phase timing, high-water marks, and triggered deep diagnostics.
- Determinism double-step checks, state hashes, rollback/resimulation audits, and first-divergence reporting.
- Reproducible fixture scenes, randomized/fuzzed structural command streams, pathological stress scenarios, and performance-regression gates.

The goal is not a single developer overlay. It is one stable physics diagnostic schema feeding in-game overlays, trace captures, CI summaries, crash attachments, and external profilers.

## 2. Existing Coverage and Identified Gap

The recursive `GAME SKILLS` inventory now contains a general profiling, telemetry, and performance-regression baseline: stable schemas, ring buffers, triggered capture, statistics-aware CI, and service ownership. Physics reports contain many requested counters and tests, but no unified physics schema or capture/repro workflow.

The remaining gap is physics-specific:

- Which per-stage, per-world, per-island, per-shape-pair, per-query, and per-solver data must be recorded.
- How to capture enough causal input/state to reproduce a failure without recording the entire world every tick.
- How to align async/fixed physics, game frames, client/server timelines, rollback generations, and origin epochs.
- Which invariants and adversarial fixtures gate backend/compiler/cooking changes.
- How diagnostic cost, overflow, privacy, and file compatibility are controlled.

## 3. Sourced Facts

### Sourced facts

1. Unreal Engine 5.8 Chaos Visual Debugger can record runtime simulation state from local or remote targets, clients, servers, packaged builds, and multiple sources. Playback can inspect game-thread frames, physics-solver frames, and simulation stages.
2. Chaos Visual Debugger exposes selectable data channels because full capture volume can become large enough to affect performance and file size.
3. Jolt 5.5 debug rendering supports bodies and constraints through a user-provided renderer, including batched triangle geometry for efficient complex debug drawing.
4. Jolt's sample determinism check records state, executes a step, rewinds, repeats the step, and compares behavior. Its documentation also states that identical ordered state-changing API calls are required.
5. PhysX exposes per-step simulation statistics including broad-phase additions/removals and shape-pair counts by discrete, CCD, modified-contact, and trigger category.
6. PhysX profiling uses per-thread preallocated buffers and notes that buffer exhaustion may cause writes/delay or new allocation, which makes instrumentation capacity itself a performance concern.
7. OmniPVD records physics internals for frame-by-frame inspection of shapes, contacts, and solver state.
8. Box2D exposes debug drawing for shapes, bounds, mass, contacts, normals, contact/friction impulses, joints, graph colors, and islands. Box2D also documents opaque validity-checked IDs and deterministic ordering based on creation order.
9. PhysX event-callback documentation warns that callback-provided objects are only valid during the callback, reinforcing the need to copy compact records rather than retain backend pointers.

### Interpretation

Mature engines combine live visualization, bounded statistics, profiler spans, and opt-in state capture. Determinism validation needs replayable ordered inputs plus internal continuation state, while multithreaded callbacks must be converted immediately into stable application-owned records.

## 4. Industry-Standard Physics API or Pattern

Use four diagnostic tiers:

1. **Always-on health:** fixed-size counters/timers and high-water marks per physics world/tick with very low overhead.
2. **Causal trace:** phase spans, jobs, waits, command batches, query batches, rollback markers, and compact summaries in per-thread rings.
3. **Triggered detail:** last-N-tick circular capture of commands, hashes, selected bodies/islands, contacts, constraints, queries, and events; freeze on invariant failure, desync, overflow, hitch, NaN, or user trigger.
4. **Full laboratory capture:** explicitly enabled backend state/geometry/manifold/solver capture for short deterministic scenes.

Every record carries:

- schema version, build/backend/cooking/config hashes;
- world ID/generation, fixed tick, substep, simulation stage;
- game frame, monotonic timestamp, thread/job ID;
- rollback timeline/generation, snapshot ID, origin epoch;
- stable body/collider/subshape/constraint/query/attack/vehicle/rope IDs.

The deterministic repro bundle contains initial snapshot, ordered structural/property/input commands, fixed-step schedule, required cooked-asset/config hashes, random seeds, and expected per-tick hashes. Large geometry is referenced by content hash rather than duplicated unless needed for crash portability.

## 5. Performance and Determinism Considerations

- **Broad phase:** Record proxy count, moved/added/removed proxies, tree height/quality, refit/rebuild time, candidate pairs, duplicates, partition counts, and worst-cell/pair density. Avoid per-node traces outside triggered capture.
- **Narrow phase:** Record candidates by shape-pair type, precise tests, contacts generated/reduced/refreshed, manifold cache hits/misses, rejected filters, and worst offending asset pairs.
- **Solver iterations:** Record active contacts/rows/joints/motors, velocity/position iterations or substeps, warm-start usage, residual/error proxies, motor saturation, break candidates, and largest islands.
- **Allocations:** Count warm-tick heap allocations, pool capacities/high-water marks, overflows, fallback allocations, capture-ring drops, and diagnostic-buffer flushes.
- **Spatial locality/cache behavior:** Use dense numeric records and interned stable labels; never emit formatted strings in hot paths. Correlate phase cost with bodies, candidates, rows, islands, and cache-miss samples from platform profilers.
- **Sleeping:** Record sleep/wake counts and reasons, active/sleeping bodies/islands, prevented sleeps, wake storms, and time-to-sleep distributions.
- **Island parallelism:** Record island count/size/row distribution, largest-island time, split/merge causes, job occupancy, work stealing, critical path, and idle time.
- **Query batching:** Record commands/results by type/lane, node/leaf visits, precise tests, hit count, sort/filter time, capacity/overflow, batch size, queue latency, and stale/cancelled tickets.
- **Fixed-step cost:** Track requested/executed ticks, catch-up, dropped/deferred work, phase/substep time, and presentation interpolation separately. Do not combine render-frame and simulation-tick cost.
- **Substeps:** Attribute collision/solve/events to outer tick and substep. Deduplicate gameplay events while retaining raw diagnostic substep records when enabled.
- **Determinism:** Hash canonical authoritative state, structural topology, configuration, and continuation state separately so first divergence is categorized. Re-run a step from the same snapshot under worker-count and insertion-order variants.
- **Rollback memory:** Track snapshot bytes by category, history occupancy, compression/delta ratio, pinned asset bytes, restore/resim time, invalidated async work, and peak simultaneous timelines.

Instrumentation overhead is measured in disabled, health-only, trace, triggered, and full-capture modes. A capture that changes scheduling enough to hide the bug is treated as a separate diagnostic limitation.

## 6. Pros and Cons

### Always-on bounded telemetry

**Pros:** production visibility, trend/regression data, and automatic trigger inputs.  
**Cons:** permanent overhead and schema/governance burden.

### Full state capture

**Pros:** deep offline inspection and collaboration without reproducing live.  
**Cons:** high CPU, memory, I/O, privacy, and versioning cost; can perturb timing.

### Command-plus-snapshot reproduction

**Pros:** compact, executable, supports bisection and determinism checks.  
**Cons:** requires deterministic ordering, compatible assets/builds, and sufficient internal state.

### Golden numeric hashes

**Pros:** fast exact divergence detection.  
**Cons:** brittle across intentional backend/compiler changes and poor at explaining the cause alone.

## 7. ECS Architectural Integration

The physics diagnostics service owns rings, capture files, intern tables, debug primitives, and backend adapters. ECS stores only opt-in tags/settings:

- `PhysicsDebugSelection`: world/entity/body focus and visualization mask.
- `PhysicsDiagnosticTrigger`: requested capture mode, duration, reason, and filters.
- `PhysicsTestScenario`: stable scenario/config/seed identifiers for harness entities.

Physics systems emit compact numeric records through thread-local writers; a post-step collector merges by stable tick/stage/order. No profiler pointers, formatted strings, backend pointers, or per-entity histories live in archetype chunks.

Debug rendering consumes an immutable diagnostic snapshot, never live mutable physics objects. Client/server captures use a shared session ID and clock/tick correlation, but retain independent authoritative streams for comparison.

## 8. Body, Collider, Query, Constraint, and Event Interfaces

```text
PhysicsTickHealth {
  schema, buildHash, backendHash, configHash,
  worldId, worldGeneration, tick, substeps, originEpoch,
  bodyCounts[], proxyAdds, proxyRemoves, candidatePairs,
  narrowTests, manifolds, contactPoints, solverRows,
  islandCount, largestIslandBodies, largestIslandRows,
  queryCounts[], eventCounts[], sleepCount, wakeCount,
  poolHighWater[], overflowFlags,
  phaseTimeNs[], snapshotBytes, rollbackResimTicks
}

PhysicsTraceRecord {
  timestamp, tick, substep, stage,
  threadId, jobId, kind, stableObjectIds[],
  value0, value1, flags
}

PhysicsDebugDrawCommand {
  tick, category, color, lifetime,
  primitive: Line | Point | Aabb | Sphere | Capsule |
             Convex | Triangle | TextKey,
  geometryData, stableObjectId
}

PhysicsCaptureRequest {
  sessionId, worldFilter, objectFilter,
  channelMask, preTriggerTicks, postTriggerTicks,
  maxBytes, triggerReason, privacyClass
}

PhysicsReproManifest {
  schema, build/backend/config/cooking hashes,
  initialTick, endTick, fixedDelta,
  snapshotRef, commandStreamRef,
  assetHashes[], seeds[], expectedHashes[]
}

PhysicsInvariantEvent {
  tick, severity,
  kind: NaN | InvalidHandle | PenetrationExceeded |
        VelocityExceeded | ConstraintErrorExceeded |
        EnergySpike | Overflow | DeterminismDivergence |
        RollbackMismatch | BudgetViolation,
  stableObjectIds[], measured, limit, captureSessionId?
}
```

Backend callbacks copy only stable IDs and values into bounded thread-local records. All object lifetime validation occurs when records are resolved after the step.

## 9. Integration Plan

1. Freeze stable world/tick/stage/object ID conventions and physics diagnostic schema/versioning.
2. Implement health counters and phase spans for command ingestion, broad phase, narrow phase, islands, solver, CCD, queries, events, snapshots, and rollback.
3. Implement batched debug drawing for bodies/shapes/AABBs/contacts/normals/impulses/constraints/islands/queries with focus filters.
4. Add per-thread causal rings, overflow counters, external profiler markers, and triggered pre/post windows.
5. Add canonical state/topology/config/continuation hashes and first-divergence reports.
6. Add initial-snapshot plus ordered-command repro bundles with content hashes and a headless runner.
7. Build deterministic fixture libraries and randomized structural/parameter/query generators with shrinking/minimization.
8. Add performance scenario manifests, warm-up, environment validation, baselines, effect-size/uncertainty gates, and artifact retention.
9. Add remote/multi-source client-server capture correlation and privacy/redaction.
10. Integrate backend-native Jolt/PhysX/Chaos capture tools as optional deep channels, not the portable schema.

## 10. Verification Strategy

### Correctness fixtures

- Primitive/convex/mesh contact pairs, manifold persistence, friction/restitution, stacks, chains, joints, CCD, triggers, and query semantics.
- Character slopes/stairs/platforms, combat sweeps/projectiles/explosions, ragdolls, vehicles, cloth/ropes, streaming, origin shifts, and rollback.

### Adversarial generators

- Random valid create/destroy/enable/type/shape/material/constraint command sequences.
- Extreme but bounded mass/inertia ratios, sizes, velocities, overlaps, dense broad-phase cells, joint graphs, sleeping sensors, and query floods.
- Random worker counts, command insertion order before canonicalization, rollback points, snapshot intervals, and asset generation changes.

### Invariants

- Finite normalized transforms; generation-valid handles; nonnegative mass/density where required; bounded speeds/depenetration.
- No illegal dynamic concave shapes or invalid topology.
- Contact normals/points finite; manifold/contact/solver capacities honored.
- Constraint error, energy growth, penetration, and rollback divergence within scenario-specific limits.
- No warm-tick general allocations or silent overflow.

### Regression procedure

- Run fixed hardware/OS/power/thermal profiles with warm-up and environment-validity checks.
- Compare absolute budgets and matched baseline/candidate distributions; noisy runs are inconclusive and retried.
- Retain minimal repro bundle, health timeline, trace slice, capture, configuration, and backend/toolchain hashes for every failure.
- Promote backend/compiler/cooking upgrades only after correctness hashes are reviewed or intentionally rebaselined and performance gates pass.

## 11. Risks and Open Decisions

- Stable schema breadth versus hot-path overhead.
- Capture file format, compression, chunking, indexes, forward/backward compatibility, and retention.
- Canonical hash fields and quantized versus bitwise comparison.
- Exact per-backend continuation-state exposure and first-divergence granularity.
- Debug-name/string interning availability in test versus shipping builds.
- Trigger thresholds for hitch, penetration, energy, overflow, desync, and rollback mismatch.
- Privacy/security for player transforms, inputs, identifiers, and remote capture.
- Maximum pre/post window and crash-safe flushing.
- Test matrix by platform/backend/compiler/SIMD/worker count.
- Performance-lab hardware control, statistical gate thresholds, and rebaseline authority.
- Fuzz seed retention, minimization/shrinking strategy, and nondeterministic failure handling.
- GPU physics/cloth observability and synchronization overhead.
- Which backend-native captures are required for support versus optional tooling.

## 12. Engineering Recommendations

### Engineering recommendations

1. Reuse the engine-wide telemetry transport but define a versioned physics schema keyed by fixed tick, substep, stage, world generation, rollback timeline, and origin epoch.
2. Make bounded health counters always available; keep per-object traces and full backend state opt-in or trigger-driven.
3. Implement debug drawing from immutable post-step diagnostic snapshots with batched geometry and stable focus filters.
4. Capture compact ordered commands plus an initial snapshot and content/config hashes as the primary executable repro artifact.
5. Hash authoritative state, topology, configuration, and continuation state separately to localize first divergence.
6. Add double-step determinism checks and worker-count/order variants to CI fixture scenes.
7. Treat ring, pool, query, contact, event, snapshot, and capture overflows as visible failures—never silent truncation.
8. Maintain adversarial fixture families for every subsystem and a randomized generator that can emit and minimize valid structural streams.
9. Gate releases with both absolute physics budgets and matched performance-regression statistics; preserve failing artifacts automatically.
10. Correlate client/server recordings by shared session and tick metadata while retaining separate authoritative streams.
11. Measure instrumentation overhead and dropped-record behavior for every diagnostic tier.
12. Integrate native Chaos Visual Debugger, Jolt debug/state tools, and PhysX/OmniPVD/profiling as backend extensions behind the portable project schema.

## 13. Source Links

- Epic Games, *Chaos Visual Debugger* (UE 5.8): https://dev.epicgames.com/documentation/en-us/unreal-engine/chaos-visual-debugger-in-unreal-engine
- Epic Games, *Capturing Data with Chaos Visual Debugger* (UE 5.8): https://dev.epicgames.com/documentation/en-us/unreal-engine/capturing-data-with-chaos-visual-debugger
- Epic Games, *Playback in Chaos Visual Debugger* (UE 5.8): https://dev.epicgames.com/documentation/en-us/unreal-engine/playback-in-chaos-visual-debugger
- Jolt Physics 5.5, determinism and debug rendering: https://jrouwe.github.io/JoltPhysicsDocs/5.5.0/index.html
- NVIDIA PhysX, `PxSimulationStatistics`: https://nvidia-omniverse.github.io/PhysX/physx/5.1.0/_build/physx/latest/class_px_simulation_statistics.html
- NVIDIA PhysX 5.6, *Profiling PhysX*: https://nvidia-omniverse.github.io/PhysX/physx/5.6.0/docs/Profiling.html
- NVIDIA ovphysx, *OmniPVD Recording*: https://nvidia-omniverse.github.io/PhysX/ovphysx/latest/tutorials/omnipvd_recording.html
- Box2D 3.1, *Simulation*: https://box2d.org/documentation/md_simulation.html
- Box2D 3.1, debug drawing fields: https://box2d.org/documentation/structb2_debug_draw.html
