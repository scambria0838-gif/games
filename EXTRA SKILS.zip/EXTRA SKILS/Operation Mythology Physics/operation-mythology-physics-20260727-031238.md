# Operation Mythology Physics & Collisions Research

**Topic:** Contact policy, material combination, one-way surfaces, conveyors, impulse limits, and solver-safe contact modification  
**Timestamp:** 2026-07-27 03:12:38 America/Los_Angeles  
**Assumptions:** Modular generic ECS; data-oriented memory; fixed-step simulation; selectable CPU-oriented 3D backend; first- and third-person gameplay; no production-code implementation.

## 1. Feature Overview

This batch specifies the last-resort policy layer between narrow-phase contact generation and constraint solving. It covers:

- physical-material pair resolution for friction, restitution, rolling resistance, and restitution thresholds;
- per-contact target surface velocity for conveyors and rotating/moving surfaces;
- one-way and drop-through platforms;
- contact rejection, sensor conversion, normal/separation edits, inverse-mass/inertia scaling, and maximum impulse;
- stable behavior across persistent manifolds, CCD, substeps, multithreaded callbacks, rollback, and backend differences.

The central rule is restraint: collision layers/masks handle categorical rejection, authored materials handle static pair properties, body/controller logic handles movement, and contact modification is reserved for rules that genuinely depend on the current contact geometry or relative motion.

## 2. Existing Coverage and Identified Gap

This run recursively scanned `C:\Users\steve\Desktop\GAME SKILLS`, the legacy index and all five legacy physics reports, and the dedicated physics index and all eight newer reports.

Existing reports already define:

- collider cooking, subshape materials, filters, sensors, and a default material-combine contract;
- broad/narrow phase, persistent manifolds, solver/CCD boundaries, and collision callbacks;
- character support, moving-platform surface velocity, slope/stair policies, and penetration recovery;
- vehicle surface sampling, combat interactions, rollback events, and physics telemetry.

The legacy collider report explicitly left “one-way platforms, conveyors, and gameplay overrides” as a later bounded contact-modification policy. No report defined callback inputs, stable pair orientation, persistence state, CCD behavior, thread restrictions, or failure policy. This report closes that named open decision.

## 3. Sourced Facts

### Official documentation facts

1. PhysX’s contact-modification callback can change contact point position, normal, and separation. It can set per-contact target velocity, maximum impulse, and per-body inverse-mass/inertia scales. PhysX documents target velocity as a way to create conveyor-belt effects and recommends tangential targets for best results.

2. PhysX warns that contact-pair and actor/shape order are not guaranteed. Callback code must determine which shape occupies each slot because target-velocity convention depends on that ordering. The callback can be invoked concurrently and must be thread-safe and reentrant.

3. PhysX warns that limiting maximum impulse can cause extra penetration or bodies passing through each other. Local mass scaling changes reported contact impulses and may require hit/force thresholds to be retuned.

4. Jolt’s `ContactSettings` permits overriding combined friction/restitution, inverse mass/inertia scales, sensor status, and relative linear/angular surface velocity on added or persisted contacts. It states that relative linear surface velocity can implement a conveyor.

5. Jolt’s documented default material combination is geometric mean for friction and maximum for restitution. Its global minimum velocity for restitution disables bounce below a configured closing speed so bodies settle. Jolt notes that friction requires at least two velocity solver iterations because it uses the prior iteration’s normal impulse.

6. Box2D 3.1 surface materials include friction, restitution, rolling resistance, tangent speed, and a user material ID. Tangent speed is implemented in the SIMD contact solver and is intended for conveyor surfaces.

7. Box2D’s pre-solve callback runs after collision detection and before response and can disable a contact based on its geometry, including one-sided platforms. It must be thread-safe and must not read or modify the world. The documentation cautions that order-sensitive callbacks may be nondeterministic; current documentation also identifies limitations around high-speed/continuous contacts.

8. PhysX 5.6’s Direct GPU API documentation states that CPU contact modification is unavailable when the relevant GPU narrow-phase contact data is not copied to the CPU. This is an explicit portability constraint for any gameplay rule that depends on contact editing.

### Interpretation

These facts establish available mechanisms and hazards. They do not dictate Operation Mythology’s material table, one-way tests, controller drop-through behavior, impulse limits, or rollback policy. The recommendations below choose a portable deterministic subset.

## 4. Industry-Standard Physics API or Pattern

### Material pair table

Cook immutable `PhysicsMaterial` records with stable IDs:

- static/dynamic friction;
- restitution;
- rolling/torsional resistance when supported;
- combine policy or precedence;
- restitution speed threshold;
- surface tags;
- optional conveyor profile ID;
- sound/FX/damage tags kept outside solver-hot data.

At cook time, build a dense symmetric `MaterialPairPolicy[a,b]` table for common materials. It returns coefficients without ECS or asset lookup. Pair precedence is explicit: override, multiply/geometric mean, minimum, maximum, or average. Custom asymmetric behavior must specify orientation by stable surface role, not callback slot.

### Contact policy input

`ContactPolicyInput`

- stable body/collider/subshape IDs and generations;
- canonical pair key and backend slot-to-canonical mapping;
- material IDs and policy flags;
- contact normal, points, separations, relative point velocity;
- fixed tick, substep, manifold age, CCD/discrete classification;
- immutable per-body contact-policy snapshot;
- optional persistent pair-state handle.

The input contains copied POD data only. No ECS traversal, allocation, logging, scripting, scene query, or backend mutation other than the provided contact settings is allowed.

### Contact policy output

`ContactPolicyDecision`

- accept/disable;
- sensor-only where backend supports it;
- friction/restitution override;
- relative linear/angular surface velocity;
- maximum normal/tangent impulse;
- inverse mass/inertia scales;
- normal/separation override only for tightly reviewed native features;
- reason code and deterministic diagnostic flags.

Unsupported backend fields fail validation at asset/config load or use an explicitly selected fallback. Silent semantic degradation is prohibited for authoritative gameplay.

### One-way platform rule

A one-way surface stores a local blocking normal and thickness/slop. For canonical platform `P` and other body `B`, accept support only when all required predicates pass:

1. the contact normal aligns with the platform’s blocking normal above an authored cosine;
2. the body’s reference point or relevant shape support was on/above the permitted side in the pre-step state, with hysteresis;
3. relative velocity along the blocking normal is not departing faster than the pass-through threshold;
4. no active drop-through token matches this platform/category;
5. penetration is within a recovery band, or a deterministic “deep penetration” policy chooses blocking to prevent falling through;
6. the pair is not in a cached pass-through state that persists until clear.

Use pre-step pose/velocity, never presentation/interpolated transforms. Persist pair state across manifold recreation and CCD/discrete transitions using generation-checked canonical IDs. A character controller should still solve one-way movement in its sweeps; rigid-body contact policy is for dynamic bodies and controller/body consistency.

### Drop-through

`DropThroughToken { actor, platformOrCategory, startTick, minimumTicks, clearDistance, sequence }`

The token disables qualifying support contacts until both minimum duration and geometric clearance are satisfied. Time alone is insufficient because low frame rate or obstruction can leave the body embedded when collision re-enables. Tokens are authoritative/predicted commands and part of rollback state.

### Conveyors

Author a surface velocity in the surface’s local tangent frame. At contact time:

1. transform it using the pre-step surface transform;
2. add kinematic point velocity if the belt body also moves/rotates;
3. remove normal component unless intentional normal drive is explicitly enabled;
4. express the relative target in the backend’s pair convention using canonical-to-slot mapping;
5. clamp speed and resulting impulse.

Do not teleport riders or directly overwrite body velocity. The friction constraint drives relative tangent velocity and naturally respects contact load, mass, and available friction.

### Impulse and mass scaling

Maximum impulse is a safety/special-effect tool, not general “soft collision.” Use compliant contacts/joints or controller policy when available. If mass/inertia scales change perceived response, keep them stable for the manifold lifetime, record them in telemetry, and calculate gameplay damage from an explicitly defined post-scale or reconstructed physical impulse.

## 5. Performance and Determinism Considerations

### Broad phase

Contact modification occurs after pair generation and does not reduce broad-phase traversal. A disabled one-way contact may still be rediscovered every step. Use layers/masks for any categorical rule to avoid unnecessary broad/narrow work. One-way flags should be limited to actual platform shapes, not broad material categories.

### Narrow phase

Pre-solve rules add work per generated/persisted manifold/contact. Complexity is linear in modified pairs/points after narrow phase, but dense piles can make that large. Evaluate pair-invariant material and role data once per manifold, then geometry-dependent predicates per point only where needed. Avoid modifying normals because it can defeat manifold coherence and increase contact churn.

### Solver iterations

Friction/conveyor behavior depends on normal impulse and velocity iterations; too few iterations causes weak or uneven transport. High target velocity or inverse-mass scaling can increase solver error. Restitution should have a minimum closing-speed threshold to avoid micro-bounce. Impulse caps may reduce stability and allow penetration, so never compensate blindly by increasing all iterations.

### Allocations

Callbacks are allocation-free. Preallocate persistent pair-state tables, drop-through tokens, diagnostics rings, and per-worker counters. Pair state uses bounded generation-checked hash/slab storage with deterministic overflow: fall back to conservative blocking (or authored alternative), emit a counter, and never allocate.

### Spatial locality and cache behavior

Store material-pair policies in a dense compact table indexed by runtime material IDs. Copy contact-policy components into physics-owned SoA snapshots before simulation. Partition persistent states by canonical pair hash and worker shard; keep hot flags/coefficient data separate from verbose diagnostics. Batch post-step diagnostic reduction by reason code.

### Sleeping

Static conveyor target velocity should not wake every sleeping body indefinitely. Wake on meaningful target-speed change, new touch, or explicit policy; allow a supported body to sleep if target and relative velocity are within tolerance. Changing material/contact policy revision wakes affected bodies only when the change alters response.

### Island parallelism

Callbacks can run concurrently. Policies must be pure functions of immutable input plus pair-local state owned through deterministic sharding/atomics. They may not query or mutate another body/world. Contact edits do not add constraints, but conveyors can keep islands awake and one-way rejection can split islands. Track awake/island effects.

### Query batching

Normal contact policy requires no scene queries. Any rule needing a ray/overlap is architecturally misplaced: perform batched pre-step queries and copy the result into policy snapshots. Character sweep filtering must share the same material/one-way predicates but runs in the query service, not from contact callbacks.

### Fixed-step cost and substeps

Evaluate one-way and conveyor rules on every solver substep where the backend updates contacts. Drop-through duration is measured in fixed ticks, while clearance is geometric. Material revision and role orientation remain constant across substeps. Avoid applying a full-tick conveyor impulse repeatedly; target velocity belongs to the constraint, and the solver handles substep impulse.

### Determinism

Canonicalize pair orientation by stable IDs/roles because backend order is unspecified. Use fixed-point/quantized thresholds where cross-platform exactness matters, stable material-table lookup, fixed reason precedence, and pair-local persistent state. Do not let callback invocation order affect shared counters or decisions. Hash decision outputs separately from manifold inputs to locate divergence.

### Rollback memory

Snapshot only authoritative non-derived state: material/policy revisions, drop-through tokens, persistent one-way side/pass state where it affects future decisions, and config hashes. Recompute ordinary pair coefficients and conveyor transforms. Budget pair-state memory by maximum active special-contact pairs; purge only after deterministic separation/age rules.

## 6. Pros and Cons

### Material tables

**Pros:** fast, deterministic, backend-portable, authorable, testable.

**Cons:** pair count can grow; unusual context-dependent behavior needs a separate policy.

### Contact modification

**Pros:** uses actual manifold geometry; expresses conveyors, one-way surfaces, and local response overrides without new bodies.

**Cons:** deep in a multithreaded hot path; difficult to debug; backend/GPU feature differences; can destabilize CCD/manifolds/solver; order mistakes reverse semantics.

### Target surface velocity

**Pros:** physically interacts through friction/load; supports dynamic riders and rotating belts.

**Cons:** effectiveness depends on friction and solver iterations; can keep islands awake; insufficient for precisely scripted movement.

### Impulse limiting

**Pros:** prevents extreme transfer and supports special soft-impact effects.

**Cons:** may cause penetration/pass-through and changes damage interpretation.

### One-way callback

**Pros:** supports dynamic bodies using current contact geometry.

**Cons:** requires persistent side/drop state, CCD testing, and matching query/controller rules. Poor logic creates trapping or tunneling.

## 7. ECS Architectural Integration

### Components

- `PhysicsMaterialRef`: stable cooked material ID.
- `ContactPolicyFlags`: one-way role, conveyor role, special response class.
- `OneWaySurface`: local blocking normal, angular tolerance, slop, recovery policy.
- `ConveyorSurface`: local linear/angular surface velocity, speed/impulse limits.
- `ContactMassPolicy`: optional stable inverse-mass/inertia scale class.
- `DropThroughState`: compact active token handle.

Hot components are copied to a physics snapshot keyed by collider handle/generation. Runtime callbacks never access ECS storage.

### Systems and ordering

1. consume gameplay drop-through/policy commands;
2. publish material table and contact-policy snapshots;
3. broad and narrow phase;
4. run pure validation/modification callbacks;
5. solve contacts;
6. copy contact/hit data to bounded event buffers;
7. update pair persistence and retractable gameplay events post-step;
8. snapshot rollback state and telemetry.

Material or role mutation is a structural physics command applied at a safe boundary and increments a policy revision. Existing manifolds are awakened/refreshed or invalidated according to backend requirements.

### Shared predicate library

The character controller, scene-query filtering, and rigid-body contact adapter share a backend-neutral `SurfacePolicy` library for canonical roles, material lookup, blocking normal, and drop token matching. Each caller supplies its own geometry facts; no caller reuses backend pointers or assumes identical hit ordering.

## 8. Body, Collider, Query, Constraint, and Event Interfaces

### Body

`SetContactPolicySnapshot(body, revision, flags)` changes only at a structural boundary.

`BeginDropThrough(actor, request) -> token` creates an ordered rollback-aware command.

Dynamic, kinematic, and controller bodies have explicit roles. Static environment never receives local mass scaling. Body generation is checked in every pair state.

### Collider

`ResolveMaterialPair(materialA, materialB) -> MaterialPairPolicy`

`ResolveSurfaceRole(collider, subshape) -> SurfaceRole`

Triangle/subshape materials resolve through cooked compact IDs. One-way normal is transformed from the owning collider’s pre-step pose. Negative/nonfinite friction or restitution and invalid normals fail cook validation.

### Query

`FilterSurfaceHit(hit, moverState, queryPolicy) -> Accept/Reject`

Queries use the same blocking-side/drop-through semantics but do not mutate solver contact settings. Async hits carry physics snapshot, collider generation, policy revision, and subshape ID; stale hits are discarded.

### Constraint

Contact edits remain backend contact constraints, not general joint components. If a conveyor must guarantee exact motion, use a kinematic carrier or explicit joint/motor instead. Impulse/mass overrides must not be applied to joint rows implicitly.

### Events

- `SpecialContactAccepted`
- `SpecialContactRejected`
- `OneWayStateChanged`
- `DropThroughStarted/Ended`
- `ConveyorContact`
- `ContactImpulseClamped`
- `ContactPolicyFallback`

Only gameplay-relevant transitions are published. Every event includes canonical pair IDs/generations, tick/substep, rollback timeline, policy revision, reason, and stable event ID. Per-contact debug events remain sampled telemetry.

## 9. Integration Plan

1. Freeze canonical pair orientation, material-pair precedence, combine functions, restitution threshold, and SI units.
2. Generate a dense cooked material-pair table and validation report.
3. Implement physics-owned policy snapshots and a pure backend-neutral decision layer.
4. Add conveyors using tangential target velocity with speed/impulse clamps.
5. Add one-way rigid contacts with pre-step side state, hysteresis, deep-penetration fallback, and pair persistence.
6. Add rollback-aware drop-through tokens and share the predicates with character sweeps.
7. Add optional max impulse and inverse-mass/inertia scaling only behind explicit profiles and telemetry.
8. Implement backend capability validation and authoritative fallbacks, including GPU-scene restrictions.
9. Add debug draw/capture of canonical role, normal, target velocity, decision reason, and pair state.
10. Ship only after CCD, substep, pile, controller, rollback, and worker-order fixtures pass.

## 10. Verification Strategy

### Material tests

- exhaustive symmetric pair table and precedence;
- zero/high friction, restitution threshold, rolling resistance;
- per-subshape material identity and hot-reload revision;
- finite/nonnegative coefficient validation;
- identical cooked table hash across build workers.

### One-way fixtures

- approach from blocking/pass side at rest, shallow, fast, and grazing angles;
- rotating/moving platforms and reversed backend pair order;
- jump through, land, walk off, drop through, cancel, and re-enable after clearance;
- deep initial overlap, teleport, spawn, origin shift, scale prohibition;
- compound subshape, manifold recreation, sleep/wake, CCD, 1/2/4 substeps;
- dynamic crates, ragdolls, vehicles, projectiles, and FP/TP character parity.

### Conveyor fixtures

- static, kinematic, rotating, reversing, accelerating, and intersecting belts;
- low/high friction, light/heavy bodies, stacks, spheres with rolling resistance;
- speed/impulse clamps, sleep/wake, edge transitions, and moving-platform combination;
- canonical pair-slot reversal produces identical world motion.

### Performance

Measure broad-phase pairs, narrow candidates, special manifolds/points, callback time, solver iterations, awake bodies, island count/size, contact cache churn, allocations/pool overflow, cache misses, query batches, fixed-tick/substep time, and rollback pair-state bytes. Stress dense rubble on conveyors, hundreds of one-way platforms, stacked riders, and mixed ordinary/special contacts.

### Determinism and rollback

Replay with randomized worker completion and pair/shape slot reversal. Compare input-manifold, policy-decision, pair-state, solver-output, event, and continuation hashes. Roll back across drop-through start/end, conveyor reversal, policy revision, CCD impact, and sleep. Verify no stale pair state survives handle reuse.

## 11. Risks and Open Decisions

- Exact friction/restitution combine policies and material precedence.
- Static versus dynamic friction support, rolling/torsional resistance, and anisotropic friction scope.
- Restitution threshold by world or material pair.
- One-way normal/slop/angle/velocity/deep-penetration rules and rigid-body versus controller parity.
- Drop-through targeting, duration, clearance, multiplayer prediction, and stacked platforms.
- Conveyor linear/angular semantics, normal drive prohibition, speed/impulse limits, and sleep behavior.
- Maximum impulse and inverse mass/inertia scaling use cases and damage-event interpretation.
- Persistent pair-state capacity, deterministic overflow, purge, and rollback budget.
- CCD/backend behavior and GPU scenes where contact modification is unavailable.
- Whether authoritative gameplay may depend on any backend-specific normal/separation edit.

## 12. Engineering Recommendations

The following are engineering recommendations, not sourced facts:

1. Keep ordinary category rejection in layers/masks and ordinary response in a cooked material-pair table; contact modification is exceptional.
2. Canonicalize every pair by stable identity/role before applying asymmetric rules; never trust callback slot ordering.
3. Implement conveyors through clamped tangential target surface velocity, including the moving body’s point velocity.
4. Implement one-way contacts from pre-step side, normal alignment, relative velocity, hysteresis, persistent pass state, and explicit deep-penetration policy.
5. Make drop-through a rollback-aware token that ends only after minimum time and geometric clearance.
6. Share backend-neutral surface predicates with controller sweeps and queries while keeping their execution separate.
7. Keep callbacks pure, reentrant, allocation-free, and limited to copied physics snapshots plus bounded pair-local state.
8. Avoid normal/separation editing in the portable baseline. Restrict impulse/mass scaling to reviewed profiles with telemetry and retuned damage thresholds.
9. Declare contact-modification capabilities per backend/platform and reject content that lacks an authoritative equivalent.
10. Gate release on pair-order reversal, CCD, substep, worker-order, pile, rollback, and stale-handle regression tests.

## 13. Source Links

- NVIDIA PhysX 5.3, Advanced Collision Detection / Contact Modification: https://nvidia-omniverse.github.io/PhysX/physx/5.3.0/docs/AdvancedCollisionDetection.html
- NVIDIA PhysX 5.6, Direct GPU API limitations: https://nvidia-omniverse.github.io/PhysX/physx/5.6.0/docs/DirectGPUAPI.html
- Jolt Physics 5.2, `ContactSettings`: https://jrouwe.github.io/JoltPhysicsDocs/5.2.0/class_contact_settings.html
- Jolt Physics architecture, friction/restitution combination: https://jrouwe.github.io/JoltPhysics/
- Jolt Physics `PhysicsSettings`, solver iterations and restitution threshold: https://jrouwe.github.io/JoltPhysics/struct_physics_settings.html
- Box2D 3.1, Simulation / custom filtering and pre-solve: https://box2d.org/documentation/md_simulation.html
- Box2D 3.1, surface materials and tangent speed: https://box2d.org/documentation/group__shape.html
- Box2D 3.1 release notes: https://box2d.org/documentation/md_release__notes__v310.html
