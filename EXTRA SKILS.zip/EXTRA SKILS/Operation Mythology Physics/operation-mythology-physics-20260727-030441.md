# Operation Mythology Physics & Collisions Research

**Topic:** Force semantics, custom gravity, buoyancy, fluid drag, currents, and water-transition physics  
**Timestamp:** 2026-07-27 03:04:41 America/Los_Angeles  
**Assumptions:** Modular generic ECS; data-oriented memory; fixed-step simulation; selectable physics backend; meter-kilogram-second units; gameplay water is sampled through a physics-facing service independent of rendering; first- and third-person compatibility; no production-code implementation.

## 1. Feature Overview

This batch defines a coherent force-field and fluid-interaction layer for rigid bodies and query-driven characters. It covers:

- unambiguous force, acceleration, impulse, velocity-change, torque, and point-force semantics;
- world gravity, per-body gravity scale, bounded local gravity fields, and priority/blending;
- water/body overlap, surface height/normal/velocity sampling, submerged volume, center of buoyancy, drag, lift, currents, and angular damping;
- water entry/exit events, splashes, character swimming transitions, projectile behavior, moving platforms/boats, and authoritative gameplay;
- deterministic fixed-step application, asynchronous sampling rules, rollback state, sleeping, batching, and verification.

The recommended production baseline is tiered. Small props use a few authored spherical pontoons; important convex boats and large props use clipped-volume or triangle-based sampling; characters retain their query-driven controller and consume a simplified water state rather than becoming rigid bodies. Full computational fluid dynamics is explicitly outside scope.

## 2. Existing Coverage and Identified Gap

The run began with a recursive read inventory of `GAME SKILLS`, the legacy shared research index and all five legacy physics reports, and the dedicated physics folder/index and all seven existing reports. Existing coverage includes rigid-body properties, fixed stepping, collision cooking/filtering, collision detection and solving, queries, combat, controllers, joints/ragdolls, vehicles, cloth/ropes, observability, and destruction.

The remaining gap was the semantics and architecture of distributed forces and fluids:

- Earlier reports mentioned gravity, drag, projectile gravity, and water only incidentally.
- No report distinguished force from acceleration, impulse, or direct velocity change at the public API boundary.
- No rule existed for local gravity, overlapping fields, nonuniform gravity, or when a body wakes.
- No physics-facing water sample contract existed for surface position, normal, flow velocity, density, or body priority.
- No buoyancy approximation tiers, submersion events, current forces, rollback representation, or aquatic character/vehicle boundary had been specified.

This report fills that gap without revisiting renderer water, shaders, or general animation.

## 3. Sourced Facts

### Official documentation facts

1. PhysX rigid-body documentation distinguishes force modes and supports adding force/torque to dynamic bodies. Its gravity documentation states that uniform scene gravity is built in; custom gravity can instead be implemented by disabling scene/body gravity and applying application-defined forces each frame.

2. Jolt exposes `GetSubmergedVolume` and `ApplyBuoyancyImpulse`. The latter accepts total and submerged volume, a center of buoyancy relative to body center of mass, buoyancy factor, linear and angular drag, fluid velocity, gravity, and timestep. Jolt documents that the body-level variant does not wake a sleeping body automatically, while the body-interface variant can be used when waking is desired.

3. Jolt’s convenience buoyancy factor uses `1` as neutral, less than `1` as sinking, and greater than `1` as floating instead of directly exposing fluid density. This is an engine convenience, not a universal physical convention.

4. Unreal Engine 5.8’s Water Buoyancy Component uses spheres (“pontoons”) as a low-cost volumetric approximation and documents that multiple pontoons can stabilize a body. Its parameters include buoyancy coefficient, damping, maximum buoyant force, water velocity strength, linear/quadratic drag, angular drag, and river forces.

5. Unreal’s newer buoyancy API also exposes convex/box shapes, submerged-volume computation, and per-triangle fluid-force calculation using water density, fluid velocity, triangle area/normal, body linear/angular velocity, and center of mass. Its water interaction records are bounded and physics-thread-facing, illustrating that water data must be copied into solver-safe structures rather than read from scene objects during simulation.

6. Unity’s official `Rigidbody.AddForce` documentation distinguishes continuous force, acceleration, impulse, and velocity change. It states that applied continuous force is integrated during the fixed physics update and that adding nonzero force wakes an active non-kinematic body.

### Physics fact

Archimedean buoyancy for a displaced volume is:

`F_b = -rho_fluid * V_submerged * g`

applied through the center of the displaced volume. The offset from body center of mass produces a restoring or overturning torque. Hydrodynamic drag is commonly approximated as a linear term at low relative speed plus a quadratic term:

`F_d = -k1 * v_rel - 0.5 * rho * Cd * A * |v_rel| * v_rel`

These equations do not prescribe a game’s sampling method, clamping, density units, or stability policy.

### Interpretation

The sources converge on three useful production patterns: explicit force modes, solver-safe water samples, and approximation tiers ranging from pontoons to submerged geometry. The exact public API, authority model, query cadence, determinism tolerance, and gameplay tuning below are engineering recommendations.

## 4. Industry-Standard Physics API or Pattern

### Force command semantics

Use one command shape with an explicit mode:

`ForceCommand { body, mode, vector, optionalPoint, space, sourceId, tick, sequence }`

- `Force`: Newtons, integrated as `dv = F * dt / m`.
- `Acceleration`: m/s², integrated as `dv = a * dt`, independent of mass.
- `Impulse`: N·s, applied once as `dv = J / m`.
- `VelocityChange`: m/s, applied once independent of mass.
- `Torque`: N·m, integrated through inverse inertia.
- `AngularImpulse`: angular momentum impulse through inverse inertia.

The API must not infer mode from call timing. Continuous forces are resubmitted each fixed tick; impulses are one-shot commands. Point forces/impulses generate both linear and angular effects through the lever arm.

### Gravity model

`GravitySample { acceleration, fieldId, priority, revision }`

Resolution order:

1. world/default gravity;
2. highest-priority exclusive field, if any;
3. additive fields explicitly marked blendable;
4. per-body gravity scale and optional axis constraints;
5. bounded gameplay modifiers.

Local gravity fields are immutable snapshots during a physics tick. They may be uniform boxes/spheres, radial/point fields with softened minimum radius, or spline/directional volumes. Arbitrary script callbacks per body are excluded from the hot loop.

### Water sample

`WaterSample { bodyId, waterBodyId, revision, surfacePoint, surfaceNormal, fluidVelocity, density, viscosityClass, depth, valid }`

Water providers publish a physics snapshot before the step. Render waves may be visually richer, but physics samples must come from deterministic/authoritative wave parameters or a coarser gameplay surface. Sampling returns no backend or scene-object pointer.

### Buoyancy tiers

**Tier 0 — volume state only:** triggers and characters; no rigid buoyancy.

**Tier 1 — pontoons:** 1–8 authored spheres per prop/boat. For each, estimate submerged fraction from signed surface distance, apply buoyancy at the pontoon center, then drag using point velocity relative to water.

**Tier 2 — convex clipped volume:** calculate submerged volume and centroid for one or a few cooked convex shapes against a locally planar surface.

**Tier 3 — triangle/patch forces:** important vessels only; calculate distributed hydrostatic and drag/lift forces on bounded hull patches.

Choose the lowest tier that satisfies gameplay. The tier is part of replicated configuration.

### Fluid interaction pipeline

1. Broad-phase water volumes produce candidate body/water pairs.
2. Resolve multiple water bodies by priority, containment, and stable ID; blend only if deliberately authored.
3. Batch surface/flow samples against the physics water snapshot.
4. Compute submersion and center of buoyancy using the body’s assigned tier.
5. Accumulate buoyancy, point drag, angular drag, current, and optional lift in deterministic probe order.
6. Clamp per-body force/torque and velocity change to authored safety limits.
7. Submit one accumulated wrench per body before velocity integration.
8. Derive enter, exit, fully submerged, and threshold-crossing events from persistent state with hysteresis.

## 5. Performance and Determinism Considerations

### Broad phase

Water volumes use the normal broad phase. Candidate generation is approximately logarithmic per moved proxy in tree-based implementations, but enormous ocean volumes can overlap every dynamic body. Represent open water as streamed spatial regions or a specialized water registry so the global ocean does not create a redundant collision pair per object. Track candidate water pairs separately from solid collision pairs.

### Narrow phase

Tier-1 pontoon tests are constant work per probe. Convex clipping scales with hull complexity and surface planes; triangle/patch models scale with selected hull patches. Never run render-mesh triangles through the physics narrow phase. Cache cooked probe layouts and shape volume; recompute only transformed probe positions and submersion.

### Solver iterations

Buoyancy is normally an external force/impulse, not a contact constraint, so it adds little direct constraint count. However, floating bodies colliding with docks, floors, other debris, or characters can create difficult stacked/contact islands. Excessive buoyancy stiffness and force clamping can inject energy that requires more velocity/position iterations. Prefer smooth submerged-fraction curves and critical-ish damping before increasing global solver iterations.

### Allocations

Preallocate water candidate arrays, sample requests/results, per-body accumulators, event state, and debug records. Pontoons and hull patches are immutable cooked arrays. No allocations, object lookup, virtual dispatch to gameplay scripts, or renderer access occur inside per-body fluid jobs. Overflow uses stable importance order and reports skipped bodies.

### Spatial locality and cache behavior

Sort candidates by water region then body dense index. Structure-of-arrays storage for sample points, radii, coefficients, transforms, and accumulated wrenches enables SIMD and cache-friendly batches. Keep wave/spline samples for a spatial tile hot while processing nearby bodies. Avoid fetching full ECS archetypes from physics jobs; consume compact copied input.

### Sleeping

A water volume should not wake every sleeping floating prop every tick. Wake on meaningful changes in surface height/normal/flow, on contact/force, or when predicted buoyant support no longer balances weight. Sleeping bodies may use a low-rate sample or conservative water-region revision. Entry into water wakes; stable neutral buoyancy can sleep if gameplay permits.

### Island parallelism

Buoyancy calculations are embarrassingly parallel by body after water snapshots are frozen. Use per-job accumulators and merge only events in stable body order. Application of accumulated wrenches must respect the backend’s safe pre-step phase. Water jobs should not serialize otherwise independent rigid-body islands.

### Query batching

Batch water surface/flow requests per region. Boats with several probes share wave evaluation data; projectiles and characters can use lower-cost samples. If terrain/bottom clearance or shore push requires scene queries, perform one bounded overlap and a small query batch rather than one ray per pontoon. Results carry snapshot and water revisions.

### Fixed-step cost and substeps

Evaluate continuous forces for each actual physics substep using that substep’s `dt`, or compute a force once and integrate consistently across substeps. Never apply a tick-sized impulse once per substep. Water samples may be held constant across substeps if waves/currents change slowly; body-relative velocity must still be recomputed. Event state commits once per fixed tick to prevent enter/exit chatter.

### Determinism

Stable field/water priority, sorted candidates, fixed probe order, deterministic accumulation, quantized network inputs, fixed clamps, and named snapshots are required. Parallel floating-point reduction order must not vary. Complex wave evaluation may differ across platforms; the server should authoritatively replicate important boat/body state or compact water parameters and correction state rather than assume bitwise equivalence.

### Rollback memory

Do not snapshot derived per-probe forces. Snapshot authoritative rigid-body states, water/field revisions, submerged-state/hysteresis bits, resolved water body ID, and ordered external force/impulse commands. Immutable pontoon layouts and water assets are referenced by hash. Moving wave phase/current state belongs to the world snapshot. Approximate rollback bytes as:

`bodies * (body state + water state) + commands + changed field/water state`

and exclude cosmetic bobbing/splash particles.

## 6. Pros and Cons

### Pontoons

**Pros:** low fixed cost; easy authoring/debugging; stable for many props; simple current and splash points.

**Cons:** only approximates volume; poor for large/irregular hulls; probe layout can create artificial torque or gaps.

### Convex submerged volume

**Pros:** better displacement and center-of-buoyancy behavior; fewer tuning artifacts; naturally responds to roll/pitch.

**Cons:** clipping/math cost; locally planar surface assumption; compound shapes need careful aggregation.

### Triangle/patch forces

**Pros:** best directional drag/lift and high-speed vessel behavior; distributed torque.

**Cons:** largest cost; sensitive coefficients; noisy forces require filtering; difficult deterministic parity.

### Custom gravity fields

**Pros:** supports planets, rotating habitats, magical zones, lifts, and water-specific effective gravity.

**Cons:** ambiguous overlap rules and abrupt direction changes can destabilize contacts/controllers; point gravity can require orientation and camera policies outside physics.

### Direct velocity control

**Pros:** predictable for authored gameplay and corrections.

**Cons:** bypasses mass and can inject energy; obscures physical cause; should not replace continuous buoyancy/drag.

## 7. ECS Architectural Integration

### Components

- `ExternalForceReceiver`: allowed modes, wake policy, clamps, authority.
- `GravityResponse`: scale, field mask, current resolved field/revision.
- `BuoyancyBody`: probe-set handle, tier, coefficients, water mask, force limits.
- `FluidInteractionState`: resolved water ID, fraction/depth bands, hysteresis, entry tick.
- `WaterMotionSource`: compact physics-facing surface/flow provider handle.
- `ForceAccumulator`: transient per-tick linear/angular wrench in a physics-owned SoA.

### Systems

1. publish immutable gravity/water snapshots;
2. gather and sort one-shot/continuous force commands;
3. discover field and water candidates;
4. batch sample gravity, surface, and flow;
5. calculate per-body buoyancy/drag/current;
6. deterministically reduce all force sources;
7. apply accumulated wrenches before integration;
8. simulate/substep;
9. commit threshold events and rollback state;
10. export transform/debug/telemetry snapshots.

The water renderer may consume the same authored wave asset, but physics never depends on rendered height, GPU readback, or material state.

### Characters and cameras

The existing query-driven controller remains authoritative. It samples water at feet, center, and head or uses a capsule submersion approximation. It transitions through wading/swimming/submerged states with hysteresis and consumes current as requested displacement/velocity under controller policy. First-person and third-person presentations subscribe to the same state; camera submersion is presentation-only and cannot define gameplay water state.

## 8. Body, Collider, Query, Constraint, and Event Interfaces

### Body

`SubmitForce(command)` validates generation, mode, finite values, authority, and tick.

`ApplyFluidWrench(body, force, torque, wakePolicy, sourceRevision)` submits the accumulated result once per substep.

Kinematic/static bodies reject physical force application but may still receive water events. Mass/inertia changes invalidate cached buoyancy calibration.

### Collider

`BuoyancyShapeSet` references cooked spheres, convexes, or patches independently of collision response shapes while sharing the body transform. Shape volumes must be positive and in SI units. Compound child removal or destruction updates buoyancy shape membership and center-of-buoyancy data at a structural boundary.

### Query

`BatchSampleFluid(snapshot, positions, masks) -> WaterSample[]`

`QuerySubmersion(snapshot, body, tier) -> SubmersionResult`

Samples include snapshot/water revision and stable ID. Asynchronous results are valid only for the named snapshot and are discarded if the body generation or water revision changes.

### Constraint

Buoyancy is not modeled as a joint. Moorings, ropes, vehicle suspension, and character platform anchors remain normal constraints/controllers and consume the same water-relative velocities. Strong current plus a taut rope must be tested as one solver island. Force clamps must not silently prevent constraint break thresholds from being reached.

### Events

- `EnteredFluid`
- `ExitedFluid`
- `SubmersionBandChanged`
- `FluidImpact`
- `ResolvedGravityFieldChanged`
- `FluidSampleUnavailable`
- `FluidForceClamped`

Events include body/entity generation, water/field stable ID and revision, tick/rollback timeline, crossing direction, quantized point/normal/relative speed, and source sequence. Hysteresis and minimum dwell suppress surface chatter. Presentation events are retractable under rollback.

## 9. Integration Plan

1. Freeze force-mode units, tick/substep application rules, wake behavior, authority, and clamps.
2. Implement a deterministic external-force command buffer and per-body wrench accumulator.
3. Add world gravity plus simple exclusive/additive field primitives and overlap priority tests.
4. Define solver-safe water snapshots with flat/static surfaces first.
5. Add Tier-1 pontoons, water entry/exit hysteresis, current, linear/quadratic drag, and debug draw.
6. Integrate query-driven character wading/swimming and moving-boat platform velocity.
7. Add convex submerged-volume support for important props/boats; retain pontoons as scalability fallback.
8. Add authoritative networking/rollback capture and wave/current revisioning.
9. Prototype triangle/patch forces only for vessels that fail Tier 2 acceptance tests.
10. Add streaming, origin-rebase, destruction/compound-change, and water-unavailable fallbacks.

## 10. Verification Strategy

### Analytical fixtures

- force/acceleration/impulse/velocity-change applied to bodies with 1×, 10×, and asymmetric inertia;
- point impulse with known linear/angular momentum;
- neutral, sinking, and floating cubes with known displaced volume;
- center-of-buoyancy offset producing expected torque direction;
- linear and quadratic drag monotonicity against still and moving fluid;
- gravity-field overlap, priority, blending, and boundary hysteresis.

### Gameplay fixtures

- small prop, log, barrel, raft, multi-pontoon boat, damaged compound, ragdoll, projectile, vehicle, rope-moored body, and character;
- calm lake, river current, waves, waterfall/vertical flow, shore, multiple overlapping water bodies, streaming edge, and origin rebase;
- FP/TP switching, predicted swim entry, rollback correction, boat platform detach, explosion at surface, and destruction while floating.

### Performance

Sweep dynamic bodies, probes/body, water regions, hull vertices/patches, wave samples, worker counts, substeps, and awake ratios. Record:

- water broad-phase candidates and resolved pairs;
- sample count/cache hit rate and query batch occupancy;
- Tier 1/2/3 narrow calculations;
- force-job, broad/narrow, solver, and fixed-tick time;
- allocations/pool high-water/overflow;
- cache misses and bytes touched where supported;
- islands, solver iterations, wakes/sleeps, clamp counts;
- rollback bytes/tick and replay time.

### Determinism and regression

Replay with different worker counts and randomized job completion while retaining fixed reduction order. Compare force-command, water-sample, accumulator, rigid-state, event, and continuation hashes separately. Test fixed tick plus 1/2/4 substeps, rollback, late join, packet loss, and cross-platform wave evaluation. Preserve first-divergence captures.

Acceptance requires no warm-tick allocation, no hidden overflow, no repeated surface event chatter, stable sleeping, bounded energy under calm water, and explicit degradation when samples/budgets are unavailable.

## 11. Risks and Open Decisions

- Public force modes, unit validation, default wake policy, and maximum force/torque/velocity change.
- Whether local gravity is exclusive, additive, blended, or priority-selected and how fields affect controllers/cameras.
- Water authority and fidelity: flat planes, analytic waves, splines, shallow-water grids, or server samples.
- Pontoon count/layout authoring and automatic generation.
- Tier-2 clipping backend, compound aggregation, and Tier-3 vessel eligibility.
- Density-based physical parameters versus normalized gameplay coefficients.
- Drag/lift models, cavitation/speed clamps, planing, and high-speed water impact.
- Entry/exit hysteresis, splash thresholds, event payload, and rollback retraction.
- Sleeping water-body update cadence and wake thresholds.
- Character swimming/current control, boat-platform behavior, and dynamic-body pushing in water.
- Replication of wave phase/current, correction policy, rollback byte budget, and late join.
- Interaction with destruction, ropes/moorings, ragdolls, projectiles, streaming, and origin shifts.

## 12. Engineering Recommendations

The following are engineering recommendations rather than sourced facts:

1. Expose explicit force modes and SI units in one command API; reject ambiguous “push” calls.
2. Accumulate all force sources in deterministic body/source order and apply one wrench before each substep.
3. Use uniform world gravity plus bounded priority/additive field primitives; exclude arbitrary per-body callbacks from the hot loop.
4. Decouple physics water from rendering through versioned solver-safe surface/flow snapshots.
5. Ship pontoons as the scalable default, convex submerged volume for important bodies, and triangle forces only where measured necessary.
6. Use water-relative point velocity for drag and apply buoyancy through the center of displaced volume so torque emerges physically.
7. Give characters a controller-owned water state and current response; do not switch the avatar to an uncontrolled rigid body.
8. Batch samples by water region, preallocate every buffer, keep probe data immutable/contiguous, and make overflow/clamping visible.
9. Avoid waking stable floating bodies every tick; wake from meaningful water revision, support error, contact, or authored force.
10. Replicate authoritative state for important boats/interactions and snapshot water revisions plus threshold state, not derived probe forces.
11. Require analytical force tests, calm-water energy tests, adversarial shore/wave/streaming cases, and worker/substep determinism tests before production.

## 13. Source Links

- NVIDIA PhysX 5.4, Rigid Body Dynamics (force modes and custom gravity): https://nvidia-omniverse.github.io/PhysX/physx/5.4.0/docs/RigidBodyDynamics.html
- Jolt Physics 5.3, `Body` buoyancy and submerged-volume API: https://jrouwe.github.io/JoltPhysicsDocs/5.3.0/class_body.html
- Jolt Physics 5.5, `BodyInterface::ApplyBuoyancyImpulse`: https://jrouwe.github.io/JoltPhysicsDocs/5.5.0/class_body_interface.html
- Epic Games Unreal Engine 5.8, Water Buoyancy Component: https://dev.epicgames.com/documentation/unreal-engine/water-buoyancy-component-in-unreal-engine
- Epic Games Unreal Engine 5.8, Buoyancy runtime API: https://dev.epicgames.com/documentation/en-us/unreal-engine/API/Plugins/Buoyancy
- Epic Games Unreal Engine 5.8, Water runtime API: https://dev.epicgames.com/documentation/unreal-engine/API/Plugins/Water
- Unity, `Rigidbody.AddForce` and force-mode semantics: https://docs.unity.cn/2020.1/Documentation/ScriptReference/Rigidbody.AddForce.html
