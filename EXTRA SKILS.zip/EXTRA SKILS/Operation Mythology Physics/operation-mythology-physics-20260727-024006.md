# Operation Mythology Physics & Collisions Research

**Timestamp:** 2026-07-27 02:40:06 America/Los_Angeles  
**New subject batch:** Cloth, ropes, cables, soft secondary motion, XPBD constraints, collisions, attachments, tearing, LOD, and authority boundaries

## 1. Feature Overview

This report defines a data-oriented secondary-simulation service for:

- Character cloth, capes, straps, hair cards/chains, hanging props, flags, nets, and soft accessories.
- Gameplay ropes, cables, chains, tethers, winches, bridges, and grappling lines.
- Distance/stretch, bend, shear, area/volume, attachment, backstop, contact, friction, and optional tearing constraints.
- CPU-authoritative rope subsets and CPU/GPU cosmetic cloth tiers.
- Collision proxy extraction, self-collision, one-way/two-way rigid coupling, sleep/freeze, LOD, rollback, and deformation output.

The recommended solver family is Extended Position-Based Dynamics (XPBD) for compliant particle constraints. Rigid segments remain appropriate when visible links, torque, stacking, or two-way contact are gameplay-critical.

## 2. Existing Coverage and Identified Gap

The recursive scan found cloth only as a downstream animation/deformation consumer and motion-vector requirement. Indexed physics reports cover general rigid bodies, collision, queries, characters, ragdolls, constraints, and vehicles. They do not define cloth/rope topology, particle constraints, self-collision, attachment/backstop behavior, tearing, GPU/CPU tiers, or gameplay-authority boundaries.

This batch fills that gap and preserves the existing rule that renderer deformation consumes simulation output but does not own physics authority.

## 3. Sourced Facts

### Sourced facts

1. The 2017 Position-Based Dynamics survey characterizes position-based methods as fast, stable, controllable, and suited to interactive environments, while generally emphasizing visual plausibility over force accuracy.
2. Macklin, Müller, and Chentanez introduced XPBD to reduce timestep- and iteration-dependent constraint stiffness by adding compliance and a persistent total Lagrange multiplier; the formulation also provides constraint-force estimates.
3. Unreal Engine 5.8 Chaos Cloth Dataflow exposes authored stretch, solver, velocity-scale, stitches, kinematic particles, weight maps, proxy deformation, collision, and self-collision configurations.
4. Unreal's self-collision configuration includes thickness, stiffness, friction, disabled neighbor-ring distance, layers, and disabled-face sets, demonstrating that self-collision must exclude topologically nearby elements and support authored pruning.
5. Unity cloth supports per-vertex constraints, selected self/intercollision particles, and only a limited collider set for performance. Unity documentation states cloth collision is one-way and warns self/intercollision can consume significant simulation time.
6. Jolt documents skinned constraints that limit simulated particles relative to animated/skinned positions using maximum-distance and backstop controls, enabling partial character-driven cloth.
7. Jolt's current soft-body documentation labels the feature work in progress and states soft bodies collide with rigid bodies but not other soft bodies; generic rigid-body impulses/constraints do not directly apply because velocity is stored per particle.
8. PhysX 5.7 GPU simulation supports PBD particle systems and FEM deformable actors on CUDA-capable Windows/Linux configurations, making GPU deformables a capability path rather than a universal portable baseline.

### Interpretation

Production secondary motion uses a lower-resolution simulation representation, per-particle/vertex authoring masks, simple collision proxies, and explicit solver/LOD profiles. Self-collision and two-way interaction dominate cost and must be opt-in. Gameplay ropes require a stricter authority tier than cosmetic cloth.

## 4. Industry-Standard Physics API or Pattern

### XPBD step

For each fixed simulation step or local substep:

1. Gather anchor transforms, collider proxies, wind/acceleration fields, and tick-addressed gameplay commands.
2. Predict particle positions from prior position/velocity and external acceleration.
3. Build/update broad-phase bins for particle-proxy, edge/segment-proxy, and enabled self-collision pairs.
4. Solve colored/batched constraints for several iterations:
   - attachments/pins and kinematic targets;
   - stretch/distance and rope maximum length;
   - shear/area and bend/dihedral;
   - volume/pressure where used;
   - contact, thickness, backstop, and friction;
   - winch/path/endpoint constraints.
5. Update velocity from corrected position, apply damping, clamp pathological energy, and accumulate break/tear candidates.
6. Deterministically commit topology/attachment changes at the outer tick boundary.
7. Publish simulation positions/normals or cage/proxy deformation data plus current/previous state for presentation.

XPBD compliance is stored in physical inverse-stiffness units and scaled by timestep in the solver. Persistent constraint multipliers are continuation state and must be reset when topology or target discontinuities invalidate them.

### Representation tiers

- **Cosmetic cloth:** particle triangle mesh or proxy cage; one-way rigid collision; GPU optional.
- **Cosmetic rope/hair:** particle chain with distance/bend constraints; optional capsule/segment collision.
- **Gameplay rope:** CPU fixed-tick chain with stable endpoints, tension, break state, and simplified collision; render spline may be denser.
- **Physical chain/cable:** rigid capsules/links plus joints only when two-way torque/contact is essential.
- **Far LOD:** reduced nodes/constraints, analytic spring bones, frozen/skinned pose, or disabled simulation.

## 5. Performance and Determinism Considerations

- **Broad phase:** Particle-to-rigid proxy tests scale with active particles and nearby proxies. Naive self-collision is O(P²); spatial hashing/BVH reduces candidate generation toward O(P + C), where C is surviving candidate pairs, but folded dense cloth remains expensive.
- **Narrow phase:** Particle-sphere/capsule/plane tests are cheap; particle-triangle, edge-edge, continuous segment, and self-collision tests cost more. Use simple character proxies and authored self-collision subsets/layers.
- **Solver iterations:** Cost is constraints × iterations × substeps. Stretch, bend, attachment, contact, and friction converge differently. Graph coloring permits conflict-free parallel batches but may increase passes.
- **Allocations:** Cook immutable topology, constraint batches/colors, adjacency exclusions, mapping data, and LODs. Pool positions, velocities, multipliers, contacts, tear events, and scratch. Tearing needs reserved capacity or bounded asset variants.
- **Spatial locality/cache behavior:** Use SoA particle arrays and contiguous constraint batches by type/color. Reorder particles offline for topology locality while retaining stable authored IDs through remap tables.
- **Sleeping:** Cloth rarely reaches rigid-body sleep naturally under wind/animated anchors. Use explicit significance/freeze criteria based on anchor motion, velocities, constraint error, visibility, and gameplay relevance. Gameplay ropes cannot freeze while carrying load or affecting authority.
- **Island parallelism:** Cloth/rope uses its own constraint graph rather than rigid-body islands. One-way coupling preserves parallelism; two-way attachment/contact introduces cross-system dependencies and can connect rigid islands.
- **Query batching:** Extract collider proxies once per character/body batch and reuse for all its particles. Batch rope environment sweeps/overlaps spatially. Avoid one general physics query call per particle.
- **Fixed-step cost:** Cosmetic simulation may run at a lower fixed rate with interpolation; authoritative ropes use the gameplay fixed tick. Changes in rate require XPBD compliance/timestep handling and verified damping.
- **Substeps:** More substeps improve collision, fast anchor motion, and constraint quality but multiply broad/narrow/solve work. Prefer local substeps for important assets rather than global physics substeps.
- **Determinism:** CPU XPBD can be repeatable with fixed topology, ordering, math, and reduction; GPU atomics/scheduling and cross-platform floating point make exact determinism unlikely. Keep cosmetic GPU cloth outside authoritative rollback.
- **Rollback memory:** Store positions, previous positions/velocities, persistent multipliers, sleep/freeze state, attachment/winch state, topology generation, and tears. Memory is O(history ticks × particles + constraints with multipliers); authoritative ropes must be aggressively bounded.

## 6. Pros and Cons

### XPBD particles

**Pros:** robust, controllable, unifies cloth/rope constraints, supports compliance, and parallelizes well.  
**Cons:** iteration/substep cost, approximate friction/contact, difficult two-way coupling, and sizable rollback state.

### Mass-spring force simulation

**Pros:** intuitive forces and familiar integration.  
**Cons:** stiff systems require small timesteps/implicit methods and are harder to keep stable in real time.

### Rigid-link rope/chain

**Pros:** strong two-way interaction, torque, visible links, ordinary rigid contacts.  
**Cons:** many bodies/joints, large islands, jitter, and high networking cost.

### GPU cloth

**Pros:** high particle counts and throughput without consuming CPU physics budget.  
**Cons:** synchronization/readback, platform limits, difficult determinism, and unsuitable gameplay authority.

## 7. ECS Architectural Integration

Assets:

- `SecondarySimAsset`: particles, triangles/segments, inverse masses, constraint sets, colors/batches, adjacency exclusions, collision thickness, render mapping, LODs, topology hash.
- `SecondarySimProfile`: rate/substeps/iterations, compliance/damping, gravity/wind, collision/self-collision, freeze, tearing, backend tier.
- `AttachmentSet`: stable particle/region IDs mapped to semantic bones, bodies, world anchors, winches, or sockets.

Components:

- `SecondarySimInstance`: asset/profile IDs, backend, authority tier, pool ranges, topology/config generation, significance/LOD.
- `RopeGameplayState`: endpoints, paid-out length, tension, winch speed, break state, load, owner.
- `SecondarySimAnchorRange`, `SecondarySimColliderProxyRange`, and `SecondarySimEventRange`.

Systems:

1. Sample fixed-tick semantic anchors and rigid collider proxies.
2. Apply attachment/profile/topology commands at safe barriers.
3. Simulate CPU authoritative instances.
4. Simulate CPU/GPU cosmetic instances under budgets.
5. Resolve bounded two-way forces and gameplay rope events.
6. Publish current/previous deformation state to the renderer-owned deformation graph.

First-person cloth/straps may use a separate cosmetic instance, but gameplay tethers and collisions reference the shared authoritative body/rope state.

## 8. Body, Collider, Query, Constraint, and Event Interfaces

```text
SecondaryParticle {
  stableParticleId, position, previousPosition,
  velocity, inverseMass, radius, flags
}

XPBDConstraintDef {
  stableConstraintId,
  type: Attachment | Distance | Bend | Shear | Area |
        Volume | Contact | Friction | Backstop | Winch,
  particleIds[], restData, compliance,
  damping, batchColor, breakProfileId?
}

SecondaryAnchor {
  anchorId, sourceKind,
  bodyOrEntity, generation, semanticSocket?,
  pose, linearVelocity, angularVelocity
}

SecondaryCollisionProxy {
  proxyId, owner, generation,
  shape, pose, velocity,
  materialId, collisionLayer
}

RopeCommand {
  tick, ropeId,
  kind: Attach | Detach | SetPaidOutLength |
        SetWinchSpeed | Cut | SetProfile,
  endpointOrConstraintId?, value?, stableCommandId
}

SecondarySimResult {
  tick, instanceId, topologyGeneration,
  particleRange, previousParticleRange,
  maxError, maxSpeed, iterations,
  contactCount, overflow, stateHash?
}

SecondarySimEvent {
  tick, instanceId,
  kind: Attached | Detached | TensionExceeded |
        ConstraintBroken | Torn | Collision |
        Froze | Woke | InvalidState,
  stableConstraintId?, body?, magnitude?, stableEventId
}
```

Rigid-body forces from two-way rope/cloth coupling are deferred ordered commands. Cosmetic contacts do not generate gameplay collision/damage events.

## 9. Integration Plan

1. Define XPBD units/compliance, stable topology IDs, fixed phase order, backend capability tiers, and asset validation.
2. Implement CPU rope chains with attachments, distance/bend constraints, gravity, damping, and simple capsule/plane collision.
3. Add cloth triangles with stretch/shear/bend, skinned anchors, max-distance/backstop, and primitive character proxies.
4. Add spatial-hash collision, adjacency pruning, friction, and opt-in self-collision.
5. Add LOD/rate/iteration budgets, freeze/wake, current/previous deformation publication, and visual debugging.
6. Add authoritative gameplay rope: winch, tension, endpoint force caps, cut/break, replication, snapshot, and rollback.
7. Add bounded tearing using precomputed seams or reserved topology variants.
8. Evaluate GPU cloth/PBD for cosmetic tiers with no gameplay readback dependency.
9. Add nets, hair chains, rigid-link chains, and two-way coupling only from measured gameplay needs.
10. Build stress suites, replay fixtures, content validators, and performance gates.

## 10. Verification Strategy

- Constraint fixtures: stretch, shear, bend, attachment, backstop, winch, compliance, damping, multiplier reset, and iteration/substep matrices.
- Cloth fixtures: hanging sheet, flag, cape, skirt/tube, folded cloth, fast animated anchor, teleport, wind gust, and character turn.
- Rope fixtures: hanging rope, pendulum, taut tether, slack transition, wrapping approximation, moving endpoints, winch, cut, overload, and dynamic load.
- Collision: sphere/capsule/plane/convex proxies, thin/fast obstacles, initial penetration, frictional slide, tunneling, proxy teleport, and origin rebase.
- Self-collision: folds, layers, neighbor exclusions, thickness versus edge length, dense crumple, inter-instance disabled/enabled, and overflow.
- Tearing: threshold duration, canonical candidate order, topology capacity, attachment tear, network replication, rollback, and render-map update.
- LOD: particle/constraint remap, rate changes, frozen/skinned transition, offscreen wake, camera cuts, FP/TP swap, and previous-position continuity.
- Determinism: CPU worker counts, constraint coloring/order, collisions, tears, rollback, save/load, and hashes. Explicitly measure GPU nondeterminism rather than promising equality.
- Performance: characters with layered garments, flags, ropes, dense nets, self-colliding piles, and mixed CPU/GPU tiers; record every stage and memory high-water mark.
- Visualization: particles/inverse mass, constraints/colors, compliance/multiplier/error, anchors, backstops, collision thickness, self-collision pairs, tension, tear candidates, LOD, backend, freeze, and budget rejection.

## 11. Risks and Open Decisions

- XPBD implementation ownership versus backend soft-body/cloth systems.
- CPU, GPU, or hybrid tiers by platform and asset.
- Compliance/damping units, solver iteration/substep defaults, and calibration workflow.
- Simulation mesh density, render mapping, topology reorder, and LOD transitions.
- Primitive, convex, SDF, or triangle collision proxies and continuous-collision scope.
- Self-collision subset, neighbor-ring exclusion, layers, friction, thickness, and overflow policy.
- One-way versus two-way rigid coupling and force/impulse caps.
- Gameplay rope particle count, wrapping model, winch, tension, cutting, and break rules.
- Preauthored seam tearing versus dynamic topology mutation.
- Wind/aerodynamics fidelity and interaction fields.
- Freeze/wake and significance rules for visible/offscreen/authoritative instances.
- GPU synchronization, current/previous deformation buffers, and readback prohibition.
- Network authority, snapshot budget, correction, and save/load for ropes.
- FP cosmetic duplicates versus shared TP cloth and camera collision.

## 12. Engineering Recommendations

### Engineering recommendations

1. Use XPBD as the common conceptual model for cloth, ropes, and soft accessories; retain backend-specific capability extensions behind explicit tiers.
2. Keep a low-resolution immutable simulation topology separate from render topology and cook mapping, constraint batches/colors, adjacency exclusions, and LODs offline.
3. Make compliance—not opaque per-iteration stiffness—the authored baseline, and validate behavior across supported timesteps/iterations.
4. Default cloth to one-way collision against simple skinned/rigid proxies. Enable self-collision only on selected particles/faces and authored layers.
5. Use CPU fixed-tick bounded XPBD for gameplay ropes; use GPU cloth only for cosmetic tiers with no authoritative readback dependency.
6. Use rigid-link chains only when torque, visible links, or strong two-way contacts justify the island/solver cost.
7. Treat attachments, winch changes, cuts, tears, and profile swaps as tick-boundary commands with stable topology generations.
8. Bound two-way forces, tension, contacts, self-collision pairs, topology capacity, iterations, and substeps; surface every overflow.
9. Freeze or reduce distant cosmetic instances, but never freeze an authoritative loaded rope or tether.
10. Snapshot XPBD continuation state for authoritative rollback; do not attempt exact cross-platform rollback of cosmetic GPU cloth.
11. Publish current and previous simulated deformation to the render deformation graph to preserve motion vectors and temporal stability.
12. Ship constraint/collision/tension visualization, content validation, deterministic CPU fixtures, and heavy self-collision stress tests from the first milestone.

## 13. Source Links

- Macklin, Müller, Chentanez, *XPBD: Position-Based Simulation of Compliant Constrained Dynamics*: https://mmacklin.com/xpbd.pdf
- Bender, Müller, Macklin, *A Survey on Position Based Dynamics*: https://diglib.eg.org/items/a8727382-7066-4821-ad76-dc15d1c4b8a1
- Epic Games, *Dataflow Graph* (UE 5.8): https://dev.epicgames.com/documentation/en-us/unreal-engine/dataflow-graph
- Epic Games, *Chaos Cloth Simulation Self Collision Config* (UE 5.8): https://dev.epicgames.com/documentation/en-us/unreal-engine/node-reference/Dataflow/SimulationSelfCollisionConfig
- Epic Games, *Dataflow Cloth Nodes* (UE 5.8): https://dev.epicgames.com/documentation/en-us/unreal-engine/node-reference/Dataflow
- Jolt Physics soft-body/skinned-constraint documentation: https://jrouwe.github.io/JoltPhysicsDocs/5.0.0/index.html
- NVIDIA PhysX 5.7, *GPU Simulation*: https://nvidia-omniverse.github.io/PhysX/physx/5.7.0/docs/GPURigidBodies.html
- NVIDIA PhysX 5.7 documentation index and PBD particle APIs: https://nvidia-omniverse.github.io/PhysX/physx/
- Unity Technologies, *Cloth* manual: https://docs.unity3d.com/6000.0/Documentation/Manual/class-Cloth.html
