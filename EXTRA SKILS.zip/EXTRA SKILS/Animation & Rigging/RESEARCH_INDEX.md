# Operation Mythology Animation & Rigging Research Index

This index covers reports stored in `C:\Users\steve\Desktop\EXTRA SKILS\Animation & Rigging`. A report is indexed only after its destination file has been saved and verified. Each run must rescan both `C:\Users\steve\Desktop\GAME SKILLS` and this folder before new research.

## 2026-07-27 01:49:35 America/Los_Angeles

**Report path:** `C:\Users\steve\Desktop\EXTRA SKILS\Animation & Rigging\operation-mythology-animation-20260727-014935.md`

**Subjects covered:**

- Root-motion extraction and authority policies
- Fixed-step animation motion intent and movement/collision validation
- Target motion warping, frozen/revisioned targets, windows, bounds, and failure policies
- Distance/phase matching, orientation warping, stride warping, slope/foot correction, and turn-in-place
- Network prediction, saved moves, correction/replay, and event deduplication
- FP/TP presentation reconciliation
- Previous simulation, evaluated-presentation, and previous-rendered-pose histories
- Pose sharing, animation LOD, job scheduling, cache behavior, SIMD, allocations, clip/root-curve decompression, IK iterations, and telemetry

**Major claims:**

- Movement/collision must remain authoritative; animation-authored root deltas are fixed-step intent rather than render-rate world-transform writes.
- Root-motion warping, distance/phase matching, pose warping, visual root-offset correction, and final contact IK are distinct stages and must not double-correct one another.
- Static warp targets should normally freeze at authoritative window entry; following moving targets requires recorded deterministic prediction/revision state.
- Authoritative motion extraction and gameplay event crossing continue when presentation animation is invisible or throttled.
- Network prediction must record/replay the parameters that generated motion—action generation/time, target revision, policy, and modifiers—rather than replicate bones.
- Temporal motion vectors require the pose actually used by the previous rendered frame, not merely previous simulation state.

**Engineering recommendations:**

- Use explicit `MovementDriven`, `PresentationRootOffset`, `AnimationIntent`, `TargetWarpIntent`, and `ProgrammaticMotion` policies.
- Precompute compact root translation/yaw, cumulative distance, phase, contact, and warp-window streams.
- Use bounded warp windows with scale, velocity, acceleration, rotation, reach, and protected-contact limits.
- Prefer movement-driven locomotion with distance matching, orientation/stride warping, and explicit turn-in-place; reserve authoritative root motion for bounded actions.
- Freeze validated targets by default and record revisions in prediction/saved moves.
- Keep authoritative, evaluated-presentation, and previous-rendered histories separately.
- Perform individual trajectory/terrain/contact corrections after any shared base pose and remove them progressively by animation LOD.
- Build root-path, target, accepted-path, contact, residual, correction, and temporal-history visualizers before scaling the action library.

**Sources:**

- Epic Games: Unreal Engine 5.8 Root Motion, Motion Warping, Pose Warping, Distance Matching, Game Animation Sample, Character Movement networking, and Mover documentation
- Unity Technologies: Animator root-motion handling
- Andrew Witkin and Zoran Popović: *Motion Warping*, SIGGRAPH 1995
- GDC Vault: *Animation Warping for Responsiveness in FIFA Soccer*

**Remaining open decisions:**

- Which action classes can use animation or target-warp intent
- Moving-character target authority
- Translation/rotation/velocity/acceleration/residual budgets
- Vertical-motion and collision-truncation policies by action
- Composition of overlapping authored, ability, and knockback motion
- Authored versus programmatic turn-in-place yaw
- Non-monotonic distance-matching behavior
- FP camera/root-offset ownership
- Network quantization and determinism requirements
- Previous palette versus previous deformed-vertex storage
- Full-body IK justification for coupled traversal actions

## 2026-07-27 02:00:46 America/Los_Angeles

**Report path:** `C:\Users\steve\Desktop\EXTRA SKILS\Animation & Rigging\operation-mythology-animation-20260727-020046.md`

**Subjects covered:**

- Analytic limb IK, CCD, FABRIK, Jacobian DLS, and position-based full-body IK
- Multi-effector priorities, contact lifecycle, root/pelvis behavior, joint limits, preferred angles, and failure semantics
- Iteration/tolerance budgets, warm starts, allocations, SIMD/cache layout, job scheduling, pose sharing, animation LOD, networking, and fixed-step goal capture

**Major claims:**

- Analytic limbs, iterative chains, and coupled full-body solving are different cost/quality classes; FBIK should not be the default for all placement.
- Numeric weights alone do not guarantee priority. Hard contacts require lexicographic tiers or a true task-priority/null-space method.
- Unreachable and conflicting goals must clamp or fail with measurable residuals rather than rely on stretch or unbounded iterations.
- Gameplay reach and interaction validity use deterministic envelopes before presentation IK; solved bones are not network authority.

**Engineering recommendations:**

- Use analytic two-bone IK by default and reserve FBIK for coupled multi-contact interactions.
- Compile topology, affected bones, limits, priorities, LOD fallbacks, and bounded scratch offline.
- Use explicit priority tiers, with weights only inside a tier.
- Require joint limits plus pole/preferred-angle data and report residual, limit, clamp, singular, and iteration telemetry.
- Start from the current input pose by default; allow presentation warm starts only with correction/teleport/LOD reset rules.
- Exclude irrelevant bones, recompute dirty branches only, and progressively replace FBIK with analytic or disabled constraints at lower LOD.

**Sources:**

- Epic Games: Unreal Engine 5.8 IK Rig Solvers, Control Rig Full-Body IK, and FBIK node reference
- Unity Technologies: Animation Rigging and Two Bone IK
- Aristidou and Lasenby: *FABRIK* (Graphical Models 2011)
- Samuel Buss: Jacobian transpose, pseudoinverse, and damped least-squares IK
- Nakamura, Hanafusa, and Yoshikawa: task-priority redundancy control

**Remaining open decisions:**

- Production whole-body solver and strict versus approximate task priority
- Root freedom, balance proxy, stretching, warm-start, and platform iteration policies
- Hard versus soft hand orientation for weapons/interactions
- Terrain-query latency, non-humanoid solvers, and self-collision constraints

## 2026-07-27 02:09:42 America/Los_Angeles

**Report path:** `C:\Users\steve\Desktop\EXTRA SKILS\Animation & Rigging\operation-mythology-animation-20260727-020942.md`

**Subjects covered:**

- Secondary rigid-body animation, partial reactions, driven physical animation, passive ragdoll, settling, recovery matching, and get-up
- Physics rig bodies/constraints/motors, hit impulse routing, ownership transitions, capsule reattachment, sleeping, LOD, networking, and temporal history
- Fixed-step/substep scheduling, solver iterations, allocations, memory/cache behavior, pose sharing, animation target masks, and automated stability tests

**Major claims:**

- Physical animation requires explicit state and transform ownership; a limp visual pose does not determine gameplay state.
- Partial physics, driven bodies, and passive ragdolls are distinct modes with different authority, cost, and networking requirements.
- Recovery requires settle dwell, pose matching, environment clearance, and validated capsule placement; copying pelvis position is unsafe.
- Base animation may share before physical overrides, but per-instance impulses/contacts break final-pose sharing.
- Physics transitions and corrections require previous-rendered-pose history resets for correct temporal rendering.

**Engineering recommendations:**

- Ship additive reactions, partial physics, passive ragdoll, then recovery; keep full active ragdoll optional.
- Use validated cooked Physics Rig assets with compact indices, limits, motor profiles, collision filters, and LOD maps.
- Apply impulses through fixed-step command buffers and drive bodies from fixed-step animation targets with bounded forces/energy.
- Blend one combined component-space physics mask per character.
- Use fixed timestep, bounded substeps/iterations, sleeping, and significance-driven body/contact LOD.
- Separate gameplay-authoritative ragdoll placement from cosmetic client-local limb reactions.
- Recover only after velocity dwell, pose selection, clearance, and safe capsule reattachment.

**Sources:**

- Epic Games: Unreal Engine 5.8 Physics Driven Animation, Physical Animation Component, Physics Asset Editor, Rigid Body node, skeletal physics blending API, and physics settings
- Unity Technologies: Unity 6 Ragdoll Wizard, Configurable Joint, and ragdoll stability guidance
- Andreas Nilsson: *Physics Meets Animation* (GDC 2010)
- Peng et al.: *DeepMimic* (ACM TOG 2018)

**Remaining open decisions:**

- Full active-ragdoll scope and physical-animation motor formulation
- Physics determinism/network replication granularity and platform timestep budgets
- Mass/inertia/self-collision policy and transform ownership during knockdown
- Constraint breakage/dismemberment, moving-platform recovery, sleeping-corpse persistence, and FP camera behavior

## 2026-07-27 02:26:56 America/Los_Angeles

**Report path:** `C:\Users\steve\Desktop\EXTRA SKILS\Animation & Rigging\operation-mythology-animation-20260727-022656.md`

**Subjects covered:**

- Motion-matching schemas, offline feature extraction, normalization, pruning, semantic filters, continuity, and database versioning
- Brute force, PCA/KD-tree approximate search, exact shortlist rescoring, memory/cache/SIMD layout, jobs, streaming, LOD, pose sharing, networking, and debugging
- Conventional versus learned motion matching and production gating

**Major claims:**

- Gameplay chooses the valid motion domain and remains authoritative; motion matching is a presentation pose-source node.
- Hard semantic constraints must filter candidates before numeric scoring.
- Approximate search requires exact shortlist rescoring and recall comparison against a brute-force reference.
- Search does not replace clip decompression, blending, inertialization, warping, IK, or skinning.
- Exact locomotion row selection should normally remain presentation-local in network play.

**Engineering recommendations:**

- Build brute-force exact search first and version schema/normalization/pruning/index data.
- Normalize comparable databases together and expose exact per-channel costs.
- Use minimum-improvement, residence, and cooldown hysteresis.
- Keep feature bones/horizons minimal through ablation testing.
- Store hot feature data contiguously, SIMD exact costs, and use bounded per-worker scratch.
- Partition/stream databases by gameplay domain with an always-resident fallback.
- Reset pose history/search generation after corrections, teleports, ragdoll, LOD/domain changes, and residency loss.
- Gate learned synthesis behind measured conventional quality, memory, latency, determinism, and authoring results.

**Sources:**

- Epic Games: Unreal Engine 5.8 Motion Matching, Pose Search database API, Motion Matching Debugging, and release notes
- Kristjan Zadziuk: *Motion Matching, The Future of Games Animation… Today* (GDC 2016)
- Holden et al.: *Learned Motion Matching* (ACM TOG/SIGGRAPH 2020)

**Remaining open decisions:**

- Search index by database size/hardware
- Feature bones/horizons/weights/history source and database partitioning
- Sampling, pruning, quantization, search cadence, and hysteresis budgets
- Streaming/fallback quality and retargeted canonical versus per-proportion feature spaces
- Remote-proxy search policy and learned-system deployment/fallback

## 2026-07-27 02:45:16 America/Los_Angeles

**Report path:** `C:\Users\steve\Desktop\EXTRA SKILS\Animation & Rigging\operation-mythology-animation-20260727-024516.md`

**Subjects covered:**

- Typed point/window event schemas, fixed-step range crossing, loops, reverse, seeks, skipped updates, blends, followers, LOD, and dedicated servers
- Combat windows, abilities, equipment ownership/attachments, interactions, animation proposals, and durable state
- Prediction/rollback side-effect journals, stable IDs, deduplication, confirmation, cancellation/replacement, networking, jobs, memory, and tracing

**Major claims:**

- Clip metadata does not automatically become gameplay authority.
- Damage, ammo, ownership, cooldowns, and interactions are durable snapshot-backed state; events request or present transitions.
- Active authoritative windows must be stored in rollback state rather than relying only on begin/end callbacks.
- Animation workers emit records but never mutate gameplay or presentation systems directly.
- Stable event identity must use generations/occurrences rather than floating-point time.

**Engineering recommendations:**

- Replace arbitrary callbacks/reflection with versioned typed cooked event streams.
- Use fixed-step interval crossing over unwrapped/quantized time with explicit loop/reverse/seek rules.
- Generate stable IDs from entity, action, schema, occurrence, loop/section, and target generations.
- Deterministically merge bounded worker buffers at a commit barrier.
- Use hard source policies for blends/shared poses and suppress cosmetic cues by LOD without suppressing authority.
- Implement speculative start, confirm, cancel/fade, replace, and committed-start side-effect journal operations.
- Validate equipment markers against durable ownership and combat markers against ability phase schemas.

**Sources:**

- Epic Games: Unreal Engine 5.8 Animation Notifies, Gameplay Ability System, Gameplay Abilities, and release notes
- Unity Technologies: Unity 6 Animation Events and Animator event dispatch API
- Existing Operation Mythology networking research: fixed ticks, selective rollback, and side-effect journal integration

**Remaining open decisions:**

- Which animation proposals may change authoritative ability phases
- Fixed-point/rational clip-time representation and reverse/time-dilation policies
- Speculative audio/FX/haptic/camera policies and journal retention
- Remote footstep derivation, contact-marker authoring, schema evolution, and dedicated-server proposal evaluation

## 2026-07-27 03:00:51 America/Los_Angeles

**Report path:** `C:\Users\steve\Desktop\EXTRA SKILS\Animation & Rigging\operation-mythology-animation-20260727-030051.md`

**Subjects covered:**

- First-person versus third-person rig topology, hybrid dual representation, body awareness, camera anchoring, and mode transitions
- Weapon/hand transform authority, grip profiles, ADS calibration, aim/muzzle reconciliation, IK, and event ownership
- Owner visibility, self-shadowing, reflections, ray tracing, spectators, replay, pose history, LOD, jobs, memory, and networking

**Major claims:**

- A camera-optimized first-person pose cannot safely serve as the truthful world representation for every external consumer.
- One authoritative action/equipment identity can drive separate first- and third-person presentation graphs and clips.
- The canonical world body must remain available whenever shadows, reflections, ray tracing, spectators, replay, attachments, or other players consume it.
- Gameplay aim/ballistics must be distinguished from rendered sight and muzzle transforms.
- Two presentation graphs must not independently issue durable gameplay events.

**Engineering recommendations:**

- Use a canonical world full body plus an optional owner-only first-person rig or first-person deformation path.
- Share action generation, fixed-tick phase, equipment, aim, and stable event identity rather than forcing shared pose buffers.
- Use a directed weapon/hand solve with a profile-selected driver, analytic support-hand IK by default, and bounded full-body IK only when required.
- Keep the camera off the raw animated head and validate ADS in screen space across supported FOV and aspect ranges.
- Track hidden-world consumers explicitly and apply consumer-driven animation LOD.
- Cook representation-specific bone/track masks, cache compatible base poses, partially decompress, schedule parallel pose jobs, and maintain separate render-pose histories.
- Validate sockets, grip residuals, event deduplication, cross-view phase, multi-view rendering, networking, and fixed-step mode switches automatically.

**Sources:**

- Epic Games: Unreal Engine 5.8 First Person Rendering, first-person character setup, Aim Offset, and IK Rig documentation
- Unity Technologies: Animation Rigging Two Bone IK constraint documentation
- Arkane Studios/GDC: *The Challenges of Designing First-Person Melee Combat*
- GDC Animation Bootcamp: *Giving Purpose to First-Person Animation*

**Remaining open decisions:**

- Floating arms, full-body first person, per-vertex interpolation, or action-dependent hybrid
- Shared skeleton subset versus semantic-only mapping between FP and world rigs
- Weapon-driven versus hand-driven attachment policy by item/action class
- ADS convergence, body visibility, camera comfort, and obstruction policies
- Hidden world update rates and phase-lock versus inertialized camera-mode transitions
- Spectator/replay cosmetic fidelity and per-weapon bespoke content scale

## 2026-07-27 16:14:15 America/Los_Angeles

**Report path:** `C:\Users\steve\Desktop\EXTRA SKILS\Animation & Rigging\operation-mythology-animation-20260727-161415.md`

**Subjects covered:**

- Automated rig, skin, clip, retarget, compression, graph, event, LOD, and runtime validation
- Semantic-bone and virtual-probe compression budgets, hierarchy-aware error, production-decoder comparisons, and platform cooks
- Deterministic diagnostics, validation manifests, CI/cook promotion gates, dependency caching, waivers, and visual review

**Major claims:**

- Format validity is necessary but does not prove game semantics, retarget quality, compression quality, or runtime performance.
- Local bone-track error can hide accumulated hierarchy error at contacts, attachments, sights, muzzles, and mesh vertices.
- Every cooked platform artifact should be compared through its production decoder against an immutable raw or losslessly normalized reference.
- Retarget acceptance is a matrix of source rig, target rig, reference/retarget pose, body proportions, mesh, clip role, and correction profile.
- A successful, versioned validation manifest should gate trusted derived-data and release promotion.

**Engineering recommendations:**

- Define stable fatal, error, warning, and advisory rules with structured diagnostics and expiring waivers.
- Use role-specific semantic probes and representative mesh points rather than a single global compression threshold.
- Sample keys, compressed boundaries, loop seams, contacts/events, graph-sensitive transitions, and adaptive midpoints.
- Validate transform, root, curve, event, retarget residual, IK cost, networking, and fixed-step behavior separately.
- Cache results by full dependency digest and use changed-asset, submission, nightly, and release validation tiers.
- Gate animation LOD semantic closure, quality delta, measured savings, switching history, and pose-sharing compatibility.

**Sources:**

- Epic Games: Unreal Engine 5.8 Data Validation, Animation Compression, codec reference, ACL integration, and IK retargeting documentation
- Animation Compression Library and Nicholas Frechette’s GDC 2017 compression material
- Khronos Group: glTF 2.0 specification and glTF Validator
- Unity Technologies: animation clip compression and humanoid Avatar import documentation

**Remaining open decisions:**

- Project-calibrated budgets by semantic, clip role, platform, representation, scale, and FOV
- Maximum versus percentile/integrated gating and adaptive sample density
- Virtual shells versus representative mesh probes and probe revision ownership
- Retarget matrix tiering and allowed runtime IK correction cost
- Special scale/twist/helper/creature policies and loop-seam rules
- Cross-platform math tolerance, waiver authority, and runtime mismatch fallback

## 2026-07-27 18:07:04 America/Los_Angeles

**Report path:** `C:\Users\steve\Desktop\EXTRA SKILS\Animation & Rigging\operation-mythology-animation-20260727-180704.md`

**Subjects covered:**

- Compiled hierarchical state machines, deterministic transition arbitration, interruption, re-entry, and state history
- Blend-space topology, filtering, sample pruning, sync groups/markers, phase/contact continuity, and fallback behavior
- Standard crossfades, inertialization, lightweight entry-pose matching, LOD, pose sharing, networking, and FP/TP synchronization

**Major claims:**

- Gameplay owns authoritative semantic state and fixed-tick action phase; animation state machines are presentation selectors.
- Standard crossfades and inertialization have different source-lifetime, event, root, curve, and contact semantics.
- Inertialization stops evaluating the outgoing source, so required gameplay semantics cannot remain dependent on its future clip callbacks.
- Phase synchronization requires compatible motion and markers; normalized clip time alone does not prove equivalent contact phase.
- Stacked movement, blend-axis, weight, transition, inertial, stride, and camera smoothing can create unintended response latency.

**Engineering recommendations:**

- Compile states, transitions, predicate programs, blend-space topology, masks, sync policies, and history needs into immutable contiguous tables.
- Use deterministic priority/interruption/tie-break rules and bound transitions and simultaneous pose sources.
- Use state machines for discrete modes, blend spaces for continuous inputs, layers for orthogonal actions, and motion matching only where justified.
- Apply inertialization before final IK with masked history, explicit resets, offset/energy clamps, and non-animation ownership of durable events.
- Give blend spaces explicit hull, filtering, marker, pruning, LOD, and resident fallback policies.
- Replicate semantic inputs/action phase rather than graph blend alpha or bones; regenerate presentation history after rollback/correction.

**Sources:**

- Epic Games: Unreal Engine 5.8 State Machines, Transition Rules, Blend Spaces, Sync Groups, blend nodes, and node functions
- David Bollo/The Coalition: *Inertialization: High-Performance Animation Transitions in Gears of War* (GDC 2018)
- Unity Technologies: Animation Transitions and Blend Trees documentation

**Remaining open decisions:**

- State-machine versus layer/tag boundaries and fixed-tick versus render-rate presentation decisions
- Crossfade versus inertialization by action class and interruption/re-entry policies
- Blend-space axes, triangulation, filtering owner, marker taxonomy, and fallback rules
- Inertial history/velocity/clamp/mask representation and entry-pose feature/candidate budgets
- FP/TP phase locking, remote LOD simplification, correction behavior, and dedicated-server graph subset

## 2026-07-27 18:29:16 America/Los_Angeles

**Report path:** `C:\Users\steve\Desktop\EXTRA SKILS\Animation & Rigging\operation-mythology-animation-20260727-182916.md`

**Subjects covered:**

- Montage/action presentation scheduling, compiled slots/channels, body-region admission, priority, preemption, queues, and cancellation
- Partial-body override/additive masks, root/curve/contact/event source arbitration, equipment attachments, hands/IK, and semantic phase mapping
- Ability ownership, FP/TP variants, networking/rollback, pose sharing, LOD, decompression, SIMD, jobs, allocations, memory, and validation

**Major claims:**

- Authoritative ability/action lifetime and presentation montage/clip lifetime must be separate but generation-linked.
- Slots and masks are established presentation mechanisms, but slot names alone do not define gameplay locks, cancellation, root authority, or event ownership.
- At most one admitted source should provide authoritative root-motion intent for a character on a fixed tick.
- FP and TP variants can use different clips while sharing action generation, semantic phase, cancellation, and equipment state.
- Presentation interruption or invisibility cannot invalidate durable damage, ammo, cooldown, ownership, or interaction state.

**Engineering recommendations:**

- Add an Action Presentation Scheduler with compiled channel compatibility, priority, access, preemption, root, event, and fallback policies.
- Map fixed-tick semantic action phases to representation-specific clips/sections rather than using section callbacks as authority.
- Compile weighted masks plus parent/twist/socket/IK/physics/cloth/face closure and sample only required tracks.
- Bound simultaneous layers, merge compatible additives, cache repeated poses, and use allocation-free request/scratch buffers.
- Resolve semantic requests once, map them to FP/TP variants, and keep separate pose/history only where content differs.
- Replicate action/phase/cancellation/equipment/target/root state rather than montage handles, slot weights, or bones.

**Sources:**

- Epic Games: Unreal Engine 5.8 Animation Montage, Montage Editor, blend nodes, layered animations, notifies, Gameplay Abilities, and Ability Tasks
- Unity Technologies: Unity 6 Animation Layers and Avatar Mask documentation
- Ryan Duffin/GDC Animation Bootcamp: *Using the Power of Layered Animation Systems to Make Games That Move*

**Remaining open decisions:**

- Channel/body-region taxonomy, maximum concurrent layers, priorities, queues, and minimum residence
- Full-body versus partial-body policy by action/weapon/stance and independent-arm scope
- Crossfade/inertial cancellation, protected windows, root eligibility, and collision-truncation response
- Mask boundaries, curve composition, equipment attachment phase, and FP/TP timing divergence
- Remote generic variants, pose sharing, and dedicated-server presentation subset

## 2026-07-27 18:49:57 America/Los_Angeles

**Report path:** `C:\Users\steve\Desktop\EXTRA SKILS\Animation & Rigging\operation-mythology-animation-20260727-184957.md`

**Subjects covered:**

- Authoritative aim, weapon presentation aim, attention, gaze, body-facing, and camera-channel separation
- Target arbitration, dwell, hysteresis, occlusion/unknown state, prediction, saccades, pursuit, binocular convergence, and recentering
- Eye/head/neck/spine/body distribution, Aim Offsets, turn-in-place proposals, weapon/hand IK, FP/TP, LOD, networking, and performance

**Major claims:**

- Gameplay aim, weapon presentation, behavioral attention, expressive gaze, body facing, and camera look require separate authority channels.
- A rendered eye/head/weapon residual cannot silently redefine authoritative targeting or ballistics.
- Believable gaze is a temporally coordinated eyes/head/torso/body process rather than a single unconstrained head-look rotation.
- Unknown visibility, confirmed visible, and confirmed occluded must be distinct states.
- Locomotion-aware gaze, Aim Offset yaw policy, weapon IK, recoil, and turn-in-place require an explicit solve order.

**Engineering recommendations:**

- Add a Target Orientation Coordinator consuming bounded tick-stamped target candidates and authoritative aim.
- Arbitrate attention with hard filters, priority, dwell, hysteresis, cooldown, stable IDs, and time-sliced/batched visibility.
- Use calibrated mesh-space additive aim profiles plus bounded procedural correction and body-turn proposals outside the envelope.
- Distribute residual through eyes, head/neck, spine, and body using per-rig asymmetric limits/timing, exposing unfulfilled residual.
- Apply aggressive gaze LOD and share base poses before per-instance aim/gaze divergence.
- Replicate authoritative aim and only important attention targets, reconstructing bones locally and omitting microbehavior.

**Sources:**

- Epic Games: Unreal Engine 5.8 Aim Offset, Head Look At, Skeletal Controls, and Skeleton documentation
- Unity Technologies: Animation Rigging Multi-Aim Constraint
- Lee, Badler, and Badler: *Eyes Alive* (SIGGRAPH 2002)
- Pejsa: *Effective Directed Gaze for Character Animation*
- Melgare et al.: *Reactive Gaze during Locomotion in Natural Environments* (SCA 2024)

**Remaining open decisions:**

- Aim origin/convergence and coupling between attention and combat aim
- Target-priority ownership, occlusion query cadence/grace, and unknown-state policy
- Per-character eye/head/spine/body limits, timing, convergence, and non-human profiles
- Aim Offset domain versus procedural correction/turn-in-place and recoil/IK solve order
- FP hidden-world evaluation, remote attention relevance, LOD quantization, and facial ownership of eyelids/blinks

## 2026-07-27 19:35:20 America/Los_Angeles

**Report path:** `C:\Users\steve\Desktop\EXTRA SKILS\Animation & Rigging\operation-mythology-animation-20260727-193520.md`

**Subjects covered:**

- Portable semantic facial controls, character-specific morph/bone/corrective rigs, authored curves, capture, audio-driven visemes, expressions, gaze, and blinks
- Coarticulation, jaw/lips/tongue/teeth, audio presentation-clock synchronization, cancellation, localization, streaming, and fallbacks
- Curve/morph compression, GPU/CPU deformation, SIMD, jobs, allocations, facial LOD, pose sharing, networking, replay, FP/TP consumers, and validation

**Major claims:**

- Shared semantic curve intent is more portable across facial identities than raw morph names or reference-pose bone animation.
- Visemes are visual speech categories rather than a one-to-one phoneme mapping and need overlapping timing/coarticulation.
- Dialogue/gameplay progression, audible audio time, and facial curve time are separate clocks with an explicit mapping.
- A character-specific facial rig may combine bones, morphs, correctives, animated maps, and LOD; control count alone does not predict cost.
- Authored dialogue usually needs line/variant/start replication, while live player faces require a separate compressed timestamped semantic stream.

**Engineering recommendations:**

- Establish a versioned Facial Semantic Schema and resolve all authored/captured/viseme/expression/gaze/procedural sources into one vector before rig evaluation.
- Use regional priority/composition/cancellation policies, then evaluate one sparse acyclic character-specific forward rig.
- Drive lip sync from the audio presentation clock while keeping dialogue state fixed-tick authoritative.
- Compress curves by semantic effect and validate production decoding against facial landmarks, lip silhouette, eye closure, jaw, and tongue/teeth probes.
- Stream coherent facial groups before audio deadlines with neutral/compact-viseme fallbacks and no I/O/allocation in callbacks.
- Scale from hero capture/correctives/maps through compact speech/expression, jaw/categorical, then disabled facial LOD.

**Sources:**

- Epic Games: Unreal Engine 5.8 Animation Curves, Morph Target Pipeline/Previewer, Facial Animation Sharing, and MetaHuman standards/devkit
- Apple: ARKit named facial blend-shape coefficients
- Microsoft: Azure Speech timestamped viseme/blend-shape output
- Li et al.: *Example-Based Facial Rigging* (SIGGRAPH 2010)
- Cao et al.: *3D Shape Regression for Real-time Facial Animation* (SIGGRAPH 2013)
- Pražák et al.: *Local Anatomically-Constrained Facial Performance Retargeting* (SIGGRAPH 2022)

**Remaining open decisions:**

- Semantic schema compatibility/governance and blend-shape, bone, hybrid, or learned hero rig
- Character-specific mapping/corrective scope and language/coarticulation/localization model
- Audio clock/latency/seek/underrun policy and speech-expression regional composition
- Tongue/teeth and gaze/eyelid ownership
- Curve/morph error budgets, sparse format, GPU/CPU crossover, and learned-deformer fallback
- Live facial replication/privacy and FP world-consumer evaluation

## Uncovered high-priority animation batches

- Quadruped and non-humanoid rig topology, gait phase, contact scheduling, retargeting, IK, and runtime LOD
- Multi-character synchronized interactions, paired alignment, role/phase authority, interruption, warping, networking, and recovery
