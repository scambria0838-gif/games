# Operation Mythology Animation & Rigging Research Report

## Physical Animation, Partial Ragdolls, Hit Reactions, and Recovery

**Timestamp:** 2026-07-27 02:09:42 America/Los_Angeles  
**Status:** New focused architecture batch  
**Assumptions:** Modular ECS, fixed-step authoritative gameplay/physics, variable-rate presentation, data-oriented native runtime, FP/TP support, no production code.

## 1. Feature Overview

Physical animation blends or drives rigid bodies toward an animated target pose while allowing impulses, collision, gravity, and constraints to affect the result. It spans four distinct modes:

1. **Secondary rigid-body simulation:** ponytails, straps, armor, and other non-authoritative appendages.
2. **Partial physical reaction:** selected body branches react to hits while the character remains movement-controlled.
3. **Driven/full physical animation:** joint motors pursue an animation pose while the complete articulated body simulates.
4. **Passive ragdoll:** motors release and physics owns the body until sleep, death persistence, despawn, or recovery.

Operation Mythology should implement an explicit state machine:

`Animated → PartialReaction → DrivenPhysical → PassiveRagdoll → Settling → RecoveryAlign → GetUp → Animated`

Gameplay owns whether a character is alive, incapacitated, damageable, interactable, and allowed to recover. Physics owns simulated bodies only while the selected state permits it. Animation supplies motor targets and recovery clips; it does not infer gameplay state from a visually limp pose.

## 2. Existing Coverage and Identified Gap

The required scan found a new `GAME SKILLS` report on pose evaluation, sharing, and GPU deformation. It establishes immutable pose jobs, required-bone masks including physics consumers, deterministic publication, follower-specific hit-reaction stages, and previous-rendered-pose history.

The dedicated folder contains completed root-motion/warping and FBIK reports. Those define movement authority, target generations, bounded solvers, final-contact ordering, and explicit residual/failure reporting.

Still uncovered:

- physical-body/animation ownership transitions;
- partial-ragdoll masks and motor-drive profiles;
- impulse routing and hit-reaction escalation;
- fixed-step and networking rules for simulated bodies;
- stable recovery pose/clip selection;
- capsule reattachment and collision-safe get-up;
- physics LOD, sleeping, pose sharing, memory, and temporal-history behavior.

## 3. Sourced Facts

1. Unreal Engine 5.8 documents blending physics simulation with keyframed animation and requires a Physics Asset containing bodies and constraints [S1].
2. Unreal supports enabling simulation recursively below a selected bone and controlling the physics blend weight for that branch, including hit-reaction workflows [S1].
3. Unreal’s Physical Animation Component applies physics simulation on top of skeletal animation and can target groups of bones while animation continues [S2].
4. Unreal’s Physics Asset defines rigid bodies and constraints for a skeletal mesh [S3].
5. Unreal’s skeletal-mesh component API explicitly blends physics bones with animated bones using complementary weights [S4].
6. Unreal’s Rigid Body animation node runs in component space and can pass character velocity, acceleration, gravity, and external forces into secondary simulation [S5].
7. Unreal exposes physics timestep, substepping, asynchronous fixed-step, joint iterations, and post-solve push-out iterations as stability/performance controls [S6].
8. Unity 6 ragdolls are built from colliders, rigid bodies, and joints; its Ragdoll Wizard generates that setup [S7].
9. Unity’s Configurable Joint exposes angular limits and position/rotation drives suitable for controlling a ragdoll toward target configurations [S8].
10. Unity’s stability guidance warns that extremely small joint angles, unsatisfiable constraints, extreme forces, and bodies initialized inside static geometry can destabilize or separate ragdolls [S9].
11. Andreas Nilsson’s GDC presentation describes recovery by waiting for low ragdoll velocity, matching against get-up start poses, driving toward the closest pose, then blending to the animation [S10].
12. DeepMimic demonstrates the broader research pattern of tracking example motion with a physically simulated character while responding to perturbations [S11].

These sources support explicit physics assets, motor/drive profiles, blending, fixed/substep controls, recovery pose matching, and strong validation. They do not establish a universal motor strength, timestep, or network model.

## 4. Industry-Standard Animation API or Pattern

### Physics rig asset

`PhysicsRigAsset`:

- skeleton compatibility hash and bone/body remap;
- body shapes, mass, inertia, center of mass, damping, collision layer, and material;
- joint parent/child, frames, angular/linear limits, projection, break thresholds;
- self-collision include/exclude table;
- motor profiles by state/body group;
- simulation LOD body-collapse maps;
- recovery probe bodies and support/contact definitions;
- offline validation results.

Physics shapes are deliberately simpler than render bones. Bodies use stable compact indices and parent-first joint order.

### Runtime state and profiles

`PhysicalAnimationState`:

- mode and generation;
- active body mask/profile;
- animation-target pose handle/tick;
- per-group drive strength/damping/maximum force;
- blend/acquire/release curves;
- root/capsule ownership mode;
- recovery candidate/phase;
- network authority and correction policy.

Motor profiles use strength/stiffness, damping, maximum force/torque, and per-axis freedom. A single global “physics alpha” is insufficient for pelvis, spine, head, arms, and legs.

### Hit reaction

`HitImpulseRequest` contains hit body, point, direction, impulse/energy class, damage/action generation, and fixed tick. Gameplay first classifies:

- cosmetic additive reaction;
- partial physical reaction;
- stagger/knockdown driven physical state;
- passive/death ragdoll.

Physics applies impulses at its fixed-step barrier. Repeated hits accumulate through a bounded policy rather than spawning new controllers or timelines.

### Recovery

1. Require linear/angular velocity and contact state to remain within thresholds for a dwell period.
2. Determine support surface and safe capsule placement.
3. Compute ragdoll orientation and a compact pose descriptor.
4. Search front/back/side/crouched get-up entry poses.
5. Reject clips whose clearance/root path fails.
6. Drive or blend the ragdoll toward the selected entry pose.
7. Reattach authoritative capsule at a validated transform.
8. Run get-up animation/root-motion intent through normal movement validation.
9. Restore ordinary collision/movement in a declared order.

Never teleport the capsule to an unchecked pelvis transform.

## 5. Runtime and Content-Pipeline Performance

Let `R` be simulated bodies, `J` joints, `C` contacts, `I` solver iterations, and `P` physical characters. Broadly, rigid-body integration is **O(R)** while constraint/contact solving is approximately **O(I × (J + C))**, with broadphase/narrowphase costs determined by the physics engine and scene.

### Pose evaluation, bones, and blending

Animation target generation still costs clip decompression/blending for driven bodies. Resolve a target-bone mask from simulated bodies plus ancestors; do not evaluate fingers/face/twists if motors do not consume them.

Partial reactions require:

- one target pose;
- physics simulation for active bodies;
- model/component-space blend;
- downstream attachment/bounds/palette recomputation.

Avoid sequentially recomputing the whole skeleton for each hit branch. Combine active physical masks and process once.

### Physics iterations and fixed step

Joint/contact iteration counts, timestep, mass ratios, collision penetration, motor stiffness, and impulses interact. High drive strength with a large timestep can create jitter or instability. Use a fixed physics step and bounded substeps; reject a catch-up spiral by capping work and applying a declared degradation/time-dilation policy.

### Allocations, memory, and cache

- Preallocate body, joint, motor, contact-event, and recovery-candidate storage.
- Store body transforms/velocities and drive targets in contiguous SoA-friendly arrays where backend access allows.
- Map skeleton-to-body indices once at cook/load.
- Use fixed-capacity impulse queues per character/world partition.
- Keep recovery pose descriptors compact; do not decompress every candidate full pose during search.
- No heap allocation when enabling ragdoll, receiving a hit, sleeping, or starting recovery.

### SIMD and job scheduling

Animation target-pose work remains SIMD/job friendly. Physics-island solving belongs to the physics scheduler; do not create one animation job per body. Synchronize:

1. fixed animation target snapshot;
2. physics commands/impulses;
3. physics step/substeps;
4. completed body transforms;
5. physics-animation blend/palette publication.

Async physics may lag presentation; interpolate completed physics snapshots rather than reading bodies mid-step.

### Pose sharing

Base animation may be shared before physical overrides. The first per-instance impulse/contact breaks final-pose sharing. Distant partial reactions can degrade to additive clips; passive ragdolls cannot share poses but can sleep/freeze.

### Animation/physics LOD

1. full local-player/hero drives and contacts;
2. reduced bodies, self-collision, contacts, and iterations;
3. partial reaction replaced by additive/inertial hit pose;
4. passive ragdoll lower update rate after settling;
5. sleep and retain last palette;
6. distant death pose baked/frozen or replaced by non-simulated representation.

Never disable authoritative collision or recovery state solely because the render mesh is invisible.

### Networking

Choose per gameplay class:

- **Server-authoritative physics replication:** required when ragdoll placement affects gameplay/collision.
- **Server root/pelvis plus state, client-local limbs:** cheaper presentation approximation.
- **Pure local cosmetic partial reaction:** no gameplay consequence.

Replicate mode/generation, root/body anchor, key velocities, impulse/event seeds, sleep/recovery state, and selected recovery clip—not every animated bone by default. Correction must be energy-aware: large body teleports can explode constraints. Apply hard resets only at safe state transitions or rebuild the island from a coherent snapshot.

### Temporal rendering

Physics blend produces a new rendered pose. Preserve the prior rendered palette/deformed state until velocity output completes. Ragdoll enable, hard correction, sleep/freeze, recovery snap, and body-LOD remap are explicit temporal-history reset reasons.

## 6. Pros and Cons

### Pros

- Localized, force-responsive hit reactions.
- Collision-valid deaths and environmental interaction.
- Motor profiles preserve authored style while allowing physical perturbation.
- Explicit state/authority contracts avoid capsule/ragdoll ownership ambiguity.
- Recovery pose matching reduces large blend discontinuities.

### Cons

- Physics assets and drives require extensive per-rig tuning.
- Results vary with timestep, mass, contacts, and platform physics behavior.
- Full-body simulation is costly and difficult to predict/network.
- Partial simulation can tear visually at the animated/simulated boundary.
- Recovery around obstacles and moving platforms is failure-prone.

## 7. ECS Architectural Integration

Components:

- `PhysicalAnimationComponent`: rig/profile handle, mode, generation, LOD.
- `HitReactionState`: queued reaction class and cooldown/accumulation state.
- `RagdollGameplayState`: alive/incapacitated/dead/recoverable authority.
- `RecoveryState`: settle timer, candidate, clearance result, phase.
- `PhysicsPresentationHistory`: opaque current/previous published handles.

Systems:

1. damage/gameplay classifies hit;
2. command extraction writes bounded physics requests;
3. animation produces fixed-step motor target pose;
4. physics owns bodies/joints and publishes coherent snapshots;
5. recovery system evaluates sleep/contact and clearance;
6. animation blends body transforms and get-up entry;
7. movement validates capsule/root reattachment;
8. render extraction publishes current/previous palettes.

ECS components never store raw physics-engine pointers.

## 8. Rig, Pose, Graph, Constraint, and Event Interfaces

### Rig validation

- finite positive mass/inertia and bounded adjacent mass ratios;
- shapes neither missing nor deeply overlapping at reference pose;
- joint frames aligned and limits contain the reference pose;
- parent/body graph connected as intended;
- collision exclusions for adjacent/internal bodies;
- motor targets available for every driven body;
- body LOD maps preserve a connected root;
- recovery probes and get-up descriptors valid.

### Pose/graph

Physical blending is a typed component-space stage. It consumes a coherent physics snapshot and target pose. Graph compiler declares the simulated mask, boundary bones, and required model-space recomputation.

### Events

`PhysicalModeChanged`, `BodyHit`, `ConstraintBroken`, `RagdollSettled`, `RecoverySelected`, `RecoveryBlocked`, `CapsuleReattached`, and `RagdollSlept` carry entity/mode/action generations. Collision callbacks are buffered and deterministically reduced before gameplay consumption.

## 9. Content and Runtime Integration Plan

1. Establish physics-rig conventions, body sets, collision layers, mass/inertia ranges, and joint limits.
2. Build automated physics-asset validation and a reference-pose drop test.
3. Implement secondary component-space rigid-body simulation.
4. Add partial hit reactions on one limb with bounded impulses and blend curves.
5. Add motor profiles for driven physical knockdown.
6. Add passive full ragdoll with capsule/body ownership state.
7. Implement sleeping, LOD, temporal resets, and networking profile choices.
8. Build recovery descriptor database and static-ground front/back get-up.
9. Add clearance checks, capsule reattachment, moving-platform handling, and failure branches.
10. Expand to partial recovery, repeated hits, constraint breakage, and FP/TP presentation.

## 10. Verification Strategy

### Asset tests

- automated overlap, mass ratio, joint frame/limit, collision-filter, and body-map checks;
- reference-pose simulation with zero external impulse;
- standardized drop, swing, twist, and high-impulse tests;
- compare all supported skeleton/physics LODs.

### Transition tests

- every state edge, interruption, repeated hit, death during recovery, teleport, moving platform, water/gravity change, unload/reload, and correction;
- assert one owner for capsule/root/body transforms at every phase;
- poison stale generations and late callbacks.

### Recovery

- front/back/left/right poses on slopes, stairs, walls, ceilings, moving bases, crowds, and narrow spaces;
- measure entry-pose distance, blend angular velocity, capsule correction, foot/root slide, time-to-control;
- blocked recovery must remain safe and choose retry/crawl/despawn policy.

### Performance and stability

Test 1/10/50/200 ragdolls, 8/12/20 bodies, 4–16 solver iterations, self-collision on/off, full/partial/sleep states. Record animation target cost, physics step/substeps, bodies/joints/contacts/islands, iterations, constraint error, penetration, motor error, allocations, cache/worker utilization, network bytes/corrections, sleep latency, and palette/history memory.

Acceptance gates:

- zero steady-state general-heap allocation;
- no nonfinite body/pose;
- no ownership race or mid-step read;
- bounded substeps/iterations;
- recovery never places capsule inside blocking geometry;
- authoritative events do not duplicate after correction;
- stable target frame time under declared simultaneous-ragdoll budget.

## 11. Risks and Open Decisions

- Full active ragdoll versus bounded driven reactions only.
- Physics backend determinism and network replication granularity.
- Fixed step/substep and solver iteration budgets.
- Mass/inertia authoring policy and self-collision scope.
- Motor formulation, maximum force, and energy clamp.
- Root/capsule ownership during driven knockdown.
- Constraint breakage/dismemberment scope.
- Moving-platform and crowd recovery policy.
- Persistence/despawn policy for sleeping corpses.
- FP visibility/camera behavior during knockdown.
- ML controllers such as DeepMimic are research options, not baseline dependencies.

## 12. Engineering Recommendations

1. Ship a layered system: additive reactions first, partial physics second, passive ragdoll third, recovery fourth; do not make full active ragdoll foundational.
2. Use explicit physical-animation states and generations with one transform owner per state.
3. Treat the Physics Rig as validated cooked data with compact body indices, limits, profiles, collision filters, and LOD maps.
4. Apply impulses through fixed-step command buffers after gameplay classification.
5. Drive bodies toward a fixed-step animation target with per-group strength/damping/force limits and energy clamps.
6. Blend physics in component space once per character using a combined body mask.
7. Use fixed timestep, bounded substeps/iterations, sleep, and significance-driven physics LOD.
8. Separate gameplay-authoritative ragdoll placement from cosmetic client-local limb reactions.
9. Recover only after settle dwell, pose matching, clearance, and safe capsule validation.
10. Record physics state transitions as temporal-history reset reasons and retain previous rendered deformation.
11. Build physics-asset validation, standardized impulse/drop tests, and a replayable physics debugger before content scale-up.
12. Keep ML-based physical controllers as a later prototype gated by control quality, determinism, authoring, memory, and platform cost.

## 13. Source Links

- **[S1] Epic Games, Physics Driven Animation in Unreal Engine 5.8:** https://dev.epicgames.com/documentation/en-us/unreal-engine/physics-driven-animation-in-unreal-engine
- **[S2] Epic Games, Physics Components / Physical Animation Component:** https://dev.epicgames.com/documentation/en-us/unreal-engine/physics-components-in-unreal-engine
- **[S3] Epic Games, Physics Asset Editor:** https://dev.epicgames.com/documentation/en-us/unreal-engine/physics-asset-editor-in-unreal-engine
- **[S4] Epic Games, USkeletalMeshComponent physics blending API:** https://dev.epicgames.com/documentation/en-us/unreal-engine/API/Runtime/Engine/USkeletalMeshComponent
- **[S5] Epic Games, Animation Blueprint Rigid Body:** https://dev.epicgames.com/documentation/en-us/unreal-engine/animation-blueprint-rigid-body-in-unreal-engine
- **[S6] Epic Games, Physics Project Settings:** https://dev.epicgames.com/documentation/en-us/unreal-engine/physics-settings-in-the-unreal-engine-project-settings
- **[S7] Unity 6, Creating a Ragdoll:** https://docs.unity3d.com/6000.0/Documentation/Manual/wizard-RagdollWizard.html
- **[S8] Unity 6, Configurable Joint:** https://docs.unity3d.com/6000.0/Documentation/Manual/class-ConfigurableJoint.html
- **[S9] Unity 6, Joint and Ragdoll Stability:** https://docs.unity3d.com/Manual/RagdollStability.html
- **[S10] Andreas Nilsson, “Physics Meets Animation,” GDC 2010:** https://media.gdcvault.com/gdc10/slides/Nilsson_Andreas_PhysicsMeetsAnimation.pdf
- **[S11] Peng et al., “DeepMimic,” ACM TOG 2018:** https://arxiv.org/abs/1804.02717

