# Operation Mythology Animation & Rigging Research

**Batch timestamp:** 2026-07-27 18:49:57 America/Los_Angeles  
**Subject:** Look-at and aim-offset coordination, gaze target arbitration, eye/head/spine distribution, limits, occlusion, and network presentation  
**Scope:** Research and architecture only; modular generic ECS; data-oriented runtime; first-person and third-person support

## 1. Feature Overview

Operation Mythology needs several superficially similar but semantically different orientation systems:

- **Authoritative aim:** the direction used by gameplay targeting, ballistics, attacks, and ability validation.
- **Weapon presentation aim:** the world/first-person pose that aligns weapon, hands, sight, muzzle, and upper body with authoritative aim.
- **Attention target:** what a character is behaviorally attending to.
- **Gaze presentation:** eyes, eyelids, head, neck, spine, and eventually body orientation that communicate attention.
- **Camera look:** the owning player’s view orientation, which must not be driven directly by raw head animation.

The recommended design is a **Target Orientation Coordinator**. It accepts typed, tick-stamped aim and attention inputs, arbitrates presentation targets, predicts and filters them, distributes angular work across eyes/head/spine/body within anatomical and style limits, and emits bounded constraint goals. It never changes gameplay targeting merely because the rendered eyes or weapon cannot exactly reach the target.

For player characters, authoritative aim normally dominates weapon/upper-body presentation while gaze may track a different contextual target. For NPCs, attention may influence aim only through explicit gameplay logic outside animation. First- and third-person rigs consume the same semantic aim/action state but may present gaze and weapon alignment differently.

## 2. Existing Coverage and Identified Gap

The required recursive scan found:

- A full-body IK report that recommends ordered independent foot, hand, aim, and look-at constraints.
- A first-/third-person report noting mesh-space additive Aim Offsets, weapon alignment, camera separation, and world representation.
- State-machine, layered-action, event, root-motion, motion-matching, physical-animation, compression, validation, pose-sharing, LOD, and networking coverage.

The uncovered gap was the orientation contract:

- Aim versus attention versus camera authority.
- Target selection, priority, dwell, hysteresis, occlusion, prediction, and loss behavior.
- Eye/head/neck/spine/body angular distribution and anatomical limits.
- Binocular convergence, per-eye calibration, saccades, pursuit, blinks, and head lag.
- Mesh-space aim offsets versus procedural look-at constraints and turn-in-place.
- Constraint ordering with locomotion, recoil, weapon IK, action layers, and physical animation.
- FP/TP, remote proxy, spectator, and replay policies.
- Bone, blend, IK, allocation, cache, SIMD, job, LOD, pose-sharing, networking, fixed-step, and memory costs.

This report fills that gap without duplicating the dedicated facial/lip-sync batch still queued.

## 3. Sourced Facts

### Official engine/tool facts

- Unreal Engine 5.8 Aim Offsets are additive blend spaces typically used for multi-directional weapon aiming. Epic requires mesh-space additive samples so the aiming direction remains consistent despite preceding-bone orientation, and warns that large yaw ranges can conflict with locomotion; one documented alternative is limiting the aim offset to pitch while character rotation handles yaw. [Epic Games, Aim Offset]
- Unreal’s Look At skeletal control rotates a selected bone toward a point or another bone. Unreal skeletal control nodes generally operate on component-space poses. [Epic Games, Head Look At; Skeletal Controls]
- Unreal Skeleton assets support sockets, virtual bones, blend masks/profiles, and animation retargeting, which are relevant to calibrated aim and look frames across rigs. [Epic Games, Skeletons]
- Unity Animation Rigging’s Multi-Aim Constraint is an aim-style runtime rig constraint with source target weighting and axis/limit configuration. [Unity Technologies, Multi-Aim Constraint]

### Academic and reputable animation facts

- *Eyes Alive* presents a statistical eye-movement model including saccades and uses gaze direction to communicate conversational turn-taking and internal thought. [Lee, Badler, and Badler]
- *Effective Directed Gaze for Character Animation* treats gaze shifts as coordinated movement of eyes, head, torso, and whole body, ranging from subtle glances to full turns. [Pejsa, 2016]
- *Reactive Gaze during Locomotion in Natural Environments* (SCA 2024) describes generating eye and head movement from path, terrain slope, and salient surrounding motion/shape, supporting the principle that locomotion-aware gaze is more than a single head-look constraint. [Melgare et al., 2024]

### Consequences supported by those facts

- Weapon aiming and expressive gaze should not be modeled as one undifferentiated look-at node.
- Aim offsets require a calibrated additive base and careful yaw policy.
- Believable gaze is distributed temporally and spatially across more than one joint.
- Component/world-space target conversion and per-rig axis calibration are explicit requirements.

### Engineering recommendations versus facts

The arbitration schemas, target lifecycle, occlusion policy, distribution profiles, fixed-step/network rules, exact solve order, performance strategy, and tests below are Operation Mythology engineering recommendations. Anatomical angles, speeds, dwell times, and occlusion grace periods must be measured and authored by character/style; this report does not claim universal numbers.

## 4. Industry-Standard Animation API or Pattern

### Separate semantic target channels

Use independent typed channels:

- `GameplayAim`: authoritative origin/direction or target solution.
- `WeaponPresentationAim`: visual target derived from gameplay aim plus bounded reconciliation.
- `Attention`: selected object/point/semantic target.
- `Gaze`: eye fixation target produced from attention behavior.
- `HeadLook`: filtered head/neck target.
- `BodyFacingProposal`: a request to locomotion/turn-in-place, never a direct root write.
- `CameraLook`: owner input/camera state, independent of animated head output.

Each target carries:

- Stable target/entity ID and generation.
- World point, direction, or semantic anchor.
- Acquisition fixed tick and expiry.
- Priority class and stable tie-break.
- Confidence, dwell, hysteresis, and loss policy.
- Visibility/occlusion status and last-confirmed tick.
- Prediction velocity and clamp policy.
- Allowed consumer set: eyes, head, spine, weapon, body, FP, TP, remote.

### Target arbitration pattern

Candidate attention targets are selected outside pose jobs. The coordinator:

1. Filters invalid, dead, out-of-range, disallowed, or stale generations.
2. Applies hard context constraints.
3. Ranks by semantic priority, relevance, visibility/confidence, continuity, and stable ID.
4. Applies minimum dwell, switch hysteresis, and cooldown.
5. Produces one primary fixation plus optional queued/ambient candidates.

Gameplay aim bypasses attention arbitration; it comes from the authoritative combat/ability path.

### Orientation distribution pattern

Solve the desired direction into a profile:

1. Compute target direction in a stable component/model reference frame.
2. Determine yaw/pitch residual from current body/weapon/eye forward axes.
3. Apply target validity and range.
4. Allocate a first response to eyes when gaze is enabled.
5. Allocate remaining response to head/neck with style-dependent delay and limits.
6. Allocate larger residual to spine/upper body.
7. When residual exceeds the pose envelope or persists, emit a turn-in-place/body-facing proposal.
8. Clamp all stages and expose remaining residual rather than forcing impossible anatomy.

Distribution is not merely multiplying one angle by percentages. Each link has asymmetric limits, speed/acceleration, timing, and contribution curves.

### Gaze-shift pattern

Recommended states:

- `NoTarget`
- `Acquire`
- `Saccade`
- `Fixate`
- `SmoothPursuit`
- `OccludedGrace`
- `Release`
- `Recenter`

Eyes may reach a new fixation before the head. Moving targets use bounded prediction/smooth pursuit; target jumps trigger a new saccade rather than dragging eyes slowly across the whole arc. Ambient microbehavior is a cosmetic layer and is suppressed when gameplay/cinematic direction requires exact gaze.

### Weapon aim pattern

- Aim Offset or procedural upper-body solve presents the authoritative aim direction.
- A declared yaw envelope determines when upper-body twist is sufficient versus when locomotion/turn-in-place must rotate the body.
- Weapon/hand hierarchy follows the previously defined grip profile and directed constraint order.
- Rendered muzzle/sight error is measured against gameplay aim but does not silently redefine ballistics.

## 5. Runtime and Content-Pipeline Performance

### Pose-evaluation complexity

Aim/gaze control cost consists of:

- Candidate selection and occlusion queries.
- Target prediction/filtering.
- Additive aim-space sample/decompression/blending.
- Component-space hierarchy work for head/spine/eyes.
- Constraint evaluation and final weapon/hand IK.

For `N` characters, `C` candidates, `B` affected bones, and `I` iterative constraint work, a naive implementation can approach `O(N × C + N × B + N × I)`, excluding scene-query cost. Candidate/visibility work, not the small look-at solve, can dominate crowds.

### Candidate and occlusion budgets

- Maintain small bounded candidate sets supplied by gameplay/AI/interaction systems.
- Do not scan all scene entities from animation.
- Time-slice occlusion checks by significance and target change.
- Reuse last-confirmed visibility for a bounded grace interval.
- Batch ray/visibility queries through the owning spatial/physics service.
- Use target anchors (face, chest, weapon, interaction point) rather than arbitrary mesh queries.
- Distinguish “not checked this frame” from “confirmed occluded.”

Occlusion affects presentation confidence and gaze release; it does not invalidate authoritative combat aim unless gameplay targeting independently says so.

### Bone counts and blend costs

- Aim offsets may touch spine, clavicles, arms, neck, and weapon helpers; gaze may touch spine, neck, head, eyes, eyelids, and facial curves.
- Compile affected masks and parent closure.
- Apply mesh-space additive aiming only to the required upper-body mask.
- Evaluate eye/head constraints after the base/action/aim pose so final axes are current.
- Avoid recomputing full component-space transforms after each individual bone; batch dirty-chain propagation.
- For remote LOD, reduce spine links, remove independent eyes, then replace head look with a single additive/pose or disable it.

### Clip decompression

- Aim Offset samples are pose samples and may require several weighted sources; prune negligible samples under validated error.
- Keep common aim poses resident for player and combat-near characters.
- Decode only required tracks and share base/aim samples for compatible pose-sharing buckets.
- Eye/head procedural solves do not require clip decompression unless authored gaze-shift, blink, or style clips are layered.
- Separate facial/gaze curve streams so lower LODs can omit them.

### Cache behavior and SIMD

- Store target states, filters, limits, and solver profiles in compact structure-of-arrays batches.
- Convert world targets to component/model space once per pose evaluation snapshot.
- Batch quaternion/vector math for characters sharing a rig/profile.
- Store affected bone indices and distribution weights contiguously.
- Use SIMD for aim-space blending and batched direction/clamp math where it improves throughput.
- Keep scalar reference paths for validation.

### Allocations

- Candidate, accepted target, visibility result, and constraint goal buffers are bounded and pooled.
- No heap allocation, entity lookup, or scene query occurs inside pose jobs.
- Target generations prevent dangling object pointers.
- Ambient gaze queues use fixed rings with a deterministic drop policy.
- Missing profiles/targets fall back to recenter/no-target, not allocation or graph mutation.

### Filtering and latency

Separate:

- Fixed-tick authoritative aim.
- Render-interpolated presentation aim.
- Weapon sway/recoil.
- Gaze fixation/saccade.
- Head follow.
- Spine/body facing.

Do not pass all channels through the same low-pass filter. For each, define maximum speed/acceleration, dead zone, prediction horizon, acquire/release timing, and reset conditions. Trace end-to-end latency from gameplay target change to weapon, eyes, head, and body.

### IK iterations and solve order

Look-at bones normally need direct constrained rotations rather than a general iterative FBIK solve. Weapon aim may use:

- Aim-space additive pose.
- Analytic hands.
- Bounded spine/shoulder correction.
- FBIK only for coupled full-body contacts.

Recommended order:

1. Base/state/action pose.
2. Aim Offset/upper-body aim.
3. Recoil and action additives.
4. Spine/head look distribution.
5. Eye fixation and eyelid corrective curves.
6. Weapon/hand/contact IK according to the action profile.
7. Physical/secondary animation.

Some weapon rigs require weapon/hand target resolution before final gaze; the profile must declare and validate the order. Cap any iterative refinement and report residual.

### Job scheduling

1. Fixed-step gameplay aim and attention-candidate production.
2. Batched target validation/ranking and visibility requests.
3. Visibility result integration and target lifecycle update.
4. Immutable presentation target snapshot.
5. Parallel pose/aim/gaze evaluation.
6. Constraint/IK jobs.
7. Socket/palette/event/telemetry commit.

Visibility can be one or more frames latent for cosmetic attention. Gameplay aim remains current through its authoritative path. Avoid one job per target or eye.

### Pose sharing

Base locomotion/action poses can share before aim/gaze divergence. Further sharing requires:

- Same skeleton/retarget/profile.
- Same aim-space cell/weights and phase.
- Same attention/gaze target direction bucket.
- Same affected mask, LOD, action, and representation.

Exact world targets usually break final-pose sharing. A crowd LOD may quantize direction into coarse gaze/aim sectors or use a shared neutral pose.

### Animation LOD and visibility throttling

Recommended progression:

- LOD0: independent eyes, eyelids, head/neck/spine distribution, weapon aim, target prediction, full constraints.
- LOD1: eyes/head/limited spine, lower update rate.
- LOD2: head-only or coarse additive direction sectors.
- LOD3: no procedural gaze; action/aim silhouette only if gameplay relevant.
- Invisible: advance only semantic/fixed-step state needed for networking, root/events, and attachments; target presentation can reset/reacquire by policy.

The local FP view prioritizes weapon aim but may not render its own head/eyes. The hidden world body may still need head/aim pose for shadows, reflections, spectators, or scene captures.

### Networking and fixed-step synchronization

- Replicate/predict authoritative aim direction/target and action phase according to combat needs.
- Replicate attention target only when socially/gameplay relevant; ambient gaze can be client-local.
- Prefer stable entity/anchor ID plus generation and optional quantized point/direction over eye/head bone rotations.
- Remote clients reconstruct head/eye/spine distribution with local rig profiles and LOD.
- Fixed-tick action/aim state is authoritative; render-rate gaze smoothing is presentation.
- Rollback/correction invalidates target/filter histories by generation and either reacquires or boundedly blends to corrected aim.
- Spectator/replay uses recorded semantic aim/action/important attention events; it need not record micro-saccade noise.

### Memory budgets

Budget:

- Target candidates and accepted lifecycle state.
- Visibility cache and generations.
- Aim/gaze profiles, limits, curves, masks, and per-rig axes.
- Aim Offset pose samples/clip residency.
- Filter/prediction/history state.
- FP and TP representation histories.
- Facial/eye curves and corrective shapes at relevant LODs.

Avoid per-character dynamic containers. Profile and rig data are immutable shared assets; instances store compact state.

## 6. Pros and Cons

### Unified target coordinator with separate channels

**Pros**

- Preserves gameplay authority while coordinating visual aim, attention, eyes, head, spine, and body.
- Centralizes limits, hysteresis, LOD, networking, telemetry, and FP/TP policy.
- Avoids multiple graph nodes fighting over the same joints.

**Cons**

- More metadata and state than a single look-at node.
- Requires cooperation across gameplay/AI, animation, equipment, camera, and networking boundaries.

### Pure procedural look-at

**Pros**

- Low content cost and responsive to arbitrary targets.

**Cons**

- Can look robotic, violate style, twist anatomy, and ignore action/locomotion context.
- Requires strong limits, timing, and corrective shapes.

### Authored aim/gaze poses

**Pros**

- Good silhouettes, shoulder/spine deformation, and artistic control.

**Cons**

- Sample count and memory grow with direction, stance, weapon, body type, and emotion.
- Sparse spaces need procedural correction between/beyond samples.

### Hybrid authored/procedural

**Pros**

- Aim poses carry shape/style while constraints provide exact target correction and eye fixation.
- Natural LOD path from full hybrid to coarse authored sectors.

**Cons**

- Solve order and double correction must be controlled.
- More validation combinations.

## 7. ECS Architectural Integration

Recommended components/assets:

- `GameplayAimState`: authoritative origin, direction/target, fixed tick, action generation, validity.
- `AttentionCandidateBuffer`: bounded candidate IDs, anchors, priorities, confidence, expiry, consumer policy.
- `AttentionState`: accepted target/generation, acquired tick, dwell, loss/occlusion state.
- `PresentationAimState`: interpolated/predicted aim and reconciliation residual.
- `GazeState`: fixation target, saccade/pursuit phase, history generation.
- `OrientationDistributionProfile`: eye/head/neck/spine/body limits, contribution, timing, axes, style.
- `AimProfile`: additive pose space, yaw/pitch envelope, body-turn thresholds, weapon/action variants.
- `TargetVisibilityCache`: target generation, last checked/visible tick, confidence, pending query.
- `OrientationConstraintSet`: immutable per-frame eye/head/spine/weapon goals.
- `RepresentationOrientationState`: FP/world/remote LOD and history.
- `BodyFacingProposal`: bounded request to locomotion/turn-in-place.

System ownership:

- Combat/abilities own authoritative aim.
- AI/interaction/dialogue/gameplay produce attention candidates.
- The coordinator owns presentation target arbitration and lifecycle.
- Animation owns aim-space sampling and pose distribution.
- Locomotion owns accepted body/root rotation.
- Equipment/IK owns weapon/hand alignment.
- Camera owns player view orientation.
- Networking owns semantic replication policy.

Pose arrays and visibility query resources remain outside ECS chunks in specialized pools/services.

## 8. Rig, Pose, Graph, Constraint, and Event Interfaces

### Rig calibration interface

`OrientationRigProfile`

- Skeleton/retarget version.
- Forward/up axes for component, head, each eye, weapon/sight, and spine controls.
- Eye centers, visual-axis calibration, and convergence limits.
- Neck/head/spine chain indices and contribution curves.
- Eyelid corrective curve/morph mapping by eye pitch and blink.
- Per-LOD chain/mask maps.
- FP/world representation compatibility.

### Target interface

`OrientationTarget`

- Target type: point, direction, entity anchor, spline/path sample, camera-derived.
- Stable ID and generation.
- World transform/velocity and timestamp.
- Semantic class, priority, confidence.
- Acquire/dwell/release policy.
- Occlusion state and last confirmation.
- Allowed consumers and representations.

### Aim result

`AimPresentationResult`

- Desired and filtered yaw/pitch.
- Aim-space cell/samples/weights.
- Applied upper-body rotation and residual.
- Body-turn proposal.
- Sight/muzzle angular and screen-space error.
- Clamp, fallback, and history-reset flags.

### Gaze result

`GazePresentationResult`

- Fixation target and lifecycle state.
- Left/right eye rotations and convergence distance.
- Head/neck/spine applied rotations.
- Remaining yaw/pitch residual.
- Saccade/pursuit/recenter phase.
- Limit, occlusion-grace, invalid-target, and LOD flags.

### Constraint interface

Each constraint declares:

- Input and output spaces.
- Affected bones and dirty descendants.
- Axis, limits, speed/acceleration, weight.
- Priority/order.
- Hard versus soft target.
- Residual and failure semantics.
- Iteration cap if iterative.

### Graph interface

Recommended graph stages:

1. Base locomotion/state/action layers.
2. Representation-specific Aim Offset.
3. Recoil and style additives.
4. Procedural spine/head distribution.
5. Eye fixation/eyelid correctives.
6. Weapon/hand/contact constraints.
7. Physical/secondary layers.

### Event interface

Gaze acquisition/loss, target switches, aim-clamped, and body-turn requested are typed presentation/telemetry events. They do not grant combat authority.

Gameplay may deliberately request a socially meaningful “look at target” action with an authoritative phase. The action owns completion/interaction; gaze reports residual/visual readiness as a proposal only if the action schema permits it.

## 9. Content and Runtime Integration Plan

### Phase 1: Semantic and rig contract

- Separate gameplay aim, weapon presentation aim, attention, gaze, body facing, and camera channels.
- Author per-rig axes, eye centers, chain maps, limits, and LOD.
- Define target IDs/generations and reset behavior.

### Phase 2: Weapon aim

- Implement mesh-space additive aim profiles with explicit yaw/pitch envelopes.
- Add body-turn proposals beyond the upper-body envelope.
- Integrate grip/sight/muzzle/hand constraints and measure alignment error.
- Support FP and world variants from one action/aim state.

### Phase 3: Head/eye gaze

- Add bounded attention candidates, deterministic arbitration, dwell/hysteresis, and target lifecycle.
- Add eye fixation, head/neck/spine distribution, saccade/pursuit/recenter states, and eyelid correctives.
- Keep ambient behavior cosmetic and suppressible.

### Phase 4: Occlusion, movement context, and LOD

- Add time-sliced visibility with explicit unknown/visible/occluded states and grace.
- Add locomotion/path-aware candidate inputs without querying the world from animation.
- Add LOD tiers, direction quantization, pose-sharing compatibility, and visibility recovery.

### Phase 5: Networking and validation

- Replicate authoritative aim and important attention targets, not bones.
- Add rollback/correction history generations.
- Establish automated alignment, anatomical, latency, performance, and multi-view tests.

## 10. Verification Strategy

### Static rig/content checks

- Valid and unique head, eyes, spine, weapon/sight/muzzle semantics.
- Finite orthonormal axes, eye centers, target anchors, limits, and contribution curves.
- Aim samples share the declared additive base and cover the intended domain without degenerate cells.
- LOD chain/masks retain required parents and sockets.
- FP/TP profiles map the same semantic aim/action contract.

### Aim tests

- Sweep yaw/pitch at every stance, locomotion mode, action layer, weapon, body proportion, and camera FOV.
- Measure weapon sight/muzzle versus authoritative aim in world and screen space.
- Verify upper-body envelope, clamp, turn-in-place threshold/hysteresis, and residual.
- Test recoil, reload, hit reaction, motion warping, and hand IK composition.
- Ensure camera orientation is unaffected by raw head motion.

### Gaze tests

- Sweep target direction/distance through eye/head/spine limits and blind zones.
- Test rapid jumps, slow pursuit, target crossing, near convergence, far direction, invalid generation, teleport, death, ragdoll, recovery, and no-target recenter.
- Measure saccade/head onset, fixation error, overshoot, speed/acceleration, residual, and limit time.
- Validate eyelid correction/blink composition and prevent eye/eyelid penetration.
- Test stylized/non-human rigs with their own profiles.

### Arbitration and occlusion tests

- Make equal/different-priority candidates appear/disappear simultaneously and verify stable choice.
- Test minimum dwell, switch hysteresis, cooldown, expiry, and queue overflow.
- Exercise confirmed visible, confirmed occluded, unknown/not-yet-checked, query delayed, and anchor unloaded states.
- Assert gameplay aim is unaffected by cosmetic attention occlusion.

### Networking/fixed-step tests

- Replay identical fixed-tick aim/action streams at different render rates and job orders.
- Quantize/dequantize remote aim/target and measure pose error.
- Predict, rollback, correct, and replace targets at action and gaze-state boundaries.
- Verify important attention target identity across clients while allowing local microbehavior.
- Exercise spectator, replay, FP, TP, shadow, reflection, and remote views.

### Performance tests

Record:

- Candidates considered, target switches, dwell/hysteresis, visibility checks/cache hits.
- Aim samples, decompressed tracks, affected bones, component-space propagations.
- Constraint types, iterations, residuals, clamps.
- Allocations, scratch high-water, cache behavior, SIMD/scalar path.
- Job timings/occupancy, LOD, update rate, pose-sharing bucket.
- FP/TP duplicate/shared work and memory.
- Fixed-tick snapshot age and correction/history generations.

## 11. Risks and Open Decisions

- Authoritative aim origin/direction and short-range camera/muzzle convergence policy.
- Separate or coupled attention and combat aim by character/action class.
- Target priority sources and ownership across gameplay, AI, dialogue, interaction, and cinematics.
- Occlusion query type, cadence, grace, and meaning of unknown visibility.
- Eye/head/spine/body limits, asymmetry, speeds, delay, and style profiles.
- Binocular convergence minimum distance and stylized/non-human eye behavior.
- Aim Offset pitch/yaw domain versus procedural spine solve and turn-in-place.
- Recoil/aim/look/weapon-IK ordering and double-correction prevention.
- FP owner head/eye evaluation when only world consumers need it.
- Remote attention replication relevance and privacy/competitive-information concerns.
- LOD direction quantization, reacquisition, and history seeding.
- Facial pipeline ownership of eyelids, blinks, expressions, and gaze-driven correctives.

## 12. Engineering Recommendations

1. Create a Target Orientation Coordinator with separate authoritative aim, weapon presentation aim, attention, gaze, body-facing proposal, and camera channels.
2. Keep combat/ability aim authoritative and fixed-step; never let rendered eyes, head, weapon, or muzzle silently redefine gameplay targeting.
3. Use stable target/anchor IDs with generations, timestamps, confidence, expiry, and explicit visibility state.
4. Arbitrate bounded attention candidates deterministically with hard context filters, priority, dwell, hysteresis, cooldown, and stable tie-breaks.
5. Treat unknown, visible, and occluded as distinct; time-slice/batch cosmetic visibility and preserve a bounded last-visible grace.
6. Use calibrated mesh-space additive aim profiles for weapon shape, then bounded procedural correction and a body-turn proposal beyond the pose envelope.
7. Distribute gaze across eyes, head/neck, spine, and body with per-rig asymmetric limits, timing, speed/acceleration, and exposed residual.
8. Use explicit acquire/saccade/fixate/pursuit/occluded/release/recenter states; keep ambient microbehavior cosmetic and suppressible.
9. Calibrate both eyes, convergence, eyelid correctives, head/spine axes, weapon sight/muzzle, and LOD maps in a versioned rig profile.
10. Apply base/action pose, aim, recoil, head/spine look, eyes/eyelids, weapon/hand/contact IK, then physical/secondary stages unless a validated action profile overrides the order.
11. Compile affected masks and dirty chains, batch world-to-component conversion, partially decompress aim samples, use SIMD-friendly buffers, and allocate nothing in pose jobs.
12. Share base poses before per-instance aim/gaze; at distance reduce eyes/spine, quantize direction, use head-only/coarse poses, then disable.
13. Resolve semantic aim/attention once for FP/TP, but maintain representation-specific pose/history and evaluate the hidden world head only when a consumer needs it.
14. Replicate authoritative aim and only important attention targets; reconstruct distribution locally and omit micro-saccade bone data.
15. Ship aim/gaze target, occlusion state, distribution arcs, limits, residuals, convergence, body-turn, sight/muzzle error, latency, LOD, and cost visualizers.

## 13. Source Links

1. Epic Games, **Aim Offset**, Unreal Engine 5.8:  
   https://dev.epicgames.com/documentation/en-us/unreal-engine/aim-offset-in-unreal-engine
2. Epic Games, **Head Look At**, Unreal Engine 5.8:  
   https://dev.epicgames.com/documentation/en-us/unreal-engine/animation-blueprint-head-look-at-in-unreal-engine
3. Epic Games, **Skeletal Controls**, Unreal Engine 5.8:  
   https://dev.epicgames.com/documentation/en-us/unreal-engine/animation-blueprint-skeletal-controls-in-unreal-engine
4. Epic Games, **Skeletons**, Unreal Engine 5.8:  
   https://dev.epicgames.com/documentation/en-us/unreal-engine/skeletons-in-unreal-engine
5. Unity Technologies, **Multi-Aim Constraint**, Animation Rigging:  
   https://docs.unity3d.com/Packages/com.unity.animation.rigging@1.2/manual/constraints/MultiAimConstraint.html
6. Sooha Park Lee, Jeremy B. Badler, and Norman I. Badler, **Eyes Alive**, ACM Transactions on Graphics/SIGGRAPH 2002:  
   https://www.cis.upenn.edu/~badler/papers/EyesAlive.pdf
7. Tomislav Pejsa, **Effective Directed Gaze for Character Animation**, University of Wisconsin–Madison, 2016:  
   https://graphics.cs.wisc.edu/Papers/2016/Pej16/
8. J. K. Melgare et al., **Reactive Gaze during Locomotion in Natural Environments**, ACM SIGGRAPH/Eurographics Symposium on Computer Animation 2024:  
   https://diglib.eg.org/bitstream/handle/10.1111/cgf15168/v43i8_cgf15168.pdf

