# Operation Mythology Animation & Rigging Research Report

## Motion Matching: Database Construction, Feature Search, LOD, and Networking

**Timestamp:** 2026-07-27 02:26:56 America/Los_Angeles  
**Status:** New focused architecture batch  
**Assumptions:** Modular ECS, data-oriented native runtime, fixed-step gameplay, variable-rate presentation, FP/TP support, no production code.

## 1. Feature Overview

Motion matching chooses a pose/time from an indexed animation database by minimizing a cost between runtime query features and offline pose features. Typical features describe:

- recent/current pose: selected bone positions and velocities;
- desired future trajectory: positions, facing, and velocities at sampled horizons;
- phase/contact/style: foot phase, stance, gait, weapon set, traversal mode, and semantic tags;
- continuity: preference for staying on the current clip unless another candidate is materially better.

Recommended architecture:

1. Offline, normalize source clips, compute feature rows at a fixed indexing interval, validate contacts, prune unusable/redundant rows, and build search data.
2. Runtime fixed-step input produces a predicted trajectory and compact query.
3. A search job retrieves approximate candidates, computes exact cost for a bounded shortlist, applies semantic/continuity rules, and selects a pose.
4. Presentation samples the chosen clip and uses inertialization plus warping/IK to reconcile remaining discontinuity.

Motion matching is a pose-source node, not the gameplay state machine. Gameplay still selects action/locomotion domain, equipment, stance, and interruption permissions.

## 2. Existing Coverage and Identified Gap

The required recursive scan found current `GAME SKILLS` reports covering ECS jobs, animation pose evaluation/sharing/GPU deformation, temporal history, physics character control, rendering, streaming, and world partition.

The dedicated animation folder contains reports on root motion/warping, FBIK, and physical animation. Its index still marks motion-matching database construction, normalization, search indexes, memory layout, LOD, and networking as uncovered.

Prior work only established:

- motion matching must remain behind a common pose-source interface;
- trajectory and root-motion authority are separate;
- previous-rendered-pose history differs from simulation history;
- motion matching should be benchmark-gated rather than displacing the state-machine baseline automatically.

This batch resolves the missing data/search/runtime contract.

## 3. Sourced Facts

1. Unreal Engine 5.8 describes Motion Matching as query-based pose selection using schema channels such as bone position/velocity and trajectory features [S1].
2. Unreal supports brute-force search, PCA projection plus KD-tree search, and an experimental vantage-point-tree mode [S1].
3. Epic documents that more principal components generally improve represented variance but increase memory and reduce performance [S1].
4. Approximate KD-tree results are followed by exact cost analysis over a configured number of nearest candidates [S1].
5. Unreal exposes pose and PCA-value similarity pruning so nearby indexed values can share entries and save memory [S2].
6. Pose Search normalization sets allow multiple databases to be normalized together; channel weights control the contribution of trajectory, pose, history, and prediction horizons [S1][S2].
7. Unreal exposes continuing-pose bias, looping bias, branch-in/exclusion ranges, search throttling, and inertial blending [S1].
8. Epic’s Motion Matching debugger records active, continuing, and candidate poses and provides per-channel cost breakdowns through Rewind Debugger [S3].
9. The original Ubisoft GDC presentation describes motion matching as searching motion data for a pose compatible with current motion and desired trajectory rather than authoring every transition [S4].
10. Learned Motion Matching proposes a neural alternative intended to retain motion-matching behavior while improving scaling with large datasets [S5].
11. Unreal 5.8 added an API to override pose history from the owning mesh, including use cases involving physical poses, showing that query history source must be explicit [S6].

These facts support a production baseline of conventional indexed search with observable costs. They do not prove that PCA/KD-tree, brute force, or learned synthesis wins for Operation Mythology’s data and hardware.

## 4. Industry-Standard Animation API or Pattern

### Offline schema

`MotionSchema`:

- skeleton/retarget compatibility;
- indexing sample rate;
- pose bones and position/velocity flags;
- past/future trajectory horizons;
- coordinate frame and facing convention;
- channel groups, normalization policy, and weights;
- semantic filters/tags;
- continuity, jump, looping, and reselection biases;
- search/index configuration;
- database LOD and platform build profile.

Feature order and meaning are content-addressed. Changing the schema invalidates derived data.

### Database row

`PoseRow`:

- clip ID and unwrapped sample time;
- normalized feature vector or compressed blocks;
- semantic bitset/domain;
- contact/phase metadata;
- allowed branch-in/branch-out flags;
- mirrored/source provenance;
- root velocity/yaw and optional distance curves;
- database generation.

Do not store runtime asset pointers inside rows. Use compact stable indices.

### Query and result

`PoseQuery` contains domain, fixed tick, current pose-history generation, trajectory samples, stance/equipment/style, required/excluded tags, and correction/reset reason.

`PoseSearchResult` contains database/row/clip/time, total and per-channel exact costs, continuing cost, candidate rank, search mode, nodes visited, shortlist count, and fallback reason.

### Search stages

1. Select domain/database using gameplay-authored chooser rules.
2. Build and normalize query once.
3. Apply hard semantic filters.
4. Retrieve candidates by brute force or approximate index.
5. Recompute exact weighted cost over bounded candidates.
6. Add continuity/transition/contact penalties.
7. Compare best candidate with continuing pose plus hysteresis.
8. Select or continue; publish trace data.

Hard constraints are not enormous weights. Invalid stance, weapon, traversal, or contact windows are filtered before numeric scoring.

### Transition policy

Use minimum improvement, minimum residence/reselection time, and transition cooldown to prevent thrashing. Inertialize from the previous rendered/evaluated pose to the new source. Never blend root-motion authority merely because visual poses blend.

## 5. Runtime and Content-Pipeline Performance

Let `N` be indexed poses, `D` feature dimensions, `K` exact candidates, `Bq` query bones, and `P` characters:

- brute-force exact search: **O(N × D)**;
- query construction: **O(Bq + trajectory samples)**;
- PCA projection: roughly **O(D × d)** for `d` retained components;
- balanced KD-tree lookup is often described as approximately **O(log N)** in favorable low-dimensional cases, but high dimension/poor distribution can degrade; exact rescoring adds **O(K × D)**;
- database build feature extraction: **O(N × D)** plus index construction/pruning.

Benchmark real distributions; do not promise KD-tree asymptotics as frame-time guarantees.

### Bone counts and pose evaluation

Query only semantically useful bones—typically pelvis/root and feet for locomotion, hands for climbing. Query feature bone count is independent of render skeleton count. Maintain compact pose history for selected bones; do not retain full 180-bone poses solely for search.

After selection, normal clip decompression/blending costs still apply. Search does not replace pose evaluation, inertialization, warping, IK, or skinning.

### Blend and IK costs

Frequent switching raises inertialization and cache costs. Track switches per second and effective live source branches. Warping and IK correct database coverage gaps but add per-instance work; they should not hide systematically poor feature schemas.

IK iterations are not part of search, but final contacts influence quality metrics and may feed next-frame pose history. Define whether history records pre-IK or final presentation pose; use final mesh history only when intentional, because environment-specific corrections can destabilize selection.

### Memory layout, cache, and SIMD

- Store feature columns/blocks aligned and contiguous.
- Keep metadata/clip provenance separate from hot numeric features.
- Quantize features only after measuring nearest-neighbor stability and final pose quality.
- Batch queries sharing schema/database.
- SIMD exact cost uses fused squared-difference/weighted accumulation over padded dimensions.
- Organize shortlist row fetches to reduce random cache misses; PCA/KD nodes and feature rows need separate telemetry.
- Keep trajectory/query scratch in fixed per-worker buffers.

Memory budget includes raw/normalized features, PCA basis/means, projected rows, tree nodes, duplicate/pruning maps, metadata, pose history, trace buffers, and clip data. Report bytes per indexed second and per pose.

### Allocations and job scheduling

No per-query heap allocations. Preallocate:

- query vector and PCA scratch;
- filter bitsets;
- candidate heap/array;
- exact-cost result array;
- trace records with bounded sampling.

Group search jobs by schema/database. One coarse job may process several characters to improve locality. Avoid a job per channel or candidate.

### Pose sharing

Characters with identical domain, history bucket, trajectory bucket, and query can share a search result, but exact equality is uncommon for players. Crowd agents can quantize trajectories into share buckets, then run per-instance final warping/IK. Never share a result across incompatible action generations or equipment domains.

### Animation LOD

1. full features, frequent search, larger shortlist;
2. fewer trajectory horizons/bones and lower search frequency;
3. smaller or coarse database LOD;
4. shared/quantized crowd queries;
5. conventional state/clip bucket or pose sharing;
6. frozen/impostor presentation.

Search throttling continues current playback; it must not pause authoritative gameplay timelines.

### Networking and fixed step

Gameplay replicates authoritative movement/action state, not motion-matching row IDs as the primary truth. Local clients may select different but compatible poses without gameplay divergence.

For tightly synchronized interactions, replicate domain/action generation, authoritative start tick/phase, and selected authored action—not a free locomotion nearest neighbor.

Run trajectory/query state from fixed-step snapshots. Presentation search may run at a lower cadence, but record selection tick and use generation checks after rollback/correction. On correction:

- reset or rebuild pose history;
- invalidate stale search result;
- requery with corrected trajectory;
- inertialize visually;
- deduplicate presentation events;
- flag temporal history when discontinuity exceeds threshold.

### Streaming

Partition databases by locomotion/action domain and platform residency. Never start a transition to a row whose clip is unavailable. Database rows and clip residency publish atomically by generation. Provide a small always-resident fallback locomotion set.

## 6. Pros and Cons

### Pros

- More data can improve transitions without combinatorial authored edges.
- Query and candidate traces make selection measurable.
- Semantic filters plus continuous costs combine gameplay control and motion quality.
- Database/domain partitioning supports equipment, stance, and traversal.
- Conventional search is deterministic enough for repeatable local presentation when inputs/build match.

### Cons

- High-quality coverage demands substantial clean, labeled animation data.
- Feature/normalization/weight tuning is nontrivial.
- Approximate indexes add memory and may miss the exact best row.
- Search can be cache-unfriendly and scales with characters/databases.
- Selection does not solve collision, root authority, foot contacts, or networking by itself.
- Replicating exact presentation choices across platforms can be brittle.

## 7. ECS Architectural Integration

Components:

- `MotionDomainComponent`: locomotion/action database domain and generation.
- `TrajectoryInputComponent`: fixed-step past/current/future samples.
- `PoseSearchStateComponent`: current row/time, residence, last search tick, history handle.
- `MotionStyleComponent`: stance, gait, equipment, injury/style tags.
- `MotionMatchingLODComponent`: schema/database/search-rate profile.

Runtime services own databases, indices, query scratch, histories, search traces, and clip residency.

System order:

1. gameplay/movement publishes authoritative trajectory/action snapshot;
2. chooser selects valid domain;
3. pose-history/query job builds features;
4. grouped search jobs select/continue;
5. pose evaluation samples selected clip;
6. inertialization, warping, IK, and physical layers run;
7. commit publishes selection trace/events/palette.

Structural domain changes use deferred commands; stale jobs are rejected by entity/domain generation.

## 8. Rig, Pose, Graph, Constraint, and Event Interfaces

### Rig/pose

Schemas reference semantic bones resolved to compact indices at cook time. Retargeted characters either share a normalized canonical feature space validated by proportion class or use separate databases.

Pose history specifies pre-IK, post-IK, or rendered-pose source explicitly. It stores timestamps with samples to handle throttling and variable presentation.

### Graph

Motion matching is a pose-source node with typed inputs and one result. It declares database residency, history bones, scratch size, search cadence, and fallback node.

### Events

Source clip events are generation-stamped. A pose jump must not retroactively fire events between unrelated times. Branch-in exclusions and contact windows are indexed metadata. Authoritative combat/equipment events remain gameplay timelines.

## 9. Content and Runtime Integration Plan

1. Capture a small locomotion dataset with starts, stops, pivots, strafes, and speed transitions.
2. Define canonical trajectory/pose/contact schema and coordinate conventions.
3. Build offline extraction, normalization, validation, pruning, and brute-force reference search.
4. Implement query/result tracing and cost visualizations before approximate search.
5. Add continuity hysteresis, inertialization, hard semantic filters, and fallback state machine.
6. Benchmark PCA/KD-tree against brute force on target hardware/data.
7. Add domain partitioning for stance/equipment and database streaming.
8. Add database LOD, query throttling, crowd share buckets, and pose-history reset rules.
9. Integrate warping/IK and measure whether corrections indicate missing data.
10. Add network correction tests; keep exact row selection presentation-local.
11. Prototype learned motion matching only after conventional metrics establish a baseline.

## 10. Verification Strategy

### Offline

- deterministic feature build hashes;
- clip/time provenance round-trip;
- normalization mean/variance and zero-variance handling;
- mirror correctness, loop boundaries, contacts, branch-in ranges, and tag coverage;
- pruning recall: compare selected rows/costs before and after pruning;
- PCA/index recall against brute-force exact nearest neighbors.

### Runtime quality

- starts/stops/pivots, strafing, sharp trajectory changes, slopes/stairs, speed mismatch, camera-relative control, aim, interruptions, and database switches;
- measure switch rate, continuing duration, cost by channel, foot slide, pose discontinuity, inertialization magnitude, warp amount, and IK residual.

### Performance

Benchmark `N = 1K/10K/100K/1M`, dimensions `D`, PCA components, shortlist `K`, database counts, and 1/10/100/500 characters. Record query-build, projection, index traversal, exact cost, candidate count, cache misses, SIMD utilization, job latency, memory, allocations, clip decompression, blend/IK cost, trace overhead, and streaming stalls.

### Networking/fixed step

- render rates 20–240 Hz over identical fixed simulation;
- rollback/correction, packet loss, late domain/clip residency, and pose-history resets;
- ensure authoritative events/movement do not depend on selected locomotion row;
- stale generation never publishes.

Acceptance gates:

- zero steady-state heap allocations;
- brute-force reference correctness;
- approximate-search recall/quality above project threshold;
- bounded search time and shortlist;
- no unavailable-clip selection;
- no authoritative divergence from presentation selection;
- cost/selection debugger available in non-shipping builds.

## 11. Risks and Open Decisions

- Brute force versus PCA/KD-tree versus another index per database size/hardware.
- Feature dimensions, bones, horizons, normalization, and weights.
- Separate databases versus one filtered database by stance/equipment/style.
- Pre-IK versus final-presentation pose history.
- Database sampling rate, pruning thresholds, and quantization.
- Search cadence and minimum improvement/residence hysteresis.
- Runtime streaming granularity and fallback quality.
- Retargeted canonical feature space versus per-proportion databases.
- Whether remote proxies run local search or receive coarse presentation phase.
- Learned Motion Matching deployment, training, determinism, fallback, and maintenance.

## 12. Engineering Recommendations

1. Build a brute-force exact reference first; optimize only with recall and frame-time evidence.
2. Treat schema, normalization, pruning, and index settings as versioned derived data.
3. Use hard semantic filters before numeric costs.
4. Normalize comparable databases together and expose every channel’s exact cost.
5. Use minimum-improvement, residence, and cooldown hysteresis to prevent reselection thrash.
6. Keep query bones/horizons minimal and validated by ablation tests.
7. Store hot features contiguously, separate metadata, SIMD exact costs, and allocate fixed scratch per worker.
8. Partition/stream by gameplay domain with an always-resident fallback.
9. Use motion matching for presentation selection; retain gameplay authority in movement/action state.
10. Reset histories/results by generation after correction, teleport, ragdoll, LOD/domain change, or residency loss.
11. Add database/query/search LOD and crowd share buckets from the first scalability milestone.
12. Gate learned synthesis behind the conventional system’s measured quality, memory, latency, authoring, and determinism baseline.

## 13. Source Links

- **[S1] Epic Games, Motion Matching in Unreal Engine 5.8:** https://dev.epicgames.com/documentation/en-us/unreal-engine/motion-matching-in-unreal-engine
- **[S2] Epic Games, UPoseSearchDatabase API:** https://dev.epicgames.com/documentation/en-us/unreal-engine/API/Plugins/PoseSearch/UPoseSearchDatabase
- **[S3] Epic Games, Motion Matching Debugging:** https://dev.epicgames.com/documentation/en-us/unreal-engine/motion-matching-debugging-in-unreal-engine
- **[S4] Kristjan Zadziuk, “Motion Matching, The Future of Games Animation… Today,” GDC 2016:** https://media.gdcvault.com/gdc2016/Presentations/Zadziuk_Kristjan_MotionMatchingFutureOfGamesAnimation.pdf
- **[S5] Holden et al., “Learned Motion Matching,” ACM TOG/SIGGRAPH 2020:** https://static-wordpress.ubisoft.com/montreal.ubisoft.com/wp-content/uploads/2020/07/09154101/Learned_Motion_Matching.pdf
- **[S6] Epic Games, Unreal Engine 5.8 Release Notes:** https://dev.epicgames.com/documentation/en-us/unreal-engine/unreal-engine-5-8-release-notes

