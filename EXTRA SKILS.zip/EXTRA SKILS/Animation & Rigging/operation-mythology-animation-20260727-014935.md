# Operation Mythology Animation & Rigging Research Report

## Root-Motion Authority, Trajectory Warping, Turn-in-Place, and Network Reconciliation

**Timestamp:** 2026-07-27 01:49:35 America/Los_Angeles  
**Domain:** Runtime animation and gameplay-animation synchronization  
**Status:** New focused architecture batch  
**Assumptions:** Modular generic ECS; fixed-step authoritative simulation; variable-rate rendering; data-oriented native runtime; first-person and third-person presentation; no production code in this report.

## 1. Feature Overview

This batch resolves how authored movement in animation clips should interact with authoritative gameplay movement. It distinguishes five related mechanisms:

1. **Root-motion extraction:** sample translation and rotation from an authored root track over a time interval.
2. **Root-motion application:** decide whether that delta is ignored, used only for presentation, or proposed to authoritative movement.
3. **Motion warping:** redistribute an authored root-motion interval so an action reaches a validated target transform.
4. **Pose warping:** adjust limbs, pelvis, and spine so a pose matches actual trajectory, speed, facing, or slope without necessarily changing authoritative displacement.
5. **Distance/phase matching:** choose clip time from remaining distance or another monotonic phase instead of advancing only by elapsed time.

The recommended architecture makes the movement solver authoritative. Animation never teleports the collision body and never integrates a second independent world transform at render rate. At each fixed simulation step, animation can produce a generation-stamped `MotionIntent` from clip root data, authored warp windows, and a frozen target snapshot. Movement validates and sweeps that intent against current rules and collision. The accepted displacement becomes simulation state. Presentation then reconciles the mesh to that accepted motion using pose warping, root-offset management, and short visual smoothing.

Locomotion should normally remain movement-driven/in-place with trajectory-based selection, stride/orientation warping, distance matching for starts/stops, and explicit turn-in-place. Root-motion authority is best reserved for bounded authored actions—mantles, vaults, executions, knockbacks, short melee lunges, and interactions—whose target and interruption rules can be validated.

## 2. Existing Coverage and Identified Gap

The required recursive scan of `C:\Users\steve\Desktop\GAME SKILLS` found eight reports/index files. Renderer and ECS batches now establish:

- immutable extracted inputs and job-safe snapshots;
- stable handles and explicit publication barriers;
- a temporal-rendering requirement to retain the **previous rendered pose**, which is distinct from previous simulation state under interpolation, skipped rendering, or rollback;
- skeletal motion vectors based on prior rendered bone matrices or deformed positions.

The dedicated folder `C:\Users\steve\Desktop\EXTRA SKILS\Animation & Rigging` was created and was empty before this batch.

The prior animation baseline saved in the former backup location recommended fixed-step root-motion intent and classified events, but deliberately left these decisions open:

- which action classes may use animation-authored displacement;
- how target warps are frozen, updated, interrupted, and networked;
- how accepted collision-limited movement is reconciled with the visual root;
- how orientation, stride, slope, distance matching, and turn-in-place compose;
- how correction/replay avoids duplicate events and divergent warp targets;
- how previous-rendered-pose history is retained when animation update rate differs from rendering.

This report addresses that uncovered decision set without revisiting general graph, compression, or rig-baseline material.

## 3. Sourced Facts

The following are sourced facts rather than Operation Mythology decisions.

1. Unreal Engine 5.8 documents root motion as motion authored on the root bone that can drive character movement. Its modes can extract root motion from all contributing enabled assets or only montages, and movement mode affects application—for example, walking/falling handling differs from flying [S1].
2. Unreal’s documented root-motion path may force Animation Graph update onto the game thread, demonstrating that root-motion integration can alter threading constraints in a production engine [S1].
3. Unreal Motion Warping uses named warp targets and authored notify-state windows. Its skew warp adjusts root motion so the character matches a target location/rotation at the end of the window; translation, vertical motion, and rotation can be enabled independently [S2].
4. Unreal Pose Warping contains orientation, stride, and slope warping. Orientation warping adjusts lower-body/IK direction and distributes compensating twist through configured spine bones; stride warping scales effective stride and requires downstream leg correction [S3].
5. Unreal Distance Matching drives animation-sequence playback from a calculated distance value rather than only linear time [S4].
6. Unreal’s Game Animation Sample generates a predicted trajectory for pose selection and detects turn-in-place from root/capsule rotational difference. Epic labels specific sample thresholds and some steering/root-offset behavior as sample/WIP choices rather than universal rules [S5].
7. Unreal Character Movement captures root-motion montage identity, track position, and movement parameters in saved moves used for network prediction and correction [S6].
8. The same Character Movement documentation warns that manually setting location/rotation is not captured by that replication path and will be treated as error by the server [S6].
9. Unreal Root Motion Sources are programmatic movement descriptions integrated with Character Movement’s saved-move replication; documented variants include move-to and jump-force behavior [S6].
10. Unreal describes Mover as supporting rollback networking through Network Prediction or networked physics, but currently labels Mover experimental and subject to API/data changes [S7].
11. Unity exposes animation root deltas through its Animator/root-motion interfaces and documents application separately from user handling such as `OnAnimatorMove` [S8].
12. Witkin and Popović’s SIGGRAPH 1995 motion-warping work demonstrates deriving families of realistic motions from captured motion by specifying a small number of warp constraints/keyframes [S9].
13. GDC’s FIFA animation-warping presentation documents animation warping as a production technique used to improve responsiveness [S10].

These facts support three conclusions without prescribing a specific engine implementation: root motion is an extracted data channel; warping is bounded by authored regions and targets; and networked movement must record/replay the motion-generating parameters rather than bypass the movement prediction system.

## 4. Industry-Standard Animation API or Pattern

### Motion policy

Every action selects one explicit `MotionAuthorityPolicy`:

- `MovementDriven`: animation is in-place; simulation velocity/trajectory owns displacement.
- `PresentationRootOffset`: root data moves only the mesh relative to the authoritative capsule within strict limits.
- `AnimationIntent`: root delta proposes fixed-step movement; movement may clip or reject it.
- `TargetWarpIntent`: an authored window redistributes a clip delta toward an approved target.
- `ProgrammaticMotion`: gameplay supplies a parameterized curve/force while animation matches presentation.

Policies are immutable for an action generation unless a defined transition changes them. Switching policy silently mid-clip is invalid content.

### Fixed-step extraction

`MotionIntent` contains:

- entity and action generation;
- prior/current unwrapped authoritative clip time;
- simulation tick interval;
- raw local root translation and rotation;
- policy and movement-mode mask;
- active warp-window ID and normalized window phase;
- frozen target ID, transform, target revision, and acquisition tick;
- horizontal, vertical, and rotational authority masks;
- maximum linear/angular correction rates;
- interruption, collision-failure, and completion rules;
- deterministic source checksum.

Extraction samples the root curve over `[previousTime, currentTime]`, including loop or section boundaries. It must not compare time for exact equality.

### Warp target contract

A `WarpTarget` is gameplay-owned, validated, and snapshotted:

- stable target ID/generation;
- transform and optional velocity;
- surface normal, traversal type, and clearance result;
- target space: world, moving-platform local, target-bone snapshot, or authored anchor;
- validity interval and maximum prediction horizon;
- ownership/permission and interaction reservation;
- revision number.

Default policy: freeze the target transform when the authoritative warp window begins. Following a moving target is opt-in and must use a deterministic target-prediction rule. A presentation graph may visualize a newer target, but it cannot change authoritative intent without a recorded revision.

### Bounded warp window

Offline, precompute cumulative root translation and rotation curves for each warpable interval. At runtime, compute remaining authored displacement and remaining target error. Redistribute only the permitted axes over the remaining normalized window with a monotonic weight curve.

Guardrails:

- minimum/maximum translation scale;
- maximum yaw and pitch/roll policy;
- maximum instantaneous linear/angular velocity and acceleration change;
- preserved contact subwindows;
- no sign reversal unless the clip is authored for it;
- explicit vertical policy: ignore, authored, ballistic, or target-aligned;
- reachable-target envelope validated before entry;
- residual error/failure result at window end.

Do not scale the whole action uniformly when only a bounded approach phase can safely change. Preserve anticipation, planted contacts, impacts, and recovery unless those phases have their own approved modifiers.

### Locomotion composition order

Recommended order:

`authoritative trajectory → clip/state/pose selection → distance/phase matching → raw pose/root extraction → accepted movement result → root-offset reconciliation → orientation warping → stride/pelvis adjustment → slope/foot placement → turn-in-place correction → upper-body aim/additives → final contacts`

Distance matching changes playback phase. Motion warping changes desired root displacement. Pose warping changes the body pose. Foot IK enforces final contacts. Combining them without separate interfaces causes double correction.

### Turn-in-place

Maintain independent authoritative facing and visual/root facing:

- accumulated yaw error = desired/capsule facing minus visual-root facing;
- begin turn only after threshold plus dwell/hysteresis;
- select a turn clip by signed angle, stance, weapon profile, and foot phase;
- consume yaw through authored root or programmatic curve at the fixed step;
- cap remaining root offset;
- allow locomotion or urgent action to interrupt with inertialization;
- publish the accepted yaw, not merely the authored yaw.

Thresholds are per stance/control mode, not global constants.

## 5. Runtime and Content-Pipeline Performance

### Pose-evaluation complexity and bone counts

Root-curve extraction is **O(1)** or **O(log K)** per track sample depending on key lookup, where `K` is key count; a cached cursor makes monotonic playback amortized **O(1)**. Warp math is constant per active window. Pose warping then costs:

- orientation warp: **O(S + L)** for `S` distributed spine bones and `L` leg/IK bones;
- stride/pelvis correction: **O(L)** before final IK;
- two-bone foot correction: **O(1)** per limb analytically;
- slope/full-body correction: **O(I × B_a)** for `I` iterations and affected bones `B_a`.

Do not evaluate the full skeleton to extract root motion or gameplay markers. Keep root curves, distance curves, warp metadata, and authoritative events in a compact simulation stream.

### Blend costs

Blending root motion from multiple sources adds weighted delta composition and can create unintuitive trajectories when sources disagree. Restrict authoritative root extraction to one primary motion source plus explicitly layered programmatic modifiers. Visual pose blends may remain broader.

Inertializing visual pose changes must not inertialize authoritative displacement. The movement policy changes at a fixed-step boundary; only mesh presentation smooths discontinuity.

### Clip decompression and allocations

- Store cumulative root-distance/yaw curves in small cache-friendly arrays independent of full pose blocks.
- Quantize curves offline with error measured in world displacement/angular error at action end.
- Use cursor-based sampling for monotonic fixed-step playback and binary search after seeks/corrections.
- Allocate no per-window objects. Use fixed-capacity active-modifier slots and generation handles.
- Store event, motion-intent, and correction records in bounded per-tick arenas or command buffers.

### Cache behavior and SIMD

Root/phase streams are small enough to stay hot and should not pull rotation/translation blocks for every bone. Batch fixed-step extraction by clip asset so sample metadata and cumulative curves are reused. SIMD has more value when sampling multiple entities sharing a clip than in isolated scalar warp arithmetic.

Full pose decompression remains SoA/SIMD work from the baseline architecture. Avoid writing a full pose merely to discover remaining distance.

### Job scheduling

Fixed-step motion extraction must complete before movement simulation for root-driven actions. Schedule one coarse job per clip/group, then deterministically merge intents by entity ID. Movement validation/sweeps run in the physics/movement phase.

Presentation pose evaluation may run later and at a reduced rate. It consumes accepted current/previous simulation transforms plus interpolation alpha. World-space target queries and collision traces are not performed inside animation worker jobs; gameplay captures them beforehand.

### IK iterations

Locomotion warping should use analytic or bounded solvers. Full-body IK is not the default response to warp error:

- prefer analytic legs plus pelvis adjustment;
- clamp targets before solving;
- cap iterations and early-out on tolerance;
- expose residual reach error;
- reduce or disable slope/foot correction at animation LOD;
- never iterate to compensate for an invalid traversal target.

### Pose sharing

Characters can share a pre-warp locomotion pose if clip/phase/state match. Per-instance trajectory, orientation, stride, slope, root offset, and contacts run after the shared pose. This creates a clear cost split:

- shared base sampling/blending: per share group;
- lightweight orientation/stride: per instance;
- terrain traces and final IK: per visible/significant instance.

At distant LOD, share the final pose only when individual trajectory/terrain correction is disabled.

### Animation LOD and visibility throttling

Priority degradation:

1. retain authoritative motion extraction for active gameplay actions;
2. disable slope traces and secondary pelvis smoothing;
3. reduce foot IK frequency/iterations;
4. reduce presentation pose rate and interpolate;
5. disable per-instance orientation/stride and use shared pose;
6. freeze distant presentation while simulation continues.

Never skip target-warp intent, authoritative section changes, or gameplay event crossing because a mesh is invisible.

### Networking

Replicate/replay inputs and compact state:

- action/policy ID and generation;
- authoritative start tick and clip/section time;
- frozen target ID/transform/revision;
- warp-window state and programmatic modifier parameters;
- movement inputs/mode and accepted server transform;
- interruption/failure result.

Do not replicate every bone or every warped pose. Client prediction records the same motion intent in saved moves. On correction, restore the action/target revision, resample root curves, replay movement, discard stale intent/events, and visually smooth the mesh.

For simulated proxies, interpolate authoritative movement and reconstruct approximate presentation phase. Exact foot contacts are presentation quality, not network authority.

### Fixed-step and previous-rendered-pose synchronization

Maintain three distinct histories:

1. previous/current authoritative simulation transforms;
2. previous/current evaluated presentation poses;
3. previous pose actually submitted to rendering.

Temporal motion vectors compare consecutive rendered states, not simulation ticks. If presentation is throttled, retain the palette or prior deformed position used by the last rendered frame until velocity generation completes. Network correction resets or flags temporal history according to correction magnitude.

## 6. Pros and Cons

### Pros

- Movement/collision remains authoritative and network-predictable.
- Authored actions retain weight and contact timing without allowing animation to bypass collision.
- Bounded windows and frozen targets make warps debuggable and replayable.
- Separate motion, phase, and pose warps prevent double correction.
- Locomotion can remain responsive with less directional/speed clip coverage.
- FP and TP can consume the same accepted movement while applying different presentation corrections.

### Cons

- Requires authored warp windows, distance curves, reach envelopes, and failure rules.
- Poorly tuned warp bounds create speed spikes, foot sliding, limb stretch, or visible residual snap.
- Moving targets complicate determinism and prediction.
- Per-instance terrain traces/IK reduce pose-sharing savings.
- Root-motion actions increase saved-move/state complexity.
- Three pose/transform histories add memory and lifetime requirements.

## 7. ECS Architectural Integration

Components:

- `MotionAuthorityComponent`: current policy, action generation, allowed axes.
- `AnimationTimelineComponent`: authoritative clip/section time and rate.
- `WarpActionComponent`: window, target handle/revision, bounds, failure policy.
- `TrajectoryInputComponent`: sampled past/current/predicted positions, velocities, and facing.
- `TurnInPlaceComponent`: accumulated visual yaw error, selected turn profile, phase.
- `PresentationRootOffsetComponent`: mesh-to-authority offset and decay state.
- `AnimationCorrectionComponent`: last correction tick/magnitude and temporal-reset flags.

Services/runtime stores:

- compiled root/distance/yaw curves;
- warp-window tables;
- target registry/reservations;
- fixed-capacity active motion modifiers;
- previous evaluated and previous rendered palette histories.

System order:

1. gameplay selects action and validates/reserves target;
2. animation timeline advances at fixed step;
3. root/phase extractor produces `MotionIntent`;
4. movement combines intent, input, gravity, bases, and programmatic modifiers;
5. collision validates and publishes accepted motion/failure;
6. action state consumes result and emits authoritative events;
7. presentation evaluates pose from accepted trajectory;
8. warping/IK reconcile mesh and contacts;
9. render extraction publishes current/previous rendered pose handles.

Structural changes are deferred to command buffers. A warp target invalidating mid-step produces a state transition, not immediate component mutation from an animation job.

## 8. Rig, Pose, Graph, Constraint, and Event Interfaces

### Rig

Warp-capable rigs require semantic root, pelvis, spine chain, leg chains, foot IK goals, foot contact points, and optional hand goals. Validation checks axes, preferred bend directions, chain lengths, root/pelvis separation, and LOD preservation.

### Pose

`WarpContext` passed to presentation nodes contains accepted linear/angular motion, desired trajectory, root offset, ground frame, stance, and LOD—not mutable movement objects.

### Graph

Nodes declare whether they modify:

- playback phase;
- root-motion intent;
- local/component-space pose;
- visual root offset;
- contacts.

The compiler rejects conflicting multiple writers without an explicit composition node. Authoritative root extraction has one primary writer.

### Constraint

Each warping/IK node declares affected bones, space, axis masks, bounds, iteration cap, and fallback. Orientation warp precedes final leg IK; slope/foot correction owns final ground contacts.

### Events

Warp-window begin/end, target acquired/lost, contact phase, residual failure, collision truncation, and completion are explicit records. Gameplay event dispatch validates action generation and fixed-step tick. Presentation effects use deduplication keys across correction/replay.

## 9. Content and Runtime Integration Plan

1. Define motion policies, authority masks, coordinate conventions, and failure taxonomy.
2. Extend clip processing to extract compact root translation/yaw, cumulative distance, phase, contact, and warp-window streams.
3. Add offline validation for loop continuity, monotonic distance segments, window overlap, speed/acceleration bounds, and reach envelopes.
4. Implement fixed-step scalar root extraction and movement validation before any visual warping.
5. Add saved-move/replay state for action generation, clip time, target revision, and motion modifiers.
6. Add presentation root-offset reconciliation and previous-rendered-pose retention.
7. Implement distance matching for stops/starts and explicit turn-in-place.
8. Add orientation and stride warping, followed by bounded foot IK.
9. Add target motion warping for one traversal action with frozen static targets.
10. Expand to moving-platform-local targets, then moving characters only after deterministic prediction tests.
11. Add FP/TP profiles: shared accepted movement/action phase, separate camera/weapon offsets and visible warp limits.
12. Profile crowds and introduce per-stage animation LOD and pose-sharing boundaries.

## 10. Verification Strategy

### Offline validation

- Compare compressed root/distance/yaw curves with source at every sample and window boundary.
- Check loop/section continuity and cumulative-distance monotonicity where required.
- Sweep target grids through reachable envelopes and flag scale, speed, acceleration, angle, or limb-extension violations.
- Verify protected contact windows remain unchanged.

### Deterministic simulation

- Replay identical fixed-step inputs and target revisions; compare motion intents, accepted transforms, failures, and authoritative events.
- Test window entry/exit on exact tick boundaries, skipped time, reverse playback, interruption, loop, and section jumps.
- Run 20/30/60/120 Hz rendering over the same simulation trace; accepted movement must match.

### Collision and traversal

- Walls, ceilings, ledges, slopes, stairs, narrow clearance, moving platforms, disappearing targets, and target reservation conflicts.
- Verify collision truncation cannot leave the visual root beyond configured offset.
- Verify failure transitions preserve capsule validity and never snap through geometry.

### Networking

- Latency, jitter, loss, reordering, correction, rollback, late join, and host migration where supported.
- Target revision changes during a warp.
- Confirm stale generations cannot emit damage/contact/completion twice.
- Compare predicted and server accepted motion per tick; chart correction magnitude and replay length.

### Pose and rendering

- Foot sliding distance, planted-foot velocity, pelvis acceleration, spine twist, limb stretch, root-offset magnitude, and warp residual.
- Camera/weapon stability in FP and silhouette/contact quality in TP.
- Previous-rendered-pose motion vectors under throttled updates, skipped rendering, correction, LOD change, and pose sharing.

### Performance

Benchmark root-only extraction versus full pose; unique versus shared clips; zero/two/four warped limbs; static versus moving targets; and no/low/high correction rates. Record:

- fixed-step root/phase sampling time;
- movement-intent merge and sweep time;
- orientation/stride/slope/IK pose time;
- traces and solver iterations;
- cache misses and bytes touched;
- pose-share hit rate;
- retained history memory;
- command-buffer counts and allocations;
- saved-move bytes and replay cost;
- corrections, target revisions, residuals, and failures.

Acceptance gates:

- zero steady-state heap allocations;
- bounded solver/physics iterations;
- no animation-side world transform writes;
- no authoritative event duplication;
- identical accepted movement across render rates;
- warp velocity/acceleration/contact metrics within content-class budgets;
- correct temporal motion vectors from consecutive rendered poses.

## 11. Risks and Open Decisions

- Which action classes may use `AnimationIntent` versus `TargetWarpIntent`.
- Whether moving-character targets are ever authoritative or only presentation assists.
- Project-specific translation, rotation, velocity, acceleration, and residual bounds.
- Vertical motion policy for mantles, jumps, knockdowns, and stairs.
- Collision-truncation response: abort, branch, continue constrained, or blend to physics.
- Root-motion blend composition when an ability, knockback, and authored action overlap.
- Whether turn-in-place consumes authored root yaw or a programmatic curve.
- Distance-matching curve conventions and behavior on non-monotonic movement.
- FP root-offset limits and camera stabilization ownership.
- Network quantization and cross-platform determinism requirements.
- Cached previous bone palettes versus previous deformed vertices for renderer velocity.
- Full-body IK justification for coupled traversal/contact actions.

## 12. Engineering Recommendations

1. Make movement the sole authority for collision-body transforms.
2. Represent root motion as fixed-step intent with explicit policy, action generation, allowed axes, and failure rules.
3. Freeze static warp targets at authoritative window entry; permit target following only through a recorded deterministic prediction policy.
4. Precompute compact root, cumulative-distance, yaw, phase, contact, and window streams so simulation never decompresses a full pose for motion logic.
5. Separate distance/phase matching, root-motion warping, pose warping, root-offset correction, and contact IK into different typed stages.
6. Use bounded authored warp windows with scale/speed/acceleration/rotation/reach limits and protected contact regions.
7. Prefer movement-driven locomotion with distance matching, orientation/stride warping, and explicit turn-in-place; reserve authoritative root motion for bounded actions.
8. Record action time, target revision, policy, and motion-modifier parameters in client prediction/saved moves; replay them after correction.
9. Preserve authoritative, evaluated-presentation, and previous-rendered histories separately.
10. Apply per-instance terrain/contact work after any shared base pose and remove it progressively by animation LOD.
11. Build target, root-path, accepted-path, contact, residual, and correction visualizers before expanding the action library.
12. Treat experimental engine movement frameworks as research references until their shipping stability and project fit are proven.

## 13. Source Links

- **[S1] Epic Games, Root Motion in Unreal Engine 5.8:** https://dev.epicgames.com/documentation/en-us/unreal-engine/root-motion-in-unreal-engine
- **[S2] Epic Games, Motion Warping in Unreal Engine 5.8:** https://dev.epicgames.com/documentation/en-us/unreal-engine/motion-warping-in-unreal-engine
- **[S3] Epic Games, Pose Warping in Unreal Engine 5.8:** https://dev.epicgames.com/documentation/en-us/unreal-engine/pose-warping-in-unreal-engine
- **[S4] Epic Games, Distance Matching in Unreal Engine 5.8:** https://dev.epicgames.com/documentation/en-us/unreal-engine/distance-matching-in-unreal-engine
- **[S5] Epic Games, Game Animation Sample Project in Unreal Engine 5.8:** https://dev.epicgames.com/documentation/en-us/unreal-engine/game-animation-sample-project-in-unreal-engine
- **[S6] Epic Games, Understanding Networked Movement in Character Movement Component:** https://dev.epicgames.com/documentation/en-us/unreal-engine/understanding-networked-movement-in-the-character-movement-component-for-unreal-engine
- **[S7] Epic Games, Mover in Unreal Engine 5.8:** https://dev.epicgames.com/documentation/en-us/unreal-engine/mover-in-unreal-engine
- **[S8] Unity, `Animator.applyRootMotion` / root-motion handling:** https://docs.unity3d.com/ScriptReference/Animator-applyRootMotion.html
- **[S9] Andrew Witkin and Zoran Popović, “Motion Warping,” SIGGRAPH 1995:** https://www.cs.cmu.edu/~aw/pdf/motion_warping.pdf
- **[S10] GDC Vault, “Animation Warping for Responsiveness in FIFA Soccer”:** https://gdcvault.com/play/1012464/Animation-Warping-for-Responsiveness-in

