# Operation Mythology Animation & Rigging Research

**Batch timestamp:** 2026-07-27 18:07:04 America/Los_Angeles  
**Subject:** Compiled animation state machines, blend spaces, transition interruption, phase synchronization, inertialization, and lightweight pose matching  
**Scope:** Research and architecture only; modular generic ECS; data-oriented runtime; first-person and third-person support

## 1. Feature Overview

Operation Mythology needs a runtime animation graph that converts authoritative gameplay state into responsive poses without making the animation graph the owner of movement, combat, equipment, or ability truth.

This batch defines a compiled presentation architecture with:

- Hierarchical state machines for discrete presentation modes.
- Blend spaces/trees for continuous motion parameters.
- Explicit transition selection, priority, interruption, and re-entry policies.
- Phase and marker synchronization for cyclic motion.
- Standard crossfades where both sources must remain semantically active.
- Inertialization where the outgoing pose can be captured and then stopped.
- Lightweight entry-pose selection inside a bounded candidate set.
- Typed, fixed-step action inputs and stable event identities shared by first- and third-person graphs.

The key boundary is that gameplay chooses the semantic domain and action phase; the animation graph chooses how that state is presented. A state-machine transition may request or visualize a change, but it must not independently invent authoritative attack, equipment, interaction, or movement state.

## 2. Existing Coverage and Identified Gap

The required recursive scan found dedicated reports for root motion and warping, full-body IK, physical animation/ragdoll, motion matching, rollback-safe animation events, first-/third-person representations, and automated rig/clip validation. The shared `GAME SKILLS` animation report already covers compiled pose evaluation, pose sharing, compression, jobs, LOD, and GPU deformation.

The remaining gap was the control layer joining those systems:

- State-machine update order and deterministic transition arbitration.
- Transition interruption when source and destination are already blended.
- State re-entry, reset, history, and one-shot completion semantics.
- Blend-space topology, parameter filtering, extrapolation, phase sync, and sparse sample behavior.
- When to use crossfade, inertialization, pose matching, montage/action layers, or full motion matching.
- What happens to source events, curves, root motion, and contacts when inertialization stops evaluating the source.
- How fixed-tick gameplay snapshots feed render-rate presentation without transition decisions changing with render rate.
- Memory, decompression, blend, cache, SIMD, allocation, job, LOD, networking, and pose-sharing implications.

This report fills that gap without repeating the prior algorithms in detail.

## 3. Sourced Facts

### Official engine facts

- Unreal Engine 5.8 state machines organize states and directed transitions. Transition rules produce a Boolean result; priorities arbitrate simultaneously valid transitions, and a maximum-transitions-per-frame property bounds how many decisions may occur in one update. State re-entry can reset sequence players or preserve their prior playback state. [Epic Games, State Machines; Transition Rules]
- Unreal transitions support duration, blend curve, per-bone blend profiles, priority, and interruption. Epic documents transition interruption when another state becomes active during an existing transition. [Epic Games, Transition Rules]
- Unreal Blend Spaces blend animation samples over one or two input axes. The system exposes triangulation, input smoothing, maximum change rate, per-bone weight speeds, and notify source policies. Epic advises against stacking multiple independent smoothing mechanisms without care. [Epic Games, Blend Spaces]
- Unreal Sync Groups synchronize animations of different lengths with leader/follower roles and matching markers. Only markers common to all synchronized animations participate; otherwise length-based synchronization may be used. Epic warns that incompatible movement or large duration differences can cause visible problems. [Epic Games, Animation Sync Groups]
- Unreal’s inertialization node records an offset between outgoing and incoming motion and fades it out. Once inertial blending starts, the source pose is no longer evaluated, so source animation notifies stop and gameplay logic may need restructuring. Epic recommends applying inertial blending before final IK. [Epic Games, Animation Blueprint Blend Nodes]
- The GDC 2018 presentation *Inertialization: High-Performance Animation Transitions in Gears of War* describes avoiding the traditional transition cost of evaluating both outgoing and incoming animation states. [David Bollo, GDC 2018]
- Unity animation transitions use conditions and exit time, can be interrupted according to current/next-state policy and ordering, and support transitions involving blend-tree states. [Unity Technologies, Animation Transitions]

### Technical consequences supported by those facts

- Transition selection, interruption, state reset, and marker policies must be explicit data, not accidental graph traversal behavior.
- A conventional crossfade and inertialization have different source-lifetime and event semantics.
- Phase synchronization requires compatible cycles/markers; it is not equivalent to normalizing every clip by length.
- Input smoothing, sample-weight smoothing, inertialization, and movement acceleration can compound latency if layered without a single response budget.

### Engineering recommendations versus sourced facts

The compiled bytecode/schema, exact arbitration tuple, history buffers, ECS components, performance strategy, event ownership rules, transition taxonomy, and rollout plan below are Operation Mythology engineering recommendations. Project thresholds and budgets require measurement; no universal blend time, hysteresis, or pose-error value is asserted.

## 4. Industry-Standard Animation API or Pattern

### Layered control pattern

Use separate presentation layers with explicit ownership:

1. **Semantic base domain:** grounded, airborne, swimming, mounted, ragdoll/recovery, cinematic override.
2. **Locomotion pose source:** blend space, distance/phase-matched clip set, or motion-matching node.
3. **Action layer:** attacks, abilities, interactions, equipment actions, hit reactions, or traversal.
4. **Additive layer:** aim, look, recoil, lean, breathing, and authored corrections.
5. **Procedural layer:** warping, hand/foot placement, constraints, physical animation, and secondary motion.

Do not encode every gameplay combination as a flat state. State machines select semantic modes; continuous variation belongs in blend spaces/trees; orthogonal actions belong in layers; combinatorial full-body selection may use motion matching.

### Compiled state-machine pattern

Authoring graphs compile into immutable tables:

- State records: pose-program entry, reset/re-entry policy, semantic tags, optional entry candidate set.
- Transition records: source, destination, predicate program, priority, interruption scope, blend policy, duration/curve/profile, sync policy, cooldown/hysteresis, event policy.
- Adjacency spans sorted deterministically.
- Compact typed parameter indices.
- Precomputed required-bone, curve, event, and pose-history masks.

Runtime instance state contains only:

- Active state and generation.
- Optional active transition with source/destination generations and progress.
- State-local clocks/phase.
- Bounded predicate latches and cooldowns.
- Pose and velocity history required by inertialization/pose matching.
- Stable event cursors.

### Transition arbitration pattern

Evaluate against one immutable parameter snapshot. Select by a deterministic tuple:

1. Required authoritative/domain transition class.
2. Explicit transition priority.
3. Interruption policy and source/destination scope.
4. Specificity or authored tie-break rank.
5. Stable compiled transition ID.

At most a configured bounded number of state changes occur per update. Detect transition cycles during compilation and report runtime budget exhaustion rather than silently looping.

### Transition taxonomy

- **Immediate cut:** teleport, hard camera/representation reset, invalid history, or explicit non-blended semantic discontinuity.
- **Standard crossfade:** outgoing and incoming sources must both continue evaluating; useful when their evolving phases/events/curves matter.
- **Inertialization:** capture outgoing pose/velocity and stop evaluating it; useful for responsive changes and lower transition evaluation cost.
- **Phase/marker crossfade:** synchronize compatible cyclic clips before/during blending.
- **Entry pose selection:** select a starting clip/time from a small authored set using current pose/velocity/contact, then crossfade or inertialize.
- **Motion matching:** query a larger database with trajectory and pose features; reserved for domains that justify the memory/search/content complexity.

### Blend-space pattern

Cook a validated 1D segment list or 2D triangulation:

- Samples have stable IDs, coordinates, phase/contact metadata, and role tags.
- Runtime locates a segment/triangle, calculates barycentric/linear weights, prunes negligible samples, and normalizes deterministically.
- Out-of-domain input follows an explicit clamp, wrap, project-to-hull, or fallback policy.
- Parameter filtering happens once at a declared layer.
- Phase synchronization uses compatible markers or a declared fallback; it does not assume all normalized times mean the same contact.

## 5. Runtime and Content-Pipeline Performance

### Pose-evaluation complexity

Let:

- `A` = active state machines/layers
- `E` = outgoing transitions inspected
- `S` = active blend-space samples
- `B` = required bones
- `L` = pose layers
- `I` = IK/constraint iterations

Control update is approximately `O(A + E)` with compiled contiguous adjacency. Pose work is dominated by clip decompression and blending, approximately `O(S × B + L × B)`, plus hierarchy propagation and constraints. A standard crossfade may evaluate both full source and destination subgraphs; inertialization captures source history and then evaluates only the destination.

### Transition and blend costs

- Bound outgoing predicates per state and compile shared expressions where safe.
- Evaluate cheap/high-rejection predicates before costly derived predicates, while retaining authored deterministic priority.
- Cache parameter-derived values once per snapshot.
- Prune blend samples below a validated weight threshold only if renormalization and event/root policies remain correct.
- Prevent nested crossfades from multiplying pose evaluations; collapse, inertialize, or impose a transition-pose budget.
- Record active source count and evaluated graph nodes, not just final state count.

### Bone counts and masks

- Compile the union of bones needed by active clips, layers, sockets, events, root motion, IK, physics, cloth/hair, shadows, ray tracing, and FP/TP consumers.
- Apply masks before decompression/blending where the codec supports track-selective sampling.
- Precompute per-state and per-transition required masks; transitioning requires the union of both standard-crossfade sources plus downstream consumers.
- Inertialization needs history only for affected bones/curves, not necessarily the entire skeleton.

### Clip decompression, cache behavior, and SIMD

- Store active clip descriptors, times, track masks, and weights in compact arrays.
- Batch sampling by codec, skeleton, and clip residency; keep per-node virtual dispatch out of inner loops.
- Decode rotations/translations/scales into aligned structure-of-arrays pose scratch and blend with SIMD-friendly kernels.
- Reuse decoded samples when multiple layers or sync followers request the same clip/time/mask.
- Maintain always-resident fallback clips for every state/domain; a streaming miss must not leave the state machine without a pose.
- Separate state-control data from large clip/pose buffers so transition traversal remains cache-resident.

### Allocations and scratch

- Runtime update/evaluation performs no heap allocations.
- State instances use fixed-size compiled layouts or generation-checked pooled blocks.
- Transition stacks, blend candidates, sync groups, event records, and pose scratch use bounded per-worker arenas.
- Report overflow with a defined fallback: reduce optional samples/layers or use a reference pose/known fallback, never write beyond capacity.

### Inertialization history

Inertialization requires outgoing pose and velocity estimates:

- Store the last two valid evaluated poses or a pose plus velocity for the affected mask.
- Treat scale and curves according to explicit filter policies.
- Reset history on teleport, skeleton/mesh swap, correction, long visibility gap, LOD mask expansion without seeded bones, ragdoll authority change, and FP/TP representation recreation.
- Apply inertialization before final contact IK so current targets can re-establish constraints, but protect hard contact/action semantics from excessive smoothing.
- Cap translational/angular offsets and decay energy; malformed history must not create explosive motion.

### Blend-space filtering and latency

Movement simulation already filters acceleration/velocity. Additional blend-axis smoothing, sample weight-speed limiting, state hysteresis, transition duration, inertialization, stride warping, and camera smoothing can accumulate into sluggish response.

Maintain one response-budget trace:

- Raw fixed-tick intent.
- Movement-resolved velocity/acceleration.
- Presentation snapshot.
- Filtered blend coordinate.
- State/transition selection time.
- Pose response and visible contact.

Choose a single owner for each kind of filtering and validate step/impulse response.

### IK iterations and contact

- Run final IK after state/blend/inertial pose generation.
- Preserve contact phase/marker state through transitions where applicable.
- Use analytic limb IK for ordinary placement and bounded FBIK only for coupled tasks, following the dedicated IK report.
- Record solver iterations/residual by transition class; a poor transition should not be hidden by persistently expensive IK.
- At lower LOD, reduce or remove IK only after contact-sensitive event/root semantics have been separated.

### Job scheduling

Recommended schedule:

1. Fixed-step gameplay/action snapshot generation.
2. Parallel control update for animation instances using immutable snapshots.
3. Build compact evaluation plans.
4. Batch clip decompression and blend jobs.
5. Hierarchy/constraints/IK jobs.
6. Deterministic commit of pose, sockets, root intent, and event records.

Avoid jobs per transition, state, or bone. Use one costly character per job or batches of inexpensive/shared characters. Control update can be batched densely; pose jobs group by skeleton/codec/LOD.

### Pose sharing

Instances may share a base pose only when their compatibility key includes:

- State-machine program/version.
- State and transition source/destination generations.
- Clip set, times/phases, blend coordinates/weights, sync leader/markers.
- Skeleton/retarget profile and required-bone mask.
- Root-motion and event-source policies.
- LOD and representation class.

Per-instance aim, actions, IK, physical reaction, equipment, and FP presentation normally diverge after the shared base. An active transition can move an instance between buckets; seed history to avoid a pop.

### Animation LOD and visibility throttling

Control semantics and authoritative root/event extraction continue independently of visual pose LOD.

LOD progression can:

- Reduce blend-space samples.
- Replace state-specific transition curves with a standard curve.
- Replace pose matching with authored default entry.
- Shorten or disable presentation-only inertialization.
- Remove additive layers and IK.
- Lower pose update rate/interpolate.
- Join a compatible shared-pose bucket.

Do not change the authoritative action/state generation or event identity because visual LOD changed. When re-enabling a richer LOD, seed state clocks, phase, pose, and inertial history explicitly.

### Networking and fixed-step synchronization

- Replicate or predict authoritative gameplay state, action generation/phase, equipment, aim, movement state, and required targets—not graph state or bone poses.
- Decide authoritative semantic transitions on fixed simulation ticks.
- Presentation state machines consume tick-stamped snapshots and interpolate parameters; render-rate updates must not create different durable events.
- Remote clients reconstruct presentation locally and may use different visual LOD/transition technique while preserving semantic phase and event identity.
- Rollback restores authoritative state/action data. Presentation transitions and inertial history are regenerated or reset by correction generation.
- For actions needing exact alignment, network phase/contact markers or deterministic action time rather than state-machine blend alpha.

### Memory budgets

Budget separately:

- Immutable compiled graph/state/transition tables.
- Per-instance clocks, latches, cooldowns, sync and transition state.
- Active clip descriptors and decompression context.
- Current, previous, and inertial-history poses by required mask.
- Blend and layer scratch.
- Events/curves/root streams.
- FP and TP graph instances and histories.

Inertialization can save outgoing graph evaluation but may require persistent pose/velocity history. Measure the crossover rather than assuming it is always cheaper.

## 6. Pros and Cons

### Compiled state machines plus blend spaces

**Pros**

- Predictable control flow, deterministic arbitration, strong tooling, and low control-state memory.
- Natural separation of discrete modes from continuous movement parameters.
- Easy to validate unreachable states, cycles, ambiguous transitions, and missing fallbacks.

**Cons**

- Flat graphs become combinatorial if orthogonal concerns are encoded as states.
- Authoring many directional/action transitions is expensive.
- Complex interruptions can create nested-source cost and unclear event ownership without strict rules.

### Standard crossfade

**Pros**

- Both sources continue evolving; outgoing events, root, curves, and phase remain observable.
- Simple and intuitive for semantically meaningful exits.

**Cons**

- Often doubles source-pose work during transition.
- Repeated interruption may keep several expensive sources alive unless bounded.

### Inertialization

**Pros**

- Responsive transition from the actual outgoing pose/velocity.
- Source can stop evaluating after capture, reducing transition evaluation cost.
- Works well for frequent unpredictable transitions and dynamic clip selection.

**Cons**

- Outgoing notifies/events stop unless semantics are moved outside the source graph.
- Needs valid pose history and robust reset/clamp rules.
- Can smear contacts or introduce drift if applied after IK or without semantic masks.

### Lightweight entry-pose matching

**Pros**

- Improves entry into one-shots, turns, stops, recovery, and action variants without a full database.
- Bounded search, small memory, and easily constrained by gameplay.

**Cons**

- Requires offline feature data and authored candidate coverage.
- Poor features may select semantically wrong poses.
- Does not solve continuous locomotion as broadly as motion matching.

## 7. ECS Architectural Integration

Recommended components and assets:

- `AnimationProgramAsset`: immutable compiled state machines, blend spaces, layers, masks, and rule version.
- `AnimationControlState`: active states, transition generations, clocks, phase, cooldown/latch storage, program generation.
- `AnimationParameterSnapshot`: tick-stamped typed movement, action, equipment, aim, environment, and presentation inputs.
- `AnimationEvaluationPlan`: compact active clips/times/weights/masks, blend policies, sync data, history requests.
- `AnimationPoseState`: current evaluated pose handle and quality/LOD generation.
- `AnimationHistoryState`: previous pose/time/velocity masks for inertialization and temporal recovery.
- `AnimationSyncState`: group, leader, marker interval, phase, and generation.
- `PresentationActionState`: non-authoritative view of authoritative action ID/generation/phase.
- `AnimationEventCursor`: stable consumption cursor into shared typed event streams.
- `AnimationLODState`: significance, update cadence, required mask, pose-sharing bucket.

System ownership:

- Gameplay/movement/ability systems own authoritative state and fixed-tick transitions.
- The animation control system selects presentation states and produces an evaluation plan.
- Clip sampling/blending systems own pose buffers.
- Constraint/IK/physical systems apply ordered post-process stages.
- The event router owns deduplication and gameplay/presentation routing.
- Rendering owns deformation and previous-rendered-pose history.

Large graph state and pose arrays live in specialized generation-checked pools, not inline in archetype chunks.

## 8. Rig, Pose, Graph, Constraint, and Event Interfaces

### State-machine interface

`CompiledState`

- Stable state ID and semantic tags.
- Pose-program entry index.
- Reset, resume, and re-entry policy.
- Entry candidate set and default fallback.
- Required parameter/bone/curve/history masks.

`CompiledTransition`

- Stable transition ID; source/destination.
- Predicate bytecode span.
- Priority and tie-break rank.
- Interruption scope: none, source, destination, both with explicit ordering.
- Blend type: cut, standard, inertial, phase/marker.
- Duration/curve/per-bone profile.
- Sync and entry-time policy.
- Cooldown, minimum residence, hysteresis.
- Root, curve, contact, and event source policies.

### Blend-space interface

`CompiledBlendSpace`

- Axis semantics, units, bounds, wrap/clamp/project policy.
- Filter owner and response parameters.
- Sorted 1D segments or 2D triangulation.
- Sample clip, coordinate, rate, role, phase/contact markers.
- Degenerate/fallback sample.
- Notify/event source policy.
- Sample pruning and LOD policy.

`BlendSpaceResult`

- Cell/triangle ID and generation.
- Sample IDs, times, phases, normalized weights.
- Extrapolation/clamp flags.
- Missing marker/fallback reason.

### Pose-matching entry interface

`EntryPoseQuery`

- Current semantic state/action generation.
- Selected bone positions/velocities.
- Root velocity/facing and contact mask.
- Candidate-domain tags.
- Desired entry phase or remaining-time constraint.

`EntryPoseResult`

- Clip/time/phase.
- Per-feature cost and total cost.
- Exact deterministic tie-break ID.
- Fallback reason.

### Inertialization interface

`InertialTransitionRequest`

- Transition/state generation.
- Duration and decay policy.
- Bone/curve mask and per-bone profile.
- Captured pose/velocity history generation.
- Offset/velocity clamps.
- Contact and curve exclusions.

`InertialTransitionResult`

- Active elapsed/remaining time.
- Maximum translation/angular offset and velocity.
- Clamp/reset flags.
- History validity and reason.

### Constraint order

Recommended pose order:

1. Base state/blend/entry pose.
2. Standard or inertial transition.
3. Action and additive layers.
4. Root/trajectory/warping presentation corrections.
5. Contact, hand, look/aim, and full-body constraints.
6. Physical/secondary overrides according to the physical-animation contract.
7. Socket and render-palette commit.

Some actions require a different declared order; the compiled graph must make space conversions and ownership explicit.

### Event interface

State enter/exit/transition notifications are presentation diagnostics unless explicitly mapped to a typed proposal. Durable gameplay never depends on a render-rate transition callback.

Each active pose source declares:

- Whether it may emit presentation events.
- Whether it may propose an authoritative semantic event.
- Highest-weight, leader-only, all-sources, or explicit-source policy.
- Stable action/state/source generation.

Inertialization captures pose motion, not future outgoing events. Any required gameplay window, root intent, or durable state must already exist in the fixed-step action/event model.

## 9. Content and Runtime Integration Plan

### Phase 1: Compiler and deterministic control

- Define typed parameters and semantic state/action inputs.
- Compile states, transitions, predicates, priorities, reset/re-entry policies, and adjacency.
- Add deterministic tracing and transition-cycle/static validation.
- Implement immediate cut and bounded standard crossfade.

### Phase 2: Blend spaces and synchronization

- Cook 1D/2D topology, validate hull/duplicates/degenerate triangles, and add explicit out-of-range policy.
- Add compatible phase/contact markers, leader/follower roles, and fallback behavior.
- Measure end-to-end parameter/pose response to remove duplicate smoothing.

### Phase 3: Inertialization

- Add masked pose/velocity history, reset generations, bounded offsets, and per-bone decay profiles.
- Move all required gameplay semantics out of outgoing animation callbacks.
- Apply inertialization before final IK and validate contacts/attachments.

### Phase 4: Entry pose matching and layers

- Add small role-specific candidate sets for stops, turns, landings, actions, traversal entries, and recovery.
- Keep hard gameplay/domain filters before numeric cost.
- Add action/additive layers without exploding base state count.

### Phase 5: LOD, pose sharing, FP/TP, and networking

- Compile LOD fallbacks and compatible pose-sharing keys.
- Drive FP and TP graphs from the same action generation/phase with representation-specific presentation.
- Add rollback/correction history resets and deterministic fixed-step tests.
- Establish platform budgets and regression gates.

## 10. Verification Strategy

### Static graph validation

- No missing/default pose source, invalid destination, unreachable required state, uncontrolled cycle, duplicate stable ID, or ambiguous equal-priority transition without tie-break.
- Predicate reads only declared typed parameters.
- Maximum transition count and nested pose-source budget are provably bounded.
- Re-entry, reset/resume, interruption, root, curve, contact, and event policies are explicit.
- Blend spaces have valid bounds, no duplicate/conflicting samples, valid triangulation, and a deterministic fallback.

### Deterministic transition tests

- Feed identical tick-stamped snapshots under different render rates, worker counts, and job completion order; assert the same semantic state/transition generations and event identities.
- Make multiple rules true simultaneously; verify deterministic priority/tie-break.
- Interrupt at every transition alpha from every allowed scope.
- Test source-to-source, source-to-destination, destination-to-third-state, re-entry, self-transition, and maximum-transition budget exhaustion.
- Test initialization with a non-default state already required.

### Blend and synchronization tests

- Sweep every blend-space axis cell/triangle and boundary; detect weight discontinuity, extrapolation, phase pop, and sample starvation.
- Apply step/ramp/noisy inputs and measure response latency and overshoot.
- Test missing/common markers, different clip lengths, leader changes, reverse playback, and LOD sample pruning.
- Compare foot/contact paths and root velocity across blends.

### Inertialization tests

- Transition from worst-case pose/velocity pairs and record positional/angular offset, decay, energy, and contact error.
- Invalidate history through teleport, rollback correction, long visibility gap, LOD expansion, ragdoll recovery, skeleton/mesh swap, and FP/TP recreation.
- Assert source clips stop evaluating and required gameplay events still occur through the authoritative event model.
- Verify filtered curves and per-bone masks.
- Compare CPU cost and quality against standard crossfade for representative transitions.

### Pose matching tests

- Compare bounded search against brute-force candidate evaluation.
- Inspect per-feature costs and deterministic ties.
- Remove candidates/features in ablation tests.
- Test contact, direction, action/domain, and phase hard filters.
- Require a deterministic authored fallback when all candidates are invalid or unavailable.

### Performance and runtime tests

Record per character/representation:

- States/transitions inspected, predicates executed, and decisions taken.
- Active pose sources, blend samples, decompressed tracks/bytes, evaluated bones, blends.
- Pose cache hits, SIMD/scalar path, allocations, scratch high-water.
- Inertial history bytes, offsets, and resets.
- IK iterations/residual, job queue/worker time, commit tail.
- Pose-sharing bucket and LOD transition.
- Fixed-tick snapshot age, action/state generations, rollback/correction generation.

Test local FP plus world TP, remote crowds, action-heavy combat, rapid interruption, streaming misses, invisible/shadow-only characters, and dedicated-server semantic evaluation.

## 11. Risks and Open Decisions

- Which semantic modes deserve separate state machines versus tags/layers.
- Exact fixed-tick ownership of presentation state transitions versus render interpolation.
- Standard crossfade versus inertialization policy by action class.
- Interruption source/destination priority and maximum transitions per fixed/render update.
- State re-entry reset, resume, phase-match, or pose-match behavior.
- Blend-space axis definitions, triangulation, hull behavior, and filtering owner.
- Marker taxonomy, compatibility, leader policy, and length-sync fallback.
- Contact/root/event source policies during multi-source blends.
- Inertial pose history representation, velocity estimation, clamps, masks, and platform precision.
- Entry pose feature set, candidate counts, thresholds, and content authoring burden.
- How FP and TP graphs phase-lock while using different clips and transition durations.
- Visual LOD transition simplifications permitted for remote proxies.
- Remote correction policy: preserve/inertialize presentation or hard-reset on large semantic divergence.
- Dedicated-server graph subset needed for root intent and typed proposals.

## 12. Engineering Recommendations

1. Compile authoring graphs into immutable contiguous state, transition, predicate, blend-space, mask, and history tables with stable IDs.
2. Keep gameplay/action state authoritative and fixed-step; make animation state machines presentation selectors consuming tick-stamped snapshots.
3. Use state machines for discrete semantic modes, blend spaces for continuous parameters, layers for orthogonal actions, and motion matching only where combinatorial selection justifies it.
4. Define deterministic transition arbitration, interruption scope/order, maximum decisions, re-entry behavior, and stable tie-breaks.
5. Distinguish cuts, standard crossfades, inertialization, phase/marker blends, entry pose matching, and motion matching as separate policies.
6. Use standard crossfade when the outgoing source must continue producing semantic time/events; use inertialization only after required gameplay semantics have moved outside outgoing clip callbacks.
7. Apply inertialization before final IK, retain only required masked pose/velocity history, clamp offsets/energy, and reset by explicit history generation.
8. Compile and validate blend-space triangulation, out-of-domain behavior, phase markers, sample pruning, and a deterministic resident fallback.
9. Assign a single owner for input filtering and trace the full response chain so movement smoothing, blend smoothing, transition duration, and inertialization do not compound unintentionally.
10. Use small, hard-filtered entry-pose candidate sets for actions, stops, turns, landings, and recovery before deploying full motion matching.
11. Build allocation-free evaluation plans, partially decompress required tracks, cache shared samples/base poses, use SIMD-friendly pose buffers, and batch jobs by skeleton/codec/LOD.
12. Key pose sharing on full state/transition/phase/blend/retarget/mask/root/event compatibility, then apply per-instance overlays and IK after the shared base.
13. Simplify visual pose work by LOD without changing authoritative action generation, root/event semantics, or stable identity; seed richer histories on recovery.
14. Replicate authoritative semantic inputs and action phase, not state-machine blend alpha or bones; regenerate/reset presentation after rollback and correction.
15. Ship graph, transition, blend-space, sync-marker, inertial-history, event-source, pose-cost, and response-latency visualizers before scaling content.

## 13. Source Links

1. Epic Games, **State Machines**, Unreal Engine 5.8:  
   https://dev.epicgames.com/documentation/en-us/unreal-engine/state-machines-in-unreal-engine
2. Epic Games, **Transition Rules**, Unreal Engine 5.8:  
   https://dev.epicgames.com/documentation/en-us/unreal-engine/transition-rules-in-unreal-engine
3. Epic Games, **Blend Spaces**, Unreal Engine 5.8:  
   https://dev.epicgames.com/documentation/en-us/unreal-engine/blend-spaces-in-unreal-engine
4. Epic Games, **Animation Sync Groups**, Unreal Engine 5.8:  
   https://dev.epicgames.com/documentation/en-us/unreal-engine/animation-sync-groups-in-unreal-engine
5. Epic Games, **Animation Blueprint Blend Nodes — Inertialization**, Unreal Engine 5.8:  
   https://dev.epicgames.com/documentation/en-us/unreal-engine/animation-blueprint-blend-nodes-in-unreal-engine
6. Epic Games, **Animation Blueprint Node Functions**, Unreal Engine 5.8:  
   https://dev.epicgames.com/documentation/en-us/unreal-engine/animation-blueprint-node-functions-in-unreal-engine
7. David Bollo, **Inertialization: High-Performance Animation Transitions in Gears of War**, GDC 2018:  
   https://www.gdcvault.com/play/1025165/Inertialization-High-Performance-Animation-Transitions
8. David Bollo, **Inertialization presentation slides**, GDC 2018:  
   https://media.gdcvault.com/gdc2018/presentations/bollo_david_inertialization_high_performance.pdf
9. Unity Technologies, **Animation Transitions**:  
   https://docs.unity3d.com/Manual/class-Transition.html
10. Unity Technologies, **Blend Trees**:  
    https://docs.unity3d.com/Manual/class-BlendTree.html

