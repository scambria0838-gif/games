# Operation Mythology Animation & Rigging Research

**Batch timestamp:** 2026-07-27 18:29:16 America/Los_Angeles  
**Subject:** Montage/action-layer arbitration, slot concurrency, partial-body masks, cancellation, and equipment/ability synchronization  
**Scope:** Research and architecture only; modular generic ECS; data-oriented runtime; first-person and third-person support

## 1. Feature Overview

Operation Mythology needs attacks, abilities, reloads, equips, interactions, hit reactions, traversal, locomotion, aiming, and facial/camera presentation to coexist without turning the animation graph into a second gameplay scheduler.

The recommended design is an **Action Presentation Scheduler**. Authoritative gameplay creates a versioned action instance with fixed-tick phase and cancellation state. Presentation then admits one or more animation requests into named channels and body regions:

- Full body.
- Lower-body locomotion/root.
- Upper body.
- Left arm/hand and right arm/hand.
- Head/look/face.
- Additive aim/recoil/reaction.
- First-person arms/weapon.
- World third-person body.

Requests declare priority, exclusivity, masks, blend policy, root/event ownership, dependencies, and cancellation behavior. The scheduler resolves conflicts deterministically, then produces a bounded layered-pose plan. A montage or clip section is a presentation mapping for an action phase; it is not the durable authority for damage, ammo, inventory, cooldown, or interaction state.

## 2. Existing Coverage and Identified Gap

The required recursive scan found:

- A compiled state-machine/blend-space/inertialization architecture.
- Typed point/window events, fixed-step crossing, rollback journals, and event deduplication.
- Root-motion authority, motion warping, full-body IK, equipment grip profiles, FP/TP dual representations, physical animation, motion matching, compression, validation, LOD, pose sharing, and job scheduling.
- A gameplay ability model in the shared research that owns activation, costs, prediction, cancellation, and durable state.

The uncovered gap was concurrent action presentation:

- How an ability, equipment action, hit reaction, and locomotion compete for the same bones.
- Whether “slots” are just graph inputs or gameplay locks.
- How partial-body masks, additive layers, and per-bone blend profiles compose.
- Which source owns root motion, curves, contacts, sockets, and events when several action clips play.
- How cancellation, replacement, combo branching, section jumps, and interruption remain fixed-step and rollback safe.
- How FP and TP variants remain phase-aligned without requiring the same clip or graph.
- How to avoid duplicated clip decompression, blend work, allocations, and event emission as layers multiply.

This report resolves those interfaces without repeating the prior event or state-machine reports.

## 3. Sourced Facts

### Official engine facts

- Unreal Engine 5.8 Animation Montages combine sequences, expose named sections that can be selected dynamically, and organize sequence tracks into Slots and Slot Groups. Epic states that sequences in the same Slot and Slot Group override other playback when triggered, while different slot groups can drive separate body regions. [Epic Games, Animation Montage]
- Unreal’s montage documentation advises against overlapping sequences in the same slot and notes that multiple slots work best when their end-to-end timing matches. [Epic Games, Animation Montage]
- Unreal’s montage editor integrates Slot nodes into the animation graph, supports section ordering/jumps, and links notifies to montage or sequence timing with absolute, relative, or proportional behavior. [Epic Games, Animation Montage Editor]
- Unreal’s Layered Blend per Bone can combine multiple poses using branch filters or blend masks and can select local- or mesh-space rotation/scale blending. [Epic Games, Animation Blueprint Blend Nodes]
- Epic’s layered-animation example combines locomotion with an upper-body firing montage by placing a slot above a per-bone layer beginning at the spine. [Epic Games, Using Layered Animations]
- Unreal Gameplay Abilities support asynchronous multi-stage execution, activation blocking/cancellation through tags, client prediction/networking, and animation through montage-oriented Ability Tasks. Ability Tasks terminate no later than the ability that owns them. [Epic Games, Gameplay Abilities and Ability Tasks]
- Unreal Montage Notifies can use branching points, which Epic describes as more precise, synchronous, and more expensive than queued ticking. [Epic Games, Animation Notifies]
- Unity 6 Animation Layers support override or additive blending, body masks, synchronized layer state machines with different clips, and timing adjustment between synchronized layers. [Unity Technologies, Animation Layers]
- Unity Avatar Masks can include/exclude humanoid body regions or individual transform hierarchies and can include/exclude hand and foot IK curves. Unity notes that removing unused curves can reduce memory and CPU work. [Unity Technologies, Avatar Mask]
- The GDC Animation Bootcamp presentation *Using the Power of Layered Animation Systems to Make Games That Move* discusses layered gameplay animation including firing, melee, reload, and full-body versus partial-body choices. [Ryan Duffin, GDC 2014]

### Consequences supported by the sources

- Slots, groups, masks, override layers, and additive layers are established patterns for concurrent body-region animation.
- Montage sections are useful presentation control points, but gameplay abilities already have their own activation, cancellation, and asynchronous lifetime.
- Precise synchronous animation callbacks have a higher cost and should be reserved for cases that need them.
- Layer timing and mask policy must be explicit when different clips or body regions run together.

### Engineering recommendations versus sourced facts

The channel taxonomy, admission/preemption algorithm, lock schema, action-phase mapping, cancellation generations, root/event arbitration, ECS components, budgets, and validation plan below are Operation Mythology engineering recommendations. They are not descriptions of a specific engine’s internal implementation.

## 4. Industry-Standard Animation API or Pattern

### Separate ability execution from presentation playback

Use two linked lifetimes:

1. **Authoritative action instance**
   - Stable entity/action ID and generation.
   - Fixed-tick phase, permissions, costs, ownership changes, targets, cancellation state, and durable outcomes.
   - Replicated/predicted according to the networking contract.

2. **Presentation action instance**
   - Representation-specific montage/clip/section mapping.
   - Requested slots/body regions, mask, blend, sync, root, event, and IK policy.
   - May be replaced, simplified, delayed, or omitted without losing durable gameplay truth.

A presentation ending may propose completion only for action classes that explicitly allow it. Most action completion should follow authoritative phase/duration/condition state, with animation reporting visual completion separately.

### Resource-admission pattern

Every presentation request declares:

- `ActionKey` and generation.
- Channel set and body-region mask.
- Priority class and stable tie-break.
- Exclusive, shared-additive, or compatible-override access.
- Minimum residence and preemption policy.
- Start policy: immediate, phase-aligned, marker-aligned, next safe point, or reject.
- Exit policy: cut, crossfade, inertialize, finish protected window, or replacement handoff.
- Root, curve, contact, socket, and event source policies.
- FP/TP variant and semantic phase map.

The scheduler evaluates requests from one immutable fixed/render snapshot and returns `Admitted`, `Queued`, `Rejected`, `Preempting`, or `Replacing`. Admission is deterministic and bounded.

### Recommended channel classes

- `BaseLocomotion`: ordinarily exclusive base pose owner.
- `FullBodyAction`: exclusive override of most body regions and possible root-motion intent.
- `UpperBodyAction`: weapon fire/reload/use while locomotion continues.
- `LeftArmAction` / `RightArmAction`: interactions or equipment-specific independent actions.
- `HeadFaceAction`: look, facial pose, dialogue, or helmet interaction.
- `AdditiveAim`, `AdditiveReaction`, `AdditiveStyle`: compatible weighted layers with declared ordering.
- `ProceduralConstraint`: post-layer targets rather than authored-pose ownership.
- `FirstPersonAction`: owner camera rig.
- `WorldAction`: world full-body representation.

Channels are not arbitrary strings. They compile to stable indices, compatibility tables, and required masks.

### Layer composition pattern

Recommended order:

1. Base locomotion/world state.
2. Full-body authoritative-action presentation when admitted.
3. Partial-body override layers.
4. Additive style/aim/recoil/reaction layers.
5. Root/trajectory/warp corrections.
6. Hands, feet, look, interaction, and full-body constraints.
7. Physical/secondary animation.
8. Socket and palette commit.

Per-action profiles may override this order only through validated graph templates.

### Section and combo pattern

Map authoritative semantic phases to presentation segments:

- `Anticipation`
- `Commit`
- `Active`
- `Recovery`
- `Loop`
- `Exit`

Clip/montage sections can branch among variants, loops, or combo continuations, but the branch is selected from the authoritative action generation and accepted input/target state. A section name or local playback callback does not grant damage, spend ammo, or transfer ownership.

## 5. Runtime and Content-Pipeline Performance

### Pose-evaluation and blend complexity

Let:

- `R` = active admitted requests.
- `S` = total active clip sources across layers.
- `B` = required bones.
- `L` = layers.
- `I` = constraint iterations.

Naive pose work is approximately `O(S × B + L × B + I × B_affected)`. Layer count can multiply decompression and blend cost even when masks touch few bones.

Controls:

- Bound concurrent override and additive layers per representation.
- Compile masks into track spans/bitsets and decompress only affected tracks plus parent closure.
- Merge compatible additive requests offline or into one runtime accumulation pass.
- Reject or downgrade redundant layers before pose evaluation.
- Prevent a full-body action and upper-body duplicate from both sampling the same source.
- Cache shared base and repeated clip/time/mask samples.

### Bone counts and mask closure

A partial-body mask must include:

- The intended deformation bones.
- Parent transforms required to evaluate them.
- Required twist/helper bones.
- Sockets, weapons, IK targets, physics drivers, cloth/hair drivers, and facial curves as declared.

The visual blend mask and the evaluation-required mask are different: the latter may include parents and consumers whose pose is not directly overwritten.

Use soft boundary bands for spine/shoulder/neck transitions where a hard mask produces seams. Compile per-bone weights and blend-space choice rather than walking branch filters each frame.

### Clip decompression and cache behavior

- Store active action sources in compact arrays sorted by skeleton/codec/clip.
- Decode only active time samples and required tracks.
- Keep frequently used combat/equipment actions resident with deterministic fallback clips.
- Batch FP and TP sampling when they share a clip/time/subset, but do not force sharing when content differs.
- Keep channel/arbitration tables hot and separate from clip bulk data.
- Reuse decoded action poses across compatible remote characters only when action generation/phase, skeleton, retarget profile, mask, equipment variant, and LOD match.

### SIMD and blending

- Use aligned structure-of-arrays transforms.
- Accumulate override and additive layers in a precompiled order.
- Renormalize quaternion/weight results under the selected blend formulation.
- Batch contiguous bone spans with equal masks/weights.
- Avoid per-bone virtual dispatch and string-based slot lookup.
- Provide scalar reference differential tests for SIMD kernels.

### Allocations and lifetime

- Requests enter through bounded command buffers.
- Scheduler instances use fixed/pooled channel state, queue slots, and action records.
- Pose scratch and event output use per-worker arenas.
- Cancellation and preemption change generations; they do not allocate callback objects.
- Every async presentation task is owned by an action generation and is retired automatically when that generation ends.
- Overflow produces a typed reject/downgrade result and telemetry, never silent loss of a gameplay-authoritative action.

### Standard blends, inertialization, and cancellation

- Standard crossfade evaluates outgoing and incoming sources and can preserve outgoing presentation events.
- Inertialization captures outgoing pose/velocity then stops outgoing evaluation, reducing source cost but eliminating future outgoing callbacks.
- Cancellation policies must account for protected gameplay windows independently from visual blend-out.
- Rapid replacement can create nested source evaluation; cap active blend sources and collapse history into an inertial handoff where permitted.
- Cancelled FP and TP variants share the same action cancellation generation even if their visual exit durations differ.

### Root motion

At most one admitted source supplies authoritative root-motion intent for a character at a fixed tick. Other layers may provide:

- No root.
- Presentation-only root offset.
- Additive orientation/lean.
- A bounded proposal routed to the action/movement contract.

Partial-body layers never implicitly contribute root motion. If a full-body action loses root authority through cancellation or collision truncation, the movement system reports the accepted path and presentation blends/warps to it.

### IK iterations and constraints

- Layer masks and weapon variants produce targets; IK solves after final authored layering.
- A support-hand layer must not simultaneously overwrite the same arm that post-layer IK is expected to solve unless the profile declares the order.
- Use analytic two-bone constraints for ordinary hand placement and bounded FBIK for coupled interactions.
- Track residual/iterations by action and layer combination.
- LOD may replace hand IK with baked offsets or remove fingers, but authoritative interaction validity is unaffected.

### Job scheduling

Recommended jobs:

1. Fixed-step action/ability update and presentation request emission.
2. Deterministic request merge and channel admission per entity.
3. Parallel evaluation-plan construction.
4. Batched decompression of active sources.
5. Layer blending and hierarchy jobs.
6. Constraint/IK/physical jobs.
7. Deterministic event/socket/palette commit.

Admission is usually small and branchy; keep it as a compact per-entity or batched control job. Decompression/blending are the heavy parallel stages. Do not create a job per layer or bone.

### Pose sharing and animation LOD

Pose sharing requires compatibility across:

- Action and cancellation generation.
- Semantic phase and section/clip time.
- Channel admission set and priorities.
- Mask/layer order.
- Skeleton/retarget/equipment variant.
- Root and event policies.
- LOD and representation.

Share the base pose before per-instance aim, reaction, equipment, IK, and physics.

LOD can:

- Replace hand-specific layers with an upper-body combined clip.
- Remove fingers/face/additive style.
- Reduce blend sources and IK.
- Use a generic action variant.
- Lower pose update rate or join a shared bucket.

It cannot suppress authoritative phase, root intent, durable events, or equipment ownership.

### FP and TP performance

The owning character may evaluate:

- FP arms/weapon action.
- World TP body for shadows/reflections/spectators.
- Shared authoritative action timeline.

Avoid duplicating control/admission work: resolve the semantic request set once, then map to representation-specific clips/masks. Pose/decompression remains separate where the rigs or clips differ. Each representation keeps its own blend/inertial/render history.

### Networking and fixed-step synchronization

- Replicate/predict action ID/generation, phase, cancellation/replacement generation, equipment state, targets, and root-motion parameters.
- Do not replicate local slot weights, mask weights, montage handles, or bone poses.
- The server validates ability/action transitions and durable outcomes.
- Clients may start speculative FP/TP presentation using the side-effect journal, then confirm, cancel/fade, or replace.
- Remote clients reconstruct world action layers from semantic state and may use a cheaper visual variant.
- Section/clip time is derived from authoritative phase mapping and corrected within bounded presentation policy.
- Rollback restores action/equipment state and invalidates presentation commands/history by generation.

### Memory budgets

Budget:

- Compiled channel, compatibility, priority, mask, layer, and action-profile tables.
- Per-instance admitted/queued requests and generations.
- FP and TP presentation states.
- Active clip descriptors and compressed residency.
- Pose/blend/inertial scratch.
- Event/curve/root streams.
- Equipment grip/attachment profiles.

Track worst-case combat combinations rather than the average locomotion case.

## 6. Pros and Cons

### Explicit action-presentation scheduler

**Pros**

- Deterministic ownership of body regions, root motion, and event sources.
- Separates ability correctness from clip/montage playback.
- Supports cancellation, networking, FP/TP variants, LOD, and telemetry cleanly.
- Prevents hidden graph ordering from deciding gameplay presentation.

**Cons**

- Adds schemas and authoring metadata.
- Requires careful priority/compatibility design.
- Poor channel taxonomy can become as complex as a flat state machine.

### Slot/group convention only

**Pros**

- Familiar author workflow and simple graph integration.

**Cons**

- Slot names alone do not define gameplay locks, cancellation, root authority, or cross-representation behavior.
- Conflicts can resolve by accidental playback order.

### Partial-body overrides

**Pros**

- Preserves locomotion while firing, reloading, gesturing, or interacting.
- Can reduce content count versus full-body variants.

**Cons**

- Mask seams, shoulder/spine mismatch, weapon drift, and conflicting IK.
- Multiple layers increase decompression/blending and reduce pose-sharing opportunities.

### Additive actions

**Pros**

- Efficient composition for aim, recoil, reactions, and style variations.

**Cons**

- Depend on correct base/reference pose and declared space.
- Large or stacked additives can distort contacts and joint limits.

## 7. ECS Architectural Integration

Recommended assets/components:

- `ActionInstance`: authoritative ID, generation, fixed-tick phase, target, cancel/replace generation, durable state.
- `PresentationActionProfile`: representation variants, phase-to-clip/section map, requested channels, masks, blend/root/event/IK policies.
- `AnimationChannelRegistry`: compiled stable channel IDs and compatibility matrix.
- `AnimationRequestBuffer`: bounded tick-stamped requests from abilities, equipment, reactions, interactions, and presentation systems.
- `AnimationAdmissionState`: admitted, queued, preempting, and replacement records by channel.
- `LayerEvaluationPlan`: ordered clip sources, times, weights, masks, root/event source selectors.
- `EquipmentPresentationState`: durable equipment generation plus visual attachment/grip phase.
- `RepresentationActionState`: FP or world variant, clip/section time, blend and history generation.
- `PresentationEventCursor`: stable typed event consumption.
- `AnimationLODState`: layer/source/IK budget and pose-sharing key.

System boundaries:

- Ability/combat/equipment systems own authoritative lifetimes and outcomes.
- The presentation request system maps authoritative state to candidate actions.
- The admission scheduler owns visual channel conflicts.
- The pose system owns sampling and layering.
- The root-motion bridge owns the one selected root-intent proposal.
- The event router owns typed proposal/presentation routing and deduplication.
- Attachment/IK systems own final weapon/hand placement.

Full pose arrays and variable-size action data remain in specialized pools addressed by generation-checked handles.

## 8. Rig, Pose, Graph, Constraint, and Event Interfaces

### Action presentation request

`ActionPresentationRequest`

- Entity, action ID, action generation, request ID.
- Fixed tick and semantic phase.
- Representation set: FP, world, remote proxy, spectator/replay.
- Channel bitset and weighted body mask.
- Priority class, stable tie-break, minimum residence.
- Access mode: exclusive, override-compatible, additive-compatible.
- Start, preemption, cancellation, and fallback policies.
- Root, curve, contact, event, and constraint policies.
- Profile and equipment-generation handles.

### Admission result

`ActionAdmissionResult`

- Request/action generations.
- Status and reason.
- Granted channels and effective mask.
- Preempted/replaced request IDs.
- Scheduled start tick/phase.
- Blend/handoff policy.
- Root/event source changes.

### Layer plan

`LayerEvaluationPlan`

- Base pose handle.
- Ordered source descriptors: clip, time/phase, weight, blend mode, mask.
- Representation and skeleton/retarget versions.
- Root source index.
- Curve blend policy by semantic curve.
- Event source policy.
- Constraint target-generation span.
- Required bone/curve/history masks.
- LOD and fallback flags.

### Mask interface

`CompiledBodyMask`

- Stable semantic mask ID and skeleton version.
- Per-bone override/additive weight.
- Required parent/twist/helper closure.
- Socket, IK, physics, cloth/hair, and face consumer flags.
- Local/mesh-space rotation and scale blend policy.
- LOD fallback masks.

### Equipment interface

`EquipmentActionBinding`

- Durable equipment item/generation.
- Handedness and grip profile.
- Action-profile variant set.
- Attachment parent by phase.
- Sight, muzzle, magazine, casing, primary/support grip semantics.
- Allowed FP/TP timing offsets and mandatory phase markers.

Attachment changes are durable equipment state or a validated fixed-tick action transition. Clip markers may propose or present them but do not independently transfer ownership.

### Event interface

Every typed event declares:

- Authority: gameplay, proposal, or presentation only.
- Action/generation/occurrence identity.
- Source policy: authoritative timeline, selected root source, selected layer, leader/highest weight, or representation-specific presentation.
- Cancellation behavior: retain durable state, suppress, cancel/fade, or replace.
- FP/TP deduplication key.

Montage/state enter/exit/section events are diagnostics/presentation unless mapped into the typed schema. Arbitrary callbacks never mutate gameplay from pose jobs.

## 9. Content and Runtime Integration Plan

### Phase 1: Channel and ownership contract

- Define stable channel/body-region taxonomy and compatibility matrix.
- Define action priority classes, admission status, and preemption/cancellation policy.
- Define one root source and typed event source rules.
- Map existing ability/equipment actions to semantic phases independent of clips.

### Phase 2: Basic layered runtime

- Implement base locomotion plus one full-body and one upper-body override channel.
- Compile weighted masks and required-bone closure.
- Add bounded standard/inertial handoffs and deterministic request admission.
- Validate no allocation and stable ordering.

### Phase 3: Equipment and FP/TP variants

- Add equipment-generation and grip/attachment phase contracts.
- Map one authoritative action to FP and world presentation variants.
- Validate reload/equip/fire/interact across both representations, shadows, spectators, and replay.

### Phase 4: Additives, independent limbs, and constraints

- Add ordered aim/recoil/reaction layers and one-arm channels only where content requires them.
- Solve support hands and interactions after layering.
- Add mask seam and curve/root/event validation.

### Phase 5: Networking, rollback, LOD, and scale

- Add speculative request journal operations and generation-based correction.
- Add remote generic variants, layer/IK LOD, pose-sharing buckets, and update throttling.
- Establish worst-case combat budgets and automated regression tests.

## 10. Verification Strategy

### Static content checks

- Every action profile references valid channels, masks, representations, clips/sections, skeletons, equipment variants, and fallbacks.
- Compatibility matrix is symmetric where required and has deterministic conflict resolution.
- Masks contain required parent/twist/socket/IK closure and valid LOD fallback.
- Only allowed profiles request root authority.
- Event/curve/contact source policies are explicit.
- FP/TP variants map all mandatory semantic phases and equipment attachment points.

### Arbitration tests

- Submit every pair and bounded combination of request classes at identical and differing ticks.
- Verify priority, stable tie-break, minimum residence, queue, preemption, rejection, replacement, and overflow behavior.
- Cancel/replace during anticipation, commit, active, recovery, loop, and exit.
- Exercise rapid fire/reload/equip/hit/interact conflicts and assert one durable action outcome.

### Layer and mask tests

- Render every layer/mask boundary over representative locomotion and body proportions.
- Measure discontinuity at spine, clavicle, neck, wrist, pelvis, and twist chains.
- Compare local- versus mesh-space rotation policies.
- Stack maximum supported overrides/additives and verify normalization, joint limits, root stability, sockets, and contacts.
- Confirm unused tracks are not decompressed and LOD masks retain consumers.

### Ability, event, and equipment tests

- Assert damage, ammo, cooldown, ownership, attachment, and interaction state remain correct when presentation is missing, delayed, interrupted, invisible, or reduced by LOD.
- Cross all event windows with skipped render updates, time dilation, loop, reverse/seek policy, rollback, and correction.
- Verify stable event deduplication across FP and TP.
- Interrupt ability tasks and assert all presentation tasks retire with their action generation.

### Root, IK, and networking tests

- Ensure exactly one root-intent source per fixed tick.
- Collision-truncate or reject root motion and validate presentation reconciliation.
- Measure hand/grip/weapon residual and IK iterations for every equipment/action/layer combination.
- Replay identical authoritative snapshots under different render rates and remote LODs.
- Simulate prediction accept/reject, replacement, late equipment updates, and action-phase correction.

### Performance tests

Record:

- Requests submitted/admitted/queued/rejected/preempted.
- Active channels/layers/sources and mask bone counts.
- Decompressed tracks/bytes, blend operations, evaluated bones, cache hits.
- Allocations, scratch high-water, SIMD/scalar path, job time/occupancy.
- IK iterations/residual, pose-sharing bucket, LOD.
- FP/TP duplicate versus shared control/sampling work.
- Action, cancellation, equipment, root, and event generations.

Stress local FP plus shadow/world body, remote crowds, maximum combat layering, and rapid cancellation.

## 11. Risks and Open Decisions

- Final channel/body-region taxonomy and maximum concurrent layers.
- Priority classes, tie-break ownership, queue limits, and minimum residence.
- Whether one-arm independent channels justify their content and mask complexity.
- Which actions are full body versus upper body by stance, weapon, and movement mode.
- Standard crossfade versus inertial exit by cancellation reason and action phase.
- Protected action windows and visual cancellation freedom.
- Root-motion eligibility and collision-truncation response by action.
- Weighted mask boundaries, mesh/local rotation blend, and twist/helper policy.
- Curve blending for aim, facial, material, morph, IK, and gameplay-proposal curves.
- FP/TP allowed timing divergence and spectator/replay variant selection.
- Equipment attachment authority and the exact fixed-tick phase for hand/world/socket transfer.
- Remote generic variant and pose-sharing policy.
- Dedicated-server subset required for root intent and typed proposals.

## 12. Engineering Recommendations

1. Introduce an explicit Action Presentation Scheduler between authoritative abilities/actions and animation pose evaluation.
2. Treat slots/channels as compiled presentation resources with compatibility, priority, access, preemption, root, event, and fallback policy—not arbitrary names.
3. Keep ability/action generation, phase, costs, cancellation, equipment ownership, and durable outcomes authoritative and fixed-step.
4. Map semantic phases to representation-specific clips/montage sections; never let a section callback alone grant damage, ammo, ownership, or completion.
5. Permit exactly one authoritative root-intent source per character/tick and make partial-body layers root-free by default.
6. Compile weighted masks and required parent/twist/socket/IK/physics/cloth/face closure; decompress and blend only required tracks.
7. Bound simultaneous override/additive sources, merge compatible additives, cache repeated samples/base poses, and make runtime scheduling allocation-free.
8. Use deterministic admission ordering, cancellation generations, bounded queues, and typed reject/downgrade results.
9. Distinguish standard crossfade from inertialization: retain the outgoing source only when its evolving semantics are actually required.
10. Solve weapon hands, contacts, look, and interactions after authored layer composition with measured residual and iteration budgets.
11. Resolve semantic requests once, then map to FP and TP variants; share control state while retaining separate pose/history where content differs.
12. Replicate/predict action, phase, cancellation, equipment, target, and root parameters rather than montage handles, slot weights, or bones.
13. Apply visual layer/IK/clip LOD and pose sharing without suppressing authoritative phase, root intent, or durable events.
14. Build arbitration, layer-stack, mask-weight, root-source, event-source, equipment-phase, FP/TP-phase, pose-cost, and cancellation-history visualizers.
15. Gate content with exhaustive pairwise arbitration, mask seam, equipment, event, root, rollback, and worst-case performance tests.

## 13. Source Links

1. Epic Games, **Animation Montage**, Unreal Engine 5.8:  
   https://dev.epicgames.com/documentation/en-us/unreal-engine/animation-montage-in-unreal-engine
2. Epic Games, **Animation Montage Editor**, Unreal Engine 5.8:  
   https://dev.epicgames.com/documentation/en-us/unreal-engine/animation-montage-editor-in-unreal-engine
3. Epic Games, **Animation Blueprint Blend Nodes**, Unreal Engine 5.8:  
   https://dev.epicgames.com/documentation/en-us/unreal-engine/animation-blueprint-blend-nodes-in-unreal-engine
4. Epic Games, **Using Layered Animations**, Unreal Engine 5.8:  
   https://dev.epicgames.com/documentation/en-us/unreal-engine/using-layered-animations-in-unreal-engine
5. Epic Games, **Animation Notifies**, Unreal Engine 5.8:  
   https://dev.epicgames.com/documentation/en-us/unreal-engine/animation-notifies-in-unreal-engine
6. Epic Games, **Using Gameplay Abilities**, Unreal Engine 5.8:  
   https://dev.epicgames.com/documentation/en-us/unreal-engine/using-gameplay-abilities-in-unreal-engine
7. Epic Games, **Gameplay Ability Tasks**, Unreal Engine 5.8:  
   https://dev.epicgames.com/documentation/en-us/unreal-engine/gameplay-ability-tasks-in-unreal-engine
8. Unity Technologies, **Animation Layers**, Unity 6:  
   https://docs.unity3d.com/Manual/AnimationLayers.html
9. Unity Technologies, **Avatar Mask**, Unity 6:  
   https://docs.unity3d.com/Manual/class-AvatarMask.html
10. Ryan Duffin, **Using the Power of Layered Animation Systems to Make Games That Move**, GDC Animation Bootcamp 2014:  
    https://media.gdcvault.com/GDC2014/Presentations/Duffin_Ryan_Animation_Bootcamp_Using.pdf

