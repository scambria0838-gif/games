# Operation Mythology Animation & Rigging Research

**Batch timestamp:** 2026-07-27 03:00:51 America/Los_Angeles  
**Subject:** First-person and third-person rig compatibility, weapon alignment, shadows, spectators, and body awareness  
**Scope:** Research and architecture only; modular generic ECS; data-oriented runtime; first-person and third-person presentation

## 1. Feature Overview

Operation Mythology needs one gameplay character to remain coherent across an owner’s first-person view, third-person play, remote clients, spectators, replays, shadows, reflections, and ray-traced representations. These views have incompatible presentation pressures:

- First-person hands and held objects must remain legible at a configurable field of view, avoid near-plane and environment clipping, preserve aim-down-sights alignment, and minimize camera discomfort.
- The world character must preserve believable anatomy, contacts, locomotion, equipment placement, silhouettes, shadows, reflections, and externally observed action timing.
- Gameplay, networking, damage, inventory, and ability state must not fork merely because two visual representations exist.

The proposed baseline is a hybrid dual-representation system. A world-space full body is the canonical external representation. The owning view may add an owner-only first-person arms/weapon rig or apply a first-person projection/deformation path. Both consume the same authoritative action, equipment, aim, and phase state, while their presentation graphs and authored clips may differ.

## 2. Existing Coverage and Identified Gap

The recursive scan of `C:\Users\steve\Desktop\GAME SKILLS` and `C:\Users\steve\Desktop\EXTRA SKILS\Animation & Rigging` found existing coverage for:

- A fixed-tick character controller shared by first- and third-person modes.
- Separation of camera/input policy from authoritative collision and movement.
- Root-motion consumption through fixed-tick collision constraints.
- Typed animation events, rollback-safe action phases, motion matching, full-body IK, physical animation, pose sharing, and deformation performance.

The uncovered gap was the presentation contract connecting those systems:

- Whether first- and third-person views should share a mesh, skeleton, pose, graph, or clips.
- Which representation owns weapon, muzzle, sight, hand, camera, and attachment transforms.
- How owner visibility, self-shadowing, reflections, ray tracing, spectators, replays, and remote clients obtain a valid world pose.
- How to keep two graphs from duplicating authoritative events or doubling all pose/decompression/skinning work.
- How body awareness and aim-down-sights calibration should be validated across camera FOV, aspect ratio, equipment, and animation.

This report addresses that gap without repeating the already documented controller, rollback, event, IK, or generic pose-sharing designs.

## 3. Sourced Facts

### Official engine and tool facts

- Unreal Engine 5.8’s First Person Rendering supports per-primitive first-person FOV and scale, and identifies primitives as first-person or as a world-space representation. The world-space representation is not rendered normally to the owning first-person camera, but remains available for other views and features such as shadows and hardware ray tracing. Epic also notes that first-person transformed geometry is not suitable as the representation for scene shadows, reflections, or other players. [Epic Games, First Person Rendering]
- Epic’s first-person character tutorial uses separate first-person and third-person skeletal meshes, owner-only visibility rules, independent animations, sockets for attachments, and hidden-shadow support for the third-person mesh. [Epic Games, Adding a First-Person Camera, Mesh, and Animation]
- Epic’s character setup documentation describes floating arms as a common first-person setup and notes that a full body may still be needed for shadows. [Epic Games, Setting Up a Character]
- Unreal Aim Offsets are additive blend spaces applied to a base pose. Epic requires mesh-space additive samples so aiming remains consistent when preceding bones are oriented differently, and recommends limiting problematic yaw extremes during locomotion. [Epic Games, Aim Offset]
- Unity Animation Rigging’s Two Bone IK constraint defines a root, mid, tip, target, optional bend hint, and a continuously weighted constraint. This is a representative portable pattern for placing a hand on a weapon while retaining authored bend direction. [Unity Technologies, Two Bone IK Constraint]
- GDC’s *The Challenges of Designing First-Person Melee Combat* identifies conflicts between hands, shields, and the body and describes contact attacks as needing coordinated animation/camera control. [Arkane Studios/GDC 2007]
- GDC’s *Giving Purpose to First-Person Animation* treats first-person animation as a gameplay communication surface rather than merely a world animation viewed from the head. [GDC Animation Bootcamp 2013]

### Consequences supported by those facts

- A camera-optimized first-person pose cannot safely be assumed to be a truthful world pose.
- A project that transforms or hides the owner’s first-person geometry still needs an externally valid full-body representation.
- Separate presentation clips are compatible with shared action state; the animations may differ while the action phase remains common.
- Weapon-hand alignment fits a target-and-hint constraint contract, while broad aiming fits an additive aim-space contract.

### Not sourced facts

The concrete ECS components, transform authority hierarchy, performance budgets, event ownership rules, and rollout stages below are engineering recommendations for Operation Mythology. They are not claims about a particular engine implementation.

## 4. Industry-Standard Animation API or Pattern

### Recommended representation pattern

Use one simulation identity with two optional presentation instances:

1. **World representation:** complete body, canonical equipment attachments, third-person locomotion and actions, remote/spectator/replay output, scene shadows, reflections, and ray tracing.
2. **Owner first-person representation:** arms/hands and weapon, or a selected full-body subset, optimized for the owning camera. It may use first-person FOV/scale, camera-space offsets, exaggerated readability, and different clips.

The instances share semantic inputs, not necessarily pose buffers:

- `ActionId`, action generation, normalized/quantized phase, stance, locomotion state, aim direction, recoil impulses, equipment identity, grip profile, and presentation tags.
- Stable event identities from the shared action timeline.
- Common skeleton semantics such as hand, wrist, forearm, weapon, sight, muzzle, camera anchor, and interaction points.

### Transform authority hierarchy

Use an explicit hierarchy instead of circular hand/weapon constraints:

- Gameplay aim supplies an authoritative ray or direction.
- The world character root and equipment state supply the canonical world transform domain.
- Each presentation profile solves a weapon presentation transform from the aim target and profile calibration.
- The primary hand or weapon root is selected as the authored driver for that profile.
- The support hand follows a weapon grip socket through two-bone IK or bounded full-body IK.
- Muzzle flash, casing, magazine, and effect transforms come from named weapon sockets, while gameplay hit validation uses the authoritative aim/ballistic contract.

Do not simultaneously constrain the weapon to both hands while constraining both hands back to the weapon. Choose a directed solve order.

### Camera and body-awareness pattern

The camera follows a filtered camera anchor derived from simulation orientation and presentation offsets; it is not a direct child of the raw animated head. Authored camera impulses are separate channels with explicit amplitude and comfort limits.

For body awareness:

- Render world legs/torso where they remain valid, possibly with per-vertex interpolation between world and first-person transforms.
- Hide or clip geometry that enters the near plane or occludes the view.
- Keep the world representation intact for all non-owner views.
- Treat mirrors, photo mode, replay, kill camera, and spectators as world-view consumers unless a feature explicitly requests the recorded owner camera.

## 5. Runtime and Content-Pipeline Performance

### Pose-evaluation and blend cost

The dangerous default is evaluating two full graphs, decompressing two complete clip sets, solving two constraint stacks, and skinning two full skeletons for the local player. Cost grows approximately with the number of evaluated bones per sampled/blended pose, plus graph nodes, decompression tracks, constraint work, and deformation vertices.

Recommended controls:

- Evaluate the owner first-person graph only for visible arms, hands, fingers, weapon helpers, and required parent chains.
- Share immutable semantic parameters and, where compatible, a cached base pose; do not force pose sharing when first-person timing or topology intentionally differs.
- Use bone masks before expensive layers so excluded tracks are not decompressed or blended.
- Cache locomotion/base poses reused by world upper-body, aim, and additive layers.
- Schedule world and first-person pose jobs in parallel after the shared action snapshot is published, then join before socket consumers and rendering.
- Maintain bounded, frame-owned pose and event buffers; prohibit graph-time heap allocations.

### Bone counts, clips, decompression, cache, and SIMD

- Establish separate evaluated-bone budgets for owner first-person, local world body, remote near, remote far, and shadow-only cases.
- Cook semantic track masks so first-person clips do not carry unused lower-body tracks and third-person clips do not accidentally include editor/helper bones.
- Group hot transforms in structure-of-arrays or SIMD-friendly blocks and keep skeleton-to-palette remaps contiguous.
- Decompress only requested tracks and samples; reuse the same decoded sample within layers when graph semantics permit.
- Keep first-person clips and current weapon set resident because a streaming miss is directly visible. Stream lower-priority world variants with a deterministic fallback.

### IK and constraints

- Prefer analytic two-bone solves for ordinary support-hand placement. Use full-body IK only when shoulders, torso, stance, or two-handed contact genuinely require it.
- Cap iterative solver iterations, expose residual error, and early-out on convergence.
- First-person hands require stricter screen-space stability than remote hands. Third-person LOD may reduce iterations, remove fingers, or replace IK with baked offsets.
- Solve against a snapshotted weapon target set so jobs never observe partially updated attachment transforms.

### Skinning, visibility, and pose sharing

- Owner-only visibility does not automatically imply zero work: a hidden world mesh may still feed self-shadowing, reflections, ray tracing, attachments, motion vectors, or scene captures.
- Express these consumers as explicit visibility reasons rather than a single `visible` boolean.
- If no world consumer exists, throttle or skip world deformation while still advancing the minimal semantic/action state needed for attachments and later recovery.
- Pose sharing is appropriate for remote crowds using the same skeleton and phase class. It is normally inappropriate between the owner’s bespoke first-person arms and their world full body unless the compatible subset and timing are proven.

### Animation LOD and job scheduling

- The local first-person rig is highest pose priority while its camera is active.
- The local world rig receives a consumer-driven LOD: full for mirrors/photo mode/near shadows, reduced for shadow-only, and minimal or skipped when no consumer requires it.
- Remote characters use distance, projected size, visibility, significance, and interaction relevance.
- Graph, decompression, IK, palette generation, and deformation should expose separate timings; a single “animation time” counter hides duplication.

### Networking and fixed-step synchronization

- Replicate authoritative action/equipment/aim state, not first-person bone transforms.
- Advance authoritative action phases on fixed simulation ticks. Presentation graphs interpolate snapshots and may add view-only recoil or sway.
- Remote clients reconstruct third-person poses. Spectators and replays consume recorded simulation/action state plus optional camera metadata.
- Rollback resets or regenerates presentation history, constraint targets, event journals, and previous-rendered-pose state by generation. Do not retransmit cosmetic first-person poses.

### Memory and motion history

- Budget skeleton metadata, clip residency, graph state, pose buffers, palettes, constraint targets, and previous-rendered poses separately for both instances.
- Previous-rendered pose is per representation and per deformation history, not a substitute for previous simulation pose. First-person and world meshes may have different transforms and visibility histories.
- After a camera-mode switch, teleport, mesh swap, FOV regime change, or long visibility gap, invalidate or seed motion history to prevent velocity streaks.

## 6. Pros and Cons

### Hybrid dual representation

**Pros**

- Highest control over first-person readability, clipping, ADS alignment, recoil, and weapon handling.
- Preserves an anatomically valid world body for other players, shadows, reflections, spectators, and replay.
- Lets first- and third-person content evolve independently while sharing gameplay semantics.

**Cons**

- Additional clips, graph branches, memory, QA combinations, and possible double evaluation.
- Requires explicit event ownership and transform authority to prevent duplicate effects and attachment feedback loops.
- Cross-view phase differences can become visible in multiplayer, mirrors, or rapid camera switches.

### Single full-body representation

**Pros**

- Fewer assets and easier continuity across camera switches.
- World contacts and body awareness naturally refer to the same pose.

**Cons**

- Camera-space composition, near-plane avoidance, weapon readability, and anatomical correctness compete.
- Raw head motion can produce discomfort.
- A pose acceptable from the owner camera may be poor externally, and vice versa.

### Floating arms only

**Pros**

- Small evaluated skeleton, direct composition, and conventional first-person authoring.

**Cons**

- Weak body awareness and difficult transitions to mirrors, shadows, interactions, vehicles, climbing, or camera changes.
- Still requires a world body, so it is not actually a single-representation solution.

## 7. ECS Architectural Integration

Recommended components:

- `CharacterActionState`: authoritative action, generation, fixed-tick phase, stance, interrupt state.
- `AimState`: authoritative origin/direction plus presentation-smoothed direction.
- `EquipmentState`: durable item identity, slot, ownership generation, attachment state.
- `PresentationMode`: owner FP, owner TP, remote, spectator, replay, photo, or scene capture.
- `RigRepresentationSet`: handles for world and optional first-person rig instances.
- `RigSemanticMap`: stable semantic IDs to bone/socket indices per rig version.
- `WeaponGripProfile`: primary/support grips, bend hints, sight, muzzle, magazine, casing, recoil axes, and calibration version.
- `FirstPersonCalibration`: FOV/scale regime, camera/weapon offsets, ADS projection target, clipping envelope, and comfort limits.
- `RepresentationConsumers`: main view, shadow, reflection, ray tracing, scene capture, attachment, replay, debug.
- `PoseEvaluationRequest`: skeleton, graph, mask, LOD, phase snapshot, constraint set, output generation.
- `SocketPoseSnapshot`: immutable post-solve transforms for effects and attachments.
- `PresentationEventCursor`: representation-specific consumption cursor referencing shared stable event IDs.
- `PoseHistory`: representation-specific previous evaluated/rendered state and invalidation generation.

System order:

1. Fixed-step simulation updates movement, action, aim, and equipment.
2. A presentation snapshot is published once per render frame.
3. Consumer analysis selects required representations and LOD.
4. World and first-person graphs evaluate in jobs from the same snapshot.
5. Weapon/hand constraints solve in a directed order.
6. Socket snapshots and palettes are committed.
7. Shared events are routed once to gameplay; view-specific presentation consumers realize effects.
8. Rendering and scene features consume their designated representation.

## 8. Rig, Pose, Graph, Constraint, and Event Interfaces

### Rig interface

`RigSemanticMap`

- `skeletonVersion`
- semantic bone IDs: root, pelvis, spine chain, clavicles, arms, hands, fingers, head
- semantic sockets: camera anchor, primary grip, support grip, sight, muzzle, magazine, casing, interaction
- parent-chain and required-bone masks
- bind/reference transforms and retarget basis

### Pose and graph interface

`PresentationPoseInput`

- `simulationTick`, interpolation alpha, action generation
- action phase, locomotion parameters, stance, aim pitch/yaw
- recoil/sway impulses, equipment/grip profile
- representation kind, camera FOV/aspect, LOD, consumer flags

`PresentationPoseOutput`

- local/model-space pose buffer
- root/world transform
- socket snapshot
- residual constraint errors
- evaluated-bone, blend-sample, decompressed-track, and solver-iteration counts
- pose/history generation

Graph layers should be explicit:

1. Representation-specific base locomotion/action pose.
2. Shared semantic action phase alignment.
3. Additive aim/recoil/sway masks.
4. Weapon transform solve.
5. Primary/support hand and body constraints.
6. Representation-specific camera/body-awareness corrections.
7. Post-solve sockets and deformation output.

### Weapon and constraint interface

`WeaponGripProfile`

- handedness and authoritative driver
- weapon-to-primary-hand transform
- support-hand target and bend hint
- sight-to-camera target
- muzzle, magazine, casing, and interaction transforms
- allowed translation/rotation correction
- per-representation overrides with a common semantic version

`ConstraintResult`

- target generation
- position/angular residual
- clamped flags
- iteration count
- invalid-target reason

### Event interface

The two graphs must never independently issue durable gameplay mutations. A shared action timeline owns gameplay-capable events. Each event contains a stable identity based on entity, action generation, schema event, occurrence, and loop/section generation.

- Gameplay consumes the authoritative event once.
- First-person and world presentation may each consume the same event for different visuals.
- Effects specify an allowed representation policy: owner FP, world, both with deduplication, or camera independent.
- Ammo, inventory, damage, cooldown, and interaction state remain snapshot-backed durable state.
- A camera switch changes presentation consumers, not action identity, preventing replayed fire/reload events.

## 9. Content and Runtime Integration Plan

### Stage 1: Semantic contract

- Define canonical bone/socket semantics and naming rules.
- Define action phase and event schemas independent of either graph.
- Define weapon grip and sight/muzzle calibration assets with versions.
- Choose world rig as the canonical external representation.

### Stage 2: Minimal hybrid prototype

- Implement one world full-body rig and one owner-only arms/weapon rig.
- Drive both from the same action snapshot.
- Route gameplay events only from the shared action timeline.
- Validate visibility, hidden-shadow, reflection, ray-tracing, and spectator consumers.

### Stage 3: Alignment and body awareness

- Add primary/support-hand directed constraints and residual telemetry.
- Calibrate hip-fire and ADS poses at supported FOV/aspect ranges.
- Add camera-anchor filtering and bounded view-only impulses.
- Prototype visible legs/torso or per-vertex first-person/world blending only where the game benefits.

### Stage 4: Performance controls

- Cook required-bone and track masks per representation and LOD.
- Add pose cache, partial decompression, bounded solver budgets, and parallel jobs.
- Add consumer-driven throttling for the hidden world rig.
- Establish clip residency and deterministic fallbacks for every equipped item class.

### Stage 5: Multiplayer and mode transitions

- Reconstruct remote third-person poses from replicated semantic state.
- Exercise owner FP/TP switching, spectator handoff, replay, kill camera, mirrors, and photo mode.
- Reset history safely after rollback, teleport, representation swap, or visibility gaps.

## 10. Verification Strategy

### Automated content validation

- Required semantic bones/sockets exist once and have valid parentage.
- First- and third-person rigs map to the same action/weapon semantic version.
- Grip, sight, muzzle, magazine, and casing transforms meet position/orientation tolerances.
- No graph with gameplay-capable events is registered as a second authority.
- First-person clips contain only allowed tracks; world clips retain required shadow/attachment bones.
- Constraint targets and hints are finite, non-degenerate, and reachable within declared correction limits.

### Runtime tests

- Measure ADS screen-space sight error across supported FOVs, aspect ratios, resolutions, camera offsets, stances, locomotion, recoil, and every weapon/skin.
- Measure support-hand position/angular residual and elbow-flip count over the full clip library.
- Verify muzzle visual direction against the authoritative aim/ballistic contract at near and far targets.
- Switch FP/TP every tick around fire, reload, equip, interaction, interruption, rollback, and death; assert no duplicate durable event.
- Exercise walls and near geometry for clipping, pose collapse, camera penetration, and weapon obstruction behavior.
- Capture owner, remote, shadow, reflection, hardware-ray-tracing, spectator, replay, scene-capture, and photo-mode outputs in the same deterministic scenario.
- Test hidden world-rig consumer combinations rather than only main-camera visibility.

### Performance and telemetry

Record per representation:

- Graph time, pose jobs, evaluated bones, blend samples, decompressed tracks/bytes, cache hits, allocations.
- IK solver type, iterations, convergence, and residual.
- Skinning vertices, palette bytes, previous-pose bytes, consumer reasons, LOD, throttling decisions.
- Clip streaming misses and fallback use.
- Fixed-tick action phase, render interpolation, event ID, and rollback generation.

Budget tests should include local FP plus a required world shadow/reflection, local TP, split/spectator views, remote crowds, and rapid mode switching.

## 11. Risks and Open Decisions

- **Representation choice:** floating arms, full-body first person, per-vertex first-person/world interpolation, or a hybrid selected by action.
- **Skeleton compatibility:** whether FP and world rigs share a skeleton subset, retarget contract, or only semantic socket mappings.
- **Weapon authority:** weapon-driven primary hand versus hand-driven weapon by item/action class.
- **ADS truth:** authoritative gameplay ray, physical muzzle, camera ray, and visual sight convergence at short distances.
- **Body awareness:** which body parts are visible, how head/shoulders are clipped, and whether visible legs use the world pose.
- **Camera motion:** maximum authored translation/rotation, comfort presets, accessibility disable/scaling, and recoil ownership.
- **Hidden world cost:** required update rates for shadow, reflection, ray tracing, attachments, and motion history on target platforms.
- **Camera switches:** whether graphs phase-lock continuously or use a short inertialized handoff.
- **Spectator/replay:** whether recorded owner-camera cosmetics are reproduced or only authoritative state plus world pose.
- **Content scale:** per-weapon bespoke FP clips versus families driven by grip profiles and procedural correction.
- **Networking:** remote aim quantization, action-phase correction thresholds, and visual muzzle reconciliation policy.

## 12. Engineering Recommendations

1. Adopt a hybrid dual-representation baseline: a canonical world full body plus an optional owner-only first-person presentation.
2. Keep one authoritative simulation/action/equipment identity. Replicate semantic state and never first-person bone poses.
3. Permit separate first- and third-person clips and graphs, but require a shared action generation, phase contract, and stable event identity.
4. Make weapon/hand solving directional. Use a profile-selected driver, analytic support-hand IK by default, and bounded full-body IK only when necessary.
5. Separate authoritative aim/ballistics from rendered muzzle and sight transforms; measure and reconcile their error explicitly.
6. Keep the camera off the raw head bone. Use a filtered anchor and bounded, accessible presentation impulses.
7. Preserve the world representation for remote views, shadows, reflections, ray tracing, spectators, and replay. Track those as explicit consumers.
8. Prevent dual graphs from duplicating gameplay effects: gameplay events come from the shared action timeline; representation graphs are presentation consumers.
9. Cook representation-specific bone/track masks, cache reusable base poses, partially decompress clips, schedule pose jobs in parallel, and use bounded allocation-free scratch.
10. Apply consumer-driven LOD to the hidden world body, but never infer that owner invisibility means no shadow/reflection/attachment work.
11. Maintain separate previous-rendered-pose histories and invalidate them on representation, FOV, teleport, rollback, or visibility-generation changes.
12. Gate production content on automated ADS projection error, grip/socket validity, constraint residual, cross-view phase, event deduplication, and multi-view render tests.

## 13. Source Links

1. Epic Games, **First Person Rendering**, Unreal Engine 5.8:  
   https://dev.epicgames.com/documentation/en-us/unreal-engine/first-person-rendering
2. Epic Games, **Adding a First-Person Camera, Mesh, and Animation**, Unreal Engine 5.8:  
   https://dev.epicgames.com/documentation/en-us/unreal-engine/coder-04-adding-a-firstperson-camera-mesh-and-animation
3. Epic Games, **Setting Up a Character**, Unreal Engine:  
   https://dev.epicgames.com/documentation/en-us/unreal-engine/setting-up-a-character-in-unreal-engine
4. Epic Games, **Aim Offset**, Unreal Engine:  
   https://dev.epicgames.com/documentation/en-us/unreal-engine/aim-offset-in-unreal-engine
5. Epic Games, **IK Rig**, Unreal Engine:  
   https://dev.epicgames.com/documentation/en-us/unreal-engine/ik-rig-in-unreal-engine
6. Unity Technologies, **Two Bone IK Constraint**, Animation Rigging package:  
   https://docs.unity3d.com/Packages/com.unity.animation.rigging@1.2/manual/constraints/TwoBoneIKConstraint.html
7. Arkane Studios, **The Challenges of Designing First-Person Melee Combat**, GDC 2007:  
   https://media.gdcvault.com/gdc07/slides/S3736i1.pdf
8. GDC Animation Bootcamp, **Giving Purpose to First-Person Animation**, GDC 2013:  
   https://www.gdcvault.com/play/1017633/Animation-Bootcamp-Giving-Purpose-to

