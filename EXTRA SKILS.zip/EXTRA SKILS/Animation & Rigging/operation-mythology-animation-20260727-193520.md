# Operation Mythology Animation & Rigging Research

**Batch timestamp:** 2026-07-27 19:35:20 America/Los_Angeles  
**Subject:** Facial semantic curves, visemes, expressions, dialogue synchronization, retargeting, deformation, LOD, networking, and memory/streaming budgets  
**Scope:** Research and architecture only; modular generic ECS; data-oriented runtime; first-person and third-person support

## 1. Feature Overview

Operation Mythology needs facial animation for dialogue, barks, exertion, combat reactions, gaze, emotional state, cinematic performance, multiplayer avatars, and ambient life. The runtime must support high-quality hero characters without evaluating a cinematic face rig on every crowd member.

The recommended architecture has four distinct layers:

1. **Semantic facial intent:** versioned named controls for speech shapes, jaw/tongue, expression, eyes/eyelids, gaze correctives, and procedural behavior.
2. **Time-aligned performance streams:** authored curves, performance capture, audio/phoneme/viseme analysis, dialogue emphasis, emotion, and procedural blink/gaze inputs.
3. **Character-specific rig solve:** semantic controls mapped through a per-character facial rig into bones, morph targets/blend shapes, corrective shapes, animated maps, or a bounded learned deformer.
4. **Runtime deformation:** evaluated at a significance-driven facial LOD, synchronized to the audio presentation clock while keeping dialogue/gameplay state authoritative elsewhere.

This separation allows one dialogue/performance stream to drive multiple characters while preserving character-specific facial anatomy. It also prevents viseme events, capture frames, or curve completion from becoming authority for conversation logic, ability state, or audio playback.

## 2. Existing Coverage and Identified Gap

The required recursive scan found:

- General animation-curve, compression, validation, pose evaluation, morph/deformer, GPU skin-cache, LOD, pose-sharing, networking, and event principles.
- Gaze/eye/head coordination, including eyelid correctives and blink ownership left to a facial system.
- Action-layer channels containing a placeholder head/face action.
- Semantic compression probes for facial landmarks.
- FP/TP dual representations and visibility consumers.

The uncovered gap was a dedicated facial contract:

- Portable semantic controls versus raw character-specific morph names.
- Performance capture, authored curves, audio-driven visemes, expressions, gaze, blinks, jaw/tongue/teeth, and corrective composition.
- Coarticulation and dialogue/audio clock synchronization.
- Curve ownership, priorities, regional masks, cancellation, interruption, and crossfades.
- Facial retargeting across different identities and rig topologies.
- Curve compression, active-set evaluation, morph-target memory, GPU deformation, jobs, allocations, streaming, and LOD.
- Multiplayer replication, replay, FP/TP visibility, and automated quality/performance gates.

This report addresses that gap without repeating the prior gaze target-selection system or general deformation architecture.

## 3. Sourced Facts

### Official engine/platform facts

- Unreal Engine 5.8 Animation Curves are float channels that can drive morph targets, material parameters, and arbitrary Animation Blueprint values. Curves can be connected to bones and limited by maximum LOD. [Epic Games, Animation Curves]
- Unreal’s Morph Target Previewer states that morph targets are additively blended vertex deformations and that multiple morph targets can combine into complex facial expressions. [Epic Games, Morph Target Previewer]
- Unreal’s FBX Morph Target Pipeline imports facial morph-target animation as Animation Sequence curve data and supports multiple morph targets driving a single animation. [Epic Games, FBX Morph Target Pipeline]
- Unreal’s Facial Animation Sharing workflow uses shared curve animation with character-specific Pose Assets. Epic warns that shared facial curve animations should not contain bone transforms because reference-pose transforms will not transfer correctly across different faces. [Epic Games, Facial Animation Sharing]
- Epic’s MetaHuman Facial Description Standard defines named control curves that represent facial movement and can be transferred among compatible characters. MetaHuman DNA describes joints, meshes, blend shapes, animated maps, LODs, and their relationships; RigLogic evaluates that rig at runtime. [Epic Games, MetaHuman Standard and Devkit]
- Apple ARKit exposes named face blend-shape coefficients, normally in a neutral-to-maximum range, and allows applications to use a small subset or a larger set depending on desired complexity. [Apple, ARFaceAnchor blendShapes]
- Microsoft Azure Speech documents that a viseme is a visual description of a phoneme, that multiple phonemes may map to one viseme, and that speech output can include timestamped viseme IDs or 3D blend-shape frames. [Microsoft, Speech Visemes]

### Academic/reputable facial-animation facts

- Example-based blend-shape facial rigging and performance-driven blend-shape fitting are established production/research approaches. [Li et al., *Example-Based Facial Rigging*, SIGGRAPH 2010; Cao et al., *3D Shape Regression for Real-time Facial Animation*, SIGGRAPH 2013]
- Facial performance retargeting is character specific: recent SIGGRAPH work explicitly targets high-quality transfer while reducing setup-shape requirements. [Pražák et al., *Local Anatomically-Constrained Facial Performance Retargeting*, SIGGRAPH 2022]

### Consequences supported by the sources

- Semantic named controls are a practical interchange layer between performance data and character-specific rigs.
- A viseme is not a one-to-one phoneme representation; timing and neighboring speech context matter.
- Curves, bones, morph targets, animated maps, and LOD can coexist in a production facial rig.
- Sharing curve intent is more portable than sharing character-specific bone transforms.

### Engineering recommendations versus sourced facts

The exact semantic schema, regional composition rules, coarticulation model, audio clock policy, ECS records, performance budgets, network protocol, fallback tiers, and verification gates below are Operation Mythology engineering recommendations. Control counts, sampling rates, compression tolerances, and LOD distances must be calibrated; this report does not assert universal values.

## 4. Industry-Standard Animation API or Pattern

### Portable semantic-control layer

Define versioned semantic groups:

- `Speech`: viseme/mouth-shape controls, lips, jaw, tongue, teeth visibility.
- `Expression`: brows, cheeks, nose, mouth corners, chin, jaw tension.
- `Eyes`: blink, widen, squint, lid follow, gaze-driven correctives.
- `Gaze`: eye direction supplied by the orientation coordinator, not dialogue curves.
- `Affect`: valence/arousal or authored emotion controls that expand into expression poses.
- `Procedural`: blink, breath, swallow, micro-expression, pain/exertion.
- `Corrective`: combinations generated by the rig solve, not normally authored as primary intent.
- `Material/Map`: wrinkle, flush, wetness, tears, blood, emissive or stylized effects.

Semantic controls are stable IDs with declared range, neutral value, side, region, composition rule, interpolation, LOD, and rig version. Raw DCC names are mapped at import and never used as runtime identity.

### Source-stack pattern

Facial intent may come from:

- Hand-authored performance.
- Offline or live facial capture.
- Audio/phoneme/viseme analysis.
- Dialogue markup and emotion.
- Gaze/eyelid coordinator.
- Gameplay reaction/exertion.
- Procedural ambient behavior.
- Cinematic override.

Each source declares:

- Source/action/dialogue generation.
- Semantic region mask.
- Priority and composition mode.
- Absolute/override, additive, maximum, multiplicative, or rig-defined combination.
- Start/stop/crossfade and cancellation behavior.
- Time base and latency.
- Confidence and fallback.

The facial mixer creates one resolved semantic-control vector. The character rig evaluates it once.

### Speech/coarticulation pattern

Do not play hard viseme poses as isolated sequential keys. Convert phoneme/viseme timing into overlapping activation envelopes:

- Anticipatory onset before acoustic release where the model/profile requires it.
- Context-dependent dominance and duration.
- Smooth overlap of neighboring mouth shapes.
- Separate jaw opening from lip articulation and tongue/teeth shapes.
- Stress/emphasis and speaking-rate scaling.
- Character/style profile for articulation strength.

Audio-driven output is a baseline or fallback. Hero dialogue may use captured or authored curves, with audio/viseme data used for alignment and recovery.

### Character-specific rig solve

Map resolved semantic controls through a `FacialRigProfile`:

- Direct morph/blend-shape weights.
- Facial joints.
- Pose-space/RBF or combination correctives.
- Animated wrinkle/material maps.
- Eye/eyelid and jaw/tongue dependencies.
- Limits and mutually corrective relationships.
- LOD-specific reduced rigs.

The mapping may be linear for simple characters and nonlinear for hero faces. Learned deformation is optional and must have a deterministic, bounded conventional fallback.

### Dialogue clock pattern

Keep three clocks explicit:

- Authoritative dialogue/gameplay state and start tick.
- Audio presentation clock actually heard by the listener.
- Facial curve evaluation time.

For local playback, drive lip sync from the audio presentation clock or a measured audio-to-render mapping, not blindly from frame delta. On seek, pause, underrun, device change, or time dilation, apply declared resynchronization behavior.

## 5. Runtime and Content-Pipeline Performance

### Evaluation complexity

Let:

- `C` = active semantic controls.
- `R` = rig outputs/correctives.
- `M` = active morph targets.
- `V` = affected vertices.
- `B` = facial bones.

Semantic mixing is approximately `O(C)`. A dense nonlinear rig may approach `O(C × R)` without sparsity. Bone evaluation is `O(B)`. Morph deformation is approximately `O(M × V_affected)` in a straightforward implementation, though GPU kernels, sparse deltas, and batching change constants and memory behavior.

The number of named controls is not the only cost. Active morph count, vertex delta bandwidth, corrective expansion, curve sampling, animated maps, and deformation consumers determine the runtime budget.

### Active-set curve evaluation

- Compile curve IDs to dense indices but store active source spans sparsely.
- Precompute region/LOD masks and source-to-control mappings.
- Skip constant neutral controls and inactive source groups.
- Resolve all sources into one compact vector before the character-specific solve.
- Avoid string lookups and per-curve objects at runtime.
- Use change thresholds only where they do not cause visible quantization or lip-sync error.

### Curve compression and sampling

- Cook curves with error metrics appropriate to their semantic effect, not a single scalar threshold.
- Speech/lip and eyelid timing need stricter temporal/shape error than slow ambient material curves.
- Validate compressed curves through the production decoder against facial landmark, lip silhouette, eye closure, and jaw/tongue probes.
- Sample keys, tangents, audio/phoneme boundaries, expression peaks, blinks, and adaptive midpoints.
- Use block/segment compression with random access for seek/replay and streaming.
- Runtime curve decoding performs no allocation.

### Blend, corrective, and rig cost

- Compile a topological evaluation order for direct controls, combinations, correctives, and animated maps.
- Use sparse dependency spans so a changed brow control does not evaluate unrelated mouth correctives.
- Batch independent regions when the rig permits.
- Limit iterative fitting to offline capture/retargeting; runtime playback should evaluate a compiled forward rig.
- Record active primaries, generated correctives, clamps, and residual landmarks.

### Bone counts and hierarchy

- Facial joints share the body skeleton or a dedicated face hierarchy depending on rig.
- Compile required parent closure and separate head/face LOD masks.
- Remote LODs can remove tongue, teeth helpers, minor eyelids, wrinkle joints, and micro-correctives while preserving jaw/lip silhouette.
- The local FP character may not render its own face, but world shadows, reflections, spectators, photo mode, or replay may require a world facial pose.

### Morph-target memory and cache behavior

Morph deltas can be expensive because each target may carry position and optional normal/tangent changes across many vertices.

Recommendations:

- Store sparse deltas only for affected vertices when the backend/content format supports it.
- Partition face deformation from body deformation and stream hero facial data as a coherent group.
- Keep compact headers/offsets and contiguous delta blocks by LOD/target.
- Batch active targets and minimize repeated reads of base vertices.
- Prefer character-specific reduced target sets at lower LOD rather than loading all hero targets and assigning zero.
- Measure target-delta bytes, active-delta bytes per frame, cache misses, and output-buffer bandwidth.

### SIMD and GPU deformation

- SIMD is useful for dense curve mixing, forward rig evaluation, facial bone transforms, and CPU morph accumulation.
- GPU morph/deformer paths can offload vertex work and reuse deformed output across render, shadow, ray-tracing, and hair consumers when the existing deformation architecture justifies the memory/barrier cost.
- Compute deformation is not automatically cheaper for a small face with one consumer; retain a vertex/CPU-compatible fallback.
- Current and previous deformed facial state must be valid for motion vectors and temporal effects.

### Allocations and streaming

- Use fixed/pool-owned source instances, semantic vectors, decoder contexts, and rig scratch.
- Dialogue performance streams are immutable assets with generation-checked handles.
- Stream speech curves before the audible line or provide a resident neutral/viseme fallback.
- Audio may start only when required synchronization policy is ready, or facial playback may join late with a bounded catch-up policy.
- Never block the audio callback, render thread, or pose worker on facial I/O.
- On a stream miss, use neutral/low-rate audio-driven fallback and report it; do not retain a stale expression indefinitely.

### Job scheduling

Recommended schedule:

1. Dialogue/gameplay state publishes tick-stamped line and affect state.
2. Audio system publishes presentation clock mapping/readiness.
3. Facial source jobs decode authored/capture/speech curves.
4. Source mixer resolves semantic controls.
5. Character-specific rig solve produces bones/morphs/maps.
6. Body/face pose integration and deformation jobs run.
7. Rendering consumes current/previous outputs.

Batch low-cost faces by rig/profile/LOD. A hero face may be its own job. Do not create a job per curve or morph target.

### IK/constraint iterations

Facial playback should ordinarily be a forward curve/pose solve, not iterative IK. Iterative work may appear in:

- Offline performance fitting/retargeting.
- Eye convergence/look constraints.
- Jaw/tongue collision or contact correction.

Keep runtime eye/jaw constraints bounded and analytic where possible. Report any iterations separately; do not hide expensive facial fitting inside the generic pose budget.

### Pose sharing

Characters can share:

- Dialogue/viseme semantic stream.
- Emotion/affect intent.
- Procedural blink schedule where exact individuality is not needed.

They generally cannot share:

- Final morph weights if character rig mappings differ.
- Final vertex deformation.
- Eye/gaze targets and character-specific correctives.

Share semantic intent, then solve per facial rig. For crowds using identical heads/rigs and the same performance/time/LOD, final curve or pose sharing may be allowed through a strict compatibility key.

### Facial animation LOD

Suggested tiers:

- **Hero/cinematic:** full captured/authored curves, nonlinear correctives, tongue/teeth, eye/eyelid, wrinkle maps, full-rate deformation.
- **Near gameplay:** reduced semantic set, speech/expression/gaze, selected correctives, reduced rate if visually safe.
- **Mid:** jaw plus compact mouth/eye/expression set, coarser curve rate, no micro-correctives.
- **Far:** jaw/open-close or categorical speaking/emotion pose.
- **Very far/invisible:** no face deformation; retain dialogue/audio/gameplay state only.

Transition LOD with curve/pose crossfade or seeded values. Do not reset to a stale neutral mid-phoneme.

### Networking and fixed-step synchronization

- For authored dialogue, replicate line asset/version, speaker, authoritative start tick, branch/locale, and important affect/gaze state. Clients play local audio/performance assets.
- For generic barks, a line/variant ID plus start/cancel generation is usually enough.
- For player live facial capture, use a separate rate-limited compressed semantic stream with timestamps, quantization, prediction/interpolation, dropout, privacy, and platform policy.
- Do not replicate morph-target arrays or vertices.
- Dialogue/gameplay completion remains fixed-step/authoritative; lip sync follows the local audio presentation clock.
- Replay records semantic line/performance identity and important live stream packets, not final deformed vertices.

### Fixed-step synchronization

The face is presentation-rate, but action/dialogue transitions are fixed-step:

- Start/cancel/interrupt generations are fixed-tick.
- Audio scheduling maps the authoritative start into device time.
- Facial curves map to audio sample/time offsets.
- Rollback of predicted barks cancels/fades presentation through the side-effect journal.
- Long-form conversation should not rewind already committed audio/face unless the game explicitly supports it.

### Memory budgets

Budget separately:

- Semantic schema and mapping tables.
- Authored/captured/speech curve streams.
- Clip decoder and active source state.
- Character rig/corrective tables.
- Facial bones and pose buffers.
- Morph delta data per LOD.
- Animated maps/wrinkle masks.
- Current/previous deformed buffers.
- Live-capture network jitter buffers.
- Audio-to-face synchronization state.

Track peak resident memory for conversations with multiple hero speakers, not only one isolated head.

## 6. Pros and Cons

### Semantic curves with character-specific solve

**Pros**

- Portable performance intent across different faces.
- Supports authored, captured, audio-driven, procedural, and network sources.
- Enables per-character anatomy and LOD.
- Keeps raw morph names and topology out of gameplay/ECS contracts.

**Cons**

- Requires schema governance and per-character mapping/validation.
- Different rigs may interpret the same semantic vector differently.
- Nonlinear combinations add runtime and authoring complexity.

### Blend-shape/morph-target rigs

**Pros**

- Direct artistic control over facial shapes.
- Established capture and expression workflow.
- Good for nonlinear anatomical detail through combination correctives.

**Cons**

- Potentially high vertex-delta memory and bandwidth.
- Target combinations can interfere or exceed plausible anatomy.
- Topology specific.

### Bone-driven face

**Pros**

- Compact for stylized/simple rigs and compatible with skeletal deformation.
- Easier to scale some proportions.

**Cons**

- Harder to achieve high-frequency surface detail without correctives/maps.
- Bone transforms are less portable across different facial reference poses.

### Audio/viseme-driven face

**Pros**

- Scales to dynamic dialogue and localization.
- Low manual authoring cost and useful fallback.

**Cons**

- Viseme identity alone lacks full coarticulation, emotion, performance nuance, and language-specific detail.
- Audio latency/seek/streaming errors are directly visible.

### Performance capture

**Pros**

- Captures timing, asymmetry, emotion, and speaker-specific nuance.

**Cons**

- Capture cleanup, retargeting, storage, actor/locale coverage, and platform/runtime complexity.
- Raw tracking noise and identity leakage require filtering and governance.

## 7. ECS Architectural Integration

Recommended assets/components:

- `FacialSemanticSchema`: stable control IDs, regions, ranges, neutral values, composition and LOD rules.
- `FacialRigProfile`: character/skeleton/mesh versions, semantic-to-rig mapping, correctives, outputs, limits, LOD tables.
- `DialoguePresentationState`: line/locale/variant, authoritative generation/start tick, audio handle, cancel state.
- `AudioFaceClockState`: audio device/sample mapping, latency, playback time, underrun/seek generation.
- `FacialSourceSet`: bounded authored/capture/viseme/expression/gaze/procedural sources.
- `FacialSemanticState`: resolved semantic vector, generation, active mask, LOD.
- `FacialRigOutput`: facial bone pose, morph weights, animated-map parameters, output generation.
- `FacialStreamingState`: asset residency, decoder state, fallback, deadline.
- `LiveFaceNetworkState`: packet sequence/time, jitter buffer, confidence, privacy policy.
- `FacialLODState`: significance, update rate, semantic/output masks, transition generation.

System ownership:

- Dialogue/gameplay owns line selection and authoritative progression.
- Audio owns audible playback and presentation clock.
- Facial mixer owns semantic source composition.
- Facial rig system owns character-specific output.
- Gaze coordinator owns eye targets; facial rig owns eyelid/corrective realization.
- Renderer/deformer owns morph/vertex/map resources.
- Networking owns line identity and optional live semantic streams.

Large curve, morph, and deformer data live in specialized asset/runtime pools, not ECS chunks.

## 8. Rig, Pose, Graph, Constraint, and Event Interfaces

### Semantic control interface

`FacialControlDefinition`

- Stable ID/name and schema version.
- Region/side.
- Neutral/min/max.
- Unit/meaning.
- Composition mode.
- Interpolation and rate policy.
- LOD floor/ceiling.
- Retarget category.
- Gameplay proposal permission, normally none.

### Source interface

`FacialSource`

- Source type and generation.
- Dialogue/action/live-capture identity.
- Time base and current timestamp.
- Region/control mask.
- Priority, weight, composition.
- Confidence and validity.
- Start/stop/crossfade/cancel policy.
- Fallback source.

### Character rig interface

`FacialRigProfile`

- Schema, skeleton, mesh topology, neutral-pose, and output versions.
- Semantic-to-primary mapping.
- Corrective dependency graph.
- Bone, morph, animated-map, eye/eyelid, jaw/tongue/teeth outputs.
- Output clamps and combination policies.
- Facial landmark probes.
- Per-LOD control/output masks and fallback poses.

### Evaluation output

`FacialEvaluationResult`

- Resolved semantic vector and active mask.
- Facial bone transforms.
- Sparse morph/animated-map output spans.
- Clamp/corrective activations.
- Landmark and lip-sync residual metrics.
- Audio/face time offset.
- LOD/fallback/streaming flags.
- Runtime cost counters.

### Graph composition

Recommended order:

1. Dialogue speech/viseme stream.
2. Authored/captured expression performance.
3. Gameplay affect/reaction overlays.
4. Gaze/eye direction.
5. Blink/eyelid and gaze-driven correctives.
6. Jaw/tongue/teeth dependencies.
7. Combination correctives and animated maps.
8. Facial bones/morph outputs integrated with body pose.
9. Deformation and temporal history.

Priority and regional masks may alter the mixer, but the character rig correctives evaluate once after primary semantic resolution.

### Event interface

- Line start/cancel/finish is authoritative dialogue state.
- Word/phoneme/viseme/emphasis markers are presentation timing data.
- Facial “ready,” lip-contact, expression peak, or capture-confidence events are presentation/telemetry proposals.
- No pose job mutates quest, conversation, ability, or inventory state.
- Side effects use stable dialogue/action generations and the existing rollback journal.

## 9. Content and Runtime Integration Plan

### Phase 1: Semantic schema and simple rig

- Define stable semantic groups, ranges, sides, and composition rules.
- Implement a compact jaw/lips/eyes/brows morph-or-bone rig.
- Add authored curves and character mapping validation.
- Establish neutral pose and facial landmark probes.

### Phase 2: Dialogue and visemes

- Integrate timestamped phoneme/viseme streams with overlapping coarticulation envelopes.
- Add explicit audio presentation clock mapping, seek/pause/underrun behavior, and fallback.
- Validate localization and speaking-rate variants.

### Phase 3: Expressions, gaze, and capture

- Add expression/affect layers and regional masks.
- Integrate gaze/eye targets, blink, and eyelid correctives.
- Add offline capture retargeting and cleanup through the semantic schema.

### Phase 4: Hero rig and deformation

- Add nonlinear combination correctives, tongue/teeth, animated wrinkle maps, sparse morph data, and GPU/CPU deformation selection.
- Preserve a conventional bounded fallback for optional learned deformation.
- Validate current/previous output for temporal rendering.

### Phase 5: LOD, streaming, networking, and scale

- Cook reduced semantic/output rigs per LOD.
- Stream dialogue curves and facial morph groups with deadlines/fallbacks.
- Replicate line identity and optional live semantic streams.
- Add crowd batching, significance throttling, memory budgets, and automated regression gates.

## 10. Verification Strategy

### Static rig/content validation

- Unique stable semantic IDs and valid ranges/neutral values.
- Every required semantic maps to valid character outputs or an explicit fallback.
- Corrective graph is acyclic, bounded, and LOD compatible.
- Morph deltas target valid topology/LOD and contain finite data.
- Facial bones retain parent closure.
- Audio/viseme/curve assets have valid ordered timestamps and locale/version metadata.
- Neutral input reproduces the validated neutral face.

### Speech/lip-sync tests

- Test every supported phoneme/viseme, language/locale, speaking rate, stress, silence, pause, and transition pair/triple.
- Measure lip landmark/silhouette, jaw, closure, teeth/tongue visibility, and audio-to-face offset.
- Exercise seek, pause, resume, underrun, device change, late stream, time dilation, interruption, and rollback cancellation.
- Compare authored/captured reference against cooked/compressed/platform output.

### Expression and combination tests

- Sweep each semantic control and important pairs/combinations.
- Detect self-intersection, lip/teeth/eyelid/eye penetration, volume collapse, asymmetry errors, clamp saturation, and corrective discontinuity.
- Combine speech, emotion, blink, gaze, hit reaction, pain, and exertion at maximum supported weights.
- Verify regional priorities and cancellation crossfades.

### Retargeting tests

- Apply canonical performances to every supported facial identity/rig family.
- Measure landmark trajectories, expression recognition, neutral drift, range saturation, and temporal alignment.
- Review worst numerical cases visually with side-by-side source/target and control/output traces.
- Invalidate cooked results whenever schema, neutral pose, topology, rig, or corrective version changes.

### LOD/deformation tests

- Compare each LOD against hero output at representative screen sizes.
- Validate LOD switches mid-phoneme, blink, expression peak, and gaze shift.
- Measure active controls, correctives, morph targets, delta bytes, bones, vertices, GPU/CPU time, bandwidth, and memory.
- Verify shadows, reflections, ray tracing, hair/skin dependencies, and motion vectors.

### Networking/fixed-step tests

- Reconstruct the same line/locale/variant from authoritative start/cancel generations on multiple clients.
- Inject latency, packet loss, reorder, and dropout into live semantic streams.
- Verify privacy/offline-disabled policy and neutral/fallback recovery.
- Record/replay authored and live performances without storing final vertices.
- Assert conversation/gameplay state remains correct when facial presentation is missing.

### Runtime telemetry

Record:

- Active source/control/corrective/morph counts.
- Curve decode bytes/cache hits and audio/face offset.
- Rig solve, bone, morph, deformation, job, and commit times.
- Allocations and scratch high-water.
- Stream misses/fallback duration.
- LOD/update rate/pose-sharing state.
- Network packet/jitter/dropout statistics.
- Landmark residual, clamp, and penetration flags.

## 11. Risks and Open Decisions

- Semantic schema choice, governance, versioning, and compatibility with MetaHuman/ARKit-like inputs.
- Blend-shape, bone, hybrid, or learned hero-rig output.
- Character-specific versus family-shared rig mappings and corrective authoring cost.
- Viseme/phoneme model and language-specific coarticulation/localization policy.
- Audio clock source, latency compensation, seek/underrun, and device-change behavior.
- Speech versus expression regional ownership and composition rules.
- Gaze coordinator versus facial system ownership of blinks, eyelids, squint, and eye correctives.
- Tongue/teeth scope for gameplay dialogue.
- Curve/morph compression thresholds by landmark and screen-space LOD.
- GPU versus CPU morph deformation crossover and sparse-delta format.
- Learned deformation/capture deployment, training data, determinism, platform fallback, and licensing/privacy.
- Live face replication rate, quantization, jitter, opt-in/privacy, abuse, and recording.
- FP local face evaluation policy for mirrors, shadows, replay, photo mode, and spectators.

## 12. Engineering Recommendations

1. Establish a versioned portable Facial Semantic Schema between all authored, captured, audio-driven, procedural, and network sources and character rigs.
2. Keep semantic controls stable and character neutral/morph/bone topology specific to a `FacialRigProfile`; never expose raw DCC morph names as gameplay identity.
3. Resolve all facial sources into one semantic vector using explicit regional masks, priorities, confidence, composition, and cancellation, then evaluate the character rig once.
4. Treat visemes as overlapping time-aligned speech-shape inputs with coarticulation, separate jaw/lip/tongue controls, stress, rate, and locale policy—not isolated phoneme poses.
5. Drive lip sync from an explicit audio presentation clock mapping while dialogue/gameplay state remains fixed-tick authoritative.
6. Share curve intent across characters and solve character-specific bones/morphs/correctives locally; do not share reference-pose bone animation across different faces.
7. Compile a sparse acyclic forward rig with bounded correctives, per-LOD control/output masks, and no runtime fitting allocations.
8. Use semantic-specific curve compression and validate production decoding against lip, eye, jaw, and landmark probes at keys, audio boundaries, peaks, and adaptive midpoints.
9. Store morph deltas sparsely/coherently where supported, stream facial groups before audio deadlines, and provide resident neutral/compact-viseme fallbacks.
10. Select CPU, vertex, or compute deformation from measured active-target/vertex/consumer cost and preserve valid previous-deformed history.
11. Batch low-cost faces by rig/LOD, give hero faces bounded jobs, use SIMD-friendly curve/rig buffers, and never allocate or perform I/O in pose/audio/render callbacks.
12. Apply facial LOD from full capture/correctives/maps to compact speech/expression, jaw-only/categorical, then disabled; crossfade/seed transitions mid-phoneme.
13. Replicate line/variant/start/cancel and important affect/gaze state for authored dialogue; reserve compressed timestamped semantic streams for opt-in live faces.
14. Keep FP and TP/world facial consumers explicit so an invisible owner face is evaluated only for required reflections, shadows, spectators, replay, or photo mode.
15. Gate content with neutral, phoneme/coarticulation, expression-combination, retarget, penetration, audio-sync, LOD-switch, streaming, network, and worst-case performance tests.

## 13. Source Links

1. Epic Games, **Animation Curves**, Unreal Engine 5.8:  
   https://dev.epicgames.com/documentation/en-us/unreal-engine/animation-curves-in-unreal-engine
2. Epic Games, **Morph Target Previewer**, Unreal Engine 5.8:  
   https://dev.epicgames.com/documentation/en-us/unreal-engine/morph-target-previewer
3. Epic Games, **FBX Morph Target Pipeline**, Unreal Engine 5.8:  
   https://dev.epicgames.com/documentation/en-us/unreal-engine/fbx-morph-target-pipeline-in-unreal-engine
4. Epic Games, **Facial Animation Sharing**, Unreal Engine 5.8:  
   https://dev.epicgames.com/documentation/en-us/unreal-engine/facial-animation-sharing-in-unreal-engine
5. Epic Games, **MetaHuman Facial Description Standard — Control Curves**:  
   https://dev.epicgames.com/documentation/metahuman/mh-standards-docs/mha_index
6. Epic Games, **MetaHuman Devkit — DNA, RigLogic, and Facial Description Standard**:  
   https://www.metahuman.com/devkit
7. Apple, **ARFaceAnchor blendShapes**:  
   https://developer.apple.com/documentation/arkit/arfaceanchor/blendshapes
8. Microsoft, **Get Facial Position with Visemes**, Azure Speech:  
   https://learn.microsoft.com/en-us/azure/ai-services/speech-service/how-to-speech-synthesis-viseme
9. Hao Li et al., **Example-Based Facial Rigging**, ACM SIGGRAPH 2010:  
   https://www.research-collection.ethz.ch/entities/publication/5d83da69-7e08-43ec-a39d-7447bf2c8b9c
10. Chen Cao et al., **3D Shape Regression for Real-time Facial Animation**, ACM SIGGRAPH 2013:  
    https://www.microsoft.com/en-us/research/publication/3d-shape-regression-real-time-facial-animation/
11. Jan Pražák et al., **Local Anatomically-Constrained Facial Performance Retargeting**, ACM SIGGRAPH 2022:  
    https://cgl.ethz.ch/publications/papers/paperPra22b.php

