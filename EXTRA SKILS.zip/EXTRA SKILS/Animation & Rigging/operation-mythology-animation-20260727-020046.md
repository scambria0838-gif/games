# Operation Mythology Animation & Rigging Research Report

## Full-Body IK, Multi-Contact Priorities, Solver Selection, and Runtime Budgets

**Timestamp:** 2026-07-27 02:00:46 America/Los_Angeles  
**Status:** New focused architecture batch  
**Assumptions:** Modular ECS, data-oriented runtime, fixed-step gameplay, variable-rate presentation, FP/TP support, and no production code.

## 1. Feature Overview

Inverse kinematics solves joint transforms from desired hand, foot, head, weapon, or body goals. Operation Mythology needs three deliberately separate solver tiers:

1. **Analytic limb IK** for ordinary two-segment arms and legs.
2. **Iterative chain IK** for tails, tentacles, spines, and variable-length serial chains.
3. **Full-body multi-effector IK (FBIK)** when several contacts must redistribute error through a shared pelvis/spine/root.

The recommendation is not to route every placement problem through FBIK. Use the cheapest solver whose degrees of freedom and contact coupling match the task. A compiled constraint plan assigns hard/soft priorities, reachable envelopes, per-axis weights, joint limits, preferred bend directions, iteration/tolerance budgets, and a deterministic failure policy. Gameplay validates targets before animation; the solver produces presentation transforms and telemetry, not gameplay authority.

## 2. Existing Coverage and Identified Gap

The required recursive scan found renderer, ECS, streaming, temporal-reconstruction, and lighting reports in `GAME SKILLS`. The dedicated animation folder contained one report covering root-motion authority, warping, networking, and final contact IK ordering.

That report established that final IK follows accepted movement, targets are immutable snapshots, and iterations must be bounded. It did not decide:

- solver selection by constraint topology;
- how multiple hand/foot/head goals compete;
- hard versus soft contact semantics;
- root/pelvis mobility and balance limits;
- singularity, reach, joint-limit, and overconstraint behavior;
- warm-starting, LOD, pose sharing, or deterministic solver budgets;
- validation and telemetry for residual contact error.

This batch covers those gaps without repeating root-motion or general graph architecture.

## 3. Sourced Facts

1. Unreal Engine 5.8 describes FBIK as a multi-goal solver with bone limits, stiffness, and preferred angles; increasing iterations can improve convergence but increases CPU cost [S1].
2. Unreal’s Control Rig FBIK uses a position-based solver core and exposes per-effector strength, pull-chain influence, root behavior, per-bone stiffness, axis limits, preferred angles, stretching, and iteration count [S2].
3. Epic documents root behaviors including pre-pull, pin-to-input, and free; the choice controls whether shared root/pelvis motion helps distant effectors converge [S2].
4. Epic recommends excluding bones rather than emulating exclusion with extreme stiffness or zero-width limits [S3].
5. Unreal’s ordinary limb solver exposes reach precision, maximum iterations, hinge axis, rotational limits, pull distribution, and twist correction, demonstrating that single-chain solvers still require explicit convergence and joint-plane controls [S1].
6. Unity Animation Rigging builds ordered animation jobs and supplies constraints including Two Bone IK and Chain IK; a two-bone constraint uses a target and a hint/pole control for the limb plane [S4][S5].
7. FABRIK is an iterative forward/backward reaching method designed for IK chains and was evaluated against other methods for cost, reliability, and convergence [S6].
8. Jacobian transpose, pseudoinverse, and damped-least-squares methods are established numerical IK approaches; damping is used to control behavior near singular configurations [S7].
9. Task-priority IK literature introduces ordered priorities for redundant manipulators so lower-priority tasks use remaining freedom instead of corrupting higher-priority tasks [S8].

These facts support explicit solver, priority, limit, and convergence contracts. They do not establish one universal solver or iteration count.

## 4. Industry-Standard Animation API or Pattern

### Compiled constraint records

`IKConstraint` contains:

- stable ID, stage, priority tier, solver type, and LOD range;
- effector bone and position/rotation goal;
- goal space and captured target generation;
- per-axis weights, compliance, maximum correction, and fade;
- chain/root indices and affected-bone closure;
- pole vector/preferred angles and twist policy;
- joint limits and optional excluded bones;
- tolerance, iteration cap, warm-start policy, and failure mode.

`IKSolveResult` contains achieved transform, position/angular residual, iterations, limit hits, clamped/unreachable/singular flags, and final weight.

### Solver choice

- **Two-bone analytic:** humanoid elbow/knee chains; constant bounded work; explicit pole and reach clamp.
- **CCD:** simple arbitrary serial chains; easy to implement; convergence/order can be sensitive.
- **FABRIK:** position-focused chains with many joints; predictable per-iteration linear passes; orientation and joint-limit handling require extensions.
- **Jacobian DLS:** coupled position/orientation goals and redundant chains; flexible but needs matrix construction/solve, damping, and robust scaling.
- **Position-based FBIK:** multiple goals over a branching skeleton with practical stiffness/limit controls; iterative and parameter-sensitive.

Baseline: analytic arms/legs plus targeted position-based FBIK for coupled interactions. Keep solver implementations behind one compiled interface.

### Priority model

Use discrete lexicographic tiers, then weighted soft goals inside a tier:

1. **Safety/validity:** joint limits, non-stretch policy, root-offset bounds.
2. **Authoritative contact:** reserved interaction hand, planted support foot.
3. **Task contact:** second hand, weapon support, traversal reach.
4. **Posture:** pelvis height, spine/head/aim, center-of-mass proxy.
5. **Style:** preferred angles, input-pose preservation, secondary goals.

When strict null-space task-priority math is not implemented, solve tiers sequentially and pin achieved high-priority results within compliance bounds. Never imply that arbitrary numeric weights guarantee priority.

### Contact state

Contacts transition through `Candidate → Acquiring → Locked → Releasing → Inactive`. Each carries target revision, acquire/release curves, friction/slip allowance, maximum reach, and ownership. Sudden goal replacement is prohibited; invalidation triggers a defined release or action failure.

## 5. Runtime and Content-Pipeline Performance

Let `B` be affected bones, `E` effectors, `I` iterations, and `P` solved characters:

- analytic two-bone IK: **O(1)** per limb;
- CCD: **O(I × B)**;
- FABRIK: **O(I × B)** for forward/backward passes;
- position-based FBIK: roughly **O(I × (B + constraints))**;
- dense Jacobian approaches add Jacobian construction and a solve whose cost depends on degrees of freedom and matrix method, potentially superlinear.

### Bone, blend, and decompression costs

Run IK after clip decompression/blending; it should not resample clips. Precompute affected-bone closures and local-to-model recomputation ranges. Recompute only dirty branches after a constraint, while preserving parent order.

FBIK on a 120-bone skeleton is wasteful if only pelvis, spine, arms, and legs participate. Exclude face, fingers, twist, cloth, weapon, and helper bones unless a goal truly needs them.

### Iterations and convergence

- fixed platform/LOD iteration caps;
- tolerance early-out;
- per-iteration residual tracking in development;
- unreachable goals clamped before solving;
- divergence/stall detection;
- no unbounded “solve until exact” loop;
- limits and stiffness tuned with the iteration budget, because both can slow convergence.

### Memory, allocations, cache, and SIMD

Store chain indices, parent indices, inverse lengths, limits, and solver coefficients contiguously. Use SoA vectors/quaternions for wide chain or character batches where practical. Matrix-heavy Jacobian solvers need bounded scratch sized at compile time; no per-frame matrix heap allocation.

Warm-starting from the previous solved pose can reduce iterations but makes results history-dependent and complicates teleport, correction, LOD, and deterministic replay. Default to current input-pose start for gameplay-adjacent actions; allow warm start only for presentation goals with explicit reset conditions.

### Job scheduling and pose sharing

Schedule one job per character/constraint group, not per effector. Batch common rig/solver programs. Run shared clip/blend pose first; per-instance IK follows and typically breaks final-pose sharing. Distant characters may share the final pose only after disabling individual contacts.

### Animation LOD

1. retain required local-player/interaction contacts;
2. remove style goals and secondary effectors;
3. replace FBIK with analytic limb IK;
4. reduce iterations/tolerance precision;
5. update IK less often and interpolate;
6. disable terrain/contact IK and share final pose.

Gameplay target validity continues even if visual IK is off.

### Networking and fixed step

Replicate interaction/action state and target IDs/transforms, not solved bones. The local presentation solver reconstructs a pose. Authoritative gameplay must not depend on small cross-platform IK residual differences. If gameplay needs a reach check, use a deterministic geometric envelope before the animation solve.

Fixed-step gameplay captures goals; render-rate IK consumes interpolated immutable goals and the accepted character transform. Corrections reset warm-start state and may invalidate contacts by generation.

## 6. Pros and Cons

### Pros

- Solver tiering prevents expensive FBIK from becoming the default.
- Explicit priorities make contact conflicts predictable.
- Bounded scratch and iterations fit data-oriented jobs.
- Residual reporting turns visual failures into measurable content problems.
- Immutable target generations integrate with rollback and threading.

### Cons

- Multiple solvers and compiled constraints increase tooling/test burden.
- Sequential approximate priorities are not mathematically identical to strict null-space task priority.
- Joint limits and preferred angles require rig-specific authoring.
- FBIK tuning can be sensitive to character proportions and input pose.
- Per-instance contacts reduce pose-sharing opportunities.

## 7. ECS Architectural Integration

Components contain logical state only:

- `IKProfileComponent`: compiled profile handle and LOD policy;
- `InteractionContactComponent`: goal IDs, generations, contact phases;
- `GroundContactInput`: captured foot targets/normals;
- `AimLookInput`: immutable direction/weight;
- `IKSignificanceComponent`: quality tier and always-solve flags.

Runtime stores own effectors, scratch, pose handles, and solver results.

System order:

1. gameplay validates/reserves interaction targets;
2. ground/scene queries produce immutable goal snapshots;
3. animation samples and blends the base pose;
4. constraint scheduler chooses LOD/solver plan;
5. workers solve priorities and write pose/results;
6. event/action logic consumes only validated contact state, not visual residual;
7. render extraction publishes completed palettes.

## 8. Rig, Pose, Graph, Constraint, and Event Interfaces

### Rig validation

- parent-before-child chains and valid root;
- nonzero segment lengths;
- expected hinge/pole axes;
- joint limits containing reference/preferred pose;
- no missing effector, root, or excluded-bone conflict;
- target spaces resolvable without worker scene queries;
- LOD preserves every active chain and parent closure;
- reachable-envelope tests for representative goals.

### Graph

Constraint stages declare bone reads/writes and component/local/world space. Compiler rejects cycles and overlapping same-priority writers without a composition rule.

### Events

Emit `GoalAcquired`, `GoalReleased`, `GoalClamped`, `ContactLocked`, `ContactBroken`, and `SolveFailed` with action/target generation. Visual “locked” never substitutes for authoritative interaction confirmation.

## 9. Content and Runtime Integration Plan

1. Define semantic chains, limits, preferred angles, and pole conventions.
2. Implement scalar analytic two-bone reference solver and validation suite.
3. Add compiled constraint plans, bounded scratch, residual telemetry, and debug drawing.
4. Add feet, hands, aim, and look-at as ordered independent constraints.
5. Implement contact lifecycle and target-generation resets.
6. Prototype position-based FBIK for two-foot/two-hand coupled interactions.
7. Add tiered priorities, root modes, exclusion lists, and LOD fallbacks.
8. Benchmark FABRIK/CCD for non-humanoid serial chains.
9. Evaluate DLS only for use cases needing coupled orientation/redundancy that simpler solvers cannot meet.
10. Integrate pose sharing, update throttling, networking correction resets, and FP/TP profiles.

## 10. Verification Strategy

### Correctness

- analytic two-bone results against geometric reference;
- reachable, exactly extended, unreachable, zero-length, mirrored, and near-singular cases;
- randomized goals within joint limits;
- multiple conflicting goals with priority permutations;
- target invalidation, teleport, correction, LOD switch, and warm-start reset;
- retargeted short/tall/long-limbed characters.

### Quality metrics

- effector position/angular residual;
- planted-foot slip;
- joint-limit hits and hyperextension;
- pelvis/root displacement;
- spine curvature/twist;
- frame-to-frame joint angular acceleration;
- contact acquisition/release continuity.

### Performance

Benchmark 40/80/120/180-bone rigs, 1–6 effectors, 2–20 iterations, and 1/10/100/500 characters. Capture solver time, iterations, affected bones, dirty-branch recomputes, scratch high-water mark, cache misses, SIMD utilization, job delay, allocations, and pose-share loss.

Acceptance gates:

- zero steady-state general-heap allocations;
- bounded iteration and scratch;
- no worker scene queries;
- high-priority contact residual within content budget or explicit failure;
- no NaN/nonfinite pose under fuzzing;
- deterministic contact/action state under replay;
- FBIK demonstrates quality benefit over analytic staged constraints at its intended interactions.

## 11. Risks and Open Decisions

- Position-based FBIK versus another whole-body solver for production.
- Approximate sequential tiers versus strict task-priority/null-space implementation.
- Root freedom and balance/center-of-mass proxy requirements.
- Stretching policy by stylized/realistic character class.
- Warm-start eligibility and reset rules.
- Per-platform iteration/tolerance budgets.
- Whether hand orientation is hard contact or soft style for weapons/interactions.
- Terrain query ownership and asynchronous trace latency.
- Non-humanoid chain solver requirements.
- Need for self-collision/body-intersection constraints.

## 12. Engineering Recommendations

1. Use analytic two-bone IK as the default humanoid limb solver.
2. Reserve FBIK for genuinely coupled multi-contact problems.
3. Compile solver topology, affected bones, limits, priorities, and bounded scratch offline.
4. Implement explicit lexicographic priority tiers; weights only arbitrate within a tier.
5. Clamp unreachable goals and report residuals instead of hiding failure with stretch or excessive iterations.
6. Treat preferred angles/pole vectors and joint limits as required rig data.
7. Start from the current input pose by default; warm-start presentation-only solves with explicit resets.
8. Exclude irrelevant bones and recompute only dirty model-space branches.
9. Replace FBIK progressively with analytic/disabled constraints through animation LOD.
10. Replicate targets/action state, never solved bones; gameplay reach uses deterministic envelopes.
11. Build visualizers for goals, priorities, limits, residuals, affected bones, iterations, and clamping.
12. Ship FBIK only after it beats staged analytic constraints on a defined quality/cost benchmark.

## 13. Source Links

- **[S1] Epic Games, IK Rig Solvers in Unreal Engine 5.8:** https://dev.epicgames.com/documentation/en-us/unreal-engine/ik-rig-solvers-in-unreal-engine
- **[S2] Epic Games, Control Rig Full-Body IK:** https://dev.epicgames.com/documentation/en-us/unreal-engine/control-rig-full-body-ik-in-unreal-engine
- **[S3] Epic Games, Full Body IK Node Reference:** https://dev.epicgames.com/documentation/en-us/unreal-engine/node-reference/ControlRig/FullBodyIK
- **[S4] Unity, Animation Rigging 1.4:** https://docs.unity3d.com/Packages/com.unity.animation.rigging@1.4/manual/index.html
- **[S5] Unity, Two Bone IK Constraint:** https://docs.unity3d.com/Packages/com.unity.animation.rigging@1.2/manual/constraints/TwoBoneIKConstraint.html
- **[S6] Aristidou and Lasenby, “FABRIK,” Graphical Models 2011:** https://andreasaristidou.com/publications/papers/FABRIK.pdf
- **[S7] Buss, “Introduction to Inverse Kinematics with Jacobian Transpose, Pseudoinverse and Damped Least Squares”:** https://people.csail.mit.edu/jbarry/spring2011PR2/readings/jactrans.pdf
- **[S8] Nakamura, Hanafusa, and Yoshikawa, “Task-Priority Based Redundancy Control of Robot Manipulators”:** https://journals.sagepub.com/doi/10.1177/027836498700600201

