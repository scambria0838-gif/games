# Operation Mythology Animation & Rigging Research

**Batch timestamp:** 2026-07-27 16:14:15 America/Los_Angeles  
**Subject:** Automated rig and clip validation, semantic-bone compression budgets, retarget matrices, and promotion gates  
**Scope:** Research and architecture only; modular generic ECS; data-oriented runtime; first-person and third-person support

## 1. Feature Overview

Animation defects are cheapest to reject before an asset becomes a runtime dependency. Operation Mythology therefore needs a deterministic validation pipeline that checks source import, skeleton topology, reference and retarget poses, skinning, clips, root motion, curves, events, constraints, compression, platform cooking, and runtime playback.

The central recommendation is a versioned **Animation Validation Contract**. It gives every rig, clip, mesh, weapon profile, retarget profile, and platform cook:

- Machine-readable compatibility and semantic metadata.
- Structural invariants that always fail when violated.
- Content-policy rules whose severity depends on asset role.
- Measured quality budgets for important semantic bones and virtual points.
- Deterministic test matrices across rigs, meshes, LODs, retarget profiles, representations, codecs, and platforms.
- A signed result manifest that gates derived-data publication and release promotion.

Compression acceptance must not rely on local transform error alone. Error accumulates through the hierarchy and is most visible at hands, feet, sights, muzzles, facial landmarks, attachments, contacts, and vertices far from their driving joints. A semantic budget policy should measure object/component-space displacement and orientation at representative points, then apply stricter thresholds to gameplay- and camera-sensitive semantics.

## 2. Existing Coverage and Identified Gap

The required recursive scan found existing Operation Mythology coverage for:

- ACL-class SIMD clip compression, uncompressed reference comparison, mesh/end-effector error, partial decompression, required-bone masks, pose sharing, job scheduling, deformation, and allocation-free runtime sampling.
- Fixed-step root motion, typed events, rollback, IK/FBIK, motion matching, physical animation, and first-/third-person presentation.
- A deterministic asset-build DAG, immutable content-addressable derived data, validation before publication, and CI promotion.
- General automated checks for compressed versus raw poses, root paths, event crossing, sockets, IK convergence, temporal history, and pose-sharing compatibility.

The identified gap is the acceptance specification:

- No canonical error units and evaluation spaces per semantic bone or virtual point.
- No distinction between structural failures, policy failures, quality regressions, and advisory warnings.
- No asset-role profiles for locomotion, combat, traversal, cinematics, first-person weapons, facial clips, crowds, or physics rigs.
- No exhaustive definition of sampling between source keys, clip boundaries, loops, additive bases, time warps, or platform codec outputs.
- No retarget compatibility matrix across source rig, target rig, body proportions, reference pose, mesh, clip class, and IK correction profile.
- No content-to-runtime manifest proving which validations and codec settings produced a cooked artifact.
- No statistical regression policy for large libraries or quarantine mechanism for intentionally waived defects.

GPU/compute deformation was not selected for this batch because the scanned `GAME SKILLS` report already contains substantial baseline coverage for skin cache reuse, cloth/morph ordering, motion-vector history, ray tracing, memory caps, and validation.

## 3. Sourced Facts

### Official specifications and engine documentation

- Unreal Engine 5.8 Data Validation supports custom asset validators, validation of assets and dependencies, command-line execution for continuous integration, and rules for conventions, performance budgets, and dependency cycles. [Epic Games, Data Validation]
- Unreal animation compression selects codecs against an error threshold, supports curve-error thresholds and an explicit error sample rate, and can force selection below a threshold even when size increases. [Epic Games, Animation Compression]
- Unreal’s codec reference includes adaptive policies based on downstream end-effector error, tighter treatment for end effectors with sockets, and limits on how much of the total error budget one track may consume. [Epic Games, Animation Compression Codec Reference]
- Animation Compression Library approximates deformation error with a rigid shell around a joint and measures the transformed shell through the hierarchy. Its author explains that local-space error alone misses accumulated downstream error. [ACL documentation and Frechette, GDC 2017]
- Khronos glTF 2.0 requires unique skin joints, a common hierarchy root, joint/inverse-bind ordering consistency, valid joint indices, nonnegative weights, and normalized weight sums. Animation time inputs have format and ordering requirements. [Khronos Group, glTF 2.0 Specification]
- The Khronos glTF Validator is a reference implementation intended to report specification violations, warnings, and hints, including malformed skin and animation data. [Khronos Group, glTF Validator]
- Unreal IK retargeting requires defined source and target rigs, retarget roots and chains, correct chain mappings, and matching or corrected retarget poses; Epic specifically calls out A-pose/T-pose differences as a source of inaccuracy. [Epic Games, Retargeting Bipeds with IK Rig]
- Unity exposes animation compression error controls and advises lower allowed error where high precision is required. Its humanoid import workflow maps source bones into an Avatar used to play humanoid animation. [Unity Technologies, Animation Clip and Avatar documentation]

### Technical consequences supported by the sources

- Validation belongs in both interactive authoring and automated CI/cook paths.
- Format validity is necessary but insufficient: a legal asset may still violate game semantics, performance budgets, or visual quality.
- A hierarchy-aware, mesh/end-effector-aware error metric is more representative than independent local-track differences.
- Retarget quality depends on the source/target characterization and reference/retarget pose, not only the animation clip.
- Compression thresholds can and should vary with content precision needs.

### Engineering recommendations versus facts

All severity levels, semantic classes, numerical budget ownership, manifests, ECS interfaces, test matrices, sampling policies, and rollout stages below are Operation Mythology engineering recommendations. Numerical thresholds must be calibrated with project assets and target displays; this report deliberately does not invent universal centimeter or degree values.

## 4. Industry-Standard Animation API or Pattern

### Validation as a staged compiler contract

Treat animation import and cooking as a compiler pipeline:

1. **Parse and format validation:** bounded counts, finite values, legal indices, monotonic times, normalized rotations, valid matrices, and supported encodings.
2. **Canonicalization:** units, handedness, axes, quaternion sign convention, sampling domain, stable IDs, skeleton order, and reference-pose representation.
3. **Structural validation:** hierarchy, semantic mappings, skin influences, inverse binds, required sockets, retarget chains, physics mappings, and LOD closure.
4. **Semantic validation:** clip role, root-motion policy, contacts, events, additive base, looping, phase curves, weapon grips, and FP/TP compatibility.
5. **Quality evaluation:** raw versus compressed, source versus retargeted, and LOD versus reference using semantic points and mesh samples.
6. **Performance analysis:** compressed bytes, tracks, bones, samples, decompression work, blend/IK needs, memory, and consumer masks.
7. **Runtime conformance:** deterministic playback in the actual runtime sampler/codec and platform cook.
8. **Promotion:** publish derived artifacts only with a successful versioned validation manifest.

### Severity pattern

- **Fatal:** unsafe or undecodable data; non-finite transforms; cyclic hierarchy; out-of-range joint; singular required inverse bind; invalid time ordering; artifact/runtime version mismatch.
- **Error:** violates a required game contract; missing semantic bone/socket; disallowed root motion; compression budget exceeded; broken retarget chain; duplicate authoritative event identity.
- **Warning:** legal but suspicious; extreme scale; unused bone; tiny key interval; low weight sum repaired within policy; excessive key density; marginal reach.
- **Advisory:** optimization or cleanup opportunity with no promotion impact.

Every diagnostic should include stable rule ID, asset ID/version, subresource, bone/track/event/time, observed value, allowed value, source/cook provenance, and remediation text.

### Semantic quality pattern

Define stable semantic classes rather than authoring thresholds by raw bone name:

- `GameplayRoot`, `MotionRoot`, `Pelvis`
- `FootContact`, `ToeContact`
- `PrimaryHand`, `SupportHand`, `FingerGrip`
- `Sight`, `Muzzle`, `WeaponAttachment`, `InteractionSocket`
- `Head`, `CameraAnchor`, `LookAt`
- `FaceLandmark`, `Jaw`, `Eye`
- `ClothDriver`, `HairDriver`, `PhysicsDriver`
- `GenericDeformation`, `Twist`, `Helper`

Each semantic maps to one or more bones plus **measurement probes**. A probe is a point and optional orientation frame in bone-local space. Long virtual offsets detect rotation error that would be invisible at the joint origin.

### Golden-reference pattern

Keep an immutable canonical reference:

- Raw or losslessly normalized clip samples.
- Canonical skeleton/reference pose and semantic map.
- Source event/curve/root-motion streams.
- Deterministic retarget profile and target reference poses.
- Representative mesh vertices or bounded virtual shells.

Compare every cooked platform artifact through the same runtime decoder against that reference. Do not compare one compressed build only against another compressed build.

## 5. Runtime and Content-Pipeline Performance

### Offline evaluation complexity

Let:

- `C` = clips under test
- `S` = sampled times per clip
- `B` = evaluated bones
- `P` = semantic/mesh probes
- `R` = target rig/mesh/retarget combinations
- `K` = codec/platform candidates

A straightforward full validation pass is approximately `O(C × R × K × S × (B + P))`, plus retarget and constraint work. Exhaustive matrices become expensive quickly, so validation must use dependency-aware tiers:

- Fast structural and changed-asset checks on save.
- Exact changed asset plus affected dependency closure on submission.
- Representative target matrix on ordinary CI.
- Full library/platform/retarget matrix on scheduled or release cooks.

Cache results by content digest of every declared input: source clip, canonical skeleton, semantic map, mesh/probes, retarget profile, codec/settings, validator version, runtime decoder version, and platform math mode.

### Sampling and missed peaks

Checking only authored keys or the output sample rate can miss interpolation and retarget peaks. Use:

- All source keys and compressed segment boundaries.
- Midpoints or an adaptive subdivision where error curvature is high.
- Clip start/end, loop seam, event boundaries, contact windows, additive-base frame, and root-motion phase boundaries.
- Runtime interpolation and rounding modes exactly matching production.
- A minimum verification rate for uniformly sampled data, plus targeted oversampling for camera, weapon, face, fast rotation, and contact semantics.

Store the worst sample and a distribution summary. Maximum error catches spikes; percentiles and integrated error distinguish persistent degradation from one isolated peak. Promotion should gate on maximum hard limits and optionally on percentile/regression limits.

### Bone counts and required chains

Structural validation is linear in skeleton bones and mesh influences. Precompute:

- Parent order, depth, descendants, and cycle result.
- Semantic bone and probe spans.
- Required closure for render, sockets, IK, physics, cloth/hair, shadows, ray tracing, root motion, and events.
- LOD remap and fallback semantic mappings.

An LOD cannot remove a parent required to evaluate a retained descendant. A render LOD may omit deformation influence from a bone while an attachment or gameplay consumer still requires its transform.

### Compression and decompression

- Compression is offline and may test multiple codecs/settings; runtime decompression must remain allocation-free.
- Validate with the production decoder, CPU feature path, interpolation mode, and platform precision.
- Record compressed bytes per second, bytes per bone-second, tracks decoded per pose, and measured decompression throughput—not only compression ratio.
- Separate transform, curve, root-motion, and event-stream budgets.
- A codec win is acceptable only if it stays within semantic quality limits and runtime CPU/cache budgets.

### Blend and additive validation

Single-clip acceptance does not prove graph composition:

- Test representative blend pairs and weights for pose collapse, scale drift, quaternion discontinuity, additive-base mismatch, and contact loss.
- Validate additive clips against their declared base skeleton, base clip/frame, and mesh-space/local-space policy.
- Exercise masks and layers to ensure semantic probes remain within limits when partial tracks are omitted.
- Sample transition boundaries and inertialization history resets.

The matrix should remain bounded: select graph-contract cases, not every possible blend permutation.

### IK and constraint costs

Retarget acceptance may include analytic limb correction or bounded FBIK:

- Record iterations, convergence, residual, reach clamp, joint-limit hits, pole flips, and failure reason.
- Use fixed iteration/tolerance profiles per validation tier.
- A retargeted clip cannot hide large base-pose or chain-map errors behind excessive runtime IK work.
- Gate both final residual and required solver cost, because a visually acceptable result that doubles runtime iterations is still a regression.

### Cache behavior, SIMD, and allocations

- Store reference and decoded transforms in aligned structure-of-arrays buffers.
- Batch by skeleton, codec, platform, and sample time to reuse hierarchy and decoder state.
- Keep probe definitions and bone remaps contiguous.
- Use per-worker arenas with bounded high-water marks; report any heap allocation after warm-up as a validator defect.
- SIMD and scalar reference paths should agree within an explicit numerical tolerance; run cross-path differential tests.
- Avoid retaining every sampled pose. Stream reductions into per-rule maxima, histograms, and a small worst-case capture set.

### Job scheduling

Run assets/combinations as independent jobs with resource-class limits:

- CPU codec/pose jobs.
- High-memory mesh-probe jobs.
- Licensed DCC/export validation.
- Platform-emulation or device jobs.

Use deterministic reduction ordering for aggregate statistics and stable diagnostics. Prevent thousands of tiny per-bone jobs; a clip/combination or a batch of short clips is the useful granularity.

### Pose sharing and animation LOD

Validation must prove pose-sharing compatibility keys:

- Same skeleton/retarget basis, required-bone mask, phase policy, root-motion policy, clip set, additive state, and semantic consumers.
- Follower overlays and per-instance IK must be excluded from the shared base result and tested after divergence.

For each animation LOD:

- Validate semantic availability, fallback sockets, event/root-motion continuity, and maximum pose difference from the next higher LOD.
- Measure the actual cost reduction in evaluated bones, decoded tracks, blends, IK iterations, palette bytes, and deformation work.
- Test LOD switches with pose/history seeding to prevent pops and invalid motion vectors.

### Networking and fixed-step synchronization

- Validate root-motion and authoritative event streams at fixed simulation tick boundaries independent of render sampling.
- Quantize/dequantize replicated action phase, aim, and root-motion inputs, then compare predicted/replayed results.
- Run rollback and correction at event/contact/loop boundaries and assert stable event identity and durable-state deduplication.
- Do not validate networking by comparing bone poses bit-for-bit unless a specific deterministic pose feature requires it. Validate authoritative state and bounded presentation divergence instead.

### Memory budgets

Manifests should report:

- Raw and compressed clip bytes; transform/curve/event/root partitions.
- Skeleton, semantic map, retarget profile, probe, and validation metadata.
- Runtime graph state, pose scratch, decoded track count, palettes, and previous-pose histories.
- Residency per clip set and worst-case equipment/FP+TP combination.

Promotion policies can gate absolute size, bytes per second, regression percentage, and package/residency group totals.

## 6. Pros and Cons

### Semantic probe and hierarchy-aware compression budgets

**Pros**

- Measures error where players see it and gameplay consumes it.
- Prevents small parent rotation errors from becoming large hand, sight, or foot displacement.
- Allows aggressive compression on low-value helpers while protecting critical contacts and camera/weapon alignment.

**Cons**

- Requires maintained semantic maps, probes, mesh samples, and asset-role profiles.
- Threshold calibration is content- and scale-dependent.
- More expensive than per-track local comparisons.

### Full deterministic promotion gate

**Pros**

- Defects are reproducible and tied to exact source/tool/settings versions.
- Invalid derived artifacts cannot enter trusted caches or releases.
- Enables trend analysis and safe bulk recompression.

**Cons**

- Full rig/mesh/platform matrices can be costly.
- Overly strict rules may block iteration if severity and waiver policy are poorly designed.
- DCC exporters and third-party assets may need canonicalization before they pass.

### Visual-only review

**Pros**

- Human reviewers detect style, intent, silhouette, appeal, and context that numerical rules cannot.

**Cons**

- Non-exhaustive, subjective, slow, and poor at catching rare times/combinations.
- Cannot replace structural, runtime, determinism, or performance validation.

The recommendation is automated gating plus targeted visual review, not either alone.

## 7. ECS Architectural Integration

Validation is primarily an offline service, but its outputs become runtime contracts.

Recommended asset-side records:

- `SkeletonContract`: version, hierarchy digest, reference pose, units/axes, semantic map, required closures, LOD maps.
- `ClipContract`: clip role, skeleton compatibility, duration/sample domain, loop/additive/root policies, curves, events, contacts.
- `RetargetContract`: source/target skeleton versions, roots/chains, reference poses, scale policy, solver/correction profile.
- `CompressionPolicy`: asset role, semantic budget table, sampling policy, codec candidates, platform overrides.
- `ValidationManifest`: input digests, validator/rule versions, platform, results, waivers, statistics, artifact digest.
- `RuntimeAnimationManifest`: compact subset required to reject incompatible runtime combinations.

Recommended ECS-facing components:

- `SkeletonComponent { skeletonAsset, contractVersion }`
- `AnimationGraphComponent { graphAsset, compatibilityKey }`
- `AnimationClipSet { manifestHandle, generation }`
- `RetargetProfileComponent { profileHandle, sourceVersion, targetVersion }`
- `AnimationLODState { lod, requiredMaskId, policyGeneration }`
- `AnimationValidationTag { artifactDigest, manifestVersion, promotionTier }`

Runtime systems should not execute the full validator. Asset activation performs constant- or low-linear-cost compatibility checks:

- Generation/version match.
- Skeleton/clip/graph compatibility.
- Required semantic/socket presence.
- Platform codec/runtime decoder support.
- LOD and retarget manifest compatibility.

On failure, activation returns a typed error and selects an explicit fallback asset; it never silently binds by similar bone names.

## 8. Rig, Pose, Graph, Constraint, and Event Interfaces

### Rig validation interface

`SkeletonValidationInput`

- Stable asset and source IDs.
- Parent indices and evaluation order.
- Reference local transforms and inverse binds.
- Bone names plus stable semantic IDs.
- Mesh influence streams and bounds.
- Required sockets, constraints, physics bodies, retarget chains, and LOD maps.

Rules include:

- One valid hierarchy root policy; no cycles or duplicate stable IDs.
- Finite transforms, valid normalized rotations, permitted scale, invertible required binds.
- Parent-before-child ordering or a deterministic cooked reorder map.
- Influence indices in range, nonnegative weights, normalized sums, maximum influence count, no unintended unweighted vertices.
- Required semantic mappings unique where uniqueness is required.
- Required bone closure for every consumer and LOD.
- Reference-pose orientation/length/side conventions within rig-family policy.

### Clip validation interface

`ClipValidationInput`

- Skeleton contract/version.
- Clip role and tags.
- Sample times/tracks, interpolation policy, duration, loop and additive metadata.
- Root-motion, curve, phase, contact, and event streams.
- Compression candidates and decoded platform outputs.

Rules include:

- Finite, ordered times and values; legal duration and sample domain.
- Quaternion normalization/continuity and scale policy.
- Track-to-bone uniqueness and skeleton compatibility.
- Loop seam pose/root/curve/contact policy.
- Additive base compatibility and declared space.
- Root-motion class, axes, displacement, speed, acceleration, and loop accumulation.
- Curve range/monotonicity where semantic.
- Event schema, stable ID source, ordering, window pairing, and valid phase.

### Quality interface

`SemanticProbe`

- Semantic ID and importance class.
- Driving bone index.
- Local point and optional orientation frame.
- Measurement space.
- Translation, angular, velocity, and optional screen-space budgets.
- Applicable clip roles, representations, LODs, and platforms.

`QualityResult`

- Rule/policy version and combination key.
- Maximum and percentile error.
- Worst clip time, bone/probe, and source/compressed transforms.
- Root, curve, event, contact, and retarget deltas.
- Compressed bytes and measured decoder cost.

### Constraint interface

`RetargetValidationCase`

- Source clip/skeleton.
- Target skeleton/mesh and retarget pose.
- Chain map and correction profile.
- Contact and effector probes.
- Allowed residual, limit-hit, pole-flip, and iteration policies.

### Event interface

Validation diagnostics are data records, not arbitrary callbacks. Worker jobs append into bounded buffers; a deterministic merge sorts by asset, combination, rule, subresource, and time.

Animation content events are validated against the previously defined typed event schema:

- Gameplay-capable events require a declared authority source.
- Window begin/end semantics must survive sampling, looping, reverse/seek policy, compression, and fixed-step crossing.
- FP and TP clips that represent one action share semantic event identity without issuing duplicate durable mutations.

## 9. Content and Runtime Integration Plan

### Phase 1: Contract and baseline

- Freeze stable semantic IDs and asset-role taxonomy.
- Define rule IDs, severity, waiver schema, and deterministic diagnostic format.
- Preserve canonical raw/losslessly normalized reference clips.
- Record current library results without blocking promotion to establish a baseline.

### Phase 2: Structural gates

- Gate finite values, hierarchy, binds, influences, time order, skeleton compatibility, semantic requirements, LOD closure, root/additive policy, and event schema.
- Integrate changed asset plus dependency validation into authoring and submission.
- Store results in the existing deterministic asset DAG.

### Phase 3: Compression quality

- Add hierarchy-aware semantic probes and representative mesh samples.
- Decode each platform artifact through the production runtime decoder.
- Define role-specific budget profiles with animation, gameplay, and performance owners.
- Add size/decompression regression reporting and bulk recompression comparison.

### Phase 4: Retarget and graph cases

- Build source/target/mesh/proportion matrices for supported character families.
- Add representative blend, mask, additive, IK, contact, root, and LOD-transition cases.
- Capture visual diffs only for worst numerical cases and curated golden scenes.

### Phase 5: Networking and production promotion

- Add fixed-step root/event, prediction, rollback, and quantization cases.
- Require a successful manifest before trusted derived-data or release publication.
- Add dashboard trends, owner routing, expiration-bound waivers, and scheduled full-library/platform runs.

## 10. Verification Strategy

### Validator correctness

- Unit-test every rule with one minimal valid asset and one minimal failure fixture.
- Differential-test scalar and SIMD decoders, offline and runtime hierarchy propagation, and reference versus cooked sampling.
- Property/fuzz-test malformed counts, indices, time arrays, weights, matrices, recursion depth, compressed streams, and manifests.
- Verify deterministic diagnostics and manifests across machine, worker count, locale, and repeated builds.
- Mutate one declared input at a time and assert cache invalidation.

### Compression quality

- Sample raw and cooked clips at keys, boundaries, adaptive midpoints, loops, contacts, events, and semantic high-motion intervals.
- Compare local transforms for debugging, but gate hierarchy-aware component/object-space probes.
- Include orientation probes for hands, sights, muzzles, feet, head/camera, and facial landmarks.
- Measure root displacement/yaw, accumulated loop drift, velocity/acceleration, curve error, and event-time quantization separately.
- Test high-error semantic bones with representative attachments and mesh vertices.

### Rig and skinning

- Validate hierarchy, reference pose, inverse binds, handedness, scale, joint indices, weight sums, influence caps, zero-weight vertices, and LOD remaps.
- Pose every bone and semantic chain through bounded test rotations to reveal wrong binds, mirrored axes, detached vertices, and missing influences.
- Exercise extreme supported morphs/proportions and ensure bounds contain deformed output.

### Retargeting and constraints

- Run representative locomotion, turn, jump, attack, traversal, interaction, equip, FP weapon, and recovery clips across every supported target family.
- Measure foot/hand contact drift, root/pelvis scaling, limb reach, joint-limit hits, solver residual/iterations, pole flips, and twist distribution.
- Compare target retarget pose version and reject stale cooked results.

### Graph, events, fixed-step, and networking

- Test representative blends, masks, additive bases, montages/layers, inertialization, and LOD switches.
- Cross event/contact windows at every supported fixed-tick ratio, loop, reverse, seek, skipped presentation update, rollback, and correction.
- Assert stable event identity and no duplicate damage, ammo, ownership, cooldown, or interaction mutation.
- Validate FP and TP phase alignment without requiring identical presentation poses.

### Performance gates

For each platform tier, report and gate as appropriate:

- Clip size and residency totals.
- Decompressed tracks/bytes, cycles or time per pose, scalar/SIMD path, cache behavior.
- Evaluated bones, blend samples, IK iterations, pose scratch, allocations.
- Pose-sharing bucket compatibility and savings.
- LOD cost and switch quality.
- Job occupancy, queue delay, critical path, and main-thread commit tail.

### Visual review

Automatically render worst-case probe times and curated golden sequences with:

- Raw and cooked overlays.
- Bone axes, probes, contact paths, root trajectory, retarget source/target, and residual vectors.
- FP camera/weapon sight and TP/world views where applicable.

Human approval remains required for style and appeal, but cannot waive fatal format/runtime safety defects.

## 11. Risks and Open Decisions

- Numerical budgets by semantic class, clip role, world scale, platform, representation, and camera FOV.
- Whether budgets gate maximum only or maximum plus percentile/integrated error.
- Representative mesh vertices versus virtual shells, and how probes follow mesh/skin revisions.
- Minimum and adaptive sample density needed to bound unsampled interpolation peaks.
- Which retarget rig/mesh combinations run on submission, nightly, and release tiers.
- How much IK correction is allowed before a retarget profile is considered structurally wrong.
- Rules for authored non-unit scale, negative/mirrored scale, twist/helper bones, and unusual creatures.
- Loop seam tolerances by cyclic, transitioning, montage, and one-shot clip roles.
- Root-motion and event time representation used by fixed-step validation.
- Platform floating-point differences and scalar/SIMD acceptance tolerance.
- Waiver ownership, expiration, visibility, and whether a waiver may enter a trusted release namespace.
- Runtime fallback policy after a manifest/version mismatch.
- Storage and privacy policy for source reference clips and rendered visual diffs.

## 12. Engineering Recommendations

1. Implement a versioned Animation Validation Contract and make its successful manifest a prerequisite for trusted derived-data and release promotion.
2. Separate fatal format safety, required semantic correctness, measured quality, performance regressions, and advisory cleanup into stable rule severities.
3. Retain immutable raw/losslessly normalized reference clips and compare every platform cook through the production runtime decoder.
4. Gate compression with hierarchy-aware semantic probes and representative mesh points, not local bone error alone.
5. Assign stricter project-calibrated budgets to root, contacts, hands, sights, muzzles, camera/head, interactions, and facial landmarks; do not invent one global threshold.
6. Sample source keys, compressed boundaries, loop seams, contacts/events, adaptive midpoints, and graph-sensitive transitions using production interpolation rules.
7. Validate transform, curve, root-motion, and event streams separately; a pose codec pass must not imply event or gameplay correctness.
8. Build explicit retarget matrices keyed by source/target skeleton, reference/retarget pose, mesh/proportion family, clip role, and correction profile.
9. Gate both retarget residual quality and required IK iterations so runtime solver cost cannot conceal a poor rig mapping.
10. Validate every animation LOD’s semantic closure, quality delta, event/root continuity, measured savings, and switch history.
11. Use dependency-digest caching and tiered changed/submission/nightly/release matrices to keep exhaustive validation affordable.
12. Run validation jobs allocation-free after warm-up, batch by skeleton/codec/platform, use SIMD-friendly buffers, and record cache/job telemetry.
13. Add fixed-step, prediction, rollback, quantization, FP/TP phase, and event-deduplication cases without replicating or requiring bit-identical presentation bones.
14. Provide deterministic structured diagnostics, worst-case captures, owner routing, and expiring documented waivers.
15. Keep targeted human visual review for intent and appeal while making structural, runtime, and promotion-safety failures non-waivable.

## 13. Source Links

1. Epic Games, **Data Validation**, Unreal Engine 5.8:  
   https://dev.epicgames.com/documentation/en-us/unreal-engine/data-validation-in-unreal-engine
2. Epic Games, **Animation Compression**, Unreal Engine 5.8:  
   https://dev.epicgames.com/documentation/en-us/unreal-engine/animation-compression-in-unreal-engine
3. Epic Games, **Animation Compression Codec Reference**, Unreal Engine 5.8:  
   https://dev.epicgames.com/documentation/en-us/unreal-engine/animation-compression-codec-reference-in-unreal-engine
4. Epic Games, **Animation Compression Library**, Unreal Engine 5.8:  
   https://dev.epicgames.com/documentation/en-us/unreal-engine/animation-compression-library-in-unreal-engine
5. Nicholas Frechette, **Simple and Powerful Animation Compression**, GDC 2017:  
   https://nfrechette.github.io/public/simple_and_powerful_animation_compression_gdc2017.pdf
6. Nicholas Frechette, **Dominance Based Error Estimation**, Animation Compression Library:  
   https://nfrechette.github.io/2023/02/26/dominance_based_error_estimation/
7. Animation Compression Library source and documentation:  
   https://github.com/nfrechette/acl
8. Khronos Group, **glTF 2.0 Specification — Skins and Animations**:  
   https://registry.khronos.org/glTF/specs/2.0/glTF-2.0.html
9. Khronos Group, **glTF Validator**:  
   https://github.com/KhronosGroup/glTF-Validator
10. Epic Games, **Retargeting Bipeds with IK Rig**, Unreal Engine 5.8:  
    https://dev.epicgames.com/documentation/en-us/unreal-engine/retargeting-bipeds-with-ik-rig-in-unreal-engine
11. Epic Games, **IK Rig Retargeting**, Unreal Engine 5.8:  
    https://dev.epicgames.com/documentation/en-us/unreal-engine/ik-rig-animation-retargeting-in-unreal-engine
12. Unity Technologies, **Animation Clip Import Settings**:  
    https://docs.unity3d.com/Manual/class-AnimationClip.html
13. Unity Technologies, **Importing Humanoid Animations**:  
    https://docs.unity3d.com/Manual/ConfiguringtheAvatar.html

