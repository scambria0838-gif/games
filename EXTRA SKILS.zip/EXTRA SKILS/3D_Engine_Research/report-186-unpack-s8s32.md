# 3D Engine Research Report #186

**Topic:** HLSL SM 6.6 Unpack (`unpack_s8s32` / `unpack_u8u32`)  
**Date:** 2026-07-31

## Finding

Hardware unpack of packed 8-bit DWORDs to int4/uint4 with sign/zero extension.

## Impact

- Deferred/G-Buffer unpack: ~20%–35% on unpack-heavy passes
- Replaces 8–12 shift/mask instructions with 1–2

## Verify

`float4(unpack_u8u32(packed)) / 255.0f` under SM 6.6+.
