# 3D Engine Research Report #187

**Topic:** HLSL SM 6.6 Unpack to 16-bit (`unpack_s8s16` / `unpack_u8u16`)  
**Date:** 2026-07-31

## Finding

Direct 8-bit → 16-bit vector unpack with `-enable-16bit-types`, avoiding 32-bit intermediate expansion.

## Impact

- Half-precision dequant / neural weight paths: ~30%–50% latency reduction claimed on those kernels
- Halves register width vs unpack-to-32 then truncate

## Verify

`dxc -T ps_6_6 -enable-16bit-types`
