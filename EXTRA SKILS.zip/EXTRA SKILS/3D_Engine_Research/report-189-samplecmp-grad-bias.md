# 3D Engine Research Report #189

**Topic:** HLSL SM 6.7 `SampleCmpGrad` / `SampleCmpBias`  
**Date:** 2026-07-31

## Finding

Explicit gradient and MIP-bias comparison sampling for PCF shadows outside pixel-shader quads (compute, mesh, ray).

## Impact

- Compute/RT soft shadows: ~30%–50% vs software multi-tap bilinear when HW TAU used
- Removes helper-lane dependency for anisotropic PCF in non-PS stages

## Verify

`-T cs_6_7` / `ps_6_7`, `D3D_SHADER_MODEL_6_7`, `SampleCmpGrad(samp, uv, cmp, ddx, ddy)`.
