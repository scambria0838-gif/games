# 3D Engine Research Report #192

**Topic:** HLSL SM 6.7 writable MSAA textures (`RWTexture2DMS` / Array)  
**Date:** 2026-07-31

## Finding

UAV write/atomics to individual MSAA subsamples from compute/mesh/pixel without RTV-only paths or flattened array copies.

## Impact

- Custom MSAA resolve / edge AA: ~25%–45%; up to 4×/8× VRAM savings vs flattened copies

## Verify

`msaaTex.sample[i][coord] = color;` under SM 6.7+.
