# 3D Engine Research Report #193

**Topic:** HLSL SM 6.7 quad control (`[WaveOpsIncludeHelperLanes]`, `QuadAny` / `QuadAll`)  
**Date:** 2026-07-31

## Finding

Explicit helper-lane persistence for wave ops feeding derivatives, plus 2×2 quad condition queries.

## Impact

- Fixes undefined helper demotion before `ddx`/`ddy` (MIP corruption)
- Quad-uniform material shading optimizations: ~15%–30% on affected PS paths

## Verify

Annotate PS with `[WaveOpsIncludeHelperLanes]`; use `QuadAny`/`QuadAll` under SM 6.7+.
