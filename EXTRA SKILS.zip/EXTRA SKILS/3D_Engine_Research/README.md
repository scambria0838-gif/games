# 3D Engine Research (Desktop drop)

Created so the scheduled **3D Engine Research Updates** task has a writable folder.

- Game Development agent ingest copy:  
  `C:\Cambria\sovereign-ai\skills\aegis\agents\game_engine\knowledge\desktop-ingest\3d-engine-research\`
- Digest: `SM65-67-HLSL-INTRINSICS.md` (also copied here)

Drop new `#NNN` reports into this folder; Game Dev agent indexes via `desktop-ingest/SOURCES.md`.
