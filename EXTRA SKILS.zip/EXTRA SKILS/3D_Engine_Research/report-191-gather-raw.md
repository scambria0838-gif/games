# 3D Engine Research Report #191

**Topic:** HLSL SM 6.7 `GatherRaw` / `GatherRawCmp`  
**Date:** 2026-07-31

## Finding

Raw unconverted 2×2 footprint DWORD fetch (no channel float conversion)—for custom bicubic, in-shader decompressors, NTC latents.

## Impact

- Custom filter / decompress paths: ~30%–50% vs 4× Load
- Needs castable DXGI formats for raw views

## Verify

`uint32_t4 texels = tex.GatherRaw(samp, uv);` under SM 6.7+.
