# DirectX 12 / HLSL Shader Model 6.5–6.7 — Game Dev digest

Ingested 2026-07-31 from scheduled **3D Engine Research Updates** reports #183–#193  
(and Microsoft / AMD public SM6.5–6.7 specs).  

**Purpose for Game Development agent:** know when UE5/DX12 paths can use these  
intrinsics; do **not** force them into Meter Drive-By browser/Three.js or toy HTML games.

Desktop mirror (for the scheduled writer):  
`C:\Users\steve\Desktop\EXTRA SKILS\3D_Engine_Research\`

---

## SM 6.5 — Partitioned wave multi-prefix

| Intrinsic | Use |
|-----------|-----|
| `WaveMultiPrefixSum` | Exclusive prefix sums per partition (`uint4 mask`) |
| `WaveMultiPrefixCountBits` | Multi-category stream compaction offsets |
| `WaveMultiPrefixProduct` / BitAnd / BitOr / BitXor | Partitioned reductions |

**Why it matters:** Replaces serial “waterfall” loops over material/entity categories  
in visibility buffers, particle compaction, light binning (~2–4× on those paths).

**Verify:** `-T cs_6_5`, `D3D_SHADER_MODEL_6_5`, PIX / RGP / Nsight for partition ISA.

---

## SM 6.6 — Pack / unpack 8-bit vectors

| Intrinsic | Use |
|-----------|-----|
| `pack_clamp_s8` / `pack_clamp_u8` | Quantize+clamp → `uint8_t4_packed` |
| `pack_s8` / `pack_u8` | Truncate low 8 bits (pre-clamped data) |
| `unpack_s8s32` / `unpack_u8u32` | Packed DWORD → int4/uint4 |
| `unpack_s8s16` / `unpack_u8u16` | Direct to 16-bit vectors (`-enable-16bit-types`) |

**Why it matters:** Cheaper G-Buffer / vertex attribute pack-unpack; less VGPR;  
good for ECS packed verts and neural weight dequant.

**Verify:** `-T cs_6_6` / `ps_6_6`, `D3D_SHADER_MODEL_6_6`.

---

## SM 6.7 — Sampling, gather, MSAA UAV, quads

| Feature | Use |
|---------|-----|
| `SampleCmpGrad` / `SampleCmpBias` | Explicit-gradient / bias PCF (compute, mesh, RT) |
| Dynamic `Offset` on Sample/Load/Gather | Runtime texel offsets ∈ [-8,7] in hardware |
| `GatherRaw` / `GatherRawCmp` | Raw 2×2 footprint DWORDs (custom filters / NTC) |
| `RWTexture2DMS` / Array | Compute writes to MSAA subsamples |
| `[WaveOpsIncludeHelperLanes]`, `QuadAny`/`QuadAll` | Stable derivatives + quad queries |

**Why it matters:** Better VSM/CSM in compute, cheaper SSAO/TAA kernels, custom  
MSAA resolve, fewer helper-lane MIP bugs.

**Verify:** Agility SDK 1.606+, `-T cs_6_7` / `ps_6_7`, `D3D_SHADER_MODEL_6_7`.

---

## When Game Development should apply this

| Project | Apply? |
|---------|--------|
| UE5 / DX12 native (Nanite-adjacent, custom shaders) | Yes — when targeting SM 6.5+ hardware |
| Forge3D procedural GLB pipeline | Rarely (CPU/trimesh); note for future GPU path |
| Meter Drive-By Three.js / browser | No — WebGL/WebGPU different stack |
| HTML/Python casual games | No |

## Source themes (reports)

- #183–184 Wave multi-prefix (+ bitwise)  
- #185–188 Pack/unpack 8-bit (32- and 16-bit)  
- #189–193 SampleCmpGrad/Bias, dynamic offsets, GatherRaw, RWTexture2DMS, quad control  

Public refs: Microsoft HLSL SM 6.5/6.6/6.7 specs, DirectX blog “In the Works”, AMD GPUOpen SM 6.7.
