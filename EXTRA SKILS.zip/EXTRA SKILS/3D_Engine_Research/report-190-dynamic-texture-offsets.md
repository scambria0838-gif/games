# 3D Engine Research Report #190

**Topic:** HLSL SM 6.7 runtime-variable texture sample offsets  
**Date:** 2026-07-31

## Finding

Agility SDK 1.606+ allows non-literal `int2`/`int3` offsets on Sample/Load/Gather (still in [-8,7] effective range), evaluated in the texture addressing unit.

## Impact

- Variable-kernel SSAO/DoF/TAA: ~20%–40% by dropping float UV offset ALU
- Kernel tables in cbuffers pass `samples[i]` directly

## Verify

`tex.Sample(samp, uv, variableOffset)` under SM 6.7+.
