# 3D Engine Research Report #183

**Topic:** HLSL SM 6.5 Wave Multi-Prefix Scan (`WaveMultiPrefixSum` / `WaveMultiPrefixCountBits`)  
**Date:** 2026-07-31

## Finding

Shader Model 6.5+ partitioned wave multi-prefix intrinsics evaluate prefix sums/counts across arbitrary SIMD partitions via `uint4 mask`, replacing serial waterfall loops over material/entity categories.

## Impact

- Multi-category visibility / particle / light binning compaction: ~2.5×–4× on those paths
- Complexity: O(categories × waterfall) → O(1) native partitioned prefix

## Verify

- Compile `-T cs_6_5` / `ps_6_5`
- Query `D3D_SHADER_MODEL_6_5`
- Inspect ISA in PIX / RGP / Nsight for partition prefix ops

## Sources

Microsoft HLSL Shader Model 6.5 specs; wave intrinsics references.
