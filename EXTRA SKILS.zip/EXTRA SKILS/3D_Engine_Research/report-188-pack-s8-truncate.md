# 3D Engine Research Report #188

**Topic:** HLSL SM 6.6 Fast bit-truncation pack (`pack_s8` / `pack_u8` without clamp)  
**Date:** 2026-07-31

## Finding

Direct low-8-bit truncation pack for pre-scaled/pre-clamped data, skipping min/max clamp units used by `pack_clamp_*`.

## Impact

- Pre-quantized attribute pack: ~30%–45% vs clamp variants when data already in range
- Accepts 16-bit and 32-bit vector inputs

## Verify

`pack_u8(u16Vector)` / `pack_s8(i32Vector)` under SM 6.6+; confirm no clamp ISA.
