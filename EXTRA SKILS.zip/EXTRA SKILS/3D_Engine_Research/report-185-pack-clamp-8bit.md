# 3D Engine Research Report #185

**Topic:** HLSL SM 6.6 Packed 8-bit quantization (`pack_clamp_s8` / `pack_u8`)  
**Date:** 2026-07-31

## Finding

Native pack of 4-component vectors into `uint8_t4_packed` in one instruction vs manual shift/mask/OR sequences.

## Impact

- G-Buffer / vertex attribute pack: ~25%–40% fewer ISA ops on pack paths
- Lower VGPR pressure for quantized attributes

## Verify

`-T cs_6_6`, `D3D_SHADER_MODEL_6_6`, RGA/Nsight for byte-permute pack.
