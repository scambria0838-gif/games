# 3D Engine Research Report #184

**Topic:** HLSL SM 6.5 Wave Multi-Prefix Bitwise (`WaveMultiPrefixBitAnd` / `BitOr` / `BitXor`)  
**Date:** 2026-07-31

## Finding

Partitioned bitwise prefix reductions across lane groups sharing a category mask—without LDS waterfall loops for heterogeneous light/material bitmasks.

## Impact

- Clustered light tile masks / multi-category feature flags: ~2×–3.5×
- Removes groupshared + barrier patterns for many bitmask aggregations

## Verify

`WaveMultiPrefixBitOr(flags, categoryMask)` under SM 6.5+; check SPIR-V / DXIL partition ops.
