# Operation Mythology Research Report

## Scalable Navigation Queries, Hierarchical Routing, Path Caching, Incremental Replanning, and Local Avoidance

**Timestamp:** 2026-07-27 01:49:41 America/Los_Angeles  
**Status:** New baseline for an uncovered domain  
**Assumptions:** Generic modular ECS, data-oriented memory, tiled navigation meshes and/or navigation graphs, first-person and third-person play, world streaming, no production-code implementation.

## Feature Overview

Navigation is a layered service, not one A* call. A production agent needs:

1. projection of start and goal onto valid navigation data;
2. a coarse route across regions, cells, sectors, or portals;
3. a detailed polygon corridor on resident navmesh;
4. a smoothed sequence of corners or trajectory targets;
5. path following that maintains the corridor despite locomotion error;
6. local avoidance around moving agents and short-lived obstacles;
7. invalidation and repair when costs, links, tiles, goals, or world residency change.

The recommended architecture separates:

- **global topology:** stable region/portal graph used for long range routing and streaming demand;
- **local topology:** tiled navmesh or specialist graph used for exact traversability;
- **path corridor:** an ordered polygon/link sequence with revisions;
- **trajectory:** short-horizon corners, speeds, facing, and traversal actions;
- **local avoidance:** bounded-neighborhood velocity selection;
- **query scheduling:** prioritized, time-sliced jobs with strict memory and expansion caps.

This separation prevents a moving barrel, another NPC, or minor steering deviation from causing full-world replanning. It also prevents a visually smooth path from being mistaken for a valid topological route.

## Existing Coverage and Identified Gap

The required recursive scan of `C:\Users\steve\Desktop\GAME SKILLS` found eight files: seven research reports plus the research index. Covered subjects are GPU residency, GPU-driven rendering, render graphs, shading paths, virtual geometry/textures, archetype ECS/job scheduling, and temporal reconstruction. The refreshed index still lists world partition and performance gates as uncovered; it contains no baseline for navigation query architecture.

The dedicated output folder `C:\Users\steve\Desktop\EXTRA SKILS\LEVEL DESIGN AI PERFORMANCE` was empty at the start of this batch.

The previous run, saved outside this new folder before the location change, established a world-cell state machine, partitioned nav chunks, a coarse portal graph, and corridor-driven prefetch. It did not settle:

- A* versus Dijkstra selection;
- query budgets and cancellation;
- path-cache keys and invalidation;
- corridor repair and path smoothing;
- incremental replanning adoption criteria;
- dynamic obstacle policy;
- local avoidance selection and density limits;
- off-mesh link reservations;
- navigation concurrency, memory pools, and worst-case safeguards.

This report fills those gaps without repeating the prior world-partition baseline.

## Sourced Facts

The following are source-backed facts; the recommendations later in the report are engineering judgments.

1. Epic's Unreal Engine navigation documentation describes a navmesh divided into tiles and convex polygons. Polygons form a graph, can have traversal costs, and can connect non-contiguous areas through navigation links.

2. Unreal exposes Static, Dynamic Modifiers Only, and Dynamic generation modes. This establishes that base geometry rebuild and runtime cost/blocking modification are separable policies.

3. Unreal Engine 5.8 documents two avoidance systems: RVO and Detour Crowd. Epic states that RVO chooses velocity using nearby agents but does not use the navmesh and can move an agent out of navigable bounds. Detour Crowd combines adaptive velocity sampling with corridor visibility and topology optimization. Epic recommends using the two systems exclusively rather than simultaneously.

4. Detour's official code describes `dtPathCorridor` as a dynamic polygon corridor that updates when agent locomotion deviates. It provides corner extraction, visibility optimization, topology optimization, position/target movement, invalid-path trimming, and look-ahead validity checks. The code warns that large movement increments may require replanning because its local mesh queries have limited range.

5. Recast Navigation's official repository identifies Detour as its runtime navmesh loading/pathfinding/query layer, DetourTileCache as navmesh streaming support for large/open worlds, and DetourCrowd as movement, collision avoidance, and crowd simulation.

6. The HPA* paper partitions maps into linked clusters, caches local crossing distances, and searches a hierarchy. Its experiments reported up to a tenfold speed improvement over optimized A* with paths within one percent of optimal on tested maps. This is evidence for hierarchical abstraction, not a universal guarantee.

7. The D* Lite paper combines incremental and heuristic search and reuses information across a series of similar search tasks. Its authors prove algorithmic properties and report benefits for studied unknown-terrain replanning tasks. It does not establish that D* Lite is always cheaper than restarting A* in games.

8. The ORCA research formulates reciprocal collision avoidance as permitted velocity half-planes and selects velocity using a low-dimensional linear program. The formal result assumes simplified agent models and reciprocal participation; dense infeasible cases require a safest-possible fallback.

9. Unreal exposes distinct regular-path-point and navigation-link acceptance radii and a policy for accepting partial paths. This supports explicit movement-contract semantics rather than one universal arrival tolerance.

## Industry-Standard API, Algorithm, or Pattern

### Query contract

A `PathRequest` should contain:

- stable requester and request generation;
- start and goal in global coordinates;
- agent/traversal profile;
- area-cost/filter profile;
- allowed off-mesh link classes;
- required path quality: exact, bounded-suboptimal, partial allowed, reachability only;
- deadline and priority;
- maximum nodes, memory, and wall/job time;
- world/nav revision snapshot;
- optional prior corridor or cache hint.

Return `PathResult` with:

- complete, partial, unreachable, cancelled, stale, overflow, or data-missing status;
- coarse route and detailed corridor handles;
- corner/trajectory prefix;
- total and partial cost;
- revisions and dependency tiles/links;
- reason for partial or failure;
- diagnostic counters.

Cancellation is generation-based. A result is published only if requester generation, goal, filter, and relevant navigation revisions remain compatible.

### A*, Dijkstra, and hierarchy

Use A* for point-to-point routing with an admissible heuristic when optimality is required. Dijkstra is A* with zero heuristic and is appropriate for:

- multi-goal distance fields;
- range/reachability queries;
- influence/cost maps;
- reverse searches shared by many agents;
- validation/reference tests.

For long paths, run A* on a coarse region/portal graph, request the required nav tiles, then refine the first corridor segments on detailed navmesh. Maintain a refinement horizon beyond stopping distance and expected replanning latency.

Use weighted A* only behind a declared quality contract. Weight greater than one reduces search effort by accepting bounded or measured suboptimality; never silently substitute it for optimal A*.

### Open and closed storage

Use:

- binary heap or 4-ary heap for the open set;
- node pool indexed by polygon/node reference;
- compact generation stamps rather than clearing full arrays;
- parent, `g`, and status fields in structure-of-arrays form;
- fixed-capacity scratch blocks from per-worker pools.

Duplicate-push heaps can outperform decrease-key implementations if stale entries are cheaply rejected and capacity is bounded. Benchmark both against target graph degree and cache behavior.

### Path corridor and smoothing

The authoritative path is a corridor of polygons and off-mesh links. Produce immediate steering corners by funnel/string-pulling through corridor portals. Apply optional curvature, acceleration, turn-radius, stance, and animation constraints afterward.

Smoothing must:

- remain inside the corridor with agent-radius clearance;
- preserve mandatory off-mesh links and authored traversal points;
- respect one-way links and area/filter changes;
- stop at unrefined or unloaded boundaries;
- be revalidated after nav revision changes.

Do not apply unconstrained spline smoothing to collision-free corners. A visually pleasing spline can leave navigable space or cut through geometry.

### Path caching

Use three cache levels:

1. **Coarse route cache:** region/portal sequences keyed by start region, goal region, traversal/filter class, gameplay-layer state, and coarse graph revision.
2. **Shared flow/distance result:** reverse Dijkstra or flow field for many agents pursuing a common goal.
3. **Agent corridor reuse:** retain and repair the agent's current polygon corridor as it moves or its target shifts slightly.

Avoid caching arbitrary full polygon paths by exact coordinates. Low hit rate, large keys, and broad invalidation usually outweigh benefits.

Each cached entry records dependency region/tile/link revisions. Invalidation is dependency-driven, not a global “nav changed” flush. Use memory-capped LRU/segmented queues with hit, stale-hit, repair, and eviction telemetry.

### Incremental replanning

Adopt a ladder:

1. validate a near-term corridor look-ahead;
2. trim invalid suffix and retain valid prefix;
3. locally reconnect around changed polygons;
4. rerun detailed A* inside the same coarse route;
5. rerun coarse routing;
6. use D* Lite/LPA* only for query classes with repeated goals and localized cost changes that demonstrate measured benefit.

Incremental search stores more per-query state and can suffer when changes are broad, the goal changes often, or the previous search explored little useful topology. It should be a specialist capability, not the default for every NPC.

### Dynamic obstacles and off-mesh links

Classify obstacles:

- moving agents and brief objects: local avoidance, no nav rebuild;
- predictable doors/lifts: revisioned link enable/cost state;
- medium-lived blockers: dynamic area modifier or tile-cache obstacle;
- persistent geometry change: bounded tile rebuild;
- catastrophic topology change: coarse graph revision plus dependent corridor invalidation.

Off-mesh links include stable ID, endpoints, direction, traversal capability, capacity, duration estimate, animation contract, and state revision. Narrow or exclusive links need reservation queues and timeout/cancellation rules. A path containing a link is not permission to begin traversal.

### Local avoidance

Use a proximity grid or spatial hash to bound neighbor discovery. Local avoidance receives preferred velocity from path following and returns a feasible velocity; it does not change the global goal.

Choose one avoidance solver per agent population. Detour-style sampled avoidance is a practical nav-corridor-aware baseline. ORCA is valuable when reciprocal assumptions and movement models fit. Non-holonomic characters, animation constraints, priority asymmetry, and dense bottlenecks require explicit policy beyond the formal disc-agent model.

## Performance Considerations

### Algorithmic complexity

Let `V` and `E` be explored graph vertices/edges, `R` coarse regions, `P` corridor portals, `A` active agents, `k` average nearby avoidance neighbors, and `T` dirty nav tiles.

- binary-heap A*/Dijkstra: `O((V + E) log V)` worst-case for the explored graph;
- uniform-grid neighbor enumeration: expected `O(A + candidate pairs)`, approximately `O(Ak)` with bounded density;
- funnel/string pulling: `O(P)`;
- corridor look-ahead validation: `O(L)` for bounded look-ahead length `L`;
- cache lookup: average `O(1)` plus revision validation proportional to recorded dependencies;
- HPA-style coarse search: `O((R + E_R) log R)` over explored abstraction;
- local avoidance: neighbor gathering `O(k)` plus solver-dependent sampling or low-dimensional optimization;
- dirty-tile queue: `O(T log T)` with priority heap, while each rebuild cost depends on rasterized geometry and configured resolution.

The meaningful bound is not total world graph size but expansions, neighbors, dirty tiles, and work allowed per frame/query. Every query must have caps and explicit partial/overflow behavior.

### Allocations and garbage collection

- Preallocate query records, node pools, heaps, corridor buffers, corner buffers, and avoidance neighbor arrays.
- Use per-worker scratch arenas reset after each query batch.
- Store common small paths inline; spill only through bounded pools.
- Keep persistent D* Lite/LPA* state in a capped specialist pool.
- Do not allocate per neighbor, edge expansion, path corner, or behavior-tree move tick.
- Release path handles through generations; never leave managed callbacks retaining large result graphs.
- Stable frames must produce zero managed garbage and no general-heap navigation allocation after warm-up.

### Spatial structures and cache behavior

Tiled navmesh bounds rebuild and streaming granularity. A navigation octree/BVH indexes relevant source geometry; a proximity grid indexes moving agents; a coarse portal graph handles long range topology.

Keep polygon adjacency and costs contiguous. Store hot search fields as SoA arrays and use integer node references. Group queries by navmesh, agent profile, and filter to improve instruction/data locality. Avoid virtual function calls per edge where filter tables or compiled policy IDs suffice.

### Concurrency

Navmesh snapshots queried by workers are immutable. Tile publication/removal occurs at a barrier or through versioned snapshot/RCU-style lifetime. A worker never observes half-rebuilt adjacency.

Query jobs are time-sliced by expansions or measured microseconds, not OS-thread blocking. High-priority immediate queries may run a bounded synchronous prefix; full work remains scheduled. Completed results enter deterministic per-phase event buffers.

Avoid one job per tiny query. Batch short reachability requests. Prevent a few long searches from monopolizing workers by cooperative yielding and per-query budgets.

### Navigation rebuild cost

Coalesce dirty bounds into tiles and apply debounce for repeated edits. Prioritize tiles near active agents and requested corridors. Publish rebuilt tiles atomically with incremented revisions. Retire old tile storage after all query readers complete.

Track rasterization, compact heightfield, region, contour, polygonization, detail mesh, serialization, and publication separately. Broad cell streaming of baked base geometry must not dirty tiles. Dynamic rebuilds must have:

- tiles-per-frame and milliseconds-per-frame caps;
- source-geometry vertex/triangle limits;
- queue-age telemetry;
- fallback blocking/cost modifiers while rebuild waits.

### AI scheduling

Movement requests enter a central scheduler rather than letting behavior trees call unrestricted synchronous pathfinding. Deduplicate repeated identical goals, add cooldown/jitter, and prioritize by:

- player threat and screen/gameplay relevance;
- time until current corridor expires;
- distance to invalid segment;
- traversal deadline;
- agent LOD;
- request age.

AI LOD reduces long-range refinement and avoidance update frequency, but authoritative collision safety remains. Activation of a streamed encounter must ramp path and avoidance registration over several budgets to avoid a request herd.

### Streaming I/O and memory residency

Nav tiles, coarse graph shards, link state, and path-cache entries have independent residency budgets. A coarse route can return `data-missing` plus required cells/tiles and trigger prefetch. Do not block a query worker on I/O.

Pin the near-term corridor and destination neighborhood while a move is active. Release far-behind tiles with hysteresis. Memory pressure drops speculative path suffixes and caches before active safety corridors.

### Visibility and whole-frame cost

Navigation relevance is not visibility. Offscreen combatants may need authoritative paths; visible distant agents may use simplified trajectory prediction. Debug nav rendering must be capped and excluded from shipping cost measurements.

For a 60 Hz target, navigation receives a platform/content-specific slice of the 16.67 ms frame. Measure CPU navigation alongside physics, animation, perception, streaming, and rendering rather than declaring an isolated average. Use p50, p95, p99, and maximum queue latency, expansions, rebuild time, and avoidance time.

### Worst-case behavior

Test:

- many agents receive one moving goal simultaneously;
- a door closes across hundreds of corridors;
- a bridge or world cell disappears;
- all agents meet at a one-agent-wide link;
- dense opposing crowds deadlock;
- goals project onto disconnected islands;
- heuristic degenerates and A* approaches Dijkstra;
- node pool or corridor buffer overflows;
- nav tiles rebuild while queries read old revisions;
- target teleports repeatedly;
- a cache entry has many dependencies;
- minimum-spec CPU receives streaming, perception, and nav spikes together.

Fallbacks include partial paths, waiting, local retreat, authored holding points, queueing, reduced replanning frequency, alternate coarse routes, and explicit failure events. Silent truncation is forbidden.

## Pros and Cons

### Pros

- Hierarchy bounds long-range search and naturally drives nav/world prefetch.
- Corridors separate topological correctness from smooth short-horizon motion.
- Dependency revisions enable narrow invalidation and useful caching.
- Central scheduling makes CPU, allocation, and latency budgets enforceable.
- Dynamic obstacle classification avoids expensive rebuilds for transient motion.
- Local avoidance scales through bounded spatial neighborhoods.

### Cons

- Multiple layers and revisions create more state to debug.
- Hierarchical routes may be suboptimal or become stale.
- Incremental search retains memory and is not beneficial for all change patterns.
- Avoidance can deadlock in dense symmetric bottlenecks.
- Off-mesh reservations introduce fairness, animation, and cancellation problems.
- Fixed query caps can produce partial results that gameplay must handle.

## ECS and World-Partition Integration

Recommended components:

- `NavAgent`: profile/capability ID, radius, height, speed class;
- `MoveIntent`: stable request ID, global goal, acceptance policy, priority;
- `PathHandle`: generation-checked service handle, never a raw buffer pointer;
- `PathFollowState`: local progress, current link, stop/turn policy;
- `AvoidanceAgent`: solver population, priority, neighbor radius;
- `NavObstacle`: obstacle class and modifier/link policy;
- `TraversalState`: reservation and authored traversal action;
- `NavigationLOD`: full, reduced, dormant scheduling policy.

Renderer, animation, physics, behavior trees, and ECS do not own nav query memory. The `NavigationWorld` owns immutable tile snapshots, coarse graphs, revisions, query pools, corridor storage, caches, and scheduling.

World-partition integration:

- cell manifests reference baked nav chunks and coarse portal edges;
- `CellSimReady` requires required nav chunks and seam validation;
- coarse routes emit nav/world-cell demand;
- active corridors pin a near-term tile band;
- cell retirement invalidates dependencies by tile/portal revision;
- dormant agents persist global position, goal, coarse progress, and traversal state, not raw polygon references.

## Navigation, AI, Streaming, and Event Interfaces

Core interfaces:

- `SubmitPath(PathRequest) -> RequestHandle`
- `CancelPath(RequestHandle)`
- `PollPath(RequestHandle) -> status`
- `AcquirePath(PathHandle) -> immutable view`
- `ReleasePath(PathHandle)`
- `ValidateCorridor(PathHandle, lookAhead) -> validity`
- `RepairCorridor(PathHandle, currentPosition, targetPosition) -> result`
- `RequestNavData(globalBounds, agentProfile, deadline) -> pin`
- `RegisterObstacle(ObstacleDescriptor) -> ObstacleHandle`
- `UpdateLink(LinkId, stateRevision, cost, capacity)`
- `ReserveTraversal(LinkId, agentId, deadline) -> reservation`
- `ComputePreferredVelocity(PathHandle, followState) -> velocity`
- `SolveAvoidance(population, preferredVelocities) -> velocities`

Events:

- `PathReady`, `PathPartial`, `PathFailed`, `PathStale`, `PathCancelled`;
- `CorridorInvalidated`, `NavTilePublished`, `NavTileRetired`;
- `CoarseRouteChanged`, `NavDataRequired`;
- `TraversalReserved`, `TraversalDenied`, `TraversalExpired`;
- `AgentStuck`, `AvoidanceInfeasible`, `NavigationBudgetExceeded`.

Events carry stable IDs, generations, and revisions. They are merged at explicit simulation barriers and must be safe if duplicated or delivered after requester destruction.

## Integration Plan

1. Define agent profiles, area/filter tables, stable node/tile/link IDs, and revision rules.
2. Implement immutable tiled-nav snapshots and thread-safe query contexts.
3. Implement bounded A*/Dijkstra with pooled SoA nodes/heaps and diagnostic statuses.
4. Add corridor handles, funnel corner extraction, corridor validation, and local repair.
5. Add central prioritized scheduling, cancellation, time slicing, and deterministic event publication.
6. Build the coarse portal graph and corridor-driven nav/world prefetch.
7. Add dependency-revision coarse-route cache and agent corridor reuse; measure hit and repair rates.
8. Add dynamic link state/reservations and classified obstacle handling.
9. Add one local avoidance solver with proximity-grid neighbors and hard population/density bounds.
10. Add tile rebuild queue, coalescing, immutable publication, and retirement.
11. Evaluate reverse Dijkstra/flow fields for shared goals and D* Lite/LPA* for repeated localized-change workloads.
12. Integrate AI LOD, streaming activation ramp, profiling overlays, and automated regression gates.

## Verification and Profiling Strategy

### Correctness

- Compare A* cost with Dijkstra on randomized finite graphs for admissible heuristics.
- Property-test filters, one-way edges, costs, links, partial paths, and unreachable islands.
- Compare funnel output with corridor containment and clearance checks.
- Randomize tile publication/removal while queries use immutable old snapshots.
- Move agents outside corridors and verify repair or explicit replan.
- Change every dependency type and assert only affected cache entries invalidate.
- Destroy requesters before completion and verify generation rejection.
- Validate off-mesh reservations under cancellation, death, timeout, and cell unload.

### Automated navigation tests

- Generate random start/goal pairs per agent profile and compare with fully loaded reference reachability.
- Traverse every directed off-mesh link with animation/physics handoff.
- Run doors, lifts, breakable bridges, temporary blockers, and moving platforms.
- Run opposing crowds through corridors, intersections, stairs, and single-capacity links.
- Inject stuck conditions and verify bounded recovery escalation.
- Replay identical authoritative inputs at different worker counts and compare path-result order/state hashes where determinism is required.

### Profiling

Record:

- requests by status/priority/agent LOD;
- expansions, heap operations, explored nodes, and heuristic effectiveness;
- query CPU time, queue latency, yield count, cancellation waste;
- node/corridor/cache memory and allocation count;
- cache hit, stale-hit, repair, and eviction rates;
- corridor length, corner count, and smoothing time;
- invalidations by tile/link/filter/layer revision;
- dirty/rebuilt tiles and stage timings;
- avoidance neighbors, samples/constraints, infeasible results, and stuck time;
- nav I/O latency, tiles pinned, and missing-data waits;
- p50/p95/p99/max frame and job cost.

Debug overlays show nav tiles/revisions, coarse graph/route, corridor polygons, corners, query frontier, cache dependencies, dirty tiles, obstacle classes, off-mesh reservations, avoidance neighbors/velocities, and scheduler queues.

### Acceptance gates

- no unbounded query, neighbor, corridor, cache, or rebuild allocation;
- no steady-state managed garbage/general-heap allocation;
- no query worker blocks on streaming I/O;
- no half-published tile is visible to a query;
- A* equals Dijkstra reference cost when optimal mode is requested;
- smoothed path stays within valid clearance and preserves mandatory links;
- stale completion cannot overwrite a newer request;
- base cell streaming does not rebuild baked nav;
- overflow/timeout produces explicit partial/failure status;
- navigation stays within platform p99 frame and request-latency budgets under combined soak workloads.

## Risks and Open Decisions

- Binary versus 4-ary heap and duplicate-push versus decrease-key.
- Maximum node expansions, query time slice, and pool sizes by platform.
- Heuristic and weighted-A* quality contracts.
- Coarse graph construction and abstraction update policy.
- Exact cache levels, memory budget, and dependency granularity.
- Whether repeated workloads justify D* Lite/LPA* retained state.
- Static, Dynamic Modifiers Only, or Dynamic nav per world/content class.
- Detour sampled avoidance, ORCA, or a custom animation-aware solver.
- Non-holonomic, flying, climbing, swimming, and large-agent representations.
- Link reservation fairness, capacity, interruption, and replication.
- Deterministic path results across platforms versus server-authoritative paths.
- Flow-field adoption threshold for shared-goal groups.
- Stuck detection thresholds and gameplay-authored fallback behaviors.

## Engineering Recommendations

1. Use A* as the default point-to-point detailed search, Dijkstra for multi-source/range/reference queries, and a coarse portal A* for long routes.
2. Make bounded partial results and explicit data-missing status first-class; never let a query block on I/O.
3. Keep polygon corridors authoritative and derive funnel corners plus movement-constrained trajectories.
4. Reuse/repair current corridors before full replanning. Cache coarse routes and shared-goal fields before arbitrary full paths.
5. Version tiles, links, filters, and gameplay layers; invalidate by recorded dependency revisions.
6. Adopt D* Lite/LPA* only after trace-based evidence shows repeated goals with localized changes and net benefit after retained-memory cost.
7. Classify dynamic obstacles. Use avoidance for agents/brief motion, link state for doors/lifts, modifiers for medium-lived blockers, and tile rebuilds only for persistent geometry.
8. Select one avoidance solver per population and bound neighbor count/density. Provide infeasible/deadlock fallbacks and authored bottleneck rules.
9. Centralize query scheduling with priority, aging, cancellation, expansion/time caps, pooled memory, and AI-LOD policies.
10. Publish nav tiles immutably and retire old snapshots after readers complete.
11. Make off-mesh traversal a capacity-controlled reservation and animation/physics contract, not just an A* edge.
12. Gate choices with combined worst-case profiling, especially encounter activation, navigation rebuild, perception, animation, physics, streaming, and frame-time tails.

## Source Links

1. Epic Games, **Navigation System in Unreal Engine**: https://dev.epicgames.com/documentation/unreal-engine/navigation-system-in-unreal-engine?lang=en-US
2. Epic Games, **Using Avoidance With the Navigation System in Unreal Engine 5.8**: https://dev.epicgames.com/documentation/en-us/unreal-engine/using-avoidance-with-the-navigation-system-in-unreal-engine
3. Epic Games, **Unreal Engine Navmesh API**: https://dev.epicgames.com/documentation/en-us/unreal-engine/API/Runtime/Navmesh
4. Epic Games, **AI System Settings in Unreal Engine 5.8**: https://dev.epicgames.com/documentation/en-us/unreal-engine/ai-system-settings-in-the-unreal-engine-project-settings
5. Recast Navigation, **Official repository and subsystem overview**: https://github.com/recastnavigation/recastnavigation
6. Recast Navigation, **Detour Path Corridor implementation and documentation**: https://github.com/recastnavigation/recastnavigation/blob/master/DetourCrowd/Source/DetourPathCorridor.cpp
7. Botea, Muller, and Schaeffer, **Near Optimal Hierarchical Path-Finding**: https://webdocs.cs.ualberta.ca/~mmueller/ps/hpastar.pdf
8. Koenig and Likhachev, **D* Lite**: https://publications.ri.cmu.edu/d-lite
9. van den Berg, Guy, Lin, and Manocha, **Reciprocal n-body Collision Avoidance / ORCA**: https://gamma.cs.unc.edu/ORCA/publications/ORCA.pdf
10. Unity Technologies, **AI Navigation package overview**: https://docs.unity3d.com/2023.2/Documentation/Manual/com.unity.ai.navigation.html

