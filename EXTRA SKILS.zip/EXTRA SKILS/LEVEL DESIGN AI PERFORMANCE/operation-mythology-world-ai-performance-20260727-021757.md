# Operation Mythology Research Report

## Scalable AI Perception, Belief Memory, Suspicion, Threat, and Team Communication

**Timestamp:** 2026-07-27 02:17:57 America/Los_Angeles  
**Status:** New baseline for an uncovered domain  
**Assumptions:** Generic modular ECS, data-oriented memory, first-person and third-person gameplay, event-driven AI decision stack, world partition, authoritative server simulation where applicable, and no production-code implementation.

## Feature Overview

Perception should turn bounded sensory evidence into beliefs; it should not directly choose behavior. The recommended pipeline is:

`Source Event/Registration -> Broad Phase -> Cheap Sensor Tests -> Budgeted Occlusion/Propagation -> Stimulus -> Belief Fusion -> Suspicion/Threat -> Working-Memory Change Event`

The system distinguishes:

- **stimulus:** immutable evidence that something occurred;
- **observation:** one listener's processed sensory result;
- **belief:** listener-owned interpretation with confidence, age, and uncertainty;
- **suspicion:** accumulated evidence that warrants investigation or alert;
- **threat:** urgency/harm estimate used by decision systems;
- **team report:** fallible, provenance-bearing information sent to other agents;
- **ground truth:** simulation state, never silently copied into an agent's belief.

Supported senses:

- sight;
- hearing;
- damage and near-miss;
- touch;
- team/social report;
- scripted/contextual stimuli;
- optional smell/track/prediction senses using the same contracts.

The architecture uses a spatial broad phase, asynchronous/batched physics visibility queries, fixed-capacity stimulus and belief pools, event-driven updates, explicit aging, and significance/AI-LOD budgets. It provides gradual identification and suspicion rather than a single visible/not-visible bit, while retaining deterministic and designer-testable behavior.

## Existing Coverage and Identified Gap

The required recursive scan of `C:\Users\steve\Desktop\GAME SKILLS` found eleven completed baseline reports and its index. New coverage since the prior pass includes scalable shadows, animation evaluation/GPU deformation, and physics plus unified FP/TP character control. Existing reports also cover ECS/jobs, renderer architecture, virtualized assets, temporal reconstruction, and GI/reflections.

The required scan of `C:\Users\steve\Desktop\EXTRA SKILS\LEVEL DESIGN AI PERFORMANCE` found:

- scalable navigation queries, caching, replanning, off-mesh traversal, and local avoidance;
- hybrid StateTree/HFSM, behavior-tree, utility, GOAP/HTN, and AI scheduling architecture;
- the folder's research index.

No scanned report defines:

- stimulus schemas and source/listener registration;
- sight broad phase, visibility points, identification certainty, or occlusion budgets;
- hearing propagation, loudness/priority, or uncertainty;
- damage/near-miss evidence;
- belief fusion, decay, last-known position, or covariance/uncertainty bounds;
- suspicion thresholds and hysteresis;
- target threat calculation separate from perceptual certainty;
- team-report provenance, latency, trust, expiry, or loop prevention;
- perception LOD, batched ray scheduling, source/listener caps, or failure behavior;
- perception-specific debug overlays, automated tests, and telemetry.

This batch fills that gap. Group tactics, cover selection, formation/role coordination, spawning, and encounter directors remain separate future subjects.

## Sourced Facts

The following are source-backed facts; recommendations are separately labeled later.

1. Unreal Engine 5.8 AI Perception models listeners that gather registered stimuli sources. It supports sight, hearing, damage, prediction, team, and touch senses, and emits perception update events that can update behavior-tree data.

2. Unreal sight configuration exposes separate `Sight Radius` and `Lose Sight Radius`, creating acquisition/loss hysteresis. It also exposes peripheral angle, near clipping, point-of-view backward offset, affiliation filtering, last-seen auto-success range, stimulus age, and enable/disable state.

3. Unreal hearing uses reported noise events, a hearing range, affiliation filtering, maximum stimulus age, and stimulus strength/location metadata.

4. Unreal perception events expose stimulus age, expiration age, strength, stimulus location, receiver location, tag, and whether sensing succeeded. The system can return currently perceived actors separately from known but not-yet-forgotten actors.

5. Unreal provides maximum age and an option to forget stale actors, showing that perception lifetime and memory cleanup are explicit policies rather than consequences of losing line of sight.

6. Unreal's perception component batches newly received stimuli before updating. Its sight API exposes query-importance calculation and asynchronous line-of-sight query completion hooks, demonstrating the need to prioritize and defer expensive visibility work.

7. Unity's `RaycastCommand.ScheduleBatch` schedules a command buffer of physics raycasts as jobs and writes results asynchronously to caller-provided buffers. This is evidence for batched visibility queries and explicit result lifetimes.

8. Steve Rabin's Game AI Pro 2 chapter describes the common distance, field-of-view, then raycast order for sight checks. It argues that a Boolean sight result creates abrupt, exploitable boundaries and presents vision zones plus continuous object-identification certainty as an alternative.

9. Rabin distinguishes identification certainty from a random chance to notice. The chapter proposes modifying certainty using motion/camouflage and using partial certainty to drive nuanced reactions, dialogue, and investigation. It notes that such nuance needs matching animation, vocalization, or UI feedback.

10. Travis McIntosh's Game AI Pro 2 account of *The Last of Us* reports that a simple view cone produced poor close/far behavior, leading to an angle that varies with distance and time-based awareness rather than instant full identification. It also describes exposure-map processing as a measurable CPU task and a pathfinding cost input.

11. Martin Walsh's GDC presentation on *Splinter Cell: Blacklist* separates visual, environmental, auditory, social, and contextual awareness. The auditory model gave events distance and priority, and the presentation emphasizes barks/HUD feedback so the player can understand uncertain detection.

12. Jeff Orkin's Game AI Pro 2 chapter on *F.E.A.R.* describes authored squad dialogues that communicate observed state, lost targets, blocked movement, deaths, and reinforcement needs. It explicitly frames dialogue as both player feedback and an illusion of squad coordination.

## Industry-Standard API, Algorithm, or Pattern

### Stimulus contract

An immutable `Stimulus` contains:

- source persistent ID and generation;
- sense type and semantic tag;
- global origin and optional direction/extent;
- source timestamp and sequence;
- base strength and effective radius;
- affiliation/faction at emission time;
- evidence payload handle, such as damage amount or sound category;
- propagation policy;
- expiry;
- source world-cell and content revision.

Stimuli are not raw entity pointers. Source destruction does not invalidate historical evidence. Per-frame producers write to thread-local buffers that merge deterministically by timestamp, source ID, and sequence.

Continuous sources such as visible characters register compact `PerceptionSourceProxy` records with bounds, affiliation, detectability channels, visibility sample points, and revision. Transient events such as gunshots or damage use the immutable stimulus stream.

### Listener contract

A `PerceptionListener` contains:

- stable agent ID/generation;
- sensor profile and enabled senses;
- global eye/ear/body transforms;
- affiliation and hostility policy;
- current AI LOD/significance;
- spatial cell;
- per-sense ranges and budget class;
- belief-store handle;
- scheduler priority.

Listeners update registration only when transform cell, profile, team, enabled senses, or LOD changes beyond thresholds. They do not rebuild query pairs every frame.

### Spatial broad phase

Use separate or shared sparse grids/BVHs for sources and listeners:

1. map listeners/sources to cells;
2. enumerate candidates within the maximum sense range;
3. apply affiliation/category masks;
4. apply squared distance;
5. apply field-of-view or event radius;
6. rank remaining expensive tests;
7. schedule bounded occlusion/propagation work.

For mostly uniform gameplay spaces, a hashed 2D/3D grid offers stable locality and expected linear behavior. A BVH/loose tree may better handle highly nonuniform scales. World cells provide coarse residency but are too large to be the only perception broad phase.

### Sight model

Sight proceeds from cheap to expensive:

1. source/listener eligibility;
2. squared distance with separate acquire and retain radii;
3. angular/zone test;
4. coarse portal/sector visibility or static occlusion hint where available;
5. one or more asynchronous physics traces;
6. certainty integration;
7. belief update.

Use target-provided visibility sample points such as head, torso, pelvis, and context-specific points. Begin with a prioritized point and request additional points only when the result is ambiguous or gameplay-critical. A source returns a visible fraction and best seen position, not just a Boolean.

Recommended identification evidence combines normalized terms:

- vision-zone quality;
- visible sample fraction;
- target screen/angular size or distance factor;
- target relative motion;
- stance/exposure;
- authored camouflage/illumination abstraction;
- listener alertness/focus;
- recent confirmation;
- occlusion confidence.

Integrate evidence over time with different acquire/lose rates and clamped hysteresis. Do not sample visibility randomly each frame. The resulting certainty drives states such as `Unnoticed`, `Anomaly`, `Suspected`, `Identified`, and `ConfirmedHostile`.

Lighting influence must use a stable gameplay visibility value authored or computed at controlled frequency; do not read arbitrary renderer exposure or pixel luminance into authoritative AI, because temporal/render-quality changes would alter gameplay.

### Hearing model

A sound stimulus contains semantic class, strength, radius, source position, directionality, and priority. Propagation tiers:

- **Tier 0:** radial falloff, no occlusion;
- **Tier 1:** radial falloff plus one occlusion/portal attenuation test;
- **Tier 2:** room/portal graph propagation with edge transmission costs;
- **Tier 3:** specialist acoustic simulation only if gameplay value justifies it.

Return an uncertain perceived location. Accuracy depends on signal strength, occlusion, listener profile, and repeated corroboration. Footsteps might yield a broad search area; gunfire or impact may be localized more accurately.

Use a room/portal acoustic graph when indoor connectivity matters. Run Dijkstra from a high-priority sound through a bounded subgraph, accumulating attenuation/delay, and share the result across listeners. Do not run independent full acoustic searches per listener.

Coalesce repeated low-value sounds by source/category/spatial bin and time window. Preserve the strongest/recent representative and count. Critical dialogue, explosion, gunshot, and damage events have reserved capacity.

### Damage, near-miss, touch, and prediction

Damage is authoritative evidence and should bypass ordinary sight/hearing uncertainty for “I was harmed,” while attacker identity/location remains limited to actual evidence. Store:

- damage type/amount;
- impact direction and position;
- instigator ID only if gameplay rules expose it;
- projectile/weapon clues;
- timestamp.

Near-miss/suppression is a separate stimulus generated by validated trajectory proximity, not by every projectile. Touch produces immediate local evidence but still applies affiliation and disguise rules.

Prediction is a derived belief, not a sense of ground truth. Extrapolate last confirmed position using bounded time and uncertainty growth. Constrain prediction to navigable/reachable space only when a navigation query is available; otherwise preserve uncertainty rather than snapping to a guessed exact point.

### Belief memory

Per listener-target belief:

- target persistent ID or anonymous stimulus cluster ID;
- classification and affiliation belief;
- last and best-known global position;
- velocity estimate;
- position uncertainty radius/covariance approximation;
- per-sense evidence/confidence;
- identification certainty;
- suspicion;
- threat;
- first/last observed and last confirmed timestamps;
- source provenance;
- revision;
- expiry/forget policy.

Use one fused belief per subject plus a bounded recent-evidence ring only for debugging or specialist reasoning. Do not retain an unbounded stimulus history.

Evidence update:

1. predict prior belief forward with growing uncertainty;
2. associate stimulus to a known target or anonymous cluster;
3. combine evidence using deterministic, tuned gains;
4. update confidence and uncertainty;
5. emit changed-fact events only when thresholds or meaningful values cross;
6. decay/expire using a timing wheel rather than scanning every belief every frame.

This need not be a mathematically strict Bayesian filter. A transparent exponential/alpha-beta style update is preferable if it produces predictable gameplay and explainable tuning.

### Suspicion and alert state

Suspicion accumulates from evidence types with semantic weights:

- weak partial sight;
- unexplained sound;
- changed environment/door/body;
- teammate report;
- near miss;
- direct damage;
- confirmed hostile sight.

Use separate rise and decay curves, thresholds, minimum dwell time, and hysteresis:

`Calm -> Curious -> Investigating -> Alerted -> Combat`

State transitions belong to the StateTree/HFSM, while the perception service supplies evidence and suspicion values. Direct damage may force a minimum alert state without granting perfect target knowledge.

Repeated stimuli should saturate; otherwise rapid footstep or particle events can inflate suspicion without bound. Correlated reports should not be counted as independent evidence.

### Threat model

Threat is not certainty. Compute it after perception from bounded candidates using:

- hostility;
- confirmed/estimated identity;
- damage/near-miss recency;
- distance and estimated time to harm;
- line-of-fire or reachability;
- weapon/ability class;
- target focus;
- vulnerability of self/squad/objective;
- confidence penalty;
- designer/gameplay priority;
- current-target hysteresis.

Generate candidates through spatial/perception memory, then score top-N. Threat selection writes a decision input; it does not rewrite sensory certainty.

### Team communication

A `TeamReport` contains:

- reporting agent and generation;
- original evidence source/provenance;
- subject ID or anonymous stimulus cluster;
- reported position plus uncertainty;
- classification, confidence, and threat summary;
- observed and sent timestamps;
- semantic report type;
- hop count/report generation;
- intended team/channel/squad;
- expiry.

Receivers combine a report as weaker second-hand evidence based on trust, latency, distance/radio rules, and whether the reporter is alive/connected. Reports retain original provenance so the same gunshot relayed by five agents does not count five times.

Use squad/shared knowledge only for facts the game intends to share. Personal uncertainty remains personal. Communication may be:

- instantaneous abstract tactical network;
- proximity speech;
- radio with delay/jamming;
- explicit leader/relay topology.

Player-facing dialogue is a presentation consumer of team/perception events. It cannot be the authoritative transport because voice concurrency, localization, and audio culling may suppress playback.

## Performance Considerations

### Algorithmic complexity

Let `L` be listeners, `S` registered sources, `C` broad-phase candidates, `R` scheduled raycasts, `B` active beliefs, `E` emitted transient stimuli, and `G` acoustic portal-graph nodes/edges.

- naive listener-source pairing: `O(LS)` and unacceptable at scale;
- spatial-grid update: expected `O(L + S)` for moved records;
- broad-phase enumeration: `O(L + S + C)` expected with a suitable grid;
- cheap sight tests: `O(C)`;
- visibility traces: approximately `O(R * physicsQueryCost)`;
- event merge/sort: `O(E log E)` comparison sort or near `O(E)` with fixed deterministic radix keys;
- belief lookup/update: average `O(1)` by target ID;
- timing-wheel aging: `O(expiring entries)` per bucket rather than `O(B)` each frame;
- bounded threat scoring: `O(K)` for `K` retained candidates;
- room/portal sound propagation: `O((G + E_G) log G)` for bounded Dijkstra, shared by affected listeners.

Raycasts and candidate pairs dominate practical CPU cost. Hard caps and prioritization are required even when average densities are low.

### Allocations and garbage collection

- Preallocate source/listener proxies, candidate pairs, stimuli, trace commands/results, beliefs, anonymous clusters, team reports, and event records.
- Use per-worker linear buffers and deterministic merge.
- Use fixed-capacity per-listener belief tables with tiered overflow policy.
- Keep recent evidence in small inline rings or sampled trace buffers.
- Timing-wheel nodes come from slabs and are reused.
- No per-ray, per-pair, per-stimulus, per-report, or per-belief general-heap allocation.
- Stable simulation produces zero managed garbage after warm-up.

On overflow:

1. retain direct damage/touch and current confirmed threats;
2. retain stronger/newer unique evidence;
3. coalesce repetitive sounds/reports;
4. drop speculative/distant evidence;
5. emit overflow telemetry.

Never grow pools opportunistically in a gameplay spike.

### Spatial data structures and cache behavior

Use compact SoA proxy arrays:

- position/cell;
- range;
- forward vector;
- masks/team;
- profile/LOD;
- stable ID/generation;
- revision.

Broad-phase cell membership uses contiguous buckets or pooled linked blocks. Sort candidate batches by listener or source depending on the next stage. Group visibility traces by physics scene and query mask.

Belief hot fields—subject ID, position, confidence, suspicion/threat, timestamps, revision—remain contiguous. Debug strings, semantic explanations, and full evidence history remain cold.

World-cell unload removes proxies by generation and emits target-unavailable events; it does not scan every listener. A reverse subject-to-belief index may accelerate invalidation, but its memory/write cost must be measured.

### Concurrency

Safe parallel work:

- source/listener spatial updates from immutable transforms;
- broad-phase candidate generation;
- distance/FOV/affiliation tests;
- batched asynchronous visibility queries;
- evidence integration into listener-partitioned belief ranges;
- threat scoring;
- sound propagation per high-value event.

Commit changed working-memory facts and decision events at an AI barrier. Physics traces read an immutable physics snapshot. If source/listener generations or transform revisions change before results return, validate or discard results.

Never block AI workers waiting for physics, navigation, streaming, or audio. A visibility query can complete next frame; current belief confidence provides continuity.

Avoid false sharing in listener result counters and candidate queues. Partition work by listener ranges or spatial cells and use per-worker output blocks.

### Navigation rebuild cost

Perception does not rebuild navigation. It may:

- constrain predicted/search positions to currently resident nav data;
- ask reachability after identifying an investigation point;
- use portal/sector topology for sound propagation;
- add exposure/threat fields as query costs.

Do not issue an exact path query for every sensed candidate. Decision systems request paths only after choosing an intent/target. A nav tile revision can enlarge belief uncertainty or invalidate reachability, but cannot erase sensory evidence.

### AI scheduling

Priority order:

1. damage/touch/near-miss and current close threats;
2. retain checks for already identified targets;
3. acquire checks for high-significance candidates;
4. suspicious sounds/environmental changes;
5. team reports;
6. ambient/background senses.

Each candidate receives importance based on:

- listener gameplay significance;
- current alert state;
- target/current-threat status;
- distance and acquire/retain state;
- time since last check;
- predicted visibility change;
- stimulus strength/priority;
- queue age.

Use separate acquire and retain queues so known combat targets are not lost behind a flood of new candidates. Reserve trace capacity for safety-critical checks. Age work to prevent starvation.

AI LOD:

- **Full:** multi-point sight, normal hearing, frequent retain checks, detailed beliefs.
- **Reduced:** fewer visibility points, slower acquire checks, event-driven damage/team, simplified sound.
- **Coarse:** sector/portal visibility and shared reports; no individual raycast unless promoted.
- **Dormant:** no active sensing; retain serialized critical beliefs with timestamp-based decay.

Promotion triggers immediate bounded checks, not a synchronous scan of every nearby source.

### Streaming I/O and memory residency

Perception profiles, source schemas, sense curves, affiliation tables, and common debug metadata are resident with the AI archetype. Encounter-specific semantic stimulus definitions may stream with their cells.

When a cell stages:

1. register source proxies in bulk;
2. register listeners only after `CellSimReady`;
3. spread initial candidate generation over activation budgets;
4. restore persisted beliefs with age/uncertainty advanced by elapsed time;
5. validate referenced persistent IDs without requiring target residency.

On unload:

1. stop new queries;
2. cancel or invalidate outstanding trace generations;
3. unregister proxies;
4. persist only durable beliefs/suspicion required by gameplay;
5. release pools in bulk.

Perception memory residency is budgeted separately from world entities. A belief can outlive target residency, but it stores a stable ID and global uncertain position, not a raw entity pointer.

### Visibility cost

AI sight and renderer visibility are related but not interchangeable:

- renderer occlusion may be delayed, camera-specific, and optimized for pixels;
- AI sight originates from each listener;
- an off-camera target can be visible to AI;
- HLOD/occlusion proxies may not match gameplay collision;
- anti-aliasing/exposure/dynamic resolution must not alter authoritative perception.

Static portal/PVS information can reject impossible pairs conservatively. Physics/gameplay occlusion is the authoritative detailed check. Optional GPU visibility for crowds introduces readback latency and must retain a CPU/fallback path for important agents.

### Frame-time budgets and worst-case behavior

At 60 Hz the entire frame is 16.67 ms. Perception must use an explicit, platform-specific share and coordinate with behavior/planning, navigation, physics, animation, streaming, networking, and rendering.

Measure:

- broad-phase pairs;
- cheap tests;
- rays submitted/completed/discarded;
- queue latency by priority;
- stimuli emitted/coalesced/dropped;
- belief count/update/expiry;
- team reports and provenance deduplication;
- sound propagation graph work;
- memory and allocation count;
- p50/p95/p99/max CPU time and reaction latency.

Worst cases:

- hundreds of agents spawn around several players;
- a loud event reaches an entire indoor complex;
- smoke/destruction changes occlusion broadly;
- many agents acquire sight on the same frame;
- a global alarm produces team reports and state transitions;
- repeated footsteps/projectile impacts flood stimuli;
- split-screen/network players create divergent listener bubbles;
- streaming inserts sources while traces are outstanding;
- the current target oscillates at a sight boundary;
- direct damage arrives from an unseen unloaded shooter;
- team reports echo cyclically;
- debug capture records every pair/ray/belief;
- minimum-spec CPU receives physics, nav rebuild, streaming, and perception spikes together.

Backpressure, coalescing, hysteresis, pool caps, trace reservations, activation ramps, and explicit degraded states are required.

## Pros and Cons

### Continuous certainty and suspicion

**Pros:** avoids abrupt detection, supports stealth/investigation, explains partial knowledge, enables nuanced feedback.  
**Cons:** requires tuning and additional animation/audio/UI; poorly normalized evidence can feel arbitrary; designers need visualization.

### Batched asynchronous sight

**Pros:** bounds main-thread cost, parallelizes physics work, supports priority and LOD.  
**Cons:** introduces latency and stale-result handling; requires continuity from prior belief; batched results need fixed buffers.

### Portal/sector hearing

**Pros:** respects indoor topology, shares propagation across listeners, produces plausible uncertainty.  
**Cons:** needs authored/built connectivity and transmission costs; doors/destruction require revisions; outdoor spaces may gain little.

### Individual belief stores

**Pros:** preserves imperfect information and agent-specific reactions; supports memory, deception, and uncertainty.  
**Cons:** memory grows with listener-target pairs; team synchronization is more complex; persistence needs limits.

### Shared team knowledge

**Pros:** supports coordinated response and reduces redundant discovery.  
**Cons:** can become omniscient; provenance/latency/trust are required; report fan-out and loops can spike work.

## ECS and World-Partition Integration

Recommended ECS components:

- `PerceptionSource`: source profile, detectability masks, proxy handle;
- `PerceptionListener`: sensor profile, listener handle, enabled senses;
- `SensorPose`: eye/ear/body anchor IDs or compact transforms;
- `Affiliation`: team/faction/relationship policy ID;
- `PerceptionLOD`: current tier and reason;
- `BeliefStoreHandle`: generation-checked service handle;
- `SuspicionState`: compact current tier/value for decision access;
- `ThreatSelection`: selected subject and score generation;
- `StimulusEmitterPolicy`: semantic sound/damage/context rules;
- `TeamCommunication`: channel/trust/range/radio profile;
- `PersistentPerceptionState`: only durable suspicion/belief summary.

The perception service owns spatial indices, candidate pairs, trace buffers, stimuli, belief tables, timing wheels, team-report queues, and debug history. ECS components never contain raw belief arrays or physics query pointers.

Phase order:

1. simulation produces transforms, damage, sound, context, and team events;
2. source/listener proxies update in bulk;
3. broad phase and cheap tests generate candidates;
4. visibility/propagation jobs run;
5. belief updates merge at the AI barrier;
6. changed working-memory facts wake StateTree/BT/utility/planner work;
7. decisions start actions in later declared phases.

World-partition rules:

- manifests declare sense-relevant portal/room data and source proxy counts;
- cell staging registers immutable spatial/acoustic data before listeners activate;
- `CellSimReady` gates authoritative sensing;
- cell unload invalidates generations and preserves only configured durable beliefs;
- global positions and persistent IDs survive origin shifts and target unload.

## Navigation, AI, Streaming, and Event Interfaces

Core interfaces:

- `RegisterSource(SourceDescriptor) -> SourceHandle`
- `UpdateSource(handle, transformRevision, detectability)`
- `UnregisterSource(handle)`
- `RegisterListener(ListenerDescriptor) -> ListenerHandle`
- `SetListenerLOD(handle, tier, reason)`
- `EmitStimulus(Stimulus)`
- `QueryBelief(listener, subject) -> BeliefView`
- `QueryKnownSubjects(listener, filter, maxResults)`
- `AcknowledgeEvidence(listener, stimulusId)`
- `EmitTeamReport(TeamReport)`
- `SubscribeBeliefChanges(listener, keyMask) -> subscription`
- `RequestInvestigationPoint(beliefHandle) -> uncertain global region`
- `RequestExposure/Visibility(query) -> async result`

Events:

- `StimulusAccepted`, `StimulusDropped`, `StimulusExpired`;
- `SubjectNoticed`, `SubjectIdentified`, `SubjectLost`, `SubjectForgotten`;
- `BeliefChanged`;
- `SuspicionThresholdCrossed`;
- `ThreatChanged`;
- `DamageEvidenceReceived`;
- `TeamReportReceived`, `TeamReportRejected`;
- `PerceptionBudgetExceeded`;
- `VisibilityResultStale`;
- `ListenerLODChanged`;
- `PerceptionSourceUnavailable`;
- `AcousticTopologyChanged`.

All events carry stable IDs, generations, timestamps, source provenance, and relevant revisions. Changed-belief events are coalesced at a decision barrier. Decision systems never receive one behavior wakeup per raw footstep/ray result when a single fused change is sufficient.

## Integration Plan

1. Define stable stimulus, source, listener, observation, belief, and team-report schemas.
2. Implement pooled registration and a hashed-grid broad phase with deterministic candidate batches.
3. Implement sight distance/FOV/acquire-retain logic and one-point asynchronous visibility traces.
4. Add fixed-capacity belief stores, deterministic evidence fusion, uncertainty, timing-wheel decay, and changed-fact events.
5. Add continuous identification certainty, suspicion tiers, hysteresis, and player-facing debug visualization.
6. Add hearing event coalescing, radial falloff, uncertain localization, and reserved critical lanes.
7. Add room/portal propagation for indoor content after measuring value against radial hearing.
8. Add authoritative damage, near-miss, touch, and bounded prediction evidence.
9. Add threat scoring as a separate bounded stage feeding utility/behavior decisions.
10. Add team reports with provenance, trust, latency, hop/deduplication, and explicit communication policy.
11. Add multi-point visibility, static portal rejection, and specialist gameplay visibility factors.
12. Integrate AI LOD, world streaming, persistence, multiplayer authority, soak automation, and regression gates.

## Verification and Profiling Strategy

### Correctness tests

- Test acquire versus lose radii and certainty hysteresis at exact boundaries.
- Sweep distance, angle, stance, motion, visibility points, and occluders through golden perception scenes.
- Randomize asynchronous trace completion, source destruction, listener movement, cell unload, and origin shift.
- Assert stale generation/revision results cannot update beliefs.
- Test sound falloff, portal attenuation, closed/open doors, coalescing, and uncertain localization.
- Verify damage informs harm without leaking forbidden instigator identity.
- Property-test belief decay/expiry and timing-wheel behavior across large time jumps.
- Test provenance deduplication so relayed evidence does not multiply.
- Test affiliation changes, disguise, friendly fire, neutral targets, and team switches.
- Replay identical authoritative events with different worker counts and compare decision-relevant belief hashes.

### Automated gameplay tests

- Stealth routes cross every vision zone and occluder edge at walking, crouching, sprinting, and stationary states.
- Agents investigate weak sight, footsteps, impacts, changed doors, bodies, and teammate reports.
- Player breaks line of sight, changes direction, hides, reappears, and crosses world-cell boundaries.
- Crowds activate gradually and under a global alarm.
- Split-screen/multiplayer players approach from different directions.
- Offscreen agents exchange reports under proximity, radio, delay, and jamming policies.
- Long soaks detect belief leaks, immortal anonymous clusters, report loops, oscillating suspicion, and orphan listeners/sources.

### Debug overlays and telemetry

Per listener show:

- acquire/retain shapes and vision zones;
- broad-phase candidates and rejection reason;
- scheduled/completed visibility rays and sample points;
- stimulus strength, age, source, and semantic type;
- beliefs with last-known position, uncertainty, confidence, and provenance;
- suspicion curve/tier;
- threat candidate score breakdown;
- team-report flow and deduplication;
- LOD, scheduler priority, next check, and queue age.

Heatmaps:

- source/listener density;
- ray demand/completion latency;
- sound propagation/attenuation;
- belief count/memory;
- dropped/coalesced events;
- suspicion and alert distribution.

### Performance matrix

Test:

- 1, 10, 100, 500, and target maximum listeners;
- sparse/dense sources;
- static/moving targets;
- indoor portal-heavy and outdoor open spaces;
- one versus multiple visibility points;
- cold/warm streamed cells;
- calm, investigation, combat, and global-alarm states;
- minimum-spec CPU with concurrent physics/nav/streaming pressure.

Record p50/p95/p99/max for source update, broad phase, cheap tests, ray submission/completion, belief fusion, sound propagation, threat scoring, team report, queue latency, reaction latency, memory, allocations, and total frame cost.

### Acceptance gates

- no `O(listeners * all sources)` full pairing in steady state;
- no steady-state managed garbage/general-heap allocation;
- every candidate/ray/stimulus/belief/report queue has a hard bound and explicit overflow telemetry;
- no stale async visibility result mutates a reused handle;
- no decision system receives ground truth through a perception shortcut;
- direct damage does not grant unauthorized exact attacker knowledge;
- team relays preserve provenance and cannot amplify one event without bound;
- perception remains stable at acquire/loss boundaries and meets stealth fairness tests;
- streamed unload leaves no proxies, callbacks, or raw entity pointers;
- platform p99 frame cost and perception-to-reaction latency pass under combined worst-case soak.

## Risks and Open Decisions

- Hashed 2D grid, 3D grid, BVH, or hybrid broad phase by world topology.
- Authoritative visibility point count and selection policy.
- Gameplay illumination/camouflage representation and update cadence.
- Evidence-fusion function, uncertainty representation, and tuning ownership.
- Suspicion thresholds, dwell, decay, saturation, and direct-damage minimum alert.
- Hearing tier: radial, occlusion ray, portal graph, or specialist acoustics.
- Maximum beliefs per listener and anonymous-cluster association policy.
- Threat scoring ownership between perception and utility AI.
- Team communication semantics: omnidirectional abstraction, speech, radio, or hybrid.
- Trust, latency, jamming, hop, and report provenance rules.
- Server-only perception versus replicated belief summaries and client presentation.
- GPU-assisted crowd sight versus CPU authoritative/fallback path.
- Dormant belief persistence duration and save-game schema.
- Player feedback requirements for uncertainty, suspicion, and unreachable agents.

## Engineering Recommendations

1. Establish a strict evidence-to-belief boundary: stimuli are facts about events; beliefs are agent-specific and uncertain; behavior consumes beliefs only.
2. Use a spatial broad phase and cheap distance/FOV/mask tests before budgeted asynchronous physics visibility.
3. Implement separate acquisition and retention radii/timing plus continuous identification certainty to prevent detection flicker and abrupt stealth boundaries.
4. Use target-provided prioritized visibility points and add rays only for ambiguous/high-value cases.
5. Keep gameplay visibility factors deterministic and renderer-independent.
6. Treat hearing as semantic events with coalescing, priority, falloff, uncertainty, and optional shared portal propagation.
7. Make damage authoritative evidence of harm without automatically revealing exact attacker identity/location.
8. Store bounded per-listener beliefs with persistent IDs, global uncertain positions, provenance, confidence, timestamps, and timing-wheel expiry.
9. Keep suspicion and threat separate: suspicion estimates abnormal/hostile evidence; threat estimates urgency and expected harm.
10. Preserve provenance, trust, latency, and hop count in team reports; never turn team communication into free omniscience accidentally.
11. Reserve perception work for current threats and safety events, age lower-priority work, and ramp sensing on streamed activation.
12. Require causal debug overlays and player-facing feedback for partial identification, investigation, communication, and AI inability.
13. Gate the system on combined stealth, crowd, streaming, multiplayer, and minimum-spec soak tests with p99 reaction and frame-time targets.

## Source Links

1. Epic Games, **AI Perception in Unreal Engine 5.8**: https://dev.epicgames.com/documentation/en-us/unreal-engine/ai-perception-in-unreal-engine
2. Epic Games, **AI Components in Unreal Engine 5.8**: https://dev.epicgames.com/documentation/en-us/unreal-engine/ai-components-in-unreal-engine
3. Epic Games, **UAIPerceptionComponent API**: https://dev.epicgames.com/documentation/en-us/unreal-engine/API/Runtime/AIModule/UAIPerceptionComponent
4. Epic Games, **UAISense_Sight API**: https://dev.epicgames.com/documentation/en-us/unreal-engine/API/Runtime/AIModule/UAISense_Sight
5. Epic Games, **UAISenseConfig_Sight API**: https://dev.epicgames.com/documentation/en-us/unreal-engine/API/Runtime/AIModule/UAISenseConfig_Sight
6. Unity Technologies, **RaycastCommand asynchronous batch API**: https://docs.unity3d.com/ScriptReference/RaycastCommand.html
7. Rabin, **Vision Zones and Object Identification Certainty**, Game AI Pro 2: https://www.gameaipro.com/GameAIPro2/GameAIPro2_Chapter04_Vision_Zones_and_Object_Identification_Certainty.pdf
8. McIntosh, **Human Enemy AI in The Last of Us**, Game AI Pro 2: https://www.gameaipro.com/GameAIPro2/GameAIPro2_Chapter34_Human_Enemy_AI_in_The_Last_of_Us.pdf
9. Walsh, **Modeling AI Perception and Awareness in Splinter Cell: Blacklist**, GDC 2014: https://media.gdcvault.com/GDC2014/Presentations/Walsh_Martin_Modeling_AI_Perception.pdf
10. Orkin, **Combat Dialogue in F.E.A.R.: The Illusion of Communication**, Game AI Pro 2: https://www.gameaipro.com/GameAIPro2/GameAIPro2_Chapter02_Combat_Dialogue_in_FEAR_The_Illusion_of_Communication.pdf

