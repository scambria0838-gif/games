# Operation Mythology Research Report

**Timestamp:** 2026-07-27 03:13:02 America/Los_Angeles  
**Subject:** Hierarchical Visibility, Sector and Portal Culling, HLOD Substitution, Multi-View Policy, and Visibility-Driven Runtime Budgets

## Feature Overview

This batch defines a whole-game visibility system that progressively reduces work without allowing renderer state to become gameplay truth. The proposed hierarchy is:

1. world and Data Layer state;
2. streaming-cell and semantic-sector eligibility;
3. conservative sector/portal potentially visible sets;
4. per-view distance, screen-size, and frustum tests;
5. HLOD or proxy substitution;
6. GPU instance/cluster occlusion and indirect compaction;
7. hardware depth rejection.

The system must support first-person and third-person cameras, camera cuts, shoulder switching, fast traversal, split-screen or spectator views, reflections/shadows, large exteriors, dense interiors, moving occluders, destruction, and world-state transitions.

This is not a repeat of the existing visibility-buffer-versus-deferred report or GPU-driven indirect-submission report. Those reports decide how surviving geometry is submitted and shaded. This report decides which world regions, representations, systems, and instances are eligible for each view and how that decision safely influences streaming, HLOD, AI LOD, animation, audio, navigation, and telemetry.

## Existing Coverage and Identified Gap

The required recursive scan read and inventoried all files under:

- `C:\Users\steve\Desktop\GAME SKILLS`
- `C:\Users\steve\Desktop\EXTRA SKILS\LEVEL DESIGN AI PERFORMANCE`

The scan found 18 general research files and six dedicated automation files. Existing baselines cover GPU frustum/HZB compaction inside an indirect-rendering pipeline, shading-path visibility buffers, virtual geometry/texture feedback, GPU residency, World Partition and HLOD relationships, profiling, animation significance, navigation, AI scheduling/perception/group behavior, encounter AI LOD, and the new modular Level Contract.

The uncovered architectural gap is a single conservative visibility contract spanning:

- indoor sectors/portals and outdoor spatial hierarchy;
- potentially visible sets and dynamic occlusion;
- HLOD representation selection and safe handoff;
- multiple gameplay and renderer views;
- streaming prediction versus visibility evidence;
- visibility-event stability and consumers outside rendering;
- false-occlusion prevention, camera discontinuities, and state invalidation;
- per-stage budgets, overflow behavior, and combined worst-case validation.

## Sourced Facts

These are sourced facts; project recommendations appear later.

1. Unreal Engine 5.8 applies culling methods in a cost-oriented order: distance, view frustum, precomputed visibility, then dynamic occlusion. Distance and precomputed visibility can reduce the number of dynamic occlusion queries. [Epic Games—Visibility and Occlusion Culling](https://dev.epicgames.com/documentation/en-us/unreal-engine/visibility-and-occlusion-culling-in-unreal-engine)

2. Unreal uses actor bounds for visibility testing. Bounding spheres are fast and conservative, while boxes more closely fit an object's shape. Incorrectly large bounds reduce culling effectiveness; undersized bounds risk visible popping. [Epic Games—Visibility and Occlusion Culling](https://dev.epicgames.com/documentation/en-us/unreal-engine/visibility-and-occlusion-culling-in-unreal-engine)

3. Unreal hardware occlusion query results are read a frame later, which can cause objects to appear late during fast camera movement. Query cost scales with the number issued. Unreal's HZB method tests bounds against a mipmapped scene-depth texture and is described as more conservative, culling fewer objects. [Epic Games—Visibility and Occlusion Culling](https://dev.epicgames.com/documentation/en-us/unreal-engine/visibility-and-occlusion-culling-in-unreal-engine)

4. Unreal's round-robin VR occlusion alternates query work between eyes, saving an eye's query workload at the cost of another frame of latency and possible peripheral errors. This demonstrates that multi-view visibility policy is an explicit quality/latency tradeoff. [Epic Games—Visibility and Occlusion Culling](https://dev.epicgames.com/documentation/en-us/unreal-engine/visibility-and-occlusion-culling-in-unreal-engine)

5. Unreal precomputed visibility stores visibility for non-movable actors in spatial cells. Epic positions it mainly for small-to-medium worlds and lower-end/mobile hardware, trading runtime memory and build time for lower rendering-thread cost. Smaller cells can improve culling but increase memory and build cost; more aggressive settings can introduce popping errors. [Epic Games—Visibility Reference](https://dev.epicgames.com/documentation/en-us/unreal-engine/visibility-and-occlusion-culling-reference-in-unreal-engine), [Epic Games—Precomputed Visibility Volumes](https://dev.epicgames.com/documentation/unreal-engine/precomputed-visibility-volumes-in-unreal-engine)

6. Unreal World Partition HLOD replaces unloaded-cell static content with generated proxy meshes/materials. Epic identifies distant visibility and draw-call reduction as primary uses. [Epic Games—World Partition HLOD](https://dev.epicgames.com/documentation/en-us/unreal-engine/world-partition---hierarchical-level-of-detail-in-unreal-engine)

7. Unreal's current visibility telemetry includes time and counts for view visibility, occlusion culling, frustum culling, processed primitives, visible primitives, and occlusion queries. Epic calls visible static-mesh elements a major contributor to rendering-thread time. [Epic Games—Visibility and Occlusion Culling](https://dev.epicgames.com/documentation/en-us/unreal-engine/visibility-and-occlusion-culling-in-unreal-engine)

8. Unity 6's documented occlusion system is conservative: when visibility is uncertain it assumes the object is visible. Increasing bake resolution can improve culling but increases data size and may reduce runtime speed; large scenes with overly fine settings can create enough computation tiles to exhaust bake memory. [Unity Technologies—Troubleshooting Occlusion Culling](https://docs.unity3d.com/kr/current/Manual/occlusion-culling-troubleshooting.html)

9. Unity's CullingGroup API maintains visibility and distance bands for arrays of bounding spheres, supports a camera and distance reference point, exposes state changes, and permits indexed queries. This is evidence for a batched bounds-and-band interface rather than per-object polling. [Unity Technologies—CullingGroup API](https://docs.unity3d.com/es/530/ScriptReference/CullingGroup.html)

10. Direct3D 12 predication is decoupled from occlusion queries and can predicate draw, dispatch, copy, resolve, clear, and `ExecuteIndirect` operations from a 64-bit buffer value. The predication buffer requires the appropriate indirect/predication resource state. [Microsoft—D3D12 Predication](https://learn.microsoft.com/en-us/windows/win32/direct3d12/predication)

11. Vulkan exposes occlusion queries and optional conditional rendering. These are low-level mechanisms, not a portable guarantee that per-object queries are profitable; capability and benchmark policy remain an engine responsibility. [Khronos—Vulkan 1.4 Specification](https://registry.khronos.org/vulkan/specs/latest/html/vkspec.html)

12. The CHC and CHC++ research uses spatial hierarchies plus temporal and spatial coherence to reduce query count and latency. CHC++ adds adaptive prediction and query batching, reducing queries and rendering state changes relative to naive hardware-query use. [Bittner et al.—Coherent Hierarchical Culling](https://www.cg.tuwien.ac.at/research/vr/chcull/), [Mattausch, Bittner, and Wimmer—CHC++](https://diglib.eg.org/items/fafd6769-3eb3-4949-ade9-1ac288f2484a)

13. AMD's Radeon GPU Profiler documentation identifies depth/HiZ resummarization and depth-surface decompression as real synchronization/format costs, and its performance counters distinguish primitive-assembly, compute, pixel-shader, and depth-unit behavior. Occlusion is therefore not free merely because it removes later pixels. [AMD GPUOpen—RGP Overview](https://gpuopen.com/manuals/rgp_manual/overview_windows/), [AMD GPUOpen—Performance Counters](https://gpuopen.com/manuals/gpu_performance_api_manual/counters/)

14. Unreal Engine 5.8 release notes add World Partition streaming debugging in Unreal Insights and the Editor, including per-cell analysis and session playback. This is a current example of correlating spatial streaming state with timelines rather than inspecting only aggregate counters. [Epic Games—Unreal Engine 5.8 Release Notes](https://dev.epicgames.com/documentation/unreal-engine/unreal-engine-5-8-release-notes?lang=en-US)

## Industry-Standard API, Algorithm, or Pattern

### Visibility domains

Keep four domains separate:

- **render visibility:** conservative eligibility to submit representation R for view V;
- **gameplay visibility:** deterministic sight/line-of-fire/perception rules;
- **streaming demand:** prediction that content may be needed by a deadline;
- **simulation significance:** policy for update rate/detail.

Render occlusion may inform streaming and significance as weak evidence, but it must never determine AI sight, damage, replication authority, quest state, collision existence, or durable simulation.

### Compiled spatial hierarchy

Compile static world content into a hierarchy:

`World -> Partition Cell -> Sector -> Cluster -> Instance/Primitive`

Each node contains:

`VisibilityNode = {stableId, parent, childRange, globalBounds, localBounds, flags, representationRange, portalRange, stateMask, residencyMask, generation}`

Use broad, stable nodes near the root and tighter clusters near leaves. A BVH or loose octree suits irregular exteriors; authored sectors and portals suit interiors. Hybrid spaces use both: portal traversal yields candidate sectors, then the spatial hierarchy filters contents.

Static arrays use depth-first or breadth-first linearization selected by measured traversal. Nodes store child ranges rather than pointers. Hot bounds, masks, and child data use structure-of-arrays layout. Authoring strings and diagnostics stay in editor data.

### Sector and portal potentially visible sets

A portal traversal begins from the camera sector, clips the view volume through open portals, and visits reachable sectors with:

- visited-state and depth bounds;
- projected-area cutoff;
- portal-state mask;
- cycle protection;
- maximum nodes/portals;
- conservative overflow result: visible.

For mostly static interiors, cook a compressed conservative potentially visible set (PVS) per sector or visibility cell. Dynamic door/destruction states either:

- select among a small set of cooked state variants;
- apply runtime portal closure to a conservative superset;
- invalidate to the broader hierarchy until rebaked/recompiled.

Never use an aggressive PVS that can omit visible geometry. False positives spend performance; false negatives break the image.

### Per-view candidate pipeline

For every view family:

1. union mandatory/global content and state-eligible cells;
2. find camera sector and conservative PVS/portal candidates;
3. traverse spatial bounds with distance and screen-size rejection;
4. frustum-test nodes and survivors;
5. choose representation using projected error, policy, residency, and hysteresis;
6. emit compact candidates to GPU;
7. build/reuse a conservative depth hierarchy;
8. run HZB bounds/cluster tests and compact visible draws;
9. rasterize and let hardware depth reject remaining hidden fragments.

The CPU never waits for current-frame GPU visibility. Results used across frames carry view generation, world-origin epoch, node generation, and previous transform state.

### Temporal visibility state

Use states rather than one boolean:

`Unknown -> AssumedVisible -> ConfirmedVisible -> CandidateOccluded -> ConfirmedOccluded`

Rules:

- new, changed, near-camera, or high-velocity objects start visible;
- require one or more conservative occluded confirmations before suppressing;
- retain recently visible nodes for a small hysteresis window;
- camera cuts, large FOV changes, teleports, origin shifts, resolution discontinuities, portal-state changes, and depth invalidation reset affected history to visible;
- periodically retest occluded hierarchy nodes, with priority based on projected size, camera approach velocity, and time since test.

### HLOD representation contract

Every representation group declares:

`RepresentationSet = {sourceMembers, levels[], switchMetric, hysteresis, residency, collisionPolicy, navPolicy, shadowPolicy, transitionMode}`

Selection is based on projected error/screen contribution rather than distance alone, then constrained by:

- view type and resolution;
- representation residency/readiness;
- material/shadow/animation capability;
- gameplay state and destruction;
- minimum dwell/hysteresis.

The fine representation cannot retire until the proxy is resident, valid for the current state, and safely published. Likewise, a proxy remains until fine content is ready. Visual representation changes do not implicitly swap authoritative collision, navigation, persistence, or gameplay entities.

### Multi-view policy

Build one candidate set per view, then share work only where semantics match:

- stereo eyes may share coarse candidates but need conservative union bounds;
- split-screen players have separate streaming and visibility demand, then share physical residency;
- shadow, reflection, portal, minimap, capture, and spectator views use explicit reduced policies;
- server/headless simulation has no render visibility but still owns gameplay relevance and streaming sources.

Represent visibility as a compact view-family mask only when the number of views is bounded. Otherwise use per-view arrays/ranges to avoid unbounded bitsets.

### Bounded work and overflow

Each stage has explicit caps:

- sectors/portals traversed;
- hierarchy nodes tested;
- HZB candidates;
- GPU output instances/draws;
- visibility events;
- HLOD transitions;
- streaming hints.

Overflow behavior is conservative: retain the parent/coarser representation, mark remaining candidates visible, raise telemetry, and degrade optional view detail. Never drop arbitrary geometry.

## Performance Considerations

### Algorithmic complexity

- Plane-versus-bound frustum testing is `O(N)` in candidates; hierarchy pruning makes practical work proportional to visited nodes rather than world objects.
- Portal traversal is `O(V + E)` in the visited sector graph but must be bounded because dense cyclic portal graphs can approach the full graph.
- PVS lookup is near `O(visible-set words)`; decompression and union cost depend on representation and view count.
- BVH traversal is typically `O(log N + K)` for localized candidates but degrades toward `O(N)` with poor bounds, open vistas, or invalidated hierarchy.
- HZB construction is linear in depth pixels across a geometric mip series; candidate tests are `O(C)` with bounded samples per projected bound.
- HLOD selection is `O(H)` in visited hierarchy nodes. Avoid per-frame sorting of all objects; use traversal order and append/scan compaction.

### Allocations and garbage collection

- Store static hierarchy, portal adjacency, PVS words, and HLOD descriptors in immutable cooked arrays.
- Use per-frame/per-view linear arenas and fixed-capacity GPU append buffers.
- Reuse visibility histories, view records, readback staging, query pools, and event rings.
- Avoid per-object delegates, heap nodes, futures, or boxed visibility events.
- HLOD transitions and cell activation use pooled command records; overflow must not spill to unbounded general allocation.

### Spatial data structures and cache behavior

- Quantize cell-local bounds where error analysis permits; retain global cell coordinates separately for large worlds.
- Arrange hierarchy nodes so likely siblings are contiguous and prefetchable.
- Separate hot bounds/state/generation data from cold asset handles and debug labels.
- Compress PVS with dense bitsets when visibility is broad and run/roaring-style containers when sparse; benchmark union and decompression, not storage size alone.
- Batch instances by representation/pipeline only after visibility; do not destroy spatial coherence prematurely.

### Concurrency

- CPU view setup, portal traversal, hierarchy traversal, and streaming-hint generation can run as jobs over immutable snapshots.
- GPU culling uses render-graph resources with explicit depth-write, HZB-build, compute-read/write, indirect-read, and retirement dependencies.
- Publish world/portal/HLOD revisions only at safe phase boundaries.
- Jobs are cancellable and generation-checked; late results from an unloaded cell or previous camera generation are discarded.
- Do not block the frame thread for occlusion readback or HLOD I/O.

### Navigation rebuild cost

- Visual HLOD swaps must not dirty navigation.
- Only authoritative collision/traversal changes enqueue nav dirties, coalesced by tile/chunk and world revision.
- Portal state can update the semantic visibility graph and nav link independently; a door's render occlusion result is not its traversal state.
- Streaming activation publishes navigation readiness before encounter spawning but can publish coarse visual proxies earlier.
- Stress simultaneous destruction, portal invalidation, HLOD transition, and localized nav rebuild to expose synchronized spikes.

### AI scheduling

- AI LOD consumes stable semantic sector, distance, relevance, and time-since-player-evidence—not raw per-frame renderer occlusion.
- Visibility events are coalesced and rate-limited; thousands of leaf-object changes should become one sector/representation significance update.
- Keep combatants, audible threats, projectiles, reservations, and network-authoritative actors at required simulation fidelity even when render-hidden.
- Stagger promotion when a camera turn or door opening reveals a populated sector.
- Perception continues to use deterministic physics/gameplay visibility queries described in the prior perception report.

### Streaming I/O and memory residency

- Visibility is reactive; streaming requires prediction. Generate prefetch from movement velocity, topology routes, portals, objectives, camera potential, and traversal deadlines.
- HLOD roots/proxies need explicit residency budgets and cannot be assumed free.
- Visibility feedback may lower priority only after dwell; it must not immediately evict recently occluded fine content.
- Budget peak overlap during fine/proxy handoff and Data Layer changes.
- Cold I/O, decompression, upload, descriptor publication, and GPU residency each have separate deadlines and telemetry.

### Visibility cost

Measure:

- CPU sector/portal and hierarchy time;
- nodes, bounds, sectors, portals, and PVS bytes processed;
- HZB build time, candidate tests, output counts, and overflows;
- occlusion query count/latency if used;
- processed/visible primitives and instances;
- indirect command counts and small-batch distribution;
- depth-prepass cost, depth bandwidth, HiZ transitions/resummarization;
- false-positive overdraw and false-negative/popping defects;
- HLOD transition count, proxy draw/material cost, and residency.

The optimization is profitable only when removed downstream work exceeds culling, depth, synchronization, memory, and transition cost.

### Frame-time budgets

Assign budget envelopes per platform and view type. At 60 Hz the whole frame is 16.67 ms; no universal visibility number is valid. Establish measured targets for:

- main-view CPU visibility;
- auxiliary-view visibility;
- depth/HZB GPU work;
- culling/compaction GPU work;
- HLOD/streaming transition CPU and copy work;
- maximum events and activations.

Gate p95/p99 and hitch maximums, not averages. Report both total saved cost and culling overhead.

### Worst-case behavior

Required cases include:

- camera teleport/cut into an open vista;
- 180-degree turn from an occluded interior to dense exterior;
- rapid FP FOV change and TP shoulder swap;
- multiple doors opening in a cyclic interior;
- destruction of a major occluder;
- split-screen players facing disjoint dense regions;
- reflection/shadow views multiplying candidates;
- Data Layer transition plus HLOD invalidation;
- cold streaming plus fine/proxy overlap;
- GPU output-buffer overflow;
- origin shift during visibility jobs;
- minimum-spec CPU/GPU with simultaneous AI promotion and nav rebuild.

## Pros and Cons

### Pros

- Cheap conservative stages prevent expensive fine tests for entire regions.
- A semantic sector layer benefits streaming, HLOD, AI LOD, audio, and debugging.
- Stable temporal policy avoids query stalls and reduces popping.
- Explicit representation handoff prevents holes during streaming.
- Multi-view policy exposes costs that are otherwise hidden in duplicated per-camera work.
- Conservative overflow preserves correctness.

### Cons

- Sector/portal authoring and validation add production cost.
- PVS data consumes cook time, storage, and runtime memory and ages under dynamic destruction.
- Coarse bounds and HLOD grouping can reduce occlusion precision.
- GPU culling adds depth/HZB, compute, barriers, buffers, and debugging complexity.
- Visibility-derived streaming can thrash if treated as immediate truth.
- Multi-view unions can become overly conservative, while separate work can be expensive.

## ECS and World-Partition Integration

Recommended records:

- `VisibilityNodeRecord`: parent/children, bounds, state mask, representation set, generation;
- `SectorRecord`: cell owner, bounds, portal range, PVS handle;
- `PortalRecord`: sectors, aperture, open/state mask, revision;
- `RepresentationSetRecord`: fine/proxy members, error thresholds, residency/readiness;
- `RenderProxyRecord`: renderer handle, bounds, flags, generation;
- `ViewRecord`: family/type, matrices, frustum, origin epoch, generation, policy;
- `VisibilityHistoryRecord`: node/view key, state, last visible/tested frame, confidence;
- `CellVisibilitySummary`: per-view eligibility, last demand, transition state, overflow flags.

The gameplay ECS stores logical render representation, significance policy, and stable world identity. The renderer owns per-view visibility history, GPU buffers, HZB, query pools, indirect commands, and physical HLOD resources.

World Partition provides coarse cell ownership and residency. Semantic sectors may cross neither cell ownership nor persistence boundaries without explicit references. Cross-cell portal edges use stable IDs and resolve only when both descriptors exist; conservative fallback treats unresolved destination visibility as potentially visible and issues prefetch.

Unloading:

1. revoke new fine-representation selection;
2. ensure proxy/coarse fallback is ready if needed;
3. cancel generation-bound visibility and streaming jobs;
4. retire GPU handles after fences;
5. remove histories keyed to the old cell generation;
6. retain only coarse topology/persistence records.

## Navigation, AI, Streaming, and Event Interfaces

Engine-neutral interfaces:

- `IVisibilityWorld::AcquireSnapshot(worldRevision)`
- `IVisibilityWorld::LocateSector(globalPosition, stateMask)`
- `IVisibilityQuery::BuildCandidates(view, snapshot, budget)`
- `IRepresentationSelector::Select(node, viewPolicy, residencySnapshot)`
- `IVisibilityFeedback::ConsumeSummary(viewFamily, frameId)`
- `IStreamingService::SubmitVisibilityHint(cellId, confidence, deadline)`
- `ISignificanceService::SubmitSectorEvidence(sectorId, viewFamily, age)`
- `IPortalService::SetState(portalId, state, revision)`
- `IHLODService::RequestRepresentation(setId, level, deadline)`
- `IVisibilityDiagnostics::Capture(viewFamily, stages)`

Events:

- `PortalStateChanged`;
- `VisibilityWorldRevisionPublished`;
- `CameraDiscontinuity`;
- `RepresentationRequested`, `RepresentationReady`, `RepresentationRetired`;
- `SectorBecamePotentiallyVisible`, `SectorVisibilityDwelledOut`;
- `VisibilityBudgetOverflow`;
- `VisibilityHistoryInvalidated`;
- `MajorOccluderChanged`;
- `CellVisibilityDemandChanged`.

Events are sector/representation level, coalesced, stable-ID based, generation tagged, and delivered at explicit phase boundaries. Leaf visibility remains renderer-private.

## Integration Plan

### Phase 0 — Capture the uncullable baseline

- Select indoor, outdoor, destruction, high-speed, FP, TP, split-view, and minimum-spec scenes.
- Capture processed primitives, visible elements, draw/dispatch counts, CPU visibility, depth/HZB, GPU frame time, overdraw, and residency.
- Identify whether the bottleneck is submission, vertex/primitive, pixel, bandwidth, or shading before adding culling complexity.

### Phase 1 — Bounds and representation hygiene

- Validate bounds, scale, mobility, occluder flags, distance bands, and HLOD membership.
- Add stable representation sets and fine/proxy readiness handoff.
- Establish camera-cut/origin/state invalidation.

### Phase 2 — CPU hierarchy and sector graph

- Compile cells, sectors, portals, clusters, and state masks into flat snapshots.
- Add bounded portal/PVS and hierarchy traversal.
- Provide overlays for candidate source and rejection reason.

### Phase 3 — GPU HZB and compaction

- Reuse the existing GPU-driven submission architecture.
- Build conservative HZB from a measured depth strategy.
- Add bounds/cluster culling, prefix/append compaction, overflow fallback, and graph synchronization.
- Compare against CPU-only/frustum-only and vendor/platform baselines.

### Phase 4 — World-system consumers

- Feed confidence- and dwell-based hints to streaming.
- Feed sector-level evidence to significance/AI LOD without changing gameplay truth.
- Stage sector reveals to avoid simultaneous AI, animation, nav, and asset promotion spikes.

### Phase 5 — Production policy

- Tune per platform/view profile.
- Cook PVS only where measured value exceeds memory/build cost.
- Gate bounds, false-negative imagery, buffer overflow, proxy holes, culling regressions, and combined worst-case hitches.

## Verification and Profiling Strategy

### Correctness

- Compare culling-enabled output against an uncullable reference using deterministic camera paths and image masks.
- Poison culled draws with a bright debug shader in validation builds to detect false-negative visibility.
- Exercise bounds under animation, world-origin shifts, deformation, attachments, destruction, and negative/non-uniform scale.
- Validate portals for gaps, cycles, one-way/state transitions, unresolved cross-cell edges, and camera-on-plane cases.
- Verify HLOD fine/proxy state equivalence for supported destruction and Data Layer states.
- Force every overflow and confirm conservative visible/proxy fallback.

### Temporal tests

- camera cuts, teleports, FOV/aspect/dynamic-resolution changes;
- FP sprint/lean and TP shoulder swap/orbit;
- fast lateral motion around thin occluders;
- recently hidden/revealed nodes;
- door opening and large occluder destruction;
- view creation/destruction and split-screen join/leave.

Measure late-visible frames, retained-visible frames, transition oscillation, and history reset causes.

### Performance experiments

Run controlled A/B modes:

- no occlusion;
- CPU distance/frustum only;
- sector/PVS plus frustum;
- hardware queries;
- HZB instance/cluster culling;
- each with and without HLOD.

For each, record culling overhead, downstream work saved, total CPU/GPU frame time, memory, I/O, and hitch distributions. A higher culled count is not automatically a win.

### Automated world tests

- traverse every critical sector/portal route with FP and TP cameras;
- replay seeded worst-camera paths on packaged minimum-spec builds;
- toggle all required Data Layer/door/destruction states;
- separate co-op/split views across streaming fronts;
- force cold cache, constrained I/O, output overflow, and HLOD cache pressure;
- combine sector reveal with encounter promotion, perception, nav dirtying, physics activation, and save/load;
- soak for history leaks, stale generations, oscillation, residency creep, and event storms.

### Debug overlays and telemetry

Overlay by stage:

- world-state excluded;
- cell/sector/PVS rejected;
- distance/frustum rejected;
- representation selected/pending/fallback;
- HZB tested/visible/occluded/history-retained;
- overflow-forced visible;
- streaming and significance hints.

Every capture includes view family, camera generation, world revision, origin epoch, platform profile, buffer capacities, PVS/HLOD versions, and reproduction seed.

## Risks and Open Decisions

- Authored sectors/portals, automatic spatial hierarchy, or hybrid?
- PVS only for interiors/mobile, or also selected exterior settlements?
- PVS compression format and per-platform memory ceiling?
- CPU versus GPU ownership of distance/frustum tests?
- Previous-frame versus current-frame depth; full prepass versus partial occluder depth?
- HZB bounds test method, mip choice, epsilon, and near-plane handling?
- Minimum occluder size and which dynamic objects may act as occluders?
- Visibility-history confirmation counts, dwell, periodic retest, and camera-cut thresholds?
- HLOD switch metric, transition mode, hysteresis, and peak-overlap budget?
- Fine/proxy grouping granularity versus culling precision and draw-call reduction?
- Shared stereo/multi-view unions versus separate traversal?
- Auxiliary-view quality policy for shadows, reflections, captures, minimap, and spectator?
- Can visibility lower streaming priority, and after what dwell/confidence?
- How should sector evidence influence AI/animation/audio LOD without correctness coupling?
- Required behavior when portals, PVS, HLOD, or GPU candidate buffers overflow?
- Platform-specific gates for CPU traversal, depth/HZB cost, culling compute, memory, and visible elements?

## Engineering Recommendations

The following are engineering recommendations, not claims made directly by sources:

1. Adopt a conservative hierarchical visibility pipeline: state/cell, sector/PVS, distance/frustum, HLOD selection, GPU HZB/compaction, then hardware depth.

2. Keep render visibility, gameplay visibility, streaming demand, and simulation significance as separate domains. Exchange bounded evidence through explicit interfaces; never share a truth bit.

3. Use hybrid spatial organization: authored sectors/portals for enclosed spaces and a cooked BVH/loose hierarchy for exteriors. Compile both into flat immutable snapshots.

4. Make all rejection conservative. On unknown state, stale generation, camera discontinuity, missing residency, or overflow, prefer visible or a valid coarse proxy.

5. Use temporal coherence without trusting it blindly: recently visible retention, delayed occluded confirmation, periodic retest, and aggressive invalidation on camera/world changes.

6. Treat HLOD as a representation-residency transaction. Publish a replacement before retiring its predecessor, budget peak overlap, and keep authoritative collision/navigation/gameplay separate.

7. Reuse the existing GPU-driven indirect pipeline for surviving candidates. Do not introduce per-object CPU readback or synchronous occlusion results.

8. Feed streaming with topology and motion prediction first; use visibility as confidence-weighted secondary evidence with hysteresis. Occlusion alone must never trigger immediate eviction.

9. Feed AI LOD only coalesced sector-level significance evidence. Never use renderer occlusion for AI sight, targeting, collision, replication, or durable state.

10. Build capability profiles for main, stereo, split, reflection, shadow, capture, and headless views. Share work only when conservative semantics match.

11. Gate profitability, not cull percentage. Require total-frame improvement after counting depth/HZB, compute, barriers, memory, event, transition, and false-positive costs.

12. Make combined worst cases a release gate: camera discontinuity, major reveal/destruction, cold streaming, HLOD overlap, encounter/AI promotion, and nav update on minimum-spec hardware.

## Source Links

- [Epic Games—Visibility and Occlusion Culling in Unreal Engine 5.8](https://dev.epicgames.com/documentation/en-us/unreal-engine/visibility-and-occlusion-culling-in-unreal-engine)
- [Epic Games—Visibility and Occlusion Culling Reference](https://dev.epicgames.com/documentation/en-us/unreal-engine/visibility-and-occlusion-culling-reference-in-unreal-engine)
- [Epic Games—Precomputed Visibility Volumes](https://dev.epicgames.com/documentation/unreal-engine/precomputed-visibility-volumes-in-unreal-engine)
- [Epic Games—World Partition HLOD](https://dev.epicgames.com/documentation/en-us/unreal-engine/world-partition---hierarchical-level-of-detail-in-unreal-engine)
- [Epic Games—World Partition](https://dev.epicgames.com/documentation/unreal-engine/world-partition-in-unreal-engine?lang=en-US)
- [Epic Games—Unreal Engine 5.8 Release Notes](https://dev.epicgames.com/documentation/unreal-engine/unreal-engine-5-8-release-notes?lang=en-US)
- [Unity Technologies—Troubleshooting Occlusion Culling](https://docs.unity3d.com/kr/current/Manual/occlusion-culling-troubleshooting.html)
- [Unity Technologies—CullingGroup API](https://docs.unity3d.com/es/530/ScriptReference/CullingGroup.html)
- [Microsoft—Direct3D 12 Predication](https://learn.microsoft.com/en-us/windows/win32/direct3d12/predication)
- [Microsoft—D3D12 Predication and Queries Sample](https://learn.microsoft.com/en-us/samples/microsoft/directx-graphics-samples/d3d12-predication-and-queries-sample-win32/)
- [Khronos Group—Vulkan 1.4 Specification](https://registry.khronos.org/vulkan/specs/latest/html/vkspec.html)
- [Bittner et al.—Coherent Hierarchical Culling](https://www.cg.tuwien.ac.at/research/vr/chcull/)
- [Mattausch, Bittner, and Wimmer—CHC++](https://diglib.eg.org/items/fafd6769-3eb3-4949-ade9-1ac288f2484a)
- [AMD GPUOpen—Radeon GPU Profiler Overview](https://gpuopen.com/manuals/rgp_manual/overview_windows/)
- [AMD GPUOpen—GPU Performance Counters](https://gpuopen.com/manuals/gpu_performance_api_manual/counters/)
