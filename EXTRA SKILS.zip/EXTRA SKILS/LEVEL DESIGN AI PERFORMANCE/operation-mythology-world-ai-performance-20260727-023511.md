# Operation Mythology Research Report

## Squad Coordination, Tactical Positioning, Cover, Spawning, Encounter Direction, and AI LOD

**Timestamp:** 2026-07-27 02:35:11 America/Los_Angeles  
**Status:** New baseline for an uncovered domain  
**Assumptions:** Generic modular ECS, data-oriented memory, FP/TP gameplay, event-driven agent decisions and perception, tiled navigation/world partition, authoritative server where applicable, and no production-code implementation.

## Feature Overview

This report defines a hierarchy for coordinated encounters:

`Encounter Director -> Encounter Instance -> Squad Coordinator -> Role/Intent Assignment -> Tactical Query -> Reservation -> Individual Action`

Each level owns a different decision:

- **Encounter Director:** pacing envelope, population budget, reinforcement timing, and encounter phase.
- **Encounter Instance:** authored constraints, objectives, spawn pools, exits, fail/complete state, and cleanup.
- **Squad Coordinator:** shared target/knowledge, confidence, frontline or formation, role limits, and coordinated maneuvers.
- **Tactical Position Service:** bounded candidate generation, filters, scores, and top results for cover, firing, flank, retreat, support, and companion placement.
- **Reservation Service:** exclusive or capacity-limited claims on cover, lanes, smart-object slots, traversal links, and spawn anchors.
- **Individual AI:** validates the assigned intent against personal belief, capability, path, and action state.

The recommended baseline is a **hybrid authored/systemic model**:

- designers author encounter envelopes, possible spawn groups, traversal constraints, tactical annotations, and mandatory beats;
- runtime systems select among validated alternatives, coordinate squads, and adjust pacing;
- the Director controls *when and how much pressure* rather than silently changing every combat rule;
- individual agents retain local autonomy and can fail, replan, or refuse impossible assignments.

The system must produce readable, fair combat, not merely optimal focus fire. Coordination includes intentional gaps, reaction delays, limited simultaneous attackers, role diversity, and visible/audible communication.

## Existing Coverage and Identified Gap

The required scan of `C:\Users\steve\Desktop\GAME SKILLS` found thirteen reports plus its index. Newly covered subjects include open-world partition/origin management and server-authoritative networking/rollback. Earlier coverage includes ECS/jobs, physics/controller, animation, GPU/renderer architecture, asset residency, and global/direct lighting.

The required scan of `C:\Users\steve\Desktop\EXTRA SKILS\LEVEL DESIGN AI PERFORMANCE` found three reports plus its index:

- navigation queries, path caching/replanning, off-mesh links, and local avoidance;
- hybrid StateTree/BT/utility/GOAP/HTN decision architecture and scheduling;
- perception, belief memory, suspicion, threat, and team communication.

No scanned report defines:

- squad creation, merge/split, membership, or leadership;
- shared objectives versus personal autonomy;
- role assignment, capacity, commitment, and reassignment;
- cover/tactical candidate generation, scoring, contention, and reservation;
- frontline/lane/flank/retreat coordination;
- influence/danger/exposure fields;
- valid spawn-point selection, visibility/fairness, population pooling, and cleanup;
- encounter pacing state, intensity estimates, director budgets, or failure modes;
- AI LOD across decision, simulation, representation, replication, and group state;
- combined squad/director telemetry and automated encounter testing.

This batch fills those gaps. It does not repeat the underlying perception, pathfinding, behavior-tree, physics, rendering, or network protocols.

## Sourced Facts

The following are source-backed facts; engineering recommendations appear separately.

1. Unreal Engine 5.8 EQS separates candidate generators, contexts, tests, and weighted results. Epic explicitly lists attack positions, cover, and pickups as applications and supports invoking EQS from behavior trees.

2. Unreal Smart Objects use a global database and spatial partition. Agents query by area and gameplay tags, and interaction slots use a reservation model. Smart Objects carry interaction information but not the interactor's execution logic.

3. Unreal Mass Gameplay includes spawning, simulation/representation/replication LOD, StateTree integration, signals, and Smart Object integration. Its LOD system exposes High, Medium, Low, and Off tiers with configurable distances and maximum entity counts.

4. Kevin Dill's Game AI Pro tactical-position architecture separates generation, conditions/filters, weights, and result return. It recommends generating candidates in relevant small areas, normalizing weighted values, and using fallback options when the preferred query has no valid result.

5. The same tactical-position source describes database points, runtime grids/rings, cover rails, nav data, and entity positions as candidate sources. It notes that raycasts can dominate position-selection cost and recommends deferring expensive tests and using asynchronous batching.

6. The tactical-position source identifies contention when parallel agents select the same position and proposes returning a small number of alternatives, combined with occupancy/reservation handling.

7. Tobias Karlsson's *Days Gone* squad-coordination chapter describes squads that can merge/split by spatial relationship, a combat frontline, lanes that distribute squad members, and squad modes including forming, normal combat, retreating, and pressing.

8. The *Days Gone* chapter describes alternating retreat/advance waves where some members move while others provide cover fire. It warns that a rapidly changing frontline causes repeated position invalidation and indecisive movement, motivating stabilization.

9. Michael Booth's Valve presentation describes *Left 4 Dead* population using navigation mesh, flow distance, potential visibility, and an active-area set. It describes spawning into active areas not visible to survivors and reusing/deleting entities as the active area moves.

10. Booth describes “structured unpredictability” as designer-bounded variation rather than pure randomness or uniform determinism. He reports using different population functions for wanderers, mobs, specials, bosses, weapons, and items.

11. Booth's adaptive pacing tracks survivor intensity, enters Build Up, Sustain Peak, Peak Fade, and Relax phases, and removes major threat generation when intensity is high. The presentation explicitly says the algorithm adjusts pacing frequency rather than difficulty amplitude.

12. Booth's presentation preserves authored boss beats outside ordinary adaptive pacing and uses designer-placed possible item-cache groups so procedural selection retains visual storytelling and placement quality.

## Industry-Standard API, Algorithm, or Pattern

### Encounter Director boundary

The Director consumes aggregated, intentionally limited telemetry:

- encounter phase and progress;
- alive/downed player counts;
- recent damage/near-death;
- active hostile cost;
- combat engagement state;
- time since pressure/relaxation;
- player separation and movement rate;
- resource scarcity bands;
- authored beat constraints;
- platform/server population budget.

The Director outputs a `PressurePolicy`, not direct agent commands:

- pacing phase;
- desired active hostile budget;
- allowed reinforcement groups;
- spawn priority and delay;
- special-role caps;
- optional resource-drop envelope;
- minimum relaxation;
- mandatory authored beat status.

Use a small explicit state machine:

`Dormant -> BuildUp -> Sustain -> Fade -> Relax -> BuildUp`

Transitions use hysteresis, minimum dwell, cooldowns, progress gates, and authored overrides. Record every transition cause.

Keep **pacing** distinct from **difficulty**. Pacing changes frequency/timing/population within declared content. Difficulty changes health, damage, aim, reaction, resource abundance, or composition rules and requires separate, visible design policy.

### Encounter instance

An encounter asset defines:

- bounds and world cells;
- objectives and completion/failure conditions;
- encounter tags/themes;
- allowed spawn groups and total cost;
- reinforcement gates;
- spawn anchors/volumes/portals;
- tactical zones and fallback areas;
- squad templates and role caps;
- mandatory/optional beats;
- despawn/cleanup rules;
- save/load policy;
- telemetry identity and version.

Runtime `EncounterInstance` stores only mutable state: phase, budget, spawned groups, cooldowns, objective state, director token, active squads, random-stream state, and revision.

Random selection uses a seeded stream and weighted bags/anti-repeat constraints. “Random” cannot bypass validity, fairness, population, or memory checks.

### Spawn validation pipeline

Spawn selection:

1. collect authored anchors/volumes and systemic nav candidates within the encounter's allowed set;
2. require resident/SimReady world and nav data;
3. filter by agent bounds, traversal profile, and spawn-volume capacity;
4. filter by minimum/maximum path or flow distance;
5. reject current player visibility using conservative multi-player visibility/PVS plus bounded rays;
6. reject immediate audio/physical intrusion unless explicitly authored;
7. check reachable engagement route and maximum arrival time;
8. check density, squad composition, population/memory budgets, and network interest;
9. score remaining points;
10. reserve anchor and required nav/stream cells;
11. stage/spawn hidden;
12. activate only after dependencies are ready.

Return explicit failure: no valid point, streaming missing, nav unavailable, visibility uncertain, population cap, memory cap, cooldown, or encounter invalid. The Director waits, relaxes constraints through authored fallbacks, or skips; it never spawns visibly because the queue is impatient.

### Population representation

Use a population cost rather than raw count:

`cost = simulation + perception + navigation + animation + rendering + replication + role pressure`

Cost is a platform-tuned estimate updated from traces. Maintain:

- active full agents;
- reduced/coarse agents;
- pooled inactive representations;
- persisted population records;
- pending spawn/despawn;
- special-role caps;
- per-encounter and global ceilings.

Entity pooling may reduce construction churn but must reset generations, subscriptions, reservations, beliefs, plans, animation state, replication state, and debug identity. Pooling is not a substitute for correct lifetime management.

### Squad identity and membership

A squad owns:

- stable squad ID/generation;
- members and role/capability summaries;
- leader/coordinator policy;
- shared objective;
- shared belief/report handle;
- confidence/morale state;
- reference frame: target centroid, frontline, formation, or zone;
- role assignments and reservations;
- maneuver state;
- update revision.

Squad join/leave/merge/split occurs at coordinator barriers. Use connectivity or distance with hysteresis and minimum dwell; do not merge/split every frame at an exact radius. Persistent authored squads may prohibit automatic merge.

Leadership is a coordination role, not necessarily an in-world character. If the visible leader dies, policy may transfer after a reaction delay rather than instantly.

### Shared versus personal decisions

Squad owns:

- objective and coarse maneuver;
- target priority policy;
- role capacity;
- shared tactical frame;
- coordinated timing;
- resource/position reservations.

Individual owns:

- whether assignment is locally executable;
- exact path/action;
- immediate survival interrupts;
- personal perception uncertainty;
- animation/weapon/action state.

An assignment is a request with generation, deadline, commitment, and cancellation rule. Agents return accept, reject with reason, in-progress, succeeded, or failed. The coordinator cannot teleport an agent or override safety cleanup.

### Role assignment

Roles include hold, suppress, flank-left/right, advance, retreat, assault, overwatch, medic/support, objective interaction, reserve, and companion.

Build a bounded agent-role cost matrix using:

- capability/equipment;
- path/time to role zone;
- current cover/exposure;
- health/ammo/status;
- role continuity/switch cost;
- current action interruptibility;
- personality/archetype;
- player readability;
- role capacity and pair compatibility.

For small squads, exhaustive/permutation, Hungarian assignment, or min-cost matching is practical. For larger groups, greedy sorted assignment with repair is often sufficient. Recompute only when membership, objective, capabilities, or maneuver state materially changes.

Apply commitment and hysteresis. A marginal score improvement must not repeatedly swap roles.

### Frontline, lanes, formations, and maneuvers

For shooter combat, derive a stable 2D tactical frame:

- squad centroid;
- enemy/target centroid and uncertainty;
- combat direction;
- frontline origin/normal;
- neutral band;
- friendly/enemy-controlled regions;
- lateral lanes or sectors;
- flank regions;
- retreat direction;
- authored constraints.

Low-pass and dead-zone the frame. Exclude specialist agents whose extreme position would distort it. Update immediately only for material threats or invalid topology.

Maneuvers are coordinated state machines:

- **form:** movers reach assigned lanes while ready members cover;
- **advance:** alternating waves move toward new positions;
- **retreat:** exposed/front members move while rear members suppress;
- **flank:** pinning roles retain pressure while selected flankers move through validated side regions;
- **breach:** reserve door/entry slots and synchronize stack/entry actions;
- **disengage:** break line of sight, release pressure, and reform.

Each maneuver has abort conditions, timeout, minimum participants, role dependencies, and fallback. Coordination should allow staggered execution rather than a global barrier that deadlocks when one agent is stuck.

### Tactical position query

A `TacticalQuery` contains:

- query type;
- context positions/entities;
- candidate sources;
- search region and radius;
- agent/traversal profile;
- mandatory filters;
- normalized score criteria and weights;
- expensive-test budget;
- result count;
- reservation requirement;
- fallback options;
- deadline and priority;
- relevant world/nav/perception revisions.

Pipeline:

1. collect/generate bounded candidates;
2. cheap static filters;
3. cheap score and upper-bound calculation;
4. partial selection/top-K;
5. expensive async visibility/path/exposure tests only for promising candidates;
6. final score;
7. return top few;
8. atomically reserve chosen point/slot;
9. validate before action start.

Candidate sources:

- authored cover points/rails;
- navmesh boundary/edge-derived cover;
- smart-object slots;
- sampled nav polygons;
- formations/lanes;
- dynamic object-relative points;
- fallback LOS-blocked positions.

Filters:

- nav reachability/agent clearance;
- reservation/capacity;
- cover height/stance;
- line of fire and friendly-fire risk;
- grenade/hazard/threat exclusion;
- encounter/role zone;
- world-cell readiness.

Scores:

- path cost;
- exposure to known threats;
- ability to fire/observe;
- distance band;
- flank angle;
- spacing from allies/player;
- player camera/line-of-fire interference for companions;
- objective relation;
- cover quality/durability;
- continuity/switch cost.

Return metadata and stable resource IDs, not just a vector.

### Cover lifecycle and reservation

Cover resources include stable ID, transform/rail parameter, stance, normal, arc, height, durability, capacity, nav approach, fire points, world revision, and owner generation.

Reservation states:

`Free -> SoftHeld -> Claimed -> Occupied -> Releasing -> Free`

Soft hold is short and exists between query result and claim. Claims expire unless renewed by progress. Occupancy is confirmed only when agent reaches the slot. Destruction/nav invalidation cancels claims with explicit reason.

For rails or continuous cover, reserve an interval with agent-radius padding, not one discrete point. Companion/player priority policies must be explicit.

### Influence, danger, and exposure fields

Use fields for broad tactical bias, not exact collision:

- danger/fire density;
- known enemy influence;
- ally support;
- exposure;
- objective attraction;
- recent death/suppression;
- traversal congestion.

Represent as nav-region/tile values or coarse grids. Update from bounded events with decay and diffusion/flood only when required. Separate channels and revisions. Do not combine all meaning into one opaque scalar.

Pathfinding may integrate a field as a cost using a snapshot revision. Tactical selection samples it cheaply before exact tests. Fields need saturation and decay to prevent permanent historical contamination.

### AI LOD across systems

LOD is multi-dimensional:

- simulation;
- decision;
- perception;
- navigation;
- animation;
- representation;
- replication;
- audio;
- squad/group coordination.

Use one significance input but independent subsystem outputs. Tiers:

- **Full:** detailed agent decisions, perception, path following, tactical queries, animation, replication.
- **Reduced:** slower decisions/perception, simplified queries, retained squad role, lower animation rate.
- **Coarse:** squad/encounter-level aggregate movement/state; no detailed cover/path unless promoted.
- **Dormant:** persisted population record and encounter/squad counts only.

Promotion/demotion is transactional. A coarse squad can simulate progress, losses, and location at aggregate resolution only if gameplay rules allow it. When players approach, promotion staging validates spawn/positions/nav and distributes work over frames.

## Performance Considerations

### Algorithmic complexity

Let `A` be agents, `Q` tactical queries, `C` candidates per query, `K` expensive finalists, `S` squad size, `P` spawn candidates, and `F` field cells/edges.

- spatial candidate collection: expected `O(C)` after grid/BVH lookup, not `O(all points)`;
- filter/cheap scoring: `O(C * criteria)`;
- top-K selection: `O(C log K)` with bounded heap or expected `O(C)` selection;
- expensive tests: `O(K * queryCost)`;
- small-squad assignment: Hungarian `O(S^3)`; greedy `O(SR log(SR))` for roles `R`;
- membership connectivity: expected `O(A + neighbor pairs)` using spatial buckets;
- influence update: `O(changed cells/events)`; full diffusion/flood can approach `O(F + E_F)`;
- Director update: `O(active encounters + spawn candidates evaluated)`;
- active population processing: proportional to agents per subsystem LOD, not total persisted population.

The primary practical costs are spatial collection cache misses, raycasts, path queries, role thrashing, and mass promotion/spawning.

### Allocations and garbage collection

- Compile encounter, squad-template, query, role, and spawn definitions into immutable data.
- Pool encounter/squad records, assignment matrices for supported sizes, query contexts, candidate buffers, score arrays, reservations, director requests, and spawn tickets.
- Use per-worker arenas for candidate evaluation.
- Use fixed-size top-K buffers.
- Bulk create/destroy ECS archetype chunks; do not allocate one behavior object per spawn.
- Stable frames produce zero managed garbage and no general-heap allocation.
- Pool exhaustion returns explicit failure/degradation; it never expands during a combat spike.

### Spatial structures and cache behavior

Store tactical points/cover/smart slots in cell-sharded spatial indices with compact SoA hot data. Candidate type, position, normal, flags, capacity, and revision stay contiguous. Expensive or authoring metadata stays cold.

Sort query batches by cell/query definition and expensive-test type. Group visibility traces by physics scene/mask. Cache static criteria and invalidate through geometry/nav/encounter revisions.

Squad hot state fits in compact records. Member arrays are dense and small. Avoid pointer-rich graphs and per-member maps in hot coordination loops.

### Concurrency

Parallelizable:

- candidate collection by query/cell;
- cheap filters/scores;
- async visibility and path estimates;
- independent squad summaries;
- influence-field event accumulation;
- spawn candidate validation.

World mutation, reservations, membership changes, assignment publication, and spawning commit at barriers. Query results contain generations/revisions; stale results are validated before reservation.

Atomic position claims require a centralized reservation service or deterministic batched arbitration. Do not let worker queries directly mark shared cover.

No AI worker blocks on physics, navigation, streaming, animation, or network. Queries continue across frames.

### Navigation rebuild cost

Tactical systems consume nav snapshots and revisions. Destructible cover:

1. immediately invalidates/rescores cover resource;
2. applies a local nav modifier if needed;
3. queues bounded tile rebuild only for persistent geometry;
4. cancels affected reservations/paths;
5. triggers new tactical queries with cooldown.

Do not rebuild nav for ordinary cover occupancy, suppression, or danger. Influence fields are query/path costs, not geometry.

Spawn staging pins required nav cells. If route-to-engagement is missing, spawn remains pending or selects another point.

### AI scheduling

Work priority:

1. active safety/invalid reservations;
2. current combat assignment failure;
3. encounter mandatory beat;
4. spawn needed to meet active pressure target;
5. squad maneuver transition;
6. tactical reposition;
7. background formation/LOD/field maintenance.

Central budgets cover:

- tactical candidates;
- expensive traces;
- path estimates;
- squad recomputes;
- role matrix solves;
- spawn validations/activations;
- Director decisions;
- LOD promotions.

Use aging and deadlines. Do not update every squad/frontline/director every frame. Events wake work; periodic validation is staggered. Preserve active valid assignments when the scheduler is overloaded.

### Streaming I/O and memory residency

Encounter cells declare:

- spawn anchors/volumes;
- cover/rail/smart-object data;
- tactical zones;
- nav and PVS dependencies;
- squad templates;
- encounter definitions;
- population/activation estimates.

The Director can request prefetch but cannot activate into an unready cell. Spawn assets pass through existing asset/GPU residency. Reserve headroom for a whole validated spawn group before committing.

Unload:

- stop new encounter/spawn requests;
- cancel tickets and reservations;
- serialize encounter/squad aggregate state;
- demote or migrate eligible agents;
- remove tactical indices in bulk;
- retire visual/physics/nav resources through their owners.

Avoid a pool of fully constructed hidden agents if it retains large animation, physics, perception, and renderer resources. Prefer lightweight population records plus bounded warm objects based on measured construction cost.

### Visibility cost

Spawn fairness requires conservative multi-player visibility:

- PVS/portal/sector rejection;
- camera/frustum plus line-of-sight;
- recent-seen area history;
- audio proximity;
- special rules for mirrors/cameras/remote views if gameplay relevant.

Renderer occlusion alone is insufficient. It may be delayed and camera-specific. Use gameplay visibility/perception contracts.

Tactical line-of-fire and cover checks share batched physics query infrastructure but have separate budgets and semantic masks. Cache only against explicit geometry revisions.

### Frame-time budgets and worst cases

For 60 Hz, total time is 16.67 ms. Group/director work must coexist with perception, planning, navigation, physics, animation, streaming, networking, and rendering.

Worst cases:

- global alert forms/merges many squads;
- target moves and destabilizes every frontline;
- grenade/destruction invalidates many cover points;
- parallel queries select the same top cover;
- encounter requests a group while memory/I/O is pressured;
- all valid spawn points are visible to split players;
- squad repeatedly advances/retreats around confidence threshold;
- narrow level provides no flank/retreat option;
- many agents promote from coarse to full at once;
- influence events flood a large field;
- network interest and local simulation LOD disagree;
- Director reacts to noisy metrics and oscillates;
- cleanup leaves reservations or pooled state;
- minimum-spec hardware receives encounter activation plus nav/perception spikes.

Use hysteresis, dwell, cooldown, top-K alternatives, explicit failure, staged promotion, admission control, and hard queue/pool bounds.

## Pros and Cons

### Central squad coordination

**Pros:** readable maneuvers, role caps, coordinated timing, less individual conflict.  
**Cons:** coordinator failure affects many agents; can feel scripted; requires individual refusal/fallback and robust stale-state handling.

### Tactical position service

**Pros:** reusable across cover, flank, retreat, companion, target, and spawn choices; designer-tunable; supports async optimization.  
**Cons:** candidate/criterion growth can explode cost; ray/path tests are expensive; weights require tooling and sensitivity tests.

### Authored cover/smart slots

**Pros:** predictable quality, metadata, animation alignment, stable reservation identity.  
**Cons:** authoring/build cost, destruction/revision burden, incomplete coverage in dynamic worlds.

### Runtime-generated positions

**Pros:** adapts to dynamic geometry and sparse authoring; provides fallback.  
**Cons:** more physics/nav queries, weaker semantic metadata, potential instability between frames.

### Encounter Director

**Pros:** pacing, replayability, population budgeting, structured variation.  
**Cons:** can feel manipulative/unfair, risks oscillation, complicates deterministic tests and multiplayer authority.

### Coarse population/AI LOD

**Pros:** supports large worlds and crowds within fixed budgets.  
**Cons:** promotion seams, aggregate-simulation approximation, cross-system synchronization, persistence complexity.

## ECS and World-Partition Integration

Recommended ECS components:

- `EncounterMembership`: encounter ID/generation;
- `SquadMembership`: squad ID/generation and join revision;
- `SquadRole`: role, assignment generation, commitment;
- `SquadObjective`: compact shared objective handle;
- `TacticalIntent`: query/result/reservation handles;
- `CoverUser`: cover resource and stance/rail interval;
- `FormationSlot`: slot/lane assignment;
- `PopulationCost`: simulation/representation/replication cost class;
- `AILOD`: subsystem tier outputs and significance;
- `SpawnState`: ticket and staged activation state;
- `PersistentEncounterAgent`: population/archetype/durable status for dormancy.

Services own encounter/director state, squad records, role matrices, tactical indices, influence fields, reservations, spawn tickets, and population pools. Components store handles, not pointers or variable candidate lists.

Phase order:

1. perception/decision facts update;
2. encounter/director metrics aggregate;
3. squad membership/objective/maneuver decisions run;
4. role assignments publish;
5. tactical/spawn queries run asynchronously;
6. reservations arbitrate;
7. individual actions/path requests start;
8. LOD/spawn/demotion structural commands commit;
9. presentation/network extraction follows.

World partition:

- cell manifests carry tactical/spawn data and cost estimates;
- `CellSimReady` gates spawn activation and tactical registration;
- encounters pin required active/escape/retreat cells;
- unload cancels claims and serializes aggregates before ECS retirement;
- persistent IDs and global coordinates survive origin changes.

## Navigation, AI, Streaming, and Event Interfaces

Core interfaces:

- `CreateEncounter(definition, context) -> EncounterHandle`
- `SetPressurePolicy(encounter, policy)`
- `RequestSpawn(encounter, groupDescriptor) -> SpawnTicket`
- `CancelSpawn(ticket, reason)`
- `CreateOrJoinSquad(agent, policy) -> SquadHandle`
- `SubmitSquadObjective(squad, objective)`
- `RequestRoleAssignment(squad, roleSet, constraints)`
- `RequestTacticalPosition(query) -> QueryHandle`
- `ReserveTacticalResource(result, agent, deadline) -> Reservation`
- `Renew/ReleaseReservation(reservation)`
- `SampleInfluence(field, position, revision)`
- `SetSubsystemLOD(agent/group, tiers, reason)`
- `PromotePopulation(record, targetTier) -> activation ticket`
- `DemotePopulation(agent/group, targetTier)`

Events:

- `DirectorPhaseChanged`;
- `PressureTargetChanged`;
- `SpawnRequested`, `SpawnReady`, `SpawnRejected`, `SpawnActivated`;
- `EncounterStarted`, `EncounterCompleted`, `EncounterFailed`;
- `SquadCreated`, `SquadMerged`, `SquadSplit`, `SquadDisbanded`;
- `SquadObjectiveChanged`;
- `RoleAssigned`, `RoleRejected`, `RoleExpired`;
- `ManeuverStarted`, `ManeuverAborted`, `ManeuverCompleted`;
- `TacticalQueryReady`, `TacticalQueryFailed`, `TacticalQueryStale`;
- `ReservationGranted`, `Denied`, `Expired`, `Invalidated`;
- `CoverInvalidated`;
- `PopulationBudgetExceeded`;
- `AILODChanged`.

Events include stable IDs, generations, timestamps, revisions, and causal reasons. They are coalesced at barriers and traced through encounter -> squad -> role -> query -> reservation -> action.

## Integration Plan

1. Define encounter, squad, role, maneuver, tactical-query, reservation, spawn-ticket, population-cost, and LOD schemas.
2. Implement the reservation service and generation-safe lifecycle shared by cover, smart objects, traversal, and spawn anchors.
3. Build cell-sharded tactical spatial indices using authored cover/rails/smart slots plus nav-generated fallback points.
4. Implement bounded generate-filter-score-top-K queries with async expensive tests and fallbacks.
5. Add squad records, membership hysteresis, objectives, compact shared knowledge, and role assignment.
6. Add stable frontline/lane/formation frames and form/advance/retreat/flank maneuvers.
7. Implement spawn validation, staging, fairness, route checks, group admission, and cleanup.
8. Implement a simple explicit Director state machine with pacing metrics, dwell, hysteresis, and authored overrides.
9. Add influence/danger/exposure fields only for demonstrated tactical queries.
10. Integrate multi-dimensional AI LOD, coarse population records, staged promotion, world streaming, and replication.
11. Add player-facing communication/telegraphing and companion-specific criteria.
12. Establish combined automated encounter, soak, performance, and regression gates.

## Verification and Profiling Strategy

### Correctness

- Property-test reservation state transitions, expiry, duplicate release, destruction, and generation reuse.
- Randomize tactical query completion and simultaneous top-choice contention.
- Validate every returned point for nav clearance, role zone, visibility/fire semantics, and revision.
- Test squad merge/split hysteresis and member death/disconnect/unload.
- Test role assignment with missing capability, stuck action, refusal, and timeout.
- Test each maneuver abort/fallback under blocked paths and lost targets.
- Fuzz Director metrics around thresholds and assert minimum dwell/no oscillation.
- Verify spawn never activates in player-visible/invalid/unready space unless explicitly authored.
- Replay seeded encounters across worker counts and validate authoritative state where determinism is required.

### Automated encounter tests

- Cover-sparse, cover-dense, destructible, vertical, indoor, outdoor, and narrow-corridor maps.
- FP/TP player camera and companion interference.
- One, split, and regrouping multiplayer players.
- Advancing, retreating, flanking, breaching, and disengaging squads.
- All spawn points visible, unreachable, occupied, streamed out, or memory denied.
- Global alarm and mass LOD promotion.
- Long soaks with repeated encounter start/abort/restart and save/load.
- Minimum-spec cold-cache traversal into a maximum-cost encounter.

### Debug overlays

Show:

- encounter bounds, phase, intensity/pressure, population budget, and blockers;
- valid/rejected spawn points with reasons and player visibility;
- squad membership, objective, confidence, frontline, lanes, flank/retreat zones;
- role assignment costs and commitment;
- tactical candidates, filters, normalized scores, expensive tests, and top-K;
- cover/smart/traversal reservations and expiry;
- influence field channels/revisions;
- agent/group subsystem LOD and promotion state;
- causal chain from Director decision to agent action.

### Telemetry

Record:

- Director phase duration/transitions and metric distributions;
- requested/active population cost;
- spawn validation count, failure reason, wait/activation latency;
- squad size, merge/split, role churn, maneuver success/abort;
- tactical candidates, filters, rays, paths, query latency, stale rate;
- reservation contention, expiry, invalidation, orphan count;
- cover usage/diversity and movement churn;
- LOD populations, promotion/demotion time and frame cost;
- CPU time, allocations/GC, memory, I/O, replication bytes;
- p50/p95/p99/max frame and reaction/activation latency.

### Acceptance gates

- zero steady-state managed garbage/general-heap allocation;
- every query, reservation, spawn, squad, field, population, and LOD queue/pool has a hard bound;
- no worker directly mutates shared reservations or live ECS;
- no stale query/ticket publishes after generation/revision change;
- no visible/unreachable/unready spawn under ordinary systemic rules;
- squad role/frontline churn stays below declared soak thresholds;
- Director respects dwell/relaxation and cannot exceed population/memory budgets;
- demotion/unload leaves no reservations, callbacks, replicated ghosts, or pooled dirty state;
- platform p99 frame, query, and spawn-to-active latency pass combined worst-case tests.

## Risks and Open Decisions

- Squad formation by authored membership, distance/connectivity, objective, or hybrid.
- Coordinator/leader transfer and communication-delay policy.
- Role assignment algorithm and maximum supported squad size.
- Frontline/formation stabilization constants and specialist exclusions.
- Authored cover points, rails, nav-derived cover, or hybrid.
- Tactical score normalization, fallbacks, and top-K size.
- Reservation priority/fairness for player, companion, elites, and normal AI.
- Influence field representation, channels, diffusion, and update rate.
- Spawn invisibility, audio distance, flow/path distance, and fallback rules.
- Entity pooling versus lightweight population records.
- Director metrics and whether it controls pacing only or difficulty too.
- Co-op intensity aggregation: maximum, average, weakest player, or hybrid.
- Authored beats excluded from adaptation.
- Aggregate coarse simulation fidelity and promotion placement.
- Server-authoritative Director/squads versus client-side presentation.

## Engineering Recommendations

1. Separate Director, encounter, squad, tactical query, reservation, and individual action ownership.
2. Keep the Director's first implementation a small, explicit pacing state machine with hysteresis, dwell, cooldown, and authored overrides; do not make it a hidden universal difficulty scaler.
3. Use structured unpredictability: designer-validated alternatives plus seeded bounded variation, not arbitrary random spawning.
4. Validate spawns against world/nav readiness, player visibility, route-to-engagement, density, population, memory, and network budgets before staging.
5. Use stable squad tactical frames and role commitment to avoid position/role churn.
6. Coordinate advance/retreat/flank as staggered maneuvers where some agents move and others cover; include timeouts and local refusal.
7. Build one reusable tactical-position service with bounded candidates, cheap-first filtering, normalized scores, async expensive tests, top-K alternatives, and explicit failures.
8. Put cover, smart-object, traversal, and spawn claims behind a generation-safe reservation service with expiry and cleanup.
9. Keep influence/danger/exposure fields separate and revisioned; use them as broad query/path biases, not exact truth.
10. Use multi-dimensional AI LOD with staged promotion and aggregate records. Distance/visibility are inputs, not the sole authority.
11. Make all runtime choices causally debuggable from Director phase through spawn/squad/role/query/reservation/action.
12. Gate rollout on cover contention, split-player spawn fairness, mass promotion, destruction, save/load, and minimum-spec combined soak.

## Source Links

1. Epic Games, **Environment Query System in Unreal Engine 5.8**: https://dev.epicgames.com/documentation/en-us/unreal-engine/environment-query-system-in-unreal-engine
2. Epic Games, **Smart Objects Overview in Unreal Engine 5.8**: https://dev.epicgames.com/documentation/en-us/unreal-engine/smart-objects-in-unreal-engine---overview
3. Epic Games, **Mass Gameplay Overview and LOD**: https://dev.epicgames.com/documentation/unreal-engine/overview-of-mass-gameplay-in-unreal-engine?lang=en-US
4. Dill, **Tactical Position Selection: An Architecture and Query Language**, Game AI Pro: https://www.gameaipro.com/GameAIPro/GameAIPro_Chapter26_Tactical_Position_Selection.pdf
5. Karlsson, **Squad Coordination in Days Gone**, Game AI Pro Online Edition 2021: https://www.gameaipro.com/GameAIProOnlineEdition2021/GameAIProOnlineEdition2021_Chapter12_Squad_Coordination_in_Days_Gone.pdf
6. Booth, **The AI Systems of Left 4 Dead**, Valve/AIIDE 2009: https://cdn.fastly.steamstatic.com/apps/valve/2009/ai_systems_of_l4d_mike_booth.pdf
7. Valve, **Publications index**: https://www.valvesoftware.com/publications

