# Operation Mythology Research Report

**Timestamp:** 2026-07-27 02:50:51 America/Los_Angeles  
**Subject:** Modular Level Construction, Gameplay Metrics, Spatial and Encounter Flow, Traversal Pacing, Landmarks, Player Guidance, and Automated Level Validation

## Feature Overview

This batch defines the missing contract between authored level layout and runtime systems. A level should not be only a collection of renderable objects. It should compile into:

- repeatable environment modules with explicit pivots, bounds, sockets, variants, ownership, and streaming behavior;
- versioned gameplay metric profiles for first-person and third-person movement, combat, camera, interaction, and AI;
- a sparse spatial graph of sectors, portals, routes, loops, gates, traversal links, encounter spaces, and landmarks;
- authored pacing and encounter annotations that express intent without hard-wiring the AI Director;
- guidance anchors and route hypotheses that can be measured in playtests;
- derived navigation, visibility, streaming, memory, and performance manifests;
- validation results that can fail a content submission or cook when hard invariants are violated.

The architectural goal is to let a designer change composition without silently breaking capsule clearance, camera comfort, AI reachability, cover behavior, streaming residency, occlusion, or frame-time budgets.

## Existing Coverage and Identified Gap

The mandatory recursive scan covered every file under:

- `C:\Users\steve\Desktop\GAME SKILLS`
- `C:\Users\steve\Desktop\EXTRA SKILS\LEVEL DESIGN AI PERFORMANCE`

Existing research already covers ECS/job scheduling, asset build DAG/CAS, open-world partition and origin management, navigation queries, path caching and replanning, AI decision architecture, perception, squads, tactical positioning, encounter direction, AI LOD, GPU residency, rendering, physics/controller integration, networking, and profiling/regression gates.

The identified gap is the authoring-to-runtime level contract. No scanned report establishes:

- a modular-kit interface that distinguishes visual repetition from gameplay and streaming semantics;
- versioned movement/camera/interaction metrics shared by blockout, navigation, animation, and tests;
- a spatial topology and pacing representation that remains stable when art geometry changes;
- measurable player-guidance and landmark intent;
- automated checks for module seams, traversal envelopes, route redundancy, encounter readability, streaming boundaries, and per-space cost.

This report does not repeat the prior world-partition, pathfinding, AI Director, or profiling baselines. It defines the level-authored inputs and validation outputs those systems consume.

## Sourced Facts

The following are sourced facts, not project recommendations:

1. Unreal Engine 5.8 Level Instances support repeatable sublevels edited in context; changes propagate to their copies. Packed Level Blueprints replace supported static-mesh arrangements with an optimized packed actor. Epic distinguishes ordinary Level Instances for points of interest/gameplay setups from Packed Level Blueprints for static buildings and dense visual arrangements. [Epic: Level Instancing](https://dev.epicgames.com/documentation/en-us/unreal-engine/level-instancing-in-unreal-engine)

2. Under World Partition, embedded One File Per Actor Level Instances are folded into the runtime partition grid. Non-OFPA instances use Level Streaming mode, which adds runtime Levels; Epic warns against high densities because of the performance cost. [Epic: Level Instancing](https://dev.epicgames.com/documentation/en-us/unreal-engine/level-instancing-in-unreal-engine)

3. World Partition subdivides a persistent world into streamable grid cells and loads cells using streaming sources such as the player. Spatial loading and Data Layer state jointly affect whether actors load. [Epic: World Partition](https://dev.epicgames.com/documentation/unreal-engine/world-partition-in-unreal-engine?lang=en-US)

4. Runtime Data Layers can load or unload content for progression and transitions. Level Instance content inherits its instance's Data Layer by default and can also belong to additional layers. Epic specifically warns that loading too many assets at once, or assigning widely used assets to too many Runtime Data Layers, can degrade streaming performance. [Epic: Data Layers](https://dev.epicgames.com/documentation/en-us/unreal-engine/world-partition---data-layers-in-unreal-engine)

5. Unreal's navigation mesh is derived from collision geometry, split into tiles to permit localized rebuilds, and searched using polygon costs. [Epic: Basic Navigation](https://dev.epicgames.com/documentation/unreal-engine/basic-navigation-in-unreal-engine?lang=en-US)

6. World Partition navigation can be stored as Navmesh Chunk Actors that load and unload with partitioned resources. Epic labels the World Partition Navmesh feature experimental in the current documentation, so a production decision must be validated against the exact engine version and target scale. [Epic: World Partitioned Navigation Mesh](https://dev.epicgames.com/documentation/en-us/unreal-engine/world-partitioned-navigation-mesh)

7. Unreal's Navigation Testing Actor exposes path-query diagnostics including open and closed node sets and navigable-end requirements. Navigation modifiers can assign area costs to geometry, and the path solver chooses the lowest-cost available route. [Epic: Navigation Testing Actor](https://dev.epicgames.com/documentation/unreal-engine/API/Runtime/NavigationSystem/ANavigationTestingActor?lang=en-US), [Epic: Navigation Components](https://dev.epicgames.com/documentation/en-us/unreal-engine/navigation-components-in-unreal-engine)

8. Epic's Data Validation framework supports custom asset rules, dependency validation, performance-budget checks, and command-line execution for continuous integration. C++ validation runs by default in the commandlet; Blueprint and Python support require explicit extension/registration choices. [Epic: Data Validation](https://dev.epicgames.com/documentation/en-us/unreal-engine/data-validation-in-unreal-engine?lang=en-US)

9. Unreal's Automation framework supports unit, feature, content-stress, and screenshot-comparison tests. Gauntlet can drive automation against Editor or packaged targets and named platforms/devices. [Epic: Automation Framework](https://dev.epicgames.com/documentation/unreal-engine/automation-test-framework-in-unreal-engine?application_version=5.7), [Epic: Gauntlet](https://dev.epicgames.com/documentation/unreal-engine/running-gauntlet-tests-in-unreal-engine)

10. Joel Burgess's GDC modular-level-design presentation identifies kit construction as an up-front cost involving lead time, onboarding, iteration, and maintenance. The accompanying Level Design Workshop treats layout, pacing, encounter design, population, narrative, and environmental storytelling as related parts of a common design language. [GDC: Modular Level Design](https://media.gdcvault.com/gdc2016/Presentations/Burgess_Joel_Modular%20Level%20Design.pdf), [GDC: Level Design Workshop Introduction](https://media.gdcvault.com/gdcchina14/presentations/833762_JoelBurgess_MattScott_LeePerry_0_Introduction_EN.pdf)

11. The workshop's pacing material separates exploration/traversal from active puzzle solving and combat, demonstrating a practical vocabulary for tagging and reviewing pacing beats rather than treating an entire level as one undifferentiated activity. [GDC: Level Design Workshop—Pacing](https://media.gdcvault.com/gdcchina14/presentations/833762_JoelBurgess_MattScott_LeePerry_3_Pacing_EN.pdf)

12. GDC preproduction material identifies paper design, cell diagrams, encounter concepts, asset lists, iteration, walkthrough, and approval as linked deliverables. This supports maintaining an explicit topology/intent representation before final geometry. [GDC: Level Design in a Day—Preproduction](https://media.gdcvault.com/gdc10/slides/2_EdByrne_LevelDesigninaDay_Preproduction.pdf)

13. The GDC procedural-level-design presentation for *Eldritch* describes memorable landmarks as an aid to wayfinding in otherwise maze-like spaces. This is production evidence, not proof that landmarks alone guarantee orientation. [GDC: Procedural Level Design in Eldritch](https://media.gdcvault.com/gdc2015/presentations/Pittman_David_Procedural%20Level%20Design.pdf)

## Industry-Standard API, Algorithm, or Pattern

### 1. Versioned gameplay metric profiles

Create immutable, versioned profiles rather than scattered magic numbers:

`MetricProfile = {agent, stance, capsule, step, slope, jump, fall, mantle, vault, squeeze, doorway, cover, interactionReach, cameraEnvelope, turnEnvelope, acceleration, stoppingDistance}`

Each authored opening or traversal feature declares the profile(s) it supports. Derived validation expands profiles by safety tolerances; nominal art dimensions never equal the exact collision limit.

Maintain at least:

- player first-person profile;
- player third-person profile, including camera boom/shoulder-swap clearance;
- common humanoid AI profile;
- large/specialist AI profiles;
- accessibility or assisted-traversal variants if supported.

Profiles are data assets with semantic version and migration state. A profile change invalidates affected navigation, traversal, animation-warp, cover, camera, and level-validation products through the existing build DAG.

### 2. Module contract and connector grammar

Each module owns a compact descriptor:

`ModuleDescriptor = {stableId, version, localBounds, pivot, snapGrid, sockets[], variants[], semanticTags, collisionProxy, navContribution, occluderProxy, residencyClass, budgetManifest}`

Each socket owns:

`Socket = {localTransform, socketType, compatibilityMask, clearanceVolume, traversalClass, portalPlane, sealRule, navSeamRule}`

Compatibility is a table or bitset, not a string comparison in the hot path. A module compiler validates snapped transforms, overlapping bounds, unsealed connectors, collision cracks, navigation seams, and invalid scale. Arbitrary non-uniform scaling of gameplay modules should be rejected unless the module explicitly supplies regenerated collision/navigation metadata.

Use nested granularity:

- **piece:** wall, floor, stair, doorway, cover segment;
- **assembly:** room, corridor, facade, traversal set-piece;
- **cell/sector:** streaming and visibility ownership;
- **encounter space:** gameplay boundary that may span assemblies or cells.

The visual hierarchy must not define gameplay ownership implicitly.

### 3. Spatial topology graph

Compile authored volumes and connectors into a sparse graph:

- nodes: rooms, sectors, combat spaces, traversal segments, safe pockets, landmarks;
- edges: portals, doors, jumps, mantles, ladders, drops, squeezes, elevators, scripted transitions;
- attributes: direction, supported agents, state requirements, nominal time, exposure, width, capacity, noise, visibility, streaming dependency.

Store weakly connected and strongly connected components, articulation points, dead ends, loop lengths, alternate-route counts, and critical-path estimates as derived diagnostics. Algorithms are standard:

- DFS/BFS for connectivity: `O(V + E)`;
- Tarjan articulation/SCC analysis: `O(V + E)`;
- Dijkstra for travel-time baselines: `O((V + E) log V)` with a binary heap;
- bounded all-pairs checks from authored anchors rather than `O(V^3)` global Floyd–Warshall.

The topology graph is not a replacement for the navmesh. It is a low-frequency semantic layer for streaming prefetch, encounter reasoning, pacing analysis, and explainable validation.

### 4. Pacing and encounter-flow schema

Represent intended play as a directed beat graph, not a fixed timestamp track:

`Beat = {type, prerequisites, entryAnchors, exitAnchors, targetDurationBand, intensityBand, populationBand, recoveryRequirement, mandatory, skippable}`

Suggested beat types include approach, preview, traversal, exploration, stealth, combat, puzzle, reward, recovery, reveal, transition, and return. Branches support FP/TP-compatible route choice without assuming a single camera or combat range.

The level owns intent and hard constraints. The encounter system owns runtime pressure and population within those bounds. A designer can lock a mandatory reveal or recovery beat; the Director may select among validated spawn groups and pressure envelopes but cannot invalidate topology or accessibility.

### 5. Guidance hierarchy and route hypotheses

Author guidance as observable hypotheses:

`GuidanceAnchor = {stableId, purpose, targetRoute, channels, viewVolumes, distanceBand, priority, occlusionExpectation, activationState}`

Channels may include landmark silhouette, framed sightline, architectural funnel, signage, value/contrast grouping, motion, audio, NPC behavior, objective feedback, and hard gate. This report addresses their system role, not their artistic style.

For each decision point, declare:

- intended first-look target;
- primary and optional routes;
- acceptable hesitation time;
- whether temporary disorientation is intentional;
- minimum redundant cues;
- states/Data Layers in which each cue exists.

Telemetry then tests the hypothesis using camera heading, dwell, reversals, route choice, objective-query frequency, and recovery time. Do not infer comprehension from completion alone.

### 6. Validation pipeline

Use four tiers:

1. **Asset-save:** schema, pivot, bounds, socket, naming, scale, collision, dependency checks.
2. **Changed-cell CI:** module seams, clearance sweeps, local navigation, portal sealing, local budgets.
3. **Map/nightly:** global reachability, beat graph, streaming traversal, encounter population, visibility, nav seam and state-matrix tests.
4. **Packaged-device soak:** scripted and exploratory bots, cold/warm I/O, memory residency, frame-time distributions, save/load, split-player divergence.

Every result includes stable asset/entity IDs, world coordinates, metric profile, Data Layer state, platform profile, reproduction seed, and causal category.

## Performance Considerations

### Algorithmic complexity

- Module/socket validation should use hash lookup by socket type and spatial hashing/BVH overlap candidates, avoiding `O(n²)` comparisons across all pieces.
- Graph connectivity and articulation analysis are linear in topology size; travel-time checks use bounded single-source Dijkstra from entries, exits, objectives, spawn groups, and landmarks.
- Clearance validation uses broad-phase cell/BVH candidates, then exact capsule/box sweeps only for likely conflicts.
- Visibility checks must not test every guidance anchor against every sample. Use sector/portal reachability, distance bands, view cones, and batched rays.

### Allocations and garbage collection

- Compile descriptors into flat arrays, interned tags, packed socket records, and stable ID tables.
- Reuse scratch arenas for graph search, collision sweeps, visibility samples, and bot routes.
- Keep per-frame telemetry in fixed-capacity ring buffers with background serialization.
- Streaming must not construct thousands of per-prop gameplay objects when an assembly or cell activates. Promote only interactive/stateful records.

### Spatial data structures and cache behavior

- Use the world-partition cell index for coarse ownership, sector/portal graphs for semantic reachability, and a BVH or hashed grid for local module/anchor queries.
- Store hot topology arrays in structure-of-arrays form: neighbor ranges, edge targets, flags, cost, and state mask.
- Keep authoring strings and editor diagnostics out of the runtime hot representation.
- Sort activation manifests by subsystem and archetype to improve sequential reads and ECS insertion locality.

### Concurrency

- Descriptor parsing, socket checks, graph analysis, path batches, visibility samples, and budget aggregation can run as jobs over immutable snapshots.
- Runtime cell activation uses staged jobs: I/O/decompression, descriptor creation, physics registration, nav readiness, AI/encounter eligibility, presentation.
- Do not publish an encounter or traversal edge until all hard dependencies report the same generation and ready state.
- Cancellation is required when streaming priorities or Data Layer states change.

### Navigation rebuild cost

- Module geometry should ship with stable collision/nav contributions where possible; snapping identical modules should reuse derived tiles/chunks rather than trigger broad runtime rasterization.
- Dirty regions are the union of changed collision bounds plus agent-specific padding. Batch edits before rebuilding.
- Validate every socket seam for each supported agent and state. A visually sealed doorway may still produce disconnected polygons; a tiny collision leak may connect forbidden spaces.
- Runtime rebuild queues need hard per-frame work and memory caps, priority by player/AI proximity, revision IDs, and fallbacks for stale or unavailable routes.

### AI scheduling

- Encounter and guidance metadata are low-frequency inputs. AI should not rescan module actors every tick.
- Publish compact sector membership, tactical affordance ranges, traversal edges, and encounter state through events/snapshots.
- Stagger expensive spawn validation, EQS/tactical queries, and route checks; cache by topology/nav/visibility revision.
- Level activation must impose a promotion budget so a newly loaded combat space cannot wake all perception, planning, and navigation jobs in one frame.

### Streaming I/O and memory residency

- Each cell/assembly budget manifest should report compressed bytes, resident CPU/GPU bytes, nav bytes, collision bytes, entity count, activation work, and external dependencies.
- Prefetch follows predicted topology edges and traversal time, not Euclidean distance alone.
- Critical landmarks/guidance can use lightweight proxy residency, but full-resolution presentation and gameplay collision have separate readiness.
- Data Layer transitions require peak-overlap budgeting for old and new states; average steady-state memory is insufficient.

### Visibility and draw cost

- Module assembly boundaries should create plausible occlusion units; one giant always-visible assembly defeats culling, while tiny pieces inflate instance lists, metadata, and draw submission.
- Portal/sector visibility is a conservative gameplay and prefetch hint, not a substitute for renderer occlusion.
- Validate sightline intent with renderer-independent geometry queries so dynamic resolution, exposure, and temporal effects cannot change AI or game rules.
- Track visible instance count, material/PSO diversity, shadow casters, overdraw proxies, HLOD transitions, and occlusion-query behavior per representative viewpoint.

### Frame-time budgets and worst cases

Budget milliseconds and work counts by phase, with p50/p95/p99 and maximum hitch:

- streaming issue/completion and activation;
- nav dirtying/rebuild/publication;
- AI promotion, perception, decisions, and path requests;
- visibility/HLOD processing;
- physics registration;
- telemetry/GC.

Worst-case tests must combine: fast traversal across a cell boundary, Data Layer transition, destroyed navigation, a full encounter promotion, split players moving apart, cold storage, minimum-spec CPU/GPU, save/load, and camera turns exposing a dense vista. Avoid independent subsystem tests that conceal synchronized spikes.

## Pros and Cons

### Pros

- A single metric source prevents blockout, animation, navigation, camera, and AI from drifting.
- Explicit sockets and graph topology make modular reuse testable and streaming-aware.
- Semantic graphs provide cheap, explainable inputs for prefetch, encounters, pacing, and guidance analytics.
- Validators catch systemic defects before full playthroughs.
- Stable IDs and revisions make telemetry actionable against authored content.
- Separate intent from runtime policy preserves designer control while allowing bounded AI variation.

### Cons

- Kit descriptors, metric migrations, and validators add early production cost.
- Overly rigid grids or connector grammars can make spaces repetitive.
- Semantic metadata can become stale if tools do not update it automatically.
- Automated guidance metrics detect behavior, not player meaning or enjoyment.
- State-matrix testing across Data Layers, destruction, quests, and agent profiles can grow combinatorially.
- Packed static assemblies can be efficient but are inappropriate when child-level gameplay behavior or independent streaming is required.

## ECS and World-Partition Integration

Authoring objects compile to runtime records:

- `WorldCellRecord`: cell ID, global bounds, neighbors, residency manifest, state, generation;
- `ModuleInstanceRecord`: stable instance ID, descriptor ID, transform, variant, cell owner;
- `SectorRecord`: bounds, portal range, encounter range, landmark range;
- `PortalRecord`: endpoints, state mask, traversal class, capacity, stream dependency;
- `TraversalLinkRecord`: agent mask, entry/exit, animation tag, reservation capacity, nav revision;
- `EncounterSpaceRecord`: beat graph, spawn groups, population envelope, state;
- `GuidanceAnchorRecord`: route target, channels, view/distance bands, state mask;
- `LandmarkRecord`: global position, proxy/full residency, visibility sectors;
- `LevelBudgetRecord`: memory, I/O, activation, navigation, visibility, and entity counts.

Runtime entities reference stable records; records do not require an entity per wall or decorative piece. Stateful objects use persistent IDs and serialize deltas outside transient cell memory. On unload:

1. stop new encounter/spawn/traversal reservations;
2. drain or cancel generation-bound jobs;
3. persist stateful deltas;
4. remove AI/nav/physics registrations;
5. release runtime entities and presentation resources;
6. retain only the coarse world record and persistence state.

Cross-cell references use stable handles resolved through registries. Raw pointers into unloadable cell storage are forbidden.

## Navigation, AI, Streaming, and Event Interfaces

Suggested engine-neutral interfaces:

- `ILevelMetricRegistry::GetProfile(profileId, version)`
- `IModuleRegistry::GetDescriptor(moduleId, version)`
- `ISpatialTopology::GetSector(position)`
- `ISpatialTopology::EnumerateEdges(sectorId, agentMask, stateMask)`
- `ITraversalService::QueryLink(linkId, agentProfile, worldRevision)`
- `IEncounterSpaceService::GetDefinition(encounterId)`
- `IGuidanceTelemetry::RecordDecisionPointSample(...)`
- `ILevelBudgetService::GetManifest(cellId, platformProfile)`
- `ILevelValidator::Validate(scope, ruleSet, stateMatrix)`
- `IStreamingService::RequestTopologyPrefetch(edgeId, deadline, priority)`

Events:

- `CellRequested`, `CellResident`, `CellGameplayReady`, `CellUnloading`;
- `ModuleDescriptorChanged`, `MetricProfileChanged`;
- `PortalStateChanged`, `TopologyRevisionPublished`;
- `NavRegionDirty`, `NavRegionReady`, `TraversalLinkChanged`;
- `EncounterSpaceReady`, `EncounterStarted`, `EncounterEnded`;
- `GuidanceStateChanged`, `LandmarkProxyReady`;
- `LevelBudgetExceeded`, `LevelValidationFailed`.

All async requests carry world/cell generation, cancellation token, and deadline. Results with stale generations are discarded.

## Integration Plan

### Phase 0 — Inventory and baseline

- Extract current controller, camera, AI, cover, doorway, stair, jump, mantle, and interaction dimensions.
- Record existing modular grids, pivots, repeated assemblies, traversal links, streaming cells, and Data Layers.
- Benchmark representative traversal corridors, combat spaces, vistas, transitions, and worst resident sets.

### Phase 1 — Metric and module schemas

- Ratify versioned FP, TP, humanoid AI, and specialist profiles.
- Define socket types, compatibility masks, clearance volumes, portal planes, seal rules, and allowed transforms.
- Add asset-save validation and visual overlays for nominal versus padded envelopes.

### Phase 2 — Semantic compilation

- Compile sectors, portals, traversal edges, encounters, landmarks, and guidance anchors into flat runtime records.
- Produce connectivity, articulation, loop, travel-time, state-matrix, and budget diagnostics.
- Establish stable IDs and build-DAG invalidation from source asset through cooked cell products.

### Phase 3 — Runtime integration

- Connect topology to predictive streaming, nav readiness, encounter eligibility, persistence, and AI LOD.
- Stage cell activation and publish readiness only after hard dependencies succeed.
- Add proxy landmark residency and state-aware guidance activation.

### Phase 4 — Automated validation and telemetry

- Add changed-cell CI, nightly full-map/state matrix, and packaged-device Gauntlet runs.
- Deploy seeded traversal/encounter bots and decision-point telemetry.
- Create dashboards for defects, player route behavior, budget regressions, and worst hitches.

### Phase 5 — Production gates

- Block submissions on broken required routes, incompatible sockets, invalid metric versions, missing dependencies, and hard memory/activation ceilings.
- Warn initially on guidance hypotheses, soft pacing targets, excessive articulation, and visual-cost outliers until baselines stabilize.
- Convert mature warnings into platform/profile-specific gates.

## Verification and Profiling Strategy

### Static validation

- sockets align within position/rotation tolerance;
- no unsupported scale or mirrored traversal animation;
- connector clearance passes swept profiles with safety margin;
- collision, nav, render, and portal boundaries agree;
- all mandatory entry/objective/exit pairs are reachable in required world states;
- one-way drops and gated transitions match save/load and backtracking rules;
- critical routes do not depend on unloaded or optional Data Layers;
- encounter spaces have legal spawn, reinforcement, retreat, and cleanup paths;
- guidance anchors exist in every required state and do not reference missing landmarks;
- cell/assembly manifests stay within hard platform ceilings.

### Automated gameplay tests

- traverse every authored edge with each supported agent profile;
- execute camera sweeps for FP and both TP shoulders at stairs, doors, corners, cover, and squeezes;
- run objective routes plus bounded exploratory routes with fixed seeds;
- toggle doors, destruction, quest layers, and transitions during traversal;
- unload/reload cells while reservations, paths, perception memories, and encounter state exist;
- separate co-op players across different streaming fronts;
- save/load at every transition phase and verify stable IDs/state restoration.

### Guidance and pacing telemetry

At declared decision points collect:

- entry heading and first-look target;
- time to commit, reversal count, route chosen, missed cue count;
- time outside intended route envelope;
- objective/help/map requests;
- completion, death, restart, and abandonment;
- actual beat durations and intensity transitions.

Use cohorts and confidence intervals; do not optimize a level from a handful of heatmaps. Pair metrics with moderated observation because a fast choice can indicate clarity, panic, or accidental commitment.

### Performance capture

Correlate one timeline across:

- cell requests, I/O bytes, decompression, activation and residency;
- nav dirties, build queue, tile/chunk publication and path failures;
- AI promotion, perception pairs/rays, decisions, tactical queries and paths;
- entity creation/destruction, allocations, GC and memory high-water marks;
- visible instances, HLOD/occlusion transitions, draw/triangle/shadow costs;
- CPU/GPU frame time and present stalls.

Gate on representative minimum-spec hardware using warm and cold runs. Report percentiles and maximums, not averages only.

## Risks and Open Decisions

- What canonical unit/grid and socket tolerances fit both interior kits and exterior terrain?
- Which metrics are hard invariants versus per-archetype or per-difficulty variants?
- How much extra TP camera envelope is required for shoulder swap and tight traversal?
- Should semantic sectors follow streaming cells, encounter spaces, visibility portals, or an independent authored graph?
- Which module granularity best balances reuse, culling, draw submission, nav stability, source-control ownership, and iteration?
- Which assemblies may be packed static actors, and which require independent gameplay/streaming identity?
- Are World Partition nav chunks mature enough in the selected engine version, or is a custom chunk/overlay strategy required?
- Which runtime world-state combinations are exhaustive, pairwise, sampled, or designer-certified?
- What route redundancy is required for combat, stealth, companions, co-op, and accessibility?
- How are landmark proxies authored and budgeted without becoming always-resident clutter?
- Which guidance signals may be mandatory, and which remain an artistic/design choice?
- What authority may the encounter Director exercise over authored pacing envelopes?
- How should traversal edges behave during nav rebuild or cell readiness loss?
- What are the per-platform hard caps for cell bytes, activation work, visible complexity, AI promotion, and nav rebuild?
- Which validation warnings are submission-blocking, and who can grant a timed waiver?

## Engineering Recommendations

The following are project recommendations derived from the facts and analysis above:

1. Establish a **Level Contract** consisting of versioned metric profiles, module/socket descriptors, a semantic topology graph, pacing/encounter annotations, guidance hypotheses, and per-cell budget manifests.

2. Keep three boundaries explicit:
   - render modules optimize visual reuse;
   - gameplay assemblies own interaction and state;
   - cells/sectors own streaming and semantic topology.
   Never infer one solely from another.

3. Compile module and level metadata into flat, stable-ID runtime records. Do not make decorative pieces full ECS entities or query authored actors each frame.

4. Make profile changes build dependencies. Changing capsule, step, camera, mantle, or specialist dimensions must invalidate affected clearance, navigation, traversal, cover, and validation products.

5. Use a sparse sector/portal/traversal graph above the navmesh. Use it for topology validation, predictive streaming, encounter eligibility, coarse routing, and explainable diagnostics—not fine movement.

6. Author pacing as bounded beat intent. Let the Director vary timing, population, and validated alternatives within explicit limits; preserve mandatory recovery, reveal, transition, and accessibility constraints.

7. Define guidance as testable hypotheses with stable decision-point IDs. Require redundant cues for critical routes, but validate them with telemetry and observed play rather than aesthetic scoring.

8. Make streaming readiness a staged state. A visible cell is not automatically safe for traversal, spawning, encounter activation, or AI promotion.

9. Use hierarchical validation: immediate asset checks, changed-cell CI, nightly map/state tests, and packaged minimum-spec soak. Every error must identify stable content IDs, world state, metric profile, and reproduction seed.

10. Gate worst-case combined transitions, not only isolated subsystem budgets. The release bar must include cold I/O, overlapping Data Layers, nav invalidation, encounter promotion, dense visibility, split players, and persistence in the same scenario.

11. Start with a small pilot kit and two contrasting spaces—one interior, one exterior—before standardizing the grammar. Measure iteration time, defect detection, runtime cost, and authoring friction, then ratify schemas.

12. Treat waivers as versioned, expiring data with owner and rationale. Silent exclusions will otherwise turn validation into an unreliable report rather than a production gate.

## Source Links

- [Epic Games — Level Instancing in Unreal Engine 5.8](https://dev.epicgames.com/documentation/en-us/unreal-engine/level-instancing-in-unreal-engine)
- [Epic Games — World Partition in Unreal Engine 5.8](https://dev.epicgames.com/documentation/unreal-engine/world-partition-in-unreal-engine?lang=en-US)
- [Epic Games — World Partition Data Layers in Unreal Engine 5.8](https://dev.epicgames.com/documentation/en-us/unreal-engine/world-partition---data-layers-in-unreal-engine)
- [Epic Games — World Partitioned Navigation Mesh in Unreal Engine 5.8](https://dev.epicgames.com/documentation/en-us/unreal-engine/world-partitioned-navigation-mesh)
- [Epic Games — Basic Navigation in Unreal Engine 5.8](https://dev.epicgames.com/documentation/unreal-engine/basic-navigation-in-unreal-engine?lang=en-US)
- [Epic Games — Navigation Components in Unreal Engine 5.8](https://dev.epicgames.com/documentation/en-us/unreal-engine/navigation-components-in-unreal-engine)
- [Epic Games — Navigation Testing Actor API in Unreal Engine 5.8](https://dev.epicgames.com/documentation/unreal-engine/API/Runtime/NavigationSystem/ANavigationTestingActor?lang=en-US)
- [Epic Games — Data Validation in Unreal Engine 5.8](https://dev.epicgames.com/documentation/en-us/unreal-engine/data-validation-in-unreal-engine?lang=en-US)
- [Epic Games — Automation Test Framework](https://dev.epicgames.com/documentation/unreal-engine/automation-test-framework-in-unreal-engine?application_version=5.7)
- [Epic Games — Running Gauntlet Tests in Unreal Engine 5.8](https://dev.epicgames.com/documentation/unreal-engine/running-gauntlet-tests-in-unreal-engine)
- [Joel Burgess, GDC 2016 — Modular Level Design](https://media.gdcvault.com/gdc2016/Presentations/Burgess_Joel_Modular%20Level%20Design.pdf)
- [Joel Burgess, Matt Scott, Lee Perry — Level Design Workshop Introduction](https://media.gdcvault.com/gdcchina14/presentations/833762_JoelBurgess_MattScott_LeePerry_0_Introduction_EN.pdf)
- [Joel Burgess, Matt Scott, Lee Perry — Level Design Workshop: Pacing](https://media.gdcvault.com/gdcchina14/presentations/833762_JoelBurgess_MattScott_LeePerry_3_Pacing_EN.pdf)
- [Ed Byrne, GDC 2010 — Level Design in a Day: Preproduction](https://media.gdcvault.com/gdc10/slides/2_EdByrne_LevelDesigninaDay_Preproduction.pdf)
- [David Pittman, GDC 2015 — Procedural Level Design in Eldritch](https://media.gdcvault.com/gdc2015/presentations/Pittman_David_Procedural%20Level%20Design.pdf)
