# Operation Mythology Research Report

## Hybrid AI Decision Architecture: StateTree/HFSM, Behavior Trees, Utility Selection, GOAP/HTN Planning, and Scheduling

**Timestamp:** 2026-07-27 02:01:22 America/Los_Angeles  
**Status:** New baseline for an uncovered domain  
**Assumptions:** Generic modular ECS, data-oriented memory, first-person and third-person gameplay, world partition and AI LOD, no production-code implementation.

## Feature Overview

No single decision algorithm is the best owner of every AI choice. A scalable game-AI stack separates timescales and responsibilities:

- **Hierarchical state machine/StateTree:** coarse lifecycle and mode such as Dormant, Ambient, Alert, Combat, Scripted, Traversing, or Dead.
- **Behavior tree:** reactive sequencing, monitoring, interruption, and action execution inside a mode.
- **Utility selection:** scoring mutually valid goals, tactics, targets, cover, or abilities where graded tradeoffs matter.
- **GOAP or HTN planner:** constructing multi-step action sequences when the required steps depend on changing world state.
- **Action runtime:** one shared contract for movement, animation, weapon use, smart objects, interaction, reservations, and cancellation.
- **Blackboard/working memory:** typed, versioned facts derived from perception and gameplay events.
- **Scheduler:** event-driven wakeups plus bounded periodic work, priority, AI LOD, and hard per-frame budgets.

The recommended baseline is **HFSM/StateTree at the top, event-driven behavior trees for execution, utility selectors at explicit choice points, and planners only for agents/problems that need variable multi-step plans**. This is a compositional architecture, not a mandate to run all algorithms on every agent.

Key runtime state:

`Mode -> ActiveBehavior -> SelectedIntent -> OptionalPlan -> CurrentAction`

Every layer owns only its decision and can be invalidated independently. An observed threat may interrupt a behavior without discarding stable personality data; a failed action may repair a plan without rebuilding the entire mode hierarchy; AI LOD may suspend leaf execution without losing durable intent.

## Existing Coverage and Identified Gap

The required recursive scan of `C:\Users\steve\Desktop\GAME SKILLS` found eight completed baseline reports plus its index. Covered topics include renderer/GPU architecture, virtualized assets, ECS/job scheduling, temporal reconstruction, and hybrid global illumination/reflections.

The dedicated folder `C:\Users\steve\Desktop\EXTRA SKILS\LEVEL DESIGN AI PERFORMANCE` contained:

- one navigation-query report covering hierarchical routing, path caching, replanning, dynamic obstacles, off-mesh links, and local avoidance;
- `RESEARCH_INDEX.md` recording that work.

No scanned document defines:

- boundaries between HFSM, behavior trees, utility AI, GOAP, and HTN;
- blackboard fact ownership and change notification;
- interruption, cancellation, and action cleanup;
- plan-domain representation, cache keys, or invalidation;
- AI decision scheduling and LOD;
- prevention of utility oscillation or behavior-tree polling storms;
- coordination with streamed cells, navigation availability, ECS structural barriers, and event delivery;
- deterministic replay, debugging traces, or worst-case planner controls.

This batch fills that decision-architecture gap. It does not repeat perception algorithms, tactical cover generation, group coordination, or encounter-director design, which remain separate uncovered topics.

## Sourced Facts

The following are sourced facts. Engineering recommendations appear in a separate section.

1. Unreal Engine 5.8 describes its Behavior Trees as event-driven so they avoid repeating work every frame when relevant state has not changed. Blackboard keys hold decision information. Decorators can observe values and abort a running branch when conditions change.

2. Unreal's Behavior Tree node reference defines composite, task, decorator, and service nodes. It states that many behavior-tree nodes are shared between agents to improve CPU performance and memory usage; shared nodes therefore cannot hold agent-specific state unless explicitly instanced or stored externally.

3. Unreal Engine 5.8 StateTree is a general-purpose hierarchical state machine combining behavior-tree selectors with state-machine states and transitions. State selection proceeds from root toward children, while monitored transitions are evaluated from active leaf upward; tasks in active states can share exposed data.

4. Epic's StateTree documentation describes hierarchical failure handling, allowing failure to propagate from a child to a parent state that chooses the recovery transition.

5. Epic's Environment Query System uses generators, contexts, tests, and weighted results to select environmental items such as attack positions, cover, or pickups. It can be invoked by a behavior tree. This is evidence that spatial option scoring is useful as a separate query service rather than embedded into every behavior node.

6. The behavior-tree survey by Iovino et al. describes behavior trees as organizing transition logic in a hierarchy rather than dispersing it among states, with modularity as a key benefit. Colledanchise and Ogren characterize BTs as modular and reactive task-switching structures.

7. Jeff Orkin's AIIDE paper on real-time planning in *F.E.A.R.* states that dynamic planners better handle unexpected situations and provide reusable goals/actions, but cost CPU time. The paper calls out distributed processing and caching of expensive calculations as supporting architectural requirements.

8. Orkin's *F.E.A.R.* presentation reports a hybrid architecture rather than a planner-only agent. The planner selected sequences while lower-level systems executed actions and handled animation/movement.

9. The SHOP2 paper describes an HTN planner that decomposes tasks using domain knowledge and generates plan steps in execution order. It supports partially ordered subtasks and can interleave subtasks. The authors note that domain knowledge can make planning efficient but that authoring good knowledge bases can be difficult.

10. Game AI Pro's utility chapter presents utility as scoring considerations to make decisions from graded inputs. Its architecture material also documents combining utility decisions with behavior trees rather than treating them as mutually exclusive systems.

11. The AIIDE study of GOAP/HTN use in three first-person shooters reports that planning telemetry can be analyzed through performance, plan, and development metrics. This supports retaining planner-specific runtime traces, not merely aggregate frame timing.

## Industry-Standard API, Algorithm, or Pattern

### Layered ownership

Use one explicit owner for each question:

- `ModeMachine`: What broad mode is allowed now?
- `BehaviorRuntime`: What reactive procedure is active?
- `IntentSelector`: Which valid goal/tactic has the highest adjusted utility?
- `Planner`: Which action sequence achieves the selected intent?
- `ActionRuntime`: Can the next primitive action start, continue, succeed, fail, or cancel?
- `Scheduler`: When may each layer evaluate again?

Do not let multiple layers independently command locomotion, animation, targeting, or interaction. All primitive work goes through shared action handles and resource reservations.

### Typed working memory

Use a schema-generated blackboard/working-memory layout, not a dynamic string-to-variant map in hot code.

Each fact includes:

- typed key ID;
- value;
- confidence and/or uncertainty where needed;
- source and source generation;
- observed/effective timestamp;
- expiry policy;
- revision;
- optional persistent/shared/team scope.

Facts are written by designated producers such as perception, damage, navigation, squad, quest, and action systems. Consumers subscribe to key revisions. Writes are coalesced at a decision barrier, producing a deterministic changed-key bitset and event batch.

Separate:

- **raw observations:** “sound at location, timestamp”;
- **beliefs:** “suspected target position, confidence”;
- **derived decisions:** “current intent, selected cover”;
- **action state:** “reload reservation acquired.”

Derived decision output must not masquerade as perception truth.

### HFSM/StateTree contract

Use hierarchical states for mutually exclusive coarse modes and inherited policy. A state defines:

- enter conditions;
- tasks active during the state;
- monitored transitions;
- parent fallback;
- enter/exit actions;
- permitted intent/planner/action classes;
- minimum residency and AI LOD.

Transition evaluation is event-driven when possible. Define priority and tie-breaking explicitly. Entry and exit must be transactional: cancel or transfer owned actions/reservations before the new state publishes.

Avoid dozens of flat states with all-to-all transitions. Common transitions such as death, cinematic control, hard stun, or unload belong high in the hierarchy.

### Behavior-tree execution

Use standard statuses: `Running`, `Succeeded`, `Failed`, plus explicit `Suspended` and `Cancelled` at the runtime boundary.

Recommended nodes:

- sequence and selector composites;
- decorator conditions with observed fact dependencies;
- reusable subtree references;
- bounded service/update nodes;
- task/action nodes that return handles rather than block;
- limited parallel policies with declared completion and cancellation semantics;
- utility-selector composite for scored alternatives;
- plan-executor node for an externally generated action plan.

Compiled tree assets should use flat node arrays, child ranges, decorator bytecode/data, and per-agent execution memory. Node definitions are immutable and shared; active stack, task state, timers, and subscriptions are per agent.

### Utility selection

For candidate `i`, compute a normalized score from considerations:

`score_i = base_i * compensation_i * combine(response_ij(input_j))`

The exact combination is a project choice. Multiplication strongly penalizes one near-zero consideration; additive or weighted geometric schemes behave differently. Normalize every input and make response curves visible in tooling.

Add:

- eligibility predicates before scoring;
- hysteresis/stickiness bonus for current choice;
- switch cost and minimum commitment time;
- cooldowns;
- bounded noise seeded for deterministic replay where desired;
- top-N diagnostic score breakdown.

Utility chooses *what* to pursue, not how every action is sequenced. Re-score on relevant fact changes or a bounded cadence. Do not score every possible target/action every frame.

### GOAP planning

Represent planner world state as compact facts:

- Boolean bitsets for common predicates;
- small enums/integers for bounded resources;
- stable object bindings kept separate from symbolic state where possible.

An action declares preconditions, effects, cost, procedural applicability, and primitive action class. A goal declares desired facts and utility/priority.

Use backward relevance filtering or a precomputed action-to-fact index to reduce branching. Run A* or another bounded best-first search over symbolic states. Search nodes come from fixed pools; repeated equivalent states use hash-based closed sets.

The runtime validates each action before start. When a precondition fails:

1. try local action substitution/repair;
2. replan for the same goal with updated facts;
3. reselect the goal if it is no longer valid;
4. fall back to a safe behavior if budgets or data are unavailable.

### HTN planning

Use HTN when designers need procedural domain knowledge and authored task decomposition. A compound task selects an applicable method; methods decompose into subtasks until primitive actions remain.

HTN is well suited to:

- multi-step combat tactics with required ordering;
- team procedures;
- interaction workflows;
- story/quest-aware routines;
- actions with designer policy constraints.

Method ordering is semantic. Detect recursive cycles and cap decomposition depth, alternatives, and generated primitive steps. Keep method applicability pure and allocation-free.

### Plan caching and reuse

Cache only when the domain demonstrates repeatability. Keys may include:

- goal/task ID;
- relevant world-state projection;
- agent capability/profile;
- equipment/resource class;
- gameplay-layer revision;
- planner-domain version.

Cache a plan template or partial decomposition, then validate/bind objects at use time. Do not key on the entire global world state. Record dependencies and invalidation reasons.

Shared squad plans and repeated ambient routines often cache better than unique combat world states. Measure hit, validation failure, repair, and wasted-search rates.

### Action runtime and cancellation

Every action implements:

- `CanStart(context)`;
- `Start(context) -> ActionHandle`;
- `TickOrEvent(handle) -> status`;
- `Cancel(handle, reason)`;
- `Finalize(handle, result)`;
- declared resource/reservation requirements;
- blackboard facts read/written;
- serialization/dormancy policy.

Cancellation is idempotent. Cleanup releases navigation requests, smart-object slots, cover reservations, animation montages, weapon tokens, and event subscriptions. A cancelled task may receive late subsystem completion, which is rejected through generation checks.

## Performance Considerations

### Algorithmic complexity

Let `N` be behavior-tree nodes, `D` changed dependent decorators, `C` utility candidates, `K` considerations per candidate, `V/E` explored GOAP states/transitions, `B` average HTN branching, and `H` decomposition depth.

- naive full BT tick: `O(N)` per tick; event-driven reevaluation is closer to `O(D + active-path work)` for changed facts;
- HFSM transition check: `O(monitored transitions on active ancestry)`;
- utility scoring: `O(CK)`;
- GOAP A* with heap: `O((V + E) log V)` over explored symbolic states, with potentially exponential explored state growth in domain size;
- HTN decomposition: worst-case exponential, approximately `O(B^H)` without pruning/memoization;
- changed-key dispatch: `O(number of subscribers to changed keys)`;
- action update: `O(active actions)` plus subsystem work.

Worst-case planner complexity must be controlled by node, depth, memory, and time budgets. “Small in typical combat” is not a bound.

### Allocations and garbage collection

- Compile immutable behavior/state/planner assets at cook/load time.
- Store shared node/action/method definitions once.
- Use fixed-size or slab-allocated per-agent execution blocks.
- Pool planner nodes, open/closed storage, plan steps, utility candidate buffers, subscriptions, and trace records.
- Use bitsets/SoA data for common blackboard facts and planner predicates.
- Reset frame/query arenas in bulk.
- Do not allocate closures, boxed variants, strings, task objects, score arrays, or event nodes during steady-state decisions.
- A stable gameplay frame must produce zero managed garbage and no general-heap AI decision allocation.

Planner pool exhaustion returns an explicit budget failure and safe fallback, never heap growth.

### Spatial data structures

Decision logic must request spatial candidates from perception, cover, navigation, smart-object, and tactical-query services backed by grids, BVHs, navmesh, or indexed registries. A utility selector or planner must not scan all world entities.

Separate candidate generation from scoring:

1. spatial/service query produces a bounded candidate set;
2. eligibility filters remove invalid entries;
3. utility/EQS-like tests score survivors;
4. reservations protect the selected resource.

### Cache behavior

Compile BT/StateTree nodes into contiguous arrays with compact type IDs and offsets. Keep hot per-agent state—active node stack, changed facts, timers, intent, plan index—in compact arrays. Put debug names, authoring metadata, and verbose descriptions in cold storage.

Group scheduled agents by decision asset and LOD to improve instruction and definition-cache reuse. Avoid polymorphic pointer chasing per node where a compact dispatch table or compiled opcode is sufficient and profiled.

### Concurrency

Perception and gameplay producers write events into per-worker buffers. At a barrier, deterministic merge updates working memory and schedules decisions.

Pure work can run on jobs:

- utility scoring over candidate ranges;
- planner search/decomposition;
- environment-query tests that use immutable snapshots;
- behavior condition evaluation;
- trace compression.

World mutation, action start/finalize, reservations, and ECS structural changes commit through declared phases. Planner jobs read immutable fact snapshots. If the snapshot revision is stale at completion, validate dependencies before publication.

No AI job blocks on navigation, streaming, physics, animation, or I/O. It yields a handle and resumes on an event.

### Navigation rebuild cost

Decision systems consume navigation readiness/revision events but do not rebuild nav. A plan action referencing a corridor, cover point, or off-mesh link records that dependency. Nav invalidation aborts or repairs only the affected action/plan.

Planner costs must use estimates that tolerate nav data absence. Exact path cost is an asynchronous query and should not be invoked for every candidate during symbolic expansion. Use hierarchical distance estimates, then validate the selected plan/action with the navigation service.

### AI scheduling

Use an event-driven scheduler with four work classes:

1. immediate safety interrupts: death, hard stun, invalid traversal, direct damage;
2. near-term reactive decisions: target lost, action completed, threat changed;
3. deliberation: utility reselection, planning, environmental scoring;
4. background maintenance: low-confidence belief decay, ambient reevaluation, trace aggregation.

Each agent has:

- decision priority;
- next eligible evaluation time;
- accumulated age/starvation credit;
- AI LOD;
- remaining active-path validity;
- estimated work based on recent history.

Budgets apply to microseconds and work units (nodes, candidates, planner expansions), not just agent count. Continue planner searches across frames. Randomize or deterministically stagger periodic intervals so agents do not synchronize.

Suggested LOD policy:

- **Full:** immediate events, normal scoring/planning, full action execution.
- **Reduced:** event-driven safety, slower deliberation, cached intent, simplified queries.
- **Coarse:** state/intent simulation with rare plan refresh; no detailed spatial scoring.
- **Dormant:** persisted mode, goal, timers, and critical facts only.

Never LOD away authoritative damage, death, ownership, reservation release, or server simulation requirements.

### Streaming I/O and memory residency

Behavior assets, action schemas, common planner domains, and blackboard schemas should be resident with the archetype/population that uses them. Rare encounter-specific subtrees, planners, voice sets, and smart-object actions can stream with encounter cells.

An agent cannot activate into Full AI until required decision assets and action dependencies are resident. While unavailable, it remains Suspended/Coarse with explicit fallback. Streamed entity unload must cancel or serialize actions, release reservations, and persist durable intent before ECS destruction.

Memory budgets cover:

- shared compiled assets;
- per-agent execution memory;
- working memory/beliefs;
- planner scratch and retained plans;
- subscriptions/timers;
- debug traces;
- squad/shared knowledge.

### Visibility cost and player-facing behavior

AI LOD may use visibility, distance, audibility, combat relevance, and multiplayer authority as inputs, but visibility alone is insufficient. An offscreen enemy firing, a squadmate communicating, or an agent controlling a world event may require full or reduced authoritative updates.

Debug visualization must show what the AI knew and why it chose, not hidden ground truth. Captured top utility scores, failed preconditions, active state ancestry, behavior path, planner frontier statistics, and interruption cause are essential for diagnosing “unfair” or incoherent behavior.

### Frame-time budgets and worst-case behavior

For a 60 Hz target, all game work shares 16.67 ms. AI decision work gets a profiled slice and must be measured with navigation, perception, animation, physics, streaming, networking, and rendering active.

Worst cases:

- hundreds of agents receive the same global alert;
- one shared blackboard fact invalidates many branches;
- a goal has many equally plausible actions and weak heuristics;
- recursive HTN methods expand deeply;
- utility candidates multiply targets by cover/ability choices;
- oscillating scores cause intent thrash;
- an action cancellation waits on late animation/navigation callbacks;
- a streamed encounter activates all agents simultaneously;
- squad facts echo between members;
- all plans invalidate when a door/bridge/gameplay layer changes;
- debug tracing itself consumes the AI budget;
- minimum-spec CPU hits planner, perception, nav rebuild, and streaming spikes together.

Hard caps, event coalescing, hysteresis, aging, activation ramps, continuation, and explicit safe fallbacks are required.

## Pros and Cons

### HFSM/StateTree

**Pros:** clear coarse modes, inherited transitions, predictable lifecycle, compact runtime state.  
**Cons:** transition coupling can grow; unsuitable for selecting among many graded alternatives; flat misuse recreates state explosion.

### Behavior trees

**Pros:** reactive, modular subtrees, readable execution hierarchy, strong interruption model, good action orchestration.  
**Cons:** uncontrolled services can become polling; large trees hide implicit priority; parallel/cancellation semantics can be error-prone.

### Utility AI

**Pros:** handles continuous tradeoffs, exposes tunable scores, supports personality and context, combines well with BT/HFSM.  
**Cons:** normalization/curve tuning is difficult; correlated considerations double-count evidence; close scores can oscillate; scoring large candidate sets is costly.

### GOAP

**Pros:** reusable actions, emergent sequences, adapts to unexpected state, separates goals from means.  
**Cons:** search can explode; symbolic model may diverge from continuous world; debugging plans and heuristics is specialized; action validation is mandatory.

### HTN

**Pros:** designer-guided procedures, predictable domain policy, hierarchical debugging, often prunes search strongly.  
**Cons:** method authoring is substantial; recursive/branching domains can still explode; procedural knowledge may become brittle or overly scripted.

### Hybrid architecture

**Pros:** each method solves the problem it fits; planners remain bounded specialists; shared action runtime avoids duplicated side effects.  
**Cons:** more interfaces, revisions, and ownership rules; poor boundaries can cause multiple systems to fight; tooling must explain cross-layer decisions.

## ECS and World-Partition Integration

Recommended ECS components:

- `AIControllerProfile`: decision asset set and scheduler class;
- `AIModeState`: current hierarchy state ID and revision;
- `AIWorkingMemoryHandle`: handle to service-owned typed facts;
- `AIIntent`: selected goal/tactic, score, commitment, generation;
- `AIPlanHandle`: generation-checked plan service handle;
- `AIActionState`: current primitive action and handle;
- `AILOD`: current tier, reason, next reevaluation;
- `AIDecisionPriority`: gameplay importance/deadline;
- `AITracePolicy`: off, sampled, error-only, full capture;
- `PersistentAIState`: durable mode/intent/timers required across unload.

Large blackboards, plans, subscriptions, planner nodes, and trace logs stay in service-owned pools. Components contain compact IDs/handles only.

World-partition integration:

1. the cell manifest declares required AI assets and smart-object/action dependencies;
2. staging constructs per-agent execution memory from compiled definitions;
3. persistence applies durable facts, mode, intent, cooldowns, and action-safe resume state;
4. AI registers with the scheduler only after `CellSimReady`;
5. activation is ramped across decision budgets;
6. `CellWillDeactivate` blocks new long actions and triggers suspend/cancel/serialize;
7. reservations and subscriptions release before entity retirement;
8. dormant persistence never stores raw entity, node, nav polygon, or pointer references.

## Navigation, AI, Streaming, and Event Interfaces

Recommended interfaces:

- `WriteFacts(agent, factBatch, sourceRevision)`
- `SubscribeFacts(agent, keyMask) -> SubscriptionHandle`
- `SelectIntent(agent, candidateSet, factSnapshot) -> IntentResult`
- `RequestPlan(agent, goal, factSnapshot, budget) -> PlanRequest`
- `ContinuePlan(request, budget) -> PlanStatus`
- `ValidatePlan(plan, changedFactMask, worldRevisions) -> validity`
- `StartAction(agent, actionDescriptor) -> ActionHandle`
- `CancelAction(handle, reason)`
- `SuspendAI(agent, reason)` / `ResumeAI(agent, readiness)`
- `SetAILOD(agent, tier, reason)`
- `RequestSpatialOptions(queryDescriptor) -> async query handle`
- `RequestPath(moveDescriptor) -> navigation handle`
- `ReserveSmartObject/Traversal/Cover(resource, agent, deadline)`

Events:

- `FactsChanged`;
- `ModeTransitioned`;
- `IntentSelected` / `IntentInvalidated`;
- `PlanReady` / `PlanFailed` / `PlanStale` / `PlanBudgetExceeded`;
- `ActionStarted` / `ActionCompleted` / `ActionFailed` / `ActionCancelled`;
- `ReservationGranted` / `Denied` / `Expired`;
- `NavigationInvalidated`;
- `StreamingReadinessChanged`;
- `AILODChanged`;
- `DecisionBudgetExceeded`;
- `AgentDecisionDeadlock`.

Events carry stable IDs, generations, revisions, and causes. They are coalesced and delivered at declared barriers. Team facts include source-agent and message generation to prevent feedback loops.

## Integration Plan

1. Define the shared primitive action lifecycle, cancellation rules, reservations, and generation safety.
2. Define schema-generated typed working memory with ownership, timestamps, confidence, expiry, revisions, and changed-key subscriptions.
3. Implement the event-driven scheduler, work budgets, continuation, LOD tiers, activation ramp, and tracing.
4. Implement HFSM/StateTree coarse modes with hierarchical transitions and transactional enter/exit.
5. Implement compiled behavior trees using shared definitions and pooled per-agent execution state.
6. Add utility-selector nodes with normalized response curves, eligibility, hysteresis, commitment, cooldown, and diagnostics.
7. Integrate bounded spatial/EQS-style candidate queries, navigation requests, and resource reservations.
8. Implement a bounded GOAP prototype for one trace-proven domain; add action relevance indexing and fact projections.
9. Implement an HTN prototype for one designer-procedural domain; validate depth/branch caps and authoring cost.
10. Add plan validation, repair/replan ladder, template caching, and domain revisions.
11. Integrate world streaming persistence/suspension and multiplayer/server-authority policies.
12. Establish automated conformance, determinism, soak, and performance gates before broad content rollout.

## Verification and Profiling Strategy

### Correctness

- Unit-test every behavior composite, decorator abort, parallel completion policy, and cancellation order.
- Property-test HFSM transition priority, ancestry, enter/exit balance, and failure propagation.
- Test blackboard ownership, type safety, expiry, confidence, event coalescing, and late writers.
- Compare utility scores against reference curves, including NaN, zero, saturation, and tied scores.
- Validate every generated plan by simulating preconditions/effects in a reference symbolic model.
- Fuzz GOAP actions and HTN methods for cycles, unbounded recursion, duplicate states, and impossible goals.
- Cancel actions at every lifecycle point and assert all reservations/subscriptions/handles release exactly once.
- Randomize async completion order for navigation, animation, streaming, and smart objects.
- Replay with different worker counts and hash authoritative decision results where determinism is required.

### Automated gameplay tests

- Run identical encounters through FP and TP player positions/cameras.
- Toggle alerts, target loss, damage, low ammo, blocked paths, destroyed cover, and link unavailability.
- Activate/unload encounters while agents plan, traverse, reload, speak, or reserve resources.
- Spawn synchronized crowds and verify scheduler staggering.
- Run planner-domain golden scenarios with expected valid goal/plan sets rather than one brittle exact sequence when multiple plans are acceptable.
- Run utility sensitivity sweeps and detect intent oscillation or never-selected options.
- Run long-duration ambient/combat soaks and detect stuck modes, orphan reservations, leaked plans, and unbounded belief growth.

### Profiling and debug tools

Per agent display:

- active StateTree ancestry and transition cause;
- active behavior-tree path, observed decorators, and pending aborts;
- working-memory facts with source, confidence, age, and revision;
- utility candidates with per-consideration score breakdown;
- selected intent, commitment, and switch cost;
- planner open/closed counts, expansions, depth, cost, elapsed budget, and failed preconditions;
- current plan/action, reservation ownership, and cancellation chain;
- scheduler priority, LOD, wake reason, queue age, and measured cost.

Aggregate telemetry:

- evaluations by algorithm and cause;
- nodes/transitions/candidates/expansions per decision;
- planner success, partial, timeout, overflow, cache hit, validation fail, repair, and replan rates;
- intent switch frequency and action interruption rate;
- event fan-out and coalescing rate;
- active/dormant agents and work by LOD;
- bytes for shared assets, agent state, facts, plans, pools, and traces;
- allocations/GC;
- p50/p95/p99/max decision time, queue latency, and frame cost.

### Acceptance gates

- zero steady-state managed garbage/general-heap allocation in decision execution;
- no unbounded tree, candidate, planner, method, event, trace, or subscription work;
- no action can retain reservations after finalization/destruction;
- no stale async completion can mutate a newer agent/action generation;
- event-driven agents do not perform full-tree polling without a declared periodic service;
- planner timeout/overflow produces a safe explicit fallback;
- utility selection meets oscillation limits in sensitivity/soak tests;
- streamed unload leaves no live callbacks or service pointers;
- AI remains within platform p99 frame and reaction-latency budgets under combined worst-case workloads.

## Risks and Open Decisions

- StateTree/HFSM versus BT ownership of combat submodes.
- Blackboard schema granularity and shared/team fact consistency.
- Behavior-node instancing policy and maximum per-agent execution memory.
- Utility combination method, normalization discipline, noise, hysteresis, and commitment values.
- Which domains genuinely require GOAP versus HTN versus authored BT sequences.
- Planner algorithm, heuristic, state hash, fact projection, and pool limits.
- Plan-template caching dependency granularity.
- Deterministic decisions across platforms versus server-authoritative outcomes.
- Parallel behavior semantics and action resource arbitration.
- AI LOD transitions for offscreen but authoritative agents.
- Resume-versus-restart policy after streaming dormancy.
- Tooling cost and whether full traces are sampled, ring-buffered, or capture-only.
- Designer workflow for validating unreachable states, unused actions, and dead utility options.

## Engineering Recommendations

1. Adopt a layered hybrid: HFSM/StateTree for coarse mode, event-driven BT for reactive execution, utility at graded choice points, and GOAP/HTN only for variable multi-step domains.
2. Build the shared action lifecycle and cancellation/reservation contract before adding multiple decision algorithms.
3. Use schema-generated typed working memory with fact ownership, confidence/time, revisions, and changed-key subscriptions.
4. Compile behavior/state assets into immutable contiguous definitions and store per-agent execution state in bounded pools.
5. Prefer event-driven invalidation; stagger the periodic work that remains.
6. Generate a bounded candidate set before utility scoring. Normalize curves, add hysteresis/commitment, and log top-N score explanations.
7. Keep planners asynchronous, continuation-based, pool-bounded, and dependency-validated. Never run an unbounded plan synchronously from a behavior tick.
8. Prototype GOAP and HTN in one representative domain each, then decide from plan quality, authoring cost, search tails, cache/reuse, and debugging data.
9. Separate symbolic planning cost from exact navigation/spatial queries; validate selected primitive actions asynchronously.
10. Make AI LOD preserve safety, authority, durable intent, and cleanup while reducing deliberation and spatial detail.
11. Treat traceability as a feature: every mode transition, branch abort, utility choice, plan failure, and action cancellation must expose a causal explanation.
12. Gate rollout on combined encounter-activation and soak tests, not isolated microbenchmarks.

## Source Links

1. Epic Games, **Behavior Tree Overview in Unreal Engine 5.8**: https://dev.epicgames.com/documentation/en-us/unreal-engine/behavior-tree-in-unreal-engine---overview
2. Epic Games, **Behavior Tree Node Reference in Unreal Engine 5.8**: https://dev.epicgames.com/documentation/en-us/unreal-engine/behavior-tree-node-reference-in-unreal-engine
3. Epic Games, **StateTree Overview in Unreal Engine 5.8**: https://dev.epicgames.com/documentation/unreal-engine/overview-of-state-tree-in-unreal-engine?lang=en-US
4. Epic Games, **StateTree Selectors Overview**: https://dev.epicgames.com/documentation/unreal-engine/state-tree-selectors-overview?lang=en-US
5. Epic Games, **Environment Query System in Unreal Engine 5.8**: https://dev.epicgames.com/documentation/en-us/unreal-engine/environment-query-system-in-unreal-engine
6. Iovino et al., **A Survey of Behavior Trees in Robotics and AI**: https://arxiv.org/abs/2005.05842
7. Colledanchise and Ogren, **Behavior Trees in Robotics and AI: An Introduction**: https://arxiv.org/abs/1709.00084
8. Orkin, **Agent Architecture Considerations for Real-Time Planning in Games**: https://ojs.aaai.org/index.php/AIIDE/article/view/18724
9. Orkin, **Three States and a Plan: The AI of F.E.A.R.**: https://www.madwomb.com/tutorials/gamedesign/prototyping/gdc2006_JeffOrkin_AI_FEAR.pdf
10. Nau et al., **SHOP2: An HTN Planning System**: https://s.aaai.org/Papers/JAIR/Vol20/JAIR-2013.pdf
11. Graham, **An Introduction to Utility Theory**, Game AI Pro: https://www.gameaipro.com/GameAIPro/GameAIPro_Chapter09_An_Introduction_to_Utility_Theory.pdf
12. Merrill, **Building Utility Decisions into Your Existing Behavior Tree**, Game AI Pro: https://www.gameaipro.com/GameAIPro/GameAIPro_Chapter10_Building_Utility_Decisions_into_Your_Existing_Behavior_Tree.pdf
13. GDC Vault, **Architecture Tricks: Managing Behaviors in Time, Space, and Depth**: https://www.gdcvault.com/play/1018040/Architecture-Tricks-Managing-Behaviors-in
14. Champandard et al., **Game AI Planning Analytics: The Case of Three First-Person Shooters**: https://cdn.aaai.org/ojs/12728/12728-52-16245-1-2-20201228.pdf

