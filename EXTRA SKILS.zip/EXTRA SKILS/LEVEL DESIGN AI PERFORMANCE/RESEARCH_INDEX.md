# Operation Mythology Level Design, AI, and Performance Research Index

This index covers reports saved in `C:\Users\steve\Desktop\EXTRA SKILS\LEVEL DESIGN AI PERFORMANCE`. It is updated only after each referenced report has been successfully saved and verified.

## 2026-07-27 01:49:41 America/Los_Angeles

**Report path:** `C:\Users\steve\Desktop\EXTRA SKILS\LEVEL DESIGN AI PERFORMANCE\operation-mythology-world-ai-performance-20260727-014941.md`

**Subjects covered:**

- A*, Dijkstra, weighted search, and hierarchical portal routing
- Tiled navmesh queries and immutable nav snapshots
- Query scheduling, priorities, cancellation, partial results, and bounded memory
- Polygon corridors, funnel/string-pulling, smoothing, and path following
- Coarse route, shared-goal, and per-agent corridor caching
- Dependency-revision invalidation and corridor repair
- D* Lite/LPA* adoption criteria and incremental replanning ladder
- Dynamic obstacle classification and bounded nav-tile rebuilding
- Off-mesh link state, capacity, reservation, and traversal contracts
- RVO, Detour-style crowd avoidance, ORCA assumptions, and density limits
- ECS, world partition, AI LOD, streaming, telemetry, soak, and automated nav tests

**Major claims:**

- Navigation should be layered into global topology, local topology, polygon corridor, trajectory, local avoidance, and query scheduling.
- A* is the default point-to-point search; Dijkstra is useful for multi-source/range/reference work; hierarchy bounds long-range search.
- A valid polygon corridor is authoritative; visual smoothing must remain constrained to it.
- Revisioned dependency invalidation and corridor repair are preferable to global cache flushes and automatic full replans.
- Incremental search retains state and is justified only for measured repeated-goal/local-change workloads.
- Moving agents and brief obstacles should use local avoidance rather than nav rebuilds.
- Every query, cache, neighbor set, corridor, dirty-tile queue, and rebuild needs hard bounds and explicit overflow behavior.

**Engineering recommendations:**

- Centralize path requests in a prioritized, time-sliced scheduler using pooled SoA search memory.
- Return explicit complete, partial, unreachable, cancelled, stale, overflow, and data-missing statuses.
- Cache coarse routes/shared goal fields and reuse agent corridors before caching arbitrary detailed paths.
- Version nav tiles, links, filters, layers, and path dependencies.
- Publish rebuilt tiles immutably and retire old snapshots after query readers complete.
- Use one avoidance solver per population, bound neighbors, and provide deadlock/infeasibility fallbacks.
- Treat off-mesh traversal as a reservation plus animation/physics contract.
- Profile navigation under combined streaming, AI, perception, physics, animation, and frame-time stress.

**Sources:**

- Epic Games: Unreal Engine navigation, avoidance, Navmesh API, and AI system settings
- Recast Navigation: official repository and Detour Path Corridor implementation
- Botea, Muller, and Schaeffer: *Near Optimal Hierarchical Path-Finding*
- Koenig and Likhachev: *D* Lite*
- van den Berg, Guy, Lin, and Manocha: ORCA / reciprocal collision avoidance
- Unity Technologies: AI Navigation package overview

**Remaining open decisions:**

- Heap type and duplicate-push versus decrease-key
- Per-platform node, time-slice, corridor, cache, and pool bounds
- Weighted-A* quality contracts
- Coarse graph construction and revision policy
- D* Lite/LPA* specialist adoption
- Dynamic navigation generation mode by content class
- Avoidance solver by movement/population type
- Non-holonomic, flying, climbing, swimming, and large-agent navigation
- Off-mesh fairness, replication, and interruption rules
- Deterministic cross-platform paths versus server-authoritative results
- Flow-field crossover threshold and stuck-recovery policy

## 2026-07-27 02:01:22 America/Los_Angeles

**Report path:** `C:\Users\steve\Desktop\EXTRA SKILS\LEVEL DESIGN AI PERFORMANCE\operation-mythology-world-ai-performance-20260727-020122.md`

**Subjects covered:**

- HFSM/StateTree coarse AI modes and hierarchical transition ownership
- Event-driven behavior trees, decorators, services, aborts, and compiled execution
- Typed blackboard/working-memory facts, ownership, confidence, expiry, and revisions
- Utility scoring, candidate generation, response curves, hysteresis, and commitment
- GOAP symbolic state, action search, plan repair, replanning, and bounded execution
- HTN methods, task decomposition, recursion/branch limits, and authoring tradeoffs
- Shared primitive-action lifecycle, cancellation, reservations, and late completion safety
- Plan templates/caching and dependency validation
- Event-driven AI scheduling, continuation, priorities, activation ramps, and AI LOD
- ECS, world partition, navigation, streaming, deterministic replay, debugging, and soak

**Major claims:**

- No single decision algorithm should own every AI choice; mode, reactive execution, graded selection, planning, action execution, and scheduling are separate responsibilities.
- An HFSM/StateTree plus event-driven behavior-tree baseline can incorporate utility selectors and planners only where their problem structure warrants them.
- Shared immutable node definitions and bounded per-agent state improve memory and cache behavior.
- Planners need asynchronous continuation, pool limits, explicit timeout/overflow status, and dependency validation.
- AI action cancellation must be idempotent and release navigation, smart-object, cover, animation, weapon, and event resources.
- Decision LOD may reduce deliberation but must preserve authoritative safety, cleanup, durable intent, and multiplayer requirements.

**Engineering recommendations:**

- Build the shared action/cancellation/reservation contract before multiplying decision algorithms.
- Use schema-generated typed working memory and changed-key subscriptions instead of hot dynamic string/variant maps.
- Compile state/behavior assets into contiguous immutable data with pooled per-agent execution blocks.
- Generate bounded candidate sets before utility scoring and expose full score explanations.
- Prototype GOAP and HTN in representative domains, then decide using plan quality, authoring cost, search tails, and trace data.
- Centralize scheduling with event wakeups, work-unit/time budgets, aging, staggering, continuation, and AI LOD.
- Make every transition, abort, utility choice, plan failure, and cancellation causally traceable.

**Sources:**

- Epic Games: Unreal Engine 5.8 Behavior Trees, StateTree, selectors, and Environment Query System
- Iovino et al.: *A Survey of Behavior Trees in Robotics and AI*
- Colledanchise and Ogren: *Behavior Trees in Robotics and AI*
- Jeff Orkin: *F.E.A.R.* real-time planning architecture and presentation
- Nau et al.: SHOP2 HTN planning
- Game AI Pro: utility theory and behavior-tree/utility integration
- AAAI AIIDE: planning analytics across three first-person shooters
- GDC Vault: time/space/depth utility architecture

**Remaining open decisions:**

- StateTree/HFSM versus behavior-tree ownership of combat submodes
- Blackboard schema granularity and squad/team fact consistency
- Utility combination, normalization, noise, hysteresis, and commitment policies
- GOAP versus HTN versus authored BT adoption by domain
- Planner algorithm, heuristic, fact projection, cache key, and pool limits
- Parallel behavior semantics and cross-action resource arbitration
- Deterministic decisions versus server-authoritative results
- Streaming dormancy resume versus restart
- AI LOD policy for offscreen but authoritative agents
- Full-trace sampling, ring-buffer, and capture policies

## 2026-07-27 02:17:57 America/Los_Angeles

**Report path:** `C:\Users\steve\Desktop\EXTRA SKILS\LEVEL DESIGN AI PERFORMANCE\operation-mythology-world-ai-performance-20260727-021757.md`

**Subjects covered:**

- Stimulus, source, listener, observation, belief, suspicion, threat, and team-report contracts
- Sight broad phase, acquire/retain hysteresis, vision zones, visibility points, asynchronous traces, and identification certainty
- Hearing events, coalescing, priority, uncertain localization, and optional room/portal propagation
- Damage, near-miss, touch, and bounded prediction evidence
- Per-listener belief memory, uncertainty, provenance, fusion, decay, and timing-wheel expiry
- Suspicion accumulation/decay and alert-state inputs
- Threat scoring as a stage separate from perceptual certainty
- Team communication provenance, trust, latency, hop/deduplication, and player-facing dialogue
- Perception spatial indices, allocation pools, concurrency, AI scheduling, and LOD
- World partition, streaming activation/unload, multiplayer authority, debugging, automation, and soak

**Major claims:**

- Perception must convert bounded evidence into agent-specific beliefs and must not directly choose behavior or expose ground truth.
- Naive listener-by-all-source pairing is unacceptable; spatial broad phase and cheap filters must precede expensive visibility work.
- Acquisition and retention need separate ranges/timing, while continuous identification certainty avoids abrupt stealth boundaries.
- Asynchronous sight requires generation/revision validation and continuity from prior beliefs.
- Damage proves harm but must not automatically reveal forbidden attacker identity or exact position.
- Suspicion and threat are distinct: suspicion measures abnormal/hostile evidence, while threat estimates urgency and expected harm.
- Team reports require provenance and deduplication to avoid accidental omniscience and evidence amplification.

**Engineering recommendations:**

- Use immutable stimuli, compact source/listener proxies, a hashed-grid/BVH broad phase, and pooled batched physics traces.
- Provide prioritized target visibility points and issue additional rays only for ambiguous/high-value cases.
- Keep gameplay visibility deterministic and independent from renderer exposure, dynamic resolution, or camera occlusion.
- Store bounded beliefs with stable IDs, global uncertain positions, confidence, provenance, timestamps, and timing-wheel expiry.
- Coalesce repeated low-value sounds and reserve capacity for damage, gunshots, explosions, and current threats.
- Preserve trust, latency, hop count, and original evidence in team reports.
- Ramp sensing on streamed activation and enforce hard bounds for every pair, ray, stimulus, belief, and report queue.
- Gate on combined stealth, crowd, streaming, multiplayer, and minimum-spec p99 soak tests.

**Sources:**

- Epic Games: Unreal Engine 5.8 AI Perception, components, sight configuration, and sight query APIs
- Unity Technologies: asynchronous batched `RaycastCommand`
- Steve Rabin: *Vision Zones and Object Identification Certainty*
- Travis McIntosh: *Human Enemy AI in The Last of Us*
- Martin Walsh: *Modeling AI Perception and Awareness in Splinter Cell: Blacklist*
- Jeff Orkin: *Combat Dialogue in F.E.A.R.: The Illusion of Communication*

**Remaining open decisions:**

- 2D/3D hashed grid, BVH, or hybrid perception broad phase
- Visibility-point count and prioritization
- Gameplay illumination/camouflage representation
- Evidence-fusion and uncertainty model
- Suspicion thresholds, dwell, decay, and saturation
- Radial, occlusion-ray, portal-graph, or specialist hearing
- Belief capacity and anonymous-stimulus association
- Threat-score ownership between perception and utility systems
- Team speech/radio/abstract sharing semantics, trust, latency, and jamming
- Server-only perception versus replicated belief summaries
- CPU versus optional GPU-assisted crowd sight
- Dormant belief persistence and player feedback requirements

## 2026-07-27 02:35:11 America/Los_Angeles

**Report path:** `C:\Users\steve\Desktop\EXTRA SKILS\LEVEL DESIGN AI PERFORMANCE\operation-mythology-world-ai-performance-20260727-023511.md`

**Subjects covered:**

- Encounter Director pacing, intensity, population budgets, phases, and authored overrides
- Encounter definitions, instances, objectives, groups, beats, cleanup, and save state
- Spawn collection, visibility/fairness, route, readiness, density, memory, and network validation
- Population cost, pooling, coarse records, and multi-dimensional AI LOD
- Squad identity, merge/split, shared objectives, leadership, and personal autonomy
- Role assignment, capacity, commitment, and reassignment
- Frontline, lanes, formations, advancing, retreating, flanking, breaching, and disengaging
- Tactical candidate generation, filters, normalized scores, async expensive tests, and top-K
- Cover rails/points, Smart Objects, reservations, expiry, destruction, and contention
- Influence, danger, exposure, support, and congestion fields
- ECS/world partition, concurrency, nav revisions, streaming, replication, telemetry, and soak

**Major claims:**

- Director, encounter, squad, tactical-query, reservation, and individual-action layers need separate ownership.
- Encounter pacing and difficulty are different controls; the initial Director should adjust bounded pressure timing/population rather than secretly rewrite all combat rules.
- Spawn validity includes player visibility, route-to-engagement, world/nav readiness, density, population, memory, and network checks.
- Stable tactical frames, role commitment, and staggered maneuvers reduce indecisive movement.
- Tactical queries should generate narrowly, filter cheaply, test expensive top candidates asynchronously, and reserve atomically.
- AI LOD is multi-dimensional across simulation, decision, perception, navigation, representation, replication, animation, and group coordination.

**Engineering recommendations:**

- Use structured unpredictability from designer-validated alternatives and seeded bounded variation.
- Implement generation-safe reservations shared by cover, Smart Objects, traversal, and spawn anchors.
- Build a reusable bounded tactical-position service with normalized scores, fallbacks, top-K alternatives, and causal diagnostics.
- Coordinate advance/retreat/flank in waves where some agents move and others cover.
- Stage Director state changes with hysteresis, dwell, cooldown, minimum relaxation, and mandatory-beat exclusions.
- Use lightweight population records and staged promotion rather than retaining unbounded fully constructed hidden agents.
- Gate on split-player spawn fairness, cover contention, destruction, mass promotion, save/load, and minimum-spec combined soak.

**Sources:**

- Epic Games: Unreal Engine 5.8 EQS, Smart Objects, and Mass Gameplay/LOD
- Kevin Dill: *Tactical Position Selection: An Architecture and Query Language*
- Tobias Karlsson: *Squad Coordination in Days Gone*
- Michael Booth/Valve: *The AI Systems of Left 4 Dead*

**Remaining open decisions:**

- Authored, spatial/connectivity, objective-based, or hybrid squad formation
- Coordinator transfer and communication-delay policy
- Role assignment algorithm and maximum squad size
- Frontline stabilization and specialist exclusion
- Authored cover, rails, nav-derived cover, or hybrid
- Tactical normalization, fallbacks, top-K, and reservation fairness
- Influence field representation and update policy
- Spawn visibility/audio/flow/path-distance rules
- Entity pooling versus lightweight population records
- Director pacing-only versus difficulty authority
- Co-op intensity aggregation and mandatory beat exclusions
- Aggregate coarse-simulation fidelity and promotion placement
- Server-authoritative coordination versus client presentation

## 2026-07-27 02:50:51 America/Los_Angeles

**Report path:** `C:\Users\steve\Desktop\EXTRA SKILS\LEVEL DESIGN AI PERFORMANCE\operation-mythology-world-ai-performance-20260727-025051.md`

**Subjects covered:**

- Versioned FP/TP/AI movement, camera, interaction, and traversal metric profiles
- Modular environment descriptors, pivots, bounds, sockets, connector grammar, and assemblies
- Sparse sector, portal, route, traversal, encounter, and landmark topology
- Pacing beat graphs and bounded encounter-Director authority
- Guidance anchors, route hypotheses, landmarks, and decision-point telemetry
- Level Instances, Packed Level Blueprints, World Partition, Data Layers, and nav chunks
- Asset-save, changed-cell CI, nightly state-matrix, packaged-device, and soak validation
- ECS records, stable IDs, streaming readiness, persistence, budgets, and event interfaces
- Complexity, allocation/GC, spatial indexing, cache behavior, concurrency, nav rebuild, AI scheduling, I/O, residency, visibility, frame time, and combined worst cases

**Major claims:**

- Authored levels should compile into explicit gameplay and runtime contracts rather than relying on render geometry as implicit truth.
- Visual modules, gameplay assemblies, and streaming/semantic ownership require separate boundaries.
- A versioned metric source prevents controller, camera, animation, navigation, cover, traversal, and level layout from drifting.
- A sparse semantic graph should sit above the navmesh for topology validation, predictive streaming, pacing, encounter eligibility, and diagnostics.
- Guidance should be expressed as measurable hypotheses; completion alone does not prove comprehension.
- Cell visibility, residency, gameplay readiness, navigation readiness, and encounter eligibility are distinct states.
- Performance gates must exercise synchronized streaming, nav, AI promotion, visibility, persistence, and cold-I/O stress.

**Engineering recommendations:**

- Create a Level Contract containing metric profiles, module/socket descriptors, semantic topology, beat intent, guidance anchors, and cell budget manifests.
- Compile authored metadata into flat stable-ID records and avoid per-frame queries over authoring objects.
- Make metric changes invalidate all dependent collision, nav, traversal, cover, camera, and validation products.
- Use connector compatibility masks, padded clearance volumes, portal seal rules, and per-agent seam tests.
- Let the encounter Director vary pressure only inside authored topology and pacing constraints.
- Use staged cell readiness with generation-safe async jobs and promotion budgets.
- Validate in four tiers and attach stable IDs, world state, profile, platform, and reproduction seed to every result.
- Pilot the contract on one interior and one exterior kit before ratifying schemas.

**Sources:**

- Epic Games: Unreal Engine 5.8 Level Instancing, World Partition, Data Layers, navigation, Data Validation, Automation, and Gauntlet documentation
- Joel Burgess: *Modular Level Design*
- Joel Burgess, Matt Scott, and Lee Perry: *Level Design Workshop* introduction and pacing material
- Ed Byrne: *Level Design in a Day—Preproduction*
- David Pittman: *Procedural Level Design in Eldritch*

**Remaining open decisions:**

- Canonical grid, socket tolerances, and module granularity
- Hard versus archetype-specific metrics and TP camera envelope
- Semantic-sector relationship to cells, encounters, and visibility portals
- Packed-static versus independently stateful/streamed assemblies
- World Partition nav-chunk maturity for the selected engine version
- State-matrix coverage strategy and required route redundancy
- Landmark proxy residency and critical guidance requirements
- Director authority over pacing envelopes
- Traversal behavior during nav rebuild/readiness loss
- Platform-specific cell, activation, visibility, AI, and nav budgets
- Submission-blocking rules and expiring waiver ownership

## 2026-07-27 03:13:02 America/Los_Angeles

**Report path:** `C:\Users\steve\Desktop\EXTRA SKILS\LEVEL DESIGN AI PERFORMANCE\operation-mythology-world-ai-performance-20260727-031302.md`

**Subjects covered:**

- Hierarchical world, cell, sector, cluster, instance, and primitive visibility
- Authored sectors/portals, conservative PVS, and exterior BVH/loose hierarchy
- Distance, screen-size, frustum, HZB, hardware-query, and depth rejection stages
- Temporal visibility state, camera discontinuity invalidation, and conservative overflow
- HLOD representation selection, residency handoff, hysteresis, and peak overlap
- FP/TP, stereo, split-screen, shadow, reflection, capture, spectator, and headless view policy
- Separation of render visibility, gameplay visibility, streaming demand, and simulation significance
- Visibility-driven streaming hints, sector-level AI LOD evidence, and staged reveal promotion
- CPU/GPU complexity, allocation/GC, spatial layout, cache behavior, concurrency, nav cost, I/O, memory, visibility, frame budgets, and combined worst cases

**Major claims:**

- Visibility should progressively reduce candidates through conservative stages rather than rely on one culling method.
- Renderer visibility is not valid ground truth for AI sight, damage, replication, collision, quests, or durable simulation.
- HLOD is a representation-residency transaction; a replacement must be ready before its predecessor retires.
- Visibility feedback is reactive and cannot replace topology/motion/objective prediction for streaming.
- Temporal coherence reduces work but requires visible-biased initialization, delayed occluded confirmation, periodic retest, and discontinuity resets.
- Multi-view visibility and residency need explicit policies because shared unions can be conservative and separate traversal can multiply cost.
- Culling is profitable only when downstream work saved exceeds depth, HZB, compute, barrier, memory, transition, and event cost.

**Engineering recommendations:**

- Use state/cell, sector/PVS, distance/frustum, HLOD, GPU HZB/compaction, and hardware depth as the default hierarchy.
- Compile hybrid portal/interior and BVH/exterior data into flat immutable snapshots.
- Resolve unknown, stale, missing-residency, and overflow cases to visible or a valid proxy.
- Keep render visibility, gameplay visibility, streaming demand, and simulation significance as separate interfaces.
- Use generation-tagged temporal history with camera/world/state invalidation and no current-frame GPU readback.
- Budget fine/proxy overlap and keep HLOD separate from authoritative collision, navigation, and gameplay.
- Feed streaming confidence-weighted visibility only after dwell; feed AI LOD coalesced sector evidence only.
- Gate total-frame profitability and synchronized camera-reveal/streaming/HLOD/AI/nav worst cases.

**Sources:**

- Epic Games: Unreal Engine 5.8 visibility/occlusion, precomputed visibility, World Partition HLOD, World Partition, and release notes
- Unity Technologies: occlusion-culling troubleshooting and CullingGroup API
- Microsoft: Direct3D 12 predication and query sample
- Khronos Group: Vulkan 1.4 specification
- Bittner et al.: *Coherent Hierarchical Culling*
- Mattausch, Bittner, and Wimmer: *CHC++*
- AMD GPUOpen: Radeon GPU Profiler and performance-counter documentation

**Remaining open decisions:**

- Authored portal sectors versus automatic hierarchy versus hybrid
- PVS scope, compression, build policy, and per-platform memory ceiling
- CPU/GPU split for distance and frustum work
- Previous/current-frame depth and full/partial prepass policy
- HZB test, epsilon, mip, near-plane, and dynamic-occluder policy
- Temporal confirmation, dwell, retest, and discontinuity thresholds
- HLOD grouping, switch metric, transition mode, and overlap budget
- Shared versus separate stereo/multi-view traversal
- Auxiliary-view quality policies
- Visibility influence on streaming and AI/animation/audio LOD
- Conservative overflow behavior and buffer capacities
- Platform gates for traversal, depth/HZB, compute, memory, and visible elements
