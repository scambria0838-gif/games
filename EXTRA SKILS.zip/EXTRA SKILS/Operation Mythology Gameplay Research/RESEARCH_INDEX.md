# Operation Mythology Gameplay Research Index

This index records completed non-rendering gameplay research generated after scanning `C:\Users\steve\Desktop\GAME SKILLS`.

## Source-library inventory at initialization

Scanned recursively on 2026-07-27 at approximately 01:11 America/Los_Angeles.

Existing source-library reports:

- `2026-07-27_renderer_gpu-driven-indirect-submission.md`
- `2026-07-27_renderer-render-graph-transient-aliasing.md`
- `2026-07-27_renderer-shading-path-visibility-deferred-forward-plus.md`
- `2026-07-27_gpu-memory-residency-streaming.md`
- `2026-07-27_virtual-geometry-texture-streaming.md`
- `2026-07-27_ecs-archetypes-job-system.md`
- `2026-07-27_temporal-upscaling-motion-vector-contract.md`
- `2026-07-27_global-illumination-reflections-hybrid.md`
- `2026-07-27_shadows-virtual-maps-stochastic-many-lights.md`
- `2026-07-27_animation-pose-evaluation-sharing-gpu-deformation.md`
- `2026-07-27_physics-character-controller-fp-tp.md`
- `2026-07-27_open-world-partition-streaming-origin.md`
- `GAME_SKILLS_RESEARCH_INDEX.md`

The source library now contains renderer architecture plus an archetype ECS/job-system baseline. The ECS report is treated as a shared architectural constraint; it does not cover the gameplay feature baselines below.

## Completed reports

| Date | Domain | Topic | Status | Report |
|---|---|---|---|---|
| 2026-07-27 | Gameplay physics and locomotion | Deterministic FP/TP character locomotion, collision, moving platforms, and hitbox boundaries | Baseline complete | `2026-07-27_011102_character-controller-fp-tp-hitbox.md` |
| 2026-07-27 | Input and gameplay commands | Action-based input, remapping, hot-plugging, accessibility, and fixed-tick command frames | Baseline complete | `2026-07-27_011802_action-input-remapping-accessibility.md` |
| 2026-07-27 | Gameplay camera architecture | Perspective-agnostic FP/TP rigs, collision, aim convergence, transitions, and motion accessibility | Baseline complete | `2026-07-27_012432_fp-tp-camera-collision-aim-accessibility.md` |
| 2026-07-27 | Character traversal | Mantling, vaulting, ledges, climbing, ladders, ziplines, swimming, reservations, and animation warping | Baseline complete | `2026-07-27_013004_traversal-mantle-vault-climb-swim.md` |
| 2026-07-27 | Character animation | Hybrid animation graph, motion matching, root-motion reconciliation, pose sharing, and foot placement | Baseline complete | `2026-07-27_013428_animation-motion-matching-root-motion-foot-ik.md` |
| 2026-07-27 | Combat rules and abilities | Authoritative damage, defense layers, attributes, effects, stacking, abilities, cooldowns, and gameplay tags | Baseline complete | `2026-07-27_015125_damage-armor-status-abilities-tags.md` |
| 2026-07-27 | Multiplayer simulation | Server authority, command streams, owner prediction, reconciliation, snapshot interpolation, bounded server rewind, and anti-cheat boundaries | Baseline complete | `2026-07-27_020000_authoritative-networking-prediction-rewind-anticheat.md` |
| 2026-07-27 | NPC AI and navigation | Tiled navmesh, hierarchical routing, corridors, crowd avoidance, smart objects, behavior selection, environment queries, and perception | Baseline complete | `2026-07-27_020502_npc-navigation-crowds-smart-objects-perception.md` |
| 2026-07-27 | Items and interactions | Authoritative item instances, containers, inventory transactions, equipment activation, pickups, interaction affordances, reservations, and replication | Baseline complete | `2026-07-27_021329_inventory-equipment-interaction-transactions.md` |
| 2026-07-27 | Persistence and replay | Versioned ECS snapshots, journals, crash-safe generations, checkpoints, schema migration, staged loading, and command/state replay | Baseline complete | `2026-07-27_022307_save-checkpoint-migration-replay-world-state.md` |
| 2026-07-27 | World environment gameplay | Canonical calendar/time, crossing-aware scheduling, deterministic regional weather, local exposure, and renderer-neutral sky/environment contracts | Baseline complete | `2026-07-27_023037_time-weather-environment-gameplay-contract.md` |

## Covered recommendations and claims

### Character controller, FP/TP, and hitbox boundaries

- Capsule-based kinematic/virtual controller is the default; a dynamic rigid-body controller is a specialized backend.
- Fixed-step, tick-addressed input and serializable movement state support prediction, replay, and rollback.
- One primary movement mode plus bounded, serializable layered moves.
- Bounded sweep-and-slide iterations, explicit walkable-slope test, constrained step validation, conditional ground snap, and overlap-safe crouching.
- Stable moving-platform/base identity and transform history are part of authoritative movement state.
- First-/third-person cameras affect intent construction and presentation, not collision or movement rules.
- Locomotion capsule, query-only hurtboxes, and attack hitboxes/traces are separate layers.
- ECS integration defines components, ordered systems, deterministic events, physics-query boundaries, and zero-allocation warm-frame requirements.
- Verification covers slopes, stairs, seams, low ceilings, platforms, FP/TP switches, replay hashes, hit deduplication, rollback, and scale benchmarks.

### Action input, remapping, and accessibility

- Three strict layers: platform/device ingestion, semantic action resolution, and fixed-tick gameplay command frames.
- Platform backends normalize timestamped controls and hot-plug events; gameplay never receives SDL/GameInput/platform objects.
- Typed actions use prioritized contexts, deterministic consumption, processors, triggers, and stable IDs.
- Inverted physical-control-to-binding lookup avoids naive event-by-all-bindings scans.
- Digital edges and relative mouse deltas are accumulated so events between simulation ticks are not lost.
- Networking and replay record compact semantic command frames, never raw device readings.
- Full action remapping, profile migration, conflict handling, prompt/glyph refresh, per-axis settings, toggles, digital alternatives, and single-stick policies are foundational.
- FP/TP cameras share `Move`/`Look` actions and differ through control-frame and presentation policy.
- Bounded queues, preallocated runtime state, dense indices, bitsets, and history rings provide zero-allocation steady-state behavior.
- Verification covers hot-plug, focus, context transitions, edge preservation, variable render rates, replay hashes, accessibility, and event floods.

### FP/TP camera, collision, and aim convergence

- Modular compiled rig pipeline exposes ideal, collision-constrained, and final presented camera poses.
- First-/third-person rigs share target, view-intent, lens, transition, and publication contracts and never alter authoritative locomotion.
- Third-person safety baseline uses a swept sphere or near-plane-aware volume, not a center ray, with immediate retraction and controlled/hysteretic restoration.
- Collision and target occlusion are separate queries and policies; optional alternate candidates remain bounded and benchmark-gated.
- Aim uses a camera/reticle acquisition ray followed by muzzle-to-target validation; muzzle obstruction wins.
- Camera state evaluates at render frequency from interpolated simulation snapshots without feeding smoothing back into simulation.
- Time-based damping, typed transitions, cut/teleport resets, fixed-capacity effect stacks, and explicit temporal-history invalidation.
- FP additive motion, shake, bob, sway, recoil motion, FOV kick, auto-centering, and camera roll have independent accessibility scaling through zero.
- ECS integration defines camera/target/rig/collision/accessibility components, ordered systems, query boundaries, and compact events.
- Verification covers thin geometry, fast obstacles, transitions, FP/TP invariance, parallax, muzzle cover, accessibility, and split-screen scaling.

### Unified traversal and environmental affordances

- Hybrid architecture uses dynamic probes for common mantles/vaults and authored semantic slots/links for ladders, ziplines, complex climbing, interactions, and AI planning.
- Both sources produce one immutable candidate with entry/exit targets, measured geometry, source-local transforms, capability requirements, profile, reservation, generation, and expiry.
- Staged intent, spatial search, geometry classification, full capsule clearance, reachability, deterministic scoring, claim, and final revalidation.
- No one-ray mantle decisions; face, top/exit support, path segments, and destination capsule must validate.
- Traversal executes as a fixed-tick movement mode with requested/claimed/aligning/executing/exiting/completed-or-aborted phases.
- Animation motion warping and root displacement are bounded movement proposals; animation never directly writes authoritative transforms.
- Smart-object-style free/claimed/occupied/released reservations prevent conflicting use and must release on all abort/lifecycle paths.
- Moving targets are stored relative to generation-checked source geometry.
- Water is a movement-volume contract with wade/surface/underwater modes; water exits reuse the mantle candidate pipeline.
- AI navigation links reference the same traversal definitions and include capability, duration, risk, and occupancy costs.
- Query/candidate counts, buffers, claims, rollback rings, and events are bounded and allocation-free after warm-up.
- Verification covers geometry thresholds, moving/streamed sources, contention, aborts, animation coverage, prediction rejection, and claim leaks.

### Animation graph, motion matching, root motion, and foot placement

- Hybrid recommendation: explicit gameplay state/action domains, motion matching for continuous locomotion, explicit clips/actions for timing-critical combat/traversal, and bounded procedural correction.
- Immutable fixed-tick simulation snapshots feed job-safe render-frequency animation; animation cannot read mutable gameplay or directly mutate ECS state.
- High-level domain/database filtering precedes pose search so illegal semantic states are never selected.
- Exact SIMD-friendly O(D x F) pose search is the correctness baseline; approximate indices require measured scale and quality evidence.
- Query features combine actual collision-accepted current motion with desired future gameplay trajectory.
- Ordinary locomotion is gameplay-driven; authored root motion becomes a serializable layered movement proposal processed by character collision.
- Motion warping, distance matching, orientation/stride warping, play rate, and pelvis adjustments have explicit limits and coverage telemetry.
- Foot placement uses animation contact metadata plus filtered support probes, source-local moving-platform targets, bounded pelvis correction, and IK; it never determines gameplay grounding.
- Animation budgets define hero/near/crowd/distant tiers for search, pose, IK, facial, physics, and update cadence.
- Compatible crowds share leader poses by skeleton/state/phase bucket, with bounded individual overlays.
- Gameplay events are fixed-tick action data; presentation notifies may be LOD-filtered and never own damage or authority.
- Renderer consumes stable current/previous pose handles and owns GPU skinning/deformation resources.
- Verification covers search quality, database gaps, collision-rejected root motion, rollback, foot locks, multithreading, sharing, and crowd scale.

### Damage, armor, status effects, abilities, cooldowns, and gameplay tags

- Immutable, versioned definitions are separated from compact runtime ability/effect instances.
- Activation follows validate, atomic commit, execute, and complete/cancel semantics; failed commits have no authoritative side effects.
- Effects share explicit duration, periodic, stacking, overflow, refresh, dispel, immunity, and tag-query contracts.
- Damage is one ordered, auditable transaction from validation and hit zone through resistance, penetration, defense layers, health, and life-state transitions.
- Attributes distinguish base/current values where reversible aggregation is required; derived dependencies use dirty evaluation.
- Hierarchical authoring tags compile to stable IDs and dense runtime bitsets/indices; strings and runtime bit positions are not serialized.
- Cooldowns and effect endpoints use simulation ticks, not timer objects or wall-clock time.
- Cosmetic cues are idempotent and disposable; authoritative gameplay events are tick-addressed and replayable.
- Fixed-capacity buffers, immutable blobs, per-worker arenas, timing-wheel/heap scheduling, and deterministic command merges eliminate steady-state GC.
- Prediction is allowlisted and reversible; instant damage and hidden/server-owned outcomes remain authoritative.
- Verification covers modifier algebra, stacking, damage conservation, deterministic hashes, rollback/rejection, overflow, burst AoE, and mass-expiration workloads.

### Server authority, prediction, reconciliation, rewind, and anti-cheat

- Dedicated server authority owns movement, combat, abilities, inventory, random outcomes, and persistence; clients submit tick-addressed semantic intent only.
- Owner-controlled characters predict shared fixed-tick kernels and reconcile by restoring authoritative state and replaying unacknowledged command history.
- Most remote entities use buffered snapshot interpolation; prediction, interpolation, and the authoritative server present remain distinct timelines.
- Commands and results are idempotent through connection-scoped sequences, acknowledgements, stable event IDs, and bounded tick windows.
- Server rewind reconstructs only minimal historical collision/hurtbox proxies in an isolated query view; it never rewinds the live physics world.
- Rewind evaluation time is derived and clamped by the server using observed timing and reported interpolation delay, never accepted directly from the client.
- Hitscan, projectiles, melee, and area effects use explicit weapon-specific lag-compensation policies and fairness caps.
- Prediction, command, snapshot, and history rings are fixed-capacity and allocation-free; predicted archetypes remain stable to avoid costly history invalidation.
- Every client field is untrusted and range/ownership/rate/state validated; simulation authority prevents invalid results while telemetry provides reviewable evidence.
- Verification covers determinism, packet impairment, rollback side effects, rewind boundaries, malicious input, memory/bandwidth budgets, and p99 tick cost.

### NPC navigation, crowds, smart objects, behavior, and perception

- Hybrid navigation uses streamable tiled navmeshes for grounded free movement, coarse portal/zone routing for world scale, and authored semantic links for traversal.
- Asynchronous global planning produces bounded polygon corridors; local corner following submits preferred velocity but the character controller owns authoritative motion.
- Dynamic obstacles use local avoidance first, temporary cost/block overlays second, localized tile rebuilds only for persistent geometry changes.
- Crowd avoidance uses a spatial index, capped high-risk neighbors, predictive constraints, deterministic tie-breaks, and near/mid/far simulation tiers.
- Local avoidance does not solve bottleneck allocation; doors, lanes, and scarce portals use explicit reservations/arbitration.
- Smart Objects expose immutable activity/slot definitions and generation-checked atomic claims; interactors own execution and release claims on every lifecycle path.
- Compiled hierarchical states, bounded selectors/utility choices, asynchronous task handles, event wakes, and scheduled reevaluation replace per-frame full-tree polling.
- Environmental queries use bounded generator-filter-score pipelines with cheap hard filters before traces/path tests.
- Perception separates world truth from agent knowledge through registered stimuli, spatial broad phase, budgeted narrow phase, fixed-tick confidence/expiry, and server authority.
- Immutable blobs, pooled queries, fixed corridors/neighbors/knowledge, per-worker arenas, and explicit budgets eliminate warm-frame GC and synchronized spikes.
- Verification covers navmesh topology, tile churn, corridor repair, crowd deadlock, perception floods, behavior cancellation, smart-object contention, AI LOD transitions, and 50k-agent tier scaling.

### Inventory, equipment, interaction, pickups, and item transactions

- Immutable versioned definitions are separated from authoritative runtime item instances; fungible stacks and unique property-bearing items use explicit identity policies.
- All inventories, equipment sets, magazines, chests, pickups, escrow, and crafting inputs are containers with stable slots, revisions, filters, capacities, and bounded nesting.
- Every mutation is a validated atomic transaction with a stable operation ID, canonical request hash, expected revisions, staged deltas, typed result, and audit record.
- Idempotency prevents retry duplication; optimistic revisions prevent stale concurrent writes. They are separate mechanisms.
- Equipment is derived active state bound to an owned item and records exact ability/effect/input/presentation grant handles for deterministic removal.
- Interaction discovery exposes typed affordances; the server revalidates target generation, range, occlusion, tags, capacity, and claims before executing.
- World pickup/drop transfers are atomic across inventory and world ownership; failed world spawn leaves the item owned.
- Reservations and escrow protect reload, crafting, timed pickup, trade, and cross-owner workflows from partial completion.
- Private owner inventory, public equipment, and public pickup views replicate separately through stable IDs and acknowledged deltas.
- Persistence consumes committed journals/outbox records or versioned snapshots; fixed-tick gameplay never blocks synchronously on a remote database.
- Verification covers invariants, fuzzed transactions, duplicate/reordered retries, revision conflicts, contested pickups, equip interruption, crash recovery, security, and high-scale delta replication.

### Save/load, checkpoints, migration, replay, and world state

- Persistence is opt-in per schema/component and partitioned into settings, profile, playthrough, checkpoint, world-cell, session, and replay domains.
- Durable formats use stable entity/content/type/field IDs, never ECS indices, pointers, runtime handles, or display names.
- Tick-consistent capture occurs after authoritative structural/transaction commit and hands immutable/copy-on-write pages to asynchronous workers.
- Periodic versioned snapshots plus idempotent journal tails provide bounded recovery and incremental autosaves.
- New save generations write, flush, verify, and atomically publish without overwriting the previous known-good generation.
- Schema evolution is additive: stable numeric field IDs, optional/defaulted additions, reserved/deprecated removals, independently versioned packed blobs, and pure deterministic migrations.
- Load occurs in a staging world with two-pass identity/reference resolution, content/cell readiness, journal replay, invariant validation, derived-cache rebuild, then atomic activation.
- Checkpoints explicitly define safe transform, dependency cells, resources/status, encounter state, world flags, random streams, and transaction cutoffs.
- Authoritative command replay serves deterministic validation; baseline/checkpoint/incremental state replay provides robust viewing and cross-build fallback.
- Replay playback runs in isolation and cannot mutate live progression, services, inventory, achievements, or the active world.
- Chunked serialization, dirty tracking, pooled buffers, compression/I/O workers, and per-frame checkpoint budgets avoid fixed-tick stalls and GC.
- Verification includes golden-version migration, corruption/crash injection at every commit phase, streaming races, malicious data, replay seeking/divergence, and million-record scale tests.

### Time of day, weather, and gameplay environment state

- Separate authoritative simulation tick, fixed-point game calendar, interpolated presentation time, monotonic real time, and optional wall-clock UTC.
- One canonical elapsed game timestamp derives calendar fields; mutable hour/day/sun values are not independently stored.
- Crossing-aware scheduling processes all events in `(oldTime, newTime]` with stable ordering and explicit execute-all, aggregate, final-state, discard, or block-jump policies.
- Weather is deterministic regional gameplay state with authored transition rules, named random streams, transition endpoints/times, continuous channels, semantic tags, and persisted decisions.
- Global calendar, climate region, weather, streamed cell, authored volume, shelter, and entity modifiers compose through typed priority/blend rules.
- Local exposure is distinct from regional weather; renderer/audio presentation is distinct from both.
- AI, abilities, navigation, physics, inventory, audio, streaming, persistence, replay, and sky adapters consume immutable revisioned environment snapshots.
- Renderer owns skybox, atmosphere, lighting, fog, clouds, visual curves, smoothing, and GPU resources; gameplay never reads visual output to determine rules.
- Region/cell membership caching, spatial indices, threshold subscriptions, analytical transitions, rate separation, immutable blobs, and pooled buffers eliminate full scans and warm-frame GC.
- Verification covers long-duration drift, simultaneous event ordering, time jumps, region borders/volumes, headless equivalence, replication, save/replay, content migration, and accelerated-year soak.

## High-priority uncovered gameplay domains

- Audio event routing, surface/material footsteps, occlusion triggers, and deterministic cue selection
- World streaming gates, collision readiness, origin rebasing, and gameplay handoff
- Telemetry, debugging overlays, soak testing, fuzzing, and performance regression gates

## Deduplication rule

Before every research batch:

1. Recursively inspect `C:\Users\steve\Desktop\GAME SKILLS`.
2. Inspect this index and all reports in this output directory.
3. Select an uncovered topic or a material update/correction.
4. Do not create a report when no meaningful delta exists.
5. Update this index only after the corresponding report has been saved successfully.

Revisit a completed topic only for a material API/status change, corrected claim, new benchmark evidence, missing architectural dependency, or changed Operation Mythology requirement. Label revisits as deltas.
