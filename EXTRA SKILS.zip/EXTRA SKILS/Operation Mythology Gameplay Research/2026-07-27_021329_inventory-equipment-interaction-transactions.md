# Operation Mythology Technical Recommendation Report

**Domain:** Inventory, equipment, containers, pickups, interactions, item instances, and transactional item state  
**Research timestamp:** 2026-07-27 02:13:29 America/Los_Angeles  
**Scope:** Non-rendering gameplay architecture for a modular, data-oriented ECS supporting first- and third-person play  
**Status:** New baseline recommendation

## Feature Overview

An inventory system is an authoritative ownership ledger, not a UI list. It must represent immutable item types, unique or stacked runtime instances, nested containers, equipment slots, world pickups, ability/effect grants, transfers, consumption, crafting/trading hooks, persistence, replication, and retry-safe transactions.

**Sourced industry pattern.** Unreal's Lyra sample separates shared item definitions, runtime inventory item instances, inventory fragments, pickup definitions, equipment definitions, and transient equipment instances. It distinguishes possession from equipment and lets equipment grant abilities. Lyra's interaction system exposes options/affordances from an interactable target and executes the selected option through an ability. Microsoft PlayFab Economy documents atomic inventory-operation batches, idempotency keys, transaction history, stack IDs, and ETag-based optimistic concurrency.

**Engineering recommendation.** Implement an engine-owned server-authoritative item ledger using immutable definitions plus compact runtime instances. Every mutation—pickup, transfer, split, merge, equip, consume, reload, drop, craft, reward, trade, or destroy—must be expressed as a validated transaction with a stable operation identity and atomic commit.

## Industry-Standard API or Pattern

### 1. Immutable definition versus runtime instance

`ItemDefinition` is immutable, versioned content:

- stable definition ID and content version;
- category and gameplay tags;
- stack policy and maximum stack size;
- mass, volume, durability/ammo schema, binding/trade/drop rules;
- compatible container/equipment slots;
- granted abilities/effects and presentation references;
- typed feature fragments such as consumable, equippable, weapon, quest, key, currency, crafting ingredient, or container.

`ItemInstance` is authoritative runtime state:

- stable instance ID and generation;
- definition/version ID;
- owner/container and slot;
- quantity;
- condition/durability, charges, ammo, rolled affixes, binding state;
- custom property blob constrained by the definition schema;
- instance revision;
- provenance/audit handle.

Stackable fungible items may use one instance with quantity. Items with distinct durability, affixes, ownership restrictions, attachments, or quest identity remain separate instances. Stack identity is an explicit normalized key derived from the definition and stack-compatible properties; display name is never used.

### 2. Containers and slots

Model all inventories as containers:

- player backpack;
- quick bar;
- equipment loadout;
- weapon magazine/chamber;
- chest/vendor/crafting station;
- world pickup bundle;
- mail/reward escrow;
- trade offer or transaction escrow.

A `ContainerDefinition` declares capacity, slot kinds, item/tag filters, weight/volume limits, nesting policy, visibility/replication policy, and ordering. Runtime `ContainerState` stores stable slot entries and a monotonically increasing revision.

Prevent cycles by rejecting any transfer that places a container inside itself or its descendants. Bound nesting depth and perform ancestry checks using cached parent/depth data. Do not represent equipped items by duplicating them into a separate ownership inventory.

### 3. Atomic transaction command

All mutations use:

`InventoryTransactionRequest { operationId, requester, expectedRevisions, orderedOperations, context, tick }`

Supported primitive operations:

- create/grant;
- destroy/consume;
- move between containers/slots;
- split stack;
- merge stacks;
- change quantity/property;
- equip/unequip;
- reserve/release;
- exchange multiple items/currencies;
- create or consume a world pickup.

Commit pipeline:

1. authenticate requester and derive authority/owner from server session;
2. deduplicate by `operationId`;
3. resolve every referenced instance/container generation;
4. sort/lock or serialize touched containers in stable ID order;
5. compare expected revisions;
6. validate ownership, capacity, filters, stack rules, nesting, item state, interaction proof, costs, and gameplay restrictions;
7. stage all deltas in a transaction-local buffer;
8. validate post-state invariants;
9. atomically commit all deltas and increment revisions;
10. append an audit record and reliable result;
11. publish gameplay/presentation events after commit.

If any operation fails, none commit. PlayFab's `ExecuteInventoryOperations` provides a current industry example of atomic multi-operation inventory writes. Its idempotency support demonstrates why retry identity is separate from concurrency revision.

### 4. Idempotency and optimistic concurrency

Use two distinct mechanisms:

- **Idempotency key:** the same logical request retried after loss/timeouts returns its original outcome without applying again.
- **Expected revision:** a write succeeds only if touched containers/items still match the state on which the command was based.

Never generate a new operation ID for a retry. A duplicate ID with a different canonical request hash is a protocol violation. Retain outcomes long enough to cover reconnects/retries; persistence services may require a longer retention policy.

On a revision conflict, return current relevant revisions and a typed failure. The client refreshes or resubmits a new logical command after user confirmation where needed. Do not silently replay a stale trade, purchase, or destructive operation against new state.

### 5. Equipment as a derived active state

Inventory ownership persists independently of which pawn/avatar is currently controlled. Equipment binds an owned item instance to a compatible loadout slot and materializes its active grants:

- ability/effect grant handles;
- attribute modifiers;
- input/action bindings;
- weapon/runtime state view;
- attachment/presentation descriptors;
- animation/camera intent;
- active gameplay tags.

Equip flow:

1. validate ownership, slot compatibility, life/movement/action state, locks, and revision;
2. atomically move/bind the item to the equipment slot;
3. create an `EquipmentActivation` record tied to the item instance;
4. grant abilities/effects and store every returned handle;
5. publish authoritative `Equipped`;
6. let presentation spawn meshes/attachments from the committed state.

Unequip/cancel removes exactly the grants recorded by that activation, releases reservations, and returns/moves the item atomically. Presentation object lifetime never determines ownership.

### 6. Interaction and pickup affordances

Separate focus discovery from execution:

- a query identifies nearby/aimed interactable candidates;
- candidates expose typed options with requirements, priority, hold duration, and action definition;
- UI displays the best valid options;
- the client requests one option;
- the server re-resolves target generation and revalidates distance, visibility/occlusion policy, ownership, tags, cooldown, claim, and inventory capacity;
- the authoritative ability/transaction executes.

Lyra's documented interaction architecture separates `InteractableTarget`, `InteractionOption`, and `InteractionInstigator` and treats collection as one interaction ability.

A world pickup is an authoritative container or item-bundle handle plus world transform/collision and reservation state. Picking up transfers from the world container to the destination inventory atomically. Dropping performs the inverse: reserve inventory quantity, find a valid spawn location, create/publish the world entity, then commit the ownership transfer. If world spawn cannot be guaranteed, the item remains owned.

### 7. Reservation and escrow

Long interactions—crafting, trading, timed pickups, reload stages, repair—reserve quantities or instances before completion:

- reservation ID, owner, reason, quantity, creation/expiry tick;
- reserved quantity is unavailable to unrelated transactions;
- commit consumes/moves it;
- cancel/timeout releases it;
- disconnect/despawn recovery is explicit.

Player-to-player trade uses escrow or a single cross-owner transaction. Never implement trade as two unrelated transfers; that creates duplication/loss windows.

### 8. Replication and persistence boundary

The server replicates inventory state by stable entry IDs and revisions using acknowledged deltas, not index-based array semantics. Unreal's Fast Array facilities are an engine example of delta replication for item collections.

Visibility policies:

- owner receives detailed private inventory;
- nearby players receive equipped/public summary;
- world pickup observers receive public bundle/presentation data;
- server services receive persistence/audit state;
- clients never receive hidden affixes, quest flags, anti-cheat fields, or other players' private contents unless required.

Persistence consumes committed transaction records or versioned snapshots plus a journal tail. Gameplay never waits synchronously on a remote database during the fixed tick. Durable-economy modes use an outbox/commit acknowledgement policy so crashes cannot duplicate rewards.

## Performance Considerations

### Complexity

Let `I` be entries in a container, `T` touched entries, `D` nesting depth, and `C` candidate interactables.

- Instance lookup is **O(1)** average via stable-ID map.
- Slot lookup is **O(1)** for fixed slots/dense arrays; ordered list insertion/removal may be O(I).
- Stack merge candidate lookup is **O(1)** average using `(container, stackKey)`, rather than O(I) scanning.
- Transaction validation/commit is **O(T + D)** plus rule-query work; it must not scan every owned item.
- Cycle validation is O(D) with bounded depth; cached ancestor/root metadata can make common rejection nearly O(1).
- Interaction broad phase is approximately **O(1 + C)** average with a spatial index; narrow traces evaluate a capped candidate set.
- Replication is **O(changed entries)** using dirty/revision lists, not O(total inventory) per snapshot.

### Memory allocation and GC

- Definitions and validation programs are immutable blobs.
- Use pooled item/container records, dense slot arrays, stable handle tables, small inline transaction operation buffers, and per-worker/connection arenas.
- Maintain bounded idempotency-result caches and audit queues with explicit persistence/backpressure.
- Avoid per-item objects, strings, dictionaries, delegates, and reflection in the fixed-tick path.
- Custom properties use schema-defined fixed/pooled fields; arbitrary JSON belongs only at service/tool boundaries.
- No general heap/GC allocation after warm-up for local inventory operations, equip changes, pickup validation, or replication delta generation.

### Cache behavior and concurrency

- Separate hot ownership/quantity/revision fields from cold display/provenance metadata.
- Group entries by container and keep fixed equipment/quick-bar slots dense.
- Route all transactions touching one container shard to a single writer or acquire touched shards in stable order.
- Validate pure rules in parallel, but commit cross-container mutations at a deterministic phase boundary.
- Publish read-only deltas/events after commit so UI, abilities, persistence, and telemetry cannot observe half-applied state.
- Server service/database completion returns through an inbox and is applied at a safe boundary.

### Fixed-step cost

- Local session transactions are bounded commands processed at fixed-tick boundaries.
- Do not poll inventories. UI and gameplay consumers subscribe to committed revisions/deltas.
- Cap operations per transaction, touched containers, custom-property bytes, pending reservations, requests per connection/tick, and delta entries per snapshot.
- Queue low-priority sorting/organization operations; prioritize combat-critical consume/reload/equip commands.
- Expire reservations with a timing wheel or ordered tick queue rather than scanning all reservations each tick.

### GPU batching implications

Inventory data never owns render objects. Equipment and pickup presentation consume immutable descriptors and committed public state. Stable equipment/pickup presentation keys allow renderer-side instancing and batching. UI thumbnails and meshes are streamed asynchronously; missing presentation assets cannot invalidate authoritative ownership. Equip/unequip publishes history-reset flags where pose or attachment discontinuities require them.

## Pros and Cons

### Transactional definition/instance/container architecture

**Pros**

- Prevents partial trades, duplicate pickups, double consumption, and retry duplication.
- Separates persistent ownership from transient equipped/world presentation.
- Supports stacking, unique items, nesting, equipment, crafting, vendors, and service persistence through one mutation path.
- Stable revisions and audit records simplify replication, reconciliation, customer support, and fraud investigation.
- Immutable definitions are cache-friendly and safe for parallel rule validation.

**Cons**

- Requires IDs, revisions, operation logs, conflict handling, and migration tooling.
- Atomic cross-owner operations need careful shard/lock/escrow design.
- Generic fragments can become an unbounded scripting system without schemas.
- UI must handle pending, rejected, refreshed, and conflicting transactions.

### Direct component/list mutation

**Pros**

- Simple for prototypes and strictly local single-player games.

**Cons**

- Allows observers to see partial state.
- Retries and concurrent requests cause duplication or item loss.
- Equipment, persistence, replication, trade, and audit logic diverge.

**Recommendation:** even offline play should use the same transaction command and invariants, with an in-process authoritative ledger. This keeps save/load and later co-op support viable.

## ECS Architectural Integration

### Components/resources

- `InventoryOwner`: root container handle and authority/persistence identity.
- `ContainerState`: definition, owner, revision, capacity summary, parent handle, depth.
- `ContainerEntryBuffer`: stable slot ID, item instance handle, quantity view/order metadata.
- `ItemInstanceState`: definition/version, instance ID/generation, quantity, revision, stack key, compact mutable properties.
- `EquipmentLoadout`: dense slot-to-activation/item handles.
- `EquipmentActivation`: source item, definition, ability/effect/input/attachment grant handles, activation generation.
- `InteractionSensor`: query profile, focus result, last query tick.
- `Interactable`: definition/options handle, generation, availability tags.
- `WorldPickup`: contained item/bundle handle, reservation, respawn/despawn policy.
- `ReservationState`: operation/user/reason/quantity/expiry.
- World resources: item-definition registry, stable handle tables, container ownership graph, stack index, transaction inbox, idempotency cache, audit journal, persistence outbox.

Definitions and UI/presentation metadata are assets/resources, not duplicated into every ECS entity.

### Ordered systems

1. Receive authenticated inventory/interaction commands.
2. Deduplicate and enforce connection/request budgets.
3. Resolve handles/generations and group transactions by touched container shards.
4. Validate expected revisions, ownership, gameplay tags, ranges, capacity, filters, reservations, and invariants.
5. Stage and atomically commit item/container/equipment/world-pickup deltas.
6. Apply/remove ability, effect, attribute, input, and equipment activation grants.
7. Finalize world pickup spawn/despawn and interaction claims.
8. Append audit record and persistence outbox entry.
9. Publish reliable transaction result and owner/public replication deltas.
10. Notify UI, animation, audio, telemetry, and save/checkpoint systems.

The UI cannot directly edit inventory buffers. Animation notifies cannot consume ammo or complete a pickup; they request/confirm through the authoritative ability transaction timeline.

## Component/System/Event Interfaces

### Commands

- `InventoryTransactionRequest { operationId, requester, expectedRevisions[], operations[], context, tick }`
- `MoveItem { item, fromContainer, toContainer, targetSlot, quantity }`
- `EquipItem { item, loadout, equipmentSlot }`
- `ConsumeItem { item, quantity, abilityActivationId }`
- `InteractionRequest { commandId, instigator, target, targetGeneration, optionId, predictionKey }`
- `PickupRequest { commandId, instigator, pickup, pickupGeneration, destinationContainer }`

### Results/events

- `TransactionResult { operationId, committed/rejected/duplicate, reason, newRevisions, auditId }`
- `ItemCreated/Destroyed/Moved/QuantityChanged/PropertyChanged`
- `EquipmentActivated/Deactivated`
- `ReservationCreated/Released/Expired`
- `InteractionStarted/Interrupted/Completed`
- `WorldPickupCreated/Claimed/Consumed/Respawned`

### Read models

- `InventoryOwnerDelta`: private detailed changes for the owner.
- `EquipmentPublicState`: visible equipped definition/cosmetic/action summary.
- `PickupPublicState`: world representation, availability, public stack summary.
- `InventoryViewSnapshot`: immutable revision-tagged UI projection; never the write model.

## Integration Plan

1. **Freeze identity and invariants.** Define item/container/slot/operation IDs, generations, revisions, numeric bounds, nesting depth, capacity rules, stack normalization, and ownership authority.
2. **Build immutable content schemas.** Compile definitions/fragments, validate references and compatible slots, version property layouts, and produce migration maps.
3. **Implement the in-memory ledger.** Stable handle tables, containers, entries, stack indices, item instances, revisions, invariant checker, and deterministic serialization.
4. **Implement the transaction engine.** Canonical request hashes, idempotency cache, expected revisions, staged deltas, atomic commit, typed failures, and audit journal.
5. **Add replication views.** Owner-private inventory deltas, public equipment/pickup state, full baseline/resync, interest filtering, and reliable result correlation.
6. **Integrate equipment with abilities.** Store exact grant handles, handle pawn/avatar changes, cancellation, death, respawn, loadout switching, and presentation lifecycle.
7. **Integrate interaction/pickups.** Candidate discovery plus server revalidation, claims, timed actions, destination selection, drop spawn validation, and accessibility-oriented focus/hold policies.
8. **Add reservations and cross-container workflows.** Reload, craft, trade escrow, vendor purchase, loot distribution, and disconnect recovery.
9. **Connect persistence.** Versioned snapshots, transaction journal/outbox, idempotent remote writes, optimistic concurrency, crash recovery, and schema migration.
10. **Add tooling.** Live ownership graph, transaction trace, revision/conflict inspector, item provenance, stuck reservation detector, audit search, and content-lint dashboards.

## Verification Strategy

### Invariants and property tests

- Quantity never becomes negative or exceeds numeric/definition limits.
- An instance has exactly one owning container/location unless explicitly escrowed.
- Container graph is acyclic and within maximum depth.
- Equipment activation always references an owned compatible item.
- Every recorded ability/effect grant is removed exactly once.
- Reserved plus available quantity equals total quantity.
- Split/merge preserves total quantity and compatible properties.
- Failed transactions leave byte-identical authoritative state and revisions.

Generate random valid/invalid transaction sequences and check invariants after every commit/rejection.

### Retry/concurrency

- Duplicate identical operation IDs return the original result without new effects.
- Same operation ID with a changed body is rejected.
- Concurrent pickup, consume, equip, trade, drop, and persistence writes resolve once.
- Stale expected revisions fail without overwriting newer state.
- Packet loss, duplication, reordering, disconnect/reconnect, server crash before/after journal/outbox commit, and delayed service acknowledgement.

### Gameplay integration

- Pickup contested by players/NPCs; only one ownership transfer commits.
- Full inventory, partial stack fit, alternate destination, auto-merge, and no-fit cases.
- Equip during attack, traversal, death, pawn swap, stun, and network correction.
- Ammo consume/reload reservations across interruption and rollback.
- Drop on invalid geometry, streaming boundary, moving platform, and entity spawn failure.
- First-/third-person switching does not change interaction eligibility or item ownership.
- UI/presentation/assets may be absent or delayed without affecting authoritative results.

### Security

- Forged item/container/owner IDs, stale generations, hidden inventory reads, out-of-range pickup, through-wall interaction, quantity overflow, NaN custom fields, nesting bombs, request floods, and replayed purchases.
- Client cannot select transaction result, price, reward, random affix, ownership, or revision.
- Audit correlation can reconstruct source and destination for every valuable-item mutation.

### Performance

- Benchmark 100/1k/10k entries, fixed and nested containers, 10k simultaneous pickups, mass loot grants, trade bursts, and delta resync.
- Require zero general-heap/GC allocation after warm-up for local transactions.
- Track transaction p50/p95/p99, touched entries, contention/retries, stack-index hit rate, audit/outbox backlog, replication bytes, capacity high-water marks, and leaked reservations.

## Risks/Open Decisions

- **Persistence authority:** decide which modes require durable service acknowledgement before exposing valuable rewards, versus local server commit with outbox recovery.
- **Item identity:** define when a stack is fungible and when individual provenance/condition requires unique instances.
- **Container sharding:** cross-player trade and shared chests need deterministic locking, actor-style serialization, or escrow; select after concurrency/load targets.
- **Prediction:** predict UI and reversible equip presentation only. Ownership, consumption, trade, purchases, and world pickup winners remain server-authoritative.
- **Nested containers:** cap depth, total descendants, weight propagation work, and replication visibility.
- **Schema evolution:** item definitions and mutable property layouts need explicit migration, quarantine, and fallback behavior.
- **World drops:** atomicity across ECS spawn and inventory commit needs reservation/two-phase handling or preallocated pickup entities.
- **Monetized economy:** requires stronger audit retention, fraud controls, service security, customer-support tools, and compliance than match-local loot.

## Source Links

1. Epic Games, **Lyra Inventory and Equipment, Unreal Engine 5.8**  
   https://dev.epicgames.com/documentation/en-us/unreal-engine/lyra-inventory-and-equipment-in-unreal-engine
2. Epic Games, **Lyra Interaction System, Unreal Engine 5.8**  
   https://dev.epicgames.com/documentation/unreal-engine/lyra-sample-game-interaction-system-in-unreal-engine
3. Epic Games, **Abilities in Lyra, Unreal Engine 5.8**  
   https://dev.epicgames.com/documentation/unreal-engine/abilities-in-lyra-in-unreal-engine?lang=en-US
4. Epic Games, **FFastArraySerializer, Unreal Engine 5.8 API**  
   https://dev.epicgames.com/documentation/unreal-engine/API/Runtime/NetCore/FFastArraySerializer?lang=en-US
5. Microsoft PlayFab, **Items and Inventory Overview (Economy v2)**  
   https://learn.microsoft.com/en-us/xbox/playfab/economy-monetization/economy-v2/inventory/items-and-inventory-overview
6. Microsoft PlayFab, **Idempotent Transactions and Retry Patterns**  
   https://learn.microsoft.com/en-us/gaming/playfab/economy-monetization/economy-v2/tutorials/idempotent-transactions-and-retries
7. Microsoft PlayFab, **ETags and Concurrency Control**  
   https://learn.microsoft.com/en-us/xbox/playfab/economy-monetization/economy-v2/tutorials/etags-and-concurrency-control
8. Microsoft PlayFab, **Inventory Stacks**  
   https://learn.microsoft.com/en-us/gaming/playfab/economy-monetization/economy-v2/inventory/stacks

## Source/Recommendation Boundary

The item definition/instance/fragment distinction, inventory versus transient equipment representation, equipment-granted abilities, interaction affordance separation, fast-array delta replication concept, atomic inventory batches, idempotency keys, stack IDs, transaction history, and ETag concurrency patterns are sourced from Epic and Microsoft documentation. The generic container graph, exact ECS layout, operation primitives, deterministic commit phases, world-drop two-phase policy, reservation/escrow model, audit/outbox boundary, caps, and verification plan are Operation Mythology engineering recommendations that require validation against its persistence, player-count, economy, and content requirements.
