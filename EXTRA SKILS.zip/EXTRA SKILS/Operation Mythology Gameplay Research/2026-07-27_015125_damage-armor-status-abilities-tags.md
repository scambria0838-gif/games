# Operation Mythology Technical Recommendation Report

**Domain:** Damage, armor, status effects, abilities, cooldowns, and gameplay tags  
**Research timestamp:** 2026-07-27 01:51:25 America/Los_Angeles  
**Scope:** Non-rendering gameplay architecture for a modular, data-oriented ECS supporting first- and third-person play  
**Status:** New baseline recommendation

## Feature Overview

This feature set is the authoritative rules layer that turns validated gameplay intent and contacts into repeatable state transitions. It owns:

- attributes such as health, stamina, poise, shields, and resistances;
- ability grants, activation, phases, costs, cancellation, and cooldowns;
- instantaneous and duration-based effects, including stacking and periodic execution;
- ordered damage mitigation across immunity, resistance, armor, shields, and health;
- hierarchical gameplay labels used for requirements, blocking, cancellation, queries, and event routing;
- deterministic events for animation, UI, audio, networking, telemetry, and replay.

**Sourced industry pattern.** Unreal Engine's Gameplay Ability System (GAS) separates abilities, attributes/attribute sets, gameplay effects, gameplay tags, and cosmetic gameplay cues. Its effect definitions are immutable assets while effect specifications carry runtime data. Effects may be instant, infinite, duration-based, periodic, or stacked. Gameplay abilities provide costs, cooldowns, asynchronous phases, cancellation, replication, and client prediction.

**Engineering recommendation.** Adopt the same conceptual separation, but express runtime state as compact ECS components and fixed-capacity buffers rather than actor-owned object graphs. Build one generic effect pipeline used by weapons, hazards, abilities, consumables, status effects, and environmental damage. Do not create separate damage frameworks for firearms, melee, or magic.

## Industry-Standard API or Pattern

### 1. Immutable definitions and runtime instances

Author immutable, versioned data:

- `AbilityDefinition`: activation policy, required/blocked tags, granted active tags, costs, cooldown effect, phase graph, target policy, and referenced effect definitions.
- `EffectDefinition`: duration policy, period, modifiers, executions, stacking policy, granted/required/blocked tags, immunity queries, cue identifiers, and dispel categories.
- `AttributeSchema`: stable attribute IDs, numeric representation, clamps, replication/persistence policy, and derived-value dependencies.
- `DamageProfile`: damage channels, penetration rules, hit-zone mapping, mitigation order, and reaction thresholds.

At runtime, create only compact handles/specifications:

- `AbilityInstance`: definition ID, owner, activation sequence, phase, start tick, prediction key, targets, and cancellation reason.
- `EffectSpec`: definition ID, source, instigator, target, level, captured parameters, start/end/next-period tick, stack count, and source sequence.

Definitions are never mutated during play. Content hot reload produces a new version; live instances retain the version against which they were created or migrate at an explicit safe point.

### 2. Authoritative activation transaction

Use one ordered activation contract:

1. Receive `AbilityActivationRequest(owner, abilityId, inputSequence, predictionKey, targetData)`.
2. Resolve the granted ability by stable handle and reject stale/revoked handles.
3. Validate authority, alive/control state, required and blocked tags, target legality, range/line-of-sight policy, charges, resources, and cooldown.
4. Reserve or atomically commit costs and cooldown according to the ability's commit policy.
5. Create the ability instance and grant its active-state tags.
6. Execute fixed-tick phases and produce effect/application requests.
7. Complete, cancel, or interrupt; release reservations and active tags on every exit path.

Use explicit `CanActivate`, `Commit`, `Cancel`, and `End` semantics. A failed commit has no authoritative side effects. Multi-resource costs use an all-or-nothing transaction.

### 3. Effect application and stacking

Compile designer-facing tag expressions and formulas into runtime IDs and operation lists during asset build. An application performs:

1. definition/spec validation;
2. target tag and immunity query;
3. stack-key lookup;
4. configured overflow/refresh/extend/replace/independent-instance policy;
5. modifier or execution evaluation;
6. active-effect insertion for non-instant effects;
7. deterministic gameplay event and presentation-cue emission.

Every effect declares its stack identity: by definition, source, instigator, source item, or custom stable key. Never infer stacking from display name. Supported policies should include independent instances, aggregate intensity, refresh duration, extend duration with a cap, replace weaker, and overflow trigger.

### 4. Attribute model and ordered damage transaction

Maintain `base` and `current` values where temporary modifiers require reversible aggregation. Store frequently mutated resources such as current health explicitly; derive or lazily recompute expensive secondary attributes from dirty dependency sets.

Damage enters as immutable `DamageRequest` data and is resolved in one auditable order:

1. validate source, target, tick, hit/contact proof, friendly-fire policy, and duplicate-hit key;
2. evaluate invulnerability, immunity, and damage-channel tags;
3. apply hit-zone and source multipliers;
4. apply penetration and resistance policy;
5. route through ordered defense layers such as barrier, shield, armor, then health;
6. clamp attributes and evaluate poise/stagger/death thresholds;
7. emit a `DamageResolved` record containing every intermediate value;
8. enqueue resulting effects, reactions, assists, death, and cosmetic cues.

The pipeline must define rounding, saturation, negative-damage/healing policy, and modifier ordering. Use integer or fixed-point authoritative quantities where cross-platform bitwise stability is required; otherwise quantify floating-point replay tolerance and preserve deterministic operation order.

### 5. Hierarchical tags with compiled runtime representation

Author tags as names such as `State.Movement.Swimming`, `Damage.Fire`, or `Ability.Attack.Heavy`. Epic documents tags as registered, hierarchical labels and supports all/any/none expression trees.

At build/load time:

- validate tags against one governed dictionary;
- assign stable serialized IDs and dense runtime indices;
- compile hierarchy closure and common queries;
- represent hot tag sets as fixed/dynamic bitsets or sorted dense indices;
- reference tags by ID in saved/networked data, never by runtime bit position;
- support redirects and schema migration for renamed tags.

Tags describe categorical state and eligibility. Numeric values belong in attributes. High-cardinality identities such as item instance IDs must not become tags.

### 6. Gameplay events versus presentation cues

Authoritative events are tick-addressed, reliable within the simulation/replay contract, and may change gameplay. Presentation cues are idempotent, disposable notifications for sound, particles, camera response, and UI. Epic explicitly warns that Gameplay Cues should remain cosmetic because their replication is not reliable.

Every cue carries a stable deduplication identity derived from simulation tick, source entity generation, activation/effect sequence, and cue ordinal. Rollback cancels or supersedes predicted looped cues; one-shot cues use deduplication and local reconciliation.

## Performance Considerations

### Complexity

Let `E` be processed entities, `A` active effects on an affected entity, `Q` clauses in a tag query, `M` scheduled expirations/periodic executions, and `R` requests this tick.

- Dense attribute and tag-bitset checks are normally **O(1)** for single IDs and **O(W)** for a bitset query, where `W` is the number of machine words in the relevant tag domain.
- Naively ticking every active effect is **O(sum A)** every simulation tick and should be avoided.
- A global min-heap schedules expirations/periods in **O(log M)** per insertion/removal and **O(k log M)** for `k` due items.
- A bucketed timing wheel provides approximately **O(1)** insertion and **O(k + b)** due processing for bounded duration ranges, with `b` entries examined in the current bucket.
- Stack lookup is **O(1)** average with a per-entity hash/index map, or **O(A)** in a small inline buffer. Benchmark the crossover; small linear scans are often more cache-efficient below a low fixed threshold.
- Batched request evaluation is **O(R)** plus referenced tag/formula work. Never scan all entities for each damage or effect event.

### Memory allocation and GC

- No general-heap allocation is permitted in the warm fixed-tick path.
- Use immutable definition blobs, pooled/fixed-capacity ability and effect instances, per-worker request/event arenas, and ring buffers for rollback history.
- Keep a small inline active-effect capacity in the entity chunk. Overflow must move to a pool with telemetry, not silently allocate.
- Size buffers from percentiles plus explicit hard limits. Overflow behavior must be deterministic: reject, aggregate, or spill to a bounded global pool.
- Avoid managed callbacks, closures, strings, reflection, and polymorphic object graphs during simulation. Resolve IDs and function/program indices during baking.

### Cache behavior and concurrency

- Store attributes in stable schema-ordered arrays or hot/cold groups. Keep health, stamina, shields, common tag words, and dirty masks hot; move descriptive metadata and rare modifiers cold.
- Partition requests by target chunk/entity so each target's attributes and effects have one writer during resolution.
- Parallelize validation and pure calculation. Merge cross-entity writes through deterministic per-worker command buffers ordered by target, request sequence, and operation ordinal.
- Build derived-attribute dependency graphs at authoring time. Detect cycles; update only dirty dependents.
- Avoid frequently adding/removing tag components because this causes archetype migration. Unity's Entities documentation supports enableable components for frequently toggled state without structural change. For many gameplay tags, an in-component bitset is generally denser than one component type per tag.

### Fixed-step and rollback cost

- Ability, cost, cooldown, effect, and damage state advance on integer simulation ticks. Wall-clock timestamps are presentation-only.
- Represent cooldown and duration endpoints as ticks; compare `currentTick >= endTick`. This avoids per-frame timer objects and supports replay.
- Unity's predicted simulation documentation notes that clients can re-simulate many ticks, with work increasing as latency rises. Therefore, predicted ability logic must be bounded, allocation-free, and free of external side effects.
- Snapshot only authoritative, prediction-relevant fields. Immutable definitions, derived caches, and cosmetic cues need not be copied.
- Instant damage should remain server-authoritative. Predict responsiveness—animation, local resource reservation, targeting feedback, and reversible non-instant effects—but reconcile health-changing results from authority.

### GPU batching implications

The gameplay system does not issue rendering work. It should improve batching indirectly by emitting compact, deduplicated cue records consumed by presentation systems. Do not spawn renderer objects or mutate materials from gameplay jobs. Aggregate repeated status visuals by `(entity, cue family, intensity bucket)` so the renderer can instance/batch them. Gameplay correctness must not depend on a cue being rendered.

## Pros and Cons

### Recommended data-driven effect/ability pipeline

**Pros**

- One auditable rules path across combat, items, hazards, and traversal-related effects.
- Immutable definitions are thread-safe, cacheable, hot-reloadable by version, and cheap to replicate by ID.
- Tick-addressed instances support prediction, rollback, replay, save/load, and deterministic tests.
- Hierarchical tags make feature composition and designer queries scalable.
- Structured resolved-damage records make balancing, telemetry, debugging, and anti-cheat review much easier.

**Cons**

- Requires disciplined schemas, tag governance, content validation, and migration tooling.
- Generalized modifier systems can become opaque if arbitrary callbacks are allowed.
- Runtime query compilation, unbounded tag sets, and object-heavy effect instances can erase the performance benefits.
- Prediction of abilities with target authority, random outcomes, or irreversible instant effects remains complex.

### Per-feature custom logic

**Pros**

- Fast to prototype a small number of mechanics.
- Specialized hot paths can be extremely compact.

**Cons**

- Rules and ordering diverge between weapons, abilities, hazards, and AI.
- Networking, save/load, telemetry, and replay integrations are repeatedly reimplemented.
- Cross-system buffs and immunities require brittle dependencies.

**Recommendation:** use the generic transaction/effect framework for orchestration and data, with registered pure execution kernels for truly specialized math. Kernels receive immutable inputs and emit bounded operations; they do not mutate arbitrary ECS state.

## ECS Architectural Integration

### Components

- `AttributeState`: schema handle, hot base/current values, dirty mask, version.
- `GameplayTagState`: explicit tags, counted granted tags, cached hierarchy/query words, version.
- `AbilityGrantBuffer`: ability definition handle, grant source, level, stable grant handle.
- `ActiveAbilityBuffer`: activation sequence, phase, start tick, prediction key, target handle, cancellation state.
- `ActiveEffectBuffer`: effect handle/spec fields, source, stack key/count, start/end/period ticks.
- `DefenseState`: shield/barrier/armor pools, resistance profile, poise, guard state.
- `LifeState`: alive/downed/dead state and transition tick.
- `PredictionState`: acknowledged command/activation sequence and rollback metadata.
- `DamageInbox`, `EffectInbox`, `AbilityRequestBuffer`: bounded transient input buffers.

Definitions live in immutable registries/blob assets, not duplicated per entity.

### Ordered fixed-tick systems

1. **Command ingest:** translate semantic input/AI decisions into activation requests.
2. **Tag cache update:** apply prior structural/tag grants and rebuild only dirty query caches.
3. **Ability validation:** resolve grants, tags, costs, cooldowns, targets, and authority.
4. **Ability commit:** atomically reserve/spend resources and create cooldown/effect operations.
5. **Ability phase execution:** advance active instances and emit bounded effect/damage requests.
6. **Effect scheduling:** process due expiration and periodic entries.
7. **Effect application:** resolve immunity, stacking, modifiers, grants, dispels, and removals.
8. **Damage resolution:** partition by target and run the ordered defense transaction.
9. **Attribute derivation/clamp:** recompute dirty dependents and enforce invariants.
10. **Life/reaction transitions:** resolve stagger, downed, death, cancellation, and cleanup.
11. **Deterministic event merge:** stable-sort/merge per-worker results.
12. **Snapshot/hash/publication:** capture prediction/replay state and publish read-only presentation events.

No presentation, audio, animation, or UI system may write authoritative health, tags, ability phase, or effect lifetime.

## Component/System/Event Interfaces

### Requests

- `AbilityActivationRequest { tick, requester, owner, abilityGrantHandle, inputSequence, predictionKey, targetDataHandle }`
- `AbilityCancelRequest { tick, owner, activationSequence, reason }`
- `EffectApplicationRequest { tick, source, instigator, target, effectDefinition, level, magnitudeParams, predictionKey, requestSequence }`
- `DamageRequest { tick, source, instigator, target, contactProof, hitZone, damageProfile, channelMagnitudes, penetration, requestSequence }`

### Authoritative results

- `AbilityActivationResult { activationSequence, accepted, rejectReason, commitTick }`
- `EffectApplied/StackChanged/EffectRemoved`
- `AttributeChanged { attributeId, oldValue, newValue, cause }`
- `DamageResolved { requestId, rawChannels, mitigatedChannels, absorbedByLayer, healthDelta, flags }`
- `LifeStateChanged`, `AbilityCancelled`, `CooldownChanged`

### Presentation/telemetry events

- `GameplayCue { cueId, source, target, tick, eventIdentity, normalizedMagnitude, phase }`
- `CombatLogRecord` and `RuleTraceRecord` use the same stable request/effect/activation IDs.
- Presentation consumers may drop or coalesce cues. Authoritative consumers may not.

## Integration Plan

1. **Freeze identifiers and numeric rules.** Define stable IDs, tick rate, numeric representation, rounding, overflow, damage-channel taxonomy, tag dictionary ownership, and save/network migration policy.
2. **Build content schemas and compiler.** Validate definitions, tag references, formula dependencies, stack policies, bounded capacities, and cycles. Emit immutable runtime blobs and source maps for diagnostics.
3. **Implement attributes and tags first.** Add counted tag grants so removing one source does not remove a tag still granted elsewhere. Add dirty dependency evaluation and deterministic tag-query tests.
4. **Implement effect lifetime/stacking.** Start with instant, duration, infinite, periodic, refresh, independent, and intensity-stack policies. Add timing-wheel or heap scheduling and explicit overflow.
5. **Implement damage as an effect execution.** Produce complete `DamageResolved` traces and keep hit detection/contact proof outside the damage math.
6. **Add abilities and transactional commit.** Integrate semantic input, AI commands, animation action requests, movement modes, inventory grants, costs, and cooldown-as-effect/tag.
7. **Add network prediction boundaries.** Predict only allowlisted phases and reversible state. Carry prediction keys, reconcile accepted instances, cancel rejected work, and deduplicate cues.
8. **Integrate persistence/replay.** Serialize definition version, stable IDs, base/current attributes, active effect timing/stack/source data, granted abilities, and authoritative tick.
9. **Add tooling.** Provide tag browser, live attribute/effect inspector, ability timeline, damage-layer trace, event correlation IDs, capacity telemetry, and deterministic state hashes.
10. **Scale and harden.** Benchmark crowds, burst damage, status storms, rollback depth, dispel cascades, and pathological content before raising capacities.

## Verification Strategy

### Unit and property tests

- All/any/none hierarchical tag queries, counted grants, redirects, and serialization.
- Attribute modifier ordering, clamps, rounding, saturation, dependency cycles, and removal reversibility.
- Every stack policy across same/different sources, overflow, refresh, extension caps, dispel, immunity, death, and source destruction.
- Damage conservation: raw damage equals mitigated/absorbed/health-applied plus explicitly discarded remainder.
- Atomic costs: no partial spend on rejected activation.
- Cooldown boundaries at exactly start/end ticks.
- Fuzz effect graphs, formulas, values, tags, and application order; reject NaN/infinity and capacity violations.

### Determinism and networking

- Re-run identical command streams across thread counts and shuffled job completion; compare per-tick state hashes and resolved event order.
- Roll back at every ability phase, effect application, periodic tick, damage/death boundary, and source/target destruction.
- Inject rejection, packet loss, duplication, reordering, latency, and jitter; ensure no double damage, double cost, leaked active tags, or duplicate cues.
- Validate join-in-progress and save/load during active periodic effects and cooldowns.
- Compare server authoritative results with client prediction while varying rollback depth.

### Performance

- Measure 1, 16, 64, and 256 active effects per entity; identify inline-buffer crossover.
- Benchmark 1k/10k/100k effect expirations distributed and synchronized on one tick.
- Stress burst AoE, chain reactions, mass dispels, death cascades, and 10k AI ability checks.
- Require zero general-heap/GC allocations after warm-up.
- Track fixed-tick p50/p95/p99, rollback amplification, cache misses, job imbalance, buffer high-water marks, and rejected overflow.

### Integration

- FP/TP camera switching cannot change damage, costs, cooldowns, or targeting legality.
- Animation cancellation and interrupted montages cannot leave ability-active tags or reservations.
- Inventory equip/unequip grants and revokes abilities without invalid handles.
- Streaming/despawn releases effects, abilities, cues, and cross-entity references deterministically.
- Cosmetic cues may be dropped entirely without changing state hashes.

## Risks/Open Decisions

- **Numeric determinism:** select fixed-point/integer quantities or define a supported CPU/platform floating-point contract before networking implementation.
- **Modifier algebra:** specify additive/multiplicative/override ordering, snapshot versus live capture, and rounding centrally.
- **Prediction allowlist:** instant health damage, randomized results, server-owned targets, and hidden-information checks should not be locally authoritative.
- **Capacity policy:** establish hard per-entity ability/effect/tag/request limits and deterministic overflow behavior.
- **Tag governance:** assign namespaces, ownership, redirects, linting, and compatibility rules; uncontrolled tags become an implicit global dependency graph.
- **Effect scheduling:** choose timing wheel for known bounded horizons or heap/hybrid for arbitrary durations after workload benchmarks.
- **Death model:** decide alive/downed/dead transitions, post-mortem damage, corpse ownership, effect cleanup, revive, and kill credit before content proliferation.
- **Save migration:** runtime bit indices cannot be serialized; persistent data must use stable IDs and definition versions.

## Source Links

### Primary official documentation

1. Epic Games, **Gameplay Ability System for Unreal Engine 5.8**  
   https://dev.epicgames.com/documentation/unreal-engine/gameplay-ability-system-for-unreal-engine?lang=en-US
2. Epic Games, **Understanding the Unreal Engine Gameplay Ability System 5.8**  
   https://dev.epicgames.com/documentation/en-us/unreal-engine/understanding-the-unreal-engine-gameplay-ability-system
3. Epic Games, **Gameplay Attributes and Attribute Sets 5.8**  
   https://dev.epicgames.com/documentation/en-us/unreal-engine/gameplay-attributes-and-attribute-sets-for-the-gameplay-ability-system-in-unreal-engine
4. Epic Games, **Gameplay Effects**  
   https://dev.epicgames.com/documentation/unreal-engine/gameplay-effects-for-the-gameplay-ability-system-in-unreal-engine?lang=en-US
5. Epic Games, **Using Gameplay Abilities 5.8**  
   https://dev.epicgames.com/documentation/unreal-engine/using-gameplay-abilities-in-unreal-engine?lang=en-US
6. Epic Games, **Using Gameplay Tags 5.8**  
   https://dev.epicgames.com/documentation/unreal-engine/using-gameplay-tags-in-unreal-engine
7. Unity, **Entities: Enableable components**  
   https://docs.unity.cn/Packages/com.unity.entities%401.3/manual/components-enableable-use.html
8. Unity, **Entities: FixedStepSimulationSystemGroup**  
   https://docs.unity.cn/Packages/com.unity.entities%401.0/api/Unity.Entities.FixedStepSimulationSystemGroup.html
9. Unity, **Netcode for Entities: PredictedSimulationSystemGroup**  
   https://docs.unity.cn/Packages/com.unity.netcode%401.4/api/Unity.NetCode.PredictedSimulationSystemGroup.html

## Source/Recommendation Boundary

The GAS feature boundaries, immutable gameplay-effect/runtime-spec distinction, base/current attributes, effect lifetimes and stacking, hierarchical tag queries, ability prediction support, and cosmetic-only cue warning are sourced from Epic's documentation. The ECS layout, damage ordering, timing-wheel/heap choice, fixed capacities, tag bitsets, deterministic merge order, prediction allowlist, transaction records, and phased integration plan are engineering recommendations synthesized for Operation Mythology and must be validated against its target platforms, content scale, and network model.
