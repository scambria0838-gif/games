# Operation Mythology Technical Recommendation Report

**Domain:** Authoritative networking, command streams, client prediction, reconciliation, server rewind, lag compensation, and anti-cheat boundaries  
**Research timestamp:** 2026-07-27 02:00:00 America/Los_Angeles  
**Scope:** Non-rendering gameplay architecture for a modular, data-oriented ECS supporting first- and third-person play  
**Status:** New baseline recommendation

## Feature Overview

Fast online action games normally present three related timelines:

- the authoritative server's current fixed simulation tick;
- the owning client's predicted timeline, advanced immediately from local commands;
- a delayed interpolated timeline used to present remote entities smoothly.

**Sourced fact.** Unreal Engine documents a server-authoritative model in which the server owns the true gameplay state. Unity Netcode for Entities documents client prediction as running shared fixed-step simulation from local input, then restoring authoritative snapshots and re-simulating commands. Unity separately identifies predicted and interpolated client timelines. Valve documents server-side lag compensation as reconstructing the world the attacker saw when the command was created.

**Engineering recommendation.** Use a dedicated authoritative server, tick-addressed semantic command streams, owner prediction for the local controllable character, buffered snapshot interpolation for most remote entities, and bounded server rewind only for explicitly eligible combat queries. Never grant a client authority over position, damage, targets, cooldowns, inventory, or rewind time.

## Industry-Standard API or Pattern

### 1. Server-authoritative fixed-tick simulation

The server receives input commands, validates them, runs gameplay exactly once per simulation tick, and publishes interest-filtered snapshots and reliable events. A client submits intent, never resulting state.

Each command frame contains:

- connection/session identity from the authenticated transport, not from client payload;
- monotonically increasing command sequence;
- target server simulation tick;
- compact semantic actions and quantized view/aim;
- acknowledgement of the newest server snapshot processed;
- optional redundancy for recent unacknowledged inputs;
- integrity/schema version fields.

Commands are idempotent by `(connection, sequence)`. The server rejects duplicates, commands outside an admissible tick window, invalid values, illegal action combinations, and rates exceeding configured budgets.

### 2. Owner prediction and reconciliation

Use the same bounded gameplay kernels for server authority and client prediction:

1. Sample local actions into a tick-addressed command.
2. Store the command in a fixed-size history ring and simulate immediately.
3. Receive an authoritative snapshot for tick `T`.
4. Restore prediction-relevant authoritative state at `T`.
5. Reapply unacknowledged commands `T+1 ... currentPredictedTick`.
6. Publish the corrected simulation pose.
7. Smooth only the presentation error; never feed smoothing into authoritative or predicted state.

Unity documents that prediction rollback can require many simulation iterations in one rendered frame; its example estimates roughly 22 re-simulated ticks at 300 ms latency. Prediction membership must therefore be narrow and its hot path allocation-free.

Use owner prediction by default. Remote player characters normally interpolate server snapshots. Predict remote entities only when replicated inputs and interaction requirements justify the CPU and correction risk.

### 3. Snapshot interpolation

Buffer remote snapshots behind estimated server time by an adaptive delay based on snapshot interval, jitter, and loss. Interpolate between two known snapshots. Use capped extrapolation only when a destination snapshot is missing, then reconcile when data resumes.

Keep visual interpolation distinct from gameplay prediction:

- interpolation intentionally displays remote state in the recent past;
- prediction estimates the owning entity's present from known local commands;
- the server has one authoritative present.

Snapshot fields are schema-versioned, quantized, delta-compressed against acknowledged baselines, and filtered by connection relevance. Reliable state changes must not depend solely on an unreliable snapshot appearing once.

### 4. Server rewind for combat queries

Maintain a server-only history ring for rewindable query state, not a complete cloned world. For each authoritative tick store:

- entity generation and rewind eligibility;
- collision proxy transform and shape/version;
- hitbox bone/proxy transforms required by the weapon rules;
- stance and gameplay flags affecting vulnerability;
- world-partition/collision generation needed to reject stale geometry;
- optional moving-platform/local-space basis.

When processing a shot or melee query:

1. Validate the command sequence, weapon state, ammo/cost, fire cadence, player life/control state, and aim data.
2. Derive the evaluation tick from server-maintained clock/tick synchronization plus the client's reported interpolation delay.
3. Clamp it to a weapon- and playlist-specific maximum rewind window.
4. Reject future, stale, discontinuous, or implausible timestamps.
5. Reconstruct only relevant target query proxies in an isolated historical query scene or immutable history view.
6. Perform the authoritative ray, shape cast, or bounded swept-volume test.
7. Validate current-world shooter/muzzle obstruction and other non-rewindable rules according to weapon policy.
8. Apply damage in the current authoritative timeline using an idempotent hit identity.
9. Record evaluated tick, clamp reason, proxy versions, result, and latency evidence.

Do not mutate the live physics world backward and forward. An isolated rewind query representation avoids job hazards, transient contacts, broad-phase corruption, and interactions with unrelated simulations.

### 5. Weapon-specific fairness policy

Lag compensation is a game-design tradeoff, not a universal physics rule.

- Hitscan: rewind target hurtboxes; validate fire origin and current muzzle obstruction; cap distance/time.
- Fast projectile: validate spawn at the eligible historical tick, then simulate an authoritative projectile forward with bounded catch-up.
- Slow projectile: usually no target rewind after spawn; clients predict visuals while server owns trajectory and impact.
- Melee: use a short, bounded swept attack volume with historical attacker/target query proxies; never accept client-selected victims.
- Area effects: validate origin/activation historically if required, but apply present-time target membership unless design explicitly specifies otherwise.

The defender can be hit after moving behind cover because the attacker saw an older state. Limit this paradox through a modest rewind cap, clear network-quality policy, region/QoS matchmaking, and weapon-specific rules.

### 6. Anti-cheat trust boundary

Treat every client-controlled field as untrusted. The server derives or validates:

- movement from commands against collision, acceleration, speed, movement-mode, and stamina rules;
- view rotation deltas and fire cadence against rate and mechanical limits;
- ability ownership, resource costs, cooldowns, tags, target eligibility, and random outcomes;
- inventory/equipment state, projectile spawn, damage, death, rewards, and persistence;
- rewind tick from server observations, never an arbitrary client timestamp;
- numeric finiteness, ranges, enums, entity generations, ownership, and interest visibility.

Avoid impossible-state heuristics as the primary authority model. Simulation validation prevents invalid results; telemetry/risk scoring detects manipulation. Enforcement should combine rule evidence over time and permit review/appeal rather than banning on one ambiguous desync.

## Performance Considerations

### Complexity

Let `C` be commands processed, `P` predicted entities, `K` re-simulated ticks, `S` relevant snapshot entities, `H` rewind history ticks, and `Q` rewind candidates.

- Server command ingest/validation is **O(C)** with O(1)-average sequence-window checks.
- Owner reconciliation is **O(K × P × predicted-system-cost)**. This is the dominant client worst case.
- Interest-filtered snapshot construction is **O(S)** after spatial relevance lookup; a global per-connection entity scan is unacceptable.
- Rewind lookup in a tick ring is **O(1)** for exact ticks and O(1) for adjacent-frame interpolation.
- Historical broad-phase query should be approximately **O(log Q + hits)** with a spatial index, or O(Q) in a small already-filtered candidate set.
- Snapshot delta comparison is **O(number of replicated fields for S)** and should use dirty/change versions where correctness permits.

### Memory allocation and layout

- Allocate command, prediction-state, snapshot-baseline, and rewind-history rings up front.
- Store rewind history as structure-of-arrays by tick/chunk or entity slot. Quantize positions/rotations relative to a cell or origin epoch.
- History memory is approximately `rewindableEntities × ticksRetained × bytesPerProxy`; measure it explicitly. At 60 Hz, one second is 60 samples before padding, indices, or multiple hitboxes.
- Keep full rollback state only for predicted components. Do not copy presentation, static definitions, audio, telemetry strings, or renderer state.
- No general heap/GC allocation in send, receive, snapshot apply, predicted simulation, or rewind-query hot paths.

### Cache behavior and concurrency

- Partition command execution by owning entity/chunk after per-connection validation.
- Write history sequentially each tick; readers access immutable completed slots.
- Generate per-worker snapshot fragments and deterministically assemble them by connection/entity/field order.
- Run historical combat queries against read-only snapshots or a dedicated query acceleration structure. Never pause or mutate live physics.
- Component structural changes inside prediction invalidate or enlarge backup work. Prefer stable predicted archetypes, enable masks, and bounded value state.

### Fixed-step cost controls

- Set one simulation tick rate from measured movement, weapon, physics, CPU, and bandwidth requirements; do not equate it automatically with render rate.
- Cap accumulated catch-up ticks and define overload behavior. The server must not silently alter authoritative delta time in a way that changes mechanics.
- Prediction uses fixed full ticks. Optional partial-tick presentation must be discarded before the next full authoritative prediction step.
- Bound `maxRollbackTicks`, `maxCommandsPerPacket`, `maxCommandsProcessedPerServerFrame`, `maxPredictedEntities`, and rewind queries per command.
- Profile p50/p95/p99 re-simulation count under latency, jitter, loss, and partial snapshots.

### GPU batching implications

Networking does not issue GPU work. It publishes stable current/previous presentation snapshots so animation and rendering can interpolate and batch without reading mutable network buffers. Corrections carry teleport/history-invalidation flags. Cosmetic shot, hit, and correction cues are deduplicated by authoritative event identity and may be coalesced without affecting gameplay.

## Pros and Cons

### Server authority with owner prediction and bounded rewind

**Pros**

- Responsive local controls without trusting client-authored results.
- One authoritative outcome for movement, combat, inventory, and progression.
- Tick histories naturally support replays, diagnostics, and lag-compensated queries.
- Interpolated remote entities are stable and far cheaper than predicting the full world.
- Explicit rewind evidence enables fairness telemetry and cheat review.

**Cons**

- Requires serializable prediction state and side-effect-safe re-simulation.
- CPU cost rises with latency and predicted entity count.
- Rewind favors what the attacker saw and can create defender-side cover paradoxes.
- Dedicated servers add hosting, observability, deployment, and regional capacity costs.
- Nondeterministic physics and partial snapshots can produce recurring corrections.

### Client-authoritative state

**Pros**

- Low server simulation cost and immediate local response.

**Cons**

- Permits teleport, fire-rate, inventory, hit, and damage fabrication.
- Requires conflict resolution between clients.
- Poor foundation for competitive combat or persistent progression.

**Recommendation:** do not use client authority for Operation Mythology gameplay. A listen-server mode may be offered for cooperative play, but it cannot provide the same trust or fairness guarantees as dedicated authority and must be labeled/configured separately.

## ECS Architectural Integration

### Components and resources

- `NetworkTickState`: authoritative/predicted/interpolation ticks, fractions, tick rate, origin epoch.
- `ConnectionState`: authenticated connection ID, sequence windows, acknowledgements, RTT/jitter estimates, command-age feedback, budgets.
- `PlayerCommandBuffer`: fixed ring of semantic tick commands.
- `PredictedStateHistory`: component snapshots and state hashes for owner-predicted entities.
- `SnapshotBaselineState`: acknowledged baseline handles and schema version.
- `NetworkIdentity`: stable net entity ID, generation, ownership, replication archetype.
- `ReplicationPolicy`: relevance class, update priority, dormancy, field masks.
- `RewindProxy`: history layout handle and query categories.
- `RewindHistory`: server resource containing immutable completed tick slots.
- `NetworkCorrection`: error vector, correction type, smoothing/reset policy.
- `ViolationEvidence`: bounded counters and correlated rule traces; never client-visible authoritative secrets.

### Ordered systems

1. Transport receive and packet validation.
2. Authentication/session/connection budget enforcement.
3. Command decode, sequence-window validation, and tick mapping.
4. Server command execution or client local command prediction.
5. Fixed-tick gameplay/physics/abilities/damage.
6. Server rewind-history capture after authoritative transforms/hurtboxes finalize.
7. Server historical combat-query evaluation and current-timeline damage commit.
8. Interest/relevance calculation and snapshot/event construction.
9. Client snapshot decode, baseline restore, reconciliation, and re-simulation.
10. Client interpolation buffer update and presentation smoothing.
11. Deterministic event publication, telemetry, and state hashing.

Transport callbacks never mutate gameplay components directly. They append validated records to bounded buffers consumed at a phase boundary.

## Component/System/Event Interfaces

### Commands and snapshots

- `PlayerCommand { tick, sequence, move, look, actionBits, selectedAbility, targetHint, lastSnapshotAck }`
- `AuthoritativeSnapshot { serverTick, baselineTick, schemaVersion, originEpoch, entityDeltas, reliableEventAck }`
- `CommandReceipt { highestContiguousSequence, receivedMask, appliedThroughTick }`
- `CorrectionRecord { entity, authoritativeTick, predictedHash, authoritativeHash, errorClass }`

### Rewind interfaces

- `RewindQueryRequest { commandId, shooter, weaponDefinition, derivedEvaluationTick, rayOrSweep, policy }`
- `HistoricalProxySample { tick, netEntity, generation, shapeSet, transforms, stance, vulnerabilityFlags, worldGeneration }`
- `RewindQueryResult { commandId, evaluatedTick, requestedAge, clampedAge, candidateCount, hits, rejectionReason }`
- `ValidatedHit { eventIdentity, attacker, target, hitZone, authoritativeApplyTick, historicalQueryTick }`

### Lifecycle events

- `PredictedSpawnAccepted/Rejected`
- `OwnershipChanged`
- `EntityBecameRelevant/Irrelevant`
- `HardCorrectionRequired`
- `NetworkQualityTierChanged`
- `CommandRejected`

All events carry stable identities and ticks. Re-simulation checks whether a side effect is first-time execution before emitting external I/O.

## Integration Plan

1. **Choose targets and fairness policy.** Fix server tick rate, snapshot rate, maximum supported RTT/jitter/loss, rewind window, interpolation target, player count, bandwidth budget, and dedicated/listen-server modes.
2. **Define protocol schemas.** Version commands, snapshots, reliable events, entity IDs, origin epochs, quantization, bounds, and compatibility policy. Fuzz decoders before gameplay integration.
3. **Implement network-time synchronization.** Track RTT, jitter, command age, acknowledgements, client prediction tick, and interpolation tick. Visualize all three timelines.
4. **Integrate command-driven locomotion.** Reuse the existing fixed-tick semantic input and character-controller state. Prove server/client replay from the same command buffer.
5. **Add snapshot replication and relevance.** Begin with full baselines, then add acknowledged delta compression, priority scheduling, dormancy, and bounded reliable events.
6. **Add owner reconciliation.** Define the exact prediction component set, history ring, restore order, re-simulation guard, hashes, correction classification, and presentation smoothing.
7. **Integrate abilities and combat.** Prediction keys and idempotent event IDs connect ability activation, projectile spawning, costs, cooldowns, and damage to reconciliation.
8. **Build isolated rewind queries.** Capture minimal collision/hurtbox history; implement weapon-specific policies and full audit records. Never reuse the live mutable scene by rewinding it.
9. **Harden the trust boundary.** Validate every client field, apply rate/budget limits, derive rewind time server-side, detect impossible state, and retain privacy-aware evidence.
10. **Add operational tooling.** Network simulation, timeline graphs, snapshot bit budgets, relevance visualization, correction heatmaps, rewind ghost overlays, rule traces, and per-connection quality tiers.

## Verification Strategy

### Correctness and determinism

- Replay identical commands under 1/2/4/8 worker schedules and compare per-tick authoritative hashes.
- Verify command duplication, loss, reordering, wraparound, reconnect, stale entity generations, and schema mismatch.
- Reconcile at every movement mode, traversal phase, ability phase, projectile spawn, status tick, damage, death, and inventory transition.
- Ensure re-simulation performs no duplicate damage, audio, telemetry, achievements, or external service writes.

### Network impairment matrix

Test at minimum:

- RTT: 0, 30, 60, 120, 200, 300 ms;
- jitter: 0, 10, 30, 60 ms;
- packet loss: 0%, 1%, 3%, 5%, 10%;
- duplication and reordering bursts;
- asymmetric uplink/downlink latency and bandwidth restriction;
- server hitch, client hitch, clock drift, and snapshot starvation.

Track command age, interpolation underruns, re-simulated ticks/frame, correction magnitude/frequency, snapshot bytes, reliable backlog, and server tick deadline misses.

### Rewind validation

- Moving targets, crouch transitions, jumps, traversal, animation hitbox changes, platforms, doors, cover edges, teleports, origin rebasing, and streamed collision.
- Shot exactly at history endpoints and between ticks.
- Attempts to claim future ticks, excessive age, falsified interpolation delay, impossible aim deltas, invalid muzzle origin, duplicate fire sequence, and fire-rate violations.
- Compare live and historical query visualizations to recorded audit results.
- Run subjective fairness sessions across latency asymmetry; tune per-weapon rewind caps rather than one global value.

### Security and robustness

- Fuzz packet, command, snapshot, entity ID, quantization, and numeric fields including NaN/infinity.
- Verify connection-level CPU, memory, bandwidth, RPC, command, spawn, and query budgets.
- Attempt speed, teleport, noclip, cooldown, ammo, inventory, damage, target, timestamp, and replay attacks.
- Ensure malformed or malicious traffic cannot allocate unbounded memory or stall authoritative ticks.

### Performance gates

- Zero general-heap/GC allocation in warm networking/prediction/rewind paths.
- Benchmark maximum players and rewindable proxies with worst supported history.
- Stress synchronized firing and snapshot priority overflow.
- Enforce p99 server tick budget and client prediction budget under 300 ms simulated RTT.
- Validate history memory, cache misses, job imbalance, and snapshot bandwidth per connection.

## Risks/Open Decisions

- **Simulation determinism:** Unity explicitly notes limitations around deterministic prediction; define platform/compiler/numeric scope and rely on authoritative correction rather than assuming bitwise identity.
- **Physics prediction:** broad rigid-body prediction greatly increases state, CPU, and correction complexity. Default to owner character plus tightly scoped gameplay proxies.
- **Rewind fairness:** set maximum age per weapon/playlist and decide how present-day cover/muzzle obstruction interacts with historical targets.
- **Snapshot consistency:** partial snapshots can create cross-entity prediction discrepancies. Identify atomic interaction groups or restore dependencies together where needed.
- **Structural changes:** predicted archetype mutation can invalidate history and cause costly rollback. Prefer stable layouts and enable/value state.
- **Late commands:** define drop, hold, or apply policy and client feedback. Never silently apply arbitrary old commands to the present.
- **Host advantage:** listen servers confer authority and latency advantages. Competitive modes should use dedicated servers.
- **Security telemetry:** formalize retention, privacy, false-positive review, and enforcement policy before collecting player behavioral evidence.

## Source Links

1. Epic Games, **Networking Overview for Unreal Engine 5.8**  
   https://dev.epicgames.com/documentation/unreal-engine/networking-overview-for-unreal-engine?lang=en-US
2. Epic Games, **NetworkPrediction API, Unreal Engine 5.8**  
   https://dev.epicgames.com/documentation/en-us/unreal-engine/API/Plugins/NetworkPrediction
3. Unity, **Netcode for Entities 1.4: Prediction**  
   https://docs.unity.cn/Packages/com.unity.netcode%401.4/manual/prediction.html
4. Unity, **Netcode for Entities: Client prediction sequence**  
   https://docs.unity.cn/Packages/com.unity.netcode%401.3/manual/prediction-high-level-explanation.html
5. Unity, **Netcode for Entities: Prediction edge cases**  
   https://docs.unity.cn/Packages/com.unity.netcode%401.5/manual/prediction-details.html
6. Unity, **Netcode for Entities: Interpolation and timelines**  
   https://docs.unity.cn/Packages/com.unity.netcode%401.5/manual/interpolation.html
7. Unity, **Netcode for Entities: PredictedSimulationSystemGroup**  
   https://docs.unity.cn/Packages/com.unity.netcode%401.4/api/Unity.NetCode.PredictedSimulationSystemGroup.html
8. Unity, **NetworkSnapshotAck API**  
   https://docs.unity.cn/Packages/com.unity.netcode%401.0/api/Unity.NetCode.NetworkSnapshotAck.html
9. Valve, **Lag Compensation**  
   https://developer.valvesoftware.com/wiki/Lag_compensation
10. Yahn W. Bernier / Valve, **Latency Compensating Methods in Client/Server In-game Protocol Design and Optimization**  
    https://developer.valvesoftware.com/wiki/Latency_Compensating_Methods_in_Client/Server_In-game_Protocol_Design_and_Optimization

## Source/Recommendation Boundary

Server authority, shared client/server prediction, snapshot restoration and re-simulation, separate interpolated and predicted timelines, prediction cost amplification, acknowledgement/time synchronization, and the historical basis of server lag compensation are sourced from Epic, Unity, and Valve. The isolated rewind query scene, exact ECS layouts, weapon policy matrix, command limits, audit schema, anti-cheat evidence model, history compression, deterministic merge rules, and staged integration plan are Operation Mythology engineering recommendations requiring measurement against its target platforms, tick rate, player count, and fairness goals.
