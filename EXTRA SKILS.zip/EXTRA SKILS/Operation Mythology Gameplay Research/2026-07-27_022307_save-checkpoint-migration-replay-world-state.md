# Operation Mythology Technical Recommendation Report

**Domain:** Save/load, checkpoints, schema migration, deterministic replay, crash safety, and streamed world-state persistence  
**Research timestamp:** 2026-07-27 02:23:07 America/Los_Angeles  
**Scope:** Non-rendering gameplay architecture for a modular, data-oriented ECS supporting single-player and authoritative multiplayer  
**Status:** New baseline recommendation

## Feature Overview

Persistence and replay solve different problems:

- a **save** preserves selected authoritative gameplay state across sessions;
- a **checkpoint** is a policy-controlled recovery point with enough data to resume safely;
- an **autosave** captures progression without blocking the active frame;
- a **replay** reconstructs a temporal sequence for viewing, debugging, moderation, or deterministic verification;
- a **rollback snapshot** is short-lived prediction/network history and is not a durable save.

**Sourced pattern.** Unreal supports multiple custom save-game classes and recommends asynchronous save/load for larger data to avoid hitches. Its Replay System records replication data through a specialized network driver and reconstructs time from a baseline, periodic checkpoints, and incremental changes. Epic also documents replay version handling. Protocol Buffers and FlatBuffers document stable field identifiers, additive evolution, deprecation/reservation, defaults, and compatibility constraints.

**Engineering recommendation.** Build a versioned persistence service around immutable, tick-consistent ECS snapshots plus a bounded journal tail. Save only authored persistent state using stable identities and schemas. Write asynchronously through crash-safe generations. Use a separate command/snapshot replay format with periodic seek checkpoints and hashes; do not treat raw memory dumps or renderer/network buffers as durable formats.

## Industry-Standard API or Pattern

### 1. Explicit persistence ownership

Every component type declares a persistence policy at schema registration:

- `Never`: transient caches, jobs, physics contacts, renderer/audio state, network buffers;
- `Session`: match/session restore only;
- `Checkpoint`: required for local recovery;
- `Profile`: account/global unlocks and settings;
- `World`: persistent streamed-world deltas;
- `ReplayInput`, `ReplayState`, or `ReplayPresentation`: explicit replay channels.

Persistence is opt-in. Reflection over every runtime object is not a save architecture.

Separate domains:

- platform/user settings;
- profile/meta progression;
- playthrough/campaign;
- current checkpoint;
- per-world-cell deltas;
- match/session;
- replay streams.

Each domain has independent schema/version, slot/generation, conflict policy, size limit, retention, and encryption/authentication requirements.

### 2. Stable identity and content references

Persist:

- stable entity/item/quest/object IDs, never ECS indices or pointers;
- generation/version where stale references must be rejected;
- stable asset/definition IDs, never process-local handles;
- world cell ID plus local transform and origin epoch where appropriate;
- authoritative simulation tick and world/content build identifiers.

Static authored world objects receive deterministic persistent IDs from the build pipeline. Runtime-spawned persistent objects receive durable IDs from the authoritative allocator. Detect duplicate/missing IDs during content build and save validation.

References load in two passes:

1. instantiate/register records and construct old-ID to new-runtime-handle maps;
2. resolve inter-record references, then invoke validated post-load activation.

Missing content uses explicit policies: migrate, substitute, quarantine, skip optional record, or reject the save. Never silently redirect by display name.

### 3. Tick-consistent capture

At a fixed-tick phase boundary:

1. accept a save/checkpoint request and assign `captureId`;
2. finish all authoritative structural commands and transactions for tick `T`;
3. freeze or copy the persistence-visible component versions/root handles;
4. record content/schema/world-generation metadata;
5. immediately release gameplay to tick `T+1`;
6. serialize, compress, checksum, and write on workers;
7. publish success only after durable atomic commit.

Use copy-on-write pages, immutable chunks, or versioned dirty-chunk copies so the simulation does not remain paused during serialization. Epic notes that its async save call can still serialize on the game thread before writing on a worker; a custom engine must explicitly budget snapshot capture/serialization rather than assuming “async” removes all main-thread cost.

### 4. Snapshot plus journal

Use:

- a periodic full or cell-partitioned snapshot;
- an ordered tail of committed persistent transactions/events since that snapshot.

On load, validate the snapshot, migrate it, instantiate state, then replay the journal tail idempotently. Compact only after a replacement snapshot is durably committed.

Journal entries contain stable operation ID, sequence, simulation tick, domain/cell, schema version, canonical payload, and checksum. Inventory operations reuse their transaction/audit IDs. Do not journal high-frequency transforms unless the persistence design requires them.

### 5. Crash-safe generation commit

Never overwrite the only good save in place:

1. write a new temporary generation;
2. flush/close according to platform guarantees;
3. read/verify header, bounds, checksums, and required chunks;
4. atomically publish/rename the generation or update a small manifest pointer;
5. retain at least one previous known-good generation;
6. clean old generations later.

Save header includes magic, container format version, product/build/content version, domain versions, timestamp, platform/user/slot identity, capture tick, endianness, compression/encryption identifiers, chunk directory, sizes, hashes/checksums, and completion marker.

Checksums detect corruption; authenticated encryption protects confidentiality/integrity where needed. Neither makes untrusted local saves authoritative for multiplayer progression.

### 6. Schema evolution and migrations

Use schema-defined records with stable numeric field IDs. Follow additive evolution:

- add optional/defaulted fields;
- never reuse removed field IDs;
- reserve/deprecate removed fields;
- do not reinterpret a field with an incompatible type;
- preserve unknown fields when round-tripping if the selected format supports it;
- version custom packed blobs independently.

Protocol Buffers explicitly warns against reusing field numbers and recommends reserving deleted field names/numbers. FlatBuffers requires compatible field addition/deprecation rules.

Migrations are pure, deterministic transformations:

`DomainRecord vN → vN+1`

Chain only across a supported version window. Test golden saves from every supported shipping version. Never run arbitrary gameplay scripts during migration. Migration output goes through the same invariant validator as a new save.

### 7. Load as staged world construction

Load pipeline:

1. read and authenticate/validate container/header;
2. select compatible build/content or route to migration;
3. migrate records off-thread;
4. load required world cells/assets and collision/navigation dependencies;
5. create ECS entities/components in a staging world;
6. build identity maps and resolve references;
7. apply journal tail and subsystem reconstruction;
8. validate inventories, abilities/effects, quests, navigation/smart-object claims, transforms, and life state;
9. reset/rebuild derived caches, broad phases, histories, presentation, and temporal state;
10. atomically activate the staged world or return a typed failure without destroying the current session.

Do not serialize derived physics broad phases, pathfinding query caches, animation pose caches, audio voices, GPU handles, job state, or presentation smoothing. Rebuild them from authoritative state.

### 8. Checkpoint policy

A checkpoint is an explicit gameplay contract:

- safe player transform/movement state;
- checkpoint identifier and world-cell dependency set;
- health/resources/equipment/status policy;
- quest/world flags;
- NPC and encounter reset/persist policy;
- random stream seeds/counters if exact continuation is required;
- time/weather/environment gameplay state;
- last durable transaction sequence.

Do not autosave mid-transaction, during unresolved world streaming, while a traversal link is invalid, or when the player would load inside unsafe collision. Either defer to the next safe tick or capture enough state to restore the operation exactly.

### 9. Replay modes

Support two complementary formats:

- **Authoritative command replay:** initial deterministic snapshot + content/build manifest + ordered semantic commands/events + periodic hashes/checkpoints. Best for simulation verification and compact debugging when determinism holds.
- **State/replication replay:** initial baseline + periodic state checkpoints + incremental authoritative deltas/events. Best for viewing across imperfect determinism and mirrors Epic's documented replay model.

Replays use chunked streams with an index for seeking. A seek loads the nearest prior checkpoint, then applies subsequent increments to target tick. Replay playback executes in an isolated world; replay events cannot modify live progression, achievements, services, or inventory.

## Performance Considerations

### Complexity

Let `P` be persisted records, `D` dirty records since snapshot, `J` journal entries, and `R` reference edges.

- Full capture/serialization is **O(P)**.
- Incremental snapshots can approach **O(D)** with per-component/chunk dirty versions.
- Two-pass reference reconstruction is **O(P + R)** with O(1)-average stable-ID lookup.
- Journal replay is **O(J)**; periodic compaction bounds load time.
- Replay seeking is **O(log C + Δ)** using a checkpoint index, where `C` is checkpoints and `Δ` increments after the selected checkpoint.
- Naive migration through every historical version is O(number of versions × data); keep migrations bounded and optionally provide direct compaction migrations for old supported versions.

### Memory allocation and GC

- Use pooled serialization buffers, chunked streaming writers/readers, per-worker arenas, bounded compression jobs, and fixed metadata tables.
- Avoid building one giant object graph or whole-save JSON string.
- Snapshot handles reference immutable/copy-on-write ECS pages; dirty pages copy into a bounded snapshot pool.
- Backpressure when snapshot/replay buffers fill. Never allocate without bound or block the fixed tick indefinitely.
- No general heap/GC allocation in steady fixed-tick capture bookkeeping or replay command recording.

### Cache behavior and concurrency

- Serialize component columns/chunks in schema order for contiguous reads and good compression.
- Partition save chunks by domain/world cell/component family so workers operate independently and loads can be selective.
- Only completed simulation versions are readable by serializer jobs.
- Use one ordered manifest/chunk-directory writer after parallel chunk jobs complete.
- Compression/encryption/storage operate off-thread. File/platform APIs must obey their thread and lifecycle contracts.
- A new save request coalesces or queues behind an active capture by policy; concurrent writes never target the same generation.

### Fixed-step and I/O cost

- Capture metadata/roots at a safe fixed-tick boundary within a strict micro/millisecond budget.
- Spread dirty-page copying across ticks only if the snapshot abstraction preserves one logical tick; do not combine state from different ticks.
- Cap bytes copied/serialized/compressed/written per frame for autosaves and replay checkpoints.
- Epic documents replay checkpoint amortization across frames; use an equivalent explicit budget.
- Monitor storage latency, throughput, queue depth, compression ratio, capture pause, and total save age.

### GPU batching implications

Persistence stores renderer-neutral logical state only. On load, rendering rebuilds instances, pose buffers, temporal histories, and resource handles. Save/load triggers explicit camera/temporal-history reset events. Replay presentation consumes stable snapshots so render batching remains independent of serialized layout.

## Pros and Cons

### Versioned snapshot plus journal

**Pros**

- Fast recovery from a recent snapshot with bounded transaction replay.
- Incremental autosaves reduce write volume.
- Journal/audit data explains corruption or progression disputes.
- Cell/domain partitioning supports large worlds and selective loading.
- Crash-safe generations preserve a known-good fallback.

**Cons**

- More complex than a monolithic save object.
- Requires compaction, sequence/idempotency rules, and recovery testing.
- Snapshot consistency and journal cutoff must be exact.

### Monolithic reflected object dump

**Pros**

- Quick prototype and easy inspection in small games.

**Cons**

- Couples disk format to runtime layout and object lifecycle.
- Poor migration, selective loading, corruption isolation, and memory behavior.
- Persists accidental caches/transient references and can hitch badly.

**Recommendation:** expose a simple high-level checkpoint API to gameplay, backed by the versioned chunked snapshot/journal architecture.

## ECS Architectural Integration

### Components/resources

- `PersistentIdentity`: durable ID, generation, persistence domain, authored/runtime source.
- `PersistencePolicy`: schema/type ID and save/replay flags; normally registered per component type, not stored per entity.
- `DirtyPersistenceVersion`: chunk/component version or journal sequence.
- `WorldCellOwnership`: cell ID, local transform/origin epoch, migration policy.
- `CheckpointState`: checkpoint ID, safe transform, capture tick, dependency set.
- `RandomStreamState`: stable stream ID, seed, counter where deterministic continuation matters.
- `PersistenceCoordinator`: active capture, generations, budgets, snapshot pool, job status.
- `PersistenceOutbox`: completed transaction/journal entries awaiting durable commit.
- `ReplayRecorder`: stream header, command/event buffers, checkpoint schedule, state hashes.
- `ReplayPlaybackState`: isolated world, current/target tick, selected checkpoint, compatibility state.

### Ordered systems

1. Gameplay transactions/structural commands finish for authoritative tick.
2. Persistent event journal merges deterministically.
3. Checkpoint safety/dependency policy evaluates.
4. Snapshot coordinator captures immutable roots/dirty versions.
5. Simulation resumes.
6. Worker jobs encode, compress, encrypt, and checksum chunks.
7. Storage writer commits a new generation and verifies it.
8. Completion event updates slot metadata/UI and retires old generations later.

Load uses a separate staging-world pipeline and swaps only after all required validation succeeds.

## Component/System/Event Interfaces

### Save/checkpoint

- `SaveRequest { requestId, slot, domains, reason, requiredDurability, requestedTick }`
- `SnapshotCaptured { captureId, tick, schemaManifest, chunkVersions, journalCutoff }`
- `SaveCompleted { requestId, generation, tick, bytes, hash, duration, status }`
- `CheckpointRequested/Deferred/Committed`

### Load/migration

- `LoadRequest { requestId, slot, generationPolicy }`
- `MigrationStep { domain, sourceVersion, targetVersion, inputHash, outputHash }`
- `LoadProgress { phase, recordsProcessed, bytes, requiredCells }`
- `LoadCompleted { requestId, generation, restoredTick, status, warnings }`

### Replay

- `ReplayHeader { formatVersion, build/content/schema manifest, tickRate, initialTick, randomStreamManifest }`
- `ReplayCommandChunk`, `ReplayEventChunk`, `ReplayStateCheckpoint`, `ReplayHashRecord`
- `ReplaySeekRequest { targetTick }`
- `ReplayDivergence { tick, expectedHash, actualHash, firstDifferingComponent/record }`

All callbacks carry stable request IDs. UI receives immutable progress/results, not pointers into serializer jobs.

## Integration Plan

1. **Define save contract.** Enumerate persistent domains/components and explicitly exclude transient/derived state. Fix size, latency, retention, compatibility, security, and platform requirements.
2. **Create schema registry.** Stable type/field IDs, defaults, versions, reserved fields, content references, validation rules, and migration registration.
3. **Assign persistent identities.** Build-time authored IDs, runtime allocator, duplicate detection, cell ownership, and two-pass reference contracts.
4. **Implement deterministic in-memory encode/decode.** Chunk directory, bounds checks, canonical ordering, hashes, unknown-field policy, and golden tests.
5. **Build tick-consistent capture.** Immutable/copy-on-write ECS pages, dirty tracking, bounded snapshot pools, and structural-command cutoff.
6. **Add crash-safe storage.** Temporary generations, verification, atomic manifest switch, previous-generation fallback, platform abstraction, quotas, and user/profile mapping.
7. **Add checkpoint policy.** Safe transform, streaming dependencies, encounter/reset decisions, transaction cutoff, and UI/autosave scheduling.
8. **Implement migration and staged load.** Pure converters, supported-version matrix, quarantine, missing-content policy, invariant validation, derived-state rebuild, and atomic world activation.
9. **Add replay recording.** Start with authoritative state/replication replay for robustness, then command/hash replay for determinism testing and compact debugging.
10. **Connect multiplayer/services.** Server-authoritative save ownership, idempotent outbox, cloud conflict policy, disconnect/crash recovery, and privacy/security rules.
11. **Ship tools.** Save inspector/diff, schema compatibility linter, migration runner, corruption injector, replay timeline/seek, state-hash drilldown, and storage performance dashboard.

## Verification Strategy

### Round-trip and invariants

- Save → load → save produces semantically equivalent canonical records.
- Persistent entity/item/container/quest references resolve or produce the configured typed fallback.
- Inventories remain acyclic and conserved; ability/effect durations resume by tick policy.
- Character loads outside penetration with valid ground/platform/cell dependencies.
- Derived caches are absent from disk and rebuild correctly.

### Compatibility

- Golden saves and replays from every supported released schema/build.
- Add fields, deprecate/reserve fields, rename content, split/merge records, change defaults, and remove optional content.
- Downgrade/forward-load attempts receive explicit compatible/rejected/quarantined results.
- Fuzz unknown fields, invalid enum/type IDs, oversized lengths, duplicate IDs, cycles, bad references, and malicious compression sizes.

### Crash/corruption

Inject termination or failure:

- before snapshot capture;
- during serialization/compression;
- during temporary write;
- after data flush but before manifest switch;
- during cloud upload;
- after journal append but before compaction;
- while retiring old generations.

Corrupt each header/chunk/index/checksum and confirm fallback to a prior generation without partial activation.

### Concurrency and streaming

- Save during inventory transaction, ability phase, status tick, traversal, NPC smart-object claim, world-cell load/unload, origin rebase, and checkpoint trigger.
- Repeated save requests coalesce/queue deterministically.
- Load with slow/missing world cells and assets; current session stays intact until staged activation.
- Autosave budgets do not exceed fixed-tick or frame-time gates under worst storage latency.

### Replay

- Authoritative replay reproduces event order and periodic hashes.
- Seek to every checkpoint boundary and random ticks.
- Replay runs in isolation and cannot grant achievements, mutate profile inventory, write services, or alter a live world.
- Network loss/reordering in the original match does not corrupt the authoritative recorded sequence.
- Divergence tooling identifies the first tick and component family.

### Performance

- Benchmark full and incremental saves for 10k/100k/1M persistent records and many streamed cells.
- Require zero warm fixed-tick GC/general-heap allocation for capture bookkeeping/recording.
- Track capture pause, copied/dirty bytes, serialize/compress/encrypt/write time, queue depth, save age, load/migration time, peak memory, replay bytes/minute, checkpoint seek time, and journal growth.

## Risks/Open Decisions

- **Format choice:** Protobuf offers mature tagged schema evolution; FlatBuffers offers direct access but stricter schema rules. Benchmark both against chunk size, migration, unknown-field, tooling, and platform requirements before selection.
- **Determinism scope:** command replay requires stable simulation contracts. State replay remains the cross-build viewing fallback.
- **Cloud conflicts:** define slot ownership and merge policy. Playthrough/world saves usually select one generation rather than field-merge; profile unlocks may merge monotonically.
- **Encryption:** protect secrets/integrity as required, but do not rely on client-held keys for authoritative multiplayer progression.
- **Mod/content removal:** decide quarantine/substitution policies for missing definitions and preserve enough provenance for recovery.
- **Checkpoint semantics:** define which enemies, physics objects, status effects, timers, weather, loot, and random streams restore versus reset.
- **Open-world scale:** select whole-world snapshot, per-cell delta, or database/journal approach from measured persistent record count and streaming behavior.
- **Version support:** publish a finite migration window and an archival conversion tool; indefinite in-runtime chains become fragile.

## Source Links

1. Epic Games, **Saving and Loading Your Game, Unreal Engine 5.8**  
   https://dev.epicgames.com/documentation/en-us/unreal-engine/saving-and-loading-your-game-in-unreal-engine
2. Epic Games, **AsyncSaveGameToSlot API, Unreal Engine 5.8**  
   https://dev.epicgames.com/documentation/en-us/unreal-engine/API/Runtime/Engine/UGameplayStatics/AsyncSaveGameToSlot
3. Epic Games, **Using the Replay System, Unreal Engine 5.8**  
   https://dev.epicgames.com/documentation/en-us/unreal-engine/using-the-replay-system-in-unreal-engine
4. Epic Games, **DemoNetDriver and Streamers, Unreal Engine 5.8**  
   https://dev.epicgames.com/documentation/unreal-engine/demonetdriver-and-streamers-in-unreal-engine?lang=en-US
5. Google, **Protocol Buffers Language Guide and schema updates**  
   https://protobuf.dev/programming-guides/proto3/
6. Google, **Protocol Buffers Best Practices**  
   https://protobuf.dev/best-practices/dos-donts/
7. Google, **FlatBuffers Schema Evolution**  
   https://flatbuffers.dev/evolution/
8. Unity, **Serialization Rules, Unity 6**  
   https://docs.unity3d.com/Manual/script-serialization-rules.html
9. Godot Engine, **Saving Games**  
   https://docs.godotengine.org/en/stable/tutorials/io/saving_games.html

## Source/Recommendation Boundary

Multiple save domains/classes, asynchronous platform I/O, replay baselines/checkpoints/incremental data, replay version hooks, and additive stable-field schema-evolution rules are sourced from Epic, Google, Unity, and Godot documentation. The exact persistence policy matrix, ECS snapshot mechanism, snapshot-plus-journal design, crash-safe generation protocol, staged-world load, per-cell partitioning, command/state dual replay, budgets, hashes, and verification program are Operation Mythology engineering recommendations requiring validation against its platforms, world scale, cloud model, and compatibility commitments.
