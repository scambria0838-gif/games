# Operation Mythology Technical Recommendation Report

**Domain:** NPC navigation, path following, crowd avoidance, smart objects, behavior selection, environmental queries, and perception  
**Research timestamp:** 2026-07-27 02:05:02 America/Los_Angeles  
**Scope:** Non-rendering gameplay architecture for a modular, data-oriented ECS supporting first- and third-person play  
**Status:** New baseline recommendation

## Feature Overview

Scalable game AI is not one algorithm. It is a layered contract:

- navigation representation answers where an agent class may travel;
- global planning selects a polygon corridor or graph route;
- local steering turns the corridor into a preferred velocity;
- crowd avoidance modifies that velocity around nearby agents and dynamic obstacles;
- the character controller accepts or rejects actual displacement;
- perception converts world stimuli and visibility tests into time-bounded knowledge;
- behavior selection chooses goals and actions from knowledge and gameplay state;
- smart objects expose reservable semantic opportunities such as doors, cover, workstations, ladders, and seats.

**Sourced pattern.** Recast builds navigation meshes from voxelized geometry; Detour performs runtime navmesh queries, path corridors, crowd movement, and tiled streaming. Unreal documents tiled navmesh pathfinding, hierarchical StateTree behavior, spatially indexed/reservable Smart Objects, event-driven AI Perception, EQS candidate generation/filtering/scoring, and Mass crowd avoidance using a spatial hash and bounded nearby colliders.

**Engineering recommendation.** Use a hybrid navigation stack: tiled navmesh for free locomotion, authored traversal/smart-object links for semantic actions, hierarchical coarse routing for open worlds, bounded local avoidance, event-driven perception, and a compiled hierarchical state/utility decision layer. All layers communicate through data and requests; none directly moves authoritative entities except the character movement system.

## Industry-Standard API or Pattern

### 1. Tiled multi-agent navigation data

Bake a distinct navigation profile for materially different agent dimensions/capabilities. Each profile defines radius, height, step, maximum slope, allowed area types, movement capabilities, and traversal-link filters.

Partition navigation into streamable tiles. A tile has:

- stable world/cell coordinate and generation;
- polygon topology and adjacency;
- area/cost identifiers;
- off-mesh/semantic link references;
- optional coarse portal graph nodes;
- build source revision and compatibility schema.

Recast's documented pipeline rasterizes triangles into voxels, removes non-walkable spans, partitions walkable regions, and triangulates navigation polygons. Its tiled mode supports large worlds, localized rebuilds, hierarchical planning, and streaming.

Dynamic obstacles use a policy hierarchy:

1. local avoidance for short-lived moving agents/objects;
2. temporary cost/blocked overlays for doors, hazards, congestion, or scripted restrictions;
3. bounded tile rebuilds for persistent geometry changes;
4. full rebuild only in offline tooling or exceptional world edits.

Do not continuously carve/rebuild navigation for ordinary NPCs.

### 2. Asynchronous corridor planning and following

Plan globally with A* over polygons or a hierarchical portal graph, then keep a bounded polygon corridor. Detour's path-corridor contract constrains current position and target to the navmesh, finds local corners, updates as locomotion deviates, and supports periodic topology/visibility optimization.

Use request/result handles:

- `PathRequest`: requester, generation, profile, start projection, goal specification, cost filter, priority, deadline, and cancellation token.
- `PathResult`: status, nav-data generation set, corridor handle, partial-path reason, cost, and diagnostic counts.

Path following:

1. validate corridor/tile generations;
2. extract a bounded near-corner window;
3. select lookahead and preferred speed from curvature, stopping distance, formation, and action constraints;
4. submit preferred velocity to avoidance;
5. convert chosen velocity into a movement proposal;
6. feed collision-accepted position back into the corridor;
7. replan only on invalidation, material goal change, stuck evidence, or bounded periodic optimization.

Never teleport the agent to the navigation solution. The character controller remains authoritative for slopes, stairs, collision, moving platforms, and traversal modes.

### 3. Local avoidance as a bounded optimization

Maintain agents and obstacles in a uniform spatial hash or similar acceleration structure. Unreal Mass Avoidance documents a navigation-obstacle hash grid, nearest-neighbor limitation, predictive avoidance forces, and separate standing/moving behavior.

For each active near-tier agent:

- query neighbors within a time-horizon/radius;
- retain only the nearest/highest-risk `K`;
- combine corridor preferred velocity, agent/obstacle constraints, acceleration limits, group/lane bias, and personal-space priority;
- output a feasible velocity or controlled stop;
- never output a transform.

RVO/ORCA-style methods are strong baselines because they account for reciprocal agent motion, but constrained doorways and adversarial symmetry can deadlock or oscillate. Add deterministic tie-breaking, lane/side preference, priority/yield classes, progress monitoring, and escalation to replanning or slot arbitration.

Use full avoidance for near/high-relevance agents, simplified separation/lane following for middle tiers, and coarse lane/flow advancement for distant crowds.

### 4. Semantic smart objects and reservations

Epic describes Smart Objects as spatially queryable activities whose immutable definitions expose slots, tags, requirements, and behavior data. The object provides interaction data but the interactor owns execution. A slot must be claimed before use.

Use one smart-object framework for AI and players:

- immutable `SmartObjectDefinition`;
- runtime object identity and generation;
- one or more local-space slots;
- activity/capability/gameplay-tag requirements;
- approach/entry/exit transforms and navigation-link references;
- concurrency, queue, priority, timeout, and interruption policy;
- behavior/action definition handle;
- lifecycle state: available, claimed, occupied, disabled, or invalid.

Reservation transition:

`candidate → claim attempt → claimed → approach → occupied → completed/released`

Claims are atomic and generation-checked. Release on success, abort, death, streaming unload, definition replacement, ownership transfer, timeout, and path failure. Persistent registry entries may survive visual/actor streaming only when their gameplay data and collision/navigation contracts also remain valid.

### 5. Behavior selection

Use a compiled hierarchical state machine with selector/utility decisions at explicit boundaries:

- high-level domain states: idle, routine, investigate, combat, flee, scripted interaction;
- state entry conditions and transition triggers;
- bounded tasks for path requests, look/aim, ability requests, interaction claims, waits, and animation-action requests;
- utility scoring only among a small eligible option set;
- asynchronous tasks represented by handles and completion events.

Unreal StateTree combines hierarchical states/transitions with selector-style state choice and activates tasks from root through the selected leaf. This is an appropriate structural reference for a data-oriented runtime.

Avoid ticking an entire interpreted behavior tree for every NPC every frame. Decisions respond to events, task completion, meaningful perception/blackboard changes, or scheduled low-frequency reevaluation. Fixed-tick combat reactions remain bounded and prioritized.

### 6. Environmental queries

Use a generator-filter-score pipeline:

1. generate a bounded candidate set from spatial indices, navmesh samples, authored cover/interaction slots, or known entities;
2. run cheap hard filters first;
3. run expensive visibility/path tests only on survivors;
4. normalize and weight scores;
5. return the best result plus diagnostic score breakdown.

Epic's EQS documentation explicitly describes generators, contexts, filters, and scoring, and notes filters run before scoring. Apply deterministic candidate ordering and tie-breaking. Cache query templates, not results whose world validity has expired.

### 7. Event-driven perception and knowledge

Separate physical truth from an NPC's knowledge:

- stimuli are registered events or queryable sources;
- senses batch broad-phase candidates;
- narrow-phase checks validate range, field of view, occlusion, hearing propagation policy, affiliation, and gameplay state;
- observations update per-agent memory;
- memories decay/expire by fixed ticks;
- behavior consumes knowledge records, never direct omniscient world queries.

Knowledge records contain target generation, sense, confidence, last-confirmed tick, last-known position/velocity, stimulus tags, threat contribution, and expiry. Sight refreshes on a budgeted cadence; damage, scripted alerts, and loud sound events can be immediate. Unreal documents registered perception listeners/sources, batched perception updates, and configurable stimulus aging/forgetting.

AI runs on the authoritative server. Clients receive only replication/presentation state relevant to rendering and local feedback.

## Performance Considerations

### Complexity

Let `V/E` be graph vertices/edges, `N` agents, `K` retained neighbors, `C` environment-query candidates, `L` listeners, and `S` stimuli.

- Binary-heap A* is **O((V + E) log V)** worst case; hierarchical routing reduces the practical search region.
- Corridor corner extraction/local repair is bounded by corridor/window sizes, not the entire navmesh.
- A spatial-hash neighbor query is approximately **O(1 + local candidates)** average with suitable cell size; avoidance becomes **O(N × K)** when neighbors are capped.
- Naive all-listener/all-stimulus perception is **O(L × S)** and prohibited. Spatial/affiliation/event filtering should reduce work to local candidate pairs.
- Environmental query work is **O(C × tests)**; staged filtering makes expensive tests proportional only to survivors.
- Smart-object spatial query is approximately **O(log M + matches)** with a tree or **O(1 + local entries)** average with a grid; claim is O(1) atomic/serialized state transition.
- Hierarchical state transition selection is **O(depth × conditions)**; utility selection is O(eligible actions), which must be bounded.

### Memory allocation and GC

- Navigation tiles, coarse graphs, definitions, query programs, and behavior programs are immutable blobs.
- Use pooled path nodes/query objects, fixed corridor/corner buffers, per-worker arenas, fixed neighbor arrays, perception inbox rings, bounded knowledge sets, and reservation tables.
- No general heap/GC allocation during warm AI updates.
- When a corridor exceeds inline capacity, use a pooled handle with an explicit cap and partial-path/replan policy.
- Store perception memory in hot small arrays for current threats and a colder bounded map for long-term knowledge.

### Cache behavior and concurrency

- Batch agents by navigation profile, LOD tier, behavior program, and active task.
- Navigation queries read immutable tile generations and execute on workers; tile publication occurs at safe points.
- Spatial hash insertion and neighborhood lookup use deterministic cell partitioning and per-worker buffers.
- Perception broad phase, candidate filtering, environment-query tests, and utility scores parallelize cleanly when reading immutable snapshots.
- Smart-object claims and cross-agent group decisions require deterministic arbitration at a phase boundary.
- Avoid per-agent virtual calls and object pointers; compile task/test/sense kinds to dense IDs and structure-of-arrays parameters.

### Fixed-step cost and update-rate tiers

- Character movement and authoritative combat operate every fixed tick.
- Near-agent steering can update every tick; path-corner refresh may update at a lower rate.
- Perception senses use independent budgets: damage/event senses immediate, sight distributed across ticks, ambient hearing event-driven.
- High-level decision reevaluation occurs on events or a jittered schedule, not synchronized global intervals.
- Distant agents use reduced simulation: coarse graph/lane position, schedule, and aggregate state. Promote only after navigation, collision, animation, and gameplay data are ready.
- Cap path requests, raycasts, perception pairs, EQS candidates/tests, claims, and behavior transitions per tick. Queue with aging/fairness rather than causing spikes.

### GPU batching implications

AI remains CPU/gameplay logic. It publishes compact state/animation intent and LOD tier, enabling pose sharing and instanced rendering. AI must not depend on visual LOD or GPU visibility for authority. A renderer may report coarse visibility as a scheduling hint, but server simulation and correctness use gameplay relevance, distance, threat, and interaction state.

## Pros and Cons

### Hybrid tiled-navmesh + semantic links + bounded avoidance

**Pros**

- Mature, debuggable free-space pathfinding.
- Streamable tiles and hierarchical routes scale to large worlds.
- Smart links/objects express ladders, doors, cover, work, and traversal without encoding semantics in polygons.
- Bounded neighbor/candidate sets provide predictable frame cost.
- Shared smart-object contracts unify player and NPC interactions.

**Cons**

- Multiple agent profiles and tile generation increase build/storage cost.
- Dynamic destruction requires overlays, rebuild policy, and version-safe invalidation.
- Local avoidance does not solve global congestion and can deadlock at bottlenecks.
- Cross-layer bugs arise if path, claim, traversal, and movement lifecycles are not correlated.

### Navigation grid/voxel field only

**Pros**

- Natural representation for destructible or volumetric movement.
- Simple dynamic occupancy updates.

**Cons**

- High memory at fine resolution.
- Ground characters receive less precise boundary/corridor geometry.
- Hierarchical smoothing and agent-radius correctness require additional systems.

**Recommendation:** use navmesh for ordinary grounded characters, a coarse portal/zone graph for world-scale routing and distant simulation, and specialized volumes/graphs for flying, swimming, roads, or tactical domains.

## ECS Architectural Integration

### Components/resources

- `NavAgent`: profile ID, radius/height, area filter, capability tags, tier.
- `NavGoal`: target entity/location/region, acceptance radius, generation, priority.
- `PathRequestState`: request ID, status, deadline, cancellation generation.
- `PathCorridor`: inline polygon refs or pooled corridor handle, tile generations.
- `PathFollowState`: corner window, progress, preferred speed, stuck evidence.
- `AvoidanceAgent`: preferred/chosen velocity, priority, horizon, neighbor cap, group/lane bias.
- `LocomotionIntent`: movement proposal consumed by the character controller.
- `BehaviorRuntime`: compiled program, active state path, task handles, wake tick.
- `KnowledgeBuffer`: bounded observations and threat records.
- `PerceptionListener`: senses, ranges, affiliation mask, budgets.
- `StimulusSource`: sense types, tags, intensity, registration generation.
- `SmartObjectUser`: active query/claim/slot/action handle.
- World resources: `NavigationTileRegistry`, `CoarseRouteGraph`, `AvoidanceSpatialIndex`, `SmartObjectRegistry`, `PerceptionSpatialIndex`, and budget queues.

### Ordered systems

1. Publish streamed navigation/smart-object tile changes at a safe point.
2. Register/remove stimuli, obstacles, agents, and smart objects in spatial indices.
3. Process event senses and budgeted perception candidate generation.
4. Execute narrow-phase perception tests and update/expire knowledge.
5. Wake behavior instances from events, task completion, or due schedules.
6. Select/transition behavior state and emit bounded task requests.
7. Arbitrate smart-object claims and group/bottleneck reservations.
8. Process budgeted asynchronous global/coarse path queries.
9. Validate/repair corridors and generate near corners/preferred velocities.
10. Run bounded local avoidance.
11. Submit locomotion, look, ability, and interaction intents.
12. Character/traversal systems resolve actual authoritative movement/actions.
13. Feed accepted motion/task outcomes back to corridors and behavior.
14. Emit diagnostics, telemetry, and network-relevant state.

## Component/System/Event Interfaces

### Navigation

- `RequestPath { requestId, agent, navProfile, start, goal, costFilter, priority, deadlineTick }`
- `PathReady { requestId, corridorHandle, navGenerationSet, cost, partialReason }`
- `PathInvalidated { corridorHandle, tileOrLink, oldGeneration, reason }`
- `MovementProposal { agent, tick, desiredVelocity, facingPolicy, movementMode }`
- `MovementResult { agent, tick, acceptedDelta, blockingContact, grounded, progress }`

### Perception/knowledge

- `StimulusEvent { source, sense, location, intensity, tags, tick, lifetime }`
- `ObservationChanged { listener, target, sense, acquired/lost/updated, confidence, tick }`
- `KnowledgeRecord { target, generation, lastKnownPose, lastConfirmedTick, expiryTick, confidence, threat }`

### Smart objects

- `SmartObjectQuery { user, activityTags, capabilityTags, searchRegion, maxCandidates }`
- `SmartObjectCandidate { object, objectGeneration, slot, slotGeneration, score, approach }`
- `ClaimRequest/ClaimResult`
- `SlotOccupied/InteractionCompleted/ClaimReleased/ClaimInvalidated`

### Behavior

- `TaskRequest { owner, behaviorInstance, taskId, sequence, parameters }`
- `TaskResult { owner, taskId, sequence, success/failure/cancelled, reason }`
- Behavior tasks request navigation, abilities, animation actions, or interactions; they do not call implementation systems directly.

## Integration Plan

1. **Fix scale targets.** Define simultaneous NPC counts, active-combat counts, world size, agent profiles, dynamic-change frequency, target platforms, server tick, and AI frame budget.
2. **Bake tiled navigation.** Add deterministic build inputs, tile schemas, validation, debug visualization, multi-profile coverage tests, and streaming generation IDs.
3. **Implement async path service.** Use pooled query contexts, priority/fairness budgets, cancellation, partial paths, bounded corridors, and reproducible diagnostics.
4. **Integrate path following with the existing controller.** Preferred velocity becomes a locomotion intent; actual collision-accepted motion repairs or invalidates the corridor.
5. **Add authored traversal links.** Reuse Operation Mythology traversal candidates/reservations for ladders, vaults, mantles, doors, jumps, and elevators.
6. **Add spatial-hash avoidance and LOD tiers.** Start with bounded predictive separation, then benchmark RVO/ORCA/Detour-style velocity sampling and bottleneck policies.
7. **Build perception/knowledge.** Event-driven hearing/damage, budgeted sight, fixed-tick aging, affiliation filters, occlusion queries, and knowledge debugging.
8. **Compile behavior graphs.** Implement hierarchical states, typed transitions, asynchronous task handles, event wakes, deterministic utility scoring, and transition limits.
9. **Build smart-object registry.** Immutable definitions, spatial query, atomic claims, slot generations, queue policy, streaming lifecycle, and shared AI/player execution interfaces.
10. **Add environment queries.** Compile generator/filter/score templates; enforce candidate, trace, and path-cost budgets; expose score breakdown.
11. **Integrate networking and persistence.** Run AI on the server, replicate outcomes, serialize persistent schedules/claims only where design requires, and restore with generation validation.
12. **Scale, fuzz, and tune.** Crowd bottlenecks, mass perception events, tile churn, object contention, path storms, streaming promotion, and deterministic job schedules.

## Verification Strategy

### Navigation

- Golden maps for slopes, stairs, ledges, narrow portals, disconnected islands, one-way links, doors, elevators, moving platforms, and multi-profile clearance.
- Random point pairs compared against reference shortest-path/cost expectations.
- Tile stream/rebuild during active queries and corridors; no stale refs or use-after-free.
- Teleport, knockback, pushed-off-corridor, moving goal, partial path, cancellation, and origin rebasing.
- Prove movement never crosses authoritative collision because navmesh said it was valid.

### Crowds

- Opposing hallway flows, door bottlenecks, crossing groups, rings, stationary clusters, formation movement, and evacuation.
- Measure collision rate, time-to-goal, oscillation, backward motion, deadlock duration, density, neighbor counts, and per-agent CPU.
- Deterministic tie-break tests under identical symmetric setups.
- LOD promotion/demotion without jumps, overlaps, or reservation duplication.

### Perception and behavior

- Sight FOV/range/occlusion, partial cover, lighting-independent gameplay rules, hearing falloff/propagation policy, damage stimuli, affiliation, expiry, and reacquisition.
- Stimulus floods cannot exceed budgets or allocate.
- Behavior transitions on simultaneous events, cancellation, task timeout, target destruction, and smart-object invalidation.
- Same inputs/world snapshot across thread schedules produce matching state/claim decisions.
- Environment-query cheap filters occur before expensive traces/path tests and respect hard caps.

### Smart objects

- Many agents contest one/many slots with deterministic fairness.
- Release on every success, failure, death, despawn, stream unload, timeout, interruption, and disconnect path.
- Moving/streamed objects preserve local-space slot correctness and generations.
- Player and AI interaction use identical availability and claim rules.

### Performance

- Benchmark 100/1k/10k/50k NPC tiers, path storms, 10k simultaneous sound events, and dense crowd cells.
- Require zero warm-frame general-heap/GC allocation.
- Track path expansions, queue age, corridor lengths, neighbor/candidate high-water marks, raycasts, EQS tests, behavior wakes/transitions, claim contention, and p50/p95/p99 subsystem time.
- Soak streamed worlds for leaked corridors, query handles, listeners, stimuli, and claims.

## Risks/Open Decisions

- **Navigation backend:** Recast/Detour is the strongest baseline; decide whether to integrate directly, fork, or implement compatible engine-owned abstractions.
- **Determinism:** floating-point path/avoidance results and parallel completion order require stable quantization, tie-breaks, publication phases, and server authority.
- **Dynamic destruction:** define when overlays are sufficient and when tiles rebuild; excessive carving creates cost spikes and corridor churn.
- **Avoidance choice:** benchmark force-based, sampled-velocity/Detour Crowd, and ORCA-style solvers against Operation Mythology crowds. Unreal marks Mass Avoidance experimental, so treat it as reference rather than a shipping dependency.
- **Crowd deadlock:** local avoidance alone cannot allocate scarce portals. Add explicit bottleneck/lane/slot reservations where congestion matters.
- **Perception truth model:** define sight occlusion geometry, hearing propagation, stealth attributes, memory decay, shared squad knowledge, and difficulty modifiers without renderer dependence.
- **AI LOD semantics:** specify which gameplay may be approximated at distance and which combat/persistence rules remain exact.
- **Streaming:** persistent smart objects require gameplay data availability even when presentation actors unload; define registry ownership and save migration.

## Source Links

1. Recast Navigation, **Recast & Detour repository and architecture**  
   https://github.com/recastnavigation/recastnavigation
2. Recast Navigation, **Detour path-corridor implementation documentation**  
   https://github.com/recastnavigation/recastnavigation/blob/master/DetourCrowd/Source/DetourPathCorridor.cpp
3. Epic Games, **Basic Navigation in Unreal Engine 5.8**  
   https://dev.epicgames.com/documentation/unreal-engine/basic-navigation-in-unreal-engine?lang=en-US
4. Epic Games, **Mass Avoidance Overview 5.8**  
   https://dev.epicgames.com/documentation/unreal-engine/mass-avoidance-overview-in-unreal-engine?lang=en-US
5. Epic Games, **Using Avoidance with the Navigation System 5.8**  
   https://dev.epicgames.com/documentation/unreal-engine/using-avoidance-with-the-navigation-system-in-unreal-engine?lang=en-US
6. Epic Games, **StateTree Overview 5.8**  
   https://dev.epicgames.com/documentation/unreal-engine/overview-of-state-tree-in-unreal-engine?lang=en-US
7. Epic Games, **Smart Objects Overview 5.8**  
   https://dev.epicgames.com/documentation/en-us/unreal-engine/smart-objects-in-unreal-engine---overview
8. Epic Games, **AI Perception 5.8**  
   https://dev.epicgames.com/documentation/unreal-engine/ai-perception-in-unreal-engine?lang=en-US
9. Epic Games, **Environment Query System Overview 5.8**  
   https://dev.epicgames.com/documentation/unreal-engine/environment-query-system-overview-in-unreal-engine?lang=en-US
10. Unity, **AI Navigation package**  
    https://docs.unity3d.com/Manual/com.unity.ai.navigation.html
11. van den Berg et al., **Reciprocal n-body Collision Avoidance (ORCA)**  
    https://gamma.cs.unc.edu/ORCA/publications/ORCA.pdf

## Source/Recommendation Boundary

The navmesh build/tile/corridor capabilities, spatially bounded avoidance, hierarchical StateTree structure, Smart Object definition/slot/claim pattern, event-driven perception with stimulus aging, and generator-filter-score environmental queries are sourced from Recast/Detour, Epic, Unity, and the ORCA paper. The exact ECS layout, hybrid world graph, AI LOD tiers, budgets, bottleneck arbitration, deterministic tie-break rules, knowledge schema, character-controller boundary, and staged integration plan are Operation Mythology engineering recommendations to validate against its world scale, NPC counts, gameplay rules, and target hardware.
