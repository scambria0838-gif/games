# Operation Mythology Technical Recommendation Report

**Domain:** Game calendar, time of day, weather simulation, regional environment state, scheduling, and sky/environment integration contracts  
**Research timestamp:** 2026-07-27 02:30:37 America/Los_Angeles  
**Scope:** Gameplay-facing world systems only; renderer architecture, shaders, lighting quality, clouds, and GPU effects excluded  
**Status:** New baseline recommendation

## Feature Overview

The environment system is the authoritative world-state service that answers gameplay questions such as:

- What simulation time/date is it?
- Is this location indoors, underwater, sheltered, exposed, hot, cold, wet, windy, or storming?
- Which scheduled events, NPC routines, encounters, crops, hazards, abilities, audio states, or save rules should advance?
- What compact state should networking, replay, audio, AI, physics, and rendering consume?

**Sourced pattern.** Unreal's Day Sequence system separates game-time day length, real-time cycle duration, initial time, runtime progression, conditional sequence collections, regional modifier volumes, multiplayer synchronization, and budgeted visual update intervals. Unity and Godot distinguish render/frame time from fixed/physics time. Godot explicitly warns that user/OS-adjustable wall-clock time is unsuitable for precise elapsed-time calculation and recommends monotonic ticks.

**Engineering recommendation.** Own time and weather in a renderer-independent, server-authoritative `WorldEnvironmentService`. Advance game time using integer/fixed-point simulation ticks, schedule gameplay events through crossing-aware tick/calendar queues, model weather as deterministic regional state with explicit transitions, and publish immutable snapshots to consumers. Rendering may interpret those snapshots, but it never owns the calendar, weather, exposure, or gameplay consequences.

## Industry-Standard API or Pattern

### 1. Explicit clock domains

Define separate clocks:

- `SimulationTick`: monotonic authoritative fixed-step tick for gameplay, networking, replay, effect duration, and ordering.
- `GameCalendarTime`: signed integer/fixed-point elapsed game-time units mapped to day/year/calendar fields.
- `PresentationTime`: interpolated render time derived from simulation snapshots.
- `RealMonotonicTime`: platform monotonic time for profiling, timeouts, network RTT, and save-operation duration.
- `WallClockUTC`: optional external timestamp for metadata or explicitly designed offline progression.

Never use local wall clock for authoritative cooldowns, NPC schedules, weather progression, or anti-cheat-sensitive rewards. System time can move backward/forward or be changed by the user. Store UTC plus explicit timezone rules only when real-world calendar integration is a product requirement.

### 2. Integer/fixed-point game calendar

Represent world time canonically as:

`elapsedGameSubseconds` or `(dayIndex, subdayTick)`

with:

- configurable calendar definition;
- exact simulation-tick-to-game-time ratio;
- rational time scale to avoid accumulating floating error;
- pause/freeze state;
- bounded fast-forward policy;
- day/season/year derivation;
- serialization and network epoch/version.

Derive hour/minute/normalized-day fraction for consumers. Do not store independent mutable hour, minute, sun angle, and day count; they drift and create contradictory state.

Changes to time scale are authoritative commands effective at a specified tick. If the game allows sleep or fast travel, prefer a deliberate time jump transaction that reports the crossed interval rather than simulating thousands of ordinary fixed ticks.

### 3. Crossing-aware scheduler

Schedule by canonical game timestamp:

- one-shot exact events;
- recurring daily/weekly/seasonal events;
- interval events;
- window enter/exit events;
- regional/weather-condition triggers;
- deferred catch-up actions.

When time advances from `A` to `B`, process all events in `(A, B]` in stable order. This avoids missed dawn, shop opening, effect expiry, or quest deadlines during fast-forward, load, low update rates, or time-scale changes.

Each event declares catch-up policy:

- execute every occurrence, with a strict cap;
- execute once with aggregated elapsed count/duration;
- set final state only;
- discard if missed;
- block the jump and require bespoke simulation.

Use stable tie-breaking `(timestamp, priority, eventId)`. Event handlers emit commands for the next safe phase rather than recursively mutating the scheduler.

### 4. Deterministic weather state machine

Weather is a regional gameplay simulation, not a visual preset. A region has:

- current weather archetype and phase;
- deterministic seed/random-stream state;
- transition start/end game timestamps;
- continuous gameplay parameters such as precipitation, wind vector/gust, temperature, humidity/wetness, visibility category, thunder hazard, accumulation rate;
- tags such as `Weather.Rain.Heavy` or `Environment.Freezing`;
- forecast/transition queue where design requires it.

Use authored transition graphs or weighted Markov-like rules constrained by biome, season, altitude, climate, quest overrides, and recent-history cooldowns. Draw random transitions only from a named deterministic stream at defined decision ticks. Record chosen transitions so content/rule changes do not retroactively alter an existing save or replay.

Separate:

- **weather truth:** authoritative regional parameters;
- **local exposure:** what an entity experiences after shelter/interior/water/volume resolution;
- **presentation state:** renderer/audio interpretation and blending.

### 5. Region and local override composition

World environment queries combine layers in a documented order:

1. global calendar/season;
2. climate/biome region;
3. active regional weather;
4. streamed world-cell/environment state;
5. authored volumes such as cave, interior, underwater, magical zone;
6. dynamic shelter/roof/cover query;
7. entity-specific equipment/status modifiers.

Every layer provides typed fields and blend/override semantics:

- replace categorical state;
- additive/multiplicative numeric modifier;
- minimum/maximum clamp;
- priority override;
- weighted blend for presentation-only values.

Volumes use stable IDs, priorities, generation checks, and deterministic tie-breaks. Unreal's Day Sequence modifier volumes provide a current example of localized time/environment overrides and weighted composition, but Epic marks the plugin experimental; use it as a reference contract, not a dependency.

### 6. Immutable environment snapshot

Publish once per authoritative environment update:

`EnvironmentSnapshot { simulationTick, gameTimestamp, calendarFields, timeScale, globalTags, regionStates, revision }`

Per-entity or per-cell consumers obtain:

`LocalEnvironmentSample { region, localTags, exposure, wetnessRate, temperature, wind, visibilityClass, surfaceCondition, revision }`

Consumers:

- AI schedules/perception;
- abilities/status effects and survival systems;
- navigation/path costs and smart-object availability;
- surface/footstep/audio state;
- physics forces only where explicitly designed;
- inventory/crafting/crops;
- streaming/persistence/replay;
- renderer/sky adapter.

Consumers never reach into weather controllers or sequence objects. They query/read snapshots or subscribe to threshold/transition events.

### 7. Renderer/sky adapter boundary

The gameplay system publishes semantic state:

- normalized day fraction and calendar;
- sun/moon direction or astronomical inputs if gameplay needs them;
- weather/region IDs and blend progress;
- precipitation/wind/cloud/fog semantic scalars;
- local override stack;
- discontinuity/history-reset reason.

The renderer owns:

- skybox/atmosphere implementation;
- light, fog, cloud, material, reflection, exposure, and shader parameters;
- visual curves, temporal smoothing, update interval, and GPU resources.

Gameplay must not read renderer-derived luminance, cloud texture, shadow state, or skybox blend to decide stealth, temperature, wetness, schedules, or damage. If darkness affects gameplay, author an explicit `GameplayIlluminationClass` or exposure rule in the environment state.

## Performance Considerations

### Complexity

Let `E` be due scheduled events, `R` active weather regions, `V` relevant override volumes, and `N` sampled entities.

- Canonical clock advance and calendar derivation are **O(1)**.
- Min-heap scheduled insertion/removal is **O(log M)** with due processing **O(E log M)**.
- A timing wheel/calendar bucket scheme gives near **O(1)** insertion and **O(E + bucket work)** for bounded horizons.
- Updating all regions is **O(R)** only at weather decision/sample cadence, not necessarily every simulation tick.
- Spatial volume query is approximately **O(log V + overlaps)** or **O(1 + local overlaps)** average with a grid.
- Naive per-entity evaluation of every layer is O(N × V) and prohibited. Cache region/cell membership and update local samples only on movement across cells/volumes, environment revision changes, or scheduled cadence.
- Threshold subscriptions avoid polling all consumers for dawn, freezing, storm, or exposure transitions.

### Memory allocation and GC

- Calendar definitions, climate profiles, transition graphs, curves, and consumer channel schemas are immutable blobs.
- Use fixed region arrays, pooled override stacks, spatial-index cells, small inline local samples, timing-wheel/heap storage, and per-worker event buffers.
- No per-minute/hour timer objects and no string tag operations in hot paths.
- Compile tags, regions, conditions, transitions, and curves to dense IDs/indices.
- No general heap/GC allocation after warm-up for clock advancement, event dispatch, regional weather, local sampling, replication, or replay.

### Cache behavior and concurrency

- Store region weather parameters structure-of-arrays for batched updates.
- Partition entity exposure sampling by world cell/region.
- Read immutable completed environment snapshots from AI, audio, abilities, and presentation jobs.
- Gather local transition/events per worker and deterministically merge by target/timestamp/event ID.
- Spatial/environment registry publication occurs at streaming safe points using generation IDs.
- Weather decisions are single-writer per region or use deterministic command playback.

### Fixed-step cost and rate separation

- Advance authoritative clock every fixed simulation tick.
- Calendar boundary/scheduler work runs only when timestamps cross due entries.
- Weather transition decisions may run every in-game minute/hour; interpolate continuous parameters analytically from stored endpoints.
- Local exposure updates are event/cell/revision driven and may be tiered for distant NPCs.
- Renderer/audio may sample more or less frequently and smooth independently. Epic's Day Sequence documentation exposes a visual update interval and time-slicing, supporting this separation.
- Fast-forward processes aggregate policies under strict occurrence/work caps; it does not execute every skipped ordinary tick.

### GPU batching implications

The system sends one shared/global and bounded regional/local parameter blocks to rendering. It does not issue draw calls or create materials. Quantized region/environment state can help renderer grouping, but gameplay sampling remains independent. Time/weather changes that invalidate temporal presentation include an explicit discontinuity/reset flag rather than modifying GPU history directly.

## Pros and Cons

### Authoritative semantic environment service

**Pros**

- Gameplay behavior remains identical with rendering disabled, headless servers, or different graphics settings.
- Fixed-point tick/calendar state is saveable, replayable, and network-friendly.
- Explicit crossing/catch-up policies make sleep, fast travel, and load reliable.
- Regional weather and local exposure support open worlds without per-entity full simulation.
- Consumers integrate through stable data contracts rather than dependencies on lighting/sky implementations.

**Cons**

- Requires careful time-jump, recurring-event, and migration semantics.
- Local exposure/shelter can be expensive if driven by uncontrolled physics traces.
- Designers must author gameplay semantics separately from visual curves.
- Regional transitions and streaming boundaries need continuity tools.

### Renderer-owned time/weather

**Pros**

- Fast visual prototype.

**Cons**

- Headless servers cannot reproduce gameplay decisions.
- Visual update rate changes mechanics.
- Save/load/network/replay state becomes ambiguous.
- Graphics settings or effects availability can affect gameplay.

**Recommendation:** renderer ownership is unacceptable for Operation Mythology's gameplay truth. Treat Unreal Day Sequence-style systems as a presentation adapter consuming the engine-owned environment clock.

## ECS Architectural Integration

### Components/resources

- `WorldClockState`: epoch, current game timestamp, rational scale, pause/freeze, revision.
- `CalendarDefinition`: immutable day/season/year rules and formatting metadata.
- `ScheduledWorldEvent`: event ID, due timestamp, recurrence, catch-up policy, payload handle.
- `ClimateRegion`: stable region ID, biome/climate profile, spatial/cell coverage.
- `WeatherRegionState`: archetype, phase, seed/stream counter, transition endpoints/times, continuous parameters, revision.
- `EnvironmentVolume`: stable ID/generation, shape/spatial handle, priority, typed override data.
- `EnvironmentMembership`: cached region/cell/volume handles and revisions.
- `LocalEnvironmentState`: exposure, wetness, temperature, wind, visibility/surface classes, tags, revision.
- `EnvironmentConsumerMask`: which channels an entity needs.
- World resources: scheduler, region registry, volume spatial index, immutable snapshot ring, deterministic random-stream registry.

### Ordered systems

1. Apply authoritative time-control/weather-override commands.
2. Advance canonical world clock at fixed tick.
3. Process all crossed scheduled/calendar events with catch-up caps.
4. Advance due regional weather decisions/transitions.
5. Publish streamed region/volume changes at a safe boundary.
6. Update dirty cell/region/volume memberships.
7. Compute required local environment samples in parallel.
8. Emit deterministic threshold/transition events.
9. Abilities, AI, navigation, physics, inventory, and world systems consume the snapshot.
10. Persist/replicate/hash authoritative environment state.
11. Publish presentation snapshot to sky, audio, UI, and effects adapters.

## Component/System/Event Interfaces

### Commands

- `SetTimeScale { commandId, effectiveTick, numerator, denominator, reason }`
- `JumpGameTime { commandId, effectiveTick, targetTimestamp, catchUpBudget, reason }`
- `FreezeWorldClock/ResumeWorldClock`
- `ForceWeatherTransition { region, definition, transitionDuration, authority, reason }`
- `RegisterScheduledEvent/CancelScheduledEvent`

### Events

- `GameTimeAdvanced { from, to, scale, jump }`
- `CalendarBoundaryCrossed { boundaryType, timestamp }`
- `ScheduledWorldEventDue { eventId, occurrenceCount, aggregatedDuration }`
- `WeatherTransitionStarted/PhaseChanged/Completed`
- `EnvironmentThresholdCrossed { region/entity, channel, oldClass, newClass }`
- `LocalEnvironmentChanged { entity, changedMask, revision }`
- `EnvironmentDiscontinuity { reason, oldRevision, newRevision }`

### Read interfaces

- `GetWorldClockSnapshot()`
- `SampleRegionEnvironment(region, timestamp)`
- `SampleLocalEnvironment(entity/location, channelMask)`
- `QueryForecast(region, horizon)` only if forecast is authoritative gameplay data.
- `GetPresentationEnvironment(viewLocation)` returns semantic data, not renderer objects.

## Integration Plan

1. **Define clock semantics.** Fix tick rate, game units, calendar, initial epoch, scale limits, pause behavior, multiplayer authority, sleep/fast-travel, and offline progression policy.
2. **Implement canonical clock and scheduler.** Integer/fixed-point time, rational scaling, crossings, recurrence, stable ordering, catch-up policies, overflow limits, and deterministic tests.
3. **Define environment schema.** Weather archetypes, continuous channels, categorical tags, thresholds, region/climate definitions, transition rules, and named random streams.
4. **Implement regional deterministic weather.** Decision cadence, history constraints, transition endpoints, overrides, forecasts, save/replay state, and server replication.
5. **Build region/volume composition.** Spatial indexing, priorities, stable IDs, typed blend semantics, cached membership, shelter/interior/water hooks, and streaming lifecycle.
6. **Integrate gameplay consumers.** AI schedules/perception, abilities/status, navigation, crops/crafting, surface conditions, audio events, survival, and checkpoints through snapshot interfaces.
7. **Add network/persistence/replay.** Replicate clock epoch/scale/revision and region transitions, persist selected regions/queues/random streams, and hash deterministic state.
8. **Build presentation adapters.** Connect sky/day sequence, audio, UI, and effects to immutable semantic snapshots with independent smoothing/update budgets.
9. **Add tooling.** Time scrub/jump simulator, scheduler timeline, region/weather map, volume stack inspector, per-entity exposure view, transition probability audit, and headless equivalence tests.

## Verification Strategy

### Clock/calendar

- Tick-to-game-time exactness across long-duration soak, pause/resume, scale changes, wrap boundaries, save/load, and replay.
- Midnight, month/season/year boundaries, negative/pre-epoch time if supported, and maximum timestamp.
- Fast-forward across zero/one/many recurring events with each catch-up policy.
- Stable ordering for simultaneous events and handler-generated follow-up commands.
- Client clock converges to server state without gameplay events firing twice.

### Weather and regions

- Fixed seed/commands produce identical transitions, parameters, events, and hashes across thread counts.
- Region borders, overlapping volumes, equal priority, moving volumes, caves, interiors, underwater, shelter, cell stream/unload, and origin rebasing.
- Forced weather/quest override starts, blends, cancels, persists, and restores correctly.
- Large time jump aggregates accumulation, crop/status, forecast, and weather history according to explicit policy.
- Removing/renaming weather or climate content migrates or rejects cleanly.

### Consumer isolation

- Headless server, minimum graphics, maximum graphics, paused renderer, and renderer restart produce identical gameplay hashes.
- Sky/visual update frequency changes do not alter AI, damage, wetness, temperature, schedules, or audio trigger identity.
- First-/third-person camera switching changes presentation sampling location only if explicitly configured; it never changes character exposure truth.
- Dropped presentation events or unloaded visual assets do not alter authoritative state.

### Performance

- Benchmark thousands of regions, 10k/100k scheduled events, dense volume overlaps, 50k NPC consumers, simultaneous dawn/weather thresholds, and large time jumps.
- Require zero general-heap/GC allocation after warm-up.
- Track due-event count, queue age, catch-up truncation, region decisions, local samples, spatial candidates, dirty memberships, bytes replicated/saved, and p50/p95/p99 system cost.
- Soak months/years of accelerated game time for drift, queue leaks, random-stream divergence, and unbounded history.

## Risks/Open Decisions

- **Calendar scope:** choose fictional fixed calendar versus Gregorian-like rules; do not add DST/timezones unless gameplay truly requires them.
- **Offline progression:** wall clock is user-adjustable. Server time or signed service timestamps are required for authoritative offline rewards.
- **Time jumps:** define aggregate behavior for status effects, crops, NPC schedules, encounters, crafting, weather, physics objects, and queued transactions.
- **Weather model:** choose authored transition graph versus simulation-heavy model based on gameplay value; do not spend CPU on atmospheric realism that no mechanic consumes.
- **Shelter:** physics ray/volume methods need caching and explicit accuracy tiers; visual occlusion is not authoritative shelter.
- **Region streaming:** decide which regional weather stays simulated while unloaded and how forecasts remain continuous.
- **Random evolution:** persist chosen transitions or random stream counters so balance/content changes do not rewrite existing world history.
- **Epic Day Sequence:** the 5.8 plugin is experimental and graphics-centric; use only as an adapter/reference, not the core gameplay clock.

## Source Links

1. Epic Games, **Day Sequence Time of Day Plugin, Unreal Engine 5.8**  
   https://dev.epicgames.com/documentation/unreal-engine/day-sequence-time-of-day-plugin-for-unreal-engine
2. Epic Games, **DaySequence API, Unreal Engine 5.8**  
   https://dev.epicgames.com/documentation/unreal-engine/API/Plugins/DaySequence?lang=en-US
3. Epic Games, **ADaySequenceActor API, Unreal Engine 5.8**  
   https://dev.epicgames.com/documentation/unreal-engine/API/Plugins/DaySequence/ADaySequenceActor?lang=en-US
4. Unity, **Time API**  
   https://docs.unity3d.com/ScriptReference/Time.html
5. Unity, **Time.timeAsDouble**  
   https://docs.unity3d.com/ScriptReference/Time-timeAsDouble.html
6. Godot Engine, **Time singleton**  
   https://docs.godotengine.org/en/stable/classes/class_time.html
7. Godot Engine, **Timer**  
   https://docs.godotengine.org/en/stable/classes/class_timer.html
8. Godot Engine, **Idle and Physics Processing**  
   https://docs.godotengine.org/en/stable/tutorials/scripting/idle_and_physics_processing.html

## Source/Recommendation Boundary

The separation of fixed versus frame time, monotonic versus system time, configurable game-day/cycle duration, regional modifier composition, network synchronization, and budgeted presentation updates are sourced from Epic, Unity, and Godot documentation. The canonical fixed-point clock, crossing-aware scheduler, deterministic regional weather graph, named random streams, region/local exposure layers, exact ECS layouts, semantic renderer boundary, time-jump policies, and verification program are Operation Mythology engineering recommendations requiring validation against its calendar, world scale, survival mechanics, multiplayer modes, and content design.
