# Operation Mythology Mechanics Research — Deterministic Simulation, Rollback, Replay, and Desync Diagnosis

**Timestamp:** 2026-07-27T02:18:19-07:00  
**Scope:** Fixed simulation boundaries, ordered commands/events, deterministic ECS execution, state snapshots and hashes, client prediction replay, full rollback, replay compatibility, side-effect control, desync diagnosis, and performance.

## Feature Overview

This batch defines the boundary of authoritative gameplay that may be replayed. It distinguishes:

- **Owner prediction/reconciliation:** restore a server snapshot and replay local commands.
- **Full deterministic rollback:** predict missing inputs, restore an earlier whole-simulation state, and resimulate.
- **Server rewind:** query bounded history for hit validation without replaying the whole world.
- **Replay:** reproduce or view recorded gameplay, either from commands plus deterministic state or periodic snapshots/deltas.
- **Debug rewind:** inspect historical state without implying a shipping network model.

The proposed generic ECS uses fixed ticks, immutable tick inputs, deterministic phase/merge ordering, versioned snapshots, canonical state projections, and side-effect journals. Determinism is a declared compatibility tier, not an assumed property of “fixed update.”

## Existing Coverage and Identified Gap

The recursive scan at 2026-07-27T02:17:31-07:00 found 12 files in `GAME SKILLS` and 9 in the dedicated folder. A newly added physics/controller report already defines controller saved state, platform history, fixed stepping, correction/replay, and backend determinism constraints. Earlier reports cover server rewind, execution IDs, event ordering, persistence, and observability.

The remaining gap is engine-wide: which components influence the next tick, how commands and parallel results acquire canonical order, how snapshots handle structural changes and references, how replayed ticks suppress or reconcile external effects, how compatibility is versioned, and how the first divergent field is located after a hash mismatch.

## Sourced Facts

- GGPO requires deterministic gameplay plus save, load, and advance-frame-without-rendering interfaces. It predicts missing remote input and resimulates from the divergence when actual input differs.
- Unity Netcode for Entities applies authoritative snapshots and runs its predicted simulation from the oldest applied tick to the target tick. Unity warns this may mean roughly 22 resimulated frames for a 300 ms connection.
- Unity runs predicted entities selectively and documents partial-snapshot interaction, quantization, and structural-component edge cases. Its current documentation explicitly says the package does not guarantee determinism.
- Unreal character movement records client moves, validates them on the server, corrects state, and replays saved moves; direct transform writes outside that contract cause corrections.
- Unreal's resimulation physics mode caches per-tick physics history for at least an RTT-scale window, consuming CPU and memory.
- GGPO-style deterministic lockstep and authoritative client prediction are different network models; deterministic code can support models other than input-only lockstep.
- GDC case studies from Overwatch, For Honor, Mortal Kombat/Injustice, and Knockout City describe determinism/rewind as major architectural and optimization commitments, including multiple simulation advances inside one render frame.
- The Knockout City presentation specifically describes a parallel, deterministic, rewindable entity system and calls for hashing/recording mutable component state.
- The INVERSUS rollback post separates state that feeds the next simulation step from presentation/non-game state and warns against wall time, global unsynchronized inputs, pointer-dependent order, uninitialized padding, architecture-dependent math, and unordered parallel merges.
- The Age of Empires networking postmortem describes world checksums and large traces used to diagnose rare deterministic divergence whose visible symptom appeared long after the original difference.

## Industry-Standard API or Pattern

Use the functional boundary:

`State[T+1] = Step(State[T], OrderedCommands[T], ImmutableConfig, TickContext)`

Real implementations mutate ECS storage, but must preserve this dependency model. External time, device input, network packets, file/service results, random seeds, content/streaming changes, and administrative actions enter as tick-stamped commands or versioned configuration facts.

Canonical fixed phases:

`ingest -> validate/order commands -> pre-sim structural commit -> gameplay jobs -> deterministic reductions/events -> outcome transaction commit -> post-sim structural commit -> canonical hash/snapshot -> presentation projection`

Systems may execute jobs in any safe order; result-sensitive merges use stable keys such as phase, system ID, target stable ID, source stable ID, command sequence, and local emission index.

## Performance Considerations

- **Asymptotic complexity:** Stepping is `O(active gameplay work)`. Sorting `K` commands/events is `O(K log K)` or `O(K)` with bounded radix keys. Full snapshots are `O(S)` bytes; dirty-page/delta capture is `O(changed pages + metadata)`. Hierarchical hashing is `O(S)` initially and `O(dirty pages)` incrementally.
- **Allocations and garbage collection:** Preallocate input, event, snapshot, restore, hash, and side-effect rings. Snapshot by copying fixed pages/chunks into pooled slabs or copy-on-write pages. No per-tick objects, reflection, strings, or allocator-order-dependent logic.
- **Cache behavior:** Canonicalize by archetype/type/stable entity ID, but hash dense raw bytes only when padding and representation are defined. Keep simulation state dense and presentation/external handles outside snapshot pages.
- **Update frequency:** Capture/hash at full authoritative ticks, not render or partial ticks. Store periodic keyframes plus deltas for long replay; keep dense recent snapshots for rollback.
- **Concurrency:** Workers read published input/state and write isolated outputs. Reductions and event buffers merge canonically. Snapshot publication occurs after dependencies complete; background compression reads immutable pages.
- **Fixed-step cost:** Resimulation cost is `O(rollback ticks × predicted work)`. Budget maximum rollback depth, predicted entity scope, physics substeps, and catch-up ticks; never let correction create an unbounded spiral.
- **Serialization cost:** Full state is `O(S)` per keyframe and deltas `O(D)`. Version every component codec and snapshot manifest. Commands alone are compact but require compatible deterministic code/content; archival replay generally needs periodic state and migration policy.
- **Networking cost:** Input streams are small and can redundantly include unacknowledged commands. Authoritative snapshots/deltas cost more but tolerate nondeterministic subsystems. Hash exchange is cheap but diagnoses only after canonical scope and tick alignment match.
- **Memory:** Recent rollback storage is approximately `history_ticks × mutable_state_bytes`, reduced by page sharing/deltas at CPU/complexity cost. Side-effect and input histories must cover the same or greater window.

## Pros and Cons

**Full deterministic rollback**

- Pros: responsive remote interactions, low state bandwidth, exact command replay.
- Cons: whole-simulation determinism, fast restore/resimulation, side-effect safety, memory, version compatibility, and difficult desync bugs.

**Authoritative snapshot prediction**

- Pros: server security and tolerance for nondeterministic remote/world systems; prediction can be scoped.
- Cons: bandwidth, corrections, partial-snapshot dependency hazards, repeated resimulation.

**Input-only replay**

- Pros: compact recordings and strong debugging reproduction.
- Cons: brittle across code/content/platform changes; requires complete deterministic initial state.

**Snapshot-assisted replay**

- Pros: seekable and more resilient; supports divergence recovery/inspection.
- Cons: larger files and component schema migration.

## ECS Architectural Integration

Classify all state:

1. **Authoritative recursive state:** influences a later tick and must be restored/hashed.
2. **Derived deterministic cache:** may be rebuilt or snapshotted with an explicit policy.
3. **Presentation state:** interpolated camera/audio/VFX/UI; never feeds authority.
4. **External state:** platform/service/file/network facts admitted only through recorded commands.

Structural changes are deterministic commands, not immediate worker mutations. Entity references use stable generational IDs mapped to runtime locations after restore. Allocation/free-list state is either captured or rebuilt by a canonical rule.

During resimulation, gameplay events may be regenerated, but irreversible side effects are not executed immediately. A journal keyed by deterministic `EffectId` compares predicted/replayed outcomes with already-presented outcomes, then confirms, cancels, adjusts, or emits once.

## Component, System, Resource, and Event Interfaces

### Components

- `StableSimulationId { id, generation }`
- `RollbackTracked { policy_id, snapshot_codec }`
- `DeterministicRandomState { stream_id, state, draw_count }`
- `SimulationLifetime { spawn_tick, despawn_tick, generation }`
- `PredictedEntity { owner, prediction_generation }`
- `AuthoritativeRevision { tick, revision }`

### Resources

- `SimulationClock { tick, fixed_dt, epoch }`
- `TickCommandRing { per_tick_ranges, acknowledgements }`
- `DeterministicPhaseRegistry { systems, access, order, merge_keys }`
- `SnapshotRing { tick, schema, pages, config_generation }`
- `CanonicalHashRegistry { component_fields, exclusions, quantization }`
- `RandomStreamRegistry { seeds, ownership, draw_counts }`
- `SideEffectJournal { effect_id, predicted_tick, status, payload_hash }`
- `ReplayManifest { build, protocol, content, schema, platform_math_tier }`
- `DesyncCapture { first_bad_tick, partition_hashes, field_diffs, commands }`

### Commands and Events

- `TickCommand { tick, source, sequence, type, payload }`
- `StructuralCommand { tick, phase, stable_sort_key, mutation }`
- `DeterministicEvent { tick, phase, event_id, causality, payload }`
- `RollbackRequested { restore_tick, target_tick, reason }`
- `SnapshotRestored { tick, generation }`
- `ResimulationCompleted { from_tick, to_tick, ticks_run, mismatch }`
- `StateHashSample { tick, partition, hash }`
- `DesyncDetected { tick, local_hash, reference_hash }`
- `PresentationEffectIntent { effect_id, tick, policy, payload }`

### Systems

1. command ingest/deduplication;
2. canonical command ordering;
3. snapshot restore when requested;
4. fixed deterministic simulation phases;
5. structural/event deterministic merge;
6. authoritative outcome commit;
7. state hash and snapshot capture;
8. side-effect reconciliation;
9. render/audio/UI projection;
10. background replay/export/desync analysis.

## Integration Plan

1. Publish a determinism matrix by subsystem/platform: bitwise, tolerance/quantized, server-authoritative only, or excluded.
2. Define authoritative state projection and fixed phase graph before adding whole-world rollback.
3. Assign stable IDs, deterministic structural playback keys, owned random streams, and explicit clock/config inputs.
4. Build canonical snapshot/save/restore for a small headless combat world and verify byte/field equality.
5. Add hierarchical hashes: world -> subsystem -> archetype/component -> chunk/page -> entity/field.
6. Add command recording and input-only replay within the same build/content version.
7. Add side-effect journaling and verify resimulation never duplicates damage commits, audio, VFX, achievements, analytics, saves, or network sends.
8. Add owner prediction restore/replay first; expand predicted scope only from measured interaction requirements.
9. Prototype full rollback only if product requirements justify deterministic physics/world/content constraints.
10. Add snapshot-assisted archival replay, seek keyframes, schema manifests, and compatibility/migration policy.

## Verification Strategy

- Run identical seeds/commands across render rates, worker counts, job stealing patterns, debug/release builds, and supported platforms; compare per-tick hierarchical hashes.
- Restore every snapshot in a rolling window, advance one tick, and compare with uninterrupted execution.
- Roll back varying depths and require the same target hash, events, random draw counts, and entity generations.
- Randomize structural command emission order while preserving canonical keys; final state must match.
- Poison padding/uninitialized memory, randomize allocator addresses, and vary hash-map insertion order.
- Fault-test tick wraparound, late/duplicate commands, spawn/despawn during rollback, component add/remove, content generation changes, and snapshot ring overflow.
- Verify predicted/replayed effects are emitted exactly once or correctly cancelled/adjusted.
- On mismatch, automatically binary-search the first divergent tick, then descend partition hashes to the first entity/component/field and retain commands plus both values.
- Benchmark worst rollback depth in one render frame; gate fixed-step percentile, allocations, snapshot bandwidth, compression time, memory, and network bytes.
- Test replay compatibility against declared policy; reject unsupported build/content/schema combinations clearly rather than silently diverging.

## Risks and Open Decisions

- Required determinism tier and supported platform/build pairs.
- Full-world versus owner/local prediction scope.
- Authoritative physics model and dynamic-body coupling.
- Floating/fixed-point, compiler flags, transcendental math, and quantization.
- Snapshot strategy: full copy, page copy-on-write, component deltas, or hybrid.
- Canonical entity allocation and structural ordering.
- Random stream ownership and content scripting restrictions.
- Replay longevity, migration, seek interval, and storage budget.
- Hash algorithm, field scope, frequency, and security exposure.
- Side-effect policies for audio, VFX, haptics, achievements, telemetry, saves, and external services.
- Maximum rollback/resimulation budget and overload behavior.
- Partial snapshot/predicted entity dependency closure.

## Engineering Recommendations

These are engineering recommendations rather than sourced requirements.

1. Do not advertise generic “rollback.” Name the exact contract and state scope.
2. Make authoritative state a versioned canonical projection; exclude presentation but include every value that feeds a future tick.
3. Preserve deterministic results with fixed phases and ordered merges, not forced single-thread execution.
4. Capture or canonically rebuild entity allocation, structural state, random streams, timers, command queues, and relevant configuration generations.
5. Quantize at the simulation boundary when quantized values are network authority; do not simulate from higher precision and compare only after serialization.
6. Treat side effects as idempotent intents keyed by deterministic IDs and reconcile them after the final predicted/resimulated result.
7. Use hierarchical hashes and automatic first-divergence field capture from day one.
8. Implement owner prediction and snapshot correction before considering whole-world peer rollback for an FP/TP action game.
9. Keep archival replay snapshot-assisted unless long-term bit-identical code/content execution is an explicit product commitment.
10. Set hard rollback depth, CPU, memory, snapshot, event, and networking budgets with observable degradation/fallback.

## Source Links

- [GGPO — Rollback Networking SDK](https://www.ggpo.net/)
- [Unity — Netcode for Entities Prediction](https://docs.unity.cn/Packages/com.unity.netcode%401.4/manual/prediction.html)
- [Unity — Prediction Edge Cases](https://docs.unity.cn/Packages/com.unity.netcode%401.5/manual/prediction-details.html)
- [Epic Games — Character Movement Network Prediction](https://dev.epicgames.com/documentation/en-us/unreal-engine/understanding-networked-movement-in-the-character-movement-component-for-unreal-engine)
- [Epic Games — Networked Physics Overview](https://dev.epicgames.com/documentation/unreal-engine/networked-physics-overview)
- [GDC 2017 — Overwatch Gameplay Architecture and Netcode](https://gdcvault.com/play/1024001/-Overwatch-Gameplay-Architecture-and)
- [GDC 2019 — Deterministic Simulation in For Honor](https://gdcvault.com/play/1026322/Back-to-the-Future-Working)
- [GDC 2018 — Rollback Networking in Mortal Kombat and Injustice 2](https://gdcvault.com/play/1025021/8-Frames-in-16ms-Rollback)
- [GDC 2022 — Knockout City's Parallel, Deterministic, Rewindable Entity System](https://gdcvault.com/play/1027634/-Knockout-City-s-Parallel)
- [Game Developer — Rollback Networking in INVERSUS](https://www.gamedeveloper.com/design/rollback-networking-in-inversus)
- [Gaffer on Games — Deterministic Lockstep](https://gafferongames.com/post/deterministic_lockstep/)
- [Terrano and Bettner — 1500 Archers on a 28.8](https://www.gamedevs.org/uploads/1500-archers-age-of-empires-network-programming.pdf)
