# Operation Mythology Mechanics Research

**Timestamp:** 2026-07-27T18:43:40-07:00  
**Subject:** Authoritative hit zones, wounds, limb capability loss, severing, treatment, recovery, and visual-flesh separation

## Feature Overview

Locational injury is a gameplay domain layered between hit validation, damage resolution, status effects, character capability, equipment, treatment, downing, death, quests, and presentation. It must answer which stable anatomical/gameplay zone was struck, what evidence is trusted, whether damage becomes a wound, how wounds stack or progress, which capabilities are impaired, whether a limb can be disabled or severed, how treatment and recovery work, and what persists or replicates.

The baseline separates:

1. **Hit evidence:** authoritative or server-reconstructed impact with stable target generation, zone candidate, point, normal, source, damage profile, and event ID.
2. **Anatomical gameplay model:** immutable versioned zone hierarchy and adjacency, health/integrity pools, protection mappings, capability dependencies, wound rules, and severability policy.
3. **Durable injury state:** compact wounds, zone integrity bands, disabled capabilities, bleeding/pain or other status projections, treatment/recovery state, attribution, and revision.
4. **Presentation:** decals, blood, mesh swaps, deformation, dismemberment visuals, audio, animation reactions, and camera effects. Presentation reflects semantic injury state but never decides it.

This report excludes detailed soft-body/FEM simulation, gore rendering, mesh cutting, asset creation, and animation authoring. It defines the direct gameplay interface that the newly discovered shared soft-body report explicitly leaves to rigid/compound or separately validated low-dimensional proxies.

## Existing Coverage and Identified Gap

The required recursive scan succeeded before research:

- `C:\Users\steve\Desktop\GAME SKILLS`: 27 files at scan time.
- `C:\Users\steve\Desktop\EXTRA SKILS\Operation Mythology Mechanics`: 27 files at scan time, including the active `RESEARCH_INDEX.md`.

The mechanics archive already covers authoritative damage, attributes, effects, stacking, prediction, downed/bleedout/revive, equipment, inventory, interactions, traversal, save/load, networking, tags/events/commands, deterministic ordering, accessibility, and validation. However, searches found no dedicated wound, dismemberment, body-part, weak-point, or locational-damage architecture. Generic “hit zone” references do not define zone identity, injury persistence, capability dependencies, treatment, or severing.

The new shared soft-body report covers tetrahedral deformation and explicitly recommends separate low-dimensional gameplay proxies rather than using visual flesh vertices. It does not define the gameplay proxy or injury lifecycle.

The uncovered subjects are:

- stable zone IDs independent of bones, colliders, LOD, mesh, animation, or solver;
- authoritative mapping from hit evidence to zones and protection layers;
- zone integrity versus global vitality;
- discrete wound records versus aggregated status;
- impairment and capability projection for locomotion, aiming, climbing, swimming, equipment, and interaction;
- severing/detachment as an irreversible or repairable semantic transition;
- bleeding, pain, infection/complication, stun, fracture, burn, and other project-selected wound families;
- treatment reservations, consumables, interruption, stabilization, recovery, and replacement/prosthetic policy;
- same-tick damage, treatment, downing, death, revive, and sever ordering;
- party credit, friendly-fire, anti-farming, telemetry, and privacy;
- prediction, replication visibility, save/load, replay, reconnect, streaming, migration, and accessibility.

## Sourced Facts

The following are sourced facts. Recommendations later in the report are engineering synthesis.

1. Unreal Engine 5.8 `FHitResult` represents a trace hit and exposes impact point, normal, actor/component, physical material, item/element/face indices, and a bone name for skeletal meshes. Its optimized network serializer demonstrates that hit evidence is structured data, but a bone name is still engine/content identity rather than a project-stable injury-zone contract.

2. Unreal's trace documentation states that skeletal-mesh traces use the Physics Asset and can return a hit bone name. It also distinguishes line and shape traces and exposes physical material. Therefore production engines provide multiple candidate signals for zone classification, with different precision and content dependencies.

3. Unreal's Gameplay Ability System effect context can contain a `FHitResult`. This supports carrying hit evidence into an effect/damage pipeline, but the engine does not prescribe anatomical health, wounds, or capability loss.

4. Unreal's actor damage API exposes authority-only point/radial damage events with hit information. Authority-only delivery supports server-owned mutation, while the project must still define validation, ordering, zone mapping, and persistence.

5. Unity 6 collision documentation shows that collision identity may resolve to a rigidbody transform or collider transform depending on object setup. This reinforces that collider/component identity is representation-specific and should map through stable authored gameplay metadata.

6. The shared soft-body report's sourced baseline uses a low-resolution tetrahedral cage for deformation but states that gameplay uses rigid/compound or separately validated low-dimensional proxies and networks state/inputs rather than vertices. Thus visual deformation can be client-local without changing wound outcomes.

7. Microsoft Xbox Accessibility Guideline 123 recommends content warnings and customization that can reduce or remove gore and dismemberment while preserving access to the rest of the game. Its examples include a dismemberment toggle and a visual-only safe mode. This supports separating injury mechanics from sensitive presentation.

8. Xbox Accessibility Guideline 108 recommends multiple difficulty options and tunable barriers. Injury penalties, treatment timing, aiming impairment, and recovery burden can create accessibility barriers and therefore should be policy-driven rather than hardwired into visual damage.

9. No cited engine or guideline establishes one universal anatomy, damage multiplier, sever threshold, healing model, or competitive disclosure policy. Those decisions are project-specific.

## Industry-Standard API or Pattern

Use a **stable zone graph plus revisioned wound ledger and capability projection**.

### Immutable injury definition

Each character archetype references a versioned definition containing:

- stable `ZoneId` values and hierarchy such as torso, head, left arm, right arm, left leg, right leg, with optional subzones;
- zone adjacency and parent fallback;
- mappings from collision proxy IDs, authored hit volumes, sockets/bones, physical materials, and gameplay tags to stable zones;
- global vitality contribution and per-zone integrity policy;
- protection/equipment coverage slots and penetration routing;
- wound families allowed per zone and damage profile;
- severity thresholds expressed in quantized bands;
- capability dependencies and impairment curves;
- severability, detach boundary, replacement, and irreversibility policy;
- bleed/pain/complication/treatment/recovery profiles;
- replication visibility, persistence, telemetry, gore-presentation class, and migration metadata;
- hard maximum wounds per entity and per zone.

Bone names and collider IDs are import-time or runtime mapping keys, never durable save/network IDs.

### Hit-to-zone resolution

An accepted damage event carries:

- idempotent `DamageEventId`;
- attacker/causer identity and authority epoch;
- target stable ID and generation;
- fixed tick and approved rewind snapshot;
- impact point/normal/direction;
- collision proxy or hit-volume ID;
- candidate bone/material/element data;
- damage family, magnitude, penetration, impulse band, and tags;
- equipment/projectile/ability provenance.

Server resolution:

1. validate attacker, target, command, rate, range, line of sight, and historical snapshot;
2. resolve the authoritative hit proxy and target generation;
3. map to stable zone through compiled proxy metadata;
4. revalidate equipment coverage and target state at the chosen historical/current policy boundary;
5. calculate protection, penetration, global vitality damage, zone integrity damage, and wound proposal;
6. commit at the fixed damage barrier in deterministic order.

If detailed classification fails, use an explicit parent/default zone or reject according to source type. Never accept a client-supplied bone or zone without reconstruction.

### Vitality, integrity, and wounds

Keep three concepts distinct:

- **vitality:** global alive/downed/dead resource already owned by the existing damage/lifecycle architecture;
- **zone integrity:** compact quantized state such as healthy, impaired, disabled, destroyed;
- **wound records:** bounded instances with stable ID, zone, family, severity, origin event, clocks, treatment state, and revision.

Not every hit creates a wound. Definitions can aggregate minor damage into a zone meter, create wounds only at thresholds, merge compatible wounds, refresh or escalate an existing wound, or reject additional records when the cap is reached while preserving aggregate severity.

Wounds project existing gameplay tags/status effects such as bleeding, aim instability, movement penalty, interaction restriction, pain pulse, or healing modifier. The wound ledger remains the provenance/source of those projections so removal and recovery are deterministic.

### Capability dependency graph

Capabilities do not query visual bones. A compiled table maps semantic injury state to capability modifiers:

- leg impairment may change acceleration, sprint, jump, crouch transition, slope/stair limits, swimming propulsion, climbing, vault/mantle, or force a crawl;
- arm impairment may affect two-handed equipment, recoil/aim stability, reload, climb grip, carry, revive, interaction speed, or shield use;
- head/torso wounds may influence perception, stamina, breathing, concentration, or downing policy;
- severing can revoke equipment sockets and drop, transfer, destroy, or preserve attached items transactionally.

Modifiers are declared as capability masks and typed scalar channels, composed through the existing status/attribute system. They do not directly rewrite input bindings or camera perspective. FP/TP presentation reads the same capability state.

### Severing and semantic detachment

Severing is a gameplay transition, not a mesh event:

1. accepted damage produces `SeverProposal`;
2. authority validates zone severability, threshold, source tags, protection, current state, difficulty/content policy, and target generation;
3. at the commit barrier it marks the zone destroyed/severed, revokes dependent capabilities and sockets, resolves attached equipment, emits damage/status/lifecycle consequences, and records attribution;
4. presentation receives a semantic event and may show a mesh swap, hidden limb, bloodless substitute, or no gore based on user/platform settings;
5. a detached physical object is cosmetic unless explicitly promoted to a bounded gameplay item/entity with its own stable identity.

Turning off dismemberment visuals must not restore the zone or alter authoritative hitboxes. Conversely, a visual mesh separation cannot cause gameplay severing.

### Treatment, stabilization, and recovery

Treatment uses the established claimed interaction/ability transaction:

- request selects patient, wound or treatment category, item/ability, and input sequence;
- authority validates range, knowledge/visibility, permissions, wound revision, treatment compatibility, resources, patient state, exclusivity, and world readiness;
- a claim reserves the wound and required consumables;
- progress runs on an explicit clock with interruption/decay policy;
- completion revalidates, atomically consumes costs, changes wound state/severity, updates clocks and capability projections, releases claim, and emits credit.

Separate outcomes:

- stabilize prevents escalation but does not heal;
- stop bleeding removes/attenuates a projected effect;
- splint/repair changes impairment or recovery rate;
- surgery/major treatment may require a station/checkpoint;
- natural recovery advances through deadlines, not per-frame scanning;
- replacement/prosthetic restoration is an equipment/progression transaction if the fiction requires it.

Treatment is idempotent and cannot duplicate resource consumption or rewards on retry.

### Conflict ordering

At one fixed tick, resolve:

1. authority epoch, target generation, and world-state invalidation;
2. accepted damage in stable event order;
3. protection break and zone integrity changes;
4. wound merge/escalation and sever proposals;
5. lethal/downed outcome evaluation;
6. executions and explicit death policy;
7. treatment completion/stabilization;
8. recovery deadlines;
9. capability/status projection;
10. equipment drops/socket changes;
11. quest/credit, persistence, replication, and presentation.

The exact design can vary, but treatment cannot retroactively erase accepted earlier damage in the same barrier unless explicitly designed, and presentation never participates in conflict resolution.

### Multiplayer, replay, and persistence

Server owns hit-to-zone resolution and injury mutation. Clients may predict hit markers and reversible local reactions, but persistent wounds, severing, treatment, and capability loss await authority unless a specific local-player prediction path can roll back all dependent state.

Replication uses audience-filtered semantic deltas:

- owner/authorized healer may receive detailed wound family, severity, clocks, and treatment compatibility;
- teammates may receive coarse incapacitation/treatment affordances;
- enemies may receive only observable capability bands;
- spectators/replays follow product policy;
- gore settings affect presentation only and are not replicated as authority.

Save compact stable zone states and wound records, not collider, bone, deformable-vertex, decal, or detached-mesh state. Late join/load reconstructs injury first, then capabilities, equipment sockets, collision proxies, and presentation. Definition revisions require redirects, merge/split migration, or explicit fallback.

## Performance Considerations

### Asymptotic complexity

Let `H` be accepted hits this tick, `Z` zones per definition, `W` active wounds, `C` capability dependencies affected, `T` treatment/recovery deadlines, and `R` interested recipients.

- Hit-zone lookup is expected `O(1)` through compiled proxy/bone/material tables; parent fallback is bounded by shallow zone depth.
- Damage commit is `O(H log H)` if stable sorting is required, or `O(H)` with already ordered per-tick event streams.
- Wound merge is `O(wz)` for bounded wounds in one zone; hard caps prevent unbounded `O(W)` scans.
- Capability recomputation is `O(Cchanged)` via reverse dependency tables, not `O(all capabilities)`.
- Deadline processing is `O(log T)` per insertion/removal and `O(expired)` per tick with a heap or timing wheel.
- Serialization is `O(Zdirty + Wdirty)`; network dissemination is `O(R * delta size)`.

### Allocations and garbage collection

Use fixed-size per-entity zone arrays, pooled wound slots, bounded damage/wound proposal buffers, arena-backed barrier work, and timing-wheel/deadline nodes from pools. Warm combat and recovery paths allocate nothing from the general heap and trigger no managed garbage collection. When the wound cap is reached, merge or aggregate using declared policy and emit telemetry; never silently discard severity or allocate an overflow list.

### Cache behavior

Keep hot zone integrity, wound slot indices, capability dirty masks, and revisions contiguous. Store cold provenance, narrative metadata, detailed audit, localization, migration, and presentation references separately. Compile bone/proxy-to-zone tables into dense hashes or sorted arrays. Batch damage by target and keep status/capability projection tables structure-of-arrays. Avoid pointer chasing into skeletal or soft-body representation during damage commit.

### Update frequency

Hit resolution and commit occur at the fixed combat step. Wound progression and recovery use event/deadline scheduling rather than per-frame scans. Capability projections update only when injury revisions change. Treatment progress updates at the interaction/ability fixed cadence. Persistence is dirty-driven and asynchronous. Network sends state deltas on semantic changes plus occasional compact checkpoints; presentation may interpolate at render rate without authority.

### Concurrency

Historical hit queries read immutable world snapshots. Different targets resolve in parallel; one logical writer commits injuries per target. Damage proposals are immutable and stable-sorted at the barrier. Treatment and recovery jobs stage proposals against expected wound revisions. Capability/status/equipment changes commit after injury state, preventing concurrent cross-domain mutation. Save/network extraction reads committed snapshots. Visual deformation never writes gameplay state.

### Fixed-step cost

Budget accepted hits, zone resolutions, wound proposals, sever checks, capability changes, treatment completions, deadlines, and emitted events per tick. Critical lethal, sever, and capability-revocation commits cannot be dropped. Under overload, coalesce minor compatible wounds, defer noncritical audit/presentation, and preserve aggregate damage. Test area damage and fragmentation against many zones/targets without multiplying work by visual vertices.

### Serialization cost

Serialize definition ID/revision, injury revision, compact zone bands, bounded wounds, clocks/deadlines, treatment state, attribution retention class, and semantic sever flags. Use varints, bit fields, quantized severity, and stable IDs. Do not serialize bones, collider pointers, per-vertex deformation, decals, gore meshes, ragdoll pose, or transient hit results. Incremental saves write dirty entities; migrations validate redirects and wound-family compatibility.

### Networking cost

Do not replicate every hit result or visual wound. Replicate authoritative global health through existing channels and audience-filtered injury deltas when a zone band, wound, sever state, treatment, or capability projection changes. Quantize severity and deadlines. Owner detail can be richer than opponent detail. Interest is entity/party/medical/objective based. Track bytes per injured entity, wounds per snapshot, correction/denial rate, late-join reconstruction time, and privacy redactions.

## Pros and Cons

### Stable zone graph and wound ledger

Pros:

- deterministic, inspectable, saveable, and networkable;
- independent of skeleton, mesh, LOD, and deformation backend;
- supports treatment provenance and capability restoration;
- allows sensitive-content presentation settings;
- bounded by authored zone/wound caps.

Cons:

- requires authoring and migration;
- creates balancing complexity;
- can burden players if penalties are too granular;
- mappings must remain correct across character variants.

### Global health plus temporary status only

Pros:

- simple, cheap, accessible, and easy to balance;
- minimal persistence/network state.

Cons:

- cannot represent persistent localized injury, treatment selection, severing, or equipment/socket consequences;
- weaker tactical and narrative specificity.

Recommendation: allow archetypes/modes to select this simpler profile through the same API.

### Per-bone or per-vertex authority

Pros:

- fine apparent precision and direct asset correspondence.

Cons:

- content/LOD/backend dependent;
- costly to save, replicate, and migrate;
- fragile across animation and deformation;
- easy for presentation changes to alter gameplay.

Recommendation: use bones/colliders only as evidence mapped to stable zones.

### Predicted injury

Pros:

- immediate feedback.

Cons:

- rollback touches abilities, equipment, locomotion, camera, status, and objectives;
- denial can be disorienting;
- exposes hidden opponent state.

Recommendation: predict presentation and hit confirmation cautiously; commit persistent injury and severing on authority.

## ECS Architectural Integration

Components:

- `InjuryProfileRef`: definition ID/revision and migration generation.
- `ZoneIntegrityState`: fixed/pooled compact zone bands and dirty mask.
- `WoundLedgerHandle`: generation-tagged range in a wound pool.
- `InjuryRevision`: authority epoch and monotonic entity injury revision.
- `CapabilityImpairment`: projected masks/scalars with source revision.
- `SeveredZoneState`: compact semantic flags and equipment/socket consequences.
- `TreatmentClaim`: claimant, wound/category, item/ability, expiry, progress policy.
- `InjuryAttribution`: bounded event/attacker provenance according to retention class.
- `InjuryReplicationClass`: owner/team/enemy/spectator visibility policy.
- `InjuryPersistenceState`: dirty revision and checkpoint/journal status.

Resources:

- `InjuryDefinitionRegistry`;
- `HitProxyToZoneTable`;
- `DamageProposalBuffer`;
- `WoundPool`;
- `CapabilityDependencyTable`;
- `InjuryDeadlineWheel`;
- `TreatmentClaimRegistry`;
- `InjuryConflictPolicy`;
- `InjuryPersistenceJournal`;
- `InjuryReplicationBudget`;
- `InjuryTelemetry`.

Systems:

1. `AuthoritativeHitResolutionSystem`
2. `ProtectionAndPenetrationSystem`
3. `ZoneDamageProposalSystem`
4. `InjuryCommitSystem`
5. `WoundMergeEscalationSystem`
6. `SeverTransitionSystem`
7. `LifecycleOutcomeAdapterSystem`
8. `CapabilityImpairmentProjectionSystem`
9. `TreatmentClaimAndProgressSystem`
10. `InjuryRecoveryDeadlineSystem`
11. `EquipmentSocketConsequenceSystem`
12. `InjuryQuestCreditSystem`
13. `InjuryPersistenceSystem`
14. `InjuryReplicationSystem`
15. `InjuryPresentationProjectionSystem`
16. `InjuryValidationTelemetrySystem`

The damage domain owns accepted damage evidence; injury owns zones/wounds; lifecycle owns alive/downed/dead; status/attributes own projected effects; equipment owns items; interaction/abilities own treatment execution; presentation owns gore and deformation. Typed proposals and committed events preserve boundaries.

## Component, System, Resource, and Event Interfaces

Conceptual interfaces:

- `SubmitDamageEvidence(DamageEventId, Source, TargetId, TargetGeneration, FixedTick, RewindTick, HitProxyId, ImpactPoint, ImpactNormal, DamageProfile, Magnitude, Penetration, Tags)`
- `ResolveHitZone(DamageEventId, InjuryDefinitionRevision, ProxyId, CandidateBone, MaterialId, ElementId)`
- `ProposeZoneDamage(TargetId, ExpectedInjuryRevision, ZoneId, VitalityDelta, IntegrityDelta, WoundProposal, Attribution)`
- `CommitInjuryRevision(TargetId, NewRevision, ZoneDeltas, WoundDeltas, SeverDeltas, FixedTick)`
- `WoundCreated(WoundId, TargetId, ZoneId, Family, SeverityBand, OriginEventId, Revision)`
- `WoundEscalated(WoundId, FromSeverity, ToSeverity, Reason, Revision)`
- `ZoneCapabilityChanged(TargetId, ZoneId, CapabilityDelta, SourceRevision)`
- `ZoneSevered(TargetId, ZoneId, SeverEventId, Attribution, EquipmentConsequences, Revision)`
- `RequestTreatment(RequestId, HealerId, PatientId, WoundOrCategory, TreatmentDefinition, ItemOrAbilityId)`
- `TreatmentClaimed(ClaimId, WoundId, ExpectedRevision, ExpiryTick)`
- `TreatmentCompleted(ClaimId, WoundId, Result, NewWoundState, CostTransactionId, Revision)`
- `RecoveryDeadlineReached(WoundId, ExpectedRevision, DeadlineId)`
- `SerializeInjuryState(TargetId, DefinitionRevision, InjuryRevision, ZoneBands, Wounds, SeverFlags, Deadlines)`
- `ApplyInjuryCheckpoint(TargetId, ExpectedDefinitionRevision, Record)`

Typed failures include stale target/injury/wound revision, duplicate damage, invalid proxy mapping, protected zone, unsupported wound, wound capacity merged, nonseverable zone, presentation-only sever disabled, treatment incompatible, already claimed, resource unavailable, interrupted, patient state invalid, migration required, privacy denied, and capacity fallback.

## Integration Plan

1. Define the minimum anatomical zone set and whether persistent wounds/severing ship at all.
2. Compile stable zone mappings from hit proxies, physics assets, materials, and parent fallbacks.
3. Extend authoritative damage evidence with stable proxy metadata and server reconstruction.
4. Implement zone integrity and bounded wound ledgers behind the existing damage/lifecycle barrier.
5. Project impairment through existing tags, attributes, movement capabilities, interactions, and abilities.
6. Integrate armor/equipment coverage and transactional socket/item consequences.
7. Implement treatment as claimed, interruptible, idempotent interaction/ability transactions.
8. Add deadlines for bleed/escalation/recovery without per-frame entity scans.
9. Integrate downing, death, revive, respawn, checkpoint, and difficulty policies.
10. Add audience-filtered replication, save/load, replay, reconnect, and definition migration.
11. Build presentation adapters for wounds, mesh variants, deformation, bloodless mode, audio, animation, camera, and UI.
12. Add accessibility options, content warnings, alternate cues, penalty tuning, and objective alternatives.
13. Certify every character/equipment variant with hit-zone coverage, capability dependencies, and migration metadata.

## Verification Strategy

- Golden tests map every authored hit proxy/bone/material/element to the expected stable zone across character variants, LODs, poses, physics assets, and content revisions.
- Server reconstruction tests reject client-supplied zone spoofing and validate latency/rewind boundaries.
- Property tests sweep damage thresholds, protection, penetration, wound merge/escalation, sever conditions, and parent fallback.
- Exhaustively permute same-tick damage, treatment, recovery, severing, downing, death, revive, equipment break/drop, disconnect, and save.
- Duplicate/reorder damage and treatment messages; vitality, wounds, costs, rewards, and attribution remain idempotent.
- Test wound caps, event overflow, deadline capacity, missing mappings, definition tombstones, and safe aggregation.
- Verify each injury band's effects on walking, sprinting, crouching, jumping, swimming, climbing, mantling, ladders, ledges, aiming, reload, carry, revive, equipment, interaction, and abilities.
- Switch FP/TP during every injury/treatment state; authority is unchanged.
- Save/load and late join after every zone band, wound state, sever state, claim state, and deadline boundary.
- Test packet loss, reordering, privacy audiences, reconnect, spectators, replay, and visual-gore settings.
- Sweep entities, hits, zones, wounds, deadlines, treatments, capability dependencies, and recipients; record fixed-step time, allocations/GC, cache misses, serialization bytes, and network bytes.
- Accessibility tests cover blood/gore/dismemberment toggles, nonvisual injury cues, remappable treatment controls, simplified timing, penalty/difficulty profiles, and mission bypass/alternatives.

## Risks and Open Decisions

- Does the game need locational injury, or only weak-point multipliers and temporary effects?
- Which zones and subzones are stable across all body plans?
- How do armor, shields, clothing, transformations, mounts, vehicles, and shapeshifting alter mappings?
- Which damage families create wounds, and which only change vitality?
- Are zone integrity and global vitality coupled, independent, or hybrid?
- Which wound families, severity bands, clocks, stacking, and caps ship?
- Which impairments affect movement, input timing, aim, perception, equipment, or cognition?
- Can injury ever remove player agency or create unwinnable states?
- Which zones are severable, by which sources, and at what difficulty/content settings?
- Is severing permanent, checkpoint-scoped, revive-reset, repairable, or replaceable?
- What happens to equipped items and collision/hit proxies after severing?
- Does treatment stop, reduce, transfer, or remove each wound?
- Which treatment actions are exclusive, cooperative, interruptible, or consumptive?
- Who receives treatment and injury credit, and how is farming prevented?
- What detail is visible to owners, teammates, enemies, spectators, replays, telemetry, and support staff?
- What data retention and privacy policy applies to injury attribution?
- How are saves migrated when zones or wounds split/merge?
- Which accessibility and sensitive-content options are cosmetic versus mechanical?
- What are the hard hit, wound, deadline, treatment, serialization, and networking budgets?

## Engineering Recommendations

These are engineering recommendations, not sourced facts.

1. Create a stable injury-zone graph and bounded wound ledger independent of skeleton, mesh, collider, LOD, and soft-body representation.
2. Treat hit bone/material/component data as evidence mapped by authority to stable zone IDs; never trust a client-supplied zone.
3. Separate global vitality, zone integrity, wound records, and projected status/capability effects.
4. Commit injury at the existing deterministic damage barrier using idempotent event IDs and target revisions.
5. Compile reverse capability dependencies so injury updates only affected locomotion, equipment, interaction, and ability channels.
6. Make severing an authoritative semantic transition; visual dismemberment is a replaceable presentation selected by accessibility/content settings.
7. Never use deformable vertices, decals, mesh cuts, or detached visual pieces as gameplay authority.
8. Implement treatment through existing claimed interaction/ability transactions with reservation, revalidation, atomic cost/state commit, and interruption policy.
9. Use deadlines for bleeding, escalation, treatment, and recovery rather than per-frame wound scans.
10. Audience-filter replication and keep opponent disclosure coarse; persist stable semantic injury only.
11. Cap wounds per zone/entity and merge deterministically while preserving aggregate severity and provenance requirements.
12. Make difficulty and accessibility profiles tune penalties, timing, assistance, and sensitive presentation without corrupting authoritative state.
13. Ship hit-zone visualizers, wound inspectors, capability-source traces, conflict logs, migration tools, headless mapping tests, race/fault tests, and privacy/network budgets.
14. Default to a small zone set and reversible impairment; add permanent severing only after narrative, balance, accessibility, save migration, and content costs are accepted.

## Source Links

1. Epic Games, **FHitResult API — Unreal Engine 5.8**  
   https://dev.epicgames.com/documentation/unreal-engine/API/Runtime/Engine/FHitResult
2. Epic Games, **Traces Overview — Unreal Engine 5.8**  
   https://dev.epicgames.com/documentation/unreal-engine/traces-in-unreal-engine---overview
3. Epic Games, **Make Hit Result — Unreal Engine 5.8**  
   https://dev.epicgames.com/documentation/en-us/unreal-engine/BlueprintAPI/Collision/MakeHitResult
4. Epic Games, **Gameplay Effect Context GetHitResult — Unreal Engine 5.8**  
   https://dev.epicgames.com/documentation/en-us/unreal-engine/API/Plugins/GameplayAbilities/FGameplayEffectContext/GetHitResult
5. Epic Games, **AActor Damage API — Unreal Engine 5.8**  
   https://dev.epicgames.com/documentation/en-us/unreal-engine/API/Runtime/Engine/AActor
6. Epic Games, **Get Closest Point on Physics Asset — Unreal Engine 5.8**  
   https://dev.epicgames.com/documentation/en-us/unreal-engine/BlueprintAPI/Components/SkeletalMesh/GetClosestPointOnPhysicsAsset
7. Unity Technologies, **Collision.transform — Unity 6**  
   https://docs.unity3d.com/6000.0/Documentation/ScriptReference/Collision-transform.html
8. Microsoft, **Xbox Accessibility Guideline 123: Mental health and sensitive content**  
   https://learn.microsoft.com/en-us/xbox/accessibility/xbox-accessibility-guidelines/123
9. Microsoft, **Xbox Accessibility Guideline 108: Game difficulty options**  
   https://learn.microsoft.com/en-us/xbox/accessibility/xbox-accessibility-guidelines/108
10. Microsoft, **Gaming and Disability Player Experience Guide**  
    https://learn.microsoft.com/en-us/xbox/accessibility/gadpeg

