# Operation Mythology Mechanics Research

**Batch timestamp:** 2026-07-27T01:48:51-07:00  
**Subject:** Prediction-safe advanced traversal: mantling, vaulting, climbing, ladders, swimming, ledges, and traversal chaining  
**Scope:** Generic modular ECS; data-oriented runtime; first- and third-person compatible; no production code

## Feature Overview

Advanced traversal extends the baseline character controller beyond grounded walking, falling, jumping, slopes, stairs, and crouching. It must recognize usable world geometry, choose a traversal action, reserve a stable target, move the authoritative collision shape through a validated path, coordinate animation-facing alignment, and exit cleanly into another movement mode.

The core pipeline is:

`intent -> candidate query -> geometric classification -> feasibility validation -> candidate scoring -> authoritative acceptance -> traversal state -> constrained motion -> exit validation`

The feature set includes:

- low obstacle step-up versus vault versus mantle;
- ledge catch, hang, shimmy, pull-up, drop, and corner transfer;
- free climbing or authored climbing surfaces;
- ladders and climbable rails;
- swimming at surface, underwater, and water entry/exit;
- traversal chaining, such as sprint-to-vault-to-wall-run or swim-to-ledge-exit;
- moving and rotating traversal targets;
- FP/TP presentation that consumes the same gameplay result.

Traversal is gameplay-owned. Animation may provide a motion curve or alignment window, but it cannot decide collision eligibility, authority, stamina cost, target reservation, or final position.

## Existing Coverage and Identified Gap

At run start, `C:\Users\steve\Desktop\GAME SKILLS` contained eight Markdown reports/index files. They cover renderer architecture, GPU memory/streaming, virtual assets, ECS archetypes/job scheduling, and temporal upscaling. None covers traversal.

The previously saved mechanics input report defines fixed-tick `PlayerCommand` intent. Physics research defines fixed-step and rollback boundaries. Animation research defines gameplay synchronization, while world/AI research defines streaming readiness. Those are dependencies, not substitutes for a traversal contract.

The new dedicated output folder, `C:\Users\steve\Desktop\EXTRA SKILS\Operation Mythology Mechanics`, was empty when scanned. Therefore no traversal claims or recommendations exist there.

The identified gap is a generic traversal-query and execution architecture that avoids per-feature raycast scripts, remains stable on irregular geometry and moving bases, supports prediction/reconciliation, and separates gameplay displacement from FP/TP camera and animation presentation.

## Sourced Facts

These are sourced facts rather than Operation Mythology recommendations:

- Unreal Engine 5.8 Mover models movement as exactly one active movement mode, optional layered moves, modifiers, instant effects, and transitions. Epic lists walking, falling, and climbing as examples, and describes rollback-networking support; Mover remains experimental. [Epic: Mover Features and Concepts](https://dev.epicgames.com/documentation/unreal-engine/mover-features-and-concepts-in-unreal-engine) and [Epic: Mover](https://dev.epicgames.com/documentation/en-us/unreal-engine/mover-in-unreal-engine)
- Unreal Character Movement exposes walking, falling, swimming, flying, and custom movement modes. Swimming is described as movement through a fluid volume with gravity and buoyancy. [Epic: EMovementMode](https://dev.epicgames.com/documentation/en-us/unreal-engine/API/Runtime/Engine/EMovementMode)
- Epic Motion Warping dynamically adjusts root motion toward named targets during authored windows. Its mantling example aligns a character to an obstacle and can selectively warp translation and rotation. [Epic: Motion Warping](https://dev.epicgames.com/documentation/en-us/unreal-engine/motion-warping-in-unreal-engine)
- Epic states that enabling certain root-motion modes can move animation-graph work to the game thread. This is a relevant concurrency/performance cost when choosing animation-driven traversal. [Epic: Root Motion](https://dev.epicgames.com/documentation/en-us/unreal-engine/root-motion-in-unreal-engine)
- NVIDIA PhysX character-controller documentation describes automatic stepping, slope limits, non-walkable modes, and capsule climbing modes. It warns that a capsule may climb higher than its configured step offset due to the interaction of capsule radius, step offset, and displacement magnitude. [NVIDIA PhysX: Character Controllers](https://docs.nvidia.com/gameworks/content/gameworkslibrary/physx/guide/3.3.4/Manual/CharacterControllers.html)
- Unity’s Character Controller is intended for FP/TP control without rigid-body dynamics. It slides along walls, handles stairs below a step offset, and limits traversable slopes. Unity also warns that too-small skin width can cause sticking. [Unity: Character Controller](https://docs.unity.cn/Manual/class-CharacterController.html)
- Massive Entertainment’s GDC 2024 traversal presentation describes a generic, nearly markup-free system for step-ups and mantles in dense irregular environments, motivated by the cost of traditional markup. [GDC: Obstacle Traversal in the Organic World of Pandora](https://gdcvault.com/play/1034304/Obstacle-Traversal-in-the-Organic)
- Guerrilla’s GDC presentation on *Horizon Zero Dawn* covers multiple traversal mechanics specifically from the boundary between gameplay code and animation. [GDC: Player Traversal Mechanics in Horizon Zero Dawn](https://www.gdcvault.com/play/1024699/Player-Traversal-Mechanics-in-the)

## Industry-Standard API or Pattern

### One primary movement mode

Use one primary movement mode at a time:

- `Grounded`
- `Airborne`
- `Swimming`
- `Ladder`
- `LedgeHang`
- `SurfaceClimb`
- `TraversalAction`
- `Disabled`

Temporary impulses, knockback, conveyor/base motion, and animation displacement are bounded layered moves, not nested primary modes. Mode changes occur through explicit transition records containing source mode, target mode, effective tick, reason, and required state payload.

### Query, classify, validate, score

Traversal detection uses a shared query service rather than feature-specific casts:

1. Broad candidate query in the intent/velocity corridor.
2. Identify approach surface and surface normal.
3. Search for top/landing or attachment surface.
4. Validate clearance for the collision capsule along the entry, action, and exit path.
5. Validate material/tags, height/depth/width, slope, water state, moving-base policy, stamina/ability gates, and authority.
6. Score candidates by intent alignment, reach, height, continuity, camera/aim bias, and current movement.
7. Apply deterministic tie-breaking using stable geometry/entity IDs and quantized metrics.

Return data, not behavior. A `TraversalCandidate` records type, anchors, normals, dimensions, supporting entity/base ID, geometry revision, score terms, query tick, and validation flags.

### Traversal target and trajectory

Accepted candidates become immutable `TraversalTarget` records. Use anchors:

- approach/contact;
- hand/ledge or ladder attachment;
- body/capsule alignment;
- apex or clearance;
- landing/exit.

Gameplay defines a swept collision trajectory or constrained solver rule. Animation maps authored contact phases onto those anchors. If motion warping is used, clamp translation/rotation warp and verify every simulation segment; never teleport the collider to an animation target without clearance validation.

### Authored, procedural, and hybrid surfaces

- **Authored links/volumes:** predictable, cheap, designer-controlled; costly to maintain and poor for dynamic geometry.
- **Procedural geometry queries:** broad coverage and lower markup; harder to stabilize on noisy meshes.
- **Hybrid:** procedural candidate discovery plus optional authored traversal metadata, exclusions, preferred anchors, and semantic constraints.

Use hybrid as the default. Authoring should constrain or enhance valid geometry rather than being required for every ordinary mantle.

### Mode-specific rules

**Mantle/vault:** classify primarily by obstacle height, depth, landing clearance, approach speed, and intent. A low thin obstacle may vault; a tall surface with reachable top may mantle. Revalidate landing before commit and before exit.

**Ledge:** store a ledge tangent, outward normal, anchor parameter, and supporting geometry revision. Shimmy advances along a sampled/represented ledge manifold with clearance checks. Corner transitions require a new target, not blind tangent continuation.

**Ladder:** use an authored or procedurally recognized climb frame with axis, normal, rung/continuous coordinate, mount zones, top/bottom exits, occupancy policy, and base identity. Motion is one-dimensional plus bounded lateral dismount.

**Swimming:** sample water membership and surface information through a water-query interface. Separate underwater 3D movement, surface constraint, buoyancy/vertical control, and exit-to-ground/ledge transitions. Water visuals are not authoritative volume data.

## Performance Considerations

### Asymptotic complexity

Let `C` be broad-phase candidates, `Q` narrow physics queries per candidate, `K` candidates retained after pruning, `I` sweep/solver iterations, `P` predicted players, and `R` resimulated ticks.

- Broad phase is normally approximately `O(log N + C)` in a spatial acceleration structure containing `N` shapes.
- Naive evaluation is `O(C * Q)`; cap `C`, early-reject by tags/direction, and retain a small top-`K`.
- Candidate scoring is `O(K)`, with `K` fixed and small.
- Active traversal integration is `O(I)` per character per fixed tick with a hard iteration bound.
- Rollback cost is `O(P * R * (Q + I))`; history or deterministic query replay must be bounded.
- Authored ladder/link lookup should be `O(log L + C_l)` spatially, not a scan of all `L` traversal objects.

### Allocations and garbage collection

The warm traversal path must allocate zero heap memory. Use fixed-capacity candidate arrays, batched query buffers, value-type targets, ring histories, and precompiled traversal profiles. Candidate overflow must be counted and deterministically truncated.

Do not allocate per-hit objects, dynamic query lists, animation callback payloads, or debug strings. Debug geometry writes compact records to a bounded ring. Rare authoring/editor validation can allocate outside gameplay.

### Cache behavior

Store hot per-character mode state, target anchors, elapsed/remaining fixed ticks, and collision parameters contiguously. Keep animation asset references, debug labels, and authored metadata cold.

Batch queries by phase and shape where the physics backend benefits. Stable traversal profiles should be small immutable tables. Avoid pointer-heavy polymorphic mode objects in the hot ECS loop; use mode IDs plus compact state unions/slabs.

### Update frequency

Do not run full mantle/climb discovery for every character every render frame. Use:

- fixed-tick evaluation for player candidates;
- intent-, speed-, and proximity-gated queries;
- lower-frequency background hints for UI/AI;
- cached candidates with short expiry and geometry revision checks;
- immediate revalidation at authoritative acceptance and exit.

Camera-only ledge indicators may update at presentation rate but cannot authorize traversal.

### Concurrency

Broad queries and scoring can run in jobs against a stable physics/query snapshot. Candidate publication and mode transitions occur at a fixed-step barrier. Moving-base transforms must be read from the same simulation tick as the query.

Animation consumes a committed traversal target and produces presentation pose or a bounded displacement proposal. It must not mutate ECS movement state from an animation worker callback.

### Fixed-step cost

Traversal must have a known maximum query and sweep budget per character. Long hitches cannot increase the number of subqueries without limit. Divide long displacement into bounded swept segments or a conservative continuous path check.

Do not evaluate gameplay collision from sampled animation at render frequency. Convert authored root motion to a fixed-tick curve or deterministic displacement proposal and validate it in the movement step.

### Serialization cost

Persist/rollback:

- primary mode and substate;
- target type and stable supporting entity/geometry revision;
- quantized anchors/frame;
- action/profile ID;
- start/effective tick and normalized fixed-tick phase;
- velocity, capsule state, stamina/cost state;
- layered-move state and event sequence.

This is `O(1)` per traversing character per history tick. Do not serialize raw physics hit pointers, animation object addresses, or transient query buffers. Save/load may restore only supported stable modes; unsafe mid-action saves can restart from a validated anchor.

### Networking cost

Send input commands normally. On acceptance, replicate compact traversal action/target identity, start tick, and quantized anchor data when clients cannot reconstruct it reliably. Server validates candidates independently or against server query state.

Bandwidth is `O(action starts + corrections)`, not `O(frame rate)`. Moving/dynamic targets may require base transform history already needed by character prediction. Use unreliable redundant movement commands plus reliable/sparse authoritative traversal acceptance where appropriate.

## Pros and Cons

### Pros

- Shared candidates prevent duplicated raycast logic across mantle, vault, ladder, ledge, and water exit.
- One-mode-plus-layered-moves maps cleanly to prediction and replay.
- Hybrid procedural/authored detection balances coverage and designer control.
- Stable targets make animation, networking, telemetry, and debugging consume the same decision.
- Perspective-independent execution supports both FP and TP.
- Bounded arrays and query budgets make cost predictable.

### Cons

- Irregular and moving geometry makes candidate stability difficult.
- Procedural queries require extensive adversarial environment testing.
- Root-motion alignment can conflict with collision, prediction, and worker-thread animation.
- Multiplayer target replication and moving-base history add state.
- A unified framework can become over-generalized if traversal types are not allowed specialized validators.
- FP camera comfort sometimes requires presentation that intentionally diverges from body motion.

## ECS Architectural Integration

Suggested fixed-step system order:

1. `TraversalIntentSystem`
2. `TraversalBroadphaseQuerySystem`
3. `TraversalCandidateBuildSystem`
4. `TraversalCandidateScoreSystem`
5. `TraversalAuthorityValidationSystem`
6. `MovementModeTransitionSystem`
7. `TraversalMovementSystem`
8. `CharacterCollisionSolveSystem`
9. `TraversalExitSystem`
10. `TraversalEventSystem`
11. `AnimationTraversalProjectionSystem`
12. `TraversalTelemetrySystem`

Queries operate against a read-only physics snapshot. Accepted transitions and entity changes use command buffers at a simulation barrier. FP/TP cameras read traversal presentation data only; they do not change anchors, collision trajectories, or completion.

AI may submit the same semantic traversal intent and consume the same targets. Navigation links may suggest candidate locations but do not bypass physical validation.

## Component, System, Resource, and Event Interfaces

### Components

`MovementModeState`

- mode ID and substate;
- entry tick;
- mode-local state handle;
- transition sequence.

`TraversalIntent`

- requested action family or automatic policy;
- movement/aim direction;
- press/hold tick;
- assist strength;
- source command sequence.

`TraversalCandidateSet`

- fixed candidate count;
- candidate records;
- query tick;
- physics/world revision;
- overflow flag.

`ActiveTraversal`

- action/profile ID;
- target ID and supporting entity;
- geometry/base revision;
- quantized anchor frame;
- start tick and phase;
- exit policy;
- cost/event sequence;
- prediction/confirmation flags.

`WaterMovementState`

- water body ID;
- immersion and surface height/normal;
- flow velocity;
- buoyancy/vertical intent;
- breath/status interface handle.

`ClimbSurfaceState`

- surface/ladder ID;
- local coordinate;
- tangent/up/normal frame;
- occupancy/reservation token;
- allowed exits.

### Resources

`TraversalProfileDatabase`: geometry ranges, query templates, scoring weights, trajectory rules, costs, camera/presentation keys, and network policy.

`TraversalQueryService`: batched shape casts, overlaps, distance/clearance tests, water queries, stable hit IDs, and snapshot revision.

`TraversalTargetRegistry`: authored ladders/rails/climb areas, exclusions, preferred anchors, semantic tags, revisions, and moving-base association.

`TraversalBudget`: per-tick query, candidate, sweep, resimulation, and debug limits with priority policy.

`TraversalHistory`: fixed rings for mode/target/phase and query evidence needed by prediction diagnostics or replay.

### Events

- `TraversalCandidateChanged` — local/presentation hint only.
- `TraversalRequested`
- `TraversalAccepted { entity, action, target, startTick, sequence }`
- `TraversalRejected { reason, sequence }`
- `TraversalPhaseChanged`
- `TraversalContactReached`
- `TraversalCompleted`
- `TraversalInterrupted`
- `MovementModeChanged`
- `WaterEntered` / `WaterExited`
- `LedgeAcquired` / `LedgeReleased`

Events that can replay under prediction carry tick and stable sequence IDs. Presentation deduplicates them.

## Integration Plan

1. Define movement-mode and layered-move contracts shared with baseline locomotion.
2. Define stable physics-hit, supporting-entity, water-body, and authored-target identities.
3. Build the candidate/query schema and deterministic scoring/tie-breaking.
4. Implement mantle/vault first on static geometry with capsule-swept entry/action/exit validation.
5. Add animation target projection and bounded motion-warp interface after gameplay motion passes tests.
6. Add moving bases and geometry revision invalidation.
7. Add ledge hang/shimmy/corners, then authored ladders and climb surfaces.
8. Add swimming, surface constraint, currents, dive, and water-exit candidates.
9. Integrate command history, authoritative validation, correction, replay hashes, and event deduplication.
10. Add FP/TP camera profiles, accessibility assists, AI/nav consumers, authoring diagnostics, and performance gates.

## Verification Strategy

### Geometry matrix

Test obstacle height/depth/width boundaries, convex/concave corners, thin rails, bevels, curved surfaces, mesh seams, stairs, steep slopes, low ceilings, overhangs, holes, and invalid landings. Sweep exact threshold values above and below every profile limit.

### Dynamic cases

Test translating/rotating/elevating platforms, disappearing targets, doors closing during action, target revision changes, other characters blocking exits, water level changes, and streaming unload denial.

### Timing and input

Test every render/fixed phase offset, low/high frame rates, catch-up ticks, buffered jump/traverse input, hold versus tap, cancel windows, stamina exhaustion, damage interruption, and chained actions.

### Multiplayer and determinism

- Run client/server queries under latency, jitter, loss, and moving-base delay.
- Force accept/reject disagreement and verify correction returns to a valid non-penetrating state.
- Replay identical command/query histories and compare state hashes.
- Verify action events and costs occur exactly once after resimulation.
- Fuzz anchor quantization and target IDs.

### Performance

- Assert zero steady-state allocations/GC.
- Measure query count, candidate count, cache hit/expiry, rejection reason, sweep iterations, job latency, resimulation cost, and network bytes.
- Stress many candidates and prove deterministic truncation.
- Gate maximum traversal cost per local/predicted/AI character.

### FP/TP and accessibility

Switch perspective during every traversal phase without changing gameplay state. Test camera collision, pitch/roll comfort, head-bob reduction, auto-mantle/hold-to-climb options, input simplification, timing assists, and cancel accessibility.

## Risks and Open Decisions

- **Detection philosophy:** mostly procedural, authored, or hybrid; hybrid is recommended but content scale may alter the balance.
- **Auto versus explicit traversal:** decide which actions trigger from movement intent and which require a button.
- **Root motion authority:** animation curve, gameplay curve, or hybrid warping needs a project-wide rule.
- **Mid-action retargeting:** locked target is deterministic; adaptive retargeting handles moving geometry better but complicates prediction.
- **Free climbing:** arbitrary geometry greatly expands query, authoring, animation, and navigation scope.
- **Ledge representation:** sampled procedural manifold versus authored spline/graph.
- **Ladder occupancy:** allow overlap, reserve lanes, or serialize users.
- **Swimming physics:** arcade velocity control versus buoyancy/current-heavy model.
- **Water authority:** define how water volumes, surface waves, and currents are represented in deterministic simulation.
- **Save policy:** allow mid-traversal saves or defer to stable anchors.
- **AI integration:** whether traversal targets become persistent nav links or are evaluated locally.
- **Camera comfort:** FP body motion, camera decoupling, roll, forced facing, and motion-sickness settings need user testing.

## Engineering Recommendations

1. Use one active movement mode plus serializable layered moves and explicit tick-addressed transitions.
2. Create one shared candidate pipeline—query, classify, validate, score, accept—for all traversal families.
3. Use a hybrid geometry approach: procedural ordinary mantle/vault discovery plus authored metadata, exclusions, ladders, and exceptional routes.
4. Make accepted `TraversalTarget` data immutable and generation/revision checked. Revalidate immediately before commit and exit.
5. Keep gameplay collision authoritative. Animation supplies pose and bounded displacement/warp proposals but never bypasses sweeps.
6. Use fixed-capacity candidate/query/history storage, deterministic tie-breaking, and hard per-tick budgets.
7. Store moving-target anchors in target-local coordinates with authoritative transform history.
8. Implement static mantle/vault before ledges, ladders, free climbing, and swimming; validate the framework with the smallest representative vertical slice.
9. Make FP/TP differences presentation-only and expose comfort/assist policies without changing authoritative target geometry.
10. Build query visualization, rejection telemetry, adversarial geometry tests, replay hashes, and network correction tests before mass content production.

## Source Links

1. Epic Games, [Mover Features and Concepts](https://dev.epicgames.com/documentation/unreal-engine/mover-features-and-concepts-in-unreal-engine)
2. Epic Games, [Mover in Unreal Engine 5.8](https://dev.epicgames.com/documentation/en-us/unreal-engine/mover-in-unreal-engine)
3. Epic Games, [EMovementMode](https://dev.epicgames.com/documentation/en-us/unreal-engine/API/Runtime/Engine/EMovementMode)
4. Epic Games, [Motion Warping](https://dev.epicgames.com/documentation/en-us/unreal-engine/motion-warping-in-unreal-engine)
5. Epic Games, [Root Motion](https://dev.epicgames.com/documentation/en-us/unreal-engine/root-motion-in-unreal-engine)
6. NVIDIA, [PhysX Character Controllers](https://docs.nvidia.com/gameworks/content/gameworkslibrary/physx/guide/3.3.4/Manual/CharacterControllers.html)
7. Unity Technologies, [Character Controller Component Reference](https://docs.unity.cn/Manual/class-CharacterController.html)
8. GDC/Massive Entertainment, [Obstacle Traversal in the Organic World of Pandora](https://gdcvault.com/play/1034304/Obstacle-Traversal-in-the-Organic)
9. GDC/Guerrilla Games, [Player Traversal Mechanics in Horizon Zero Dawn](https://www.gdcvault.com/play/1024699/Player-Traversal-Mechanics-in-the)

