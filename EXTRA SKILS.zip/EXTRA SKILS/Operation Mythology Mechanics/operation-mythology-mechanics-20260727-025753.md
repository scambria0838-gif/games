# Operation Mythology Mechanics Delta Research — Authoritative Gameplay Command Trust Boundary

**Timestamp:** 2026-07-27T02:57:53-07:00  
**Scope:** Client-command ingress, authenticated participant binding, object and capability authorization, schema and epoch validation, anti-replay sequencing, authoritative state checks, cost-aware budgets, overload protection, cheat evidence, privacy, ECS integration, performance, and adversarial verification.

## Feature Overview

Every multiplayer gameplay mutation begins as untrusted remote input. Transport delivery, an authenticated account, RPC ownership, a valid entity identifier, and a plausible value are useful checks, but none alone authorizes a gameplay outcome.

Operation Mythology needs one project-wide command trust boundary:

`decode bounds -> authenticated connection binding -> session/authority epoch -> schema and version -> replay window -> command/capability authorization -> object authorization -> cheap state checks -> cost admission -> authoritative simulation/validation -> atomic commit -> outcome/evidence`

The boundary accepts **intent**, never client-declared truth. A client may request movement, activation, interaction, equipment use, or targeting and may attach bounded timing/aim evidence. The authoritative world derives the resulting transform, damage, inventory, reward, quest, cooldown, and ownership changes.

The boundary has three distinct outputs:

- **accepted:** the command was authorized, validated, admitted, and committed;
- **rejected/deferred:** the command was invalid, stale, duplicate, unauthorized, over budget, or temporarily inadmissible;
- **security evidence:** a bounded observation was recorded for later correlation.

A rejection is not automatically proof of cheating. Packet duplication, reordering, prediction error, reconnect races, version mismatch, accessibility hardware, bugs, and overload can all create anomalies.

## Existing Coverage and Identified Gap

The required recursive scan found 16 files in `C:\Users\steve\Desktop\GAME SKILLS` and 17 files in the dedicated mechanics archive. No scan or access error occurred. The newly added shared profiling report in `GAME SKILLS` was audited and did not create a mechanics delta.

Existing mechanics reports already define:

- server authority, prediction, reconciliation, rollback, replay, and hit rewind;
- authenticated reconnect, participant identity, connection generations, and authority epochs;
- input commands, intent buffers, deterministic arbitration, and authoritative revalidation;
- interaction offers, inventory/equipment transactions, abilities, cooldowns, costs, and status effects;
- versioned gameplay manifests, protocol compatibility, idempotency, revisions, atomic commits, and observability.

Those reports apply validation inside individual features. They do not establish one mandatory ingress contract for all remote gameplay commands. Missing rules include:

- deriving participant identity from the authenticated connection rather than client payload;
- checking command permission and referenced-object authorization on every request;
- generation-safe references and relationship/capability checks beyond mere existence;
- per-session anti-replay windows and reconnect/authority-epoch fencing;
- resource budgets weighted by estimated CPU, query, allocation, serialization, and fan-out cost;
- cheap-before-expensive validation order and global overload admission;
- a uniform trust classification for client-provided fields;
- separation of operational rejection from accumulated cheat evidence;
- evidence retention, privacy, explainability, appeal, and false-positive policy.

This is a cross-system security and reliability boundary, not a replacement for feature-specific authoritative simulation.

## Sourced Facts

The following are sourced facts unless explicitly labeled as an inference:

- Epic documents Unreal multiplayer as server-authoritative: the server holds authoritative replicated state. Actor owner and owning connection determine which client may invoke applicable remote functions and which connection receives owner-specific replication.
- Epic's current RPC execution matrix drops a client-to-server RPC when the invoking client does not own the relevant actor. This is a routing/ownership rule; the documentation does not claim that successful routing validates game-specific range, cooldown, inventory, or target legality.
- Unity Netcode's owner-restricted server RPCs likewise allow invocation by the owning client by default. Unity exposes the sender client ID from receive metadata and advises using that server-supplied value rather than a client-provided identifier.
- Unity connection approval can accept or deny a connection and supplies a server-observed client identifier. Unity also exposes protocol-version and prefab-compatibility controls. Connection approval is an admission stage, not continuing authorization for every gameplay object.
- OWASP states that every endpoint receiving an object identifier and acting on the object should check whether the authenticated caller is allowed to perform the requested action on that object. Random identifiers make guessing harder but do not replace authorization.
- OWASP's authorization guidance recommends deny by default and validating permission on every request. A single missed path can compromise integrity.
- OWASP identifies unbounded CPU, memory, storage, bandwidth, operation count, and interaction frequency as unrestricted resource-consumption risks. It recommends input-size bounds, operation limits, rate limiting, and endpoint-specific tuning.
- Google SRE describes overload as a cause of nonlinear degradation and cascading failure. It recommends realistic capacity/load testing, early cheap rejection, bounded queues, load shedding, and deliberately exercised degraded modes.
- IETF anti-replay protocols use monotonically increasing sequence numbers and receiver-maintained sliding windows to reject duplicates while permitting bounded reordering. The window size must reflect expected packet reordering.
- The anti-replay algorithm rejects sequence numbers already observed in the window and those older than its left edge. It advances only after a newer message is authenticated/validated.

**Bounded engineering inference:** RPC ownership, connection approval, authentication, anti-replay, object authorization, resource admission, and gameplay-state validation solve different problems. Therefore Operation Mythology should compose them as ordered gates rather than treat any one as sufficient authorization.

**Bounded engineering inference:** IPsec's exact wire algorithm is not prescribed for gameplay commands. Its sequence/window principle can be adapted per authenticated participant and authority epoch, with game-specific handling for reliable versus unordered command channels.

## Industry-Standard API or Pattern

Use a typed command envelope whose identity fields are stamped or verified at trusted boundaries:

`GameplayCommandEnvelope { command_type, schema_version, participant_binding, connection_generation, authority_epoch, match_id, command_sequence, client_tick, definition_revision, payload_length, payload }`

The transport/session adapter supplies `participant_binding`, connection identity, and receive time. Client payload may not override them.

Each registered command type owns a declarative policy:

`CommandPolicy { allowed_phases, required_capabilities, ownership_rule, reference_kinds, replay_class, cost_class, maximum_size, maximum_refs, frequency_budget, prediction_policy, evidence_policy }`

Recommended validation pipeline:

1. **Bounded decode:** reject unknown type, malformed encoding, unsupported schema, excessive payload, excessive arrays, invalid enum, non-finite scalar, or unsafe numeric range before allocation-heavy work.
2. **Identity binding:** resolve the authenticated connection to one session participant and current connection generation; never accept participant/account IDs as authority from the command.
3. **Fence validation:** require current match, session, gameplay-manifest revision where relevant, and authority epoch. Old-host or replaced-connection traffic cannot mutate the new authority.
4. **Replay classification:** check the command sequence in a bounded receive window. Return cached outcome for idempotent reliable retries where useful; discard duplicate transient input; reject messages outside the supported age/reorder window.
5. **Command authorization:** deny by default unless the participant's current role, game-flow phase, pawn/control state, and capability set permit that command type.
6. **Object authorization:** resolve each stable generational entity reference, then validate existence, generation, visibility/relevance if required, relationship, ownership/capability, current revision, and action-specific access.
7. **Cheap state validation:** test dead/stunned/paused/spectating state, cooldown, resource balance, distance bounds, temporal bounds, and obvious invariant violations using authoritative data.
8. **Cost admission:** consume hierarchical budgets by estimated work, not message count alone. Check per-command, per-participant, per-connection, per-match, and server/global limits.
9. **Authoritative validation/simulation:** run bounded spatial queries, rewind validation, movement simulation, ability rules, or transaction preparation. Treat client aim, tick, focus, hit, and target as evidence to constrain and verify.
10. **Atomic commit:** publish authoritative mutations and semantic outcome once, using the existing command transaction/idempotency boundary.
11. **Observation:** update low-cardinality counters and, when policy permits, append bounded security evidence without blocking the simulation.

### Client field trust classes

- **Transport-stamped:** sender connection, receive timestamp, channel, packet metadata. Trusted only as observations from the server transport.
- **Authenticated binding:** account/participant/session relationship established by the session layer. Authoritative until its generation/epoch expires.
- **Client intent:** action, directional input, desired target, requested ability. Accepted as a request, never as an outcome.
- **Client evidence:** client tick, aim ray, local focus, predicted pose, input history. Bounded, plausibility-checked, and re-derived or compared with server history.
- **Authoritative-only outcome:** damage, hit confirmation, transform, inventory delta, reward, quest progress, ownership, cooldown completion, save data. Never accepted directly from a client.
- **Risk signal:** attestation result, behavioral anomaly, impossible-frequency count, integrity alert. Useful for security analysis but not a substitute for authoritative gameplay checks.

### Object-reference rule

Every remote entity reference is treated like an untrusted object identifier:

`{ logical_entity_id, generation, optional_expected_revision }`

Successful lookup proves only that an object exists. Authorization additionally proves that the participant may perform this command on this object in the current relationship and state. Do not rely on UUID randomness, replication relevance, client UI visibility, or a previously valid focus alone.

### Budget rule

Represent cost in calibrated units:

`estimated_cost = base_decode + reference_count + spatial_query_class + history_ticks + affected_entities + replication_fanout + persistence_class`

A token bucket for message count can coexist with cost buckets. A cheap movement-input command and an expensive area query must not consume identical protection budgets. Reserve capacity for disconnect, heartbeat, correction, and administrative control paths so overload cannot prevent recovery.

## Performance Considerations

### Asymptotic complexity

- Envelope decode and fixed-field validation are `O(B)` in bounded payload bytes; hard maximum sizes make worst-case work finite.
- Hash-table participant, policy, entity-generation, and capability lookups are expected `O(1)`. Sorted/dense policy tables can be direct-indexed by command type.
- A sliding replay bitmap is `O(1)` per command with `O(W)` bits per active replay stream; large sequence jumps must clear at most the fixed window, not iterate across the numeric gap.
- Reference authorization is `O(R)` for bounded references. Never accept unbounded lists.
- Feature validation varies: spatial lookup is commonly `O(log N + K)` or grid-cell proportional; rewind is `O(H)` over bounded historical samples; affected-entity work is `O(A)`. Policies must cap `R`, `K`, `H`, and `A`.
- Budget checks and evidence counter updates should be `O(1)`. Offline correlation can be more expensive but must not run in the fixed simulation path.

### Allocations and garbage collection

- Decode into fixed-capacity/native buffers or generated value records; reject lengths before materializing collections.
- Store replay windows, token buckets, rejection counters, and compact evidence rings in connection/participant resources with pooled lifecycle.
- Avoid strings, exception-driven validation, per-command closures, dynamic tag sets, and unbounded diagnostic blobs in hot paths.
- Queue only small typed evidence records. Enrichment and human-readable formatting belong on background/telemetry consumers.
- Disconnect cleanup must reclaim buffers after a generation-safe grace period without retaining attacker-controlled payloads.

### Cache behavior

- Keep command policies in dense read-only tables keyed by compact command ID.
- Split hot ingress state—sequence window, epoch, budget counters, participant/pawn IDs—from cold account, moderation, and verbose audit data.
- Batch commands by type or policy class only when doing so preserves per-participant ordering and deterministic phase semantics.
- Favor structure-of-arrays counters for scanning budgets and metrics; keep random object graph traversal outside the common cheap-reject path.

### Update frequency

- Run decode, identity, replay, authorization, and budget gates on command arrival or at a bounded ingress drain before the relevant fixed tick.
- Apply gameplay mutations only at defined fixed-step phases.
- Refill rate budgets using authoritative monotonic time, not client time. Update global overload state at a coarser stable cadence to avoid feedback oscillation.
- Aggregate telemetry periodically; do not export one synchronous event per rejected command.
- Evaluate behavioral security rules over bounded windows outside latency-critical simulation unless an impossible invariant can be rejected immediately.

### Concurrency

- Network threads may perform bounded decode and enqueue immutable envelopes, but authoritative ECS lookup and mutation occur in simulation-owned phases or read snapshots with explicit lifetime.
- Shard replay and budget state by connection/participant to avoid global locks.
- Global admission may use approximate atomics or per-thread counters merged periodically; correctness-critical per-command authorization cannot rely on eventually consistent ownership.
- Parallel feature validation must produce immutable proposals/results and commit through deterministic barriers.
- Evidence writers use bounded multi-producer queues with drop/coalesce policy; telemetry backpressure must never stall gameplay.

### Fixed-step cost

- Establish per-tick command count and weighted-cost budgets. Drain only a bounded amount, preserving fair scheduling across participants.
- Perform cheap rejection before spatial queries, rewind, inventory scans, or replication fan-out.
- Commands deferred for server load need explicit expiry and client outcome; silently accumulating a queue increases latency and memory.
- Reserve a fixed fraction of tick capacity for authoritative simulation and corrections so ingress cannot consume the entire frame.
- Profile validation cost at high player counts, adversarial command mixes, maximum legal payloads, reconnect bursts, and degraded capacity.

### Serialization cost

- Use compact typed schemas, bounded lengths, canonical enum/range validation, and explicit versions.
- Do not serialize client account IDs, redundant sender IDs, verbose capability/tag sets, or full predicted state when a compact command and revision suffice.
- Rejection outcomes should use small stable reason codes. Detailed internal reasons may aid attackers and create localization/cardinality costs; expose only actionable safe summaries.
- Evidence records store normalized fields, policy revision, authoritative context IDs, and hashes/digests where full payload retention is unnecessary.
- Save/replay formats record accepted authoritative commands/results as required; rejected hostile payload bodies should not contaminate gameplay saves.

### Networking cost

- Unreliable high-rate input should tolerate loss and use sequence/tick ordering; reliable transactional commands need idempotent request IDs and cached semantic outcomes.
- Acks/rejections can be coalesced. Do not amplify one small client command into unbounded RPC, replication, logging, or persistence fan-out.
- Budget both inbound bytes and downstream work/fan-out. Apply per-source controls without assuming IP address equals player identity.
- Reconnect establishes a new connection generation and replay context; old-generation packets are fenced even if their sequence is numerically plausible.
- Client time is accepted only within bounded lag/lead and retained-history windows; server receive time and authoritative tick govern eligibility.

## Pros and Cons

### Pros

- One deny-by-default contract closes inconsistent feature-specific authorization paths.
- Server-derived identity prevents simple participant-ID substitution.
- Per-object authorization prevents another player's valid entity ID from becoming an access grant.
- Replay windows tolerate bounded packet reordering while rejecting duplicates and stale traffic.
- Weighted budgets protect CPU, memory, history queries, persistence, and network fan-out better than packets-per-second alone.
- Cheap-first gates reduce denial-of-service amplification and fixed-tick jitter.
- Trust classes make code reviews and tests explicit about which client fields may influence outcomes.
- Separating rejection from suspicion reduces false-positive enforcement and improves debuggability.
- Common policies and outcome codes support fuzzing, telemetry, automated validation, and replay analysis.

### Cons

- Central policy tables require disciplined ownership and can become a bottleneck if every feature adds bespoke callbacks.
- Cost estimates drift as feature implementations change and require load-test calibration.
- Replay windows add per-participant state and careful reconnect/epoch semantics.
- Strict object revisions may reject legitimate predicted commands during churn unless tolerance is designed per feature.
- Rich evidence can create privacy, storage, access-control, and incident-response obligations.
- Security thresholds disclosed through detailed errors may help attackers; opaque errors can frustrate legitimate players.
- Load shedding and fairness policies can alter feel during overload and require UX.
- Behavioral detection remains probabilistic and cannot replace authoritative prevention.

## ECS Architectural Integration

Treat network ingress as an adapter that produces bounded data, not as a caller of gameplay systems.

Suggested phase order:

`TransportReceive -> CommandDecode -> IdentityFence -> ReplayGate -> AuthorizationGate -> AdmissionGate -> DomainValidation -> DeterministicCommit -> Replication/Outcome -> EvidenceDrain`

Hot per-connection state lives outside arbitrary gameplay entities when its lifetime follows a transport connection. Participant security state follows the durable session participant. Pawn/entity capabilities remain authoritative ECS data. Explicit IDs and generations connect these lifetimes.

Command policies are immutable resources compiled from code/schema and pinned to the match's gameplay manifest. Domain systems register bounded validators and cost classes through stable IDs, not runtime function objects stored in components.

Authorization reads capability, relationship, ownership, team, game-flow, and state snapshots. It never grants authority by receiving a client tag. If a feature needs a new permission, it adds an authoritative capability rule and tests every command/object combination.

Accepted commands enter the existing deterministic intent, prediction, transaction, and event architecture. Rejections publish an outcome but no gameplay mutation. Evidence events go to a separate bounded security stream and are excluded from rollback simulation; deterministic replay may regenerate invariant violations but must not double-submit enforcement side effects.

## Component, System, Resource, and Event Interfaces

### Components

- `ParticipantControlBinding { participant_id, controlled_entity, generation, authority_epoch }`
- `GameplayCapabilitySet { dense_capability_bits, revision }`
- `ObjectAccessPolicy { owner_participant, team, relationship_mask, capability_mask, revision }`
- `NetworkRelevantIdentity { stable_entity_id, generation }`
- `CommandValidationState { last_accepted_tick, domain_counters, revision }`

Do not attach account secrets, IP addresses, raw attestation payloads, or moderation history to ordinary replicated gameplay components.

### Resources

- `AuthenticatedConnectionRegistry`
- `CommandPolicyTable`
- `CommandSchemaRegistry`
- `ReplayWindowStore`
- `HierarchicalAdmissionBudgets`
- `ServerLoadState`
- `AuthoritativeClockAndTickMap`
- `GameplayManifestRevision`
- `RejectionReasonRegistry`
- `SecurityEvidencePolicy`
- `EvidenceRingAndExportQueue`

### Systems

- `BoundedCommandDecodeSystem`
- `ConnectionParticipantBindingSystem`
- `AuthorityEpochFenceSystem`
- `ReplayProtectionSystem`
- `CommandCapabilityAuthorizationSystem`
- `ObjectReferenceAuthorizationSystem`
- `CheapInvariantValidationSystem`
- `WeightedAdmissionControlSystem`
- domain validators for movement, traversal, interaction, inventory, abilities, quests, and combat
- `AuthoritativeCommandCommitSystem`
- `CommandOutcomeSystem`
- `SecurityEvidenceAggregationSystem`
- `IngressTelemetryAggregationSystem`

### Events

- `GameplayCommandAccepted { command_id, participant, authoritative_tick, result_code }`
- `GameplayCommandRejected { command_id, participant, stage, safe_reason_code, retry_class }`
- `GameplayCommandDeferred { command_id, participant, expiry_tick, reason }`
- `ReplayObserved { participant, connection_generation, sequence_class }`
- `AuthorizationViolationObserved { participant, command_type, object_kind, policy_revision }`
- `BudgetExceeded { scope, cost_class, measured_cost, window }`
- `ServerAdmissionModeChanged { previous, current, reason }`
- `SecurityEvidenceRecorded { evidence_id, category, confidence_class, retention_class }`

Raw client payloads are not general ECS events. Event fields are bounded, normalized, access-controlled, and low-cardinality.

## Integration Plan

1. Inventory every client-to-server gameplay entry point and map it to one typed command ID, owner, mutation domain, current validation, payload bound, and downstream cost.
2. Classify every field by trust class. Remove sender/account/participant IDs that can be derived from receive context.
3. Define a deny-by-default command policy schema and compile it into a dense immutable match-pinned table.
4. Standardize stable generational entity references and expected revisions; add object-level authorization rules for owned, team, public, focused, reserved, and capability-mediated objects.
5. Bind each authenticated connection generation to exactly one active participant control generation and authority epoch.
6. Add per-channel replay classes: latest-state/input sequence, sliding-window unordered intent, and idempotent reliable transaction.
7. Insert bounded decode, identity, epoch, replay, command, and object gates before all domain validators.
8. Profile legal and adversarial command costs. Create hierarchical count, byte, and weighted-work budgets plus queue and history caps.
9. Integrate domain-specific authoritative validators and atomic commit without moving feature logic into the ingress layer.
10. Define stable accepted/rejected/deferred outcomes and client UX for retryable, stale, incompatible, and overload cases.
11. Add bounded evidence aggregation, access controls, retention, redaction, and export. Keep automated enforcement disabled until labeled evaluation and appeal policy exist.
12. Roll out in observe-only mode, compare would-reject decisions against authoritative outcomes, then enable cheap invariant enforcement per command family.
13. Exercise global overload/degraded modes in scheduled tests and verify recovery paths retain capacity.

## Verification Strategy

- **Entry-point completeness:** static/schema inventory proves every remote gameplay mutation crosses the boundary; CI fails on an unregistered command.
- **Identity substitution:** fuzz payload participant/account IDs and prove the server always uses receive-context binding.
- **Cross-object authorization:** for two participants and every referenced object kind, substitute IDs/generations/revisions and prove deny-by-default behavior.
- **Lifecycle races:** destroy/recycle entities, transfer ownership, possess/unpossess pawns, reconnect, replace connections, migrate authority epochs, and deliver delayed commands.
- **Replay properties:** duplicate, reorder, delay, wrap/test near numeric limits, jump sequences, reconnect, and mix channels. Property tests verify each sequence is accepted at most once under its policy.
- **Schema fuzzing:** malformed varints, unknown versions, NaN/infinity, maximum lengths, nested counts, truncated payloads, invalid enums, and decompression/amplification cases fail before unsafe allocation or mutation.
- **State validation:** verify dead, stunned, paused, spectating, cooldown, insufficient cost, excessive range, hidden target, invalid phase, and stale revision across every domain.
- **Authoritative outcome:** mutate client-declared transform, damage, reward, inventory, quest, and cooldown outcomes; prove none bypass authoritative derivation.
- **Budget fairness:** simulate one abusive participant, many abusive identities, NAT-sharing clients, legal bursts, reconnect storms, and expensive low-rate requests. Verify honest-player latency and reserved recovery capacity.
- **Overload:** reduce server capacity and inject adversarial mixes. Verify bounded memory/queues, early rejection, stable tick time, degraded-mode entry/exit, and no cascading amplification.
- **Determinism:** replay identical accepted command sets under varied worker scheduling and prove identical commit order/state hash; security exports occur once outside replay.
- **Observability:** every rejection stage has bounded metrics and trace correlation without raw secrets or unbounded labels.
- **False-positive evaluation:** use packet loss, jitter, reorder, old builds, controller macros allowed by policy, accessibility devices, remapping, low frame rate, reconnect, and known bugs as negative cases.
- **Security red team:** enumerate object IDs, invoke unauthorized command types, exploit expensive queries, spam rejected commands, forge client ticks, replay captured commands, and target reconnect/epoch boundaries.
- **Privacy and operations:** verify retention expiry, access audit, redaction/deletion workflows, evidence integrity, model/rule versioning, analyst explanation, and appeal/review reconstruction.

Release gates should include zero unauthorized mutation in adversarial suites, bounded p99 ingress cost, bounded tick overrun at the supported hostile-load envelope, no unbounded allocations, and measured false-positive targets for any enforcement rule.

## Risks and Open Decisions

- Which modes require dedicated authority, and which peer-host modes accept weaker trust?
- What authenticates account-to-participant binding, and how are stolen/resumed sessions revoked?
- Which commands use latest-only, ordered, unordered-window, or idempotent transaction semantics?
- Replay-window width, sequence bit width, wrap/rekey policy, and connection-generation reset rules.
- Stable entity-ID size, generation width, reuse delay, and expected-revision policy.
- Capability model: dense bits, relation policies, gameplay tags, or compiled attribute rules.
- Whether replication relevance is required evidence for targeting, without treating relevance as sufficient authorization.
- Client-tick lead/lag limits and how those interact with server rewind and high latency.
- Cost-unit calibration, refill rates, burst sizes, fairness, and mode/player-count scaling.
- Which commands may be deferred under load versus immediately rejected, and how clients recover.
- Capacity reserved for corrections, reconnect, heartbeat, chat/reporting, and administrative actions.
- Safe rejection detail for player UX versus information disclosure to attackers.
- What constitutes an impossible invariant versus a probabilistic anomaly.
- Evidence categories, access, encryption, geographic storage, retention, deletion, and incident holds.
- Whether raw input, aim history, voice, device, IP, attestation, or accessibility-related data is ever collected; default should be minimal collection.
- Labeled-data provenance, drift monitoring, platform/input fairness, confidence calibration, and human review for behavioral detection.
- Enforcement ladder: prevent mutation, warn, throttle, shadow-observe, remove from match, restrict matchmaking, or account sanction.
- Appeal, reversal, compensation, and player communication policy.
- How third-party anti-cheat signals are versioned, challenged, unavailable, or contradicted by authoritative evidence.
- Split-screen and shared-network identity/budget rules.
- Offline/listen-server behavior and development bypasses that must never ship.

## Engineering Recommendations

The following are Operation Mythology engineering recommendations, not direct statements from the sources:

1. Establish one mandatory, deny-by-default command ingress boundary for every remote gameplay mutation.
2. Derive sender identity from authenticated receive context. Never authorize using a client-supplied participant, account, owner, team, or role identifier.
3. Treat RPC ownership and connection approval as preliminary gates, not complete gameplay authorization.
4. Require command-level capability and object-level authorization on every referenced entity. Existence, UUID randomness, relevance, or prior focus is insufficient.
5. Use stable generational entity references, authoritative relationship checks, and optional expected revisions to resist stale/recycled-object commands.
6. Fence commands by match, connection generation, participant-control generation, gameplay manifest, and authority epoch where applicable.
7. Apply bounded sequence/replay policies per command class. Combine reliable transactional retries with idempotent outcomes; use sliding windows only where bounded reordering is intended.
8. Order checks from cheap and general to expensive and domain-specific. Reject before spatial, rewind, persistence, or fan-out work whenever possible.
9. Budget bytes, counts, and estimated downstream work hierarchically. Calibrate with load tests and cap every attacker-controlled multiplicity.
10. Reserve simulation and recovery capacity; bound queues; fail early and visibly under overload; regularly exercise degraded modes.
11. Accept client intent and bounded evidence only. Re-derive transforms, hits, costs, inventory, rewards, quest progress, cooldowns, and save mutations from authoritative state.
12. Keep validation and mutation separate: prepare a typed authoritative result, then commit atomically once through the existing transaction boundary.
13. Return small stable outcomes for accepted, rejected, duplicate, stale, incompatible, deferred, and retryable commands. Do not expose sensitive internal policy detail.
14. Separate prevention, rejection, evidence, and enforcement. One rejected command should generally be an operational fact, not an automatic cheating verdict.
15. Prefer deterministic impossible-invariant prevention over probabilistic punishment. Treat behavioral or attestation signals as versioned evidence requiring calibrated policy.
16. Minimize evidence collection, especially device/accessibility characteristics and raw inputs. Define retention, access, audit, explanation, and appeal before automated sanctions.
17. Ship an ingress inspector showing command ID, trusted binding, gate decisions, authoritative revisions, estimated/actual cost, outcome, and evidence references with role-based redaction.
18. Make entry-point registration, authorization matrices, sequence properties, malformed-input fuzzing, overload, lifecycle races, and false-positive cases mandatory automated gates.

## Source Links

- Epic Games, [Remote Procedure Calls in Unreal Engine 5.8](https://dev.epicgames.com/documentation/unreal-engine/remote-procedure-calls-in-unreal-engine)
- Epic Games, [Actor Owner and Owning Connection in Unreal Engine 5.8](https://dev.epicgames.com/documentation/en-us/unreal-engine/actor-owner-and-owning-connection-in-unreal-engine)
- Epic Games, [Actor Role and Remote Role in Unreal Engine 5.8](https://dev.epicgames.com/documentation/en-us/unreal-engine/actor-role-and-remote-role-in-unreal-engine)
- Unity Technologies, [Netcode for GameObjects RPC documentation](https://docs-multiplayer.unity3d.com/netcode/2.3.2/advanced-topics/message-system/rpc/)
- Unity Technologies, [Netcode ServerRpc ownership and sender metadata](https://mp-docs.dl.it.unity3d.com/netcode/2.3.2/advanced-topics/message-system/serverrpc/)
- Unity Technologies, [Netcode connection approval](https://docs-multiplayer.unity3d.com/netcode/2.0.0/basics/connection-approval/)
- Unity Technologies, [Netcode NetworkManager settings](https://docs-multiplayer.unity3d.com/netcode/current/components/networkmanager/)
- OWASP, [API1:2023 Broken Object Level Authorization](https://owasp.org/API-Security/editions/2023/en/0xa1-broken-object-level-authorization/)
- OWASP, [Authorization Cheat Sheet](https://cheatsheetseries.owasp.org/cheatsheets/Authorization_Cheat_Sheet.html)
- OWASP, [API4:2023 Unrestricted Resource Consumption](https://owasp.org/API-Security/editions/2023/en/0xa4-unrestricted-resource-consumption/)
- Google, [Site Reliability Engineering: Addressing Cascading Failures](https://sre.google/sre-book/addressing-cascading-failures/)
- Google, [Site Reliability Engineering: Reliable Product Launches—Overload Behavior and Load Tests](https://sre.google/sre-book/reliable-product-launches/)
- IETF, [RFC 4302: IP Authentication Header—Anti-Replay Window](https://datatracker.ietf.org/doc/html/rfc4302)
- IETF, [RFC 6479: IPsec Anti-Replay Algorithm without Bit Shifting](https://datatracker.ietf.org/doc/html/rfc6479)

