# Operation Mythology Mechanics Research

**Batch timestamp:** 2026-07-27T02:01:19-07:00  
**Subject:** Perspective-independent FP/TP camera rigs, aim convergence, collision, transitions, comfort, and multiplayer boundaries  
**Scope:** Generic modular ECS; local presentation with authoritative aim contracts; no production code

## Feature Overview

The camera system produces a local view from authoritative/predicted gameplay state without becoming gameplay authority. It supports first person, third person, over-shoulder aim, sprint/traversal, swimming, ladders, death/spectator, interaction focus, lock-on, photo/debug, and cinematic handoffs.

The pipeline is:

`gameplay intent/state -> rig selection -> pivot/aim solution -> framing modifiers -> collision/occlusion solve -> comfort filters -> final camera pose/lens -> render view`

Three coordinate facts remain distinct:

- **control/intent orientation:** what the player commands;
- **authoritative aim origin/direction:** what gameplay uses for targeting;
- **render camera pose:** what this local view presents.

FP and TP share control and aim contracts. They differ in local rig, boom/offset, collision, body visibility, and comfort treatment.

## Existing Coverage and Identified Gap

The fresh scan found nine source-library files covering graphics, GPU, ECS, and streaming topics. The dedicated mechanics folder contains traversal, inventory, ability/effect, and quest/persistence reports. Traversal mentions camera comfort but does not define a camera architecture. Temporal rendering defines render-view history, not gameplay camera behavior.

The uncovered gap is a modular camera director/rig system with deterministic gameplay-facing aim, local collision/occlusion, stable transitions, shoulder handling, accessibility settings, and correct network privacy.

## Sourced Facts

- Unreal Engine 5.8’s experimental Gameplay Camera System uses reusable Camera Assets containing rigs, transitions, and a Camera Director; rigs are node networks and the system includes debugging tools. Epic’s quick start demonstrates FP, TP, and top-down rigs in one asset. [Epic: Gameplay Camera System Overview](https://dev.epicgames.com/documentation/unreal-engine/gameplay-camera-system-overview) and [Quick Start](https://dev.epicgames.com/documentation/unreal-engine/gameplay-camera-system-quick-start)
- Unreal documents Spring Arm use as typical for TP cameras; its API exposes a collision probe size and collision displacement state. [Epic: Using Cameras](https://dev.epicgames.com/documentation/en-us/unreal-engine/using-cameras-in-unreal-engine) and [USpringArmComponent](https://dev.epicgames.com/documentation/en-us/unreal-engine/API/Runtime/Engine/USpringArmComponent)
- Unity Cinemachine Deoccluder adjusts a camera when obstacles occlude its subject and requires colliders for potential obstacles. [Unity Cinemachine Deoccluder](https://docs.unity.cn/Packages/com.unity.cinemachine%403.0/manual/CinemachineDeoccluder.html)
- Unity’s Cinemachine third-person aim module documents forcing the LookAt point to screen center while canceling camera noise/corrections for accurate aim, showing that aim and aesthetic camera modifiers require an explicit relationship. [Unity Cinemachine 3rd Person Aim](https://docs.unity.cn/Packages/com.unity.cinemachine%402.9/api/Cinemachine.html)
- Xbox Accessibility Guideline 117 identifies FOV, camera bob, weapon sway, automatic camera changes, motion blur, and screen shake as settings relevant to motion sickness and recommends player adjustment, including reducing motion to zero where appropriate. [Microsoft: XAG 117](https://learn.microsoft.com/en-us/gaming/accessibility/xbox-accessibility-guidelines/117)
- GDC camera-design material describes TP over-shoulder framing and catalogs common real-time camera design problems, supporting systematic rig/constraint evaluation rather than one follow offset. [GDC: Fundamentals of Real-Time Camera Design](https://media.gdcvault.com/gdc05/slides/GD_Haigh-Hutchinson_FundamentalsReal-TimeCameraDesign2.pdf)

## Industry-Standard API or Pattern

### Camera director, rigs, modifiers, and constraints

Use a `CameraDirector` that selects/blends rigs based on local gameplay presentation facts. Rigs are immutable data graphs:

- target/pivot provider;
- orientation provider;
- boom/offset/framing;
- lens/FOV;
- collision/occlusion constraints;
- damping and transition profile;
- modifier acceptance policy.

Examples: `FirstPerson`, `ThirdPersonExplore`, `ThirdPersonAimRight/Left`, `Traversal`, `SwimmingSurface`, `Underwater`, `Ladder`, `Death`, `Spectator`, `Conversation`, and `Photo`.

Modifiers—recoil, damage impulse, sprint FOV, breathing, landing, lock-on bias—produce bounded additive/override proposals with priority, blend, duration, comfort category, and deduplication ID. They do not directly set the camera.

### Aim convergence

Recommended aiming:

1. Derive control ray from camera/crosshair through the view.
2. Query a prospective aim point using gameplay collision policy and range.
3. Derive authoritative shot/interact ray from weapon/muzzle/body origin toward that point.
4. Resolve near-cover obstruction from the authoritative origin.
5. Server validates using command aim plus lag-compensation policy.

The camera ray cannot shoot around cover. Crosshair presentation indicates obstruction/convergence mismatch. Hip fire, ADS, projectile, melee, interaction, and lock-on can use different aim profiles but share evidence/result schemas.

### Camera collision

Solve TP collision with sphere/capsule casts from pivot to desired camera, not a zero-radius ray. Use:

- retract quickly on obstruction;
- recover outward more slowly with hysteresis;
- protect near clip and minimum subject visibility;
- ignore self and explicitly classified transparent/nonblocking volumes;
- optional shoulder swap or lateral search;
- fade/dither subject/occluders only as presentation supplements.

Keep pivot correction distinct from camera boom collision. Collision should not move the gameplay character or authoritative aim target.

### Perspective switching

Switch rigs while preserving control orientation, aim point where possible, input sensitivity semantics, and gameplay state. Blend in pose/lens space with interruption policy. Snap on teleports, respawn, severe occlusion, or comfort setting when blending would expose invalid space.

FP should not attach raw view directly to animated head motion. Use a stable gameplay pivot plus bounded animation-derived secondary motion.

## Performance Considerations

### Asymptotic complexity

With `r` active rig nodes/modifiers, `c` collision candidates, and `i` lateral/occlusion iterations:

- rig evaluation is `O(r)`;
- broad-phase collision is approximately `O(log N + c)`;
- bounded camera solve is `O(i)`;
- aim queries are `O(1)` physics queries per local view under fixed profiles.

Cost scales with local rendered views, not total network players.

### Allocations and garbage collection

Warm rig selection/evaluation, modifiers, aim, collision, and transitions allocate zero heap objects. Use precompiled rig arrays, fixed modifier stacks, cached query filters, and per-view scratch. Debug traces use bounded rings.

### Cache behavior

Keep active rig parameters, previous solution, modifier values, comfort scalars, and transition state contiguous per view. Asset graphs, localized settings text, and debug names remain cold.

### Update frequency

Authoritative control/aim samples at simulation ticks. Camera presentation evaluates once per rendered view using interpolated predicted state. Collision normally evaluates every view frame, with cached hit identity and hysteresis. Expensive occlusion alternatives are budgeted.

### Concurrency

Rig math/modifier evaluation can run in a view job. Physics camera queries require a stable query scene and return immutable results. Final publication occurs before render-view construction. UI/settings mutate profiles at a safe point.

### Fixed-step cost

Only control orientation, authoritative aim evidence, and gameplay targeting belong to fixed simulation. Damping, shake, FOV easing, camera collision, and local fades do not consume rollback fixed-step cost unless a gameplay rule explicitly depends on them.

### Serialization cost

Persist user settings, selected perspective/shoulder, sensitivity/FOV/comfort options, and stable local mode if desired. Save games should not serialize transient damping, collision hits, or shake. Replay records authoritative aim/control; playback may regenerate or optionally record a spectator camera track.

### Networking cost

Do not replicate render camera transforms, local collision, shake, FOV, or comfort settings. Commands replicate quantized authoritative aim/control as required. Remote characters receive coarse look/aim state for pose/visibility. Camera-based target evidence is server-validated.

## Pros and Cons

### Pros

- Same gameplay aim works across FP/TP.
- Modular rigs scale to traversal, combat, death, and spectator modes.
- Local camera remains private and cheap on servers.
- Explicit collision and convergence prevent shooting through cover.
- Comfort modifiers/settings are systematic.
- Debuggable inputs/constraints improve tuning.

### Cons

- TP camera and muzzle rays can disagree near cover.
- Collision recovery and shoulder swaps can cause motion.
- Rig graphs/modifier priority need governance.
- FP body/weapon rendering may need separate presentation treatment.
- Lock-on and camera assist can interfere with player control.
- Split-screen multiplies queries and view cost.

## ECS Architectural Integration

Presentation order:

1. `CameraFactProjectionSystem`
2. `CameraDirectorSystem`
3. `CameraRigEvaluationSystem`
4. `AimPresentationSystem`
5. `CameraModifierSystem`
6. `CameraCollisionSystem`
7. `CameraComfortSystem`
8. `CameraTransitionSystem`
9. `RenderViewPublicationSystem`
10. `CameraTelemetrySystem`

Fixed simulation independently runs `ControlIntentSystem` and `AuthoritativeAimSystem`. Camera components are local/presentation ECS or per-local-player resources and are excluded from authoritative hashes.

## Component, System, Resource, and Event Interfaces

Components/resources:

- `ControlOrientation { yaw, pitch, tick }`
- `AuthoritativeAim { origin, direction/target, profile, evidenceTick, obstruction }`
- `CameraSubject { pivot providers, bounds, self-ignore set }`
- `CameraPresentationFacts { movementMode, aiming, traversal, death, spectator, tags }`
- `LocalCameraState { rigId, pose, lens, shoulder, transition, collision }`
- `CameraComfortProfile { FOV, bob, shake, sway, roll, autoRotation, blur scalars }`
- `CameraRigDatabase`
- `CameraQueryService`
- `CameraModifierStack`
- `CameraDiagnostics`

Events:

- `CameraRigRequested/Changed`
- `PerspectiveChanged`
- `ShoulderChanged`
- `CameraObstructed/Cleared`
- `AimConvergenceChanged`
- `CameraModifierStarted/Ended`
- `CameraComfortSettingsChanged`
- `CameraCut`

## Integration Plan

1. Define control orientation and authoritative aim contracts independent of perspective.
2. Build FP, TP explore, and TP aim rigs plus director/transitions.
3. Add pivot/boom sphere-cast collision, hysteresis, and debug visualization.
4. Add camera-ray-to-authoritative-origin convergence and near-cover feedback.
5. Integrate traversal/swimming/ladder/death/spectator facts.
6. Add bounded modifiers and full comfort settings.
7. Add multiplayer validation, remote aim projection, split-screen budgets, automated tests, and telemetry.

## Verification Strategy

- Test FP/TP parity for movement, aim, interaction, traversal, swimming, ladders, death, and respawn.
- Sweep walls, corners, ceilings, narrow tunnels, stairs, moving doors/platforms, transparent volumes, and near-clip cases.
- Verify camera ray never authorizes muzzle/body shots through cover.
- Test shoulder swap around both cover sides and convergence feedback.
- Switch perspective/rig during every movement mode and interrupted transition.
- Fuzz frame rate, hitches, camera cuts, teleport, origin rebase, rollback corrections, and split-screen.
- Assert zero warm allocations; measure query count/time, retraction/recovery velocity, occlusion duration, modifier count, transition interruptions, and per-view CPU.
- Accessibility test FOV, sensitivity, inversion, bob/shake/sway/roll/auto-rotation reductions including zero.

## Risks and Open Decisions

- Unified body versus separate FP arms/body presentation.
- Camera-relative versus character-relative movement by mode.
- Absolute/relative aim representation and server rewind boundary.
- Projectile convergence range and parallax policy.
- Right/left/automatic shoulder behavior.
- Fade occluder, fade character, lateral search, retract, or hybrid.
- Lock-on authority and camera assistance strength.
- ADS FOV versus magnification/render scope.
- Camera smoothing during prediction corrections.
- Traversal camera animation coupling.
- Split-screen query/visibility budgets.
- Competitive restrictions on FOV and perspective.

## Engineering Recommendations

1. Separate control orientation, authoritative aim, and local render camera as distinct contracts.
2. Use a data-driven director with reusable rigs, bounded modifiers, explicit constraints, and interruptible transitions.
3. Share gameplay across FP/TP; perspective differences remain presentation except declared competitive rules.
4. Use camera aim to select a prospective point, then validate from authoritative weapon/body origin.
5. Solve TP collision with swept volume, fast retraction, slower hysteretic recovery, and debug traces.
6. Do not attach FP view directly to raw head animation; make bob/sway secondary and adjustable to zero.
7. Keep local camera state out of replication, saves, and deterministic hashes except control/aim facts required by gameplay.
8. Treat FOV, sensitivity, inversion, bob, shake, sway, roll, automatic rotation, and motion blur as first-class accessibility settings.
9. Budget per local view and build geometric regression scenes before content scale.

## Source Links

1. Epic Games, [Gameplay Camera System Overview](https://dev.epicgames.com/documentation/unreal-engine/gameplay-camera-system-overview)
2. Epic Games, [Gameplay Camera System Quick Start](https://dev.epicgames.com/documentation/unreal-engine/gameplay-camera-system-quick-start)
3. Epic Games, [Using Cameras](https://dev.epicgames.com/documentation/en-us/unreal-engine/using-cameras-in-unreal-engine)
4. Epic Games, [USpringArmComponent](https://dev.epicgames.com/documentation/en-us/unreal-engine/API/Runtime/Engine/USpringArmComponent)
5. Unity Technologies, [Cinemachine Deoccluder](https://docs.unity.cn/Packages/com.unity.cinemachine%403.0/manual/CinemachineDeoccluder.html)
6. Unity Technologies, [Cinemachine Third Person Aim API](https://docs.unity.cn/Packages/com.unity.cinemachine%402.9/api/Cinemachine.html)
7. Microsoft, [Xbox Accessibility Guideline 117](https://learn.microsoft.com/en-us/gaming/accessibility/xbox-accessibility-guidelines/117)
8. GDC, [Fundamentals of Real-Time Camera Design](https://media.gdcvault.com/gdc05/slides/GD_Haigh-Hutchinson_FundamentalsReal-TimeCameraDesign2.pdf)

