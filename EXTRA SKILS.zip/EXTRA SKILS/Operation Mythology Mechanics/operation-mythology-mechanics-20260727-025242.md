# Operation Mythology Mechanics Delta Research — Gameplay Intent Arbitration, Claims, and Deterministic Commit

**Timestamp:** 2026-07-27T02:52:42-07:00  
**Scope:** Shared/context actions, buffered intent, heterogeneous candidate proposals, traversal/interactions/abilities/movement competition, deterministic scoring and tie-breaking, reservations, validation, multiplayer authority, accessibility, ECS interfaces, performance, debugging, and tests.

## Feature Overview

A single semantic action can have several valid interpretations at one tick:

- jump from ground;
- mantle or vault a nearby obstacle;
- grab a ledge or exit water;
- climb or mount a ladder;
- use the focused interaction;
- enter a vehicle or occupy a station;
- activate an ability;
- cancel or transition the current action.

If systems independently consume the same input edge, result depends on system order. If one hard-coded priority list decides everything, it becomes brittle across modes, content, accessibility, and first-/third-person presentation.

Use a deterministic intent transaction:

`intent edge -> bounded proposal generation -> eligibility filtering -> policy partition -> deterministic scoring -> selection -> resource claim/reservation -> authoritative revalidation -> commit -> consume/reject/retain intent -> publish result`

The broker does not execute traversal, interaction, or abilities. It selects one typed proposal and transfers its stable evidence to the owning system. Explicit actions may bypass competition by addressing a domain directly; shared/context actions use arbitration.

## Existing Coverage and Identified Gap

The required recursive scan found 16 files in `C:\Users\steve\Desktop\GAME SKILLS` and 16 files in the dedicated mechanics archive. No scan error occurred and no hashes changed after the prior pass.

Existing reports define:

- semantic input, fixed-tick commands, and bounded intent buffers;
- traversal candidate query/classify/validate/score/accept;
- interaction offers with local focus and server validation;
- ability activation tags, cooldowns, costs, prediction, and commit;
- movement-mode transitions;
- deterministic phase/event ordering;
- idempotent local gameplay transactions.

They leave consumption arbitration open. No shared contract decides when the same edge can feed multiple domains, how each domain describes a proposal, how priority and player intent interact, when exclusive targets are claimed, how authority reproduces or overrides client selection, or how rejected candidates return/consume a buffered edge.

This report fills that cross-system boundary without merging the domain implementations.

## Sourced Facts

The following are sourced facts, not Operation Mythology recommendations:

- Epic Enhanced Input uses Mapping Context priorities to resolve multiple mappings that compete to consume the same physical input. Higher-priority consuming mappings can block lower-priority mappings.
- Epic describes semantic Input Actions, dynamic contexts, modifiers, triggers, contextual mappings, and prioritization. This arbitration occurs before game-specific traversal/interaction/ability feasibility.
- Unreal Smart Objects expose query results containing available slots and use an explicit claim operation. A successful claim returns a handle; a failed claim lets the agent choose another result. Claimed and occupied are distinct slot states.
- Epic states that Smart Objects contain interaction data but not execution logic; the interactor implements the behavior. This separates discovery/reservation from execution.
- Unreal Gameplay Abilities can declare activation-required/blocked tags, tags that block other abilities, and tags that cancel active abilities. The server remains authoritative for replicated/predicted ability impact.
- Epic documents local-predicted abilities as responsive client execution subject to server correction.
- Existing engine mechanisms therefore solve three different layers: physical binding collision, exclusive resource claim, and ability eligibility/conflict. None of the cited documentation defines a universal cross-domain selector for jump versus traversal versus interaction versus ability.

The final point is a bounded inference from the documented scopes, not a claim that engines prohibit custom arbitration.

## Industry-Standard API or Pattern

### Intent classes

Each buffered intent has a stable action ID and an arbitration class:

- **direct:** routed to one named domain (`Reload`, `OpenInventory`);
- **shared contextual:** several domains may propose (`ContextAction`);
- **movement contextual:** locomotion/traversal transitions may compete (`JumpOrTraverse`);
- **cancel/back:** resolves against active ownership stack;
- **non-consuming broadcast:** multiple observers may respond without authoritative mutation.

The accessibility/input profile may map distinct physical inputs to the same direct or shared semantic actions. Arbitration never inspects physical controls or disability/profile labels.

### Proposal record

Every participating system emits bounded immutable proposals:

`{ proposal_id, intent_sequence, domain, action_kind, owner, target, evidence_tick, state_revisions, policy_class, score_terms, required_claims, prediction_class, expiry_tick }`

A proposal is a promise that the domain can revalidate and commit if selected. It contains no callbacks or mutable pointers.

Proposal generators remain specialized:

- locomotion proposes grounded jump, crouch/slide, stance transition;
- traversal proposes mantle, vault, ledge, ladder, water exit;
- interaction proposes an offer/target pair;
- ability system proposes an ability/spec/target activation;
- active execution proposes cancel, chain, or transition.

### Eligibility and policy partition

Reject before scoring:

- wrong intent/action class;
- stale context/mode/generation;
- state/tag/cooldown/cost/authority failure;
- target outside required evidence bounds;
- invalid movement transition;
- missing required claim capability;
- proposal past expiry;
- accessibility/mode policy that requires explicit activation.

Then partition by authored policy bands, for example:

1. safety/escape/cancel;
2. explicit direct action;
3. active-action continuation;
4. traversal or interaction explicitly aimed/focused;
5. ordinary locomotion;
6. low-confidence contextual assistance.

Bands express design precedence; numeric scoring compares only within a compatible band. This prevents a huge distance score from overriding an explicit cancel or safety action.

### Deterministic scoring

Score terms are normalized, bounded integers or deterministic fixed-point values:

- explicit action match;
- aim/facing alignment;
- movement-intent alignment;
- distance/reach;
- target focus stability/hysteresis;
- continuity with current mode/execution;
- traversal feasibility and landing safety;
- interaction offer priority;
- player-selected preference;
- accessibility assist adjustment;
- predicted-authoritative evidence confidence.

Use a lexicographic key:

`policy_band, primary_score, hysteresis_bonus, domain_priority, target_id, proposal_id`

All tie-break fields are stable and specified. Do not use entity iteration, pointer address, job completion, floating unordered reduction, or event subscription order.

### Claims and reservations

Selection is provisional if it needs an exclusive slot/resource:

`select -> claim targets/resources in canonical order -> if claim fails, mark rejection and select next eligible proposal or retain/expire intent`

Claims include target revision/generation, owner, intent/proposal ID, lease/expiry, and authority epoch. Examples: ladder slot, vehicle seat, interaction use slot, pickup claim, traversal anchor occupancy, ability charge reservation.

Avoid long-lived global locks. Claims are short reservations validated again at commit. Multi-resource proposals acquire in canonical stable-ID order or through one local transaction to avoid deadlock.

### Authoritative revalidation and commit

The client may predict proposal selection and presentation. It sends semantic intent plus selected proposal/target evidence where useful, not authority. The server:

1. reconstructs bounded candidates from authoritative state or validates supplied stable evidence;
2. applies the same manifest/policy generation;
3. claims required resources;
4. revalidates revisions, geometry/range, tags, costs, and ownership;
5. commits one domain transition at the fixed barrier;
6. returns accepted proposal/result or structured rejection/correction.

Commit emits one `IntentResolved` fact and domain-specific committed events. The intent buffer follows its declared terminal policy.

### Intent disposition

Every intent ends as:

- `ConsumedAccepted`;
- `ConsumedRejected` for attempts that should not repeat;
- `RetainedNoEligibleProposal`;
- `RetainedClaimRace`;
- `Expired`;
- `FlushedByStateChange`;
- `Superseded`;
- `BroadcastCompleted`.

Policy is data-driven by intent/action class. A jump pressed before landing may remain; an interaction request against a destroyed unique target may consume/reject; a cancel edge normally consumes once.

### Prompt and preview contract

UI observes the current winning preview and alternatives from an immutable presentation snapshot. It may display “Mantle,” “Open,” or “Enter” and apply hysteresis so prompts do not flicker. UI preview never reserves or authorizes the action. If ambiguity is high, design may expose separate actions, a hold/radial choice, or require clearer targeting rather than silently guessing.

## Performance Considerations

- **Asymptotic complexity:** With domain candidate caps, proposal generation is `O(sum C_d)` and selection is `O(P)` using a single deterministic min/max reduction for `P` eligible proposals. Full sorting is unnecessary unless alternatives must be presented (`O(P log P)`). Claim lookup is expected `O(1)` by stable resource ID; multi-claim canonical sorting is `O(k log k)` for small bounded `k`.
- **Allocations and garbage collection:** Use fixed per-owner proposal arrays, intent rings, claim tables, and score-term structs. Warm arbitration allocates zero heap memory. Overflow is deterministically truncated by policy key and counted. Debug explanations use bounded cold buffers.
- **Cache behavior:** Store proposal headers and hot score fields in structure-of-arrays or compact contiguous records by owner. Keep localized prompts, debug strings, authoring graphs, and rich geometric evidence cold. Reference targets by stable compact handles.
- **Update frequency:** Generate proposals only when a relevant buffered intent exists, or at lower presentation cadence for prompts. Rebuild on owner/target/context revision changes. Authoritative resolution runs once at a fixed phase. Claims expire through the timer service rather than per-resource polling.
- **Concurrency:** Domains may generate proposals in parallel against one immutable tick snapshot. Deterministically merge per-domain buffers by owner/domain/stable key. One arbitration/commit phase owns intent disposition and claims. Workers never consume intents or mutate target reservations directly.
- **Fixed-step cost:** Cap intents per owner/tick, proposals per domain, target queries, score terms, re-selections after claim failure, and claims per proposal. Defer noncritical contextual attempts on overload; never extend the tick or allow unbounded retry loops.
- **Serialization cost:** Persist authored policy profiles and score schemas, not transient proposal buffers or prompt previews. Save active committed action/claim only if its domain supports persistence. Replays record semantic intents and committed resolution IDs/evidence as required. Cost is `O(committed resolutions)`.
- **Networking cost:** Commands carry action/intent sequence and compact optional proposal/target evidence. Server response carries accepted action/target or rejection reason. Do not replicate full candidate lists normally. Predicted resolution history is bounded by rollback window. Rate-limit contextual spam and validate target/claim identifiers.

## Pros and Cons

### Pros

- Removes hidden system-order dependence.
- Allows traversal, interactions, abilities, and locomotion to remain modular.
- Makes contextual controls predictable, debuggable, replayable, and server-validatable.
- Claims handle exclusive targets without conflating selection and execution.
- Explicit policy bands protect safety/cancel/direct actions from numeric-score accidents.
- Shared result/rejection taxonomy improves prompts, telemetry, and automated tests.

### Cons

- Policy/scoring becomes a governed gameplay product requiring tuning.
- Context actions can still feel surprising when candidates are close.
- Candidate generation and authoritative reconstruction add fixed-step/query cost.
- Hysteresis can preserve a stale choice too long.
- Claims introduce race, expiry, and cleanup complexity.
- One generic proposal schema can become bloated unless domain payloads stay separate.

## ECS Architectural Integration

Intent buffers attach to participant/control ownership, not pawns. Proposal generation reads the current pawn/avatar projection and authoritative world snapshot.

- Domain systems write fixed proposal buffers.
- An `IntentArbitrationSystem` reads buffers in a declared phase and publishes selected proposal transactions.
- A `ClaimSystem` owns exclusive resource state.
- Domain commit systems consume selected typed payloads at the same or next fixed barrier.
- Structural/action transitions use the existing transaction coordinator.
- Presentation reads a separately published preview snapshot and never mutates claims.
- Prediction/rollback restore intent, selection, claim, and committed domain state inside the declared rollback boundary.

## Component, System, Resource, and Event Interfaces

### Components

- `BufferedIntent { action_id, sequence, pressed_tick, expiry_tick, disposition_policy }`
- `IntentProposalBuffer { fixed_records, count, overflow }`
- `SelectedIntentProposal { intent_sequence, proposal_id, domain, target, evidence_revision }`
- `GameplayClaim { resource_id, claimant, proposal_id, generation, expiry_tick, state }`
- `IntentResolutionHistory { fixed_tick_ring }`
- `ContextPreview { action_label_id, target, confidence_band, alternatives_count, revision }`

### Resources

- `IntentArbitrationPolicyRegistry`: bands, weights, caps, eligibility and disposition policies.
- `DomainProposalSchemaRegistry`: typed payload/evidence contracts.
- `GameplayClaimTable`: resource state, generations, leases, owners.
- `ArbitrationBudgets`: intents, proposals, queries, claims, retries, history.
- `ArbitrationDebugRegistry`: stable term/rejection/reason IDs.

### Systems

- `BufferedIntentAdmissionSystem`
- `LocomotionProposalSystem`
- `TraversalProposalSystem`
- `InteractionProposalSystem`
- `AbilityProposalSystem`
- `ActiveExecutionTransitionProposalSystem`
- `IntentEligibilityAndScoreSystem`
- `IntentArbitrationSystem`
- `GameplayClaimSystem`
- `SelectedProposalRevalidationSystem`
- `IntentCommitAndDispositionSystem`
- `ContextPreviewPublicationSystem`
- `ArbitrationTelemetrySystem`

### Events and commands

- `IntentBuffered`
- `ProposalGenerated/Rejected`
- `ProposalSelected`
- `ClaimRequested/Granted/Denied/Expired/Released`
- `IntentResolved { disposition, action_kind, domain, target, tick }`
- `PredictedResolutionCorrected`
- `ContextPreviewChanged`
- `ArbitrationOverflowDetected`

## Integration Plan

1. Inventory shared/context actions and convert unambiguous controls to direct domain actions.
2. Define the bounded proposal header, domain payload handles, evidence revisions, and stable reason taxonomy.
3. Create policy bands before numeric weights; specify stable tie-breaks and canonical claim ordering.
4. Integrate locomotion and traversal first for jump/mantle/vault/ledge/ladder/water-exit competition.
5. Add interaction offers and Smart-Object-like claim semantics for exclusive targets.
6. Add ability activation proposals only where actions genuinely share an intent; keep dedicated ability buttons direct.
7. Connect intent disposition to fixed-tick buffering, pause/death/possession/travel flush rules, and prediction history.
8. Add authoritative revalidation, correction, claim generation fencing, and anti-spam/security limits.
9. Publish prompt previews with hysteresis and accessibility alternatives, independent of authoritative claims.
10. Add inspector, traces, scenario tests, tuning telemetry, and content validation before broad content rollout.

## Verification Strategy

- Exhaustively test every shared intent across mode/state/tag/cooldown/target combinations.
- Randomize ECS archetype layout, job completion, worker count, and proposal generation order; identical state yields identical selection.
- Property-test tie-breaking, overflow truncation, score bounds, NaN/invalid input rejection, and policy-band dominance.
- Test edge windows before landing, ledge arrival, cooldown completion, interaction readiness, and target destruction.
- Race two or more participants for ladder slots, vehicle seats, pickups, interactions, and traversal anchors.
- Fault claim grant before revalidation, target revision change after preview, lease expiry at commit, death/disconnect/rollback during claim, and stale authority epoch.
- Compare client prediction with authoritative resolution under latency, loss, different render rates, clock drift, and partial target relevance.
- Verify rejected/claim-raced intents retain or consume exactly per policy and cannot fire later in an unrelated state.
- Accessibility-test direct alternatives, hold/toggle settings, prompt stability, limited inputs, and modes that prohibit automation.
- FP/TP tests use identical authoritative selection while camera/aim evidence and prompt presentation remain perspective-appropriate.
- Performance-test worst contextual geometry, many offers, many abilities, split-screen, resimulation, and proposal overflow.
- Record proposal terms, bands, claims, selected/rejected reason, correction, and disposition for deterministic reproduction.

## Risks and Open Decisions

- Which actions are shared contextual versus direct.
- Whether jump and traversal share one semantic action in all modes.
- Policy bands and domain precedence.
- Score normalization, weight ownership, hysteresis, and tuning workflow.
- Automatic versus explicit traversal and interaction.
- Whether focused UI target biases authority or is presentation evidence only.
- Claimable resource types, lease duration, renewal, and cleanup.
- Behavior after claim failure: next proposal, retain, consume, or prompt.
- Multi-resource proposals and deadlock avoidance.
- Client evidence versus server reconstruction and relevance limitations.
- Prediction scope and correction presentation.
- Accessibility assist influence and competitive/mode constraints.
- Split-screen claims and local-user prompt ownership.
- AI use of the same broker versus separate decision systems.
- Save/replay representation of buffered but unresolved intents and live claims.
- Anti-cheat limits for impossible targets, proposal spam, and stale evidence.
- Telemetry privacy and safe cardinality for targets/proposals.

## Engineering Recommendations

These are Operation Mythology engineering recommendations, not direct source claims:

1. Route direct semantic actions directly; use arbitration only for deliberately shared contextual intent.
2. Require each domain to emit bounded immutable proposals with stable evidence, revisions, claims, and prediction class.
3. Apply eligibility and policy bands before numeric scoring. Never allow raw score magnitude to override cancel, safety, or explicit intent.
4. Use bounded deterministic integer/fixed-point score terms and lexicographic stable tie-breaks.
5. Separate proposal selection, exclusive resource claim, authoritative revalidation, and domain execution.
6. Make claims generation-fenced, short-lived, and acquired in canonical order; selection alone grants no authority.
7. Let clients predict selection for responsiveness, but let the server reconstruct/revalidate and commit the result.
8. Give every intent an explicit terminal disposition. No system may independently clear or consume the shared buffer.
9. Preserve modular domain payloads; the broker owns common metadata and decision policy, not traversal/interaction/ability execution.
10. Publish prompt previews from immutable snapshots with hysteresis, but never use UI focus as authorization.
11. Offer direct/remapped alternatives when contextual ambiguity is high or accessibility requires control.
12. Make proposal generation intent-gated, allocation-free, bounded, parallel-readable, and deterministically merged.
13. Ship an inspector showing all candidates, eligibility failures, score terms, policy band, claims, authoritative correction, and disposition.
14. Gate content on randomized-order determinism, claim races, network impairment, accessibility, and ambiguity telemetry.

## Source Links

- [Epic Games — Enhanced Input in Unreal Engine 5.8](https://dev.epicgames.com/documentation/en-us/unreal-engine/enhanced-input-in-unreal-engine)
- [Epic Games — Add Mapping Context and Input Consumption](https://dev.epicgames.com/documentation/unreal-engine/BlueprintAPI/Input/AddMappingContext)
- [Epic Games — Smart Objects Overview](https://dev.epicgames.com/documentation/en-us/unreal-engine/smart-objects-in-unreal-engine---overview)
- [Epic Games — Understanding the Gameplay Ability System](https://dev.epicgames.com/documentation/en-us/unreal-engine/understanding-the-unreal-engine-gameplay-ability-system)
- [Epic Games — Using Gameplay Abilities](https://dev.epicgames.com/documentation/en-us/unreal-engine/using-gameplay-abilities-in-unreal-engine)
- [Epic Games — Gameplay Tags](https://dev.epicgames.com/documentation/en-us/unreal-engine/using-gameplay-tags-in-unreal-engine)
