# Operation Mythology Mechanics Research

**Timestamp:** 2026-07-27T19:29:18-07:00  
**Subject:** Persistence hardening delta: immutable save generations, schema governance, cloud lineage conflicts, transactional publication, untrusted input, and ECS recovery

## Feature Overview

This is a delta to the existing quest/checkpoint/save-load report, not a replacement baseline. The prior report correctly recommends stable IDs, sectioned snapshots, asynchronous serialization, migrations, generational slots, cloud conflict handling, and transactional load publication. The newly available shared research adds missing precision about what constitutes one durable generation, how a platform atomicity boundary constrains chunk placement, how cloud histories should be compared, how serializer evolution differs from semantic migration, and how imported saves must be validated before allocation or ECS construction.

The hardened model treats a save slot as a lineage of immutable generations:

`fixed-step capture -> immutable domain snapshots -> encode/hash -> stage generation -> verify chunks -> publish manifest/container atomically -> reopen/validate -> advance visible head`

Loading is a separate transaction:

`enumerate candidates -> validate envelope and bounds -> resolve lineage/conflict -> decode -> pure migration -> construct candidate world -> resolve references -> validate invariants -> publish at game-flow safe point`

No live ECS layout, renderer/physics handle, open database file, partially synchronized cloud file, or serializer byte sequence is itself the durable gameplay contract.

## Existing Coverage and Identified Gap

The required recursive scan succeeded:

- `C:\Users\steve\Desktop\GAME SKILLS`: 33 files, 772,647 bytes.
- `C:\Users\steve\Desktop\EXTRA SKILS\Operation Mythology Mechanics`: 31 files, 883,777 bytes, including 30 research reports and the active index.

The shared tree added `2026-07-28_savegame-persistence-schema-migration-cloud-conflicts.md`. Existing mechanics report `operation-mythology-mechanics-20260727-015823.md` already covers quest persistence, checkpoint manifests, immutable snapshots, section versions, async work, ordered migrations, generational commits, cloud conflicts, and replay separation. Repeating those findings would violate the delta-only rule.

Searches showed these meaningful gaps or under-specified decisions:

- no canonical save-generation envelope, parent UUID lineage, per-chunk digest/dependency model, or reopen-before-promote rule;
- no explicit mapping of one logical generation to a platform's atomic container/update boundary;
- no distinction between serializer compatibility, pure semantic migration, and canonical engine-level equality;
- no prohibition on wall-clock last-writer-wins for divergent offline branches;
- no formal merge eligibility restricted to tested commutative domains;
- no requirement to preserve unchosen divergent branches and unavailable DLC/mod records;
- no live-database/WAL backup rule;
- no complete untrusted-input validation sequence before allocation and object construction;
- no per-user writer fencing across sign-out, suspend/resume, or stale async callbacks;
- no bounded delta depth/compaction dependency rule or explicit retention headroom.

## Sourced Facts

These are sourced facts; engineering recommendations are separated later.

1. Epic's Unreal Engine 5.8 documentation recommends `AsyncSaveGameToSlot`; asynchronous saving avoids frame-rate hitches and possible platform certification issues. Epic also notes that save contents are game-specific and that separate SaveGame classes/files can separate global unlocks from playthrough data.

2. Epic documents that some platforms may not support simultaneous save and load. This makes per-user/slot operation serialization a portability requirement rather than an optional optimization.

3. Microsoft's current XGameSave documentation models saves as containers containing blobs. One update applies to one container, can modify multiple blobs, and is atomic: if any part fails, the whole update fails. Microsoft warns that data dependencies across containers are unreliable.

4. Microsoft documents provider initialization/synchronization at start and resume, provider/container cleanup at suspend or termination, quota and update-size limits, offline decisions, and user-visible cloud conflict resolution. The platform lifecycle therefore constrains when a game may safely enumerate, create, publish, or retain generations.

5. Unity Cloud Save write locks return conflicts when a submitted lock no longer matches stored state. The documented choices are to re-read and resolve or deliberately bypass the lock; omitting/bypassing conflict checks can overwrite newer data.

6. Protocol Buffers supports compatible message evolution only under documented field-number/type rules. Its official documentation states that deterministic serialization is not canonical and serialized bytes may change with schema, build, flags, or library versions; serialized bytes are therefore unsuitable as a long-lived semantic equality hash.

7. FlatBuffers supports forward/backward evolution only under rules such as appending fields or assigning stable IDs and deprecating rather than deleting fields. Its compiler provides `--conform` to check that a new schema evolves validly from a base schema.

8. SQLite documents atomic transactions through rollback-journal or WAL mechanisms. Its WAL is part of persistent database state and must remain with the database when copied or moved. SQLite also documents consistent backup approaches, including its backup API and `VACUUM INTO`; copying a live main file alone can create an inconsistent backup.

9. None of these sources defines Operation Mythology's durable domain schema, gameplay merge algebra, save-lineage UI, content-removal compensation, or cross-build support window. Those are project policies.

## Industry-Standard API or Pattern

Use a **manifested immutable generation with lineage-aware synchronization** behind a platform storage adapter.

### Generation envelope

Each committed generation declares:

- magic and envelope version;
- stable slot/user namespace and generation UUID;
- parent generation UUID and monotonic per-slot sequence;
- checkpoint kind, authoritative simulation tick, playtime, authored label, and diagnostic timestamp;
- engine/build, content catalog, schema set, migration, entitlement, and downloadable-content revisions;
- byte order, numeric units, coordinate conventions, and canonical ID encoding;
- chunk directory with stable type ID, schema version, required/optional flag, parent dependency, encoded/decoded sizes, compression/encryption IDs, and cryptographic digest;
- canonical manifest digest and terminal publication metadata supplied by the backend.

Chunks include account settings, playthrough/player state, quests/objectives, inventory/economy, world facts, persistent entities, checkpoint/spawn state, and bounded domain-specific deltas. Accessibility/input settings remain in an account-global generation so a playthrough conflict cannot overwrite them.

### Storage transaction

The generic adapter exposes:

1. `BeginGeneration(slot, expectedParent, generationId)`
2. `WriteImmutableChunk`
3. `FlushAndValidate`
4. `PublishManifestOrContainer`
5. `ReopenAndVerify`
6. `PromoteVisibleHead`
7. `RetainOrCollectGenerations`

One logical generation must fit within one backend atomicity boundary. For XGameSave, mutually dependent blobs belong in one container update because cross-container dependencies are not reliable. A file backend uses unique generation names and a platform-qualified durable replacement primitive. A database backend uses supported transactions and backup/checkpoint APIs rather than copying live files.

The previous known-good generation remains reachable until the new generation has reopened, passed integrity/schema checks, and become the visible head. Manual saves and user-chosen conflict branches have separate retention policy from a coalescible autosave ring.

### Capture and construction

At one fixed simulation barrier, each persistence provider supplies an immutable, generation-tagged snapshot or versioned-page view. The barrier performs no disk/cloud I/O. Workers normalize, sort, encode, compress, hash, encrypt where required, and write under bounded memory/I/O budgets.

Load never mutates the active world incrementally. It validates the envelope and chunks, decodes into bounded intermediate records, runs pure ordered migrations, registers stable identities, resolves references in a second phase, validates domain and cross-domain invariants, then publishes a candidate ECS/service world transactionally at a game-flow safe point.

### Schema and migration governance

Serializer evolution rules are necessary but insufficient. The engine owns stable domain type/field IDs, explicit defaults, unknown-enum handling, units, maximum lengths, and retired-ID reservations. Semantic changes use a new field plus migration rather than reinterpreting old bytes.

Each chunk records schema version. Pure migrations transform `Vn -> Vn+1` without querying live ECS, wall time, mutable services, or network state. Explicit content mapping tables are inputs. A golden save corpus represents every shipped schema and important content revision.

Compute lineage/equality from a canonical engine manifest plus normalized domain digests, not raw serializer bytes.

### Cloud lineage and conflict

After platform synchronization, validate local/cloud candidates and compare their generation UUID/parent chains:

- same generation: identical;
- one descends from the other: select the valid descendant;
- neither descends from the other: divergent offline branches.

Divergent branches are both retained. Resolution UI shows checkpoint, playtime, progress summary, device/session label, and diagnostic save time, but does not silently assume that the latest wall clock is correct. The unchosen branch remains recoverable for a retention window.

Automatic field/domain merge is allowed only when the domain declares and property-tests a commutative, associative, idempotent merge such as set-union unlocks. Currency, inventory ownership, quest branches, world state, and non-monotonic counters are not generically mergeable.

### Security and content absence

Treat local, imported, migrated, modded, and cloud data as untrusted. Before allocating decoded objects, validate identifiers, versions, offsets, integer arithmetic, lengths, total decoded bytes, nesting, collection counts, compression ratios, text encodings, chunk dependencies, references, entitlements, and domain invariants.

Preserve opaque optional records for temporarily unavailable DLC/mod content so loading and resaving the base game does not erase owned state. Missing required content blocks load with a clear reason; missing optional content uses an explicit inert placeholder policy. Client saves never authoritatively restore server economy, payment, authentication, or entitlement state.

## Performance Considerations

- **Asymptotic complexity:** with `E` persistent entities, `F` fields/records, `B` encoded bytes, `D` dirty records, `R` references, `M` migration operations, and `K` chunks, full capture is `O(E + F)`, dirty capture targets `O(D)`, encode/hash/compress/validate is `O(B)`, reference registration/fixup is expected `O(E + R)`, chunk lookup is expected `O(1)` or `O(log K)`, and migration must remain `O(B + M)` unless an explicitly indexed join is declared. Reject accidental quadratic migrations.
- **Allocations and garbage collection:** use bounded snapshot arenas, versioned pages, request queues, encoder/migration scratch, compression contexts, and I/O buffers. Validate lengths before allocation. Do not allocate one managed object per field/entity. Cap concurrent snapshots, decoded size, strings, collection elements, compression expansion, delta depth, and total in-flight bytes.
- **Cache behavior:** extract hot ECS fields in contiguous provider batches, normalize into stable-ID-sorted domain arrays, and keep manifests/chunk descriptors compact. Durable disk layout follows persistence domains rather than live archetypes. Stream large chunks to avoid holding raw, compressed, encrypted, and upload copies simultaneously.
- **Update frequency:** capture only on checkpoint, manual save, meaningful dirty state, transition, or debounced autosave policy. Coalesce pending autosaves before capture; never cancel or replace a generation after durable commit begins. Manual saves remain distinct.
- **Concurrency:** one writer serializes commits per user/slot. Workers process disjoint immutable chunks. Late callbacks validate user, slot, session, generation, and authority tokens. Sign-out/suspend fences new work and prevents stale publication into another user's namespace. Cross-slot concurrency is globally limited by I/O and memory budgets.
- **Fixed-step cost:** the barrier only captures/freeze-copies bounded provider state and records one authoritative tick. It performs no encode, compression, encryption, cloud, or storage work. Providers exceeding the capture budget use copy-on-write/versioned pages or amortized dirty logs rather than extending the fixed step.
- **Serialization cost:** complete snapshots are simplest and bound load time. Chunk replacement or semantic deltas may reduce `O(B)` write amplification for measured large worlds, but must identify/hash parents, cap depth, retain bases, and compact asynchronously. Measure capture bytes, encoded bytes, compression ratio, migration scratch, flush, reopen verification, and p95/p99 load/commit latency.
- **Networking cost:** save blobs do not travel over gameplay replication. Cloud transfer is `O(changed uploaded bytes)` at the backend's blob/file granularity; monolithic files amplify small changes to `O(B)`. Apply bandwidth caps, backoff, quota checks, immutable publication, and conflict metadata limits. Shared multiplayer state remains server authoritative and is restored from trusted server persistence.

## Pros and Cons

**Pros**

- Interrupted writes remain invisible and the previous verified generation stays recoverable.
- Independent chunks enable bounded corruption diagnosis, migration, and measured reuse.
- Lineage detects offline divergence without trusting device clocks.
- Pure migrations and golden saves make long-term compatibility testable.
- Candidate-world publication prevents partial live ECS mutation.
- Strict bounds make cloud/imported saves safer against corruption and hostile input.

**Cons**

- Staging, rollback, conflict branches, and compaction require storage headroom.
- Schema governance and historical migration support create permanent tooling obligations.
- Chunking can conflict with platform atomic-container limits if designed carelessly.
- Branch preservation and user choice complicate sync UX.
- Automatic merge is unavailable for most authoritative gameplay domains.
- Cross-version replay/presentation may remain compatible even when an old save is intentionally retired, requiring separate support policies.

## ECS Architectural Integration

ECS stores stable identity, ownership, persistence class, dirty revision, and compact save-policy metadata. It does not store serializer objects, file offsets, open handles, compression contexts, cloud requests, or migration object graphs.

Suggested integration:

- `PersistentIdentity { stable_id, domain_type, scope, definition_revision }`
- `PersistenceDirty { domain_mask, dirty_revision, last_captured_generation }`
- `SaveAnchor { checkpoint_id, authoritative_tick, world_revision }`
- `OpaqueContentStateRef { content_id, ownership_state, blob_handle }`
- `SaveOperationStatus { user_id, slot_id, generation_id, phase, error_class }` as service-facing state, not per-frame gameplay logic.

Resources/services:

- `PersistenceProviderRegistry`
- `SaveSchemaRegistry`
- `MigrationRegistry`
- `SaveGenerationCoordinator`
- `SaveBackendAdapter`
- `SaveSnapshotArenaPool`
- `ContentMappingRegistry`
- `CloudLineageResolver`
- `CandidateWorldBuilder`
- `PersistenceBudgetsAndTelemetry`

Provider capture runs after authoritative gameplay commits at the fixed barrier. Async workers operate only on immutable snapshots. Candidate load publishes through the existing game-flow transition after world, navigation, physics, quest, inventory, ability, and checkpoint validators acknowledge the same generation.

## Component, System, Resource, and Event Interfaces

### Save generation records

- `SaveGenerationId { slot_namespace, uuid, parent_uuid, sequence }`
- `SaveManifest { envelope_version, generation, tick, build, content_revision, schema_set, chunks, digest }`
- `SaveChunkDescriptor { type_id, schema_version, flags, encoded_size, decoded_limit, codec, dependencies, digest }`
- `SaveCandidate { source, lineage, validation_state, migration_plan, conflict_metadata }`

### Commands

- `RequestManualSave`
- `RequestCheckpointSave`
- `RequestAutosave`
- `RequestLoadGeneration`
- `ResolveSaveConflict`
- `CancelSaveBeforeCommit`
- `AcknowledgePlatformSuspend`

Commands carry user/slot identity, expected visible generation, request token, and game-flow state. Conflict resolution names exact generation IDs; it never identifies a branch only as "newer."

### Events

- `SaveSnapshotCaptured`
- `SaveGenerationStaged`
- `SaveGenerationVerified`
- `SaveGenerationCommitted`
- `SaveGenerationFailed`
- `SaveConflictDetected`
- `SaveConflictResolved`
- `SaveMigrationApplied`
- `SaveCandidateValidated`
- `SaveLoadPublished`
- `SaveLoadRejected`
- `SaveRetentionPressure`

User-facing success is emitted only after durable publication and verification. Telemetry records error categories, versions, sizes, timings, and lineage shape without uploading payload contents by default.

## Integration Plan

1. Freeze the engine-owned envelope, stable domain/type/field ID rules, unit conventions, chunk limits, and support window.
2. Add generation UUID/parent lineage, canonical manifest/domain digests, and previous-known-good retention to the existing save coordinator.
3. Require every backend adapter to document atomicity boundary, flush/durable-replace semantics, quota, size, suspend, sign-in, and conflict behavior.
4. Convert providers to fixed-barrier immutable snapshots and bounded async encode paths.
5. Implement bounds-first envelope/chunk validation, pure migrations, two-phase identity/reference construction, and candidate-world publication.
6. Build schema-conformance CI plus golden saves for every shipped schema/content revision.
7. Add ancestry-based cloud comparison, divergent-branch preservation, explicit conflict UI, and tested per-domain merge declarations.
8. Add DLC/mod opaque-record preservation, entitlement reconciliation, and missing-required/optional-content policy.
9. Qualify file, platform-container, and optional database adapters with power-loss, live-backup, suspend, quota, and multi-device tests.
10. Establish retention/compaction/storage-headroom budgets and ship save inspector, lineage viewer, migration trace, and redacted diagnostics.

## Verification Strategy

- Fault at every byte/write/flush/manifest/pointer/reopen boundary; the visible head must be either the old verified generation or the complete new one.
- Corrupt/truncate/fuzz every header field, offset, length, count, encoding, codec, dependency, hash, and compression ratio before allocation.
- Load every golden schema through each ordered migration; compare normalized domain state, not raw serializer bytes.
- Randomize ECS/archetype/iteration order and prove canonical manifest/domain digests remain stable.
- Validate serializer conformance rules in CI and reserve retired IDs permanently.
- Create divergent offline histories on two devices; verify ancestry classification, branch retention, manual selection, rollback, and no clock-based silent overwrite.
- Property-test every declared auto-merge operation for commutativity, associativity, idempotence, identity, bounds, and invariant preservation.
- Exercise sign-out, user switch, suspend, resume, termination, quota exhaustion, storage removal, network loss, retry, late callback, and stale expected-parent races.
- Verify missing optional DLC/mod state survives load-resave unchanged; missing required content never partially publishes.
- Test SQLite-qualified backends with supported live backup and WAL/journal handling; prohibit raw copying through automated checks.
- Measure worst-case capture barrier, arenas, encoded/decoded bytes, migration time, compaction time, reopen validation, cloud traffic, and p95/p99 commit/load latency.
- Assert no renderer, GPU simulation, transient physics contact, ECS handle, pointer, descriptor, auth token, payment state, or raw personal identifier enters persistent gameplay chunks.

## Risks and Open Decisions

- Envelope and canonical domain-hash specification.
- Generation UUID source, sequence ownership, ancestry retention depth, and conflict-branch expiry.
- Backend targets and each platform's actual atomicity, quota, suspend, and certification rules.
- Full generations versus chunk reuse versus bounded semantic deltas by domain.
- Maximum capture time, concurrent snapshots, decoded bytes, compression expansion, migration scratch, and storage headroom.
- Shipped-schema support window, bridge migrators, rollback support, and removed content compensation.
- Required versus optional chunks and fallback policy for corruption or missing content.
- DLC/mod opaque preservation format and entitlement/privacy policy.
- Which account/profile domains are safely mergeable, and formal merge algebra.
- Conflict UI wording, progress summaries, accessibility, parental/account restrictions, and backup retention.
- Encryption/authentication threat model, key custody, and offline tamper expectations.
- Server-authoritative economy/progression reconciliation after local load.
- Mid-combat/manual-save legality and snapshot consistency across streaming/destruction/quests.
- Candidate-world memory overhead and safe publication/rollback across all services.

## Engineering Recommendations

These are engineering recommendations derived from the sourced facts and the existing architecture:

1. Extend the current generational save design into a canonical immutable envelope with generation UUID, parent UUID, sequence, manifest digest, bounded chunk descriptors, and backend-owned publication state.
2. Keep every mutually dependent generation inside one platform atomicity unit; never assume cross-container or cross-file publication is atomic.
3. Retain the previous verified generation until the new generation has been reopened, fully validated, and promoted.
4. Serialize commits per user/slot and fence every asynchronous callback by user, slot, request, session, and generation tokens.
5. Separate wire-format compatibility from pure semantic migrations and engine-defined normalized equality.
6. Never hash raw Protocol Buffer or other serializer bytes as long-lived semantic identity; hash the canonical engine manifest and normalized domain records.
7. Maintain schema-conformance CI and a golden corpus for every shipped save/content version, with explicit support/retirement policy.
8. Resolve cloud state by generation ancestry. Preserve divergent branches and require explicit user/platform policy rather than silent wall-clock last-writer-wins.
9. Permit automatic merge only for formally declared and property-tested commutative domains; prohibit generic inventory, currency, quest, and world-state merging.
10. Validate all imported/cloud/local saves as untrusted before allocation, migration, reference construction, or live-world publication.
11. Load into a candidate ECS/service world and publish transactionally only after every mandatory domain and cross-domain invariant passes.
12. Preserve unavailable optional DLC/mod records opaquely, reject missing required content clearly, and reconcile entitlements/economy with authoritative services.
13. Use complete generations by default; allow chunk reuse or bounded semantic deltas only after measuring write/upload amplification and defining parent retention/compaction limits.
14. Require backend-specific power-loss, suspend, quota, user-switch, conflict, and live-backup certification before shipping.

## Source Links

- Epic Games, [Saving and Loading Your Game in Unreal Engine 5.8](https://dev.epicgames.com/documentation/unreal-engine/saving-and-loading-your-game-in-unreal-engine?lang=en-US)
- Epic Games, [Async Load Game from Slot—platform concurrency note](https://dev.epicgames.com/documentation/unreal-engine/BlueprintAPI/SaveGame/AsyncLoadGamefromSlot?lang=en-US)
- Microsoft, [XGameSave API overview](https://learn.microsoft.com/en-us/gaming/gdk/docs/features/common/game-save/xgamesave?view=gdk-2604)
- Microsoft, [XGameSave container information and atomic updates](https://learn.microsoft.com/en-us/gaming/gdk/docs/reference/system/xgamesave/structs/xgamesavecontainerinfo?view=gdk-2604)
- Microsoft, [Understanding the Game Saves sync flow](https://learn.microsoft.com/en-us/xbox/gdk/docs/features/common/game-save/game-saves-syncing?view=gdk-2604)
- Unity Technologies, [Cloud Save write locks](https://docs.unity.com/en-us/cloud-save/concepts/write-locks)
- Unity Technologies, [Cloud Save Files](https://docs.unity.com/cloud-save/concepts/files)
- Protocol Buffers, [Proto serialization is not canonical](https://protobuf.dev/programming-guides/serialization-not-canonical/)
- Protocol Buffers, [Proto3 language guide—updating message types](https://protobuf.dev/programming-guides/proto3/)
- FlatBuffers, [Schema evolution and conformance](https://flatbuffers.dev/evolution/)
- SQLite, [Atomic Commit](https://www.sqlite.org/atomiccommit.html)
- SQLite, [Write-Ahead Logging](https://www.sqlite.org/wal.html)
- SQLite, [How to corrupt an SQLite database—safe live backup and journal handling](https://www.sqlite.org/howtocorrupt.html)
