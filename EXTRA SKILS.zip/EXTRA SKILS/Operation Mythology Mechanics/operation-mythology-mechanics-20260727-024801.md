# Operation Mythology Mechanics Delta Research — Gameplay Definition Manifests, Compatibility, Hotfixes, and Migration

**Timestamp:** 2026-07-27T02:48:01-07:00  
**Scope:** Stable gameplay definition identity, immutable revisions, release manifests, dependency closure, client/server compatibility, save/replay provenance, hotfix publication, runtime generation pinning, migration, removed content, mods/DLC, ECS interfaces, performance, and verification.

## Feature Overview

Operation Mythology's items, equipment, abilities, effects, tags, quests, objectives, interactions, movement profiles, traversal policies, difficulty rules, and accessibility policies are authored data. Existing systems reference them by stable IDs, but correctness also depends on the exact released revision and its compatible code/schema.

Use three distinct identities:

- **Logical definition ID:** durable semantic identity, such as `ability:combat.firebolt`.
- **Immutable revision digest:** exact canonical gameplay payload and gameplay-relevant dependency closure.
- **Gameplay manifest ID:** signed release set mapping logical IDs to approved revisions plus schema, protocol, migration, platform, DLC/mod, and policy metadata.

Every match, save, replay, deterministic test, and persisted workflow records the manifest/provenance it used. Live instances either pin the definition revision captured at creation or follow an explicitly declared live-update rule. A hotfix is staged, validated, activated at a legal boundary, and generation-published; it never mutates shared definition objects underneath running systems.

## Existing Coverage and Identified Gap

The required recursive scan found 15 files in `C:\Users\steve\Desktop\GAME SKILLS` and 15 files in the mechanics archive. A new shared report covers the asset build DAG, content-addressable storage, stable asset IDs, output manifests, runtime loading, and hot reload. Asset creation/build mechanics remain outside this report.

Existing mechanics research specifies stable IDs, versioned definitions, save migrations, protocol compatibility, tag governance, deterministic replay versions, and state-transfer schemas. It does not define:

- the difference between logical definition identity and exact released revision;
- one gameplay-relevant manifest spanning all definition families;
- how client, server, save, replay, and hotfix compatibility are classified;
- whether active effects/abilities/quests use captured or updated data;
- atomic activation and rollback of a live data update;
- dependency closure, removed-content tombstones, redirects, and manifest retention;
- how content provenance enters hashes, telemetry, validation, and support.

This is a new gameplay-facing contract enabled by, but separate from, the asset pipeline.

## Sourced Facts

The following are sourced facts, not project recommendations:

- Unreal Engine's Asset Manager distinguishes Primary and Secondary Assets. Primary Assets are globally addressable through a `Type:Name` Primary Asset ID, and the system supports ID/type/name redirects.
- Unreal Asset Bundles associate named dependency lists with Primary Assets and can be loaded asynchronously. The Asset Manager provides discovery, loading, unloading, audit, cooking, and chunking facilities; it does not define game-specific save/network compatibility semantics.
- Unity Addressables uses catalogs to map logical keys to physical content. A remote catalog with a different hash can replace the built-in catalog.
- Unity requires preservation of the published `addressables_content_state.bin` for differential updates to a previous player/content release. Its documentation warns that code or engine/package changes generally require a new player and fresh content build because old serialized content may not be compatible.
- Unity Addressables can block new Addressables requests while catalogs update, recommends unique bundle IDs for safer live catalog updates, and leaves release of stale loaded assets to the application.
- Unity Netcode for Entities exchanges a protocol version containing netcode version, user game version, RPC collection hash, and serialized component collection hash. Incompatible peers are disconnected to avoid undefined behavior.
- Unity documents that relaxing the strict protocol collection check can defer an incompatibility until an unknown type is encountered later in a match, potentially causing a late disconnect.
- Unreal's local network version is, by default, a checksum derived from engine version, project name, and project version string, and projects may override it.
- Godot exposes stable resource UIDs mapped to resource paths. This demonstrates logical identity indirection but does not by itself provide released gameplay semantics or migration.

These mechanisms establish identity, content catalogs, and protocol checks. Operation Mythology must still define which gameplay changes are compatible and how state created under one revision behaves under another.

## Industry-Standard API or Pattern

### Definition record

Each authored gameplay definition compiles to a canonical immutable record:

`{ logical_id, definition_type, schema_version, revision_digest, gameplay_payload, dependency_ids_and_digests, compatibility_flags, migration_metadata }`

The digest excludes presentation-only dependencies unless they alter gameplay timing, collision, targeting, readability policy, or authoritative behavior. Canonical encoding fixes field ordering, numeric encoding, normalization, defaults, and absent/unknown-field behavior.

Logical IDs never derive solely from file paths or display names. Renames use explicit redirects; semantic replacement uses a new ID.

### Release gameplay manifest

A manifest contains:

- manifest ID/digest and signature;
- build/application/protocol versions;
- target platform and mode capabilities;
- definition registry mapping ID → type/schema/revision;
- required gameplay code/plugin modules and serializer hashes;
- dependency edges and bundle/DLC/mod ownership;
- redirects, tombstones, and removal policy;
- supported source-manifest migration routes;
- deterministic/numeric/RNG policy versions;
- authoritative tuning/policy generation;
- creation, approval, rollout, and rollback metadata.

The release pipeline produces it from validated cooked gameplay records. Server and client load the same authoritative manifest class even when presentation packages differ.

### Compatibility classes

Classify a change rather than using one binary version:

- **Presentation-only compatible:** no authoritative or serialized gameplay effect.
- **New-session compatible:** may be used for newly created matches but not injected into existing ones.
- **Boundary-compatible:** can activate at round/checkpoint/travel boundary after explicit conversion.
- **Live-instance compatible:** new instances may use it while old instances stay pinned.
- **Migratable persisted state:** an ordered tested migration exists from specified manifests.
- **Replay-compatible:** the runtime can reproduce or faithfully interpret the recorded revision.
- **Network-compatible:** command/RPC/snapshot schemas and authoritative semantics are mutually supported.
- **Breaking/incompatible:** requires new application/server fleet, match termination, or explicit unsupported-state handling.

Network, save, and replay compatibility are separate decisions. Matching serializers does not prove matching gameplay semantics.

### Runtime generation pinning

Publish immutable registry generations. A runtime instance stores:

- logical definition ID;
- captured revision/generation or explicit live-policy handle;
- captured parameters that must remain stable;
- source manifest ID when persistence/replay requires it.

Default policies:

- instant actions resolve one revision at commit;
- active effects capture magnitude/stack/timing rules at application unless authored as live;
- cooldowns retain their committed deadline/rule;
- quest/objective graph instances pin their graph revision for a playthrough or use a tested boundary migration;
- inventory item instances retain stable logical identity plus schema-required instance data; balance fields resolve by explicit policy;
- match rules pin one authoritative manifest for the match.

### Transactional hotfix activation

`discover -> download -> verify signature/digests -> parse with limits -> build staging registry -> validate schemas/dependencies/redirects/invariants -> simulate migration/compatibility -> choose legal activation boundary -> atomically publish generation -> retain old generations -> observe canary -> commit or rollback`

Do not modify active definition objects in place. New lookups use the published generation; pinned instances retain old revisions. Retire an old generation only after no live instance, save/replay job, rollback history, network connection, or workflow references it.

### Save and replay provenance

Persist:

- manifest ID and required definition revision set or compact closure;
- schema/protocol/numeric policy versions;
- stable logical IDs and instance state;
- migration history and result digest.

Load first resolves the exact manifest where retained. Otherwise it selects a declared migration path, stages state, applies ordered transforms, validates invariants, and publishes atomically. Missing or removed content follows an authored policy: redirect, placeholder preserving ownership/value, disable with explanation, refund/compensate, quarantine, or reject load.

Replays either retain required manifests/definitions, embed a permitted minimal gameplay closure, or declare a supported interpretation migration. Never silently replay against “latest.”

### Multiplayer handshake

Handshake compares:

- application/network protocol;
- serializer/RPC/component hashes;
- authoritative gameplay manifest or compatible-range proof;
- required DLC/mod set and trust/signature;
- deterministic policy where prediction/replay needs it.

Mismatch returns an actionable structured reason and update/join route. Clients cannot supply authoritative definitions; the server selects the match manifest.

## Performance Considerations

- **Asymptotic complexity:** Registry lookup is expected `O(1)` by dense/stable ID. Manifest validation is `O(n + e)` for definitions `n` and dependency edges `e`; cycle checks/topological order are also `O(n + e)`. Digest verification is `O(bytes)`. Migration is `O(records + transforms)`. Retirement uses reference counts or generation-indexed owner sets rather than world scans.
- **Allocations and garbage collection:** Parse and validate in staging arenas. Publish flat immutable tables and compact ID/revision indices. Normal lookups and fixed-tick access allocate zero. Reuse hash, decompression, migration, and diagnostic buffers. Bound manifest/definition sizes before allocation.
- **Cache behavior:** Store hot numeric/tags/policy fields in type-specific contiguous tables indexed by compact runtime IDs. Keep logical strings, source metadata, signatures, dependency graphs, redirects, and localized text cold. Active instances store compact generation/revision handles, not asset pointers.
- **Update frequency:** Registry reads occur at gameplay cadence. Manifest discovery/download/validation is asynchronous and rare. Activation runs only at declared boundaries. Reference retirement and remote-catalog checks use low-frequency/event-driven work. Never rehash the whole registry per frame.
- **Concurrency:** Workers read immutable generations lock-free. One publication coordinator atomically swaps the active registry pointer/generation. Migration and validation operate on staging worlds/data. Old generations remain valid until epoch/reference reclamation proves no readers.
- **Fixed-step cost:** A fixed barrier may swap a generation and emit one event, but parsing, hashing, loading, migration, dependency traversal, and retirement stay outside the fixed step. Cap conversion work per boundary; matches that pin a manifest avoid mid-tick change entirely.
- **Serialization cost:** Saves/replays store compact manifest/revision identifiers and only required provenance, not complete duplicated catalogs by default. Cost is `O(referenced definition closure + instance state)` when embedding closure. Migrations stream by section and use immutable capture. Retaining many old manifests consumes storage and CDN/cache capacity.
- **Networking cost:** Handshake adds a small fixed manifest/protocol tuple plus optional compatible-set proof. Do not transmit full catalogs during gameplay. Content acquisition uses separate authenticated/CDN channels with byte budgets and integrity checks. Hotfix rollout can fragment the player population and fleet; measure mismatch rates, update bytes, join delay, and retained-version demand.

## Pros and Cons

### Pros

- Saves, replays, servers, clients, and support tools identify exact gameplay data.
- Stable logical IDs survive packaging and path changes.
- Immutable generations remove data races and mid-action semantic changes.
- Compatibility becomes explicit and testable rather than inferred from version strings.
- Hotfix rollback and canary analysis have precise provenance.
- Removed content and migrations use authored, auditable policies.

### Cons

- Manifest retention, signing, migration fixtures, redirects, and compatibility matrices add release complexity.
- Pinning old revisions consumes memory/storage and can preserve old balance behavior temporarily.
- Strict matching can split matchmaking populations.
- Overly permissive compatibility risks subtle divergence; overly strict policy blocks safe updates.
- Mods/DLC multiply dependency, trust, and migration combinations.

## ECS Architectural Integration

Gameplay definitions are immutable external resources compiled into ECS-friendly tables. Entities store stable logical IDs plus compact revision/generation handles only where required.

- A `GameplayDefinitionRegistry` resource exposes typed read-only tables.
- A `ManifestGeneration` resource identifies the authoritative published set.
- Instance creation resolves definition and captures policy-defined fields/revision.
- Systems never retain raw authoring object pointers across generation changes.
- Save/replay/network serializers record provenance through a shared compatibility service.
- Hotfix activation enters the existing game-flow readiness/transaction barrier.
- Registry change events invalidate derived caches explicitly; unaffected hot ECS data remains stable.
- Definition validation participates in existing content validation and deterministic test infrastructure.

## Component, System, Resource, and Event Interfaces

### Components

- `DefinitionReference { logical_id, revision_or_generation, policy }`
- `CapturedDefinitionState { revision, captured_fields_handle }`
- `PersistedContentProvenance { manifest_id, migration_revision }`
- `DefinitionMissingState { original_id, source_manifest, resolution_policy }`
- `RegistryDependentCache { source_generation, cache_revision }`

### Resources

- `GameplayDefinitionRegistry`: immutable typed tables and ID index.
- `GameplayManifest { manifest_id, signature, versions, definition_map, dependencies }`
- `ManifestCompatibilityMatrix`: network/save/replay/live/boundary decisions and reasons.
- `DefinitionRedirectAndTombstoneTable`
- `ManifestArchive`: retained manifests/revisions and reference/retirement state.
- `MigrationRegistry`: ordered source→target transforms and fixtures.
- `ManifestTrustStore`: signing keys, revocation, mod/DLC trust namespaces.
- `ContentCompatibilityBudgets`: sizes, generations, migration time, retained versions.

### Systems

- `ManifestDiscoveryAndVerificationSystem`
- `GameplayDefinitionCompileValidationSystem`
- `CompatibilityHandshakeSystem`
- `RegistryGenerationPublicationSystem`
- `InstanceDefinitionCaptureSystem`
- `PersistedStateMigrationSystem`
- `RemovedContentResolutionSystem`
- `OldGenerationRetirementSystem`
- `ManifestTelemetryAndAuditSystem`

### Events and commands

- `ManifestAvailable/Rejected`
- `CompatibilityCheckPassed/Failed { domain, reason }`
- `ManifestActivationRequested/Staged/Committed/RolledBack`
- `RegistryGenerationChanged { old, new, boundary }`
- `DefinitionRedirectApplied`
- `DefinitionMissing/Quarantined`
- `StateMigrationStarted/Committed/Failed`
- `OldGenerationRetired`
- `ClientContentUpdateRequired`

## Integration Plan

1. Inventory every gameplay definition family and declare stable logical ID, schema, canonical encoding, dependency rules, and runtime capture policy.
2. Generate one gameplay manifest from released cooked data, separate from presentation-only catalogs.
3. Add signatures/digests, redirects, tombstones, DLC/mod ownership, and dependency closure validation.
4. Define compatibility classes and independent network, save, replay, live-update, and boundary-update decisions.
5. Compile immutable type-specific ECS tables and replace raw authoring pointers in hot components with stable/compact handles.
6. Pin one authoritative manifest per match; extend connection handshake and structured mismatch responses.
7. Store manifest provenance in saves, replays, checkpoints, workflows, telemetry, and reproduction artifacts.
8. Implement staging migration and removed-content policies with fixtures for every supported released manifest.
9. Add transactional activation, old-generation retention, canary rollout, rollback, and leak-safe retirement.
10. Add release gates that compare manifests semantically and require explicit approval for authoritative changes.

## Verification Strategy

- Deterministic-build tests: identical canonical inputs produce identical revisions/manifests across workers and machines.
- ID tests: rename/move, redirect chain, collision, deletion, reuse prohibition, type change, DLC/mod namespace, and unknown ID.
- Dependency tests: missing edge, cycle, hidden gameplay dependency, presentation-only classification, and closure digest changes.
- Compatibility tests: every manifest pair receives explicit network/save/replay/live/boundary classification; no implicit fallback.
- Handshake tests: code/protocol/serializer/manifest/DLC/mod mismatches produce early structured rejection, never late undefined behavior.
- Hotfix tests: activation during ability/effect/quest/inventory/match activity; old instances follow declared pin/live policy; new instances use the new generation.
- Concurrency tests: readers across generation swap, job completion after swap, rollback history, async save capture, and retirement.
- Migration tests: golden fixtures for every supported source manifest, repeated migration, interrupted migration, removed content, corrupted data, and invariant failure.
- Replay tests: exact old manifest reproduction, retained closure, unsupported manifest, and migration behavior.
- Security tests: forged manifest, digest mismatch, revoked key, downgrade, dependency substitution, oversized/cyclic data, unauthorized mod, and CDN rollback.
- Performance tests: largest manifest, validation/hash time, staging peak memory, lookup cache behavior, migration tails, generations retained, handshake bytes, update download, and population fragmentation.
- Operational tests: canary metrics, rollback after partial rollout, mixed server fleet, reconnect during update, save created before/after activation, and support reproduction by manifest ID.

## Risks and Open Decisions

- Which fields/dependencies are gameplay-relevant versus presentation-only.
- Logical ID format, namespace ownership, redirects, and prohibition on ID reuse.
- Canonical encoding and digest algorithm/version.
- Manifest signing, key rotation, revocation, downgrade protection, and offline trust.
- Match pinning versus boundary/live updates by game mode.
- Active ability/effect/cooldown/quest/item capture policy.
- Compatibility authority and review process.
- Supported save/replay migration horizon and retention cost.
- Removed-content policy by item, quest, entitlement, and mod/DLC ownership.
- Whether balance hotfixes alter existing item instances or only future calculations.
- Multiplayer population split and fleet rollout order.
- Mod compatibility, trust, deterministic/network eligibility, and dependency conflicts.
- Old-generation memory reclamation and maximum concurrent generations.
- Content acquisition during join and behavior when CDN/platform update is unavailable.
- Analytics/support retention and privacy of mod/DLC manifests.

## Engineering Recommendations

These are Operation Mythology engineering recommendations, not direct source claims:

1. Separate stable logical definition IDs, immutable revision digests, and signed release gameplay manifests.
2. Include gameplay-relevant dependency closure in revision identity; exclude presentation-only data only through validated classification.
3. Pin one authoritative manifest per match and record it in saves, replays, checkpoints, workflows, telemetry, and bug artifacts.
4. Treat network serializer compatibility, gameplay semantic compatibility, save migration, and replay interpretation as separate gates.
5. Publish immutable registry generations transactionally. Never mutate definitions in place while jobs or active instances reference them.
6. Give every definition family an explicit capture/live-update policy; default long-lived effects, quests, cooldowns, and match rules to pinned semantics.
7. Stage, verify, validate, and canary hotfixes; activate only at legal boundaries and retain rollback generations.
8. Use redirects only for identity-preserving renames. Use new IDs for semantic replacement and tombstones for removal.
9. Load and migrate persisted state in staging, validate invariants, then publish atomically. Never silently substitute “latest.”
10. Retain exact manifests or sufficient gameplay closures for the promised save/replay support horizon.
11. Reject incompatible peers early with structured reasons and update routes; do not relax hashes and risk late-match failures in production.
12. Compile manifests into dense ECS tables and keep hot lookups allocation-free; keep signatures, strings, dependencies, and migration metadata cold.
13. Sign authoritative manifests and enforce namespace/trust policy for DLC/mod content.
14. Gate releases on semantic manifest diffs, compatibility fixtures, migration tests, mixed-version network tests, and rollback drills.

## Source Links

- [Epic Games — Asset Management in Unreal Engine 5.8](https://dev.epicgames.com/documentation/en-us/unreal-engine/asset-management-in-unreal-engine)
- [Epic Games — FPrimaryAssetId](https://dev.epicgames.com/documentation/en-us/unreal-engine/API/Runtime/CoreUObject/FPrimaryAssetId)
- [Epic Games — FNetworkVersion::GetLocalNetworkVersion](https://dev.epicgames.com/documentation/en-us/unreal-engine/API/Runtime/Core/FNetworkVersion/GetLocalNetworkVersion)
- [Unity Addressables — Content Update Builds Overview](https://docs.unity.cn/Packages/com.unity.addressables%401.21/manual/content-update-builds-overview.html)
- [Unity Addressables — Build Artifacts and Content Catalogs](https://docs.unity.cn/Packages/com.unity.addressables%401.20/manual/BuildArtifacts.html)
- [Unity Addressables — Runtime Catalog Updates](https://docs.unity.cn/Packages/com.unity.addressables%401.14/manual/UpdateCatalogs.html)
- [Unity Netcode for Entities — Network Protocol Checks](https://docs.unity.cn/Packages/com.unity.netcode%401.6/manual/network-protocol-checks.html)
- [Unity Netcode for Entities — NetworkProtocolVersion](https://docs.unity.cn/Packages/com.unity.netcode%401.4/api/Unity.NetCode.NetworkProtocolVersion.html)
- [Godot Engine — ResourceUID](https://docs.godotengine.org/en/latest/classes/class_resourceuid.html)
