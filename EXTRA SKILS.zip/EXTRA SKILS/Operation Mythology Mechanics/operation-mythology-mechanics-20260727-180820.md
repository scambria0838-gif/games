# Operation Mythology Mechanics Research

**Timestamp:** 2026-07-27T18:08:20-07:00  
**Subject:** Authoritative downed, incapacitation, bleedout, revive, carry, elimination, and team-wipe mechanics

## Feature Overview

A downed/incapacitated state separates loss of normal combat capability from final elimination. It creates a bounded rescue window in which allies may revive, move, protect, or abandon the affected participant while enemies, hazards, bleedout, objectives, and match rules continue. The feature sits between damage/health, abilities/status effects, interactions, locomotion, game-flow, inventory/equipment, cameras, networking, spawn/respawn, quests, progression credit, accessibility, and save/load.

This report covers:

- entry from alive into downed, immediate elimination exceptions, and repeated-down penalties;
- authoritative bleedout/tenacity and damage while downed;
- revive eligibility, interaction claims, contributors, progress, interruption, decay, completion, and cancellation;
- self-revive, remote revive, AI revive, carry/drag/throw, execution/finish, surrender, and rescue-zone variants;
- revive health, invulnerability, status cleanup, re-entry locks, and exploit controls;
- simultaneous death/revive/elimination/team-wipe races;
- participant/pawn lifetime, travel, disconnect, reconnect, checkpoints, save/load, and server migration;
- FP/TP camera and input behavior;
- ECS interfaces, data-oriented performance, telemetry, and automated validation.

Animation authoring, ragdoll simulation, visual injury effects, and detailed rigid-body carrying are excluded except for their gameplay-facing state and clearance interfaces.

## Existing Coverage and Identified Gap

The mandatory recursive scan completed successfully:

- `C:\Users\steve\Desktop\GAME SKILLS`: 23 files.
- `C:\Users\steve\Desktop\EXTRA SKILS\Operation Mythology Mechanics`: 23 files before this batch, consisting of 22 reports plus `RESEARCH_INDEX.md`.
- Both trees, all reports, and the active index were readable; no filesystem/access errors occurred.

Existing research already establishes:

- hierarchical player/match flow including labels for alive, downed, dead, spectating, and respawning;
- damage, health, status effects, tags, timers, stacking, immunity, and ability cancellation;
- stable participant versus disposable pawn lifetime;
- authoritative interaction offers, intent arbitration, claims, command validation, and idempotent transactions;
- traversal, cameras, inventory/equipment, quests, progression credit, spawn/respawn, save/load, replay, reconnect, determinism, accessibility, telemetry, and test architecture.

However, “downed” appears only as a state name. The archive has no contract for entry/elimination policy, bleedout clocks, revive claims, multi-reviver progress, downed damage, carry/execution conflicts, completion commit, team-wipe ordering, revive protection, repeated-down rules, disconnect/travel handling, or revive-specific verification.

The new shared gameplay-AI report was audited. Its perception, decision, action-request, reservation, authority, and deterministic-commit architecture is complete for AI and reuses existing gameplay contracts; it does not replace a downed/revive domain design.

## Sourced Facts

These are sourced facts, distinct from the later engineering recommendations:

1. Epic's Fortnite Down But Not Out (DBNO) documentation defines DBNO as a state between healthy and removed/eliminated. It exposes rules for revival, carrying/throwing, shakedown interactions, team/class eligibility, and events for downed, picked up, dropped, thrown, revived, and shakedown transitions.
2. The DBNO device exposes configurable downed invincibility time, tenacity depletion, health after revive, time to revive, and revive-progress decay policies including instant reset and custom decay.
3. Fortnite's DBNO configuration distinguishes “last man standing” behavior: a match can wait for complete elimination rather than ending when all remaining players are merely downed. Epic warns that enabling the behavior without an escape path can leave a solo player downed with no reviver.
4. Fortnite class/device rules show that downed capabilities can vary: an “improved” mode permits additional interactions such as opening doors and dropping items, while other modes restrict them.
5. Epic's Verse DBNO API exposes typed events and explicit `Down`/`Revive` functions; `Revive` transitions an agent from DBNO back to healthy when eligible.
6. Epic's Lyra documentation describes a Death Gameplay Ability triggered by a death gameplay event. It cancels other abilities and signals the health component to begin the death process; a reset ability creates a new pawn in an initial state.
7. Unreal's Gameplay Ability System supports replicated abilities, asynchronous ability tasks, tag-based activation/block/cancel rules, attributes such as health, duration effects, server authority, and limited client prediction. Epic notes that instantaneous damage/attribute changes are not generally reversible through predicted-effect rollback.
8. Unreal Gameplay Abilities require explicit completion/cancellation cleanup; otherwise an ability can remain considered active and continue blocking other actions.
9. A Game Developer design analysis of cooperative revive mechanics observes that a channeled close-range revive creates rescue risk and team cohesion, while remote/self-revive variants trade different costs and timing. This is design commentary, not an engine guarantee.
10. A retrospective on Uncharted 4 describes multiplayer medic AI as explicitly selecting downed allies and activating revive behavior, with fallback handling for awkward geometry. This illustrates why AI revival requires the same target/claim/result contract rather than bespoke health writes.
11. Microsoft's Xbox Accessibility Guideline 108 recommends exposing difficulty dimensions and adjustable resources for core mechanics, including depletion speeds and precision/timing assists. Applying that guidance to revive mechanics is an engineering inference, not an explicit revive prescription.

## Industry-Standard API or Pattern

Use an authoritative hierarchical state machine plus a claimed multi-stage interaction.

**Participant lifecycle**

`Alive → Downing → Downed → Reviving → Alive` is the rescue path.  
`Downed/Reviving → Eliminating → Eliminated → Spectating/RespawnPending/GameOver` is the failure path.

`Downing`, `Reviving`, and `Eliminating` are transactional transition states, not presentation animation names. They give one owner responsibility for resolving simultaneous triggers.

**Down request and policy**

When post-mitigation damage would cross the alive threshold, the authoritative health system emits `LethalOutcomeProposed` with stable damage/evidence identity. A rule system selects:

- enter downed;
- eliminate immediately;
- consume an automatic/self-revive resource;
- apply another mode-specific survival state.

The decision checks match phase, team/lives, damage type, prior-down count, execution/instant-kill tags, environment, checkpoint/mode, and whether a legal recovery path exists. It commits exactly once against participant/pawn generation and health revision.

**Downed state**

Entry:

- cancels or suspends incompatible abilities/interactions/traversal;
- applies `State.Downed` and capability-block tags;
- switches locomotion/stance/collision/camera/input policy;
- starts an authoritative bleedout/tenacity clock;
- applies entry invulnerability if configured;
- publishes one committed event and objective/AI stimulus.

Downed damage never writes “negative health and hope.” A separate downed-health/tenacity policy maps damage, hazards, executions, falls, out-of-world, and ally effects to depletion, interruption, or elimination.

**Revive offer and claim**

The downed entity exposes a typed revive interaction offer only to eligible actors. The server revalidates:

- target is downed and same pawn/participant generation;
- reviver identity/team/class/capability and alive/action state;
- distance, line/use clearance, reachability, world readiness, and forbidden zones;
- revive charges/resources/cooldown;
- claim capacity and contributor policy;
- match/team-wipe/elimination state.

A short claim prevents incompatible execution, carry, teleport, respawn, and competing exclusive revives. Cooperative multi-reviver policy may allow multiple contributor slots rather than one exclusive owner.

**Progress**

Revive progress is authoritative fixed-step state driven by qualified contributors. Policy chooses:

- continuous hold, accumulated work, discrete stages, or instant action;
- single-reviver, fastest-reviver, additive, diminishing-return, or capped contribution;
- pause, preserve, decay, or reset on interruption;
- damage/movement/input/LOS/range/target-motion interruptions;
- reviver replacement and contributor credit.

The client predicts prompt/progress presentation but not completion, health restoration, resource consumption, or invulnerability.

**Completion**

At the commit barrier, revalidate target, contributors, claim, bleedout, resources, match state, and pawn generations. Atomically:

- consume revive costs/charges once;
- end the claim and revive execution;
- transition target to alive;
- restore configured health/tenacity;
- remove downed-only effects and apply post-revive effects/protection;
- rebuild allowed movement/abilities/equipment projections;
- emit one `ReviveCommitted` result with contributor evidence.

**Conflicts**

Define a stable priority matrix for bleedout, execution, revive completion, team-wipe, disconnect, respawn, carry/drop, environmental destruction, and administrative commands on the same tick. Stable event IDs and fixed-barrier ordering replace callback timing.

## Performance Considerations

**Asymptotic complexity**

- Let `D` be downed entities, `O` nearby potential revivers, `C` active contributors, and `E` transition events.
- Naive offer discovery is `O(DO)`; spatial indexes make it approximately `O(D(log N + k))` or event-driven only for nearby candidates.
- Active progress is `O(sum C)` per fixed tick, bounded by small per-target contributor capacity.
- Transition resolution is `O(E log E)` if sorting all events, or `O(E)` with stable bucketed priority and already ordered IDs.
- Team-wipe evaluation should use maintained alive/downed/recoverable counters (`O(1)` per change), not scan every participant.

**Allocations and garbage collection**

- Downed state, claims, contributor slots, timers, and transition proposals use fixed ECS components or pooled records.
- Interaction offers and nearby-target queries reuse bounded buffers.
- No per-tick strings, closures, futures, dynamic contributor lists, or presentation objects occur in authoritative simulation.
- Warm downed/revive ticks perform zero general-heap allocation and no managed GC.

**Cache behavior**

- Store hot state in SoA columns: lifecycle, tenacity, bleedout deadline, protection deadline, claim ID, contributor count, policy ID, revisions, dirty flags.
- Keep cold damage provenance, contributor history, and debug traces in generation-checked pools.
- Batch progress by policy/clock and team counters by match partition.
- Use dense participant/pawn indices internally while retaining stable IDs for network, save, replay, and audit.

**Update frequency**

- State transitions are event-driven at fixed barriers.
- Bleedout uses deadline/timer-wheel scheduling where the rate is constant; per-tick accumulation is used only when effects dynamically modify the rate.
- Active revive progress updates at fixed simulation cadence; UI interpolates between authoritative samples.
- Eligibility/offer queries wake on proximity, state, claim, team, damage, or input changes rather than full-frame scans.

**Concurrency**

- Pure eligibility and offer generation may run in parallel over immutable snapshots.
- Per-target claims, progress, damage, and lifecycle transitions have a single authoritative owner or deterministic command merge.
- Contributors write proposals to owned/thread-local buffers; one target-domain system resolves them.
- Multi-target resources or shared revive charges acquire reservations in canonical order.

**Fixed-step cost**

- Cap new offer queries, revive admissions, contributors, transition proposals, damage records, and completion commits per tick.
- Lethal/downed/elimination transitions are critical and cannot be dropped; reserve capacity and degrade optional telemetry/presentation first.
- Bound repeated damage and progress events through aggregation while preserving semantic instigator/credit evidence.
- Downed timers continue even when AI, animation, or presentation LOD is throttled.

**Serialization cost**

- Save/replay state includes participant/pawn generation, lifecycle, policy revision, down count, tenacity/deadline and clock, claim/contributor state where supported, consumed revive resources, protection, transition IDs, and committed outcomes.
- Normal checkpoints may intentionally collapse active downed/revive state to a safe restore rule; that policy must be explicit.
- Replays record authoritative damage/down/revive/elimination events and ordering, not presentation interpolation.
- Bounded contributor summaries prevent unbounded audit growth.

**Networking cost**

- Replicate lifecycle, tenacity/bleedout facts, claim/progress state to authorized audiences, and committed transition events.
- Clients send revive intent/hold/release with target generation and input tick, never completion or restored health.
- Quantize progress and send on change/interval; the local UI interpolates.
- Private enemy information, accessibility settings, and full contributor/audit data are not broadly replicated.
- Prioritize down/revive/elimination over cosmetic state because these affect targeting, input, objectives, and team-wipe.

## Pros and Cons

**Pros**

- Creates cooperative rescue decisions and reduces immediate spectator time.
- Explicit transition ownership resolves revive-versus-death races.
- Reuses tags, abilities, interactions, claims, timers, damage, and transaction infrastructure.
- Server authority and generations prevent forged revive completion and stale-target writes.
- Policy profiles support solo, co-op, competitive, class, difficulty, and accessibility variants.
- Participant/pawn separation supports reconnect, carry, respawn, and post-revive rebuild.
- Typed events support AI medics, objectives, quests, progression credit, and telemetry.

**Cons**

- Adds a second health-like resource and more lifecycle states.
- Rescue dependency can frustrate solo or mismatched teams.
- Revive loops may trivialize attrition or enable farming.
- Carry/drag and moving targets add collision, streaming, and network complexity.
- Protection can be abused for blocking, scouting, objective contesting, or first-shot advantage.
- Multi-reviver rules complicate progress, credit, claims, and UI.
- Persisting mid-revive state across save/travel/migration increases compatibility burden.

## ECS Architectural Integration

The durable participant owns team, lives, down count, eligibility, and credit identity. The current pawn owns transform, collision, downed locomotion, health/tenacity projection, carry attachment, and presentation-facing state. A downed pawn remains an authoritative gameplay entity; elimination may destroy it later under game-flow policy.

The domain flow:

1. Damage commits a `LethalOutcomeProposed`.
2. `DownedRuleSystem` chooses downed versus elimination using pinned policy.
3. `LifecycleTransitionSystem` commits entry, tags/effects, clocks, and cancellation.
4. `ReviveOfferSystem` publishes eligible interaction offers.
5. Existing intent arbitration selects revive when input is shared.
6. `ReviveClaimSystem` reserves target/contributor slots.
7. `ReviveProgressSystem` consumes fixed-tick contributor facts.
8. `ReviveCompletionSystem` atomically restores state or loses to a higher-priority transition.
9. Game-flow evaluates team-wipe, respawn, spectating, and game over from committed counters/events.
10. Camera, input, equipment, AI, quests, progression, audio, and presentation consume results.

Downed is represented with explicit lifecycle state plus tags, not tags alone. Tags provide cross-system filtering; the state machine enforces legal transitions and generation.

Revive may be implemented as an ability/execution, but the ability cannot own the authoritative target lifecycle. It owns contributor execution and submits progress/completion proposals to the lifecycle domain.

## Component, System, Resource, and Event Interfaces

Conceptual data interfaces:

**Components**

- `PlayerLifecycle { State, StateGeneration, TransitionId, PolicyId, ParticipantId, PawnGeneration }`
- `DownedState { DownCount, EnterTick, Tenacity, MaxTenacity, BleedoutDeadline, ClockId, ProtectionEndTick }`
- `DownedCapabilityMask { Movement, Interaction, Ability, Inventory, Carry, Objective, Communication }`
- `ReviveTarget { ClaimId, ClaimGeneration, ContributorCapacity, Progress, RequiredWork, DecayPolicy, LastProgressTick }`
- `ReviveContributor { TargetId, TargetGeneration, ClaimId, ContributionRate, StartTick, State }`
- `CarriedDowned { CarrierId, CarrierGeneration, AttachmentId, State }`
- `PostReviveState { ProtectionPolicyId, EndTick, CancelMask, ReentryLockEndTick }`

**Resources**

- `DownedPolicyRegistry`: immutable mode/team/class/difficulty policies.
- `LifecyclePriorityTable`: deterministic same-tick transition ordering.
- `TeamRecoveryCounters`: alive, downed-recoverable, reviving, eliminated, disconnected.
- `ReviveClaimTable`: generation-fenced target/contributor reservations.
- `ReviveTimerQueue`: bleedout, progress-decay, protection, and re-entry deadlines.
- `ReviveBudget`: offer/query/admission/contributor/transition/telemetry limits.
- `ReviveDecisionTraceRing`: bounded privileged evidence.

**Systems**

- `LethalOutcomeAdmissionSystem`
- `DownedRuleSystem`
- `PlayerLifecycleTransitionSystem`
- `DownedDamageAndBleedoutSystem`
- `ReviveOfferSystem`
- `ReviveClaimSystem`
- `ReviveProgressSystem`
- `ReviveCompletionSystem`
- `CarryDownedSystem`
- `TeamWipeEvaluationSystem`
- `PostReviveProtectionSystem`
- `ReviveTelemetrySystem`

**Commands and events**

- `LethalOutcomeProposed`
- `PlayerDowned`
- `RequestRevive`
- `ReviveClaimGranted/Rejected/Revoked`
- `ReviveContributionStarted/Stopped`
- `ReviveProgressChanged`
- `RequestCarryDowned/DropDowned`
- `RequestExecuteDowned`
- `ReviveCommitted`
- `BleedoutExpired`
- `PlayerEliminated`
- `TeamRecoveryStateChanged`
- `TeamWipeCommitted`
- `PostReviveProtectionEnded`

Every mutation includes stable request/event ID, participant/pawn generation, policy revision, authoritative tick, and relevant claim/health revisions.

## Integration Plan

1. Define lifecycle states, terminal outcomes, same-tick priority, down eligibility, team-wipe semantics, and owner systems.
2. Add pinned downed/revive policies for solo, co-op, competitive, difficulty, team/class, and accessibility variants.
3. Route lethal damage into a proposal/transition barrier rather than directly destroying the pawn.
4. Add downed tags, ability cancellation, capability mask, tenacity/bleedout clock, invulnerability, and camera/input policy.
5. Expose revive through the interaction/intent architecture with server revalidation.
6. Add generation-fenced target and contributor claims plus bounded single-reviver progress.
7. Implement authoritative completion as one atomic lifecycle/health/effect/resource/event commit.
8. Add interruption and decay matrices for movement, damage, distance, LOS, target motion, input release, and competing transitions.
9. Integrate team counters, team-wipe, spawn/respawn, checkpoint, spectating, and game-over.
10. Add repeated-down, self/remote revive, multiple contributors, AI medic, carry, and execution only after the baseline is proven.
11. Integrate save/load, travel, disconnect/reconnect, streaming, host migration, replay, and content-policy migration.
12. Build lifecycle/claim inspectors, scenario automation, adversarial tests, accessibility options, and telemetry release gates.

## Verification Strategy

**State and ordering tests**

- Exhaustively validate the legal transition graph and reject impossible/reentrant transitions.
- Generate every pair/permutation of same-tick damage, bleedout, revive completion, execution, disconnect, respawn, team-wipe, and admin events; ordering must be stable.
- Verify duplicate/reordered requests and callbacks yield one semantic result.
- Prove every downed participant eventually reaches alive, eliminated, or an explicitly legal suspended state.

**Revive interaction tests**

- Test eligibility by team/class/role/capability, distance, LOS, slope, stairs, ledges, water, ladders, moving platforms, vehicles, doors, and streamed boundaries.
- Test hold/release, contributor join/leave, reviver replacement, decay/reset/preserve, damage interruption, target movement, carry, and claim revocation.
- Race two revivers, revive versus execution, carry versus revive, self-revive versus ally revive, and resource consumption.
- Confirm output health/effects/resources commit once and stale generations cannot revive replacement pawns.

**Damage, ability, and inventory tests**

- Exercise every damage type, hazard, DOT, immunity, invulnerability, execution tag, fall/out-of-world, friendly fire, and repeated-down rule.
- Assert incompatible abilities/interactions/traversal cancel and always clean up.
- Test equipped items, dropped items, revive consumables, quest items, charges, cooldowns, and transaction failure.
- Verify downed/carry/protection tags block exactly the intended actions.

**Multiplayer/lifecycle tests**

- Inject latency, loss, jitter, duplication, reconnect, authority migration, relevancy loss, and late join during every state.
- Disconnect reviver or target; destroy/repossess pawn; unload cell; travel; pause; save; load; end match.
- Test all-player simultaneous down, last recoverable player, no legal reviver, solo modes, team changes, and post-match.
- Ensure clients cannot forge downed state, claim ownership, progress, completion, health, protection, contributor credit, or team-wipe.

**FP/TP and accessibility tests**

- Validate camera/input transitions, prompt focus, progress cues, threat/ally direction, color-independent state, text/icon/audio alternatives, remapping, hold/toggle alternatives, and timing/difficulty options.
- Keep accessibility profile private and apply competitive-policy limits explicitly.
- Ensure downed players retain required communication and do not face uncontrollable camera motion or repeated input.

**Performance and telemetry tests**

- Sweep downed count, potential revivers, contributors, damage/event storms, timer count, team size, and network loss.
- Assert zero warm-tick heap allocation/GC, bounded queries/queues, reserved critical capacity, and fixed-step limits.
- Track down rate, rescue opportunity, revive attempts/success, time downed, bleedout, interruption reasons, repeated-down loops, team wipes, post-revive deaths, contributor distribution, network correction, and abandonment.
- Segment carefully by mode/map/team/party/skill/difficulty/accessibility without exposing sensitive profiles or small cohorts.

## Risks and Open Decisions

- Which lethal outcomes permit downed versus immediate elimination?
- Is downed health separate tenacity, clamped health, a status effect, or another resource?
- Does damage accelerate bleedout, reduce tenacity, interrupt revive, execute, or combine these?
- Which clock governs bleedout, revive, decay, protection, pause, offline, and migration?
- Can downed players crawl, swim, climb, use doors, drop items, communicate, interact, fight, or contest objectives?
- Are allies/enemies allowed to carry, drag, throw, shakedown, interrogate, or execute?
- Is revive exclusive, multi-contributor, additive, capped, fastest-only, or diminishing-return?
- What interrupts progress and whether progress pauses, decays, persists, or resets?
- Are self/remote/AI revives allowed and what costs, cooldowns, LOS, and authority apply?
- What health, resources, effects, invulnerability, movement lock, and re-entry lock follow revive?
- How are repeated downs penalized and when does the count reset?
- When is a team wiped: all downed, all unrecoverable, all eliminated, deadline expiry, or explicit rule?
- Can a solo/last player enter downed without a legal recovery path?
- What happens on target/reviver disconnect, reconnect, pawn replacement, travel, world unload, checkpoint restore, or host migration?
- Do active revive interactions persist across save/load, or collapse to a safe rule?
- How are revive contributions credited for quests, progression, assists, stats, and anti-farming?
- What information is visible to allies, enemies, spectators, and late joiners?
- Which difficulty/accessibility adjustments are allowed in ranked/co-op modes?
- How are carry collision, navigation, fall, hazard, vehicle, and spawn placement validated?

## Engineering Recommendations

These are engineering recommendations derived from the sources and existing architecture:

1. Make downed/revive a dedicated authoritative lifecycle domain between damage and elimination; do not implement it as a health boolean or animation callback.
2. Route lethal outcomes through a fixed-barrier policy decision with stable event identity, participant/pawn generation, health revision, and deterministic same-tick priority.
3. Represent state both as an explicit legal-transition machine and projected gameplay tags/capability masks.
4. Use a separate bounded tenacity/bleedout resource and explicit clock rather than relying on negative health.
5. Implement revive as a claimed interaction/ability whose execution submits progress; only the lifecycle domain commits revival.
6. Revalidate reviver, target, distance/clearance, team/capability, claim, resources, bleedout, match state, and generations at completion.
7. Atomically restore health/state, consume costs, remove downed effects, apply protection, release claims, rebuild projections, and publish credit evidence.
8. Define a complete conflict matrix for damage, execution, bleedout, revive, carry, disconnect, respawn, and team-wipe.
9. Start with one reviver and simple reset-on-interrupt progress. Add multi-contributor, decay, self/remote revive, AI medics, carry, and executions only with explicit policies/tests.
10. Maintain recoverable team counters incrementally and base wipe/game-over on committed lifecycle states, never presentation or callback order.
11. Keep server authority for state, progress, completion, health, protection, costs, and credit; clients predict prompts/progress presentation only.
12. Treat post-revive protection as an authoritative status effect with clear cancel/abuse rules and telemetry.
13. Preserve participant-owned inventory/progression/quests while the pawn changes state; revalidate equipment and pawn-bound grants on revive.
14. Use event/deadline scheduling, fixed-capacity claims/contributors, spatial offer queries, and reserved critical event capacity.
15. Provide mode/difficulty/accessibility policies for timing, depletion, input hold/toggle, cues, and solo recovery without replicating private accessibility labels.
16. Ship a lifecycle inspector showing lethal evidence, policy, state generation, tenacity/deadline, claims, contributors, progress, transition ordering, costs, protection, and network/replay facts.
17. Make exhaustive ordering, race, fault, network, save/migration, security, accessibility, and revive-loop tests release gates.

## Source Links

1. Epic Games, **Using Down But Not Out Devices in Fortnite Creative**  
   https://dev.epicgames.com/documentation/en-us/fortnite/using-down-but-not-out-devices-in-fortnite-creative
2. Epic Games, **Down But Not Out device Verse API**  
   https://dev.epicgames.com/documentation/fortnite/verse-api/fortnitedotcom/devices/down_but_not_out_device
3. Epic Games, **Abilities in Lyra**  
   https://dev.epicgames.com/documentation/unreal-engine/abilities-in-lyra-in-unreal-engine
4. Epic Games, **Understanding the Gameplay Ability System**  
   https://dev.epicgames.com/documentation/en-us/unreal-engine/understanding-the-unreal-engine-gameplay-ability-system
5. Epic Games, **Using Gameplay Abilities**  
   https://dev.epicgames.com/documentation/unreal-engine/using-gameplay-abilities-in-unreal-engine
6. Epic Games, **Gameplay Effects**  
   https://dev.epicgames.com/documentation/unreal-engine/gameplay-effects-for-the-gameplay-ability-system-in-unreal-engine
7. Game Developer, David Wipperfurth, **Co-op Revive Mechanics**  
   https://www.gamedeveloper.com/design/co-op-revive-mechanics
8. Game Developer, Ming-Lun “Allen” Chou, **A Brain Dump of What I Worked on for Uncharted 4**  
   https://www.gamedeveloper.com/design/a-brain-dump-of-what-i-worked-on-for-uncharted-4
9. Microsoft, **Xbox Accessibility Guideline 108: Difficulty options**  
   https://learn.microsoft.com/en-us/xbox/accessibility/xbox-accessibility-guidelines/108
