# Operation Mythology Mechanics Research

**Timestamp:** 2026-07-27T19:35:43-07:00  
**Subject:** Governed scripting delta: untrusted mod isolation, capability IDL, artifact authorization, generation-safe hot reload, process containment, and deterministic multiplayer

## Feature Overview

This report is a delta to the existing governed gameplay-scripting architecture. The earlier report already establishes declarative-first behavior, immutable snapshots, bounded script proposals, least-authority host calls, deterministic fuel, explicit persistent state, rollback, migration, and fault quarantine. It intentionally defers public/untrusted mods and leaves production hot-reload boundaries open.

The uncovered architecture is a trust-tiered package service:

- **first-party authored behavior:** a sandbox-oriented embedded VM or equivalent trusted cooked runtime;
- **curated community packages:** validated WebAssembly components behind generated typed capability interfaces;
- **high-risk server/tool extensions:** optional separate process/container with IPC capabilities and crash containment;
- **native plugins:** signed build-time engine code only, never the public mod boundary.

All tiers consume the same immutable gameplay query snapshots and emit the same bounded validated command buffers. A language VM, Wasm store, package heap, bytecode format, JIT artifact, stack, closure, or linear memory is never authoritative ECS state and never the persistence/rollback format.

Hot reload is a generation transaction, not in-place code patching:

`compile/cook candidate -> validate package and capability world -> instantiate isolated candidate -> export old explicit state -> pure migrate -> initialize/shadow test -> safe-barrier swap -> invalidate old generation -> probation -> retire or roll back`

## Existing Coverage and Identified Gap

The mandatory recursive scan succeeded:

- `C:\Users\steve\Desktop\GAME SKILLS`: 34 files, 808,952 bytes.
- `C:\Users\steve\Desktop\EXTRA SKILS\Operation Mythology Mechanics`: 32 files, 913,504 bytes, including 31 reports and the active `RESEARCH_INDEX.md`.

The shared tree added `2026-07-28_scripting-mod-sandbox-hot-reload-determinism.md`. Existing mechanics report `operation-mythology-mechanics-20260727-030920.md` already covers generic governed gameplay scripting and explicitly says not to create another generic sandbox report without a concrete delta.

The new source closes previously recorded open decisions:

- practical trust tiers for first-party, curated, adversarial, and native extensions;
- a language-neutral capability IDL/WIT-style contract rather than per-runtime hand bindings;
- no ambient WASI, filesystem, network, clock, entropy, or device access;
- one isolate/store per untrusted package or trust-equivalent group rather than one VM per entity;
- distinction among module validation, publisher signature, memory isolation, host authority, denial-of-service control, and process containment;
- deterministic VM fuel versus nondeterministic watchdog/epoch interruption;
- host-call transfer/allocation budgets in addition to guest instruction and memory budgets;
- validation/AOT pipeline and prohibition on blindly deserializing attacker-produced precompiled artifacts;
- generation-safe reload, exported schema state, quiescence, handle invalidation, last-known-good rollback, and probation;
- multiplayer artifact-hash authorization and coordinated reload boundaries;
- save/replay behavior when a package is missing, disabled, updated, or unsupported.

## Sourced Facts

These are sourced facts; project recommendations are separated later.

1. WebAssembly's security documentation states that modules execute in sandboxed environments and cannot escape without appropriate APIs. It also states that the embedding supplies the security policy. WebAssembly memory isolation therefore does not determine which gameplay capabilities a host import may exercise.

2. WebAssembly 3.0 specifies computation independently from a concrete embedding. WebAssembly itself provides an import mechanism rather than ambient APIs/syscalls; files, networks, clocks, and randomness come from an embedding such as WASI or a custom host.

3. A WIT world describes a component's typed exports and required imports. A host can therefore define a package contract in which an untrusted component has only explicitly linked gameplay capabilities.

4. Wasmtime documents fuel-based interruption as deterministic for the same program and fuel absent other nondeterminism. It documents epoch interruption as lower overhead but nondeterministic because it is based on wall time.

5. Wasmtime exposes limits for memory size, tables, memories, and instances. Its component API also exposes host-call fuel to bound guest-to-host transferred data, showing that VM instruction limits and host-side allocation limits are separate controls.

6. Wasmtime's architecture describes a Store as a unit of isolation whose objects do not cross stores, and states that the same Store is not used simultaneously from multiple threads. Its security documentation emphasizes that all external interaction occurs through imports/exports.

7. Wasmtime documents precompilation as a way to separate compiler and execution attack surfaces, but explicitly warns that deserializing precompiled modules/components is unsafe for unknown or untrusted bytes. Validation/signing/cooking provenance remains mandatory.

8. Luau's sandbox guidance says the embedder must cooperate to construct a fully sandboxed environment. Its C API provides immutable shared libraries, separated globals, pointer encoding, interrupt callbacks, and per-category memory accounting.

9. Luau's interrupt documentation states that VM execution reaches the interrupt handler eventually, but a long-running native host function can delay interruption. Host calls therefore require independent bounded-work contracts.

10. Luau uses incremental garbage collection and recommends avoiding temporary allocations in tight loops. Its documentation also notes an indivisible atomic GC step can still scale with heap state, so per-package heaps and GC debt need explicit scheduling/budgets.

11. These sources do not define Operation Mythology's mod distribution, platform approval, publisher trust, package capability list, authoritative numeric profile, save fallback, multiplayer join policy, or player-facing fault handling. Those are project decisions.

## Industry-Standard API or Pattern

Use a **capability-IDL package architecture with trust-tiered isolation and generation transactions**.

### Package manifest

Every cooked package declares:

- stable package ID, version, content hash, publisher/signature, trust tier, and distribution channel;
- source language/compiler/runtime/ABI versions and platform artifact profile;
- deterministic class and permitted simulation phases;
- entry points, dependencies, load order, exported persistent-state schemas, and migration compatibility;
- requested capability IDs/versions and WIT-like import/export world;
- CPU/fuel, host-call work/transfer, memory, GC, stack, table, handle, query, event, command, log, storage, async-work, and instance budgets;
- prediction/rollback/replay/save policy;
- source-map/debug-symbol references separated from shipping runtime artifacts.

A signature proves artifact/publisher identity; it does not prove safe behavior. Every package is validated, linked only to granted capabilities, and subject to runtime budgets.

### Generated capability IDL

Define one small engine-owned IDL that generates:

- native host adapters;
- first-party VM bindings;
- WIT/component interfaces;
- value-record codecs and bounds checks;
- capability/version documentation;
- cost metadata and permission declarations;
- fuzz/property/compatibility test scaffolds.

Expose coarse domain operations:

- immutable fixed-tick query snapshots;
- stable-ID asset/content lookup;
- deterministic clock and addressable RNG;
- bounded target/navigation/physics queries;
- bounded events/subscriptions/timers;
- validated spawn/despawn/effect/interaction/quest/ability command buffers;
- package-local persistent storage mediated by the save service;
- optional local-only UI/audio/VFX/camera commands.

Never expose native pointers, ECS chunk references, arbitrary reflection, filesystem paths, OS handles, sockets, process creation, environment variables, wall clock, entropy, native libraries, renderer resources, authentication/account identifiers, or direct economy/reward/save writes.

Every crossing validates package/generation, capability version, phase, authority, ownership, stable-handle generation, argument ranges, collection lengths, target visibility, rate limits, and budgets. Charge downstream native work and guest-to-host transfer; instruction fuel alone cannot bound a spatial query or huge marshaled list.

### Isolation

Recommended tiers:

1. `TrustedFirstParty`: in-process sandboxed VM, cooked by the trusted toolchain, broad validated gameplay capability profile.
2. `CuratedCommunity`: one Wasm Store/component instance per package or small trust-equivalent group; no ambient WASI; strict fuel, memory, table, handle, transfer, and storage limits.
3. `AdversarialOrServerExtension`: separate worker process/container, IPC form of the same capability IDL, OS sandbox, independent memory/CPU quota, and crash restart/quarantine.
4. `NativeEnginePlugin`: signed, reviewed, platform-certified build-time code; never dynamically accepted from users.

Do not instantiate one VM/store per ECS entity. Package isolates own many compact engine-visible instance records. Deduplicate immutable code across compatible isolates while keeping globals/linear memories/heaps and handles separated.

### Deterministic authoritative profile

Authoritative packages receive fixed ticks, stable-ID-ordered snapshots, deterministic fuel/cost tables, addressable RNG, bounded collections, and a project numeric policy. They receive no wall clock, entropy, locale, filesystem, network, asynchronous completion order, shared memory, relaxed numeric operations, or uncontrolled threading.

Host capabilities use quantized/integer/fixed-point records where cross-platform equality matters. Canonicalize permitted floating edge cases and never hash opaque VM memory. Deterministic fuel controls authoritative interruption; a wall-time/epoch watchdog remains a non-authoritative outer safety mechanism for engine/runtime defects.

Package execution produces only a typed proposal buffer. The authoritative domain validates and commits it at the deterministic phase barrier. Cosmetic/editor packages may use nondeterministic services only when their outputs cannot mutate authoritative simulation.

### Artifact pipeline and multiplayer authorization

Trusted build infrastructure compiles source, validates dependencies/imports, pins runtime/compiler/flags, and produces platform-specific interpreted/AOT artifacts. Unknown guest bytecode/precompiled native blobs are never deserialized directly.

Multiplayer handshake includes package ID, content hash, ABI, deterministic profile, capability world, and relevant definition revisions. The server authorizes every gameplay-affecting artifact. A client with missing, extra, or mismatched authoritative content cannot join/predict. Local cosmetic packages receive only cosmetic capabilities and are excluded from authoritative hashes.

Authoritative live reload occurs only at a coordinated session boundary/restart unless a separately verified synchronized migration protocol commits the identical artifact and state generation across authority, clients, replay, and rollback histories.

### Generation-safe hot reload

Reload phases:

1. asynchronously compile/cook and validate the candidate;
2. verify trust, signature, dependencies, ABI, capabilities, deterministic profile, and budgets;
3. instantiate in a fresh isolate/store;
4. export bounded old state through an engine schema;
5. run pure versioned migration and validation;
6. initialize candidate and optionally shadow-evaluate representative inputs without committing;
7. atomically swap package/instance generation at a fixed safe barrier;
8. invalidate old handles, timers, events, subscriptions, async requests, callbacks, and queued commands by generation;
9. retain last-known-good artifact/state through a probation window;
10. retire old isolate after calls/queues reach quiescence, or roll back if policy permits.

Failure before promotion leaves the old generation active. No executable stack frame, coroutine, closure, userdata, JIT state, or linear-memory image is patched/migrated in place.

### Persistence, rollback, and missing packages

Persist only engine-schema state: package/revision, instance identity, declared state fields, stable handles, timers/deadlines, subscriptions, and deterministic continuation/node identifiers. Long-running behavior is an engine-visible state machine that yields at declared boundaries.

A save records package provenance and required/optional status. Missing required gameplay packages block load with an actionable error or invoke a predeclared replacement migration. Missing optional packages retain opaque bounded state and deactivate their objects/capabilities without erasing ownership. Rollback snapshots explicit bounded state or replays deterministic inputs; it never snapshots arbitrary VM heaps.

## Performance Considerations

- **Asymptotic complexity:** with `I` ready instances, `E` delivered events, `Q` matched query records, `H` host crossings, `C` commands, `B` executed fuel, and `S` explicit state bytes, indexed scheduling is `O(I + E + subscribers reached)`, snapshot extraction is `O(matching chunks + Q)`, execution is bounded by `O(B)`, bridge work is `O(H + transferred records)`, command validation is `O(C)` plus deterministic ordering (`O(C log C)` comparison sort or near `O(C)` fixed/radix keys), and reload is `O(artifact validation + S + affected instances)`.
- **Allocations and garbage collection:** preallocate/pool isolate records, instances, stacks where supported, event/command rings, bridge scratch, handle tables, query views, and diagnostics. Cap guest heap/linear memory plus host-created buffers and handles. Per-package GC debt is scheduled; avoid per-tick tables, closures, strings, userdata, and marshaled object graphs. Process-isolated tiers have OS memory caps in addition to VM accounting.
- **Cache behavior:** keep hot package/generation/capability bitsets, compact instance state, host dispatch tables, and immutable code near execution. Keep source maps, symbols, editor reflection, and detailed audit data cold. Batch invocations by artifact/revision and exchange SoA/value spans rather than pointer-rich object trees.
- **Update frequency:** event/deadline scheduling replaces per-frame polling. Authoritative packages run only in declared fixed phases. Cosmetic packages run at presentation cadence. Validation, compilation, AOT, migration, and shadow tests run off the critical step; reload promotion is one bounded safe-point operation.
- **Concurrency:** each mutable VM/store has one owner thread per call. Parallelism uses independent isolates/shards over immutable snapshots. Scripts never run while ECS structural locks are held. Commands merge at deterministic barriers. Async completions are bounded, generation-tagged events; stale completions after unload/reload are discarded.
- **Fixed-step cost:** hard-cap fuel, host work, queries/results, commands/bytes, event fan-out, and ready instances per package/tick/world. Reserve core simulation capacity. Overrun produces a typed yield/trap/quarantine policy without partial mutation. Deterministic fuel defines replayable authoritative cutoffs; watchdog time is diagnostic/containment only.
- **Serialization cost:** explicit state extraction is `O(S)`, bounded independently of guest heap size. State uses versioned generated schemas and stable IDs. Save/rollback never serializes stacks, closures, raw linear memory, native pointers, allocator state, or compiled code. Migration and package-state compaction run outside the fixed step under decoded-size limits.
- **Networking cost:** gameplay replication carries semantic commands/results and necessary compact state, not source, bytecode, heaps, or arbitrary RPCs. Join/reconnect sends or verifies bounded package manifests/hashes. Packages cannot define unrestricted network schemas. Cosmetic local mods receive no authoritative data. Rate-limit fault reports, package negotiation, and content delivery; distribute artifacts through the platform/content pipeline rather than gameplay packets.

## Pros and Cons

**Pros**

- One capability contract supports first-party scripts, curated Wasm mods, isolated processes, tests, save, replay, and native domain validation.
- Per-package isolation and generation handles contain faults and prevent stale callbacks after reload.
- Deterministic budgets and artifact hashes make multiplayer prediction/replay auditable.
- Process isolation can contain runtime/compiler or hostile-package failure beyond VM memory safety.
- Explicit state schemas make save, rollback, migration, and package removal tractable.

**Cons**

- Two runtime adapters plus optional IPC substantially increase build, security-update, profiling, and QA cost.
- Component lifting/lowering and host crossings add CPU/copy cost; batching becomes mandatory.
- Process isolation adds latency, serialization, startup, and operational complexity.
- Public mods create distribution, signing, moderation, privacy, entitlement, support, and platform-policy obligations.
- Coordinated authoritative hot reload is risky enough that session-boundary restart may remain the only shippable policy.
- Missing or abandoned packages can strand persistent content without predeclared recovery migrations.

## ECS Architectural Integration

ECS remains authoritative and stores only compact package/instance/provenance/generation handles plus schema-owned state.

Suggested components:

- `ScriptPackageBinding { package_id, artifact_hash, entry_id, trust_tier, execution_profile, generation }`
- `ScriptInstance { stable_instance_id, package_generation, state_handle, enabled, fault_state }`
- `ScriptOwner { owner_entity, lifecycle_policy }`
- `ScriptPersistence { schema_id, schema_version, required_package_policy, state_handle }`
- `ModProvenance { package_id, publisher_id, artifact_hash, trust_tier }`
- `ScriptReloadFence { current_generation, candidate_generation, phase, probation_state }`

Service-owned data includes VM/store/process instances, code/AOT artifacts, heaps, linear memories, handle tables, IPC rings, source maps, debug symbols, subscriptions, queues, and migration buffers.

Systems publish immutable query/event snapshots, schedule package batches, execute on VM/process owners, collect proposals, validate and deterministically commit through existing domain commands, publish continuation state, apply fault policy, and reclaim retired generations after quiescence.

No package writes ECS directly. The same capability/command validators apply regardless of runtime tier, FP/TP perspective, local/server role, or mod provenance.

## Component, System, Resource, and Event Interfaces

### Resources

- `ScriptPackageRegistry`
- `ScriptArtifactAuthorizationRegistry`
- `ScriptCapabilityIdlRegistry`
- `ScriptTrustPolicy`
- `ScriptRuntimeAdapterRegistry`
- `ScriptBudgetAndCostTable`
- `ScriptIsolatePool`
- `ScriptProcessSupervisor`
- `ScriptStateAndMigrationRegistry`
- `ScriptGenerationTable`
- `ScriptTraceAndQuarantineService`

### Commands

- `InstallPackageCandidate`
- `AuthorizePackageForSession`
- `EnablePackage`
- `DisablePackage`
- `RequestPackageReload`
- `ApproveReloadGeneration`
- `RollbackPackageGeneration`
- `QuarantinePackage`
- `MigratePackageState`

Commands carry package/artifact hash, expected generation, trust authority, capability-world revision, idempotency key, and scope.

### Events

- `PackageValidated`
- `PackageRejected`
- `PackageAuthorized`
- `PackageInstantiated`
- `PackageBudgetExceeded`
- `PackageCapabilityDenied`
- `PackageTrapped`
- `PackageProcessExited`
- `PackageStateExported`
- `PackageMigrationFailed`
- `PackageGenerationPromoted`
- `PackageGenerationRolledBack`
- `PackageQuarantined`
- `PackageMissingOnLoad`

All simulation events are compact typed records. Source excerpts, stack traces, PII-sensitive paths, and publisher diagnostics remain in redacted protected tooling.

## Integration Plan

1. Keep the existing declarative-first and snapshot/proposal architecture as the immutable gameplay boundary.
2. Define the engine capability IDL, type/bounds rules, versioning, cost metadata, and generated test harness.
3. Classify packages into first-party, curated community, process-isolated, and native build-time tiers; deny public native plugins.
4. Prototype a first-party sandboxed VM adapter and a Wasm component adapter against identical representative ability, interaction, quest, and UI capabilities.
5. Implement package manifests, signing/provenance, trusted cooking/validation/AOT, artifact authorization, and no-ambient-WASI linking.
6. Add deterministic fuel, host-transfer/work, guest/host memory, handle, query, event, command, storage, GC, and world-total budgets.
7. Add per-package isolate/store ownership, optional process supervisor/IPC, fault quarantine, and security-update operations.
8. Implement schema-owned explicit state, missing-package persistence policy, rollback/replay provenance, and golden migration fixtures.
9. Implement candidate-isolate reload, state export/migration, safe-barrier generation swap, stale-handle invalidation, quiescence, probation, and rollback.
10. Add multiplayer manifest/hash handshake and prohibit authoritative live reload outside coordinated session transitions until proven.
11. Benchmark host crossings, batching, GC, isolate count, startup/AOT, process IPC, reload, save, and worst-case hostile packages before enabling community distribution.
12. Complete platform, privacy, moderation, signing, entitlement, content-delivery, crash-reporting, and user-support review before shipping public mods.

## Verification Strategy

- Validate packages against exact IDL world, imports/exports, ABI, compiler/runtime, deterministic profile, capabilities, budgets, signatures, and dependency DAG.
- Attempt filesystem, network, process, environment, native library, wall clock, entropy, clipboard, device, account, hidden-entity, raw-ECS, renderer, save, reward, and arbitrary RPC access; deny by default.
- Fuzz module/component parsers, bindings, value codecs, handle tables, proposal validators, IPC messages, state decoders, migrations, and package manifests.
- Run infinite loops, deep recursion, memory/table growth, allocation/GC churn, huge guest-to-host strings/lists, host-call spam, query fan-out, logging floods, and process crashes; enforce all independent limits.
- Compare deterministic outputs/interruption across supported CPUs, OSes, runtime builds, worker counts, entity order, rollback depth, and replay. Pin or reject mismatched artifacts/configurations.
- Inject reload failure at compile, validation, instantiate, export, migration, initialize, shadow, swap, probation, and retire. Before promotion, old generation remains active; after promotion, rollback follows declared durability policy.
- Complete old timers, subscriptions, async queries, callbacks, commands, and IPC replies after reload/unload; every stale generation must be rejected.
- Save/load at every legal continuation, remove/disable/update packages, corrupt package state, restore opaque optional state, and reject missing required packages without partial world publication.
- Join/reconnect with missing, extra, mismatched, unauthorized, or cosmetic-only packages; server-authoritative hash/capability policy must hold.
- Verify package traps/budget faults never partially mutate gameplay and cannot suppress core cleanup, death, checkpoint, pause, or accessibility controls.
- Profile p50/p95/p99/max fuel, host work, crossings/bytes, GC debt, allocations, instance counts, queues, command validation, startup, AOT load, IPC latency, reload swap, and fixed-step cost.
- Conduct third-party runtime security-update drills, kill-switch/quarantine tests, compromised-signing-key response, mod removal, and redacted diagnostic review.

## Risks and Open Decisions

- Whether public/community mods ship at all, and on which desktop/console/server platforms.
- First-party runtime choice and whether maintaining two adapters is justified.
- Wasm component-model/runtime maturity, version pinning, security patch cadence, and AOT/JIT platform policy.
- Capability IDL vocabulary, evolution, deprecation, and compatibility horizon.
- Trust/signing/distribution/moderation/entitlement/revocation model.
- Per-package versus grouped isolate/store policy and maximum concurrent isolates.
- Which threats require process isolation and acceptable IPC latency.
- Deterministic numeric policy, Wasm features, compiler/runtime matrix, and cross-platform test scope.
- Fuel and host-cost calibration; guest/host memory, GC, transfer, query, command, log, storage, and world-total limits.
- Package fault UX, dependency failure, quarantine, retry, and multiplayer match outcome.
- Authoritative hot-reload boundary, probation duration, rollback after durable consequences, and fleet coordination.
- State-schema ownership, missing/abandoned package fallback, opaque retention, migration support, and repair tools.
- Cosmetic mod data visibility and prevention of competitive information leakage.
- Debug symbol/source-map exposure, crash-report privacy, publisher diagnostics, and appeal/support workflows.

## Engineering Recommendations

These are engineering recommendations derived from the sourced facts and the established mechanics architecture:

1. Preserve one engine-owned snapshot/query/validated-command contract across all script and mod runtimes; capabilities, not language objects, are the durable ABI.
2. Generate runtime bindings, WIT-like worlds, bounds checks, cost metadata, documentation, and tests from one versioned capability IDL.
3. Use trust tiers: sandboxed first-party VM, curated Wasm component per package/group, optional process-isolated adversarial extensions, and signed build-time native plugins only.
4. Give untrusted packages no ambient WASI or OS access. Grant named capability versions explicitly and deny everything else.
5. Validate source/module inputs in a trusted cooking pipeline. Never blindly deserialize attacker-produced VM bytecode or precompiled native Wasm artifacts.
6. Budget deterministic fuel, host work, guest-to-host transfer, guest and host memory, GC debt, stack/tables, handles, queries, events, commands, logs, storage, instances, and world totals independently.
7. Use deterministic fuel for authoritative interruption; use wall-time/epoch/watchdog interruption only as an outer containment mechanism.
8. Run one isolate/store per untrusted package or trust-equivalent group, not per entity; thread-confine mutable runtime state and parallelize independent isolates over immutable snapshots.
9. Treat memory safety as one layer, not complete security. Validate every host input, retain runtime patch operations, and use process containment for the highest-risk tier.
10. Make hot reload a candidate-generation transaction with schema state export, pure migration, safe-barrier swap, generation invalidation, quiescence, probation, last-known-good retention, and typed rollback/failure.
11. Do not support live authoritative multiplayer reload until identical artifact/state migration across server, clients, rollback, replay, and persistence is proven; prefer coordinated session restart.
12. Persist only explicit engine-schema state and package provenance. Never serialize VM stacks, closures, userdata, raw linear memory, allocator state, or compiled code.
13. Define required/optional missing-package policy before shipping persistent mod content and preserve bounded optional state without silently erasing it.
14. Require platform, privacy, distribution, moderation, signing, security-update, performance, save/replay, multiplayer, and accessibility certification before enabling community packages.

## Source Links

- WebAssembly, [Security model](https://webassembly.org/docs/security/)
- WebAssembly, [Specifications—WebAssembly 3.0 and embedding interfaces](https://webassembly.org/specs/)
- WebAssembly, [Portability—host-defined imports and APIs](https://webassembly.org/docs/portability/)
- WebAssembly Component Model, [WIT Worlds](https://component-model.bytecodealliance.org/design/worlds.html)
- Wasmtime, [Interrupting execution—deterministic fuel and nondeterministic epochs](https://docs.wasmtime.dev/examples-interrupting-wasm.html)
- Wasmtime, [Deterministic execution](https://docs.wasmtime.dev/examples-deterministic-wasm-execution.html)
- Wasmtime, [Store resource limits](https://docs.wasmtime.dev/api/wasmtime/struct.StoreLimitsBuilder.html)
- Wasmtime, [Store API—resource and host-call fuel](https://docs.wasmtime.dev/api/wasmtime/struct.Store.html)
- Wasmtime, [Security](https://docs.wasmtime.dev/security.html)
- Wasmtime, [Architecture—Store isolation](https://docs.wasmtime.dev/contributing-architecture.html)
- Wasmtime, [Pre-compiling and cross-compiling WebAssembly](https://docs.wasmtime.dev/examples-pre-compiling-wasm.html)
- Luau, [Embedding a sandboxed Luau virtual machine](https://luau.org/sandbox/)
- Luau, [C API—sandbox, interrupts, and memory categories](https://luau.org/api/)
- Luau, [Performance and garbage-collection behavior](https://luau.org/performance/)
