# Operation Mythology Mechanics Research

**Timestamp:** 2026-07-27T18:15:07-07:00  
**Subject:** Shared party quests, objective contribution and credit, membership churn, late join, reward eligibility, persistence, and authority

## Feature Overview

Shared quests let multiple participants contribute to one objective graph while preserving individual eligibility, narrative position, rewards, privacy, and persistent progress. The central problem is not broadcasting a counter. It is deciding which scope owns the quest, which membership snapshot applies to each event, whether progress is shared or mirrored, how late join/leave/reconnect affect eligibility, how individual gates coexist with a party objective, and when completion/reward rights become durable.

This report covers:

- player, character, party, session, world, account, and hybrid quest scopes;
- shared aggregate progress versus synchronized per-member copies;
- acceptance, invitation, opt-in, prerequisite, narrative, difficulty, and content-entitlement gates;
- membership generations and join/leave/kick/leader-change/disconnect/reconnect;
- authoritative evidence, contribution, objective credit, completion, reward eligibility, and anti-carry/anti-farming policy;
- branching decisions, leader authority, voting, consent, and divergence;
- late join catch-up, members ahead/behind, phased worlds, and unavailable content;
- party dissolution, host migration, save/load, offline/multi-device conflict, and external storage;
- sparse replication, ECS interfaces, performance, telemetry, and automated validation.

Quest writing, narrative design, localization, cinematic production, matchmaking, and social UI are outside scope except where they define gameplay-facing contracts.

## Existing Coverage and Identified Gap

The mandatory recursive scan completed before research:

- `C:\Users\steve\Desktop\GAME SKILLS`: 23 files.
- `C:\Users\steve\Desktop\EXTRA SKILS\Operation Mythology Mechanics`: 24 files before this batch, consisting of 23 reports plus `RESEARCH_INDEX.md`.
- Both roots and the active index were readable; no filesystem/access error occurred.

Existing quest research defines immutable graphs, objective subscriptions, authoritative events, idempotent progress, completion transactions, rewards, stable IDs, checkpoint/save persistence, schema migration, and sparse authorized replication. It explicitly lists quest scope as player/party/account/session/world/mixed but does not choose the ownership model. The state-lifetime report leaves quest sharing/ownership and party membership changes open. Session continuity covers late join/reconnect generically. Progression covers bounded contributor evidence and exactly-once reward credit generically.

No existing report defines:

- party-quest aggregate identity or membership epoch;
- shared aggregate versus mirrored individual progress;
- acceptance and prerequisite matrices per member;
- event-time versus completion-time membership;
- late-join catch-up and leave retention;
- branch authority and dissent;
- mixed shared/personal objective nodes;
- completion snapshot and reward eligibility;
- party dissolution, merge/split, leader migration, and durable ownership;
- privacy/replication of member-specific quest facts;
- quest-specific anti-carry, exploitation, repair, or churn tests.

The most recent shared gameplay-AI report was also audited. Its typed facts/actions and deterministic reservations are comprehensive for AI and do not resolve party quest semantics.

## Sourced Facts

These are sourced facts, not the project recommendations that follow:

1. Epic's Unreal Online Services Lobbies interface models a lobby and its members with separate schema-validated attributes. It emits events for member join/leave, leader changes, lobby/member attribute changes, and invitations.
2. Epic documents distinct leave reasons including voluntary leave, kick, disconnect, and lobby closure. This supports distinguishing membership causes rather than treating every absence identically.
3. A lobby leader can change lobby attributes, join policy, schema, leadership, and membership; ordinary members can change their own attributes and invite players. These are social/session permissions, not quest-authority semantics.
4. Unreal lobbies may persist across multiple matches and can be restored after application startup. Therefore, lobby lifetime and one quest/playthrough lifetime are not automatically identical.
5. PlayFab group entities support membership, roles, permissions, invitations/applications, and group-owned object/file data. PlayFab explicitly lists short-term parties and persistent guilds as possible group uses.
6. PlayFab group operations evaluate caller role permissions; title/server authority can bypass member-role checks. The service provides membership and storage primitives, not game-specific objective-credit rules.
7. PlayFab membership responses include profile versions that can participate in concurrency control, and group/member events record membership changes.
8. Unity Cloud Save can store server-authoritative player or game data from Cloud Code. Its write locks reject writes based on stale versions and require the application to reread and resolve conflicts.
9. Unity Cloud Save custom data can be scoped to a custom ID and is server-authority-only; service limits and write-lock semantics bound but do not define a party-quest aggregate.
10. Unity Lobby session events update local session state before callbacks fire, and Unity documents host migration/session ownership transfer. These lifecycle primitives do not guarantee durable quest ownership unless the game explicitly separates it from the transient host.
11. Academic and industry quest research treats quests as graphs/state machines and highlights shared persistent worlds as a constraint, but no reviewed source establishes one universal party-sharing policy. The architectural policy below is therefore an engineering synthesis.

## Industry-Standard API or Pattern

Use a durable **Quest Aggregate + Membership Epoch + Per-Member Ledger**.

**Aggregate identity**

`QuestAggregateId` is independent of lobby/party ID and owner connection. It contains:

- quest definition ID and pinned revision;
- scope and playthrough/world/session identity;
- shared graph/node/counter state and aggregate revision;
- active branch decisions and decision provenance;
- membership epoch and ordered membership transitions;
- per-member eligibility/participation ledger;
- completion snapshot and reward-delivery state;
- lifecycle: proposed, active, suspended, completed, failed, abandoned, archived.

**Membership ledger**

Every join/leave/kick/disconnect/reconnect/role change becomes a committed transition:

`MembershipChange { event_id, aggregate_id, member_id, old_role, new_role, reason, epoch_before, epoch_after, authoritative_time }`

Do not derive historical eligibility from the current party list. Evidence and completion reference the applicable membership epoch.

**Sharing models**

Choose explicitly per quest or node:

1. **Shared aggregate:** one objective state owned by the party aggregate.
2. **Mirrored individual:** each member owns progress, but accepted evidence fans out under a sharing policy.
3. **Shared unlock, personal completion:** party actions unlock a stage; each member performs personal gates.
4. **World/session objective:** progress belongs to world/session; party membership only controls observation/reward eligibility.
5. **Leader/host story:** one canonical story owner advances; guests receive participation/reward credit without rewriting their personal narrative.

Avoid a global “share quests” toggle that obscures these semantics.

**Acceptance**

At activation, create a member ledger entry:

`MemberQuestState { eligibility, prerequisite_snapshot, content_entitlement, narrative_position, opt_in, participation_state, join_epoch, leave_epoch?, personal_nodes, completion_right, reward_state }`

Policy decides whether members automatically opt in, must accept, may decline, or are ineligible. Ineligible members may help world combat without receiving objective credit or spoilers.

**Evidence and contribution**

Gameplay emits committed semantic evidence with stable event ID, actor/targets, contributors, location, tick, party/aggregate context, and definition revisions. Quest policy then computes:

- relevance to an active node;
- member eligibility at the evidence epoch;
- proximity/presence/participation requirements;
- direct, assist, support, group, or world contribution;
- per-member versus aggregate counter mutation;
- anti-farming/dedupe identity.

The party list supplied by a client is never authoritative.

**Completion snapshot**

When terminal conditions pass, atomically record a bounded snapshot of:

- aggregate revision and membership epoch;
- eligible member IDs/roles;
- participation/contribution summaries;
- prerequisite/content checks;
- completion rights and reward policy revision;
- branch/outcome and evidence digest.

Later membership changes cannot silently rewrite this snapshot. Reward delivery is idempotent per aggregate/member/reward/policy.

**Membership churn**

Policy matrices cover:

- join before acceptance;
- join after progress;
- join after branch;
- join after completion but before reward;
- voluntary leave, kick, disconnect grace, reconnect, and permanent departure;
- party split/merge/dissolution;
- leader/host migration.

Default safe pattern: disconnect preserves membership during a bounded grace period; voluntary leave/kick ends future shared credit; already committed personal credit remains; aggregate progress remains with the aggregate owner; completion eligibility uses the frozen completion snapshot.

## Performance Considerations

**Asymptotic complexity**

- Let `Q` be active aggregates, `N` subscribed objective nodes, `K` bounded members/contributors, and `E` committed evidence events.
- Event routing through type/tag subscription tables is `O(E + matching subscriptions)`, not `O(EQ)` scanning.
- Applying shared evidence is `O(K)` only for bounded eligible members; aggregate-only nodes are `O(1)`.
- Membership changes are `O(1)` plus optional `O(active quests for party)` updates through a party-to-aggregate index.
- Completion snapshot creation is `O(K + active personal nodes)`.
- Never scan all historical members or all player quests from one evidence event.

**Allocations and garbage collection**

- Use pooled/fixed-capacity evidence records, member ledgers, contributor arrays, mutation buffers, and replication deltas.
- Compile quest policies and objective subscriptions into immutable dense tables.
- Warm evidence/credit ticks allocate no general heap memory and trigger no managed GC.
- Historical membership and contribution logs roll into bounded summaries/audit storage under explicit retention.

**Cache behavior**

- Store hot aggregate node state, counters, revision, epoch, dirty masks, and member eligibility in SoA tables.
- Keep cold narrative metadata, verbose provenance, and external delivery state in separate pools/storage.
- Index aggregate by stable party/playthrough/world scope and member-to-aggregate memberships.
- Batch evidence by type/node and mutations by aggregate owner for linear processing.

**Update frequency**

- Quest progress and membership are event-driven.
- Timed objectives use deadline queues/timer wheels; UI countdowns interpolate from authoritative facts.
- Disconnect grace, invitation expiry, and reward retries wake on deadlines, not frame polling.
- Replication sends sparse dirty node/member facts at commit boundaries.

**Concurrency**

- Evidence filtering may run in parallel over immutable aggregate/membership snapshots.
- One authoritative owner serializes mutations per aggregate revision.
- Thread-local proposals merge in stable event/aggregate/member order.
- Cross-player durable rewards use outbox/idempotency workflows, not direct parallel writes from quest evaluation.
- Membership and objective events committed on the same tick use an explicit ordering table.

**Fixed-step cost**

- Bound evidence, affected aggregates, contributors, node transitions, membership changes, completion snapshots, and reward intents per tick.
- Reserve capacity for mission-critical transitions; delay optional UI/telemetry fan-out.
- Detect content that expands one event across excessive members/nodes during validation.
- Party join storms and reconnect bursts are scheduled without starving simulation.

**Serialization cost**

- Persist aggregate ID/revision, quest definition revision, scope owner, graph state, counters, membership epoch/log summary, per-member ledger, branch decisions, completion snapshot, reward/outbox state, and migration version.
- Saves do not serialize transient lobby object pointers or client UI selection.
- Compact membership transitions after support/replay horizons while preserving completion/reward evidence.
- Party aggregates may outlive one session; retention and archive/tombstone policy are explicit.

**Networking cost**

- Replicate shared nodes once per authorized party audience plus sparse per-member private deltas.
- Clients send quest actions/choices with aggregate/member generations; they never send contributor lists, completion, or reward eligibility.
- Use sequence/revision numbers and scoped resync on gaps.
- Do not expose private prerequisites, narrative position, accessibility/difficulty settings, hidden branches, or other members' reward state.
- Late join receives a bounded baseline followed by deltas; large quest histories remain server-side.

## Pros and Cons

**Pros**

- Membership epochs make join/leave races reproducible and auditable.
- One aggregate avoids conflicting duplicate party counters.
- Per-member ledgers preserve eligibility, narrative, privacy, and rewards.
- Explicit sharing models support co-op without forcing identical personal progression.
- Completion snapshots prevent post-completion membership manipulation.
- Stable ownership survives leader/host migration and reconnect.
- Sparse aggregate/member replication scales better than full quest-log broadcasts.

**Cons**

- Mixed shared/personal nodes increase authoring and test complexity.
- Membership history and contribution evidence add storage.
- Late-join/catch-up rules can create spoilers, carries, or repeated content.
- Leader-authoritative branching can frustrate dissenting members.
- Party splits/merges and durable groups create difficult ownership choices.
- Cross-account rewards require durable multi-owner workflows.
- Overly strict eligibility can make cooperative actions feel unrewarding.

## ECS Architectural Integration

Quest definitions, sharing policies, prerequisite predicates, and compiled subscriptions are immutable resources. Runtime aggregates are stable ECS entities or external durable aggregates referenced through generation-checked handles.

Recommended flow:

1. Session/social services emit authenticated membership facts.
2. `PartyMembershipCommitSystem` converts them into game-owned membership transitions and epochs.
3. `QuestSharingAdmissionSystem` creates/updates per-member ledger states.
4. Gameplay domains publish committed semantic evidence.
5. `QuestEvidenceRoutingSystem` finds relevant aggregate/node subscriptions.
6. `QuestContributionSystem` evaluates eligibility and bounded member credit from the captured epoch.
7. `QuestAggregateCommitSystem` atomically applies shared/personal mutations, transitions, and events.
8. `QuestCompletionSystem` freezes the completion snapshot and reward intents.
9. Progression/inventory/outbox systems grant exactly-once results.
10. Replication publishes shared and private projections to authorized clients.

The transient lobby/host does not own quest state. A game-owned party/playthrough identity maps to the aggregate; social services are membership inputs and discovery/presence layers.

First- and third-person presentation consume identical objective facts. Camera perspective never changes contribution authority. World phasing/streaming readiness may affect eligibility but must be represented as explicit authoritative facts.

## Component, System, Resource, and Event Interfaces

Conceptual data interfaces:

**Components**

- `QuestAggregate { AggregateId, DefinitionId, DefinitionRevision, Scope, OwnerId, State, Revision, MembershipEpoch }`
- `SharedQuestNodeState { NodeId, State, Counter, Sequence, DirtyMask }`
- `QuestMemberLedger { MemberId, MemberGeneration, Role, Eligibility, OptIn, JoinEpoch, LeaveEpoch, Participation, CompletionRight, RewardState }`
- `QuestMemberPersonalState { AggregateId, MemberId, PersonalNodeHandle, NarrativeRevision }`
- `QuestCompletionSnapshot { SnapshotId, AggregateRevision, MembershipEpoch, EligibleSetHandle, ContributionDigest, RewardPolicyRevision }`
- `QuestContributionSummary { MemberId, Direct, Assist, Support, Presence, LastEvidenceTick }`

**Resources**

- `QuestSharingPolicyRegistry`
- `QuestSubscriptionIndex`
- `PartyQuestAggregateIndex`
- `MemberQuestIndex`
- `QuestEvidenceDedupeLedger`
- `QuestMembershipTransitionLog`
- `QuestReplicationAudienceMap`
- `QuestSharingBudget`
- `QuestSharingTraceRing`

**Systems**

- `PartyMembershipCommitSystem`
- `QuestShareAdmissionSystem`
- `QuestLateJoinPolicySystem`
- `QuestEvidenceRoutingSystem`
- `QuestContributionSystem`
- `QuestAggregateMutationSystem`
- `QuestBranchDecisionSystem`
- `QuestCompletionSnapshotSystem`
- `QuestRewardIntentSystem`
- `QuestPartyDissolutionSystem`
- `QuestSharingReplicationSystem`
- `QuestSharingTelemetrySystem`

**Commands/events**

- `RequestShareQuest`
- `Accept/DeclineSharedQuest`
- `PartyMembershipChanged`
- `QuestMemberEligibilityChanged`
- `SharedQuestActivated`
- `QuestEvidenceCommitted`
- `QuestContributionAccepted/Rejected`
- `SharedObjectiveProgressed`
- `RequestQuestBranchChoice/Vote`
- `QuestBranchCommitted`
- `QuestCompletionSnapshotCommitted`
- `QuestMemberCompletionGranted`
- `QuestRewardPending/Delivered`
- `QuestAggregateSuspended/Transferred/Archived`

All writes carry stable request/evidence identity, aggregate/member generations, definition/policy revisions, and expected aggregate revision.

## Integration Plan

1. Classify every quest/node as personal, shared aggregate, mirrored, shared-unlock/personal-complete, world/session, or leader-story.
2. Define stable game-owned party/playthrough IDs independent of lobby connection and host.
3. Add membership transition events, reasons, roles, generations, epochs, and disconnect grace.
4. Implement per-member eligibility/opt-in/prerequisite/content/narrative ledger.
5. Route existing committed gameplay evidence through captured membership epochs.
6. Add deterministic contribution and credit matrices for direct/assist/support/presence/group/world facts.
7. Implement atomic aggregate mutation with optimistic revision and idempotent evidence.
8. Freeze completion snapshots and deliver per-member rewards through existing progression/inventory/outbox systems.
9. Add late-join, leave/kick, reconnect, branch, leader migration, dissolution, and ahead/behind policies.
10. Integrate save/load, cloud/service storage, host/server migration, offline restrictions, hotfix pinning/migration, and repair.
11. Split replication into shared party state and private member projections.
12. Build authoring validation, state/membership inspectors, scenario matrices, security tests, and telemetry gates.

## Verification Strategy

**Policy and state tests**

- Exhaustively test all sharing models and mixed shared/personal graph transitions.
- Property-test that one evidence ID mutates each allowed aggregate/member at most once.
- Permute evidence, membership, branch, completion, disconnect, and reward events on the same tick; results must follow explicit ordering.
- Validate impossible prerequisite/narrative/content combinations and no-recovery states.

**Membership churn tests**

- Join before/after acceptance, progress, branch, completion, and reward.
- Leave voluntarily, kick, disconnect, reconnect within/after grace, switch party, merge/split party, transfer leader, close lobby, migrate host/server.
- Verify historical eligibility uses event epochs rather than current membership.
- Ensure completion snapshots cannot be expanded by post-completion joins or reduced by leaves.

**Contribution and reward tests**

- Direct kill/use/collect, assist, heal/support, proximity, dead/downed/spectator, AFK, different world phase, late arrival, disconnect before completion, and reconnect.
- Test personal gates inside shared nodes, ahead/behind story states, optional objectives, branch dissent, and opt-out.
- Duplicate/reorder/retry completion and reward delivery; no double grant or lost pending result.
- Exercise anti-farming, repeated party rotation, alternate accounts, kick-before-reward abuse, and leader manipulation.

**Persistence and migration tests**

- Save/load every aggregate/member state, cloud conflict, unsupported definition, redirected/tombstoned quest, active branch, pending reward, party dissolution, and archived aggregate.
- Crash between objective commit, completion snapshot, reward intent, and external delivery.
- Migrate active aggregates across definition/policy versions or fail into an explicit repair state.

**Security/privacy/network tests**

- Forge party ID, membership epoch, role, contributor list, evidence, prerequisites, completion, branch vote, reward eligibility, and revision.
- Verify only server-observed identity and committed membership/evidence are trusted.
- Late join/relevancy/loss/reorder tests reconstruct shared/private state from baseline plus deltas.
- Confirm private narrative, entitlement, accessibility/difficulty, hidden branch, and reward facts are not leaked.

**Performance/telemetry**

- Sweep active aggregates, nodes, members, evidence fan-out, join storms, completions, reward intents, replication audiences, and reconnect baselines.
- Assert bounded queues, zero warm-tick heap allocation/GC, fixed-step budgets, and graceful overflow.
- Track acceptance, opt-out, eligibility rejection, contribution distribution, late join, churn, completion, reward pending/failure, branch disagreement, abandonment, repair, and duplicate evidence under privacy/cardinality rules.

## Risks and Open Decisions

- Which quests/nodes use each sharing model?
- What stable identity owns the aggregate: party, playthrough, session, world, guild, or leader?
- Does joining a party auto-accept, invite, mirror, or merely expose quests?
- Are prerequisites checked at acceptance, evidence, completion, reward, or several stages?
- Can ineligible/ahead/behind members contribute without receiving progress or spoilers?
- Is event eligibility based on event-time membership, completion-time membership, both, or a grace rule?
- What proximity, presence, participation, assist, support, AFK, death, spectator, and phase criteria apply?
- Does late join inherit prior progress, begin at current node, receive catch-up tasks, or stay personal?
- What progress/reward survives voluntary leave, kick, disconnect, party switch, and dissolution?
- Who chooses branches: leader, owner, unanimous vote, majority, per-member choice, or authored policy?
- Can a party split/merge active quest aggregates?
- How does leader/host migration differ from aggregate ownership transfer?
- When is completion eligibility frozen, and can contributors leave before rewards?
- Are rewards equal, contribution-weighted, personal, choice-based, entitlement-gated, or claimable later?
- How are repeated joins, carries, kick abuse, boosting, and alternate accounts constrained?
- Which quest facts are shared, private, hidden, or spectator-visible?
- Can offline/listen-server play authoritatively modify shared durable quests?
- How long are membership/evidence/completion records retained and who may repair them?
- How do definition hotfixes migrate mixed shared/personal active states?

## Engineering Recommendations

These are engineering recommendations derived from the sources and existing architecture:

1. Separate transient social lobby membership from durable game-owned party/playthrough quest identity.
2. Model every shared quest as one versioned aggregate plus a per-member ledger; never infer historical rights from the current party list.
3. Assign an explicit sharing model to every quest/node rather than a global share toggle.
4. Commit every membership change with reason, role, generation, epoch, and authoritative time; define same-tick ordering against evidence/completion.
5. Capture eligibility at evidence time and freeze a completion snapshot before reward delivery.
6. Keep aggregate progress, personal gates, narrative position, opt-in, entitlement, completion right, and reward state separate.
7. Route only committed semantic gameplay evidence into quests and compute contributors server-side from bounded authoritative facts.
8. Deduplicate by evidence/aggregate/node/member/policy and apply mutations atomically under aggregate revision.
9. Default disconnect to bounded grace, voluntary leave/kick to no future credit, committed personal credit to retention, and post-completion membership changes to no effect on the frozen snapshot.
10. Use explicit late-join/catch-up policies per quest and prevent unintentional narrative spoilers or progression skips.
11. Make branch ownership/consent explicit; preserve dissenting members' personal story state where required.
12. Deliver rewards idempotently per aggregate/member/reward/policy through existing progression/inventory/outbox workflows.
13. Persist aggregates independently of host/connection and pin definition/policy revisions; require explicit migration/repair.
14. Replicate one shared projection plus private per-member deltas to authorized audiences.
15. Bound members, evidence fan-out, transitions, completion snapshots, baseline size, and audit retention; use compiled indexes and event-driven processing.
16. Ship an inspector showing aggregate revision, membership epochs, per-member eligibility, evidence/contribution, branch provenance, completion snapshot, reward/outbox, and repair history.
17. Make churn matrices, concurrency, duplicate/reorder, security/privacy, persistence/migration, anti-abuse, and performance tests release gates.

## Source Links

1. Epic Games, **Lobbies Interface in Unreal Engine 5.8**  
   https://dev.epicgames.com/documentation/unreal-engine/lobbies-interface-in-unreal-engine
2. Epic Games, **FLobbyEvents API**  
   https://dev.epicgames.com/documentation/unreal-engine/API/Plugins/OnlineServicesCommon/FLobbyEvents
3. Unity Technologies, **Lobby events**  
   https://docs.unity.com/en-us/mps-sdk/lobby-events
4. Unity Technologies, **Migrate session host**  
   https://docs.unity.com/en-us/lobby/host-migration
5. Unity Technologies, **Store data using Cloud Code / Cloud Save**  
   https://docs.unity.com/en-us/cloud-save/tutorials/cloud-code
6. Unity Technologies, **Cloud Save write locks**  
   https://docs.unity.com/en-us/cloud-save/concepts/write-locks
7. Microsoft PlayFab, **Groups, Guilds and Clans**  
   https://learn.microsoft.com/en-us/gaming/playfab/community/associations/groups/
8. Microsoft PlayFab, **Entity Groups quickstart**  
   https://learn.microsoft.com/en-us/gaming/playfab/community/associations/groups/quickstart
9. Microsoft PlayFab, **Groups REST API**  
   https://learn.microsoft.com/en-us/rest/api/playfab/groups/groups
10. Microsoft PlayFab, **Entity Programming Model**  
    https://learn.microsoft.com/en-us/gaming/playfab/features/data/entities/
11. Sullivan, Grow, Mateas, and Wardrip-Fruin, **Towards Adaptive Quest Narrative in Shared, Persistent Virtual Worlds**  
    https://cdn.aaai.org/ojs/12540/12540-52-16062-1-2-20201228.pdf
