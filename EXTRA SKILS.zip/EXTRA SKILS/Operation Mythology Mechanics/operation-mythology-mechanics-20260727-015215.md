# Operation Mythology Mechanics Research

**Batch timestamp:** 2026-07-27T01:52:15-07:00  
**Subject:** Authoritative interactions, inventory, equipment, pickups, containers, stacking, and transactional item ownership  
**Scope:** Generic modular ECS; data-oriented runtime; offline and multiplayer; no production code

## Feature Overview

This batch defines how players discover and invoke interactions and how the game transfers item ownership without duplication, loss, or presentation-driven authority. It covers:

- focus, proximity, line-of-sight, and contextual interaction offers;
- pickup, drop, move, split, merge, equip, unequip, consume, trade, loot, and container operations;
- immutable item definitions versus mutable item instances;
- stackable commodities versus uniquely identified/durable/procedural items;
- equipment slots, granted capabilities, spawned presentation, and possession changes;
- server authority, prediction policy, replication, persistence, and audit history.

The central rule is that every ownership-changing operation is a validated transaction over stable item/container identities and expected revisions:

`request -> validate -> reserve -> commit atomic mutations -> emit result/delta -> present`

UI drag-and-drop, pickup animation, and visible equipped meshes project the committed state. They are not the state.

## Existing Coverage and Identified Gap

The required recursive scan found eight `GAME SKILLS` files covering renderer/GPU architecture, ECS/job scheduling, and temporal reconstruction. The dedicated mechanics folder contains the advanced traversal report and its index. No report covers interactions or item ownership.

Earlier mechanics research established tick-addressed input commands; game-flow research established transactional transitions; world research established stable entity identity and persistence boundaries. This batch uses those principles but adds the missing item/container schema, atomic mutation protocol, equipment derivation, interaction-offer boundary, replication delta, and failure semantics.

The folder index also contained a mojibaked quote in its traversal entry. The next index publication corrects that encoding defect without changing its claim.

## Sourced Facts

These are sourced facts:

- Epic’s Lyra documentation distinguishes inventory items from equipment. Inventory represents possessed/stowed items and persists item state; equipped objects are created while in use, can spawn actors and grant abilities, and may have different ownership/replication visibility. Lyra uses immutable item definitions, mutable item instances, extensible fragments, stack counts, and equipment bookkeeping. [Epic: Lyra Inventory and Equipment](https://dev.epicgames.com/documentation/en-us/unreal-engine/lyra-inventory-and-equipment-in-unreal-engine)
- Lyra documents inventory ownership on the controller and equipment ownership on the pawn. This allows persistent possession to outlive a particular pawn while equipped representation follows the currently possessed pawn. [Epic: Lyra Inventory and Equipment](https://dev.epicgames.com/documentation/en-us/unreal-engine/lyra-inventory-and-equipment-in-unreal-engine)
- Unreal’s Gameplay Ability System can grant/remove abilities, tags, attributes, and effects; in multiplayer it replicates state, sends player requests to the server, and verifies authorization. Epic states server-owned-object interactions must be routed through a locally owned actor and then authorized on the server. [Epic: Gameplay Ability System](https://dev.epicgames.com/documentation/en-us/unreal-engine/understanding-the-unreal-engine-gameplay-ability-system)
- Unreal Gameplay Tags are centrally defined hierarchical labels used for object properties, capabilities, events, and triggers. [Epic: Gameplay Tags](https://dev.epicgames.com/documentation/unreal-engine/using-gameplay-tags-in-unreal-engine)
- Unreal Fast Array replication uses stable replication IDs/keys to send changed and deleted elements rather than an entire array. Epic notes list indices are not guaranteed to match between server and client. [Epic: Fast Array Type Helper](https://dev.epicgames.com/documentation/unreal-engine/API/Runtime/NetCore/TFastArrayTypeHelper)
- Unity Netcode for GameObjects is server-authoritative by default: the server normally spawns/despawns network objects and can assign or change ownership. [Unity Multiplayer: NetworkObject Ownership](https://docs-multiplayer.unity3d.com/netcode/2.2.0/basics/networkobject/)

## Industry-Standard API or Pattern

### Definitions, instances, stacks, and containers

`ItemDefinition` is immutable authored data: stable definition ID, category/tags, maximum stack, size/weight, equip profile, interaction verbs, persistence schema, presentation keys, and fragment/trait references.

`ItemInstance` is mutable identity-bearing state: stable instance ID, definition ID, quantity, durability/charges, rolled properties, binding/quest flags, owner/container location, revision, and optional child-container ID.

Use no instance per individual unit for fungible items unless unique mutable state requires it. A stack is one instance plus quantity. Unique weapons, procedural affixes, durability, attachments, and quest provenance require instance identity.

`Container` is a stable owner of ordered or slotted entries with constraints: capacity, weight/volume budget, accepted tags, access policy, replication audience, persistence owner, and revision.

Equipment is a derived container/view with named slots and compatibility rules. Equipping moves or references an inventory item into an equipment assignment, applies a deterministic grant set, and creates presentation proxies. Unequipping reverses grants and destroys proxies while preserving the inventory instance.

### Interaction offers

World objects expose data-driven `InteractionOffer` records:

- verb/action ID and localized presentation key;
- target and optional item/container IDs;
- range, view, posture, team, tag, lock, and ability requirements;
- authority and prediction policy;
- duration/hold behavior;
- priority and exclusivity;
- server validation handler ID.

The client may score offers for focus/UI using distance, aim alignment, visibility, and intent. The server independently validates the selected offer against authoritative state at execution. A client never sends “give item”; it sends “attempt offer X on target Y with request sequence Z.”

### Transaction command

Use one mutation language:

- `AcquireWorldPickup`
- `Transfer`
- `SplitStack`
- `MergeStacks`
- `Swap`
- `Equip`
- `Unequip`
- `Consume`
- `Drop`
- `Destroy`
- `Craft/Transform`

Each command carries request ID, initiator, source/destination container and expected revisions, item instance and expected revision, quantity, operation parameters, and authoritative tick/time.

Validation checks identity, revisions, access/ownership, range/context, locks/reservations, quantity, capacity, stack compatibility, equipment rules, quest/trade restrictions, and gameplay costs. Commit applies all mutations or none, increments revisions, writes an audit result, and emits deltas/events.

Requests are idempotent by `(client/session, request ID)`. Retrying a timed-out pickup returns the prior result rather than transferring twice.

### World pickups and reservations

A world pickup is a container/item representation with one authoritative claim. On attempt, the server validates, reserves for the transaction, transfers quantity, and then despawns or updates the pickup. Presentation can predict focus and animation but should not predict unique ownership unless rollback of all dependent gameplay is supported.

Shared-loot policies—first claimant, per-player instancing, party roll, ownership window, or shared container—are explicit data, not race-dependent implementation accidents.

## Performance Considerations

### Asymptotic complexity

Let `n` be entries in a container, `s` equipment slots, `o` nearby interaction offers, `m` mutations in a transaction, and `d` changed entries replicated.

- Item lookup is `O(1)` average through instance-ID indexing.
- Slot access is `O(1)`; filtered inventory queries are `O(n)` unless maintained indexes justify their update cost.
- Stack insertion is `O(k)` over compatible stacks; keep category/definition indexes for large containers.
- Offer scoring is `O(o)` after spatial broad phase, with a fixed retained top-`K`.
- Transaction validation/commit is `O(m)` plus constraint checks; ordinary operations have fixed small `m`.
- Delta replication is `O(d)` rather than `O(n)` when stable dirty IDs are used.

Avoid global searches for instance ownership. Maintain one authoritative location index.

### Allocations and garbage collection

Warm interaction scoring, request validation, ordinary transfers, and delta construction must allocate zero heap objects. Use fixed request/result rings, pooled transaction scratch, value-type mutations, stable numeric IDs/tags, and container capacity reservation.

Do not instantiate world/equipment presentation during validation. Stage grants/spawns and publish after commit. UI builds views from snapshots/deltas and owns its own recyclable view models.

### Cache behavior

Store container entries contiguously and keep hot fields—instance ID, definition ID, quantity, revision, slot—in compact arrays/structs. Large procedural property blobs, localized text, icons, meshes, and audit descriptions remain cold behind handles.

Maintain an ID-to-location hash index and optional per-definition stack index. Excess indexes harm mutation locality; add them only from query telemetry.

### Update frequency

Inventory does not tick. It changes on commands. Interaction proximity broad phase may update at fixed or throttled cadence; fine focus scoring runs for local players at presentation/fixed cadence as needed. Equipment effects update only through their owning systems.

Expiration, reservation, trade, and timed-use records use timer services, not scans of every inventory each frame.

### Concurrency

Transactions are prepared in jobs only from immutable snapshots. Authoritative commit is serialized per involved container set using stable ordering or a single-owner partition. Never await while holding container locks.

For cross-partition trade/storage, use reservation and a coordinator with timeout/compensation. Within one server simulation, prefer a deterministic commit barrier and command buffer.

### Fixed-step cost

Gameplay-facing consume/equip/drop commands apply at defined tick barriers. Place a per-tick transaction/mutation budget and queue excess noncritical work. Critical pickup/equip latency must be measured separately from bulk sorting/crafting.

Predicted simulation reads a compact derived loadout/capability snapshot, not mutable UI container structures.

### Serialization cost

Save definition ID, instance ID, quantity, mutable property schema, owner/container/slot, revisions, nested-container relation, and binding/provenance flags. Definitions are referenced, not duplicated. Serialization is `O(total persisted instances + properties)`.

Version item definitions and instance property schemas. Missing definitions need explicit quarantine/substitution/failure policy. Detect cycles and depth limits in nested containers.

### Networking cost

Replicate only containers relevant to a client, using stable entry IDs and add/change/remove deltas. Do not rely on matching array indices. Equipment visible to observers is a compact public projection; private inventory details remain owner/server only.

Requests are small and sparse. Results include request ID, success/failure reason, authoritative revisions, and changed-entry deltas. Server validation is `O(requests * mutations)`. Rate-limit/fuzz hostile requests and cap batch sizes.

## Pros and Cons

### Pros

- Transactional ownership eliminates partial swaps, duplication, and most pickup races.
- Definition/instance separation keeps content data shared and mutable state compact.
- Stable IDs/revisions support replication, persistence, audit, and idempotency.
- Inventory can persist across pawn death while equipment follows possession.
- Interaction offers provide one extensible UI/gameplay boundary.
- Sparse deltas scale better than full inventory snapshots.

### Cons

- Stable identity and revision checking add metadata.
- Atomic multi-container operations require ordering/reservations.
- Highly generic fragments can hide cost and dependencies.
- Prediction of ownership changes is risky and often not worth visual latency savings.
- Nested containers and procedural items complicate save migrations.
- Public/private projections require additional schemas.

## ECS Architectural Integration

Suggested system order:

1. `InteractionBroadphaseSystem`
2. `InteractionOfferBuildSystem`
3. `InteractionFocusSystem`
4. `ItemCommandIngestSystem`
5. `ItemTransactionValidateSystem`
6. `ItemTransactionCommitSystem`
7. `EquipmentDerivationSystem`
8. `GrantedCapabilitySystem`
9. `WorldPickupProjectionSystem`
10. `InventoryReplicationSystem`
11. `InventoryPersistenceJournalSystem`
12. `InventoryTelemetrySystem`

Containers and instance property slabs can be resources/external stores referenced by ECS handles; creating one entity per fungible stack is optional, not mandatory. World pickups and visible equipped objects are ECS entities projecting stable item IDs.

Structural changes and grants publish only after transaction commit. Observers consume committed deltas.

## Component, System, Resource, and Event Interfaces

### Components

`InventoryOwner { containerId, authorityId, replicationAudience }`

`WorldPickup { containerId/itemId, offerSetId, respawnPolicy, claimState }`

`EquipmentState { equipmentContainerId, loadoutRevision, derivedGrantSetHandle }`

`InteractionProvider { offerProviderId, stateRevision, interactionTags }`

`InteractionFocus { targetId, offerId, score, evidenceTick, targetRevision }`

`VisibleEquippedProxy { ownerId, slotId, itemDefinitionId, itemInstanceId?, presentationKey }`

### Resources

`ItemDefinitionDatabase`: immutable definitions/fragments and schema migrations.

`ItemInstanceStore`: dense mutable records, property slabs, generation-checked handles.

`ContainerStore`: entry arrays, constraints, revisions, locks/reservations, replication metadata.

`ItemLocationIndex`: item instance to container/slot mapping.

`ItemTransactionQueue`: bounded requests, validation results, commit records, idempotency cache.

`InteractionQueryService`: spatial target discovery, line-of-sight evidence, offer scoring profiles.

`InventoryAuditJournal`: compact committed operation records for diagnostics/persistence/security.

### Events

- `InteractionOfferFocused`
- `InteractionStarted/Interrupted/Completed`
- `ItemTransactionAccepted/Rejected`
- `ItemAdded/Removed/QuantityChanged`
- `ItemTransferred`
- `EquipmentSlotChanged`
- `CapabilityGrantSetChanged`
- `WorldPickupClaimed/Respawned`
- `ContainerRevisionChanged`

All ownership events carry transaction/request ID and post-commit revisions. Presentation and achievements deduplicate by transaction ID.

## Integration Plan

1. Define stable definition, instance, container, slot, offer, transaction, and request IDs.
2. Build immutable definitions plus compact instance/container stores and location index.
3. Implement single-container add/remove/split/merge with invariant tests.
4. Implement atomic cross-container transfer/swap and idempotent request results.
5. Add world pickup offers, server validation, claim reservation, and drop projection.
6. Add equipment slots, derived grants, visible proxies, and possession/death behavior.
7. Add owner/public replication deltas and revision-based reconciliation.
8. Add persistence migrations, audit journal, nested-container validation, and missing-content policy.
9. Add trade/crafting/bulk operations only after core transaction correctness and performance gates.

## Verification Strategy

- Property-based tests conserve item quantity/identity across arbitrary valid command sequences.
- Assert every instance has exactly one valid location or an explicit transient reservation state.
- Fuzz stale revisions, duplicate requests, reordered packets, invalid IDs, oversized quantities, nested cycles, and hostile batch sizes.
- Race two clients for one pickup and verify one committed owner.
- Disconnect/crash at every transaction phase; verify restart/journal policy neither duplicates nor loses committed items.
- Test full containers, weight/slot limits, split/merge boundaries, unique properties, durability, bindings, quest items, and recursive containers.
- Equip/unequip across pawn death, respawn, possession, travel, save/load, and network reconnect.
- Assert zero warm-path allocations and measure mutation latency, delta bytes, index misses, queue depth, rejection reasons, and audit volume.
- Verify UI cannot create state by drag/drop and correctly reconciles rejected optimistic rearrangement.

## Risks and Open Decisions

- Grid, slot, weight, volume, or hybrid container model.
- Whether stack identity survives merge/split and how provenance is retained.
- Inventory owner lifetime: account, player state/controller, pawn, party, or world.
- Prediction policy for rearrangement, consumption, pickup, and equip.
- Whether equipment moves an item or references/reserves it in inventory.
- Nested container depth and weight propagation.
- Trade atomicity across server shards/services.
- Loot instancing/claim policy.
- Item-definition patch compatibility and removed-content behavior.
- Audit retention, privacy, and operational cost.
- Durability/attachments as fragments, properties, or child items.
- Offline-to-online conflict resolution and anti-duplication authority.

## Engineering Recommendations

1. Treat every item ownership change as an idempotent, revision-checked transaction that commits all mutations or none.
2. Separate immutable item definitions, mutable instances, containers, equipment assignments, and presentation proxies.
3. Maintain one authoritative item-location index and assert single ownership continuously in debug/tests.
4. Use server authority for multiplayer pickups, transfers, consumption, crafting, trade, and equipment grants; predict focus/animation freely but ownership conservatively.
5. Make interaction offers data records selected locally but independently validated by authority.
6. Preserve inventory above pawn lifetime and derive equipment/public proxies for the possessed pawn.
7. Replicate stable-ID deltas, never index-based truth; send private inventory only to its authorized audience.
8. Use fixed-capacity queues/scratch, event-driven updates, and zero allocations in ordinary mutations.
9. Build invariant/property/fault-injection tests before UI, trading, crafting, or content scale.
10. Journal compact committed transaction IDs and revisions for persistence recovery, telemetry, and duplication investigations.

## Source Links

1. Epic Games, [Lyra Inventory and Equipment](https://dev.epicgames.com/documentation/en-us/unreal-engine/lyra-inventory-and-equipment-in-unreal-engine)
2. Epic Games, [Understanding the Gameplay Ability System](https://dev.epicgames.com/documentation/en-us/unreal-engine/understanding-the-unreal-engine-gameplay-ability-system)
3. Epic Games, [Using Gameplay Tags](https://dev.epicgames.com/documentation/unreal-engine/using-gameplay-tags-in-unreal-engine)
4. Epic Games, [Fast Array Type Helper](https://dev.epicgames.com/documentation/unreal-engine/API/Runtime/NetCore/TFastArrayTypeHelper)
5. Unity Technologies, [NetworkObject Ownership](https://docs-multiplayer.unity3d.com/netcode/2.2.0/basics/networkobject/)

