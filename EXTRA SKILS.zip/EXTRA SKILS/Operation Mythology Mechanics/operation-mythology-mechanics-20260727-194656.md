# Operation Mythology Mechanics Research

**Timestamp:** 2026-07-27T19:46:56-07:00  
**Subject:** Cinematic evaluator delta: rational time, half-open event ranges, nested transforms, reverse/loop/seek policy, occurrence deduplication, pre-roll suppression, and authoritative milestone safety

## Feature Overview

This is a narrow delta to the existing authoritative cinematic/cutscene session report. That report already defines session identity, readiness barriers, authoritative start ticks, semantic milestones, gameplay leases, branching, skip voting, persistence, replay, multiplayer correction, recovery, and accessibility. The new shared cinematic research adds one missing gameplay-facing interface: how a sequence evaluator maps exact time traversal into reversible samples and discrete events without double-firing or skipping authoritative consequences.

The evaluator must distinguish:

1. **Rational sequence coordinates:** integer ticks plus rate, nested transforms, checked rounding, and an authority epoch.
2. **Evaluation traversal:** previous/current time, direction, half-open boundary policy, loop splits, and jump/scrub/pre-roll flags.
3. **Continuous state:** sampleable transforms, weights, lens/UI/audio positions, and other reversible values.
4. **Discrete occurrences:** stable event IDs with explicit forward/reverse/loop/seek/skip/replay/authority policy.
5. **Authoritative milestones:** semantic gameplay commands committed once by the cinematic session, never once per render frame, temporal sample, or local playhead callback.

This report excludes camera-rig authoring, renderer temporal histories, offline image quality, animation production, lighting, VFX authoring, and audio implementation except where their evaluation modes can accidentally duplicate or suppress gameplay events.

## Existing Coverage and Identified Gap

The mandatory recursive scan succeeded:

- `C:\Users\steve\Desktop\GAME SKILLS`: 35 files, 849,102 bytes.
- `C:\Users\steve\Desktop\EXTRA SKILS\Operation Mythology Mechanics`: 33 files, 947,166 bytes, including 32 reports and the active index.

The shared tree added `2026-07-28_cinematic-sequencing-camera-rigs-streaming-sync.md`. Most of it concerns compiled animation/camera/render/streaming machinery already present in the shared archive or outside the mechanics scope. The mechanics cinematic report already covers multiplayer anchors, streaming readiness, skip, branch, camera/control leases, checkpointing, replay, and recovery.

The genuine uncovered gameplay delta is:

- rational tick/rate time rather than accumulated floating seconds;
- explicit display rate, tick resolution, clock source, and authoritative clock separation;
- half-open evaluation ranges with previous-time inclusion and direction;
- exact nested/subsequence time transforms and checked rounding/overflow;
- stable event occurrence identity and boundary semantics;
- separate policies for play, reverse, loop, scrub, seek, pre/post-roll, skip, replay, and offline temporal sampling;
- state reconstruction at a seek destination rather than replaying every intermediate side effect;
- split evaluation at loop/reverse boundaries;
- authoritative-event execution once at a fixed simulation crossing, even when presentation evaluates multiple times;
- pre-roll/warm-up suppression of gameplay, reward, inventory, quest, save, and external side effects;
- bounded event lookup/dedup state for save, late join, rollback, and reconnect.

## Sourced Facts

These are sourced facts; project recommendations appear later.

1. Epic's `FMovieSceneEvaluationRange` represents evaluation using current and previous frame time, a frame rate, a choice of whether previous time is inclusive, and a preferred play direction. Epic recommends querying the range rather than relying directly on previous time.

2. Epic documents the evaluation range/context as bitwise copyable and free of external state because it may be used on a thread. `FMovieSceneContext` adds status, hierarchical context, and pre/post-roll handling.

3. Unreal Sequencer distinguishes display rate from tick resolution. Epic describes tick resolution as the smallest representable time unit and supports rational rates such as `30000/1001`.

4. Unreal Sequencer exposes multiple clock sources, including engine tick, platform time, audio, relative timecode, timecode, play-every-frame, and custom sources. Thus an authored sequence's presentation clock is not inherently the authoritative gameplay fixed-step clock.

5. Epic's MovieScene API includes evaluation fields/trees optimized for searching applicable time ranges and execution-token accumulation. Engine primitives therefore treat range lookup and deferred application as explicit concepts rather than scanning all keys or mutating immediately.

6. OpenTimelineIO defines `RationalTime` as a value at a rate and `TimeRange` as start plus duration. Its API explicitly distinguishes inclusive and exclusive end times; adjacent clips can meet where one range's exclusive end equals the next range's start.

7. OpenTimelineIO also provides time transforms and range transforms across compositions. Nested timeline time is therefore a mapped coordinate space, not merely the same global floating seconds.

8. Epic notes that a chosen Sequencer display rate defines when certain events occur relative to a shot but does not necessarily throttle the engine tick. Variable engine update and authored frame rate can diverge.

9. None of these sources defines which Operation Mythology events are authoritative, idempotent, reversible, legal on seek/reverse, required on skip, or retained for late join/replay. Those are project policies.

## Industry-Standard API or Pattern

Use a **rational evaluation context plus classified event-occurrence ledger**.

### Time representation

`SequenceTime` contains signed integer ticks and a rational rate. Every sequence definition declares:

- high-resolution tick rate;
- editorial display rate;
- half-open authored range `[start, end)`;
- root clock policy and allowed runtime override;
- checked transform/rounding rules;
- optional source timecode as metadata, not gameplay authority.

The authoritative cinematic session maps its fixed simulation tick and start anchor to root sequence time. Presentation and audio may interpolate or schedule from that root, but only the fixed-step authority advances semantic milestones.

Never accumulate authoritative sequence time by repeatedly adding floating-point frame deltas. Convert from the authoritative tick/epoch using checked integer/rational math. Reject overflow, invalid rates, cyclic nesting, and transforms whose rounding ambiguity would move a semantic boundary.

### Evaluation context

`SequenceEvaluationContext` contains:

- sequence instance ID and generation;
- definition/content revision;
- authority epoch;
- previous and current root time;
- evaluation range with explicit inclusive/exclusive endpoints;
- direction: forward or reverse;
- status: playing, paused, scrubbing, seeking, pre-roll, post-roll, skip reconstruction, replay, rollback, or offline sample;
- loop iteration and branch path;
- fixed authoritative crossing tick when applicable;
- side-effect realm: authoritative, confirmed presentation, predicted presentation, or sample-only.

Normal forward traversal uses a consistent half-open rule such as `(previous, current]` or `[previous, current)`; the project must choose one and compile every boundary to it. Reverse traversal uses the exact dual. A zero-width sample evaluates continuous state but crosses no events unless an event explicitly supports point evaluation.

### Nested sequences

Each subsequence has a rational scale, offset, trim, loop/reverse policy, hierarchy priority, and stable path ID. Compile root-to-local and local-to-root transforms. Split a root evaluation at every discontinuity:

- loop boundary;
- direction reversal;
- trim/start/end boundary;
- branch transition;
- time-warp discontinuity;
- definition/authority epoch change.

Evaluate segments in deterministic root order, then transform each segment into local time. An event occurrence identity includes root session, stable nested path, event ID, loop iteration, branch identity, and authoritative epoch so repeating a loop is distinguishable from retransmitting the same occurrence.

### Track/event classes

Every channel/event is one of:

- `ContinuousReversible`: sample destination state at any time.
- `StatefulReconstructible`: sample from a compiled checkpoint/key state plus bounded forward reconstruction.
- `DiscreteCosmetic`: lossy/idempotent presentation cue with seek/reverse policy.
- `DiscreteInformational`: reliable UI/subtitle/accessibility fact derived from semantic state.
- `AuthoritativeCommand`: validated gameplay command committed only in the authority lane.
- `ExternalIrreversible`: economy/achievement/platform/backend intent routed through the durable transaction/outbox system.

Each discrete event declares stable ID, payload schema, target binding, valid directions, play/scrub/seek/loop/pre-roll/skip/replay/rollback policy, authority realm, idempotency/transaction class, save requirement, and retention window.

### Crossing and occurrence rules

For monotonic playback, locate only events in the traversed range and dispatch in deterministic time/path/event order. Looping splits the range at the loop boundary, increments iteration, and evaluates each segment separately. Reverse playback dispatches only events explicitly designed for reverse; it never guesses an inverse for damage, rewards, inventory, quests, world changes, or external transactions.

An `AuthoritativeCommand` produces a `CinematicMilestoneCommand` containing occurrence ID, expected session revision, fixed crossing tick, definition revision, and idempotency key. The cinematic session validates and commits it once through ordinary domain systems. Local sequence-player callbacks cannot bypass that path.

Predicted/local presentation may start reversible cues early, but confirmation promotes or corrects them through the existing cue-intent lifecycle. It cannot precommit gameplay consequences.

### Seek, scrub, skip, and reconstruction

A seek:

1. evaluates continuous state at the destination;
2. reconstructs declared stateful channels from the nearest compiled semantic checkpoint;
3. repositions seekable audio/media/subtitle state;
4. does not replay all skipped discrete occurrences;
5. dispatches only events explicitly marked for seek and safe in the current realm.

Skip remains the terminal semantic transaction defined in the prior report. It commits required-on-skip milestones once in declared order, chooses a terminal checkpoint, and then asks presentation to sample/reconstruct the destination. Presentation seeking to the end never causes the gameplay commit.

Scrubbing and editor preview are sample-only by default. Pre-roll, simulation warm-up, camera settling, VFX warm-up, offline shutter samples, and render-history warm-up suppress gameplay, external, save, telemetry-credit, achievement, and irreversible audio/UI effects unless a specific non-authoritative track opts in.

### Save, rollback, replay, and late join

Persist:

- sequence/definition revision and instance generation;
- authoritative root tick/time and clock epoch;
- branch path and loop iteration;
- committed semantic milestone frontier/bitset;
- bounded occurrence ledger only for non-frontier optional/looping events;
- stateful checkpoint identity and required reconstruction metadata;
- gameplay leases and terminal transaction IDs as defined previously.

Do not persist evaluator cursors, curve caches, engine pointers, camera solver history, audio/GPU handles, or arbitrary presentation events.

Late join/reconnect receives authoritative root anchor, branch/loop state, milestone frontier, active leases, and current reconstructible presentation state. Replay records semantic occurrence commands/outcomes once, not every local evaluation call.

## Performance Considerations

- **Asymptotic complexity:** with `T` total ranges, `A` active channels, `K` keys per channel, `X` crossed events, and `L` retained occurrences, seek interval lookup is `O(log T)`, monotonic cached traversal is amortized `O(1 + entered/exited ranges)`, active sampling is `O(A)` with cached curve cursors or `O(A log K)` for arbitrary seek, event dispatch is `O(X)`, and occurrence lookup is expected `O(1)` with a bounded hash/bitset or `O(log L)` sorted structure. Never scan every track/event each frame.
- **Allocations and garbage collection:** compiled ranges, transforms, event metadata, and checkpoint tables are immutable. Pool evaluation contexts, segment splits, event batches, occurrence records, and command buffers. The warmed fixed/presentation paths allocate no general-heap objects and create no per-key/event strings, delegates, closures, reflection paths, or managed collections.
- **Cache behavior:** store sequence ranges, event times/IDs, transform data, and active channel descriptors in contiguous immutable arrays. Keep hot instance cursors, next-event indices, loop/branch state, and milestone frontier dense. Keep authoring metadata, localization text, editor curves, and diagnostic descriptions cold.
- **Update frequency:** authoritative milestone crossing runs once per fixed simulation step. Presentation can sample continuous state per rendered view/frame; audio schedules on its own clock. Scrub/offline temporal samples are sample-only and never increase authoritative update count. Drift correction seeks or adjusts presentation without re-crossing authority.
- **Concurrency:** evaluation contexts and compiled plans are immutable/thread-safe values. Parallel jobs evaluate independent domains into local buffers. Binding snapshots remain stable for the phase. Authoritative events merge and commit at one deterministic barrier. No evaluator waits on I/O, streaming, GPU, audio, network, or mutable sequence state.
- **Fixed-step cost:** cap active authoritative sequences, crossed events, loop splits, nested depth, milestone commands, reconstruction work, and occurrence-ledger maintenance per tick. Extremely large jumps use checkpoint reconstruction and required semantic summaries rather than iterating unbounded event distance.
- **Serialization cost:** saving sequence state is `O(branch depth + milestone bitset/word count + bounded optional occurrence records)`. Prefer an ordered milestone frontier when possible. Version exact time/rate/epoch and nested path IDs. Do not serialize continuous curves, evaluator caches, or cosmetic occurrence history.
- **Networking cost:** replicate session anchor, definition hash, branch/loop changes, semantic occurrence/milestone commits, terminal state, and occasional drift correction—not per-frame time or every local cue. Cost is `O(relevant participants)` per semantic change. Late join payload is bounded by frontier/bitset, active state, and retention window; cap correction and occurrence replay rates.

## Pros and Cons

**Pros**

- Exact boundary rules eliminate frame-rate-dependent missing/duplicate milestones.
- Rational time supports non-integer display rates and nested sequences without float accumulation drift.
- Explicit event classes make reverse, seek, scrub, pre-roll, skip, replay, and offline sampling safe.
- Stable occurrence IDs unify idempotency, late join, rollback, replay, and diagnostics.
- State reconstruction avoids replaying thousands of irreversible events on large seeks.
- Authoritative fixed-step crossings remain independent of FP/TP view count and presentation sampling.

**Cons**

- Rational transforms, loop splitting, reverse duals, and boundary rules are subtle and require extensive property tests.
- Authors must classify every event and supply reconstruction/skip/reverse policy.
- Stable nested path and occurrence identity constrain sequence editing/migration.
- Checkpoint/state reconstruction adds cook time, storage, and validation tooling.
- Presentation may temporarily diverge during correction while gameplay truth remains authoritative.

## ECS Architectural Integration

ECS owns authoritative cinematic session identity, root clock anchor, branch/loop state, milestone/occurrence state, and gameplay leases. The timeline evaluator owns immutable plans and ephemeral cursors outside durable ECS data.

Suggested additions to the existing cinematic components:

- `CinematicClockState { start_fixed_tick, root_time_ticks, root_rate, clock_epoch }`
- `CinematicTraversalState { previous_time, current_time, direction, loop_iteration, branch_path, evaluation_status }`
- `CinematicMilestoneFrontier { ordered_frontier, optional_bitset, last_occurrence_id }`
- `CinematicReconstructionState { checkpoint_id, checkpoint_revision, destination_time }`
- local-only `SequencePresentationCursor { plan_handle, interval_cursor, channel_cursors, binding_generation }`

System order:

1. fixed gameplay facts and branch decisions commit;
2. authority builds a rational evaluation context from fixed ticks;
3. range traversal finds crossed authoritative events;
4. milestone commands validate and commit through domain systems;
5. session frontier/occurrence state updates;
6. presentation samples committed root/branch state;
7. cue/audio/UI adapters route only their allowed event classes.

No presentation evaluation directly mutates quests, inventory, abilities, player control, checkpoints, save slots, world facts, economy, achievements, or external services.

## Component, System, Resource, and Event Interfaces

### Value records

- `SequenceTime { ticks, rate_numerator, rate_denominator }`
- `SequenceRange { lower, upper, lower_inclusive, upper_inclusive }`
- `SequenceEvaluationContext { session, generation, revision, range, direction, status, loop, branch, epoch, realm }`
- `SequenceOccurrenceId { session, nested_path, event_id, loop, branch, authority_epoch }`
- `SequenceEventPolicy { class, directions, play, scrub, seek, pre_roll, skip, replay, rollback, authority, retention }`

### Resources

- `CompiledSequencePlanRegistry`
- `SequenceTimePolicy`
- `SequenceEventPolicyRegistry`
- `SequenceCheckpointRegistry`
- `CinematicOccurrenceLedger`
- `CinematicDefinitionMigrationRegistry`
- `SequenceEvaluationBudgets`

### Events/commands

- `SequenceRangeAdvanced`
- `SequenceLoopBoundaryCrossed`
- `SequenceDirectionChanged`
- `SequenceSeekRequested`
- `SequenceStateReconstructed`
- `SequenceOccurrenceCrossed`
- `CinematicMilestoneCommand`
- `CinematicOccurrenceCommitted`
- `CinematicOccurrenceRejected`
- `SequenceEvaluationSuppressed`

Every authoritative command carries stable occurrence identity, fixed tick, expected session revision, definition revision, and idempotency key.

## Integration Plan

1. Choose canonical rational time/rate representation, half-open range convention, reverse dual, transform rounding, and overflow policy.
2. Extend cinematic definitions with stable nested path IDs, classified event policies, reconstruction checkpoints, and loop/branch occurrence identity.
3. Compile authored sequences into immutable interval/event arrays and exact checked root/local transforms.
4. Drive authoritative evaluation only from fixed-step session time and produce milestone commands through the existing transaction system.
5. Implement loop/discontinuity splitting, stable ordering, occurrence deduplication, and bounded frontier/ledger state.
6. Add seek/scrub/pre-roll/offline-sample realms that reconstruct continuous/stateful output while suppressing forbidden side effects.
7. Integrate skip so semantic completion commits first and presentation reconstruction follows.
8. Add save/load, rollback, replay, late-join, reconnect, and definition-migration handling for exact time/branch/loop/frontier state.
9. Add authoring lint for every event's direction/seek/skip/pre-roll/authority/idempotency/persistence policy.
10. Ship boundary visualizers, occurrence traces, deterministic evaluator reference tests, and network/replay fault injection.

## Verification Strategy

- Property-test rational conversion, reduction, negative time, non-integer rates such as `24000/1001` and `30000/1001`, overflow, rounding, nested scale/offset/trim, and root/local round trips.
- Exhaustively test events at lower/upper boundaries for forward/reverse ranges, zero-width samples, dropped frames, large jumps, loop wraps, multiple loops, direction changes, and branch transitions.
- Differentially compare cached monotonic traversal with binary-search arbitrary evaluation at every tick/subframe.
- Fuzz nested sequence graphs, time transforms, overlapping events, hierarchy priorities, missing bindings, and migration aliases.
- For every event class, test play, pause, resume, scrub, seek forward/backward, reverse, loop, pre-roll, post-roll, skip, rollback, replay, late join, reconnect, and offline temporal subsampling.
- Assert gameplay milestones, rewards, quest changes, inventory grants, checkpoint writes, achievements, and external effects occur once despite duplicate callbacks, packet replay, multiple views, temporal samples, or presentation correction.
- Seek between every pair of semantic checkpoints and compare reconstructed state with a reference evaluation that suppresses side effects.
- Inject skip on the same fixed tick as milestone, branch, loop, disconnect, death, travel, and save; deterministic conflict ordering must match policy.
- Save/load and migrate every boundary, loop iteration, branch path, and optional occurrence-ledger shape; unsupported definitions fail without partial mutation.
- Vary render rate, fixed rate, audio drift, worker count, evaluation job order, FP/TP/split-screen view count, packet latency/loss/duplication, and replay speed; authoritative milestone results and hashes remain identical.
- Profile maximum active sequences, nested depth, events crossed by a large jump, ledger size, reconstruction cost, fixed-step time, allocation count, save bytes, and network payload.

## Risks and Open Decisions

- Canonical half-open convention and reverse-range dual.
- Tick-rate limits, rational reduction, integer width, rounding, overflow, and time-warp support.
- Which engine/editor display clocks are legal for runtime presentation and which clock owns authority.
- Stable nested path/event identity across sequence edits and content migration.
- Loop occurrence identity and retention for long/infinite loops.
- Reverse semantics by event class; whether authoritative reverse is supported at all.
- Seek/fire-on-seek policy and maximum reconstruction distance.
- Semantic checkpoint frequency, memory/cook cost, and missing-checkpoint fallback.
- Pre/post-roll and warm-up events that are informational versus completely suppressed.
- Prediction policy for local cues during forward play and correction.
- Milestone frontier versus bitset/ledger representation and retention window.
- Same-tick ordering among milestone, skip, branch, death, disconnect, travel, checkpoint, and reload.
- Late-join/reconnect payload budget and privacy of undiscovered branches/events.
- Definition/version support for old saves and replays.

## Engineering Recommendations

These are engineering recommendations derived from the sourced facts and the existing cinematic architecture:

1. Represent cinematic time as signed integer ticks plus rational rate, derived from an authoritative fixed-step anchor; never accumulate authoritative floating seconds.
2. Standardize one half-open evaluation convention and its reverse dual across compiler, runtime, tests, save, replay, and networking.
3. Compile nested sequence transforms with checked integer/rational math, stable path IDs, explicit rounding, and discontinuity splitting.
4. Classify every channel/event as continuous, reconstructible state, cosmetic, informational, authoritative command, or external irreversible intent.
5. Require explicit forward/reverse/loop/scrub/seek/pre-roll/skip/replay/rollback/authority/idempotency policy for every discrete event.
6. Give every discrete crossing a stable occurrence identity including session, nested path, event, loop, branch, and authority epoch.
7. Commit authoritative milestones only once at the fixed simulation barrier through normal domain commands; never from render/audio/editor/timeline callbacks.
8. On seek, reconstruct destination state and fire only explicitly seek-safe events. Never replay all intermediate side effects.
9. On skip, commit the terminal semantic transaction before presentation seeks/reconstructs.
10. Suppress gameplay and irreversible effects during scrub, pre-roll, warm-up, drift correction, and offline temporal samples by default.
11. Persist compact exact clock/branch/loop/frontier/checkpoint state, not evaluator cursors, curves, presentation caches, or cosmetic history.
12. Use active-range indexes, cached cursors, immutable plans, pooled contexts/buffers, and bounded ledgers so fixed-step work scales with crossed events rather than sequence length.
13. Block release until boundary, loop, reverse, seek, duplicate, large-jump, save/replay, late-join, and multi-sample tests prove exactly-once semantic results.

## Source Links

- Epic Games, [FMovieSceneEvaluationRange API](https://dev.epicgames.com/documentation/unreal-engine/API/Runtime/MovieScene/FMovieSceneEvaluationRange)
- Epic Games, [FMovieSceneContext API](https://dev.epicgames.com/documentation/unreal-engine/API/Runtime/MovieScene/FMovieSceneContext?lang=en-US)
- Epic Games, [MovieScene runtime API and evaluation fields](https://dev.epicgames.com/documentation/en-us/unreal-engine/API/Runtime/MovieScene)
- Epic Games, [Level Sequence settings—display rate, tick resolution, and clock source](https://dev.epicgames.com/documentation/en-us/unreal-engine/level-sequence-settings-in-the-unreal-engine-project-settings)
- Epic Games, [Sequencer Cinematic Toolbar—clock sources](https://dev.epicgames.com/documentation/unreal-engine/sequencer-cinematic-toolbar-in-unreal-engine?lang=en-US)
- Epic Games, [Get Tick Resolution](https://dev.epicgames.com/documentation/unreal-engine/BlueprintAPI/Sequencer/Sequence/GetTickResolution)
- Epic Games, [Setting Your Display Rate—engine tick versus Sequencer FPS](https://dev.epicgames.com/documentation/unreal-engine/setting-your-display-rate)
- Academy Software Foundation, [OpenTimelineIO architecture—RationalTime and TimeRange](https://opentimelineio.readthedocs.io/en/v0.12/tutorials/architecture.html)
- Academy Software Foundation, [OpenTimelineIO time ranges and exclusive ends](https://opentimelineio.readthedocs.io/en/v0.18.1/tutorials/time-ranges.html)
- Academy Software Foundation, [OpenTimelineIO serialized time schema](https://opentimelineio.readthedocs.io/en/v0.15/tutorials/otio-serialized-schema.html)
