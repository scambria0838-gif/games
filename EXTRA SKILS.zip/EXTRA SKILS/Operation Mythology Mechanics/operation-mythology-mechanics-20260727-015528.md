# Operation Mythology Mechanics Research

**Batch timestamp:** 2026-07-27T01:55:28-07:00  
**Subject:** Gameplay tags, abilities, attributes, damage, cooldowns, timers, status effects, stacking, and prediction  
**Scope:** Generic data-oriented ECS; offline and authoritative multiplayer; no production code

## Feature Overview

This feature is the rule-execution layer for attacks, spells, tools, traversal powers, item-granted actions, passive traits, damage/healing, resource costs, cooldowns, buffs, debuffs, immunities, and state-dependent interactions.

The runtime separates:

- **tags:** hierarchical categorical facts and event identifiers;
- **attributes:** numeric authoritative state such as health, stamina, armor, speed, or resistance;
- **ability definitions/grants:** what an owner can attempt;
- **ability executions:** active, tick-addressed instances with targets, costs, phases, and cancellation;
- **effect definitions/specs/instances:** immutable behavior, captured application data, and persistent target state;
- **cues:** presentation-only projections of confirmed or predicted gameplay events.

The core flow is:

`activation request -> tag/attribute/cooldown/authority checks -> reserve/commit cost -> execute tasks -> produce effect specs -> validate target -> apply instant/persistent effects -> aggregate attributes/tags -> emit gameplay events and presentation cues`

## Existing Coverage and Identified Gap

The fresh scan found nine `GAME SKILLS` files; a new global-illumination report was added, but no gameplay ability material exists. The dedicated mechanics folder contains traversal and transactional inventory reports. Inventory establishes equipment-granted capabilities but does not define ability lifecycle, effect stacking, damage resolution, or timers.

The uncovered gap is a deterministic and network-aware ability/effect kernel with explicit stacking, clock, prediction, cancellation, and event semantics. Without it, tags become ungoverned strings, timers proliferate per entity, damage order becomes unstable, and equipment integrations acquire feature-specific code.

## Sourced Facts

- Epic’s Gameplay Ability System models abilities, attributes, gameplay effects, tags, and cues. Abilities have activation/in-progress/completion state and may coordinate animation, movement, collision, resources, blocking/cancellation, cooldowns, and UI. [Epic: Gameplay Ability System Overview](https://dev.epicgames.com/documentation/en-us/unreal-engine/understanding-the-unreal-engine-gameplay-ability-system)
- Epic documents Gameplay Effects as instant or persistent changes; persistent effects can expire and undo modifiers. Some non-instant predicted effects can roll back when server activation is rejected, while instantaneous changes such as damage are notably harder to roll back. [Epic: Gameplay Ability System Overview](https://dev.epicgames.com/documentation/en-us/unreal-engine/understanding-the-unreal-engine-gameplay-ability-system)
- Gameplay Tags are centrally registered hierarchical labels usable for properties, capabilities, events, and triggers. Ability tags can require, block, cancel, or grant state. [Epic: Gameplay Tags](https://dev.epicgames.com/documentation/unreal-engine/using-gameplay-tags-in-unreal-engine) and [Epic: Using Gameplay Abilities](https://dev.epicgames.com/documentation/unreal-engine/using-gameplay-abilities-in-unreal-engine)
- Epic distinguishes immutable Gameplay Effect assets from runtime Gameplay Effect Specs that carry instanced application data. [Epic: Gameplay Effects](https://dev.epicgames.com/documentation/unreal-engine/gameplay-effects-for-the-gameplay-ability-system-in-unreal-engine)
- Epic attributes maintain base and current values and support calculations and replication, but documented metadata min/max values do not automatically clamp attributes. [Epic: Gameplay Attributes](https://dev.epicgames.com/documentation/en-us/unreal-engine/gameplay-attributes-and-attribute-sets-for-the-gameplay-ability-system-in-unreal-engine)
- Unity Netcode’s client anticipation explicitly separates visual anticipated values from authoritative values and corrects stale anticipation; it is not a full rollback/replay system. [Unity: Client Anticipation](https://docs-multiplayer.unity3d.com/netcode/2.1.1/advanced-topics/client-anticipation/)

## Industry-Standard API or Pattern

### Stable tag dictionary and queries

Compile authored hierarchical tags to stable numeric IDs. Runtime containers use sorted small vectors, bitsets for selected hot domains, and count maps only where stacked grants require them. A tag query is an immutable compiled expression over `All`, `Any`, and `None` groups.

Tags describe categorical state; they are not numeric attributes and should not encode arbitrary values in names. Separate owned state tags, ability classification tags, target tags, event tags, and presentation cue tags by namespace and governance.

### Ability definition, grant, and execution

`AbilityDefinition` is immutable: ID, tags, activation query, blocked/cancel tags, cost/cooldown specs, targeting policy, execution graph/task IDs, prediction policy, and presentation keys.

`AbilityGrant` binds a definition to an owner with level/source, input/action mapping, charges, and grant revision.

`AbilityExecution` is a bounded runtime record: execution/prediction ID, owner/source/instigator, start tick, phase, target data, reserved/committed costs, active tasks, cancellation reason, and emitted-event sequence.

Lifecycle:

`Requested -> Validating -> Active -> Committing/Executing -> Completed`

with `Rejected`, `Canceled`, and `Interrupted` exits. Cleanup is mandatory and idempotent.

### Effect definition, spec, and active instance

`EffectDefinition` is immutable. An `EffectSpec` captures source, instigator, target, level, magnitude parameters, source/target tag snapshots as required, duration/period, and prediction ID. An `ActiveEffect` stores target-side remaining deadline/ticks, stack count, source grouping, granted tags, modifiers, periodic schedule, and removal policy.

Stacking is data, never implicit:

- independent instances;
- aggregate by source;
- aggregate by target;
- maximum stacks;
- refresh duration;
- add duration;
- replace weaker/stronger;
- reject new;
- overflow trigger;
- periodic timer reset/retain;
- removal removes one stack or all.

### Attribute aggregation and damage pipeline

Attributes have base/current or base plus deterministic modifier channels. A recommended order is:

`base -> additive -> multiplicative additive -> multiplicative compound if explicitly required -> override/clamp`

Define rounding, saturation, NaN/overflow handling, and order. Cache derived values and dirty only dependent attributes.

Damage is a typed transaction:

`source snapshot -> target validation -> hit/damage tags -> immunity -> additive bonuses -> resistance/armor -> block/shield -> health change -> death/outcome event`

Every stage emits optional trace data. Health mutation and resulting death event commit once at an authoritative tick.

### Timers and cooldowns

Timers declare clock domain: fixed simulation tick, server session time, monotonic real time, or turn count. Gameplay durations/cooldowns normally use fixed ticks or synchronized authoritative deadlines. UI derives remaining display time; it does not decrement authority.

Use a central timer heap/wheel and effect expiration/period queues, not one ticking object per effect.

## Performance Considerations

### Asymptotic complexity

Let `g` be granted abilities, `e` active effects, `m` modifiers touching an attribute, `t` tags in a query container, and `x` expirations this tick.

- Ability lookup by stable ID/input is `O(1)` average; activation query is `O(t)` or fixed bit operations for hot tags.
- Effect insertion/removal is `O(log e)` with indexed expiry plus `O(m)` dirty aggregation.
- Recomputing one attribute is `O(m)`; dependency propagation is `O(V+E_d)` over affected attribute graph nodes/edges.
- Timer processing is `O(x log e)` with a heap or near `O(x)` with a timing wheel.
- Never scan every ability/effect every tick.

### Allocations and garbage collection

Use fixed/paged pools for executions, effect instances, tasks, timer nodes, specs, events, and prediction records. Warm activation/application/expiration must allocate zero general-heap objects. Effects with rare variable payloads use size-class slabs.

### Cache behavior

Keep hot effect fields in dense arrays by owner: definition ID, deadline, stack count, source ID, granted-tag delta, modifier range. Store graphs, names, descriptions, cue assets, and debug captures cold. Maintain per-attribute modifier spans and per-tag reference counts.

### Update frequency

Abilities/effects are event- and deadline-driven. Periodic effects enqueue exact ticks. Attribute aggregation runs on dirtiness. UI samples immutable cooldown/effect snapshots at presentation cadence.

### Concurrency

Activation validation and effect calculation may run in jobs against snapshots. Authoritative mutation commits at ordered ECS barriers. Cross-entity effects become command-buffer records sorted by target, source, execution sequence, and local emission index. Presentation cues run after gameplay commit.

### Fixed-step cost

Cap activations, emitted effects, task transitions, periodic firings, and chain depth per tick. Detect effect/event cycles. Catch-up ticks preserve periodic semantics but must obey a policy: execute each missed period, aggregate missed magnitude, or cap and record degradation.

### Serialization cost

Persist grants, charges, base attributes, active effect definition/source, stacks, remaining tick/deadline, captured parameters, and schema versions. Do not serialize derived modifiers, cue state, pointers, or task objects unless an execution is explicitly saveable.

Cost is `O(grants + active effects + persistent executions)`. Rebuild tag counts and derived attributes deterministically on load.

### Networking cost

Replicate grants/effects/attributes only to authorized audiences using stable-ID deltas. Ability requests carry input/ability ID, tick, prediction ID, and compact target data. Results acknowledge/reject prediction IDs and send authoritative corrections.

Public observers usually need cues and visible status, not private cooldown/resource details. Network cost is `O(changes)`, not `O(frame rate)`.

## Pros and Cons

### Pros

- Shared lifecycle eliminates feature-specific cooldown/status code.
- Explicit stacking and clocks make balance behavior testable.
- Tags decouple equipment, movement, combat, quests, and UI.
- Data definitions plus compact instances scale content.
- Prediction IDs support responsive local presentation and correction.
- Dirty aggregation avoids per-frame scans.

### Cons

- A generic kernel has significant tooling and validation cost.
- Tag hierarchies can become uncontrolled global dependencies.
- Complex modifier ordering is hard to explain to designers.
- Predicted instant damage remains risky.
- Saving active executions/tasks increases schema burden.
- Effect chains can create runaway work without budgets.

## ECS Architectural Integration

System order:

1. `AbilityRequestIngestSystem`
2. `AbilityActivationValidationSystem`
3. `AbilityCostCooldownCommitSystem`
4. `AbilityTaskStepSystem`
5. `EffectApplicationSystem`
6. `EffectStackResolutionSystem`
7. `AttributeAggregationSystem`
8. `PeriodicEffectSystem`
9. `DamageResolutionSystem`
10. `EffectExpirationSystem`
11. `AbilityCancellationSystem`
12. `GameplayEventMergeSystem`
13. `CueProjectionSystem`
14. `AbilityReplicationTelemetrySystem`

Use dense external pools/resources with handles in ECS components when active-effect sets vary widely. Structural changes and cross-entity applications use deterministic command buffers.

## Component, System, Resource, and Event Interfaces

Components:

- `AbilityOwner { grantSetHandle, executionSetHandle, predictionState }`
- `TagState { hotBits, sparseTagHandle, revision }`
- `AttributeState { baseBlock, currentBlock, dirtyBits, revision }`
- `ActiveEffectSet { effectRangeHandle, revision }`
- `CooldownState { cooldownGroupHandle }`
- `Damageable { damageProfileId, outcomeSequence }`

Resources:

- `TagDictionary` and compiled `TagQueryDatabase`
- `AbilityDefinitionDatabase`
- `EffectDefinitionDatabase`
- `AttributeSchema/DependencyGraph`
- pooled `AbilityExecutionStore`, `ActiveEffectStore`, and `EffectSpecArena`
- `GameplayTimerService`
- `PredictionLedger`
- `GameplayEventBuffer`
- `AbilityBudgets/Diagnostics`

Events:

- `AbilityRequested/Accepted/Rejected/Started/Committed/Completed/Canceled`
- `EffectApplied/StackChanged/Removed/Expired`
- `AttributeChanged`
- `DamageResolved`
- `DeathRequested`
- `GameplayTagChanged`
- `CooldownStarted/Ended`
- `GameplayCueRequested`

All deterministic events carry tick and stable execution/prediction/event IDs.

## Integration Plan

1. Govern namespaces and compile stable tag IDs/queries.
2. Define attribute schemas, modifier order, clamps, and dependency validation.
3. Build instant and duration effect application with explicit stacking.
4. Add deadline-driven timers/periodic effects and cooldown groups.
5. Add ability grants, activation validation, cost/cooldown commit, cancellation, and bounded tasks.
6. Add deterministic damage/healing and outcome events.
7. Integrate equipment grants, movement/traversal blockers, interaction requirements, and presentation cues.
8. Add server authority, prediction ledger, correction, delta replication, save migration, and tooling.

## Verification Strategy

- Golden-test every modifier and stacking policy, equal-deadline ordering, refresh/add duration, overflow, immunity, dispel, and source removal.
- Property-test apply/remove returns attributes/tags to the correct state.
- Fuzz cycles, NaN/infinity, extreme magnitude, zero/negative duration, duplicate prediction IDs, and hostile target payloads.
- Replay command/effect streams and compare per-tick hashes.
- Test latency/rejection for predicted costs, cooldowns, movement abilities, cues, and non-predicted damage.
- Assert exactly-once cost, damage, death, cue, and cleanup across rollback/cancellation.
- Measure active effects, dirty recomputes, timer operations, chain depth, pool high-water marks, allocations, fixed-tick cost, and network bytes.

## Risks and Open Decisions

- Required tag hierarchy/governance and hot-bit allocation.
- Fixed-point versus floating attribute math and determinism tier.
- Snapshot versus live source/target attributes for periodic effects.
- Modifier order and rounding.
- Cooldown timing from request, commit, impact, or completion.
- Predicted cost/cooldown policy and whether instant damage is ever predicted.
- Stack grouping and dispel semantics.
- Catch-up behavior for missed periodic ticks.
- Ability-task graph complexity and saveability.
- Persistence owner across pawn death/respawn.
- Public/private replication audience.
- Designer scripting sandbox and instruction budgets.

## Engineering Recommendations

1. Build a small data-oriented ability kernel around stable tags, attributes, grants, executions, effect specs/instances, timers, and cues.
2. Compile/govern tag dictionaries; do not use runtime strings or tags as numeric storage.
3. Make stacking, duration refresh, periodic scheduling, dispel, immunity, modifier order, and clocks explicit definition data.
4. Use deadline/event-driven effects and central timer structures; never tick every effect.
5. Commit costs/cooldowns/damage exactly once with execution/prediction IDs and deterministic event ordering.
6. Predict reversible owner-facing state and presentation; keep authoritative instant damage conservative.
7. Separate gameplay events from cues and deduplicate cues across rollback.
8. Use dense pools, fixed budgets, zero warm allocations, and cycle/chain guards.
9. Add golden/property/fuzz/replay tests before large-scale ability authoring.
10. Treat equipment, traversal, interaction, quests, and AI as clients of the same tag/ability/effect contracts.

## Source Links

1. Epic Games, [Gameplay Ability System Overview](https://dev.epicgames.com/documentation/en-us/unreal-engine/understanding-the-unreal-engine-gameplay-ability-system)
2. Epic Games, [Using Gameplay Tags](https://dev.epicgames.com/documentation/unreal-engine/using-gameplay-tags-in-unreal-engine)
3. Epic Games, [Using Gameplay Abilities](https://dev.epicgames.com/documentation/unreal-engine/using-gameplay-abilities-in-unreal-engine)
4. Epic Games, [Gameplay Effects](https://dev.epicgames.com/documentation/unreal-engine/gameplay-effects-for-the-gameplay-ability-system-in-unreal-engine)
5. Epic Games, [Gameplay Attributes and Attribute Sets](https://dev.epicgames.com/documentation/en-us/unreal-engine/gameplay-attributes-and-attribute-sets-for-the-gameplay-ability-system-in-unreal-engine)
6. Unity Technologies, [Client Anticipation](https://docs-multiplayer.unity3d.com/netcode/2.1.1/advanced-topics/client-anticipation/)

