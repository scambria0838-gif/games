# Operation Mythology Mechanics Delta Research — Governed Gameplay Scripting Runtime

**Timestamp:** 2026-07-27T03:09:20-07:00  
**Scope:** Designer-authored logic for abilities, interactions, quests, objectives, status effects, encounters, and game flow; declarative graphs; sandboxed script escape hatch; capability-based host API; deterministic execution; fuel, memory, and host-call budgets; ECS integration; prediction/rollback; persistence; hot reload; faults; security; performance; and validation.

## Feature Overview

Operation Mythology needs designer-extensible gameplay without turning arbitrary scripts into invisible authorities over ECS state, networking, files, clocks, saves, rewards, or platform services.

Use two tiers:

1. **Declarative definitions and graphs** for common mechanics: conditions, selectors, sequences, timers, tag queries, attribute modifiers, costs, cooldowns, objective counters, transitions, and typed command emission.
2. **Governed custom evaluators/scripts** only when the declarative vocabulary is insufficient. Scripts run inside a restricted runtime with typed imports, deterministic inputs, bounded fuel/memory/host calls, explicit state, staged mutation, and versioned artifacts.

Authoritative execution follows:

`typed event/command -> select pinned script revision -> construct immutable context -> run with deterministic budget -> collect typed proposals -> validate proposals -> atomic gameplay commit -> publish semantic result`

The script never receives raw ECS pointers or a general world object. It cannot directly mutate components, send network messages, write saves, grant rewards, read wall time, access operating-system resources, or perform external transactions. It proposes operations through capabilities; authoritative systems validate and commit them.

## Existing Coverage and Identified Gap

The mandatory recursive scan found 17 files in `C:\Users\steve\Desktop\GAME SKILLS` and 19 files in the mechanics archive. No access error or unexpected modification occurred.

Existing reports already recommend:

- declarative quest graphs and compiled event subscriptions;
- data-defined abilities, effects, costs, cooldowns, tags, and status state;
- typed semantic events and deterministic phase ordering;
- owned random streams, deterministic simulation, rollback, replay, and hashes;
- gameplay manifests, versioned definitions, hotfix staging, and migration;
- authoritative transactions, idempotency, compensation, debugging, tests, and budgets.

They leave “designer scripting sandbox,” “evaluator scripting,” “content scripting restrictions,” and “instruction budgets” open. Missing architecture includes:

- which mechanics stay declarative and when custom code is permitted;
- the host-call/capability surface and authority checks;
- deterministic time, randomness, iteration, numeric, and async rules;
- CPU/fuel, memory, stack, host-call, query, event, and mutation budgets;
- script-owned state representation, serialization, rollback, and migration;
- parallel scheduling and conflict declaration;
- error, timeout, quarantine, retry, and fallback behavior;
- hot reload and active-instance revision pinning;
- trusted first-party versus mod/untrusted execution policy;
- static analysis, test harnesses, tracing, profiling, and content certification.

This report defines that shared boundary without selecting a production language or writing an interpreter.

## Sourced Facts

The following are sourced facts:

- The WebAssembly security documentation says modules execute in a sandbox separated from the host and can reach host functionality only through appropriate APIs. The embedding's security policy remains responsible for what is exposed.
- The WebAssembly specification states that the embedder controls functional capabilities through imports. Core WebAssembly provides a sandboxed computation model, while files, network, clocks, and randomness belong to host/system interfaces.
- WASI capability documentation describes imported instances/functions as capabilities that can be granted or attenuated. This demonstrates a useful least-authority pattern; it does not make every WASI embedding safe by default.
- Wasmtime documents deterministic fuel: with the same program and fuel, interruption occurs at the same program location absent other nondeterminism. It also documents lower-overhead epoch interruption as wall-time based and therefore nondeterministic.
- Wasmtime's resource-limiter documentation separately limits guest memories, tables, and instances, while noting CPU needs fuel/epoch mechanisms and that not all embedder allocations are covered. CPU and memory are therefore distinct budget dimensions.
- Lua's official manual exposes a custom allocator, garbage-collection modes, coroutines, error handling, debug hooks, and optional standard libraries including I/O, OS, package loading, and debug facilities.
- Lua's debug hook API can trigger after a configured instruction count. The existence of OS/I/O/package/debug libraries also shows that an embedder must deliberately decide which libraries are available; using a language runtime does not automatically produce a least-authority gameplay sandbox.
- Velan Studios' GDC 2022 session describes a production entity system and scripting language designed together for parallel, deterministic, rewindable computation, supporting prediction and world-state scrubbing.
- Epic's Gameplay Ability System describes abilities as actions with tags, costs, cooldowns, effects, and server-authoritative/predicted execution policies. This is evidence that many extensible mechanics benefit from constrained domain APIs rather than unrestricted world mutation.

**Bounded engineering inference:** memory isolation protects the host process, but gameplay integrity depends primarily on the imports/host calls and the validation of resulting mutations. A memory-safe script that can call `GrantItem` or enumerate hidden entities without authorization is still unsafe.

**Bounded engineering inference:** wall-clock timeouts are useful as an outer operational kill switch but cannot be the sole authoritative budget when prediction/replay must stop at the same logical point. Deterministic instruction/fuel or equivalent work accounting is required.

## Industry-Standard API or Pattern

### Declarative-first content model

Provide reviewed nodes/operators for:

- tag/attribute/state queries;
- boolean, comparison, fixed-point arithmetic, and bounded aggregation;
- sequence, selector, all/any, branch, gate, repeat-with-static-bound;
- timers/deadlines in named clock domains;
- random draw through the governed addressable RNG service;
- typed target selection through bounded query handles;
- emit command/proposal;
- wait for typed event/result using durable subscription identity;
- success, failure, cancel, and compensation transitions.

Graphs compile to immutable validated bytecode/data and subscription tables. Offline tools can calculate dependencies, required capabilities, possible mutations, event types, save state, worst-case node/fuel bounds, and compatibility.

### Script manifest

Every custom module declares:

`ScriptManifest { script_id, revision_digest, runtime_abi, deterministic_tier, capabilities, read_sets, write_proposal_sets, event_inputs, result_types, fuel_class, memory_limit, host_call_limits, state_schema, migration_id, prediction_policy, trust_class }`

Missing declarations fail closed. The manifest is signed/pinned through the gameplay-definition manifest.

### Capability-based host surface

Expose narrow typed operations, not ambient services:

- `ReadSelfSnapshot(fields)`
- `ReadTargetSnapshot(target, fields)` after authorization/relevance checks
- `QueryTargets(query_descriptor, max_results)`
- `GetTickTime(clock_domain)`
- `Random(draw_slot, distribution)`
- `ProposeApplyEffect(target, definition, parameters)`
- `ProposeSpendCost(owner, cost)`
- `ProposeEmitCommand(command_type, bounded_payload)`
- `AwaitEvent(subscription_descriptor)`

Do not expose:

- raw component storage or entity iterators;
- arbitrary reflection/type lookup;
- filesystem, process, environment, network sockets, HTTP, or native library loading;
- wall clock, thread creation, sleep, or unrestricted async tasks;
- unrestricted logs/telemetry;
- direct save, reward, economy, achievement, moderation, or platform APIs;
- client identity/secret/anti-cheat data;
- mutable global RNG.

Each host call charges fuel plus a domain cost, validates capability, bounds data, and returns a typed result rather than throwing uncontrolled host exceptions.

### Deterministic authoritative profile

Authoritative/predicted scripts use:

- fixed or project-specified numeric semantics;
- authoritative fixed tick and named clocks only;
- addressable governed randomness;
- stable-ID-sorted query results;
- explicit bounded collections;
- no dependence on hash iteration, pointer order, job completion, locale, environment, filesystem, network, or wall time;
- deterministic fuel accounting;
- explicit yield only at legal state-machine boundaries;
- immutable inputs and staged outputs;
- pinned runtime/ABI/script/definition versions.

Presentation scripts may use broader nondeterministic APIs only in a separate capability namespace and may not feed authoritative state.

### Execution transaction

Scripts produce a bounded `ScriptProposalBatch`:

`{ invocation_id, script_revision, read_revisions, proposals[], emitted_events[], continuation_state?, fuel_used, host_cost_used }`

The owning system:

1. validates read revisions, authority, targets, costs, cooldowns, and invariants;
2. canonicalizes proposal order;
3. commits all accepted mutations atomically or returns a typed rejection;
4. records continuation state only after successful commit.

A script trap, timeout, invalid proposal, or stale read produces no partial mutation.

### Budget hierarchy

Limit independently:

- decoded module/bytecode size;
- compile/validation time and cache size;
- instances and linear/heap memory;
- stack/call depth and recursion;
- deterministic fuel/instructions per invocation and per tick;
- host-call count and weighted host-call cost;
- query count, radius, history depth, and result count;
- proposed mutations/events/continuations;
- allocated persistent state size;
- log/trace volume;
- concurrent and queued invocations by script, owner, match, and server.

Fuel is necessary but insufficient: one cheap guest instruction could invoke an expensive host spatial query unless host calls have separate calibrated charges and caps.

## Performance Considerations

### Asymptotic complexity

- Script dispatch by stable ID is expected `O(1)`.
- Declarative graph evaluation is `O(V_e + E_e)` over visited nodes/edges, bounded by validated graph size and repeat limits.
- VM execution is `O(F)` for consumed fuel/instructions.
- Host queries dominate domain cost: target query may be `O(log N + K)` with spatial indexing, for `N` objects and bounded `K` results.
- Proposal validation/commit is `O(P log P)` if `P` proposals require stable sorting; fixed small `P` makes this bounded.
- Subscription dispatch should be indexed `O(1 + M)` for `M` matching consumers, not scan all scripts.
- State serialization is `O(S)` in bounded script state bytes.

### Allocations and garbage collection

- Compile/load outside simulation; cache immutable validated artifacts by revision digest.
- Use pooled/preallocated instances, linear memories, stacks, invocation contexts, proposal arrays, and continuation buffers.
- The fixed-tick path should allocate zero general heap memory. A GC runtime must use bounded heaps and deliberate collection scheduling or arena reset where possible.
- Deny unbounded strings, tables/maps, closures, reflection objects, and dynamically shaped host results in authoritative hot paths.
- Charge guest and embedder-side allocations; a guest-memory limiter alone does not bound host allocations caused by calls.

### Cache behavior

- Keep hot bytecode, constants, capability bitsets, and typed host-call tables compact and immutable.
- Store large source maps, editor metadata, source text, localized debug messages, and migration descriptions cold.
- Batch invocations by artifact/revision when dependency ordering permits to improve instruction/data locality.
- Script state should be compact schema-defined value blobs or ECS components, not pointer-rich VM object graphs.
- Pooling too many large per-instance heaps harms cache and memory; prefer stateless/pure invocations plus compact continuations.

### Update frequency

- Invoke on typed events, commands, scheduled timer deadlines, or explicit state-machine resumptions—not by polling every script every frame.
- Fixed-tick authoritative logic runs only in its registered phase.
- Presentation-only scripts run at presentation cadence under separate budgets.
- Incremental compilation, validation, and migration run off the gameplay thread and publish only at legal boundaries.
- Aggregate profiling/telemetry periodically; do not synchronously export every instruction or host call.

### Concurrency

- Parallel invocations read immutable published snapshots and write disjoint proposal buffers.
- Manifest read/write sets support scheduling and conflict detection, but runtime validation remains necessary.
- No script receives mutable ECS references across a yield.
- Deterministic merge sorts by phase, owner/event/invocation ID, and proposal sequence—not worker completion.
- VM instances are thread-confined or safely pooled; “thread-safe runtime” does not justify sharing mutable script state.
- Native host calls must not reenter the VM or block on I/O in authoritative phases unless explicitly designed and proven.

### Fixed-step cost

- Allocate per-system, per-script-class, per-owner, and global fuel/host-cost budgets.
- Reserve core simulation capacity; low-priority content is deferred, degraded, or failed by policy rather than overrunning the tick.
- Deterministic fuel produces replayable interruption points; a wall-time watchdog remains an outer safety net for runtime/compiler/host bugs.
- Continuations resume with a fresh bounded budget at defined ticks; scripts cannot yield in the middle of a committed transaction.
- Record budget use and top offenders; certify worst-case representative content, not only averages.

### Serialization cost

- Persist schema-defined state only: node/continuation ID, locals from an allowlisted value schema, stable entity references, deadlines, event subscription tokens, script revision, and state version.
- Never serialize VM stacks, native pointers, closures, coroutine internals, allocator layouts, or JIT state as the durable format.
- Replays record authoritative inputs/outcomes plus pinned artifact/runtime versions as required.
- Compression occurs outside fixed simulation; state sizes are hard-capped before allocation/decompression.
- Hot reload requires explicit migration from old state schema to new or keeps active instances pinned.

### Networking cost

- Clients do not receive source, bytecode, state, or hidden data unless needed for an approved predicted script.
- Replicate semantic commands/outcomes and compact continuation state only when the client must predict/reconstruct it.
- Server validates all script-produced proposals even if identical code ran on the client.
- Script events/results use bounded versioned schemas and interest filtering.
- Mod/untrusted modules cannot introduce arbitrary RPC schemas or network calls.
- Revision digests participate in compatibility handshake; incompatible predicted artifacts are rejected before play.

## Pros and Cons

### Declarative graphs

Pros:

- analyzable dependencies and capabilities;
- predictable serialization and migration;
- strong editor validation;
- compact runtime and deterministic execution;
- easier performance estimates and accessibility/content tooling.

Cons:

- vocabulary can become large or awkward;
- bespoke mechanics may require engine work;
- over-general graphs can recreate a poor programming language;
- designers may work around missing constructs with excessive graph complexity.

### Embedded scripting language/VM

Pros:

- expressive and productive for complex logic;
- reusable functions and better abstraction;
- faster iteration for exceptional mechanics;
- strong debugging possible with source maps and tooling.

Cons:

- hidden dependencies and mutations;
- CPU, allocation, GC, security, and determinism risks;
- harder save migration and static analysis;
- runtime/ABI/version support burden;
- designer code can create systemic interactions difficult to validate.

### WebAssembly-like sandbox

Pros:

- validated portable module format;
- isolated linear memory and typed imports;
- capability-oriented host boundary;
- mature runtime ideas for fuel/interruption and memory limits;
- language choice can be decoupled from runtime ABI.

Cons:

- not automatically deterministic across all source languages/host calls;
- sandbox does not validate gameplay authority;
- JIT/AOT availability differs by platform;
- runtime updates and security patches are operational dependencies;
- debug iteration and state serialization require custom tooling;
- host-call overhead and data marshaling can dominate.

## ECS Architectural Integration

ECS remains authoritative. Scripts are deterministic evaluators that consume snapshots and emit typed proposals.

Script identity/revision and compact continuation state may be ECS components. Runtime artifacts, compiled code, VM instances, heaps, source maps, and caches are service-owned resources keyed by handles.

Invocation scheduling derives from semantic event subscriptions, timers, ability/quest/effect state, and game-flow transitions. Systems gather immutable contexts at a phase boundary. Worker jobs execute scripts and fill fixed-capacity result buffers. A deterministic commit system validates and applies proposals through the same domain commands used by native gameplay.

The capability model mirrors ECS/domain ownership:

- an ability evaluator can read its owner/source/targets and propose ability/effect operations;
- a quest evaluator can read committed quest-scoped facts and propose objective progress;
- an interaction evaluator can read an authorized offer/target and propose an interaction transaction;
- none can enumerate or mutate unrelated domains.

Rollback snapshots capture schema-defined continuation state and relevant inputs, not runtime internals. Replay and resimulation suppress external side effects. Script state/outcomes participate in canonical hashing according to determinism tier.

## Component, System, Resource, and Event Interfaces

### Components

- `ScriptBinding { script_id, pinned_revision, entrypoint, capability_profile }`
- `ScriptContinuation { state_schema, state_revision, continuation_id, bounded_state_handle }`
- `ScriptInvocationStatus { invocation_id, phase, status, retry_class, last_result }`
- `ScriptFaultState { fault_code, occurrence_count, quarantine_generation }`
- `ScriptOwnedTimerSet { named_clock_deadlines }`

### Resources

- `ScriptArtifactRegistry`
- `ScriptRuntimeAbiRegistry`
- `ScriptCapabilityPolicy`
- `ScriptBudgetTable`
- `ScriptInstancePool`
- `ScriptStateStore`
- `ScriptSubscriptionIndex`
- `ScriptMigrationRegistry`
- `GameplayManifestRevision`
- `ScriptTraceRing`
- `ScriptQuarantinePolicy`

### Systems

- `ScriptEventDispatchSystem`
- `ScriptContextBuildSystem`
- `ScriptInvocationScheduleSystem`
- `ScriptExecutionSystem`
- `ScriptProposalValidationSystem`
- `ScriptDeterministicCommitSystem`
- `ScriptContinuationPublishSystem`
- `ScriptFaultPolicySystem`
- `ScriptMigrationSystem`
- `ScriptBudgetTelemetrySystem`

### Events

- `ScriptInvocationRequested`
- `ScriptInvocationCompleted`
- `ScriptProposalRejected`
- `ScriptBudgetExceeded`
- `ScriptTrapped`
- `ScriptQuarantined`
- `ScriptContinuationCreated`
- `ScriptRevisionActivated`
- `ScriptMigrationFailed`
- `ScriptCapabilityViolation`

All are bounded typed records. Error strings/source excerpts stay in protected diagnostics, not simulation events or network payloads.

## Integration Plan

1. Inventory current/planned custom behavior in abilities, effects, interactions, quests, objectives, encounters, AI, and flow; classify what declarative nodes can express.
2. Expand a small declarative vocabulary and compile it into immutable typed artifacts with static dependency/capability/budget analysis.
3. Define script manifest, ABI, type system, numeric policy, deterministic subset, stable IDs, and artifact signing/versioning.
4. Design capability imports per gameplay domain and forbid ambient ECS/world/platform access.
5. Implement immutable context snapshots and fixed-capacity proposal batches; route proposals through existing authoritative commands/transactions.
6. Add deterministic fuel plus separate memory, stack, host-call, query, mutation, event, state, and trace limits.
7. Implement event-indexed scheduling, instance pooling, deterministic merge, fault isolation, and replay-safe side-effect suppression.
8. Define schema-owned continuation state and migration; prohibit durable VM stack/object serialization.
9. Add prediction policy and compatibility handshake for the small subset of scripts that clients need.
10. Build editor compile/validate/test/profile tooling, source mapping, capability visualization, and worst-case budget reports.
11. Roll out to one representative ability, objective evaluator, interaction, periodic effect, and multi-step encounter.
12. Operate first in trusted first-party mode. Treat mods/untrusted code as a separate threat model and enable only after sandbox, signing, capability, platform, and support decisions.

## Verification Strategy

- **Static validation:** reject unknown imports, undeclared reads/proposals, recursion/unbounded loops, unsupported opcodes/features, oversized module/state, nondeterministic APIs, invalid schemas, and incompatible revisions.
- **Capability tests:** every import is tested for allowed and denied script/domain/target combinations. Missing capability denies by default.
- **Sandbox tests:** attempt file, network, environment, clock, process, native-load, arbitrary-memory, hidden-entity, raw-ECS, and external-service access.
- **Budget tests:** infinite loops, deep recursion, memory growth, allocation churn, host-call spam, expensive spatial queries, huge result sets, event storms, logging floods, and continuation explosions terminate within bounds.
- **Determinism:** vary platform where supported, worker count, job order, entity/chunk order, hash iteration, and replay depth; outputs, interruption point, proposals, and state hashes remain identical for the authoritative tier.
- **Transactional safety:** trap or exceed every budget after each proposal step and prove no partial mutation/continuation publication.
- **Rollback:** predict, reject, correct, and resimulate scripts with timers, randomness, waits, and events; ensure external side effects emit once only after commit.
- **Persistence:** save/load at every legal continuation, migrate schemas, remove revisions, corrupt state, and verify explicit recovery/failure without VM-internal serialization.
- **Hot reload:** activate new revisions at allowed boundaries; verify pinned active instances, migration, rollback, fleet compatibility, and replay provenance.
- **Fuzzing:** module parser/validator, ABI marshaling, host-call payloads, state decoder, proposal validator, and migration functions.
- **Differential/reference:** compare declarative interpreter, optimized/JIT/AOT execution, and reference models on generated cases.
- **Performance:** cold compile/load, warm invocation, pool miss, host-call cost, cache locality, GC, memory high-water, fixed-tick p50/p95/p99/max, and overload degradation.
- **Content certification:** headless scenario suites, property assertions, capability audit, budget report, save/replay test, network authority test, and accessibility-critical-path test per script revision.
- **Operations:** kill switch/quarantine, revision rollback, fault cardinality, privacy/redaction, crash-safe traces, and non-blocking telemetry.

## Risks and Open Decisions

- Declarative graph vocabulary and threshold for custom scripts.
- Runtime choice: custom bytecode, Lua-like interpreter, WebAssembly, engine language, or several trust tiers.
- Interpreted, JIT, or AOT by platform; console/mobile certification and executable-memory restrictions.
- Numeric semantics and cross-platform determinism tier.
- Runtime/ABI/source-language/compiler versions included in compatibility.
- Capability granularity and whether read/write declarations are static, dynamic, or both.
- Maximum fuel, memory, stack, host calls, queries, results, proposals, state, logs, and continuations per content class.
- Cost calibration for host calls and whether budgets are deterministic across platforms.
- Timeout policy: fail ability, defer, cancel effect, quarantine script, fail objective, or fail match.
- Retry semantics and idempotency after traps/stale reads.
- Async/wait model and legal yield boundaries.
- State schema language, migration ownership, active-instance pinning, and support horizon.
- Hot reload boundaries and whether balance-only data can change under pinned code.
- Client prediction eligibility and artifact disclosure/security.
- Mod/untrusted support, signing, distribution, review, platform restrictions, and save/network compatibility.
- Native extension prohibition and third-party library policy.
- Debug/source-map exposure in shipping builds.
- Deterministic garbage collection or authoritative no-GC/arena policy.
- Script fault player UX and developer escalation.
- Whether persistent quest/encounter state falls back, repairs, or blocks load after unsupported revisions.

## Engineering Recommendations

The following are Operation Mythology engineering recommendations:

1. Keep common mechanics declarative. Add custom scripting only as a governed escape hatch, not the default representation.
2. Make scripts pure evaluators over immutable typed contexts that emit bounded proposals. ECS/domain systems validate and atomically commit mutations.
3. Expose least-authority, domain-specific imports. Never expose raw ECS pointers, general world traversal, filesystem, network, wall clock, platform services, or direct reward/save/economy APIs.
4. Require a signed/versioned script manifest declaring capabilities, dependencies, result types, deterministic tier, budgets, state schema, and prediction policy.
5. Use deterministic fuel/instruction accounting for authoritative scripts, with wall-time interruption only as an outer safety net.
6. Budget CPU/fuel, memory, stack, host calls, query work/results, mutations, events, persistent state, logs, concurrency, and queues independently.
7. Charge host calls by estimated downstream work; a guest instruction limit alone cannot protect spatial queries, serialization, or fan-out.
8. Prohibit partial mutation. A trap, timeout, stale read, invalid proposal, or capability violation returns a typed failure and publishes no state.
9. Restrict authoritative inputs to fixed ticks, governed clocks/randomness, stable IDs/order, bounded collections, and pinned numeric/runtime versions.
10. Serialize schema-defined continuation state only. Never make VM stacks, coroutines, closures, heap graphs, or JIT state part of durable saves.
11. Pin active instances to a revision or run explicit migrations at legal boundaries. Record script/runtime/ABI versions in saves, replays, matches, and diagnostics.
12. Schedule scripts from indexed semantic events/timers instead of polling. Parallelize immutable invocation work and merge proposals deterministically.
13. Separate authoritative and presentation script capabilities/runtimes so nondeterministic presentation logic cannot affect gameplay.
14. Start with trusted first-party scripts. Do not imply that memory isolation alone makes untrusted mods safe; require a separate threat model and operational program.
15. Ship a script inspector with source location, revision, context IDs, capabilities, fuel/host cost, proposals, state transition, and fault reason, with shipping redaction.
16. Make static validation, capability-denial tests, sandbox escape attempts, budget bombs, deterministic schedule tests, rollback, transactional trap points, migrations, fuzzing, and headless content scenarios release gates.

## Source Links

- WebAssembly Community Group, [WebAssembly Security](https://webassembly.org/docs/security/)
- W3C/WebAssembly Community Group, [WebAssembly Core Specification 3.0](https://www.w3.org/TR/wasm-core/)
- WebAssembly/WASI, [Capabilities in WASI](https://github.com/WebAssembly/WASI/blob/main/docs/Capabilities.md)
- Bytecode Alliance, [Wasmtime: Interrupting Wasm Execution](https://docs.wasmtime.dev/examples-interrupting-wasm.html)
- Bytecode Alliance, [Wasmtime `ResourceLimiter`](https://docs.wasmtime.dev/api/wasmtime/runtime/limits/trait.ResourceLimiter.html)
- PUC-Rio, [Lua 5.4 Reference Manual](https://www.lua.org/manual/5.4/)
- PUC-Rio, [Lua 5.4 Debug Hook C API](https://www.lua.org/source/5.4/lua.h.html)
- GDC/Velan Studios, [Knockout City's Parallel, Deterministic, and Rewindable Entity System](https://www.gdcvault.com/play/1028073/-Knockout-City-s-Parallel)
- GDC/ArenaNet, [Sculpting a Gameplay Scripting Solution](https://www.gdcvault.com/play/1023204/Sculpting-a-Gameplay-Scripting)
- Epic Games, [Gameplay Ability System](https://dev.epicgames.com/documentation/en-us/unreal-engine/gameplay-ability-system-for-unreal-engine)
- Epic Games, [Gameplay Abilities](https://dev.epicgames.com/documentation/en-us/unreal-engine/gameplay-ability-in-unreal-engine)

