# Operation Mythology Mechanics Research

**Batch timestamp:** 2026-07-27T01:58:23-07:00  
**Subject:** Quests, objectives, checkpoints, transactional save/load, schema migration, cloud conflicts, and replay persistence  
**Scope:** Generic data-oriented ECS; offline and authoritative multiplayer; no production code

## Feature Overview

This feature records long-lived player/world progress and restores it safely across death, checkpoint retry, level travel, application restart, content patches, device changes, and network reconnect.

It separates five concerns:

- **quest definitions:** immutable authored graphs of stages, objectives, conditions, failure paths, and rewards;
- **runtime progress:** compact per-scope state keyed by stable definition/node IDs;
- **checkpoints:** validated restoration manifests and respawn/world-transition targets;
- **save snapshots/journals:** versioned durable representations captured from authoritative state;
- **replay records:** initial conditions plus tick-addressed commands/events for reproduction, not general save files.

The authoritative pipeline is:

`gameplay event -> indexed objective evaluators -> deterministic progress mutations -> quest transition/reward transaction -> dirty persistence records -> immutable save snapshot -> asynchronous durable commit`

Loading reverses this through validation and migration:

`read -> integrity check -> schema/content compatibility -> migrate -> stage -> validate invariants -> transactional world publication -> resume`

## Existing Coverage and Identified Gap

The mandatory scan found nine `GAME SKILLS` files, including a newly added global-illumination report; none covers quests or persistence. The dedicated mechanics folder contains traversal, inventory/interaction, and ability/effect reports. Inventory defines item persistence fields, and abilities define saveable effects, but neither owns cross-system snapshot consistency, objective progression, checkpoint recovery, or schema migration.

Earlier world research recommends stable global entity IDs and transactional `SimReady` publication. Game-flow research recommends transition transactions and safe restore points. This batch adds the missing progress model, persistence coordinator, save transaction, migrations, conflict policy, and verification requirements.

## Sourced Facts

- Unreal Engine’s save system uses game-specific `SaveGame` classes and supports multiple save files/classes, including separation of global unlocks from playthrough state. Epic explicitly cites quests, mission objectives, and subplots as possible saved state. [Epic: Saving and Loading Your Game](https://dev.epicgames.com/documentation/unreal-engine/saving-and-loading-your-game-in-unreal-engine)
- Epic recommends `AsyncSaveGameToSlot` for active gameplay because asynchronous saving avoids visible frame hitches and possible certification issues; completion reports success/failure. Synchronous saving is described as suitable for small formats or paused/menu contexts. [Epic: Saving and Loading Your Game](https://dev.epicgames.com/documentation/unreal-engine/saving-and-loading-your-game-in-unreal-engine)
- Epic’s async save API notes some platforms may not support simultaneous load and save operations. [Epic: Async Save Game to Slot](https://dev.epicgames.com/documentation/unreal-engine/BlueprintAPI/SaveGame/AsyncSaveGametoSlot)
- Unity Cloud Save write locks implement optimistic concurrency: a write using a stale lock returns a conflict instead of overwriting newer data. Resolution may re-read and merge or deliberately overwrite. [Unity Cloud Save: Write Locks](https://docs.unity.com/en-us/cloud-save/concepts/write-locks)
- Unity documents Cloud Save files as BLOB save-game storage backed up in the cloud and available across platforms. [Unity Cloud Save: Files](https://docs.unity.com/cloud-save/concepts/files)
- Research interviewing fifteen experienced game developers found quest definitions vary and proposed considering definition, context, and purpose rather than assuming one universal quest form. [Kybartas et al.: Definition-Context-Purpose Paradigm](https://arxiv.org/abs/2110.04148)
- Research on deriving quests from open-world mechanics formalized gameplay as logical rules and analyzed dependency order, bottlenecks, and generated quest graphs. This supports offline graph validation rather than treating quest data as opaque scripts. [Doran and Parberry: Deriving Quests from Open World Mechanics](https://arxiv.org/abs/1705.00341)

## Industry-Standard API or Pattern

### Quest definition graph and runtime projection

Use immutable `QuestDefinition` assets with stable IDs and version:

- scope: player, party, account, world, or session;
- prerequisite/visibility/activation queries;
- nodes and directed edges;
- objective definitions and completion/failure conditions;
- optional/hidden branches;
- reward transaction;
- reset/repeat policy;
- localization/presentation keys.

Node types should remain a small declarative set: sequence, all-of, any-of, count, condition, timer/deadline, choice, gate, terminal success, and terminal failure. Complex bespoke behavior is an event producer or registered evaluator, not arbitrary mutable script inside the persisted graph.

Runtime `QuestProgress` stores only definition/version, active/completed/failed node bitsets or compact sets, objective counters, accepted/completed sequence/tick, scoped bindings, branch choices, and reward transaction ID.

### Indexed event-driven objectives

Gameplay systems emit semantic committed events such as:

- `EntityDefeated`
- `ItemAcquired`
- `LocationEntered`
- `InteractionCompleted`
- `AbilityUsed`
- `DialogueChoiceMade`
- `WorldFactChanged`

Objective definitions compile into subscriptions indexed by event type and coarse filters such as target definition, tag, faction, location, or quest scope. Only relevant active objectives evaluate an event. Polling every quest every frame is prohibited.

Events carry stable subject/target/source IDs, authoritative tick, event sequence, tags, quantities, and context handle. Objective mutations are idempotent by event ID where retransmission/replay can occur.

Quest completion and rewards commit as one transaction. A crash after marking complete but before granting rewards must not lose or duplicate them.

### Checkpoint manifest

A checkpoint is not just a transform. `CheckpointManifest` contains:

- stable checkpoint ID and content/world revision;
- player/party spawn anchors and possession policy;
- required world cells/layers and `SimReady` gates;
- restoration scope: health/effects/ammo/inventory/quest/world facts;
- checkpoint epoch/sequence;
- encounter reset/persistence policy;
- autosave policy and UI key.

Checkpoint activation validates and commits at a fixed barrier, then schedules an immutable persistence snapshot. Death/retry uses a game-flow transition to stage the destination and restore the declared scope.

### Snapshot plus optional journal

Use a versioned snapshot as the canonical durable format. Optional write-ahead/delta journals reduce autosave bandwidth and provide audit/recovery, but periodic compaction produces a new snapshot.

Save header:

- magic/format version;
- build/content compatibility ID;
- platform user/account and slot IDs;
- save sequence, parent sequence, timestamp;
- schema table;
- compression/encryption/integrity metadata;
- section directory with offsets, sizes, hashes.

Sections are independently versioned: profile/unlocks, playthrough, quests, world facts, entities, inventory, abilities/effects, checkpoint, settings, and diagnostics. Unknown optional sections can be preserved/skipped; unknown required sections fail safely.

Capture produces an immutable staging snapshot at an authoritative barrier. Serialization/compression/write occurs asynchronously. Durable commit writes a new generation and atomically updates the slot manifest/pointer only after verification. Never overwrite the sole good generation in place.

### Migration

Migrations are ordered pure transformations from schema version `n` to `n+1`. Stable IDs are never silently reused. Maintain definition aliases/tombstones and explicit policies for removed quests, items, abilities, world entities, and checkpoints.

Migration runs on staging data, records applied steps/warnings, validates invariants, and preserves the original save. Failed migration returns an actionable error and never partially loads live ECS state.

## Performance Considerations

### Asymptotic complexity

Let `q` be active objectives, `k` subscribers matching an event index, `d` dirty persistence records, `n` total saved records, and `m` migration steps.

- Event dispatch is `O(k)`, not `O(q)`.
- Quest graph transition is `O(affected nodes/edges)`.
- Dirty snapshot capture is `O(d)` when copy-on-write/versioned stores are available; full snapshots are `O(n)`.
- Serialization, hashing, compression, load, and full validation are `O(bytes or records)`.
- Migration is `O(m * relevant records)` unless transforms can stream section-by-section.

### Allocations and garbage collection

Quest event evaluation and progress mutation allocate zero general-heap objects. Use fixed event rings, compiled subscriptions, compact bitsets/counters, and pooled mutation records.

Save capture uses pre-sized section buffers or arenas and bounded double-buffered snapshots. Do not construct object graphs, reflection strings, or per-field heap wrappers. Enforce a maximum in-flight snapshot count; coalesce autosave requests.

### Cache behavior

Store active objective subscriptions by event/filter in contiguous spans. Keep progress counters/bitsets dense by player/party. Definition graphs, localization, descriptions, and editor metadata are cold.

Serialize dense section arrays sorted by stable ID for locality, deterministic hashes, and better compression. Avoid pointer chasing through live ECS during background serialization.

### Update frequency

Quest progress is event-driven. Timed objectives use the central authoritative timer service. Autosaves trigger on meaningful dirty state, checkpoints, transitions, or elapsed policy with debounce/coalescing—not every frame.

### Concurrency

The simulation thread owns progress mutation. A barrier captures immutable section snapshots/generations. Worker threads serialize, compress, encrypt, hash, and write. Completion returns a save sequence/result event; workers never read mutable live ECS.

Only one load/commit transaction owns a slot at once. Cloud synchronization uses revision/write locks and explicit conflict resolution.

### Fixed-step cost

Cap quest transitions/rewards caused by one event and detect graph/event cycles. Save capture has a per-tick copy budget or uses versioned page references; never serialize on the fixed-step thread. Checkpoint activation and reward commits are deterministic barrier operations.

### Serialization cost

Measure capture bytes, uncompressed/compressed size, section time, migration time, write/flush latency, and load publication time. Delta journals reduce average writes but increase recovery/compaction complexity. Compression benefits repeated IDs/structured arrays; already compressed blobs should not be recompressed blindly.

### Networking cost

Server owns shared quest/world progress. Replicate sparse progress deltas only to authorized player/party audiences. Clients receive quest/node/objective IDs, counters/state, sequence, and presentation facts—not authoritative save blobs.

Cloud sync operates outside frame networking and needs bandwidth caps, retry/backoff, write locks, and conflict UI/policy. Replays store command/event streams; large authoritative multiplayer replays may require periodic keyframes.

## Pros and Cons

### Pros

- Event indexes scale with relevant objectives rather than total quest count.
- Stable IDs/versioned sections make patches and diagnostics survivable.
- Immutable async snapshots avoid gameplay hitches and data races.
- Generational commits protect the last known-good save.
- Reward transaction IDs prevent duplication.
- Checkpoint manifests unify respawn, streaming readiness, and persistence.

### Cons

- Schema/version discipline creates ongoing content and tooling work.
- Cloud conflicts cannot always be merged automatically.
- Journals add compaction/recovery complexity.
- Arbitrary scripted quest logic is harder to migrate and analyze.
- Cross-system consistent capture needs barriers/versioned storage.
- Full deterministic replays have stronger requirements than saves.

## ECS Architectural Integration

System order:

1. `CommittedGameplayEventMergeSystem`
2. `ObjectiveSubscriptionDispatchSystem`
3. `ObjectiveEvaluationSystem`
4. `QuestGraphTransitionSystem`
5. `QuestRewardTransactionSystem`
6. `CheckpointActivationSystem`
7. `PersistenceDirtyTrackingSystem`
8. `SaveSnapshotCaptureSystem`
9. background `SaveSerializationService`
10. `SaveCompletionSystem`
11. `ProgressReplicationSystem`
12. `PersistenceTelemetrySystem`

Quest definitions and subscription tables are resources. Per-player/party progress is dense component/external-store state referenced by handles. Persistent world facts use stable IDs and ownership scopes, not raw entity handles.

## Component, System, Resource, and Event Interfaces

Components:

- `QuestProgressOwner { scopeId, progressStoreHandle, revision }`
- `CheckpointState { checkpointId, epoch, activationTick, saveSequence }`
- `PersistentIdentity { stableId, schemaType, persistenceScope }`
- `PersistenceDirty { sectionMask, revision }`
- `ReplaySubject { commandStreamId, hashPolicy }`

Resources:

- `QuestDefinitionDatabase`
- `ObjectiveSubscriptionIndex`
- `QuestProgressStore`
- `WorldFactStore`
- `CheckpointDefinitionDatabase`
- `PersistenceSchemaRegistry`
- `SaveSnapshotPool`
- `SaveSlotManifestStore`
- `MigrationRegistry`
- `ReplayRecorder`
- `PersistenceBudgets/Diagnostics`

Events:

- semantic committed gameplay events;
- `QuestAccepted/NodeActivated/ObjectiveProgressed/QuestCompleted/QuestFailed`
- `RewardTransactionCommitted`
- `CheckpointActivated`
- `SaveRequested/SnapshotCaptured/SaveCommitted/SaveFailed`
- `LoadRequested/MigrationApplied/LoadValidated/LoadCommitted/LoadFailed`
- `CloudConflictDetected`
- `ReplayHashMismatch`

All durable mutations carry stable sequence/transaction IDs.

## Integration Plan

1. Establish stable-ID and schema governance across quest, world, item, ability, checkpoint, and entity definitions.
2. Build declarative quest graphs and offline validation/compiler.
3. Add semantic event schema, subscription index, compact progress, and idempotent reward transactions.
4. Define checkpoint manifests and integrate game-flow/world `SimReady` transitions.
5. Build sectioned snapshot capture with generational local commits and integrity checks.
6. Add migrations, missing-content policies, corruption recovery, and save inspector/diff tools.
7. Add cloud revisions/conflict policy, progress replication, replay commands/keyframes, and performance budgets.

## Verification Strategy

- Validate graph reachability, cycles, impossible prerequisites, missing localization/rewards, terminal paths, and stable IDs.
- Property-test duplicate/reordered events and prove objective/reward idempotency.
- Golden-test every quest branch, optional/failure path, checkpoint reset scope, and reward.
- Kill the process/power-fault logically at every save phase; verify last good generation remains loadable.
- Corrupt/truncate each section, header, hash, manifest, and journal record.
- Load every historical schema fixture through migrations; compare canonical expected state and preserve originals.
- Test missing/renamed definitions, content rollback/forward compatibility, and cloud concurrent writes.
- Assert zero warm quest allocations, bounded event chains, no fixed-thread serialization, and budgeted snapshot memory.
- Replay recorded commands/events and compare per-tick/section hashes where deterministic scope applies.

## Risks and Open Decisions

- Quest scope ownership: player, party, account, session, world, or mixed.
- Declarative graph expressiveness versus sandboxed custom evaluators.
- Event retention for objectives activated after the triggering event.
- Autosave frequency, coalescing, and platform write endurance.
- Full snapshot versus snapshot+journal.
- Mid-combat/manual-save policy and legal safe states.
- Cloud conflict policy: latest, highest progress, manual choice, or domain merge.
- Encryption/authentication and threat model.
- Cross-build determinism required for replay.
- Multiplayer reconnect snapshot and shared-quest authority.
- Removed quest/content compensation and achievement/reward integrity.
- Maximum save size/load time per platform.

## Engineering Recommendations

1. Use immutable versioned quest graphs and compact runtime progress keyed by stable IDs.
2. Drive objectives from committed semantic events through compiled subscription indexes; never poll every quest.
3. Commit quest completion and rewards atomically with idempotent transaction IDs.
4. Treat checkpoints as versioned restoration manifests tied to world readiness, not positions.
5. Capture immutable snapshots at simulation barriers and perform serialization/compression/writes asynchronously.
6. Use sectioned formats, integrity hashes, generational slots, and atomic manifest replacement; never overwrite the only good save.
7. Require explicit ordered migrations and missing-content policies before shipping persistent content.
8. Use revision/write-lock conflict detection for cloud state; never silently last-write-wins by accident.
9. Separate save snapshots from deterministic replay streams and define each scope explicitly.
10. Ship graph validators, save inspector/diff, migration fixtures, power-failure tests, and persistence telemetry as core tooling.

## Source Links

1. Epic Games, [Saving and Loading Your Game](https://dev.epicgames.com/documentation/unreal-engine/saving-and-loading-your-game-in-unreal-engine)
2. Epic Games, [Async Save Game to Slot](https://dev.epicgames.com/documentation/unreal-engine/BlueprintAPI/SaveGame/AsyncSaveGametoSlot)
3. Unity Technologies, [Cloud Save Write Locks](https://docs.unity.com/en-us/cloud-save/concepts/write-locks)
4. Unity Technologies, [Cloud Save Files](https://docs.unity.com/cloud-save/concepts/files)
5. Kybartas et al., [Definition-Context-Purpose Paradigm for Quests](https://arxiv.org/abs/2110.04148)
6. Doran and Parberry, [Deriving Quests from Open World Mechanics](https://arxiv.org/abs/1705.00341)

