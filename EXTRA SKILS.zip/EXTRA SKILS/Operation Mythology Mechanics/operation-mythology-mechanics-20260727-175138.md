# Operation Mythology Mechanics Research

**Timestamp:** 2026-07-27T17:51:38-07:00  
**Subject:** Authoritative player spawn and respawn placement, safety scoring, reservations, protection, and streamed-world readiness

## Feature Overview

Player spawning is the gameplay transaction that converts an eligible participant into a controllable character at an accepted world transform. Respawning repeats it after death, checkpoint recovery, reconnect, late join, team change, or travel. Entity construction is only the final step; the architectural problem is selecting and committing a location that is valid, fair, ready, explainable, and consistent across first-person, third-person, standalone, cooperative, and competitive play.

This batch covers authored starts, checkpoint-relative anchors, teammate-relative anchors, bounded navigation samples, and emergency fallbacks; eligibility by phase/team/role/checkpoint; collision and world-readiness validation; threat and route scoring; concurrent reservations; server-side revalidation; atomic spawn commit; bounded protection; deterministic diagnostics; replay evidence; and automated gameplay validation.

NPC population spawning, encounter pacing, procedural level generation, detailed rigid-body placement, animation entry, and visual spawn effects are excluded except at their gameplay-facing interfaces.

## Existing Coverage and Identified Gap

The mandatory recursive scan completed successfully before research:

- `C:\Users\steve\Desktop\GAME SKILLS`: 21 files.
- `C:\Users\steve\Desktop\EXTRA SKILS\Operation Mythology Mechanics`: 21 files before this batch, consisting of 20 mechanics reports plus `RESEARCH_INDEX.md`.
- No read or access errors occurred.

Existing mechanics research covers death/respawn flow states, checkpoint identity and persistence, participant-versus-pawn lifetime, authoritative commands, late join and reconnect, transactional commits, deterministic randomness, gameplay intent arbitration, world streaming, movement/collision interfaces, cameras, status effects, accessibility, telemetry, and testing.

The archive contains only one direct spawn-safety reference: an unresolved late-join decision in the session-continuity report. No report defines a spawn request schema, candidate providers, hard validity versus soft desirability, deterministic scoring, concurrent reservations, authoritative revalidation, fallback behavior, protection cancellation, or spawn-specific validation and telemetry.

The newly observed platform-capability report was audited as well. Its mechanics-facing input, lifecycle, save/service, accessibility, and capability concerns are already owned by existing reports and do not justify duplication.

## Sourced Facts

These are sourced facts rather than Operation Mythology recommendations:

1. Epic documents Player Start actors as player starting locations. With multiple starts, Unreal's default selection is random while preferring unobstructed locations. `FindPlayerStart()` and `ChoosePlayerStart()` are customization points, and Epic gives checkpoint proximity, teammate proximity, and team assignment as example criteria. Epic also warns when the Player Start capsule intersects blocking geometry.
2. Epic's gameplay framework assigns spawn and respawn rules to Game Mode. `RestartPlayer`, `RestartPlayerAtPlayerStart`, `RestartPlayerAtTransform`, and `SpawnDefaultPawnAtTransform` participate in this flow. Game Mode exists only on the server in network games; shared match state belongs in replicated Game State.
3. Unity Netcode for GameObjects can automatically create a PlayerObject or allow game code to delay and manually spawn it. With scene management, automatic PlayerObject creation waits until the joining client completes initial synchronization. In the default client-server topology, the server has ultimate spawning and despawning authority.
4. Unity documents allocation and initialization costs for repeatedly instantiating and destroying network prefabs and describes pooling as a lower-allocation option for repeated spawning.
5. Roblox's official laser-tag tutorial separates connected Player lifetime from spawned character lifetime, restricts spawn locations by team, changes spawn policy between lobby and active-round states, and keeps server-visible player state so the server can enforce spawning and equipment behavior.
6. The same Roblox tutorial demonstrates time-bounded spawn protection that ends early when the player attacks or resets. Its termination is guarded so multiple asynchronous conditions cannot destroy the protection twice.
7. The IEEE CoG 2019 paper *Heuristics for Placing the Spawn Points in FPS Games* treats safety and spatial uniformity as placement goals. Its cited rules favor lower-interest areas that are easy to leave, reject dead ends, and favor rooms with multiple exits. It uses graph representations and terms based on visibility, spacing, and topology.
8. That preliminary paper reports a 27-user study across three maps in which heuristic placement increased the time and distance needed to find targets compared with uniform placement, with statistically significant reported differences. This supports measuring topology and exposure, not adopting one universal runtime formula.
9. Naughty Dog's GDC 2023 Post System talk presents a reusable system for finding gameplay spots, including places to spawn objects, and discusses multiple implementations and their performance characteristics.

## Industry-Standard API or Pattern

Use a staged **request → discover → reject → score → reserve → revalidate → commit → protect → release** pipeline.

1. A game-flow system submits a typed request containing stable request ID, participant and generation, spawn reason, policy revision, team/party, preferred checkpoint or anchor, character footprint, required world generation, and deadline.
2. Bounded providers return candidate references from authored starts, checkpoints, teammate sockets, safe rooms, or navigation samples. Discovery never creates the pawn.
3. Hard validation rejects disabled, wrong-team, stale-generation, blocked, unsupported-footprint, lethal-volume, invalid-surface, navigation-unready, world-unready, occupied, or phase-ineligible candidates.
4. Remaining candidates receive named quantized score terms for enemy distance, hostile line of sight, recent death/damage heat, ally cohesion, objective distance, exit quality, camera clearance, repeat use, and accessibility. Mode-specific profiles select terms and weights.
5. Selection compares quantized totals and then stable provider/candidate IDs. Any random tie-break uses an explicit governed random domain rather than iteration order.
6. The server acquires a short generation-fenced reservation on the candidate and capacity cell. Wave spawns reserve in stable participant order or use a separately budgeted batch assignment.
7. Dynamic hard checks run again at the authoritative fixed-step commit barrier.
8. One atomic transaction consumes the request, creates or reactivates the pawn generation, applies transform/ownership/initial tags or effects, and emits one committed event.
9. Optional grace is an authoritative status effect with a maximum duration and explicit early-release conditions such as attacking, using an ability, leaving a safe zone, or interacting with an objective.
10. Reservation and protection cleanup are idempotent because timeout, disconnect, travel, death, and late callbacks can race.

Recommended terminal results are `Committed`, `DeferredWorldNotReady`, `DeferredNoCandidate`, `RejectedIneligible`, `Cancelled`, and `FailedInvariant`. A client timeout is an unknown outcome, not proof that the server did not commit.

## Performance Considerations

**Asymptotic complexity**

- Let `C` be bounded candidates and `E`, `A`, and `R` nearby enemies, allies, and threat records. Naive evaluation is `O(C(E + A + R))`; spatial indexes and coarse summaries approach `O(C(log N + k))` for small local result size `k`.
- Selecting one stable maximum is `O(C)`. Sorting is `O(C log C)` and should be reserved for top-`K` fallback or batch assignment needs.
- Multi-player wave assignment can become combinatorial. Prefer bounded greedy reservation in stable participant order unless a small, explicitly budgeted assignment solver materially improves fairness.
- Expensive all-pairs visibility or graph shortest paths belong in authoring/cook validation; runtime queries compiled features.

**Allocations and garbage collection**

- Candidate arrays, score terms, spatial results, reservations, and trace records use fixed-capacity arenas or pools.
- Avoid per-candidate strings, closures, dictionaries, futures, and polymorphic heap results.
- Pooled pawns may reduce construction cost only if every gameplay component, subscription, owner, effect, generation, and replication baseline is reset.
- Capacity overflow produces a deterministic measured truncation/defer result, never an unbounded allocation fallback.

**Cache behavior**

- Store immutable anchor data in structure-of-arrays form: ID, transform, footprint class, team/phase masks, world cell, navigation region, exit count, static exposure, capacity, and provider generation.
- Evaluate dense hard masks before loading expensive dynamic fields.
- Keep threat, occupancy, ally, and death-heat summaries spatially partitioned rather than scanning heterogeneous entities.
- Use dense runtime indices while retaining stable logical IDs for saves, events, logs, and replication.

**Update frequency**

- Selection is request-driven, not per-frame.
- Static features are baked; dynamic threat and occupancy update incrementally from events or at a coarse fixed cadence.
- Exact collision, line-of-sight, and navigation checks run only for the bounded finalist set and again at commit.
- Reservations and protection expiry process at fixed barriers.

**Concurrency**

- Discovery and pure scoring may run in parallel over immutable snapshots.
- Deterministic merge requires stable IDs, defined quantization, and stable result ordering.
- Reservation and commit use a serialized authoritative boundary or atomic generation compare-and-swap.
- Asynchronous spatial callbacks cannot mutate ECS; generation-stale results are discarded.

**Fixed-step cost**

- Cap requests, candidates, overlaps, rays, navigation queries, retries, and commits per tick.
- Defer nonurgent requests instead of overrunning simulation, while bounding competitive deferral.
- Batch compatible collision queries and reuse coarse threat summaries.
- Reserve simulation/recovery capacity so a join or wave-spawn burst cannot starve the match.

**Serialization cost**

- Saves persist durable checkpoint or safe-zone intent, not transient reservations.
- Replays record request ID, participant generation, reason, stable candidate or quantized transform, policy revision, world/manifest generation, fallback tier, score digest, and commit tick.
- On load, an old transform is evidence to revalidate, not an unconditional teleport.
- Use bounded bitsets and quantized fields for rejection and protection state.

**Networking cost**

- Clients send respawn intent/readiness, never an accepted transform or safety score.
- The server replicates one committed spawn record plus normal entity state; candidate lists and enemy evidence remain private.
- Possession and interest ordering must prevent enabling control before the pawn and required world are ready.
- Wave spawns amortize headers but must remain within construction and replication budgets.
- Spawn protection is authoritative and replicated compactly.

## Pros and Cons

**Pros**

- One contract supports initial spawn, checkpoint recovery, respawn, late join, reconnect, and travel while preserving policy differences.
- Hard rejection prevents an attractive score from overriding collision, streaming, team, phase, or footprint invariants.
- Deterministic scores and IDs make decisions replayable and testable.
- Reservations close concurrent selection/commit races.
- Server authority prevents advantageous client-chosen transforms or protection.
- Compiled metadata and bounded queries produce predictable cost.
- Decision evidence improves level validation, live balancing, support, and exploit diagnosis.
- Placement remains shared between FP and TP while camera clearance is a policy-specific validation input.

**Cons**

- Fairness is multi-objective and needs per-mode/map tuning.
- Threat heat and visibility become stale between updates.
- Reservations and world readiness add lifecycle states.
- Dynamic ally-relative starts can produce geometry, pop-in, or tactical exploits.
- Protection can enable scouting, body blocking, objective contesting, or first-shot advantage.
- Fully deterministic choices may become predictable to opponents.
- Diagnostics can expose sensitive player-position and anti-cheat evidence.

## ECS Architectural Integration

Spawn placement is a transactional domain service around the ECS, not behavior owned by the disposable character.

- Game-flow, death, checkpoint, session, travel, or administration emits a request for a durable participant.
- Providers publish immutable candidate views for the current world generation.
- Query systems discover, hard-filter, and score from read-only snapshots.
- One authoritative reservation system acquires capacity leases.
- The commit system establishes pawn generation, transform, control ownership, initial state, and replication identity.
- Presentation, telemetry, quests, checkpoints, and accessibility consume the committed event but cannot rewrite the decision.

Durable inventory, progression, quest, and ability ownership remains outside the pawn. Pawn-bound state is reconstructed through the established participant-to-pawn initialization contract. Reconnect may repossess a surviving pawn rather than spawning; that decision precedes the spawn request.

The service reads character footprint, stance, and locomotion capability so a candidate cannot require an unavailable crouch, climb, swim, or traversal action. It writes a perspective-independent facing basis; FP and TP camera systems resolve their own presentation pose.

Rollback simulation must not repeatedly create entities or dispatch external effects. The committed spawn is a journaled authoritative boundary. A client may predict the transition presentation but reconciles placement and protection to the committed record.

## Component, System, Resource, and Event Interfaces

These are conceptual data interfaces, not production code.

**Components**

- `SpawnEligibility { ParticipantId, ParticipantGeneration, State, TeamId, RoleTags, EarliestTick, DeadlineTick }`
- `SpawnFootprint { ShapeClass, Radius, StandingHeight, CrouchedHeight, RequiredLocomotionTags }`
- `SpawnProtection { PolicyId, StartTick, EndTick, CancelMask, State }`
- `SpawnedFrom { RequestId, CandidateId, PolicyRevision, CommitTick, FallbackTier }`
- `SpawnAnchorRuntime { CandidateId, ProviderId, ProviderGeneration, DenseIndex, Capacity, EnabledMask }`
- `SpawnReservation { CandidateId, CapacityCellId, RequestId, OwnerGeneration, ExpiresTick }`

**Resources**

- `SpawnPolicyRegistry`: immutable versioned validation and scoring profiles.
- `SpawnCandidateRegistry`: compiled anchor tables and provider generations.
- `SpawnSpatialIndex`: occupancy, threat, ally, death-heat, and capacity summaries.
- `SpawnWorldReadiness`: cell, collision, navigation, and replication-readiness generations.
- `SpawnBudget`: request, candidate, spatial-query, retry, and commit limits.
- `SpawnDecisionTraceRing`: bounded privileged diagnostics.

**Systems**

- `SpawnRequestAdmissionSystem`
- `SpawnCandidateDiscoverySystem`
- `SpawnHardValidationSystem`
- `SpawnScoreSystem`
- `SpawnStableSelectionSystem`
- `SpawnReservationSystem`
- `SpawnAuthoritativeRevalidationSystem`
- `SpawnCommitSystem`
- `SpawnProtectionLifecycleSystem`
- `SpawnReservationExpirySystem`
- `SpawnTelemetrySystem`

**Commands and events**

- `RequestSpawn { RequestId, ParticipantId, ParticipantGeneration, Reason, PolicyId, PreferredAnchorId?, RequiredWorldGeneration, RequestedTick }`
- `SpawnDeferred { RequestId, Reason, RetryAfterTick, Attempt }`
- `SpawnRejected { RequestId, Reason }`
- `SpawnCommitted { RequestId, ParticipantId, PawnId, PawnGeneration, CandidateId, Transform, CommitTick, PolicyRevision, ProtectionPolicyId? }`
- `SpawnProtectionEnded { ParticipantId, PawnGeneration, Reason, Tick }`
- `SpawnReservationExpired { RequestId, CandidateId, Tick }`
- `SpawnDecisionDigest { RequestId, CandidateCount, RejectionHistogram, ScoreDigest, FallbackTier, Outcome }`

Repeated delivery of a committed request returns the same semantic result. Reusing a request ID with changed participant, generation, or intent is rejected.

## Integration Plan

1. Enumerate spawn reasons, eligibility states, terminal results, hard-invalid conditions, protection cancellation, and ownership between game-flow and spawn service.
2. Add non-reused logical IDs, provider generations, capacity cells, team/phase tags, footprint classes, and world-cell dependencies to authored starts and checkpoints.
3. Bake collision envelopes, surfaces, navigation regions, exits, static exposure, camera clearance, and streaming dependencies. Fail content validation on missing IDs or impossible footprints.
4. Begin with bounded authored and checkpoint providers. Add teammate-relative or navigation-derived candidates only after their exploit rules are specified.
5. Ship hard rejection bitsets before score tuning. Add named quantized score terms behind versioned policies and diagnostics.
6. Implement generation-fenced reservation, final revalidation, idempotent atomic commit, and cleanup.
7. Integrate world-cell pinning/readiness, deadlines, retry bounds, and safe fallback.
8. Integrate server authority, committed-record replication, interest, possession, input enabling, and camera bootstrap.
9. Implement protection through the existing status-effect/timer architecture with explicit outgoing-action, collision, objective, and zone policies.
10. Add candidate overlays, rejection/score inspectors, reservation views, heatmap replays, and telemetry dashboards.
11. Tune distinct profiles for checkpoint, co-op regroup, arena, wave spawn, late join, reconnect, and emergency recovery.
12. Gate release on automated map certification, adversarial races, fixed-step budgets, network-order tests, and fairness metrics.

## Verification Strategy

**Determinism and invariants**

- Permute candidate storage, job completion, and spatial-query result order; identical snapshots must produce identical decisions.
- Test score quantization, stable ties, policy revisions, random-domain slots, and replay reconstruction.
- Generate candidates with ideal scores but one failed hard invariant; none may be selected.
- Prove each admitted request reaches one terminal outcome and each committed request creates at most one pawn generation.

**Geometry and movement**

- Test every footprint, stance, slope, stair, ledge, water, ladder, low ceiling, moving platform, and forbidden volume relevant to initialization.
- Sweep collision before reservation and at commit.
- Validate facing/camera clearance in FP and TP without changing authoritative placement by perspective.
- Confirm non-emergency starts have usable exits and do not require unavailable traversal capability.

**Multiplayer races**

- Respawn many players into fewer capacity cells; verify stable reservation, no overlap, bounded deferral, and no starvation.
- Race death, disconnect, reconnect, team change, travel, match end, checkpoint update, world unload, and cancellation against selection/commit.
- Inject duplicate, delayed, reordered, and lost requests and acknowledgements.
- Verify clients cannot provide transforms, scores, protection duration, or another participant's request.
- Test possession and interest under latency, packet loss, late join, and relevancy transitions.

**Safety and abuse**

- Position enemies nearby, behind cover, above starts, looking at candidates, firing through exits, or camping routes.
- Include hazards, projectiles, turrets, AI, stealth actors, spectators, damage zones, and recent-death heat.
- Attempt protection abuse by attacking, healing, scouting, blocking, pushing, reviving, contesting, carrying objectives, and crossing zone boundaries.
- Trigger several protection-end conditions on one tick and verify idempotency.

**Streaming, persistence, and performance**

- Unload the selected cell between discovery and commit; delay collision, navigation, replication, and client readiness independently.
- Remove or redirect saved checkpoint anchors and verify deterministic fallback.
- Measure worst-case candidates, density, waves, rays, overlaps, navigation queries, retries, allocations, pool misses, fixed-step time, and bytes.
- Assert zero steady-state heap allocation for bounded selection/reservation and load-test join/respawn bursts.

**Gameplay validation**

- Track death within post-spawn windows, visible-at-spawn rate, time/distance to threat, repeat use, objective travel, deferral, fallback, protection cancellation, and team asymmetry.
- Segment cautiously by map, mode, team, skill, party size, perspective, input device, network quality, and accessibility configuration.
- Require human playtests because geometric safety does not prove orientation, clarity, fairness, or fun.

## Risks and Open Decisions

- Which reasons share a policy and which require separate contracts?
- Are candidates authored, dynamically sampled, or hybrid?
- What are hard-invalid conditions for every mode and footprint?
- Which enemies, AI, turrets, hazards, projectiles, objectives, and recent events count as threats?
- How are line of sight, exposure, stealth, spectator knowledge, and anti-cheat secrecy represented?
- Who owns score terms, normalization, weights, hysteresis, and policy approval?
- Is tie-breaking predictable deterministic choice, governed random choice, or secret server randomness?
- Are teammate-relative starts legal during combat, vehicles, traversal, water, or scripted sequences?
- How are wave assignments and group fairness evaluated?
- What are capacity, reservation radius, lease, retry, starvation, and overflow policies?
- When no candidate passes, does the game wait, relax named constraints, use a safe room/checkpoint, spectate, or fail?
- How long can streaming defer, and which subsystem certifies replication-ready world state?
- Does reconnect repossess, restore a safe anchor, or use current-mode selection?
- What exactly does protection block, which actions cancel it, and can protected players scout, block, heal, revive, contest, or carry?
- How do fade, camera, input enablement, and possession acknowledgement interact with protection time?
- Which evidence is replicated, logged, retained, or hidden?
- What fairness thresholds block map release or trigger policy rollback?
- How do anchor redirects/tombstones work across saves, replays, hotfixes, mods, and DLC?
- Can pooled pawns satisfy all component, ownership, subscription, effect, and replication reset invariants?

## Engineering Recommendations

These are engineering recommendations derived from the sources and existing Operation Mythology architecture:

1. Establish one authoritative spawn-domain contract with reason-specific versioned policies; prohibit independent pawn construction by modes, checkpoints, sessions, or character features.
2. Make trusted simulation solely authoritative for candidate selection, transform, pawn generation, and protection. Clients provide intent/readiness only.
3. Separate hard validity from soft scoring. Collision, world readiness, footprint, team/phase, ownership, lethal-volume, and generation checks are vetoes.
4. Use bounded providers, compiled structure-of-arrays metadata, event-driven evaluation, and fixed-capacity scratch storage.
5. Quantize score terms and use stable IDs/tie-breaks. Route any randomness through the existing governed random-domain contract.
6. Reserve finalists, revalidate at the authoritative fixed barrier, and atomically commit pawn, transform, ownership, initial state, event, and audit digest.
7. Make request handling, reservation, commit results, and protection termination idempotent and generation-fenced.
8. Require world, collision, navigation, replication-interest, possession, and camera bootstrap readiness before control; define bounded deferral and fallback.
9. Implement protection as an authoritative status effect with maximum duration, early cancellation, abuse restrictions, replication, and telemetry.
10. Start with authored/checkpoint anchors and add dynamic or teammate-relative candidates only when evidence shows a gameplay need.
11. Precompute topology, exits, visibility, and exposure, combine them with bounded current threat summaries, and reserve exact queries for finalists.
12. Record enough decision evidence for replay and diagnosis without exposing enemy-sensitive information to clients.
13. Ship an editor/runtime inspector and automated map certification before tuning weights; treat overflow, unexplained rejection, fallback, and unsafe-spawn rates as release signals.
14. Evaluate fairness using survival, visibility, orientation, engagement time/distance, repeat use, and team asymmetry—not nearest-enemy distance alone.
15. Keep character placement perspective-independent while validating camera clearance for both FP and TP.

## Source Links

1. Epic Games, **Player Start Actor in Unreal Engine 5.8**  
   https://dev.epicgames.com/documentation/en-us/unreal-engine/player-start-actor-in-unreal-engine
2. Epic Games, **Game Mode and Game State in Unreal Engine 5.8**  
   https://dev.epicgames.com/documentation/en-us/unreal-engine/game-mode-and-game-state-in-unreal-engine
3. Unity Technologies, **PlayerObjects and player prefabs — Netcode for GameObjects**  
   https://docs-multiplayer.unity3d.com/netcode/current/basics/playerobjects/
4. Unity Technologies, **Understanding ownership and authority — Netcode for GameObjects**  
   https://docs-multiplayer.unity3d.com/netcode/2.2.0/basics/ownership/
5. Unity Technologies, **Object spawning — Netcode for GameObjects**  
   https://docs-multiplayer.unity3d.com/netcode/current/basics/object-spawning/
6. Roblox, **Spawn and respawn — Creator Hub**  
   https://create.roblox.com/docs/tutorials/curriculums/gameplay-scripting/spawn-respawn
7. Loiacono, Lanzi, and Togelius, **Heuristics for Placing the Spawn Points in FPS Games**, IEEE Conference on Games, 2019  
   https://ieee-cog.org/2019/papers/paper_59.pdf
8. Game Developers Conference, Ming-Lun “Allen” Chou / Naughty Dog, **Picking a Good Spot: Naughty Dog’s Post System**, GDC 2023  
   https://www.gdcvault.com/play/1029277/Picking-a-Good-Spot-Naughty
