# Operation Mythology Mechanics Delta Research — State Lifetime, Ownership, and Transfer Contracts

**Timestamp:** 2026-07-27T02:26:29-07:00  
**Delta basis:** Cross-report audit of unresolved ownership decisions after baseline mechanics coverage.  
**Scope:** Process/user/session/playthrough/match/world/participant/avatar/action/presentation lifetimes; stable identities; state ownership; death, respawn, possession, travel, reconnect, save/load, split-screen, replication, transfer manifests, and ECS integration.

## Feature Overview

This delta resolves a shared architectural dependency across inventory, equipment, abilities/effects, quests, accessibility, input, cameras, game flow, networking, persistence, and replay: **what owns state, how long it lives, and how it crosses a boundary**.

Use an explicit lifetime lattice:

1. **Process:** engine instance, platform services, global registries.
2. **Local user:** accessibility, input mappings, display/audio preferences, local entitlements cache.
3. **Online session/connection:** authentication evidence, connection sequence, session membership, transport state.
4. **Account/profile:** durable unlocks, account progression, cross-play identity.
5. **Playthrough/campaign:** world facts, quests, checkpoints, persistent inventory depending on design.
6. **Match/mission:** teams, score, round rules, match objectives, authoritative mode policy.
7. **Participant/player:** stable in-match player identity, inventory/equipment ownership, persistent ability grants, reconnect/life state.
8. **World/zone:** spawned world entities, containers, environmental state, navigation/streaming generations.
9. **Avatar/pawn:** transform, movement, posture, health where avatar-specific, transient status, collision, current motion sources.
10. **Execution/action:** ability activation, item transaction, interaction, combat command, predicted cue.
11. **Local presentation:** camera rig, UI focus/stack, narration/caption queues, smoothing, haptics.

Longer-lived owners may create projections into shorter-lived domains. A participant equips an item, grants an avatar ability, and creates a third-person weapon proxy; destroying the avatar or proxy must not destroy the authoritative item unless an explicit gameplay transaction says so.

## Existing Coverage and Identified Gap

The mandatory recursive scan at 2026-07-27T02:25:51-07:00 found:

- `C:\Users\steve\Desktop\GAME SKILLS`: 12 files.
- `C:\Users\steve\Desktop\EXTRA SKILS\Operation Mythology Mechanics`: 11 files.

All baseline requested domains have reports. The open-decision audit revealed repeated unresolved lifetime questions:

- inventory owner: account, participant, pawn, party, or world;
- effects/abilities across death and respawn;
- quest scope: player, party, account, session, or world;
- accessibility/input profile across user, device, cloud, and local guest;
- camera/UI state per local player;
- checkpoint/save legality during traversal, death, travel, or pause;
- stable IDs across respawn, reconnect, save/load, replay, and world partition;
- travel persistence and late-join readiness;
- owner-predicted entity scope and disconnect cleanup.

Treating each independently risks contradictory behavior and duplicate transfer code. The genuinely new gap is one project-wide ownership and transfer protocol.

## Sourced Facts

The following are sourced facts; the lifetime lattice and policies below are engineering recommendations.

- Epic documents `GameInstance` as process-long (launch to shutdown), non-replicated, and suitable for systems/data that must persist across level loads. Game-instance and local-player subsystems inherit the lifetime of their owner.
- Unreal creates `GameMode` per loaded world and keeps it server-only. `GameState` and `PlayerState` hold replicated game-wide and participant-specific state respectively.
- Epic describes a pawn as a possessed world actor, while player controllers/player states represent player control and network-relevant participant state. This separates participant lifetime from physical avatar lifetime.
- Unreal `PlayerState` has explicit hooks for copying properties during seamless travel and overriding state during reconnect; it also tracks inactive/rejoining state.
- Unreal seamless travel preserves selected framework actors and lets game/player controllers add an explicit persistence list. Non-seamless travel disconnects/reconnects instead.
- Unreal's player controller exposes `SeamlessTravelFrom`/`SeamlessTravelTo` hooks to transfer and clean up selected persistent controller state when controller classes change.
- Unity Netcode for GameObjects is server-authoritative by default for spawning/despawning network objects. A client should not locally destroy a replicated object; it requests server action.
- Unity distinguishes player objects from other client-owned network objects. A client has at most one player object but may own multiple other objects.
- Unity provides `DontDestroyWithOwner` and `destroyWithScene` controls, demonstrating that owner destruction and scene destruction are separate lifetime axes that require an explicit policy.
- Unity Netcode for Entities' `GhostOwner` associates a replicated entity with a connection and is required for owner-predicted ghosts and ownership-targeted data.
- Unity's `ConnectionState` cleanup component can retain connection identity and disconnect reason until gameplay removes it, illustrating a tombstone/cleanup lifetime beyond the active transport entity.
- Unity documents protocol/prefab compatibility checks and scene-load timeouts, reinforcing that state transfer depends on compatible schemas/content and bounded readiness.
- Both engine families expose mechanisms rather than deciding game semantics: an engine can preserve an object across a scene or owner loss, but the game must define whether inventory, effects, quests, or progression should persist.

## Industry-Standard API or Pattern

### Owner and projection

Every state record declares:

`owner_domain, stable_owner_id, lifetime_policy, authority, replication_audience, persistence_policy, transfer_codec, reset_policy`

Separate:

- **authoritative record:** source of truth;
- **runtime projection:** shorter-lived data derived from that record;
- **presentation proxy:** local/replicated visualization;
- **reference:** stable ID plus expected generation/revision, never a raw ECS pointer across boundaries.

### Boundary transaction

Use a transition manifest:

`freeze/close input -> capture eligible source records -> validate target/schema/policy -> reserve target identities -> transfer/rebind -> rebuild projections -> verify invariants -> publish readiness -> retire source/tombstones`

The manifest is allowlisted by boundary type:

- pawn death/respawn;
- unpossess/repossess;
- seamless world travel;
- hard travel;
- disconnect/reconnect;
- save/load;
- party/session migration;
- replay restore.

Do not use “copy all components” or “preserve all entities.” Those approaches carry transient caches, physics handles, presentation state, stale references, and uncommitted transactions across incompatible lifetimes.

## Performance Considerations

- **Asymptotic complexity:** Ordinary lookup through stable ID maps is expected `O(1)`. Boundary capture/transfer is `O(E + B)`, where `E` is eligible records and `B` is referenced bytes. Reference validation is `O(R)`. Full-world scans are avoidable by maintaining per-owner/per-policy indexes.
- **Allocations and garbage collection:** Reserve per-domain stores, transfer manifests, remap tables, tombstone rings, and projection command buffers. Boundary transitions may allocate from dedicated arenas, but hot spawn/death/equip paths should reuse pooled records. Never allocate per-frame ownership wrappers or strings.
- **Cache behavior:** Keep hot participant/avatar state in separate dense tables so respawn does not scatter participant data through avatar chunks. Store stable IDs, owner IDs, generations, and compact policy IDs together. Transfer codecs iterate dense registered fields rather than object graphs.
- **Update frequency:** Ownership changes are event-driven. Do not poll parents for lifetime. Projection reconciliation runs on source revision changes, spawn/possession/readiness, or boundary completion. Tombstone expiration and reconnect deadlines use bounded periodic service work.
- **Concurrency:** Capture from immutable snapshots at a commit barrier. Background save/serialization reads captured pages. Target creation and reference remap commit deterministically after jobs complete. No worker follows mutable pointers into another domain during transfer.
- **Fixed-step cost:** Death/respawn, possession, item/effect grants, and world entity retirement commit at defined tick barriers with per-tick budgets. Large world travel/save work is staged outside fixed simulation. A participant must not become command-ready until required projections are rebuilt.
- **Serialization cost:** Persist only domains declared durable. Serialization is `O(records + references)` with stable IDs and versioned sections. A remap table converts saved IDs to runtime handles. Transient connection IDs, ECS rows, physics handles, UI widgets, and pending async objects are never serialized.
- **Networking cost:** Replicate state by authoritative owner and audience. Private inventory/profile state is owner-only; match/public participant facts have wider audiences; pawn state follows relevance. Boundary messages carry generation/revision and are idempotent. Reconnect snapshots should be sectional/delta-capable rather than replaying arbitrary creation side effects.
- **Memory:** Separating domains adds stable maps, generations, tombstones, and projection metadata. Bound tombstone/reconnect retention; use compact dense owner ranges. Avoid duplicating full inventory/effects in participant and pawn—pawn projections reference authoritative records.
- **Migration:** Cross-version transfer cost includes codec/migration work and missing-content policy. Measure worst saves and travel manifests; never migrate on the fixed thread.

## Pros and Cons

**Explicit lifetime lattice**

- Pros: predictable death/travel/reconnect; stable ownership; clear persistence/replication; fewer dangling references.
- Cons: up-front taxonomy and tooling; some feature state spans multiple domains and must be split.

**Participant-owned durable gameplay state**

- Pros: pawn replacement is cheap; reconnect and spectating are natural; inventory/equipment/quest ownership is not tied to collision actors.
- Cons: avatar queries need projections/joins; local single-player implementations cannot assume everything lives on the character.

**Allowlisted transfer manifests**

- Pros: auditable, versionable, testable, secure; excludes transient state by default.
- Cons: new state requires registration; omissions surface as missing state until validation catches them.

**Preserving runtime entities wholesale**

- Pros: initially less transfer code.
- Cons: preserves stale handles, callbacks, physics/contact caches, presentation, invalid async tasks, and incompatible world references. Avoid as the generic architecture.

## ECS Architectural Integration

Use a separate ECS world/store or explicit domain tag only when scheduling/lifetime isolation warrants it; the conceptual lifetime lattice does not require eleven ECS worlds. The minimum useful physical split is:

- process/local-user services outside authoritative gameplay ECS;
- authoritative session/playthrough/match/participant records in stable dense stores;
- world/avatar entities in the simulation ECS;
- execution records in bounded transaction/prediction pools;
- presentation state in client-local ECS/services.

`StableId` is namespaced by domain and includes generation. A runtime `EntityHandle` is only valid for its world generation. Cross-domain components store stable references resolved through published maps. Systems declare whether a missing reference means wait, rebuild, cancel, substitute, or fail.

Participant-to-avatar projection is one-way:

- inventory/equipment record -> avatar ability/stat grants and visual proxies;
- participant accessibility/input profile -> local command/presentation configuration;
- player life state -> pawn spawn/possession/camera policy;
- quest/playthrough state -> local HUD/objective projections;
- authoritative effect policy -> participant- or avatar-owned effect instances according to definition.

Reverse changes occur only through typed transactions/events, not by copying mutated projection data back automatically.

## Component, System, Resource, and Event Interfaces

### Components

- `StableDomainId { namespace, id, generation }`
- `LifetimeOwner { domain, owner_id, policy_id }`
- `AuthorityOwner { authority_type, authority_id, revision }`
- `RuntimeProjectionOf { source_id, source_revision, projection_type }`
- `StableReference { target_domain, target_id, expected_generation }`
- `TransferEligible { boundary_mask, codec_id, priority }`
- `PendingRetirement { boundary_id, retire_after_phase }`
- `ParticipantAvatarLink { participant_id, avatar_id, possession_generation }`
- `ReconnectTombstone { participant_id, token_hash, expiry, last_revision }`

### Resources

- `LifetimePolicyRegistry { domains, boundary_rules, reset_rules }`
- `StableIdentityAllocator { namespace_counters, free_generations, reservations }`
- `DomainLocationMaps { stable_id_to_runtime_handle, published_generation }`
- `OwnershipIndex { owner_to_records, policy_to_records }`
- `TransferManifestRegistry { boundary_type, codecs, dependencies, ordering }`
- `BoundaryTransactionPool { manifests, remaps, results, idempotency }`
- `ProjectionRegistry { source_type, target_type, builder, teardown }`
- `TombstoneStore { disconnect, destruction, transfer, retention }`
- `ReferenceValidationPolicy { wait, substitute, drop, fail }`

### Commands and Events

- `BoundaryRequested { boundary_id, type, source, destination, reason }`
- `BoundaryCaptureCompleted { boundary_id, manifest_hash, record_count }`
- `OwnershipTransferCommand { record_id, old_owner, new_owner, expected_revision }`
- `ProjectionCreate/Destroy/Rebind { source, target, generation }`
- `AvatarRetired { avatar_id, participant_id, cause, tick }`
- `ParticipantReconnected { participant_id, connection_id, resume_revision }`
- `ReferenceInvalidated { source, target, reason }`
- `BoundaryCommitted/Rejected { boundary_id, result, reason }`
- `StateResetApplied { record_id, reset_policy, cause }`

### Systems and Ordering

1. close/cancel in-flight actions that cannot cross the boundary;
2. capture authoritative eligible records at a commit barrier;
3. validate schema, destination, authority, and revisions;
4. reserve stable IDs and build deterministic remap table;
5. transfer/rebind records in dependency order;
6. rebuild participant/avatar/world/presentation projections;
7. validate invariants and readiness;
8. publish new domain/location generations;
9. retire source projections/entities and retain bounded tombstones;
10. emit replicated/persistence deltas and transition telemetry.

## Integration Plan

1. Approve the lifetime/authority matrix for every current component/resource: owner domain, replication audience, persistence, death reset, travel behavior, reconnect behavior, and replay/hash inclusion.
2. Introduce namespaced stable IDs and published location maps. Ban raw cross-domain ECS handles in serialized, replicated, queued, or long-lived state.
3. Establish the participant entity/store distinct from pawn. Move authoritative item ownership, equipment assignment, persistent grants, reconnect identity, and player life state there as design permits.
4. Split state currently mixing lifetimes. Example: item ownership stays with participant/playthrough; held-weapon pose and mesh proxy stay with avatar/presentation.
5. Define effect ownership in data: avatar-life, participant-life, match-life, playthrough-life, or real-time account service. Apply explicit reset/transfer policies on death/travel.
6. Define quest/inventory/playthrough owners and party/shared authority. Avoid deriving ownership from the current pawn or connection.
7. Build boundary transactions for death/respawn and unpossess/repossess first. Verify exact-once teardown and rebuild.
8. Add seamless travel manifest, then hard travel/save-load manifests. Hard travel must work without relying on runtime object preservation.
9. Add reconnect tombstones and sectional participant resync with authenticated resume tokens, revision checks, expiry, and duplicate-login policy.
10. Connect local-user profile/accessibility/input/camera/UI projections to local player—not pawn or network connection—while defining profile swap and split-screen behavior.
11. Generate diagrams, validators, and code/data registries from the same lifetime schema to prevent documentation drift.

## Verification Strategy

- Generate a complete component/resource lifetime report in CI and fail unclassified authoritative state.
- Property-test arbitrary sequences of spawn, possess, die, revive, respawn, spectate, travel, disconnect, reconnect, save, load, and profile swap.
- Assert each authoritative item instance has exactly one owner/location before and after every boundary; no projection may become a second owner.
- Assert every ability/effect definition follows its declared reset/transfer policy and that costs/damage/cues are not recommitted during projection rebuild.
- Test references to destroyed, recycled, unloaded, migrated, and version-mismatched targets; generation checks must reject stale aliases.
- Compare uninterrupted gameplay with seamless-travel, hard-travel, save/load, and reconnect paths at equivalent checkpoints using domain-level canonical hashes.
- Fault-inject cancellation or crash after every boundary phase. Recovery must either resume idempotently or roll back to the last committed manifest.
- Test duplicate and reordered boundary/ownership messages, repeated reconnect, simultaneous profile sign-out, host loss, and late async completion.
- Run split-screen tests with two local profiles, separate accessibility/input/UI/camera state, shared world/match state, and independent join/leave.
- Verify network audiences: private profile/inventory fields never reach non-owners; public participant facts do; pawn relevance does not delete participant authority.
- Load-test mass respawn/travel/reconnect. Measure transfer records/bytes, remap cost, projection rebuild, stable-map misses, tombstone memory, replication bytes, allocations, and fixed-step stalls.
- Maintain migration fixtures for previous lifetime schemas and removed content. Unsupported manifests fail with actionable diagnostics, not partial silent transfer.

## Risks and Open Decisions

- Final owner of inventory/equipment: account, playthrough, participant, party, or combinations by item category.
- Whether health/attributes live on participant, avatar, or split into persistent and avatar pools.
- Effect lifetime vocabulary and default; whether designers may override it per effect.
- Quest sharing/ownership and party membership changes.
- Stable-ID format, namespace size, generation width, and offline/cloud merge behavior.
- Whether seamless travel preserves selected runtime entities or always reconstructs from manifests.
- Reconnect grace, duplicate login, abandoned participant, bot takeover, and host migration.
- Split-screen local-user identity versus online participant identity.
- Save/load treatment of active executions, traversal, combat, death, and boundary transactions.
- World entity persistence across streaming cells/zones and cross-zone references.
- Ownership transfer for dropped/traded/looted items during disconnect or travel.
- Projection rebuild ordering among equipment, abilities, attributes, effects, camera, input, and UI.
- Tombstone retention and privacy/security of reconnect evidence.
- Party/account services outside the simulation and compensation for partial external commits.

## Engineering Recommendations

These are engineering recommendations derived from the cross-report audit and sources.

1. Adopt one project-wide **lifetime and ownership lattice**; require every authoritative field to declare an owner domain.
2. Make participant identity independent of pawn, connection, controller, and world entity lifetimes.
3. Store authoritative inventory/equipment/quests/persistent grants at their true durable owner and derive avatar/presentation projections.
4. Use namespaced generational stable IDs across domains; raw runtime handles never cross travel, save, network, async, replay, or long-lived event boundaries.
5. Transfer through allowlisted, versioned, idempotent manifests. Do not preserve/copy arbitrary entities or components.
6. Define death, respawn, travel, reconnect, and save/load reset/transfer policy in data and validate it offline.
7. Publish new location-map generations only after references and projections are rebuilt and invariants pass.
8. Retain bounded tombstones for destruction/reconnect diagnostics and stale-reference rejection.
9. Keep local-user settings/accessibility/input/camera/UI private and attached to local-player lifetime; attach authoritative assists to mode/participant policy.
10. Make hard reconstruction the correctness baseline even if seamless travel optimizes by preserving selected runtime objects.
11. Test boundary sequences as transactions, including crash/cancel at every phase and exact-once side effects.
12. Instrument transfer volume, projection rebuild, reference failures, ownership invariant failures, tombstone growth, and boundary recovery.

## Source Links

- [Epic Games — Gameplay Framework](https://dev.epicgames.com/documentation/en-us/unreal-engine/gameplay-framework-in-unreal-engine)
- [Epic Games — Gameplay Framework Quick Reference](https://dev.epicgames.com/documentation/en-us/unreal-engine/gameplay-framework-quick-reference-in-unreal-engine)
- [Epic Games — Programming Subsystems and Managed Lifetimes](https://dev.epicgames.com/documentation/en-us/unreal-engine/programming-subsystems-in-unreal-engine)
- [Epic Games — APlayerState API](https://dev.epicgames.com/documentation/en-us/unreal-engine/API/Runtime/Engine/APlayerState)
- [Epic Games — APlayerController API](https://dev.epicgames.com/documentation/en-us/unreal-engine/API/Runtime/Engine/APlayerController)
- [Epic Games — Travelling in Multiplayer](https://dev.epicgames.com/documentation/en-us/unreal-engine/travelling-in-multiplayer-in-unreal-engine)
- [Epic Games — Game Mode and Game State](https://dev.epicgames.com/documentation/en-us/unreal-engine/game-mode-and-game-state-in-unreal-engine)
- [Unity — Netcode for GameObjects NetworkObject](https://docs-multiplayer.unity3d.com/netcode/1.13.0/basics/networkobject/)
- [Unity — Netcode Object Spawning and Scene Lifetime](https://docs-multiplayer.unity3d.com/netcode/current/basics/object-spawning/)
- [Unity — NetworkManager Session Lifecycle](https://docs-multiplayer.unity3d.com/netcode/current/components/networkmanager/)
- [Unity — Netcode for Entities GhostOwner](https://docs.unity.cn/Packages/com.unity.netcode%401.0/api/Unity.NetCode.GhostOwner.html)
- [Unity — Netcode for Entities ConnectionState](https://docs.unity.cn/Packages/com.unity.netcode%401.0/api/Unity.NetCode.ConnectionState.html)
- [Unity — Ghost Snapshots and Ownership Audiences](https://docs.unity.cn/Packages/com.unity.netcode%401.4/manual/ghost-snapshots)
