# Operation Mythology Mechanics Research

**Timestamp:** 2026-07-27T17:56:36-07:00  
**Subject:** Authoritative crafting, recipes, ingredient selection, stations, queued production, quality, provenance, durability, and attachment transformations

## Feature Overview

Crafting converts owned resources and world conditions into one or more item/state outcomes. A complete system must define much more than “subtract ingredients and add output”: recipe identity and revision, ingredient predicates, exact instance selection, catalysts and reusable tools, station access, capacity, time, cancellation, quality, byproducts, durability/attachment transformation, ownership, authoritative commit, retries, queue persistence, multiplayer contention, and content migration.

This report covers immediate crafting and time-based production; fungible stacks and unique instances; deterministic ingredient allocation; reusable tools/catalysts; repair and upgrade transformations; attachment installation/removal; output placement; station reservations; cooperative contribution; client preview versus authority; and offline/service persistence. It does not prescribe UI, animations, VFX, detailed physical manufacturing, marketplace monetization, or authored asset workflows except where they define gameplay contracts.

## Existing Coverage and Identified Gap

The required recursive scan completed before this batch:

- `C:\Users\steve\Desktop\GAME SKILLS`: 21 files.
- `C:\Users\steve\Desktop\EXTRA SKILS\Operation Mythology Mechanics`: 22 files before this batch, consisting of 21 reports plus `RESEARCH_INDEX.md`.
- Both trees and the active index were readable; no filesystem errors occurred.

The inventory/equipment report already defines stable item instances, stacks, ownership, equipment grants, authoritative inventory transactions, revision checks, and durability/attachment identity. It explicitly postpones crafting until core transactions are correct and leaves durability/attachment representation unresolved. The transaction report adds idempotency, reservations, atomic local commits, outboxes, sagas, compensation, and unknown-outcome handling. Definition manifests cover revision identity and migration. Progression covers recipe unlocks.

No existing report defines:

- a recipe schema or matching semantics;
- deterministic selection among equivalent stacks/instances;
- consumed ingredients versus returned tools/catalysts;
- immediate versus queued production;
- station capability, capacity, reservation, destruction, and disconnect policy;
- output placement when inventories are full;
- repair, upgrade, reroll, or attachment transformations that preserve or replace identity;
- quality/provenance derivation;
- cooperative contributions and ownership;
- crafting-specific prediction, replay, save/load, content migration, abuse controls, or performance limits.

Replication interest was considered as another candidate and rejected as duplicate: the shared networking report already covers server-authoritative relevance, dependency closure, privacy, priority, byte budgets, complexity, and ECS integration.

## Sourced Facts

These facts come from the sources; project recommendations follow later.

1. Unity Economy virtual purchases exchange configured currency or inventory-item costs for currency or inventory-item rewards. A virtual purchase can have multiple cost and reward resources, and the purchase result identifies costs spent and rewards granted.
2. Unity's SDK lets a caller name specific player-inventory item instance IDs to use toward purchase costs; if not supplied, the service can choose automatically. This distinction matters when items have unique instance data.
3. Unity Economy inventory items can have per-instance data. Its documented operational caps include bounded cost/reward resource counts, custom-data size, and inventory-instance count. These are service limits, not universal gameplay limits.
4. Unity recommends restricting direct client writes and routing authoritative updates through trusted server code such as Cloud Code, while allowing safe reads where appropriate.
5. PlayFab's crafting tutorial represents recipes as prices and stations/locations as stores. Its reusable Icebox example consumes the tool and returns another instance, which demonstrates transactional input/output modeling but also shows that apparent preservation may replace identity.
6. PlayFab Economy V2 `ExecuteInventoryOperations` runs ordered inventory operations transactionally: the batch succeeds or fails together. The current REST reference documents request limits, single-collection scope, ETags for concurrency, idempotency IDs, and returned transaction IDs.
7. PlayFab documents idempotency IDs for inventory writes so identical retries return the original result during the retention window, and separately documents ETags for optimistic concurrency. Its guidance notes that identical idempotent retries and re-read/new-request ETag conflict retries have different semantics.
8. PlayFab inventory stacks can have distinct stack IDs and custom properties; batched operations can target specific stacks.
9. Steam Inventory exchange recipes declare required quantities and item types. A successful exchange destroys the supplied required items and adds a new target item instance; a nonmatching set fails without inventory changes.
10. Steam's secure server exchange API states that API keys must not be shipped in clients. It also propagates the latest trade restriction from consumed items to the created item, illustrating provenance/restriction inheritance.
11. Steam Inventory item tools can transform tags on a target by consuming a tool and producing a copied target with modified tags, illustrating attachment/cosmetic transformations as explicit item exchanges.
12. Epic's Lyra documentation distinguishes durable inventory instances from equipment instances, stores per-instance stat/tag data, and treats equipment as a pawn-owned runtime projection. This supports completing crafting against durable inventory state before rebuilding equipment projections.

## Industry-Standard API or Pattern

Use an authoritative **quote → select → reserve → execute or enqueue → commit → deliver** transaction.

**Recipe definition**

A versioned immutable recipe declares:

- stable logical recipe ID and revision digest;
- input clauses with quantity, acceptable definition/tag/property predicates, stackability, condition range, binding/ownership rules, and selection policy;
- roles: consumed ingredient, required-but-returned catalyst/tool, damaged target, attachment, currency, capability, or station charge;
- output clauses with definition, amount, instance policy, property/provenance transform, byproducts, destination policy, and overflow behavior;
- station/capability/environment predicates;
- duration, clock domain, queue/capacity class, cancellation/refund policy, and commit point;
- quality and randomness algorithm revision;
- authority, prediction, persistence, and migration policy.

**Quote**

The client or UI requests a nonauthoritative quote from a read-only snapshot. The quote identifies recipe revision, eligible candidates, default deterministic allocation, expected outputs/range, station/time/cost, blocking reasons, and an expiry/revision token. It never grants items or reserves indefinitely.

**Selection**

Ingredient matching is a bounded bipartite allocation problem. First satisfy explicit user-selected unique instances, then deterministic policy-selected fungible stacks. Use stable ordering such as:

1. exact definition before tag alternatives;
2. lowest sufficient condition/quality when policy minimizes waste;
3. smallest expiring stack or explicit perishable policy;
4. unbound before bound if allowed;
5. stable instance/stack ID.

Do not rely on container iteration order. For recipes with overlapping predicates, greedy matching can fail even when a solution exists; either constrain recipe authoring to an unambiguous form or use a bounded matching/flow solver and validate complexity offline.

**Reserve**

At command admission, trusted authority revalidates recipe revision, unlocks, participant/station state, distance, ownership, inventory revision, quantities, selected instances, capacity, and output destination. It reserves exact inputs, output capacity, station slot, and any cross-owner contribution. Reserved items cannot be equipped, moved, traded, consumed, or used by another craft unless policy explicitly shares them.

**Immediate execution**

For zero-duration/local-owner crafts, consume inputs, transform/replace targets, create outputs/byproducts, release reservations, update revisions, record provenance, and publish committed events atomically.

**Queued execution**

For time-based production:

- commit a durable job and reservations first;
- advance using an explicit simulation/server/wall clock;
- record an irreversible pivot such as `ProductionStarted` or `OutputCommitted`;
- at completion, revalidate delivery rather than recharging inputs;
- deliver idempotently to reserved inventory capacity, station output, mailbox/claim container, or an explicit blocked-output state;
- persist retries and unknown outcomes.

Station destruction, travel, disconnect, owner transfer, pause, save/load, and server migration use explicit cancellation, continuation, salvage, or compensation policies.

**Transformations**

Repair, upgrade, reroll, and attachment operations explicitly choose:

- preserve item identity and increment revision; or
- consume old identity and create a successor linked by provenance.

Never silently replace a unique item when binding, history, trade restrictions, quest references, or external ownership expect identity preservation. Returned catalysts retain their original identity unless the recipe explicitly transforms them.

## Performance Considerations

**Asymptotic complexity**

- Let `I` be candidate inventory entries, `R` recipe clauses, `M` mutations, `J` active jobs, and `S` station slots.
- Indexed exact-definition matching is approximately `O(R + matches)`; naive tag/property scanning is `O(RI)`.
- Deterministic greedy allocation is `O(I log I + R)` if candidates require sorting, or near `O(I + R)` with maintained stable indexes/buckets.
- General overlapping ingredient predicates form a matching/flow problem; worst-case solver cost can exceed linear time. Bound clause/candidate counts and reject ambiguous high-cost recipes during content validation.
- Commit is `O(M)` plus index maintenance. Job advancement is `O(due jobs)` with a timer wheel/min-heap (`O(log J)` insertion for a heap) rather than `O(J)` polling.

**Allocations and garbage collection**

- Compile recipes into dense immutable tables and preallocate candidate, clause, reservation, mutation, and result buffers.
- Quotes reuse bounded scratch arenas; UI receives compact handles/results rather than object graphs.
- Immediate and warm queued-job ticks perform zero general-heap allocation and no managed GC.
- Pool job, reservation, provenance, and outbox records; fail or defer when declared limits are exceeded.

**Cache behavior**

- Index inventory by definition, tags, owner/container, reserved state, expiry/condition bands, and stable instance ID.
- Store compiled clauses in structure-of-arrays form and group common predicates.
- Separate hot quantities/revisions/reservations from cold descriptive/custom data.
- Batch jobs by recipe/station/clock and apply mutation command buffers in stable owner order.

**Update frequency**

- Quotes run on user request or relevant revision change, not every frame.
- Immediate crafts execute at a fixed gameplay barrier.
- Queued jobs wake on due-time buckets, station/state events, cancellation, or delivery availability.
- UI countdowns interpolate locally from authoritative start/end facts; they do not drive completion.

**Concurrency**

- Read-only quote/matching can run in parallel over immutable inventory/definition snapshots.
- Exact reservation and commit serialize per inventory/station aggregate or use revision-checked atomic command buffers.
- Acquire multiple owner/container/station reservations in canonical order to avoid deadlock.
- Cross-service crafting uses durable workflow/outbox semantics and never assumes one distributed transaction.

**Fixed-step cost**

- Budget craft admissions, candidate scans, matching work, mutations, completions, and event fan-out per tick.
- Cap batch craft quantity after expanding mutation/output counts, not only by requested recipe count.
- Spread large job completions deterministically while preserving completion order and player-visible deadlines.
- Do not resimulate durable inventory commits during prediction rollback.

**Serialization cost**

- Definitions serialize stable IDs/revisions and compiled dependency manifests.
- Jobs persist job ID, recipe revision, owner/contributors, exact reserved input identities/quantities, station generation, start/end clock facts, random address/quality inputs, state, pivot, output plan, and delivery status.
- Saves record committed jobs and reservations, not UI quotes or scratch matches.
- Provenance can grow without bound; store a compact lineage digest plus policy-required audit references rather than recursive embedded history.

**Networking cost**

- Clients send recipe ID, request ID, quantity, optional explicit input IDs, station ID, and quote/revision evidence—not output quality or success.
- Server replies with bounded rejection/quote data or committed job/result deltas.
- Replicate queue state only to authorized owner/party/station audiences.
- Large inventory refreshes are avoided by sparse mutation deltas plus revisions; on mismatch, request a scoped authoritative resync.
- Craft spam is controlled with command/byte/work budgets before expensive matching.

## Pros and Cons

**Pros**

- One transaction model covers crafting, repair, upgrades, rerolls, attachments, salvage, and refinement.
- Exact reservation prevents double-spend across craft, equip, trade, drop, or consume races.
- Versioned recipes and recorded revisions make jobs, saves, and replays auditable.
- Deterministic selection makes preview and authority easier to reconcile.
- Identity/provenance rules preserve unique-item semantics and external restrictions.
- Event-driven queues scale better than polling all jobs.
- Explicit overflow and cancellation avoid lost outputs and ad hoc refunds.

**Cons**

- General predicate recipes can create expensive or surprising matching behavior.
- Reservations reduce inventory availability and add lifecycle states.
- Time-based jobs introduce durable state, migrations, clocks, and support cases.
- Preserving full provenance can consume substantial storage.
- Cross-owner cooperative crafting is a workflow, not one local atomic transaction.
- Deterministic auto-selection may consume an item the player valued unless the policy and preview are clear.
- Live recipe changes need pinning or migration and can create economic arbitrage.

## ECS Architectural Integration

Crafting is an inventory-domain transaction coordinator. It reads immutable recipe definitions, participant capabilities/unlocks, station state, and inventory projections; it writes only through authoritative inventory mutations and durable job state.

The ECS flow is:

1. `CraftQuoteSystem` builds a read-only preview.
2. `CraftCommandAdmissionSystem` authenticates the participant and validates rate/state/station/recipe evidence.
3. `CraftIngredientSelectionSystem` resolves explicit and deterministic inputs.
4. `CraftReservationSystem` reserves input identities, output capacity, and station capacity.
5. `CraftImmediateCommitSystem` atomically applies zero-duration operations, or `CraftJobStartSystem` creates durable queued work.
6. `CraftJobDueSystem` schedules completions using the selected clock.
7. `CraftCompletionSystem` commits results exactly once and hands external delivery to the transaction/outbox architecture.
8. `EquipmentProjectionSystem`, abilities, quests, progression, and presentation react to committed item changes.

Crafting never mutates an equipped pawn proxy directly. If a crafted/repaired/modified item is equipped, the inventory commit publishes a new item revision and equipment revalidates/rebuilds grants at its legal barrier.

Authoritative random quality uses the existing random-domain contract addressed by job/request ID, recipe revision, output slot, and named draw slot. Replays record the committed outcome or governed inputs. Rollback suppresses durable commit and presentation duplication.

## Component, System, Resource, and Event Interfaces

Conceptual interfaces, not production code:

**Components**

- `CraftStation { StationId, Generation, CapabilityTags, QueueClass, SlotCount, State, OwnerPolicy }`
- `CraftStationOccupancy { ActiveSlots, ReservationRevision }`
- `CraftJob { JobId, RequestId, RecipeId, RecipeRevision, OwnerId, State, Pivot, StartTick, DueTime, ClockId }`
- `CraftJobInputs { ReservedInputSetHandle, ContributionSetHandle }`
- `CraftJobOutputs { OutputPlanHandle, DeliveryDestination, DeliveryState }`
- `ItemReservation { ItemId, ItemGeneration, Quantity, PurposeId, OwnerId, ExpiresOrJobId }`
- `ItemProvenance { OriginKind, RecipeId, RecipeRevision, SourceDigest, CreatorId?, CreatedTick }`

**Resources**

- `RecipeRegistry`: immutable compiled recipes and revisions.
- `CraftMatchingIndex`: definition/tag/property indexes over eligible inventory state.
- `CraftStationRegistry`: stable station IDs, generations, capabilities, and world readiness.
- `CraftJobStore`: durable active jobs and completion indexes.
- `CraftTimerQueue`: due jobs by explicit clock.
- `CraftBudget`: limits for quotes, clauses, candidates, mutations, jobs, reservations, and completion fan-out.
- `CraftDecisionTraceRing`: bounded privileged matching/commit diagnostics.

**Commands and events**

- `RequestCraftQuote`
- `SubmitCraft`
- `CancelCraftJob`
- `CraftQuoteProduced`
- `CraftRejected`
- `CraftInputsReserved`
- `CraftJobStarted`
- `CraftJobProgressChanged`
- `CraftCommitted`
- `CraftOutputDeliveryBlocked`
- `CraftOutputDelivered`
- `CraftCancelled`
- `CraftCompensationPending`
- `ItemTransformed`
- `CraftReservationReleased`

Every write command carries stable request identity, participant generation, recipe revision, inventory/station revisions, and explicit selected item IDs when player choice matters.

## Integration Plan

1. Freeze recipe roles, identity semantics, clocks, terminal states, and authority boundaries.
2. Extend the gameplay manifest with stable recipe IDs, revision digests, dependencies, redirects, tombstones, and compatibility classes.
3. Compile exact-definition/tag/property clauses and reject ambiguous or over-budget recipes offline.
4. Add inventory reservation state and canonical multi-resource acquisition.
5. Implement quotes and immediate single-owner crafts using existing atomic inventory transactions.
6. Add deterministic auto-selection plus explicit unique-item selection and clear preview evidence.
7. Add repair/upgrade/attachment transformations with preserve-versus-successor identity policy.
8. Add stations, distance/capability checks, capacity slots, and generation-fenced reservations.
9. Add durable queued jobs, timer scheduling, cancellation pivots, output capacity, and blocked-delivery recovery.
10. Integrate save/load, travel, reconnect, server migration, hotfix pinning/migration, and external outboxes.
11. Add cooperative contribution only after cross-owner reservation, withdrawal, ownership, and compensation rules are approved.
12. Build recipe graph validation, economy simulation, inspector, job/admin repair tooling, and telemetry gates.

## Verification Strategy

**Recipe and matching tests**

- Validate missing definitions, cycles, impossible quantities, overlapping clauses, ambiguous catalysts, duplicate outputs, integer overflow, excessive mutation expansion, and unsupported property predicates.
- Property-test that selection never consumes an ineligible/reserved/bound/equipped/quest item.
- Permute inventory iteration and job scheduling; deterministic policies must select identical input IDs.
- Compare greedy results with a reference matching solver for constrained generated recipes.

**Transaction and race tests**

- Race crafting with equip, consume, drop, trade, split/merge, durability loss, quest reservation, death, disconnect, and concurrent crafts.
- Inject duplicate, reordered, delayed, lost, and timed-out commands. One request may commit at most once and return the same semantic result on retry.
- Fail each mutation step; no partial local inventory result is allowed.
- Race station destruction, ownership transfer, capacity change, world unload, and queue cancellation.

**Identity and provenance tests**

- Verify consumed, returned, transformed, and successor identities for fungible stacks, unique items, tools, catalysts, repair targets, and attachments.
- Preserve binding, trade/market restriction, quest, ownership, and audit rules through every transformation.
- Validate provenance digest determinism, retention, redaction, and migration.

**Queue and persistence tests**

- Test pause/suspend, clock discontinuity, offline elapsed time, save during every state/pivot, load on another build, reconnect, host migration, and unsupported recipe revision.
- Fill all output destinations; verify blocked delivery without reconsuming inputs or duplicating output.
- Test cancellation before/after pivots, refund/salvage rounding, compensation failure, and administrative repair.

**Security and multiplayer tests**

- Forge recipe, revision, quantity, station, ingredient IDs, ownership, quality, completion time, output IDs, contributor lists, unlocks, and provider success.
- Enforce station distance/line-of-use where required and reject stale participant/station generations.
- Rate-limit cheap admission before matching and mutation expansion.
- Verify private inventory/provenance and party queue data are not replicated to unauthorized peers.

**Performance and balance tests**

- Measure candidates per clause, matching time, allocation/GC, cache misses, commit mutations, queue size, due-job bursts, serialized job size, network bytes, resyncs, and outbox lag.
- Assert fixed-capacity behavior and zero warm-tick general-heap allocation.
- Run economy simulations for recipe graph sources/sinks, loops, arbitrage, overflow, rounding, salvage, repair, and live revision transitions.
- Telemetry includes success/rejection reason, selected alternatives, time/cost, cancellation, blocked delivery, duplicate retries, and output distribution under privacy/cardinality limits.

## Risks and Open Decisions

- Are recipes exact definitions, tags, property predicates, alternatives, or a constrained combination?
- Is auto-selection allowed for unique, valuable, bound, modified, equipped, or quest items?
- Which selection order minimizes waste, expiration, condition loss, or player surprise?
- Are catalysts/tools truly preserved by identity, damaged, charged, returned as successors, or only capability predicates?
- Do repair/upgrade/attachment operations preserve target identity?
- How are binding, ownership, trade restrictions, provenance, quest references, and external platform items inherited?
- What quality inputs are authoritative, deterministic, random, skill-based, station-based, or difficulty/accessibility affected?
- Are outputs fixed, ranged, probabilistic, choice-based, or deferred until completion?
- Which clock advances jobs during pause, suspend, offline time, maintenance, or migration?
- What is the irreversible pivot and cancellation/refund/salvage rule?
- Where do outputs go when inventory, station, or mailbox capacity is full?
- Can jobs continue when station/owner unloads, travels, disconnects, dies, changes party, or loses the recipe unlock?
- Does a live recipe update pin active jobs, migrate them, compensate them, or invalidate only future jobs?
- Are stations exclusive, shared, queued, parallel, ownable, destructible, or movable?
- How are cooperative contributions reserved, withdrawn, credited, owned, and compensated?
- What maximum clauses, alternatives, candidates, batch quantity, mutations, outputs, jobs, and provenance bytes are allowed?
- Can offline or listen-server authority craft durable/economy items, and how is trust reconciled?
- Which operations may call an external economy provider and what is the source of truth?
- What player-facing state appears for timeout, pending durability, blocked delivery, migration, or repair?

## Engineering Recommendations

These recommendations are distinct from the sourced facts:

1. Build crafting as a specialization of the existing authoritative inventory transaction architecture, not as direct item removal/addition in UI or station code.
2. Define immutable versioned recipes with explicit input roles, output identity, station/capability predicates, clock, cancellation pivot, quality/randomness, destination, and migration policy.
3. Constrain recipe predicates so matching remains bounded and explainable. Reject ambiguous/high-cost content offline or use a small deterministic matching solver.
4. Let players explicitly select valuable/unique inputs; use stable deterministic auto-selection only for policy-approved fungible resources.
5. Reserve exact item quantities/instances, output capacity, and station slots before execution; generation-fence all evidence and acquire multiple resources in canonical order.
6. Commit immediate local-owner crafts atomically. Model time-based work as durable idempotent jobs whose completion never recharges inputs.
7. Treat repair, upgrade, reroll, and attachments as explicit transformations with preserve-or-successor identity and provenance rules.
8. Keep returned tools/catalysts by identity unless the recipe intentionally transforms or consumes charges/durability; do not fake preservation by replacement when identity matters.
9. Route quality randomness through governed named draw slots and record recipe revision plus committed output facts.
10. Make full-inventory delivery a durable blocked state or declared claim destination, never silent loss or repeated consumption.
11. Use server/trusted authority for recipe validation, selection, timing, output, and durable economy writes; clients predict presentation and quotes only.
12. Use event-driven timer queues and compiled inventory indexes; cap all candidate, mutation, job, and network work.
13. Pin active jobs to recipe revisions by default. Require explicit migration/compensation for incompatible hotfixes.
14. Delay cooperative/cross-owner crafting until reservation withdrawal, ownership, contribution credit, disconnect, and compensation policies are specified.
15. Ship a crafting inspector showing recipe revision, matching candidates, selected inputs, reservations, pivots, random addresses, mutations, delivery, idempotency, and provider status.
16. Make recipe graph validation, race/fault tests, identity/provenance tests, queue recovery, security fuzzing, and economy simulation release gates.

## Source Links

1. Unity Technologies, **Economy Purchases SDK**  
   https://docs.unity.com/en-us/economy/sdk/purchases
2. Unity Technologies, **Add a virtual purchase to your game**  
   https://docs.unity.com/en-us/economy/add-virtual-purchase
3. Unity Technologies, **Introduction to resources in Economy**  
   https://docs.unity.com/en-us/Economy/item-types
4. Unity Technologies, **Control access to services / Cloud Code server authority**  
   https://docs.unity.com/en-us/cloud-code/server-access-control
5. Unity Technologies, **Economy parameters of operation**  
   https://docs.unity.com/en-us/economy/parameters
6. Microsoft PlayFab, **Crafting Game: Context**  
   https://learn.microsoft.com/en-us/gaming/playfab/economy-monetization/economy-v2/tutorials/craftinggame/game-context
7. Microsoft PlayFab, **Crafting Game Part 3: Coding**  
   https://learn.microsoft.com/en-us/gaming/playfab/economy-monetization/economy-v2/tutorials/craftinggame/crafting-game-coding
8. Microsoft PlayFab, **Execute Inventory Operations REST API**  
   https://learn.microsoft.com/en-us/rest/api/playfab/economy/inventory/execute-inventory-operations
9. Microsoft PlayFab, **Idempotent transactions and retry patterns**  
   https://learn.microsoft.com/en-us/gaming/playfab/economy-monetization/economy-v2/tutorials/idempotent-transactions-and-retries
10. Microsoft PlayFab, **ETags and concurrency control**  
    https://learn.microsoft.com/en-us/gaming/playfab/economy-monetization/economy-v2/tutorials/etags-and-concurrency-control
11. Valve, **Steam Inventory Service / ExchangeItem**  
    https://partner.steamgames.com/doc/webapi/IInventoryService
12. Valve, **Steam Inventory Item Tools**  
    https://partner.steamgames.com/doc/features/inventory/tools
13. Epic Games, **Lyra Inventory and Equipment**  
    https://dev.epicgames.com/documentation/en-us/unreal-engine/lyra-inventory-and-equipment-in-unreal-engine
