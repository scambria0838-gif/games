# Operation Mythology Mechanics Delta Research — Durable Player Progression, Unlocks, and Reward Credit

**Timestamp:** 2026-07-27T16:14:08-07:00  
**Scope:** XP, levels, ranks, mastery, skill/unlock graphs, prerequisites, reward credit, party/community contribution, respec, seasonal progression, authoritative grants, offline/cloud reconciliation, ECS integration, performance, security, debugging, and verification.

## Feature Overview

Progression converts committed gameplay outcomes into durable player capabilities and records:

- experience, level, rank, reputation, and mastery;
- skill points and unlock nodes;
- recipes, abilities, equipment permissions, traversal capabilities, and content gates;
- milestone, quest, achievement, challenge, party, and community rewards;
- seasonal or mode-scoped progress;
- respec, reset, migration, compensation, and administrative repair.

Progression must not be a set of unrelated integer fields modified directly by quests, combat, UI, scripts, platform achievements, and cloud callbacks. Use an authoritative progression transaction:

`committed evidence -> credit policy -> bounded contribution records -> prerequisite/curve evaluation -> progression mutation plan -> reward/unlock grant plan -> atomic local commit -> durable outbox -> external reconciliation -> semantic outcome`

Separate four concepts:

1. **Evidence:** a committed match, quest, objective, encounter, discovery, or administrative fact.
2. **Credit:** which progression owners receive how much progress under a versioned policy.
3. **Progression state:** XP, levels, mastery counters, points, and unlock graph state.
4. **Rewards/effects:** items, currencies, abilities, tags, entitlements, achievements, and presentation cues produced after progression commits.

This separation prevents duplicate grants, makes party/late-join rules explicit, supports respec and seasonal scopes, and lets external platform/backend services reconcile without becoming the live ECS authority.

## Existing Coverage and Identified Gap

The mandatory recursive scan found 18 files in `C:\Users\steve\Desktop\GAME SKILLS` and 20 files in the mechanics archive. No required directory or file produced an access error.

Existing reports cover:

- inventory/equipment ownership and transactions;
- abilities, attributes, effects, costs, cooldowns, damage, healing, and tags;
- quests/objectives/checkpoints and sectioned save/load;
- player/account/playthrough/match/avatar lifetimes;
- reconnect, late join, host recovery, and authority epochs;
- idempotent commands, outboxes, workflows, compensation, and external effects;
- definition manifests, compatibility, migration, deterministic RNG, scripting, telemetry, and validation.

They mention account progression, unlock save sections, match rewards, achievements, and compensation, but do not define a progression model. Missing contracts include:

- progression owner and scope—account, character, playthrough, class, weapon, faction, party, community, season, or match;
- XP curve and threshold semantics, overflow, caps, prestige, and level loss;
- immutable unlock definitions versus runtime node state;
- prerequisite expression, mutual exclusion, ranks, points, and derived capabilities;
- contribution/credit policy for assists, party proximity, shared objectives, disconnects, late joins, and forfeits;
- exactly-once evidence consumption and reward granting;
- respec as a validated transaction with dependency closure and refunds;
- permanent versus seasonal/resettable state;
- multi-device/offline/cloud conflict handling;
- client-readable versus server-writable/internal fields;
- repair, audit, privacy, accessibility presentation, and live-balance migration.

This report fills that domain model while reusing the established persistence and transaction infrastructure.

## Sourced Facts

The following are sourced facts:

- Unity Cloud Code states that important player progress and high scores should be server-authoritative, with rules and achievement validation on the server so clients cannot directly manipulate scores or unlocks.
- Unity access-control guidance recommends restricting direct player writes and routing updates through trusted server code. It gives examples denying player writes to Cloud Save, inventory/currency, and leaderboard scores while allowing reads where appropriate.
- Unity's server game-state example loads authoritative state, validates the requested action, applies changes, saves the result, and then notifies the client.
- Unity Economy stores player currency balances and inventory instances, and its inventory APIs support write locks for optimistic concurrency.
- Microsoft PlayFab distinguishes client-writable player data, server-writable/client-readable data, and server-only internal data. It recommends entity objects for new titles and documents player-scoped versus publisher/cross-title data.
- PlayFab's progression services provide player data and statistics across devices. Its transactional statistics feature specifically addresses duplicate operations when queued or retried updates use aggregations such as sum.
- PlayFab seasonal statistics create new versions while retaining a configurable number of previous versions, rather than destructively overwriting the same record.
- PlayFab community statistics aggregate player source statistics into title- or group-level destinations and document that historical values are not automatically backfilled when aggregation is introduced later.
- Steamworks provides persistent roaming stats and achievements. It can restrict specific stats/achievements to game-server or official-game-server writes, preventing client writes for those definitions.
- Steamworks states that official server writes offer stronger anti-cheat properties than player-hosted servers and limits game-server stat updates to users currently present plus a short post-departure grace period.
- Steamworks warns that a separate local stats cache can conflict with its roaming cache and appear to revert progress; it describes automatic merging behavior for multi-machine changes.
- Epic Online Services achievements can derive from ingested stat progress or be manually unlocked, are configured per deployment/sandbox, and have service and definition limits.

**Bounded engineering inference:** backend statistics, achievements, economy objects, and player-data stores provide primitives, not a complete gameplay progression domain. Operation Mythology must still define credit, prerequisite, respec, scope, idempotency, migration, and authority semantics.

**Bounded engineering inference:** platform achievement XP is not the same as in-game XP. Treat platform achievements as projections of committed internal progression facts unless a deliberate product policy says otherwise.

## Industry-Standard API or Pattern

### Progression scopes

Every progression track declares an owner and reset scope:

`ProgressionScope { owner_kind, mode_id, season_id?, definition_revision, persistence_class }`

Examples:

- account-wide permanent unlocks;
- character/playthrough level;
- class or skill-line mastery;
- weapon/tool familiarity;
- faction reputation;
- party/guild/community challenge;
- match-only upgrade track;
- season-limited pass/challenge;
- platform achievement projection.

Do not infer scope from where a component happens to live. The same player may have simultaneous permanent, playthrough, character, match, and seasonal tracks.

### Immutable definitions

`ProgressionTrackDefinition`:

- stable track ID and revision;
- owner/reset scope;
- value type and legal range;
- threshold/curve table;
- cap, overflow, prestige, decay, and loss policy;
- eligible evidence/credit policies;
- granted point/capability/reward tables;
- visibility and replication policy;
- migration and removal policy.

`UnlockNodeDefinition`:

- stable node ID and revision;
- owning graph/track;
- ranks and point cost by rank;
- prerequisites and exclusion groups;
- granted capabilities/definitions/tags;
- refund/respec policy;
- mode/season/content requirements;
- migration/tombstone policy.

Definitions are immutable within a pinned match or transaction. Runtime state references stable IDs and revisions.

### Evidence and credit

Only committed authoritative facts create progression evidence:

`ProgressionEvidence { evidence_id, type, source_transaction, authoritative_tick, match/playthrough, subject, targets, contributors, context_tags, definition_revisions }`

Credit calculation produces bounded immutable records:

`ProgressionCredit { evidence_id, progression_owner, track_id, amount, reason, credit_policy_revision }`

Credit policy may consider:

- direct action versus assist;
- damage/healing/support/objective contribution;
- party membership and objective sharing;
- proximity, presence, eligibility, and minimum participation;
- join/leave/disconnect/forfeit state;
- difficulty/mode and accessibility-assist policy;
- anti-farming caps and repeated-target rules;
- server-verified match completion.

The policy must not consume client-claimed contribution totals as truth.

### Transaction and idempotency

Use `evidence_id + progression_owner + track_id + policy_revision` as a deduplication identity or derive a stable credit ID. A repeated event, reconnect replay, outbox retry, platform callback, or server recovery returns the prior semantic outcome rather than granting twice.

One local progression commit atomically:

1. verifies evidence and eligibility;
2. reserves/deduplicates credit IDs;
3. applies XP/stat deltas with overflow-safe arithmetic;
4. computes crossed thresholds;
5. grants level/rank points;
6. validates auto-unlocks/milestones;
7. records reward intents and audit facts;
8. increments aggregate revision;
9. publishes semantic events/outbox entries.

External inventory, currency, achievement, entitlement, or cross-title effects use the existing durable workflow/outbox boundary.

### Unlock graph

Compile prerequisite expressions into a directed dependency representation:

- required track/level/rank;
- required node/rank;
- any/all groups;
- mutually exclusive choice groups;
- content/mode/season ownership;
- quest/world/account facts;
- available point/currency costs.

Reject missing IDs, impossible ranks, self-dependencies, unauthorized cross-scope references, and unintended cycles at content build time. If cycles are deliberately used for mutual groups, represent them explicitly rather than as prerequisite cycles.

Runtime unlock command:

`RequestUnlock { command_id, owner, graph_id, node_id, desired_rank, expected_revision }`

The server re-evaluates prerequisites/costs from authoritative state and commits point spend plus capability grants atomically.

### Respec

Respec is not “clear all nodes.” It is a transaction:

1. select requested removal set or target build;
2. compute dependent closure;
3. detect equipped/active abilities, items, quests, or modes requiring removed capabilities;
4. apply policy—block, unequip, deactivate, replace, or grandfather;
5. compute refunds/fees and cap behavior;
6. validate the resulting graph from roots;
7. commit removals, grants, refunds, equipment/ability adjustments, and events atomically.

Preserve audit identity so repeated respec requests do not duplicate refunds.

### Seasonal state

Separate:

- permanent account progression;
- season-scoped values/unlocks;
- season-earned permanent claims;
- archived historical summaries;
- unclaimed reward state.

Advancing a season creates/pins a new version/scope. It does not mutate old evidence identities or silently reuse a previous season's track IDs. Define claim grace, conversion, expiry, and offline reconciliation explicitly.

## Performance Considerations

### Asymptotic complexity

- Track lookup, credit dedupe, and node-state lookup are expected `O(1)` by stable IDs.
- Applying `C` credit records is `O(C)` plus threshold crossings. Threshold lookup is `O(log L)` for `L` sorted thresholds or amortized `O(crossed levels)` from current state.
- Unlock prerequisite evaluation is `O(P)` for the node's compiled prerequisite terms; maintained dependency counters can make common checks near `O(1)`.
- Unlock commit plus dependent capability grant is `O(G)` for `G` grants.
- Respec dependent closure is `O(V + E)` over affected unlock nodes/edges; it is command-driven, not per tick.
- Party/community credit is `O(K)` for bounded eligible contributors. Never scan all players/community members from a gameplay event.
- Audit/outbox append is `O(1)` amortized; reconciliation is `O(pending records)`.

### Allocations and garbage collection

- Fixed simulation uses value-type evidence/credit buffers and precompiled definitions; no per-XP heap object, string, reflection record, or closure.
- Batch multiple credits from one tick/match into bounded transaction buffers.
- Persistent histories and audit records are append pages/pools outside ECS chunks.
- Unlock graph dependencies, threshold tables, and reward tables are immutable compiled arrays.
- UI builds presentation models from immutable snapshots at presentation cadence.
- External service payload/serialization buffers are pooled and bounded.

### Cache behavior

- Keep hot track state dense: track ID/index, value, level/rank, available/spent points, revision, season.
- Store names, descriptions, icons, narrative text, audit detail, and historical seasons cold.
- Compile stable IDs to dense manifest indices per definition generation.
- Store unlock states as compact rank arrays/bitsets where graph size permits; keep sparse maps only for very large optional graphs.
- Group credits by owner/aggregate to reduce random writes and lock contention.

### Update frequency

- Progression is evidence- and command-driven. It does not tick each frame.
- Accumulate noisy combat contributions in bounded match-local counters and commit policy-defined credits at meaningful boundaries where appropriate.
- Permanent/external progression writes may be batched, but the local authoritative outcome is committed immediately or marked pending with a visible durability state.
- Seasonal rollover and decay are scheduled service workflows using authoritative time/version boundaries.
- UI observes revision changes instead of polling backend services every frame.

### Concurrency

- One commit authority or optimistic revision rule owns each progression aggregate.
- Workers may calculate credit/progression plans from immutable snapshots, but commit rechecks revision, policy, caps, and prerequisites.
- Parallel credits to the same owner are canonically ordered or folded with overflow-safe associative rules when semantics allow.
- Cross-owner party/community aggregation uses durable contribution events, not shared mutable counters in worker jobs.
- Backend callbacks enter bounded inboxes and never mutate live ECS/account state directly.
- Respec takes an aggregate lease/revision and fences concurrent unlock/equipment changes.

### Fixed-step cost

- Bound evidence records, contributors, credits, threshold crossings, auto-unlocks, reward intents, and progression commits per tick.
- Expensive graph closure, migration, season rollover, community aggregation, and external reconciliation run outside the hot fixed step or under explicit command budgets.
- For a large post-match batch, stage and commit at a legal flow barrier without blocking the match simulation.
- Cap pathological multi-level jumps or process them as one range operation rather than emitting one heavy workflow per level.
- Telemetry counts batch size, crossed thresholds, grant fan-out, conflicts, retries, and fixed-step time.

### Serialization cost

- Persist stable track/node IDs, scope/season, values/ranks, point balances, claimed milestones, revisions, dedupe cursors/records, and definition provenance.
- Derived capabilities may be rebuilt from validated unlock state, but external/durable grants require ledgers and reconciliation IDs.
- Use sectioned versioned records for permanent, character/playthrough, mastery, season, and audit summaries.
- Compress/archive old seasons outside gameplay. Bound retained detailed evidence according to dispute/security policy.
- Do not serialize UI tree state or duplicate provider caches into authoritative save sections.

### Networking cost

- Replicate only relevant compact progression snapshots/deltas. Private permanent progression is owner-only; public rank/title may be separately projected.
- The client sends unlock/respec intent with stable IDs and expected revision, never authoritative points, XP, prerequisites, or rewards.
- Match gameplay may use a pinned projection of capabilities; permanent progression arriving mid-match activates only at declared boundaries.
- Post-match credit responses are idempotent and can include pending external reward status.
- Community/party totals are service projections, not broadcast every fixed tick.
- Rate-limit progression commands and cap payload lists; validate all referenced tracks/nodes.

## Pros and Cons

### Central progression aggregate

Pros:

- one invariant boundary for XP, levels, points, unlocks, and rewards;
- clear idempotency and audit;
- easy snapshot, migration, and respec validation;
- prevents feature systems from granting directly.

Cons:

- can become oversized if every mastery/faction/season shares one lock/revision;
- high contention for games with frequent independent tracks;
- requires deliberate aggregate partitioning.

### Independent track aggregates

Pros:

- parallel writes and smaller records;
- independent lifecycle/season/migration;
- lower conflict rates.

Cons:

- cross-track prerequisites and rewards need coordinated validation;
- respec/cross-scope operations may become workflows;
- snapshot consistency is harder.

### Declarative unlock graph

Pros:

- offline validation, visualization, migration, and dependency closure;
- deterministic prerequisites and respec;
- designer-friendly data and test generation.

Cons:

- complex bespoke rules need governed evaluators;
- graph changes can invalidate existing builds;
- dense graphs increase tooling and migration burden.

### Backend-authoritative permanent progression

Pros:

- stronger cheat resistance and cross-device continuity;
- central repair/audit and seasonal operation;
- fewer local-cache conflicts.

Cons:

- availability, latency, cost, privacy, and operational dependencies;
- offline play requires reconciliation policy;
- provider limits and semantics differ;
- service outage can delay durable confirmation.

## ECS Architectural Integration

Separate match-local simulation state from durable progression authority.

ECS may hold:

- a compact projection of relevant track values/levels;
- currently active capability/unlock generation;
- match-local contribution accumulators;
- pending credit/reward status;
- immutable handles to account/character progression snapshots.

Durable account/character progression lives in an aggregate/store appropriate to its lifetime, not on a disposable pawn. Match-local upgrades may be ordinary rollback state and can project into the same capability/tag interface without sharing persistence.

Gameplay systems emit committed semantic evidence. `ProgressionCreditSystem` applies the pinned policy and submits credit transactions. `ProgressionCommitSystem` publishes an immutable new revision. Capability projection adds/removes abilities, equipment permissions, recipes, or tags only at defined barriers and revalidates current equipment/actions.

Progression output may feed:

- ability/effect grant commands;
- inventory/equipment reward workflows;
- quest/content-gate facts;
- account/playthrough saves;
- platform achievement/stat projections;
- accessibility-aware presentation cues.

No consumer may treat a presentation level-up event as authority.

## Component, System, Resource, and Event Interfaces

### Components

- `ProgressionProjection { owner_id, snapshot_revision, capability_generation }`
- `ActiveTrackProjection { track_id, scope, value, level_or_rank, revision }`
- `UnlockProjection { graph_id, compact_rank_state_handle, revision }`
- `MatchContributionAccumulator { policy_id, bounded_contribution_spans }`
- `ProgressionPendingState { transaction_ids, durability_flags }`

### Resources

- `ProgressionTrackRegistry`
- `UnlockGraphRegistry`
- `CreditPolicyRegistry`
- `ProgressionAggregateStore`
- `ProgressionDedupeLedger`
- `RewardGrantOutbox`
- `ProgressionMigrationRegistry`
- `SeasonRegistry`
- `ProgressionAuditStore`
- `ProgressionBudgetPolicy`

### Systems

- `ProgressionEvidenceIngestSystem`
- `ContributionAggregationSystem`
- `ProgressionCreditPolicySystem`
- `ProgressionPlanSystem`
- `ProgressionCommitSystem`
- `UnlockRequestValidationSystem`
- `RespecPlanningSystem`
- `CapabilityProjectionSystem`
- `ProgressionOutboxRelaySystem`
- `ProgressionReconciliationSystem`
- `ProgressionRepairSystem`

### Events

- `ProgressionCredited`
- `TrackValueChanged`
- `LevelOrRankChanged`
- `UnlockGranted`
- `UnlockRemoved`
- `RespecCommitted`
- `MilestoneReached`
- `RewardGrantPending`
- `RewardGrantConfirmed`
- `ProgressionConflictDetected`
- `SeasonProgressionRolled`
- `ProgressionRepairApplied`

Every event carries stable transaction/evidence identity and post-commit revision.

## Integration Plan

1. Inventory every existing/planned XP, level, rank, mastery, reputation, skill point, unlock, challenge, season, and reward field or direct grant.
2. Define progression owner/reset scopes and aggregate boundaries; separate account, character/playthrough, match, and seasonal state.
3. Create immutable track, threshold, unlock-node, prerequisite, credit-policy, and reward definitions with stable IDs/revisions.
4. Compile and validate unlock graphs, prerequisite indexes, threshold tables, capability grants, and migration metadata.
5. Introduce committed `ProgressionEvidence` and bounded contribution records; prohibit direct feature writes.
6. Implement idempotent progression planning/commit with aggregate revision, dedupe ledger, threshold crossing, points, and reward outbox.
7. Add server-authoritative unlock and respec commands with expected revisions and complete prerequisite/dependency validation.
8. Project committed unlocks into abilities, equipment, recipes, content gates, and tags at legal barriers.
9. Connect sectioned saves/backend storage, transactional writes, optimistic concurrency, offline policy, and cross-device reconciliation.
10. Add seasonal scope/versioning, claim grace, archive, rollover, and migration.
11. Integrate platform stats/achievements as projections with provider-specific limits and repair/retry status.
12. Build progression inspector, graph visualizer, evidence/credit audit, repair tooling, and headless scenarios.

## Verification Strategy

- **Curve tests:** exact threshold boundaries, multi-level jumps, caps, overflow, negative values, prestige, decay, and migration.
- **Graph tests:** missing nodes, cycles, exclusion groups, ranks, any/all prerequisites, content ownership, unreachable nodes, and point sufficiency.
- **Credit tests:** direct, assist, support, party, shared objective, proximity, late join, disconnect, reconnect, forfeit, spectator, difficulty/mode, and anti-farming cases.
- **Idempotency:** duplicate/reorder/retry evidence, replay, reconnect, server recovery, outbox delivery, provider callbacks, and same-ID/different-payload attacks grant once.
- **Concurrency:** simultaneous credits, unlocks, respec, equipment changes, season rollover, profile writes, and two-device commands produce explicit conflicts or deterministic outcomes.
- **Respec:** remove every node/rank combination; verify dependent closure, active ability/equipment handling, refund limits, fees, exclusivity, and repeated-request safety.
- **Persistence:** save/load at every transition, offline progress, cloud conflict, corrupt/missing sections, removed definitions, and old-season migration.
- **Security:** forge XP, points, contributor lists, match completion, track IDs, node IDs, revisions, reward IDs, provider success, and administrative repair.
- **External failure:** backend timeout, throttling, partial provider outage, platform achievement failure, inventory/currency failure, lost response, unknown outcome, and compensation.
- **Season:** exact rollover boundary, delayed/offline login, claim grace, archived visibility, no cross-season ID collision, and old event arriving after rollover.
- **Capability projection:** unlock/lock/respec while abilities/equipment/actions are active; prove no illegal retained capability.
- **Performance:** large post-match batches, dense graphs, many tracks, community contributions, migration, audit retention, zero warm-tick allocation, and fixed-step budgets.
- **Privacy/accessibility:** export/delete applicable player data, restrict audit access, explain credit/reward status, and ensure level-up/unlock meaning is available through multimodal semantic cues.
- **Repair:** authorized correction is idempotent, audited, reversible/compensated where possible, and cannot bypass invariants.

## Risks and Open Decisions

- Account versus character/playthrough progression ownership.
- Aggregate partitioning and cross-track transaction boundaries.
- XP curves, caps, overflow, prestige, decay, and level-loss policy.
- Skill/unlock graph topology, ranks, exclusions, and point currencies.
- Unlock effects captured at grant time versus live from current definitions.
- Credit formulas for assists, support, objectives, party sharing, distance, presence, disconnects, and late joins.
- Accessibility/difficulty assist effects on rewards, achievements, matchmaking, and disclosure.
- Offline progression trust, local proof/evidence, caps, merge, and conflict UX.
- Client-hosted/listen-server progression authority and ranked restrictions.
- Respec dependent-closure handling, refund rounding, fees, cooldown, and active equipment/abilities.
- Permanent versus seasonal claims and rollover/claim-grace policy.
- Old season/event arrival and clock authority.
- Live curve/weight changes for existing accumulated values.
- Removed/merged unlock nodes and grandfathered builds.
- External platform/backend source of truth, rate limits, retries, and provider-specific merge behavior.
- Achievement/stat privacy, visibility, export/deletion, and retention.
- Fraud detection, anti-farming thresholds, false positives, and appeal.
- Administrative repair authorization, dual control, audit, compensation, and service objectives.
- Community/group aggregation ownership and historical backfill.
- Presentation of pending durability/external grants to players.

## Engineering Recommendations

The following are Operation Mythology engineering recommendations:

1. Create a dedicated progression domain; prohibit quests, combat, UI, scripts, platform callbacks, or items from directly modifying XP, levels, points, unlocks, or rewards.
2. Separate committed evidence, credit allocation, progression state, and reward effects.
3. Define every track's owner and reset scope explicitly. Keep account, character/playthrough, match, and seasonal progression distinct.
4. Store immutable versioned track/unlock definitions separately from runtime state. Pin definitions during matches and transactions.
5. Use stable idempotent credit identities derived from authoritative evidence, owner, track, and policy revision.
6. Make progression mutation, threshold crossing, point grants, auto-unlocks, reward intents, and audit publication one local atomic commit.
7. Route external inventory, currency, entitlement, achievement, and cross-title grants through durable outbox/workflow reconciliation.
8. Keep permanent progression server-writable or trusted-authority writable. Clients send intent/evidence references and may read projections; they never submit authoritative totals or grants.
9. Compile unlock graphs and reject invalid/cyclic/unreachable content before publication. Re-evaluate prerequisites and costs authoritatively on every unlock.
10. Implement respec as an idempotent dependency-closure transaction with explicit handling for active abilities/equipment and bounded refunds.
11. Version seasonal tracks by scope/season rather than destructively clearing permanent records. Preserve claim, archive, late-event, and migration policy.
12. Use optimistic revisions or single-writer ownership per progression aggregate and provide explicit multi-device/offline conflict UX.
13. Treat platform achievements/stats as projections of internal committed facts, not the source of live gameplay capabilities.
14. Keep durable progression on account/character lifetimes; project only relevant capabilities and match-local counters into ECS.
15. Ship a progression inspector showing evidence, credit policy, dedupe identity, before/after values, crossed thresholds, grants, revisions, outbox/provider status, and repair history.
16. Make curve/graph property tests, credit matrices, duplicate/reorder tests, concurrency, respec closure, season rollover, provider failure, migration, security, and repair tests release gates.

## Source Links

- Unity Technologies, [Cloud Code Server Authority](https://docs.unity.com/ugs/en-us/manual/cloud-code/manual/server-authority)
- Unity Technologies, [Control Access to Services](https://docs.unity.com/en-us/cloud-code/server-access-control)
- Unity Technologies, [Cloud Code Game State Management](https://docs.unity.com/en-us/cloud-code/game-state-management)
- Unity Technologies, [Cloud Code Cheat Prevention](https://docs.unity.com/ugs/en-us/manual/cloud-code/manual/cheat-prevention)
- Unity Technologies, [Economy Player Inventory and Write Locks](https://docs.unity.com/ugs/en-us/manual/economy/manual/SDK-player-inventory)
- Unity Technologies, [Economy Publication](https://docs.unity.com/ugs/manual/economy/manual/publication)
- Microsoft, [PlayFab Player Progression](https://learn.microsoft.com/en-us/gaming/playfab/player-progression/)
- Microsoft, [PlayFab Player Data](https://learn.microsoft.com/en-us/xbox/playfab/player-progression/player-data/)
- Microsoft, [PlayFab Transactional Statistics Writes](https://learn.microsoft.com/en-us/gaming/playfab/player-progression/statistics/transactional-writes)
- Microsoft, [PlayFab Seasonal Statistics](https://learn.microsoft.com/en-us/gaming/playfab/player-progression/statistics/seasonal-statistics)
- Microsoft, [PlayFab Community Statistics](https://learn.microsoft.com/en-us/gaming/playfab/player-progression/statistics/community-statistics)
- Valve, [Steamworks Stats and Achievements](https://partner.steamgames.com/doc/features/achievements?language=english)
- Epic Games, [Epic Online Services Achievements Reference](https://dev.epicgames.com/docs/game-services/achievements/achievements-reference)

