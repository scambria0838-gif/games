# Operation Mythology Mechanics Research — Input Abstraction, Rebinding, Device Switching, and Buffered Commands

**Timestamp:** 2026-07-27T02:31:55-07:00  
**Scope:** Local-user input ownership, semantic actions, contexts, binding profiles, device pairing and hot-swap, analog processing, prompt selection, fixed-tick sampling, input buffering, multiplayer command transport, accessibility, ECS integration, performance, and validation.

## Feature Overview

Operation Mythology needs one input architecture that supports first- and third-person play without coupling gameplay to keyboard keys, mouse buttons, controller layouts, or engine callbacks. The proposed path is:

`physical samples -> device/user routing -> binding resolution -> processors -> triggers -> semantic action samples -> fixed-tick command assembly -> bounded intent buffers -> gameplay consumption`

The stages serve different responsibilities:

- **Physical samples** preserve device identity, control identity, timestamps, values, and connection state.
- **Binding resolution** maps controls to stable semantic actions under an explicit local-user context stack.
- **Processors** normalize values, dead zones, curves, inversion, sensitivity, and coordinate conventions.
- **Triggers** interpret press, release, hold, tap, toggle, chord, repeat, and threshold policy.
- **Action samples** are local presentation/input facts such as `Move`, `Look`, `Jump`, `Interact`, `Pause`, or `Confirm`; they contain no pawn pointer.
- **Player commands** quantize the authoritative subset for a simulation tick and attach sequence, acknowledgement, and integrity metadata.
- **Intent buffers** retain eligible edges for a bounded number of ticks until a movement, interaction, or ability system consumes or rejects them.

This supports the same action vocabulary across first- and third-person modes. Perspective changes camera interpretation and presentation, not the player's physical binding profile or the authoritative meaning of `Move`, `Look`, `Jump`, `Interact`, and combat actions.

## Existing Coverage and Identified Gap

The mandatory recursive scan at the beginning of this batch found 13 files in `C:\Users\steve\Desktop\GAME SKILLS` and 12 files in the mechanics output folder, including the newly saved state-lifetime report and index. The GAME SKILLS tree added an open-world streaming report, but it does not supply an input architecture.

Existing mechanics work mentions action-based rebinding, accessibility alternatives, input-context push/pop during flow transitions, controller disconnect testing, input buffering during pause, ability grants linked to actions, and semantic input as a recommendation. No document owns:

- the physical-to-semantic transformation contract;
- binding and context conflict resolution;
- local-user/device pairing and hot-swap;
- rebinding persistence, migration, validation, and prompt glyphs;
- render-frame versus fixed-tick sampling;
- bounded press buffering, early-input windows, and consumption arbitration;
- command formation for prediction, reconciliation, replay, or deterministic tests;
- split-screen device isolation;
- allocation, cache, fixed-step, serialization, and network costs of the whole path.

This report fills that uncovered baseline subject. It does not replace the accessibility, flow, traversal, abilities, deterministic simulation, or state-lifetime reports; it defines the shared input-facing interface those systems consume.

## Sourced Facts

The following are sourced facts, not project recommendations:

- Epic's Enhanced Input documentation defines Input Actions, Input Mapping Contexts, Input Modifiers, and Input Triggers. Contexts are applied per local player, can be dynamically added or removed, and use priority to resolve collisions. Epic describes separate contexts for walking, swimming, and vehicles and recommends mutually exclusive contexts where collisions would otherwise activate the wrong action.
- Epic documents modifiers as ordered preprocessing of raw values and triggers as activation conditions such as press, release, tap, hold, or chord. Its user-settings API stores player-changeable mappings, sensitivity, and accessibility-related input settings per user/local player, supports mapping profiles, and can save settings asynchronously.
- Unity's Input System models Actions, Action Maps, Bindings, Control Schemes, processors, and interactions. Unity states that enabling an Action Map in bulk is more efficient than enabling actions individually, and that input updates may occur per dynamic frame, fixed update, or manually.
- Unity binding overrides are non-destructive relative to authored bindings. Bindings have stable IDs that can identify overrides in user settings. Unity's interactive rebinding operation must be disposed because it owns unmanaged resources.
- Unity exposes device added, removed, disconnected, reconnected, reset, and configuration-change notifications. `InputUser` pairs devices to a player, applies control schemes through binding masks, retains knowledge of a disconnected paired device, and can automatically re-pair it when it returns.
- Unity's Player Input documentation supports multiple local players with distinct device assignment and notes that devices can also be deliberately shared for designs such as split keyboard or hot-seat play.
- Godot's stable documentation recommends named input actions rather than hard-coded keyboard/controller branches. It documents per-action dead zones, analog vector helpers, one-frame `just_pressed` edges, controller hotplug considerations, and device/platform differences such as keyboard repeat not being supplied for controller buttons.
- Valve's Steam Input documentation exposes action sets and narrower action-set layers. Valve advises applying layers on game-state changes; repeatedly changing multiple layers can create ordering conflicts, and the last conflicting layer wins.
- Microsoft's Xbox Accessibility Guideline 107 recommends remapping game actions rather than only physical controls, full in-game remapping for supported methods, independent axis inversion and sensitivity, single-input alternatives to chords, and toggle/automatic alternatives to sustained holds. Microsoft's Accessibility Feature Tags distinguish full remapping from limited presets or button swaps.

These sources establish common engine and platform capabilities. They do not dictate Operation Mythology's buffering duration, conflict policy, networking format, accessibility defaults, or authoritative command semantics.

## Industry-Standard API or Pattern

Use a semantic-action pipeline with explicit ownership and phase boundaries.

### Stable action catalog

Each action has a stable namespaced ID and metadata:

- value type: digital, scalar, 2D, or 3D;
- domain: gameplay, UI, spectator, photo/debug, or system-reserved;
- authoritative relevance: local-only, command-bearing, or mixed;
- activation policies allowed: press, release, hold, toggle, repeat, chord, sequence;
- buffer class and default window;
- simultaneous-action and consumption policy;
- supported device/control classes;
- accessibility alternatives;
- localization key and prompt concept.

Gameplay consumes action IDs and normalized values, never physical control paths. Renaming display text does not change identity.

### Context resolution

Contexts are immutable definitions. A local-user resource holds active context instances with source, priority band, generation, and exclusivity group. Examples are `Frontend`, `Gameplay.Common`, `Gameplay.OnFoot`, `Gameplay.Swimming`, `Gameplay.Vehicle`, `Gameplay.Traversal`, `UI.Modal`, and `Spectator`.

State changes submit context transactions. Resolution occurs once at a safe boundary, producing an immutable compiled table. Equal-priority collisions are content-validation errors unless an explicit fan-out or arbitration rule exists. Modal UI can suppress gameplay command production without destroying held-state knowledge.

### Binding profiles

An authored default profile is overlaid by a versioned per-local-user override set keyed by stable action ID, binding slot, device layout family, and profile ID. Store control paths/capabilities, not transient device instance numbers. A profile may contain primary and alternate bindings, analog settings, inversion, trigger thresholds, hold/toggle preferences, and chord alternatives.

Rebinding is a transaction:

`begin capture -> filter eligible controls -> receive candidate -> normalize -> detect reserved/conflicting use -> preview resolution -> accept/swap/unbind/cancel -> validate required coverage -> commit revision -> rebuild compiled table -> update prompts -> save asynchronously`

Never strand the user: preserve cancel/confirm/navigation controls during capture, provide reset-by-action/context/profile, and retain a known-safe fallback profile if migration fails.

### Device ownership and switching

Separate three concepts:

- `DeviceInstance`: ephemeral connected hardware;
- `LocalUser`: durable signed-in or guest user;
- `InputSeat`: the local routing/pairing role used by a player slot.

Explicit pairing is authoritative for split-screen. In single-player, unpaired-device activity may propose switching the active prompt family after hysteresis, but it must not silently steal another local player's device. Device loss changes the seat state and generates a flow event; it does not zero gameplay state by destroying the local user.

Prompt selection follows the most recently meaningful active device family, not noisy stick drift. Use magnitude and time thresholds, ignore synthetic/virtual events where appropriate, and debounce prompt-family changes.

### Sampling and command formation

Capture physical events at the engine/platform cadence into a bounded local ring. Resolve actions for presentation as often as required, but sample command-bearing actions at the authoritative fixed-tick boundary. Each command frame contains:

- participant/input-seat identity;
- simulation tick and monotonically increasing command sequence;
- quantized move/look/aim values;
- digital held bits and edge bits;
- optional action parameters selected from a fixed schema;
- active context/configuration revision where useful for diagnostics;
- acknowledgement/hash fields required by the networking design.

Continuous values use latest-sample or explicitly configured integration over the tick interval. Digital transitions preserve every relevant edge within the interval. A press and release that both occur between simulation ticks must not disappear.

### Bounded intent buffering

Do not implement buffering as one mutable `jumpPressedRecently` flag. Append eligible semantic edges to a fixed-capacity per-owner queue:

`{ action_id, press_tick, expiry_tick, sequence, value, source_context_generation, consumption_policy }`

Gameplay systems publish offers or gates, then consume at a deterministic phase. Examples include jump shortly before landing, mantle shortly before a valid ledge, interaction during a short readiness transition, or an ability pressed just before cooldown expiry.

Consumption policy is action-specific:

- first eligible consumer wins;
- named subsystem owns consumption;
- broadcast without consumption;
- consume on accepted command only;
- retain through a state transition;
- clear on pause, death, possession, focus loss, or context generation change.

Early-input windows and grace windows are data, expressed in simulation ticks. Record the reason for consume, reject, expire, or flush.

## Performance Considerations

- **Asymptotic complexity:** Physical event ingestion is `O(e)` for `e` events. With a precompiled direct lookup from `(device layout/control, active context revision)` to bindings, resolution is `O(e + a_changed)` rather than scanning every action. Context rebuild is `O(b log b)` if bindings are priority-sorted, or `O(b + p)` with bounded priority buckets, for `b` active bindings and `p` priority bands. Per-tick command assembly is `O(c)` for the fixed command field count. Buffer insertion is amortized `O(1)` in a ring; bounded action-specific consumption is `O(k)` for at most `k` buffered intents, with a strict cap.
- **Allocations and garbage collection:** Preallocate device event rings, resolved-action state, command history, rebind candidates, and intent buffers. Use stable numeric IDs, bitsets, small fixed vectors, and pooled diagnostic strings. Context changes and profile commits may allocate off the hot path; ordinary sampling and fixed-tick assembly should allocate zero. Dispose engine rebinding operations and unsubscribe callbacks when their owner ends.
- **Cache behavior:** Store hot action values, edge bits, timestamps/ticks, and command fields in dense per-seat arrays ordered by action index. Keep localized names, glyph assets, binding descriptions, device metadata, and authoring graphs cold. Compile sparse authored bindings into flat lookup tables; do not chase asset objects during a simulation tick.
- **Update frequency:** Device ingestion follows platform events. Presentation actions may update per render frame. Command-bearing actions sample once per fixed tick. Prompt-family selection updates only on meaningful-device activity. Context resolution runs on context/profile/device-layout revision, not every frame. Rebinding capture is temporary. Buffer expiry and consumption run at one defined fixed phase, not in every potential consumer.
- **Concurrency:** Platform callbacks write to a single-producer ring or thread-safe inbox. One local-input phase owns binding/action mutation. Workers may read the immutable published action snapshot and command frame. Profile/context rebuild happens in staging storage and atomically publishes a revision. Gameplay consumers must not race to remove buffered intents; schedule deterministic ownership or submit consume proposals resolved at a barrier.
- **Fixed-step cost:** Cap physical events drained per seat/tick, commands processed per connection/tick, buffered intents per action/owner, and trigger state machines. Preserve overload evidence and apply a declared coalescing policy for analog samples; never discard digital edges silently. Input work should be a small, measured portion of the simulation budget and independent of render-frame count.
- **Serialization cost:** Persist only versioned user overrides and preferences, not transient device handles, held states, active rebinding captures, context stacks, or buffered presses. Load cost is `O(overrides)` plus validation and table compilation. Save asynchronously from an immutable profile snapshot, coalesce rapid settings edits, use an atomic replacement strategy, and retain migration/reset diagnostics.
- **Networking cost:** Send compact command frames, usually unreliable-sequenced with redundancy or acknowledgement appropriate to the prediction design. Cost is `O(players × command_rate × command_bytes)`. Quantize axes, delta/bit-pack held state, and carry edge counters or sequences so repeated presses are distinguishable. Never transmit raw key names, accessibility profile details, device model, or local UI actions unless an explicit feature requires it. The server validates command cadence, legal action vocabulary, context-independent gameplay constraints, and sequence windows; it never trusts a client binding or trigger result as gameplay authority.

## Pros and Cons

### Pros

- Gameplay, AI, replay, tests, and accessibility automation share one semantic command vocabulary.
- Rebinding and device support do not force changes in movement, abilities, interactions, or quests.
- Fixed-tick command frames align input with prediction, reconciliation, rollback, replay, and desync traces.
- Explicit contexts and revisions make modal UI, vehicles, swimming, traversal, spectating, and perspective changes inspectable.
- Bounded intent buffers improve responsiveness without making acceptance nondeterministic.
- Per-local-user profiles and explicit seats support split-screen, guests, reconnects, and accessibility preferences.
- Dense compiled tables and rings keep the hot path predictable and allocation-free.

### Cons

- The project must govern action IDs, context priorities, binding slots, conflict rules, and migration indefinitely.
- Debugging has more stages than direct key callbacks, so tooling must expose where an action was filtered or consumed.
- Device families differ in sampling, dead zones, glyph availability, touch/gyro behavior, and platform restrictions.
- Input buffering can feel unfair or cause unintended actions when windows or flush rules are too permissive.
- Rebinding UI, localization, glyph selection, accessibility alternatives, and safe recovery are significant product work.
- Deterministic command formation requires disciplined ordering and quantization across client builds.

## ECS Architectural Integration

Physical devices and local users are not authoritative world entities. Keep platform/engine objects behind a local input adapter. ECS receives compact resources and local-seat entities:

- local-user/profile resources live across worlds;
- input-seat entities live across pawn possession and may outlive a match;
- pawn/avatar entities receive command projections through participant ownership;
- simulation systems read command frames and intent buffers, not OS events;
- UI reads an immutable action/prompt snapshot and writes context/rebind commands;
- network code serializes the command-bearing projection only;
- replay/test adapters can replace physical ingestion while preserving the same downstream path.

Schedule:

1. drain device events;
2. update pairing/focus/device state;
3. apply pending context/profile transactions;
4. resolve processors and triggers;
5. publish local action/prompt snapshot;
6. at fixed boundary, assemble command frame and append eligible intent edges;
7. run authoritative/predicted gameplay consumers in declared order;
8. resolve consumption and emit diagnostics;
9. serialize/store command history and network payload.

This keeps render/presentation input responsive while preserving a single deterministic fixed-tick entrance to gameplay.

## Component, System, Resource, and Event Interfaces

Conceptual interfaces follow; names are architectural contracts, not production code.

### Components

- `InputSeatIdentity { seat_id, local_user_id, participant_id, generation }`
- `SeatDevicePairing { device_instances[], control_scheme_id, pairing_revision, status }`
- `ResolvedActionState { action_bitset, values[], pressed_edges, released_edges, sample_time, revision }`
- `CommandCursor { next_sequence, last_assembled_tick, last_acknowledged_sequence }`
- `IntentBuffer { fixed_slots[], head, count, dropped_count }`
- `InputContextInstance { context_id, source_id, priority_band, generation, flags }`

### Resources

- `ActionCatalog`: immutable stable IDs, types, policies, localization keys, and network fields.
- `BindingDefinitionCatalog`: authored defaults and supported device/control capabilities.
- `LocalInputProfiles`: versioned per-user overrides, settings, migration state, and save revision.
- `DeviceRegistry`: ephemeral devices, layouts, capabilities, connection/configuration state.
- `CompiledBindingTables`: immutable published tables per seat/profile/context revision.
- `InputClockBridge`: monotonic event timestamps and fixed-tick interval mapping.
- `InputBudgets`: event, binding, buffer, command-history, and diagnostic limits.

### Systems

- `DeviceEventIngestSystem`
- `LocalUserPairingSystem`
- `InputContextTransactionSystem`
- `BindingCompileAndValidationSystem`
- `ActionResolutionSystem`
- `PromptFamilySelectionSystem`
- `FixedTickCommandAssemblySystem`
- `IntentBufferSystem`
- `IntentConsumptionArbitrationSystem`
- `InputProfilePersistenceSystem`
- `InputCommandTransportSystem`
- `InputDiagnosticsAndTelemetrySystem`

### Events and commands

- `DeviceAdded/Disconnected/Reconnected/Removed/ConfigurationChanged`
- `PairDeviceRequest`, `PairingChanged`, `SeatDeviceLost`
- `Push/Pop/ReplaceInputContext { seat, context, source, generation }`
- `Begin/Cancel/CommitRebind { user, profile, action, slot, candidate, expected_revision }`
- `BindingConflictDetected`, `ProfileMigrated`, `ProfileFallbackApplied`
- `ActivePromptFamilyChanged { seat, family, reason }`
- `ActionEdgeObserved { seat, action, edge, tick_interval, sequence }`
- `PlayerCommandAssembled { participant, tick, sequence, payload_hash }`
- `IntentQueued/Consumed/Rejected/Expired/Flushed { owner, action, sequence, reason }`
- `InputOverrunDetected { seat, queue, dropped_or_coalesced, revision }`

## Integration Plan

1. Freeze a stable action catalog for frontend, gameplay-common, on-foot, swimming, traversal, interaction, inventory/equipment, abilities, spectator, and system actions. Assign types, authority class, localization keys, and accessibility requirements.
2. Define local-user, input-seat, participant, and pawn ownership using the state-lifetime report. Ensure possession and perspective changes rebind projections without recreating the user's profile.
3. Build the engine adapter and bounded physical-event ring. Preserve timestamps, device identity, digital edges, analog values, focus, and connection changes.
4. Define immutable contexts and a deterministic priority/exclusivity policy. Add content validation for equal-priority conflicts, missing required actions, illegal chords, and unreachable cancel/confirm paths.
5. Compile authored bindings plus per-user overrides into flat per-seat tables. Publish only after complete validation and retain the last known-good revision.
6. Implement transactional rebinding design, conflict choices, reset paths, prompt/glyph lookup, async persistence, schema migration, and corrupt-profile fallback.
7. Add per-seat pairing and device-loss flow, including single-player automatic prompt switching, split-screen isolation, reconnect grace, shared-keyboard policy, and synthetic/assistive devices.
8. Define processor order and numeric conventions for mouse, sticks, triggers, gyro, touch, and digital-to-vector composites. Separate presentation sensitivity from authoritative quantization where necessary.
9. Assemble tick-indexed command frames with edge preservation and bounded history. Connect them to existing prediction, reconciliation, replay, deterministic test, and desync-hash infrastructure.
10. Add data-driven intent-buffer classes and deterministic consumption. Start with jump-before-grounding, coyote/grace policy, interact-before-ready, and ability-before-cooldown; require explicit flush rules at pause, death, travel, possession, focus loss, and context changes.
11. Add input inspection, recording, injection, and telemetry with privacy filters. Expose each transformation stage and all buffer outcomes.
12. Roll out feature by feature; forbid new gameplay code from reading physical controls after its semantic action is registered.

## Verification Strategy

- Catalog validation: stable IDs, unique localization keys, supported value types, required actions, legal authority classes, buffer rules, and network schema coverage.
- Binding validation: every supported device family can reach engagement, settings, play, pause, and exit; no required action becomes unreachable after rebind; cancel remains available during capture.
- Conflict property tests: randomized context stacks and overrides always produce the same resolution for the same ordered transaction history; declared exclusive contexts never fan out accidentally.
- Edge tests: press/release within one render frame, both between fixed ticks, multiple presses within one tick, long hold, focus loss while held, disconnect while held, reconnect, device reset, and timestamp reordering.
- Analog tests: radial and axial dead zones, drift, saturation, inversion, sensitivity extremes, mouse delta, high polling rate, digital composites, gyro/touch where supported, and quantization boundaries.
- Buffer tests: before/inside/after acceptance windows, equal-tick ordering, multiple eligible consumers, state transition, death, pause, travel, possession, rollback/resimulation, expiry, capacity pressure, and rejected-command behavior.
- Multiplayer tests: packet loss, duplication, reordering, variable render rates, client tick drift, command bursts, duplicate edge counters, malicious cadence, stale contexts, and reconnect. Authoritative outcomes must depend on legal commands and world state, not client device details.
- Split-screen tests: device stealing, join/leave, guest/profile swap, shared keyboard policy, two identical controllers, disconnect/reconnect, independent prompts, and independent rebinding.
- Persistence tests: schema migration, removed/renamed actions, changed device layouts, duplicate overrides, corrupt/truncated files, disk failure, rapid edits, cloud conflict policy, and safe-default recovery.
- Accessibility tests: full remapping, stick swap, independent inversion/sensitivity, keyboard-only navigation where supported, single-input chord alternatives, hold/toggle/auto alternatives, custom/assistive controllers, and readable prompt updates.
- Performance tests: worst-case high-polling mouse plus controllers, context rebuild spikes, rebind enumeration, split-screen seats, event-ring saturation, zero-allocation fixed ticks, cache misses, and command bandwidth.
- Deterministic replay tests: recorded semantic command frames reproduce authoritative results independently of physical device, render rate, or active prompt glyph family.

## Risks and Open Decisions

- Final action taxonomy, namespacing authority, deprecation, and mod/plugin extension policy.
- Whether UI and gameplay share action IDs or use an explicit navigation translation layer.
- Context priority bands, tie handling, modal suppression, held-state behavior, and transaction boundary.
- Per-action press/release/hold/toggle/chord/repeat semantics and accessibility overrides.
- Binding conflict choices: reject, swap, duplicate, unbind previous, or context-qualified coexistence.
- Required unbindable platform/system controls and platform certification constraints.
- Profile scope: device family, local user, account cloud, machine, character, or playthrough.
- Split-screen device pairing, shared keyboard, guest profiles, device stealing, and prompt ownership.
- Device-family detection thresholds, noisy analog suppression, and mouse/controller hybrid play.
- Processor order, dead-zone model, response curves, sensitivity units, gyro/touch support, and FP/TP parity.
- Render-to-fixed sampling rule for analog input and edge ordering within a tick.
- Command quantization, redundancy, sequence/acknowledgement format, rate limits, and compatibility version.
- Buffer windows for jump, traversal, interaction, abilities, and UI; whether settings are fixed, difficulty-scaled, or user-adjustable.
- Consumption arbitration when one press could jump, mantle, vault, interact, or activate an ability.
- Flush/retain rules across pause, death, respawn, possession, travel, save/load, focus loss, and rollback.
- Whether buffered intent is serialized in a save; default recommendation is no except for explicitly resumable deterministic scenarios.
- Input recording privacy, retention, anti-cheat access, and whether device identity leaves the local machine.
- Text input, IME, OS accessibility features, virtual controls, remote play, and assistive-device qualification.
- Glyph licensing, platform-specific prompt policy, unknown-device fallback, localization, and simultaneous-device prompts.

## Engineering Recommendations

The following are Operation Mythology engineering recommendations, not claims made directly by the sources:

1. Adopt the physical sample → semantic action → fixed-tick command → gameplay-consumption pipeline as the only gameplay input path.
2. Keep input profiles on local-user lifetime, device pairing on input-seat lifetime, and commands on participant lifetime. Never store durable bindings on a pawn.
3. Use stable namespaced action IDs and binding-slot IDs. Persist versioned overrides against those IDs, never array positions or transient device numbers.
4. Compile contexts and overrides into immutable flat tables; apply context/profile changes transactionally and publish a revision at a safe boundary.
5. Make conflict resolution explicit and validate it offline. Equal-priority ambiguity must not depend on subscription order, asset load order, or frame timing.
6. Preserve digital edges when bridging render/platform sampling to fixed ticks. A fast press-release must produce a command-visible edge even if no fixed update occurred between them.
7. Use fixed-capacity, tick-indexed intent queues with action-specific expiry, consume, and flush policies. Log every terminal disposition.
8. Let server gameplay validate semantic commands against authoritative state. Do not send raw keys or treat a client-reported context, hold duration, or binding as authority.
9. Pair devices explicitly for split-screen. Limit automatic device switching to unambiguous single-user cases and prompt presentation; debounce changes against analog drift.
10. Provide complete in-game action remapping, alternate activation policies, stick swap, inversion, sensitivity, and safe recovery. Rebinding is a core accessibility and persistence feature, not an optional debug menu.
11. Treat prompt glyphs as a projection of current bindings and meaningful device family. UI must query the binding service rather than hard-code button art.
12. Make the hot path allocation-free and bounded. Rebuild on revisions, sample command-bearing state once per fixed tick, and expose queue overruns rather than hiding loss.
13. Record semantic command frames for replay and tests. Raw device capture is a separate diagnostic mode with tighter privacy and retention controls.
14. Ship an input debugger that shows device → binding → modifier → trigger → action → command → buffer → consumer, including revisions and rejection reasons.

## Source Links

- [Epic Games — Enhanced Input in Unreal Engine 5.8](https://dev.epicgames.com/documentation/en-us/unreal-engine/enhanced-input-in-unreal-engine)
- [Epic Games — Input Overview in Unreal Engine](https://dev.epicgames.com/documentation/unreal-engine/input-overview-in-unreal-engine)
- [Epic Games — Enhanced Input API](https://dev.epicgames.com/documentation/en-us/unreal-engine/API/Plugins/EnhancedInput)
- [Epic Games — UEnhancedInputUserSettings](https://dev.epicgames.com/documentation/unreal-engine/API/Plugins/EnhancedInput/UEnhancedInputUserSettings)
- [Epic Games — Map Player Key](https://dev.epicgames.com/documentation/en-us/unreal-engine/BlueprintAPI/EnhancedInput/UserSettings/MapPlayerKey)
- [Unity — Input System 1.14](https://docs.unity.cn/Packages/com.unity.inputsystem%401.14/manual/index.html)
- [Unity — Actions](https://docs.unity.cn/Packages/com.unity.inputsystem%401.4/manual/Actions.html)
- [Unity — Input Bindings and Runtime Rebinding](https://docs.unity.cn/Packages/com.unity.inputsystem%401.0/manual/ActionBindings.html)
- [Unity — Devices](https://docs.unity.cn/Packages/com.unity.inputsystem%401.10/manual/Devices.html)
- [Unity — User Management and Device Pairing](https://docs.unity.cn/Packages/com.unity.inputsystem%401.4/manual/UserManagement.html)
- [Unity — Player Input](https://docs.unity.cn/Packages/com.unity.inputsystem%401.15/manual/PlayerInput.html)
- [Godot Engine — InputMap](https://docs.godotengine.org/en/stable/classes/class_inputmap.html)
- [Godot Engine — Controllers, Gamepads, and Joysticks](https://docs.godotengine.org/en/stable/tutorials/inputs/controllers_gamepads_joysticks.html)
- [Valve Steamworks — Steam Input](https://partner.steamgames.com/doc/features/steam_controller)
- [Valve Steamworks — Action Set Layers](https://partner.steamgames.com/doc/features/steam_controller/action_set_layers)
- [Microsoft — Xbox Accessibility Guideline 107: Input](https://learn.microsoft.com/en-us/xbox/accessibility/xbox-accessibility-guidelines/107)
- [Microsoft — Accessibility Feature Tags](https://learn.microsoft.com/en-us/xbox/accessibility/accessibility-feature-tags)
