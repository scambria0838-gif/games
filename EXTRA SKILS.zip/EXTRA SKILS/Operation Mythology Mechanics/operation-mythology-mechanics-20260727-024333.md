# Operation Mythology Mechanics Delta Research — Gameplay Transactions, Idempotent Commands, Outbox, and Compensation

**Timestamp:** 2026-07-27T02:43:33-07:00  
**Scope:** Local atomic gameplay commits, distributed workflows, request identity, retries, deduplication, optimistic revisions, transactional outbox, sagas, compensation, irreversible pivots, unknown outcomes, external services, recovery, ECS interfaces, performance, and verification.

## Feature Overview

Operation Mythology needs one failure contract for actions that cross inventory, equipment, abilities, quests, rewards, checkpoints, cloud state, online services, and analytics. A network timeout or process crash cannot reveal whether a mutation succeeded. Blind retries can duplicate items, rewards, costs, quest progress, or purchases; refusing to retry can lose valid actions.

Use three transaction scopes:

1. **Local simulation transaction:** all authoritative ECS changes owned by one world commit atomically at a fixed-tick barrier.
2. **Durable single-owner transaction:** one persistence owner commits state, its idempotency result, and an outbox record atomically.
3. **Cross-owner workflow:** an explicit durable state machine coordinates multiple local transactions, prefers forward recovery, and invokes domain-specific compensation when required.

Every mutating request has stable identity, expected revisions, declared owner, retry policy, result retention, and terminal outcome. Events describe committed facts; commands request work. Presentation cues are derived from committed/predicted event identities and never stand in for transaction state.

## Existing Coverage and Identified Gap

The mandatory recursive scan at the beginning of this batch found 14 files in `C:\Users\steve\Desktop\GAME SKILLS` and 14 files in the dedicated mechanics archive. Both paths were readable. Existing reports already recommend:

- revision-checked idempotent inventory transfers;
- atomic quest completion and reward commits;
- ability cost/damage/cooldown commit points;
- transactional save publication and cloud conflict detection;
- versioned state-transfer manifests;
- command/event ordering and side-effect journals;
- authority epochs and idempotent external ledgers during server recovery.

Those reports define domain mutations but not a shared failure protocol. Unresolved questions remain when an operation crosses owners: whether a timed-out request committed, how dedupe results survive restart, how state and notification avoid dual-write loss, how compensation differs from rollback, where irreversible steps occur, and who repairs an unknown or partially compensated outcome.

This report fills that coordination gap without replacing domain-specific invariants.

## Sourced Facts

The following are sourced facts, not project recommendations:

- AWS's Builders' Library describes idempotent APIs as a way for callers to retry a request while ensuring the intended effect occurs once. It emphasizes caller-provided request identity rather than guessing that two similar requests mean the same intent.
- AWS Prescriptive Guidance identifies the dual-write failure: committing state and publishing a message as separate operations can produce either committed state without notification or notification without committed state.
- AWS's transactional-outbox guidance stores the state mutation and outbox message in the same local transaction. Relay delivery can still be duplicated, so consumers must be idempotent and ordering must be explicit.
- Microsoft's Azure Architecture Center states that compensating transactions are domain-specific, can themselves fail, must record progress for resumption, and do not necessarily restore the exact original state because concurrent work may have occurred.
- Microsoft's guidance distinguishes transient retries from compensation, recommends identifying irreversible points of no return, and notes that compensation steps may execute in a different order or in parallel when domain rules allow.
- The original 1987 Sagas paper defines a long-lived transaction as a sequence of transactions with compensating transactions used to amend partial execution.
- Unity Cloud Save write locks implement optimistic concurrency: a stale write lock produces a conflict rather than silently overwriting newer state.
- Epic's Gameplay Ability System separates activation checks from commitment of ability cost and cooldown; this supports a gameplay-facing distinction between proposal/validation and committed resource effects.

These facts establish general mechanisms. They do not determine which Operation Mythology actions are atomic, compensable, irreversible, or safe to retry.

## Industry-Standard API or Pattern

### Command envelope

Every authoritative mutation enters through a typed envelope:

`{ command_id, workflow_id?, caller, authority_epoch, owner, operation, expected_revisions, payload, issued_tick, expiry, schema_version }`

`command_id` represents one player/system intent and is reused for retries. A new intentional repetition receives a new ID even if the payload is identical. The owner validates authentication, authority epoch, expiry, schema, rate, preconditions, and expected revisions.

Terminal results are:

- `Committed { result_revision, result_digest, committed_tick }`
- `Rejected { stable_reason, observed_revisions }`
- `Expired`
- `CancelledBeforeCommit`
- `InProgress { workflow_revision }`
- `Unknown { recovery_locator }`

Timeout is not a transaction outcome. The caller queries or retries with the same command ID.

### Local prepare/commit

For one authoritative ECS world:

`receive -> validate -> reserve bounded resources -> build mutation set -> validate invariants -> commit at barrier -> write result/dedupe record -> publish committed events`

All component and structural changes for the local operation commit together. Validation reads one consistent snapshot. Systems do not publish irreversible cues or external messages during prepare.

### Idempotency ledger

The owner records:

`command_id -> payload_digest, caller, status, result/rejection, owner_revision, retention_expiry`

If the same ID and digest return, reply with the stored semantic result. If the ID is reused with a different digest or caller, reject it as misuse. `InProgress` records carry a lease/generation so recovery can resume or safely take ownership.

Retention must cover the maximum retry, reconnect, replay, and recovery horizon. High-value operations may retain compact terminal records much longer than transient movement commands.

### Transactional outbox and inbox

When a local commit must notify another owner, atomically record:

- authoritative state changes;
- idempotency result;
- ordered outbox entries with stable event IDs and source revisions.

A relay publishes committed outbox entries at least once. Consumers maintain an inbox/dedupe cursor and apply each event idempotently. Delivery acknowledgement removes or compacts the outbox only under retention/audit policy. Per-aggregate sequence numbers preserve required order; unrelated aggregates need not serialize globally.

### Cross-owner workflow

Use a durable orchestrator when a user-visible operation spans independent owners, for example:

- trade between players plus inventory ownership;
- quest completion plus external reward/achievement;
- match reward plus account progression/cloud save;
- platform purchase entitlement plus in-game grant;
- server recovery plus reconciliation of external commits.

Each step is a local transaction with its own idempotency key derived from workflow and step identity. Workflow state records step status, attempts, deadlines, outputs, compensation state, and audit correlation.

Classify steps:

- **read/validate:** no durable mutation;
- **compensable:** has a defined semantic counter-action;
- **pivot:** irreversible point after which forward completion is required;
- **retryable:** safe to repeat after the pivot;
- **manual/exception:** cannot be repaired automatically with sufficient confidence.

Place the pivot only after critical validation and reservations. Prefer completing forward over compensating when safe.

### Compensation

Compensation is a new business operation, not time travel. It has its own command ID, authorization, invariants, revisions, retries, events, and audit. Examples:

- release an item reservation, not restore an old container snapshot;
- issue a balancing debit/credit, not overwrite a concurrently changed balance;
- revoke or replace an entitlement only if platform rules permit;
- mark a quest reward pending/manual rather than reverse completed narrative state.

If compensation fails, persist `CompensationPending` and retry with bounded backoff or route to an operator/admin repair path. Never claim rollback when only eventual compensation is possible.

### Unknown-outcome recovery

After crash or timeout:

1. query local idempotency result;
2. inspect workflow/step state;
3. reconcile outbox delivery and consumer inbox;
4. query external provider using the provider's operation key;
5. resume forward or compensation;
6. if evidence conflicts or is insufficient, quarantine the affected operation/resources and surface a repair case.

Do not infer success from a presentation cue, client inventory view, or absence of an error.

## Performance Considerations

- **Asymptotic complexity:** Dedupe lookup is expected `O(1)` by command ID. Revision validation is `O(r)` for touched records; local mutation commit is `O(m)` for `m` changes. Outbox relay is `O(e)` in pending entries. Workflow advancement is `O(ready steps)`; deadline management is `O(log w)` with a heap or amortized `O(1)` with a timing wheel. Avoid global scans.
- **Allocations and garbage collection:** Use fixed command/result slabs, pooled mutation buffers, compact IDs, and bounded per-owner ledgers. Warm local commits allocate zero general heap memory. Durable workflow/outbox serialization uses pooled pages off the fixed-step path. Diagnostic text is cold and sampled.
- **Cache behavior:** Keep command ID, owner, status, revision, expiry, and result digest in dense hash/table storage. Domain mutation sets are sorted by archetype/container/aggregate before commit. Payload blobs, audit detail, external responses, and compensation history remain cold.
- **Update frequency:** Local commands process at fixed barriers. Outbox relay, retries, compensation, and external reconciliation run asynchronously at bounded service cadence. UI polls no workflow; it observes immutable status changes. Deadline services wake only due work.
- **Concurrency:** Each aggregate/owner has one commit authority or deterministic conflict rule. Workers may prepare against immutable snapshots, but commit validates revisions again. Workflow leases use generation fencing. Outbox relay never mutates live ECS; completions enter a bounded inbox and commit at a barrier.
- **Fixed-step cost:** Cap commands, touched records, structural changes, and transaction bytes per tick. Large sorts, serialization, external calls, compression, and retry scheduling stay outside the fixed step. Critical gameplay transactions have reserved budget; bulk inventory/UI work can queue.
- **Serialization cost:** Durable records include compact command/workflow/step state, revisions, result digests, outbox events, and compensation progress. Cost is `O(changed workflow state + emitted events)`. Snapshot/compact terminal ledgers by retention class while preserving high-value audit and retry horizons.
- **Networking cost:** Clients send compact commands and receive semantic results/deltas. Retries reuse IDs and should be suppressed by acknowledgement/status queries. Server-to-service workflows add outbox/event traffic and provider queries. Backoff, jitter, circuit breaking, admission limits, and per-domain retry budgets prevent retry storms. Never replicate internal compensation/audit details to unauthorized clients.

## Pros and Cons

### Pros

- Safe retries across packet loss, disconnects, crashes, and server recovery.
- Clear atomic boundary for local ECS mutations.
- State changes and committed events cannot diverge through a naive dual write.
- Durable workflows make partial failure inspectable and resumable.
- Domain-specific compensation preserves concurrent legitimate work.
- Stable IDs correlate gameplay, networking, persistence, telemetry, and support cases.

### Cons

- Ledgers, outboxes, workflow state, retention, migrations, and repair tooling add storage and operational complexity.
- Compensation cannot always restore the original experience.
- Long workflows expose temporary intermediate states.
- Incorrect idempotency scope can suppress a legitimate repeat or allow a duplicate.
- Ordering and concurrency rules must be defined per aggregate.
- Manual resolution remains necessary for ambiguous external outcomes.

## ECS Architectural Integration

The authoritative ECS owns local gameplay commits. External workflows and durable ledgers live in persistence/service resources, projected into ECS by stable handles.

- Commands enter bounded queues and are assigned to one owning domain.
- Prepare systems build immutable mutation proposals.
- A transaction coordinator validates revisions/invariants and commits structural/component changes at one barrier.
- Committed events and local outbox entries are generated from the same mutation record.
- Presentation, audio, animation, achievements, analytics, and replication consume committed events; predicted cues use stable IDs and reconcile later.
- Cross-owner workflow status is represented by compact projections, not arbitrary service objects.
- Replay/resimulation suppresses external dispatch and uses the recorded committed outcome.

## Component, System, Resource, and Event Interfaces

### Components

- `PendingGameplayCommand { command_id, owner, operation, caller, expected_revision, state }`
- `TransactionParticipant { aggregate_id, revision, lock_or_reservation_generation }`
- `WorkflowProjection { workflow_id, type, revision, phase, visible_status }`
- `ResourceReservation { reservation_id, workflow_id, resource, quantity, expiry, state }`
- `ExternalCommitProjection { provider, operation_id, status, revision }`

### Resources

- `CommandSchemaRegistry`: payload/version/auth/precondition/expiry rules.
- `IdempotencyLedger`: command identity, digest, state, semantic result, retention.
- `TransactionCoordinator`: mutation staging, invariant validation, barrier commit.
- `CommittedEventOutbox`: ordered durable events and relay state.
- `ConsumerInbox`: processed event IDs and aggregate sequence cursors.
- `WorkflowStore`: durable step graph, leases, attempts, deadlines, compensation.
- `RetryAndCircuitPolicy`: transient classification, backoff, jitter, caps, provider state.
- `TransactionBudgets`: commands, mutations, bytes, workflows, retries, retention.

### Systems

- `CommandAdmissionAndDedupeSystem`
- `GameplayTransactionPrepareSystem`
- `InvariantAndRevisionValidationSystem`
- `FixedBarrierCommitSystem`
- `CommittedEventOutboxSystem`
- `InboxDedupeAndProjectionSystem`
- `WorkflowOrchestrationSystem`
- `ReservationAndLeaseSystem`
- `CompensationSystem`
- `UnknownOutcomeReconciliationSystem`
- `TransactionAuditAndTelemetrySystem`

### Events and commands

- `CommandAccepted/Duplicate/Rejected/Expired`
- `TransactionPrepared/Committed/Aborted`
- `RevisionConflictDetected`
- `OutboxEntryCommitted/Relayed/Acknowledged`
- `WorkflowStarted/Advanced/Stalled/Completed`
- `StepCommitted/RetryScheduled/Failed`
- `CompensationRequested/Committed/Failed`
- `IrreversiblePivotCommitted`
- `OutcomeUnknown/Resolved`
- `ManualRepairRequired`

## Integration Plan

1. Inventory every mutating command and assign one owner, aggregate/revision set, atomicity scope, idempotency class, expiry, and terminal results.
2. Standardize command/workflow/event IDs, payload digests, authority epochs, and correlation fields.
3. Build the local ECS prepare/validate/commit barrier and migrate inventory, equipment, ability cost/effects, quest progress, and checkpoint mutations.
4. Add bounded idempotency ledgers with retention classes and same-ID/different-payload rejection.
5. Generate committed domain events from the mutation record; prevent pre-commit external dispatch.
6. Add transactional outbox/inbox behavior for durable persistence/service boundaries.
7. Model high-value cross-owner flows explicitly: trade, quest reward, match reward, purchase grant, cloud commit, and server-recovery reconciliation.
8. Define compensable, pivot, retryable, and manual steps plus resource reservations and expiry.
9. Add unknown-outcome queries, quarantine, administrative repair commands, and player-visible pending states.
10. Connect replay, rollback, prediction, save/load, reconnect, telemetry, and support tooling to stable transaction identities.
11. Establish load, retention, fault, abuse, and operational acceptance gates before enabling each workflow.

## Verification Strategy

- Property-test local transactions: any failure before commit leaves no mutation/event; commit produces all intended state and events exactly once.
- Retry the same ID before/during/after commit, response loss, reconnect, server crash, restore, and authority-epoch change; outcome remains semantically identical.
- Reuse an ID with changed payload/caller and verify rejection.
- Crash at every dual-write boundary; committed state always has a recoverable outbox entry and rolled-back state publishes none.
- Duplicate, delay, reorder, and lose relay messages; inbox dedupe and sequence policy converge correctly.
- Race conflicting inventory transfers, equipment changes, rewards, consumes, trades, and save/cloud revisions.
- Fault every workflow step, retry, timeout, lease takeover, pivot, and compensation step.
- Verify compensation preserves concurrent unrelated changes and never restores stale aggregate snapshots.
- Simulate provider success with lost response, provider timeout with later success, contradictory status, and permanent unavailability.
- Restore from checkpoints/replay and prove external side effects are suppressed or deduplicated.
- Test ledger expiry against maximum offline/reconnect/replay horizons and deliberately delayed duplicates.
- Fuzz schemas, sizes, IDs, revisions, step transitions, and unauthorized repair/compensation commands.
- Measure fixed-step transaction cost, queue tails, ledger memory, outbox lag, retry volume, workflow age, compensation rate, unknown outcomes, and repair backlog.

## Risks and Open Decisions

- Aggregate boundaries and which mutations require one local atomic commit.
- Command-ID generation, collision resistance, caller ownership, and offline creation.
- Retention by operation value and maximum retry/replay horizon.
- Expected-revision policy: reject, rebase, merge, or revalidate.
- Event ordering scope and whether gaps block consumers.
- Durable outbox location for authoritative servers and offline play.
- Workflow orchestration versus choreography and single point of operational ownership.
- Reservation duration, expiry clocks, and disconnect behavior.
- Pivot placement for rewards, trades, purchases, achievements, and cloud writes.
- Which operations are truly compensable and what player-visible compensation means.
- Treatment of narrative/quest progress that cannot be meaningfully reversed.
- External providers lacking idempotency or query-by-operation support.
- Manual repair authorization, audit, tooling, service-level objective, and player support.
- Privacy and retention of transaction/audit records.
- Retry limits, backoff, circuit breakers, and degraded-mode policy.
- Cross-region/offline conflict and authority-epoch reconciliation.
- Whether transaction status is saved in local saves or reconstructed from authority.

## Engineering Recommendations

These are Operation Mythology engineering recommendations, not direct source claims:

1. Require a stable command ID for every authoritative mutation; reuse it on retry and reject same-ID/different-intent requests.
2. Make one ECS owner commit all local gameplay state atomically at a fixed barrier, including its semantic result and committed events.
3. Never publish a durable event separately from its state change. Use a local transactional outbox and idempotent inbox consumers.
4. Treat network timeout as unknown, not failure. Query or retry with the same identity.
5. Use optimistic revisions and explicit reservations rather than long locks across ticks or services.
6. Model cross-owner operations as durable workflows with step identities, leases, deadlines, retries, and audit.
7. Classify steps as compensable, pivot, retryable, or manual. Put irreversible pivots after validation and reservation.
8. Treat compensation as a new invariant-checked operation; never restore stale snapshots over concurrent work.
9. Prefer forward completion after a pivot. Persist and retry compensation, and expose manual repair when evidence is insufficient.
10. Record external provider operation IDs and queryable status; quarantine high-value unknown outcomes instead of guessing.
11. Suppress external dispatch during rollback/replay and reconcile using recorded transaction identities.
12. Bound queues, ledgers, outboxes, retries, workflow age, and per-tick mutation work; expose overflow and backlog telemetry.
13. Provide one transaction inspector showing command, revisions, mutations, events, workflow steps, retries, compensation, and external evidence.
14. Ship each high-value workflow only after crash-at-every-boundary and duplicate/reorder/concurrency tests prove its invariants.

## Source Links

- [AWS Builders' Library — Making Retries Safe with Idempotent APIs](https://aws.amazon.com/builders-library/making-retries-safe-with-idempotent-APIs/)
- [AWS Prescriptive Guidance — Transactional Outbox Pattern](https://docs.aws.amazon.com/prescriptive-guidance/latest/cloud-design-patterns/transactional-outbox.html)
- [AWS Well-Architected — Make All Responses Idempotent](https://docs.aws.amazon.com/wellarchitected/2024-06-27/framework/rel_prevent_interaction_failure_idempotent.html)
- [Microsoft Azure Architecture Center — Compensating Transaction Pattern](https://learn.microsoft.com/en-us/azure/architecture/patterns/compensating-transaction)
- [Microsoft Azure Architecture Center — Transactional Outbox with Cosmos DB](https://learn.microsoft.com/en-us/azure/architecture/databases/guide/transactional-out-box-cosmos)
- [Garcia-Molina and Salem — Sagas, ACM SIGMOD Record, 1987](https://doi.org/10.1145/38713.38742)
- [Unity Cloud Save — Write Locks](https://docs.unity.com/en-us/cloud-save/concepts/write-locks)
- [Epic Games — Gameplay Ability System](https://dev.epicgames.com/documentation/en-us/unreal-engine/gameplay-ability-system-for-unreal-engine)
- [Epic Games — Gameplay Abilities](https://dev.epicgames.com/documentation/en-us/unreal-engine/gameplay-abilities-in-unreal-engine)
