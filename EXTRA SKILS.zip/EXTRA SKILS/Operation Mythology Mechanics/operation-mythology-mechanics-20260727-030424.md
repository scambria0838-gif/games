# Operation Mythology Mechanics Delta Research — Deterministic Gameplay Randomness and Stream Governance

**Timestamp:** 2026-07-27T03:04:24-07:00  
**Scope:** Gameplay pseudorandomness, stream ownership, counter-addressed draws, parallel ECS scheduling, rollback and replay, save/load, multiplayer authority, unpredictable secure outcomes, distribution correctness, content versioning, performance, debugging, and verification.

## Feature Overview

Randomness affects combat spread, AI choices, procedural encounters, loot, status-effect chances, quest variants, spawn selection, shuffles, and cosmetic variation. A global “next random” function makes those outcomes depend on unrelated call order. One added draw, a different worker schedule, a culled cosmetic, or a rollback branch can shift every later result.

Operation Mythology needs two deliberately separate services:

1. **Deterministic gameplay random function:** reproducible, addressable by stable gameplay identity, independent of thread scheduling, rollback-safe, and versioned with simulations, saves, and replays.
2. **Secure unpredictable random service:** server-only, backed by an operating-system/approved cryptographic generator for authentication material, resume tokens, nonces, secrets, and outcomes whose advance prediction creates economic or competitive abuse.

The normal deterministic path should be conceptually:

`RandomBits = PRF_or_counter_PRNG(match_seed, domain_id, owner_id, event_id, draw_slot, algorithm_version)`

Distribution code then maps those bits to a typed result:

`TypedResult = Distribution_v(bits, parameters)`

This makes the draw address part of gameplay data. It avoids mutable global state and decouples results from physical job order. A stateful local stream remains acceptable inside a strictly owned sequential transaction when its state/draw count is captured, but it should not become a cross-system singleton.

## Existing Coverage and Identified Gap

The mandatory recursive scan found 17 files in `C:\Users\steve\Desktop\GAME SKILLS` and 18 files in the mechanics archive. A new AI-navigation report was inventoried; its mechanics-facing traversal, authority, deterministic commit, and ECS contracts were already covered, while its pathfinding/crowd details are outside this batch.

Existing mechanics reports state that:

- random seeds enter deterministic simulation as explicit facts;
- systems should use owned random streams;
- rollback tests should compare random draw counts;
- snapshots/reconnect restoration must capture or rebuild RNG state;
- RNG policy version belongs in gameplay manifests.

They do not define:

- the unit of stream ownership;
- how parallel jobs draw without races or schedule dependence;
- how optional/cancelled branches avoid perturbing unrelated outcomes;
- how draw addresses are constructed and kept unique;
- when stateful streams versus counter-addressed functions are appropriate;
- how algorithms and distribution mappings are versioned;
- how seeds, counters, and results enter saves, replays, prediction, and network replication;
- how biased range mapping and floating-point differences are avoided;
- how deterministic simulation randomness is separated from cryptographic unpredictability;
- how designers debug, test, migrate, and audit random outcomes.

This batch fills that interface without prescribing every game's balance table or procedural-generation algorithm.

## Sourced Facts

The following are sourced facts, not Operation Mythology recommendations:

- Epic documents Unreal Random Streams as seeded generators that reproduce the same sequence for the same initial seed.
- Epic's `FRandomStream` is a thread-safe stateful generator with an initial and current seed. Epic warns that its lower bits are poor quality and explicitly says not to use the modulus operator for range reduction.
- Unity's global `UnityEngine.Random` is statically shared. Unity states that this global state is problematic for threads/jobs and for independent generators; use outside the main thread errors.
- Unity exposes the full serializable state of `UnityEngine.Random`, and its current documentation describes the implementation as Xorshift128 seeded once from operating-system entropy at process start.
- Unity Mathematics provides a value-type xorshift generator with 32 bits of state designed to be embedded in components and vectorized. This is an example of local state ownership, not a guarantee of schedule-independent draws.
- Salmon, Moraes, Dror, and Shaw show that counter-based generators compute an output from a key and counter without sequential state dependence. Their Random123 families parallelize without communication, require little or no mutable state, and permit streams keyed by application variables such as object ID and time step rather than machine/thread identity.
- The Random123 paper reports that its presented families pass TestU01 BigCrush, support at least `2^64` streams with period at least `2^128`, and enable machine-independent results when keys/counters derive from logical application state.
- Lemire's peer-reviewed work explains that converting uniformly random fixed-width words to `[0, s)` must avoid statistical bias; it presents an unbiased ranged-integer method using rejection and multiplication.
- NIST SP 800-90A specifies deterministic random bit generators based on hash functions or block ciphers for security applications. NIST's random-bit-generation project separately covers entropy sources and constructions.

**Bounded engineering inference:** an engine's seeded sequential stream provides repeatability only when its draw order and implementation remain identical. It does not by itself make parallel ECS execution, rollback branching, content migration, or cross-implementation replay deterministic.

**Bounded engineering inference:** a statistically strong counter-based gameplay PRNG is not automatically a secure secret generator. Conversely, a secure entropy/DRBG service is not automatically suitable as the reproducible simulation API. Separate contracts are required.

## Industry-Standard API or Pattern

### Random domain registry

Every authoritative use belongs to a stable namespaced domain:

- `Combat.Spread`
- `Combat.Critical`
- `Ability.Proc`
- `Status.PeriodicProc`
- `Loot.TableSelect`
- `Encounter.SpawnChoice`
- `Quest.Variant`
- `AI.Decision`
- `Traversal.CosmeticVariation`

Domain IDs are durable manifest entries. Renaming display text does not change them. Retired IDs are tombstoned rather than reused.

### Addressable deterministic draw

Use an immutable request:

`RandomAddress { algorithm_version, root_seed_id, domain_id, owner_id, event_id, tick_or_epoch, draw_slot, salt_revision }`

`event_id` is the stable semantic transaction/execution identity, not a memory address, chunk index, worker ID, or transient entity position. `draw_slot` is a stable authored/code-defined purpose within that event, such as `HitSpreadX`, `HitSpreadY`, or `ProcDecision`, not “the next call.”

The random function is pure:

`bits = RandomBits(RandomAddress)`

Repeated evaluation returns the same bits. Parallel execution order does not matter. Duplicate prediction/resimulation does not advance shared state.

### Stateful stream exception

A stateful stream may be used when:

- one owner performs a genuinely sequential algorithm;
- no other owner shares the stream;
- state and draw count are explicit;
- branch/cancellation behavior is deterministic;
- snapshot, rollback, save, and migration policies capture that state;
- the algorithm/version is pinned.

Examples include generating a procedural room from one immutable generation request or shuffling a bounded deck whose final order is persisted. Do not store one mutable stream per system if system iteration order can change its meaning.

### Seed hierarchy

Derive child keys/seeds with a stable keyed hash or documented mixing function:

`root -> match/playthrough -> domain -> owner/event`

Never create child seeds by adding small integers to a parent, hashing platform-dependent object bytes, using pointer values, thread indices, wall-clock time inside deterministic simulation, or consuming a global stream.

Root-seed policy is mode-specific:

- local procedural worlds may expose a user seed;
- authoritative matches generate and retain a server seed;
- predictable non-sensitive cosmetic streams may be client-local and presentation-only;
- secure secrets and anti-abuse values never use exposed gameplay seeds.

### Distribution catalog

Random bits are not a gameplay distribution. Provide versioned typed samplers:

- unbiased integer range;
- Bernoulli/probability threshold using integer fixed-point comparisons;
- weighted choice with validated non-negative integer/fixed-point weights;
- shuffle/permutation;
- sample without replacement;
- continuous scalar/vector distributions with specified interval semantics;
- direction/cone sampling with documented numeric policy.

Each sampler defines:

- inclusive/exclusive bounds;
- zero/empty/overflow behavior;
- normalization and precision;
- maximum rejection iterations or bounded fallback;
- deterministic ordering of candidates;
- algorithm/distribution version;
- reference test vectors.

Do not implement `raw_bits % bound` unless the algorithm proves that bound divides the source range. Epic's own `FRandomStream` warning and ranged-integer research both reinforce this.

### Outcome authority

Clients may predict a deterministic outcome only from seeds/addresses the server intentionally discloses. The server remains authoritative and either:

- reproduces the draw from a server-known address; or
- commits the resulting authoritative choice and replicates it.

For loot/economy/ranked outcomes, withholding the seed can prevent advance prediction, but secrecy is not proof of fairness. Record a server-side audit commitment/result policy if player-facing verification is required. Cryptographic commit-reveal is a separate product/security decision, not the default simulation mechanism.

## Performance Considerations

### Asymptotic complexity

- Counter-based generation is `O(1)` per fixed-width block and permits direct random access to any draw.
- A stateful stream draw is also `O(1)` but introduces sequential dependence and mutable state.
- Unbiased bounded integer generation has expected `O(1)` work; rejection adds a small data-dependent number of iterations. Validate extreme bounds and cap pathological custom samplers.
- Weighted linear choice is `O(n)` for `n` entries; prefix sums plus binary search are `O(log n)` per draw after `O(n)` preprocessing; alias tables are `O(1)` per draw after `O(n)` preprocessing/storage.
- Fisher-Yates shuffle is `O(n)` time and in-place `O(1)` auxiliary storage.
- Random audit comparison is `O(d)` for `d` recorded draw digests/counts; use hierarchical hashes to localize divergence without retaining every value.

### Allocations and garbage collection

- Deterministic draw requests are small value records constructed in registers/stack/native job memory.
- No per-draw heap objects, strings, dynamic domain lookup, closures, or logging allocations belong in fixed simulation.
- Compile weighted tables, aliases, and stable candidate order into immutable definition data.
- Stateful stream components hold compact state/version/count only.
- Debug traces use bounded per-thread rings and numeric IDs, with formatting deferred.

### Cache behavior

- Counter-based functions trade a few integer operations for near-zero mutable-state traffic and no shared cache-line contention.
- Dense domain/sampler metadata and immutable precomputed distribution tables are cache-friendly.
- Avoid embedding large generator states per entity; large state can inflate ECS chunks and reduce useful component density.
- Keep secure RNG state outside ECS in a protected service. Gameplay systems receive opaque secure results or committed outcomes.

### Update frequency

- Draw only when a semantic event needs a decision, not every render frame by default.
- Periodic status effects derive an address from execution ID plus occurrence index, so missed/catch-up processing does not consume unrelated streams.
- Presentation randomness can update at presentation cadence but must not mutate authoritative state.
- Seed creation, manifest pinning, and stream migration occur at lifecycle boundaries rather than per tick.

### Concurrency

- Counter-addressed draws need no shared mutable generator and can run in parallel jobs when addresses are unique.
- Address uniqueness must come from logical IDs, not worker assignment; duplicate addresses intentionally reproduce the same result.
- Stateful streams require exclusive owner access or deterministic partition/merge. A thread-safe lock only prevents data races; it does not make lock acquisition order deterministic.
- Parallel candidate construction must sort candidates by stable IDs before a weighted draw if input iteration order could vary.
- Secure RNG calls can be batched outside hot ECS loops, but secret buffers and service errors need explicit handling.

### Fixed-step cost

- Budget random draws and expensive distribution work per system/tick, especially content-scripted loops.
- Counter-based recomputation is usually cheaper than snapshotting many mutable states, but measure the chosen algorithm on target CPUs.
- Never let a rejection sampler or script request an unbounded number of retries.
- Record per-domain draw counts and optional address digests at validation level; full trace capture is triggered and bounded.
- Randomness must not become a hidden reason to serialize otherwise parallel systems.

### Serialization cost

- Addressable draws usually serialize root-seed identity, algorithm/distribution versions, and stable event state—not a large mutable stream per entity.
- Stateful exceptions serialize current state, initial/root reference, draw count, owner, and version.
- Saves/replays pin the gameplay manifest containing RNG/domain/distribution versions.
- Do not serialize secret seed material to clients, ordinary telemetry, crash text, or player-readable saves.
- For long-lived saves, prefer persisting already-committed durable outcomes where regenerating under an obsolete algorithm would change the world.

### Networking cost

- The server need not replicate every random bit. Replicate authoritative semantic outcomes or a seed/address contract when client reconstruction is safe and bandwidth-efficient.
- Prediction can derive cosmetic or rollback results locally; correction references stable event/outcome IDs.
- Hidden server seeds reduce disclosure but require authoritative result replication and server-side audit storage.
- Join/reconnect baselines include committed state and pinned versions; clients must not reroll history by joining.
- Never accept client-provided “random results,” and do not let clients choose unrestricted seeds/event IDs that influence rewards or competitive outcomes.

## Pros and Cons

### Counter-addressed deterministic randomness

Pros:

- independent of physical job order;
- direct access and cheap rollback/resimulation;
- little or no mutable state;
- reproducible per event/domain;
- isolates optional branches and unrelated systems;
- natural divergence diagnostics.

Cons:

- address construction and uniqueness are architectural obligations;
- accidental address reuse creates repeated/correlated outcomes;
- changing semantic IDs or draw-slot layout changes results;
- multi-value distributions need explicit slot/block conventions;
- a non-cryptographic counter PRNG may expose future outcomes if seed/address is known.

### Stateful owned streams

Pros:

- familiar sequential API;
- convenient for shuffles and procedural builders;
- compact for small-state algorithms;
- easy to capture when ownership is truly local.

Cons:

- result depends on draw order and branching;
- snapshots/migration must preserve state;
- parallel scheduling is difficult;
- unrelated added draws cause butterfly changes;
- locks provide safety, not deterministic ordering.

### Secure server randomness

Pros:

- appropriate for tokens/secrets and unpredictable sensitive outcomes;
- prevents derivation from public gameplay seeds;
- can support audited commit policies.

Cons:

- not reproducible unless results/commit records are persisted;
- higher operational and security complexity;
- unavailable/error behavior must be defined;
- cannot be reconstructed from deterministic replay without recorded outcomes;
- indiscriminate use blocks prediction and increases replication/storage.

## ECS Architectural Integration

Randomness is a service contract with compact ECS-facing data.

Authoritative deterministic systems build `RandomAddress` from stable components/resources and call a pure fixed-version generator. They do not fetch a mutable global RNG resource.

Use stable semantic identities:

- match/playthrough ID or root seed ID;
- participant/entity logical ID and generation where appropriate;
- ability execution, attack, loot transaction, quest step, encounter, or spawn request ID;
- deterministic occurrence index;
- domain and draw-slot IDs from the gameplay manifest.

Presentation-only systems use a separate namespace/root and may include view/local-user identity. They cannot feed authoritative decisions. Editor preview and tests use explicitly labeled roots.

Stateful generator components are exceptions with declared owner and snapshot policy. A validator rejects copying one stateful stream to several jobs or consuming it from undeclared systems.

Random outcome commit occurs at the same deterministic barrier as its owning gameplay transaction. External achievements, inventory grants, economy effects, or analytics receive the committed semantic result, not permission to reroll.

Security randomness lives in a non-ECS protected resource/service. Only opaque token/result APIs cross into gameplay; seed material never appears in replicated components or generic event buses.

## Component, System, Resource, and Event Interfaces

### Components

- `RandomEventIdentity { stable_event_id, occurrence_index, revision }`
- `StatefulRandomStream { owner_id, algorithm_version, state_words, draw_count }` — exception only
- `CommittedRandomOutcome { event_id, domain_id, result_code_or_value, definition_revision }`
- `RandomAuditDigest { tick, domain_digest, draw_count }` — debug/validation mode

### Resources

- `GameplayRootSeedReference`
- `RandomDomainRegistry`
- `RandomAlgorithmRegistry`
- `DistributionCatalog`
- `GameplayManifestRevision`
- `RandomValidationPolicy`
- `SecureRandomService`
- `RandomTraceRing`

### Systems

- `RandomAddressValidationSystem`
- `StatefulStreamOwnershipValidationSystem`
- domain systems that request typed draws
- `RandomOutcomeCommitSystem`
- `RandomDigestSystem`
- `RandomTraceExportSystem`
- `RandomMigrationSystem`
- `SecureOutcomeAdapterSystem`

### Events

- `RandomOutcomeCommitted { event_id, domain_id, sampler_id, result_digest }`
- `RandomAddressCollisionDetected { address_digest, first_owner, second_owner }`
- `RandomDrawBudgetExceeded { domain_id, owner_id, count }`
- `RandomDivergenceDetected { tick, domain_id, expected_digest, actual_digest }`
- `RandomVersionUnsupported { algorithm_version, distribution_version, artifact_id }`
- `SecureRandomUnavailable { request_class, policy_action }`

Raw secure seeds and unrestricted random values are not broadcast events.

## Integration Plan

1. Inventory every authoritative and presentation random call. Record owner, purpose, current generator, distribution, schedule dependence, persistence, prediction, network visibility, and sensitivity.
2. Classify calls as deterministic authoritative, deterministic presentation, stateful generation transaction, or secure unpredictable.
3. Establish stable domain and draw-slot registries in the gameplay manifest with no ID reuse.
4. Select and freeze a canonical integer-defined counter-based algorithm with published test vectors; record algorithm and mixing versions.
5. Define `RandomAddress` construction rules and collision diagnostics. Ban worker IDs, memory addresses, chunk indices, and incidental iteration order.
6. Implement versioned unbiased integer, fixed-point Bernoulli/weighted choice, shuffle, sampling, and required geometric distributions with reference vectors.
7. Convert rollback/predicted combat, abilities, periodic effects, encounters, and AI decisions to addressable draws.
8. Keep explicitly bounded procedural builders/decks stateful only where their state/result ownership is clear; snapshot or persist final outcomes.
9. Integrate root/version/state into save, replay, reconnect, host recovery, and gameplay manifests.
10. Create a separate secure RNG adapter for tokens and sensitive server outcomes. Persist authoritative outcomes/audit data where reconstruction is impossible or inappropriate.
11. Add deterministic draw inspectors, address collision detection, per-domain digests/counts, and triggered traces.
12. Roll out one domain at a time, comparing old/new distributions statistically and reviewing balance/content changes.

## Verification Strategy

- **Reference vectors:** fixed inputs for every algorithm, mixer, sampler, hash/derivation, and platform must produce exact expected integer outputs.
- **Schedule independence:** randomize worker count, chunk order, batch size, job completion, and entity insertion; counter-addressed outcomes remain identical.
- **Rollback:** resimulate arbitrary depths, cancel/replay predictions, and verify the same addresses, outcomes, draw counts, events, and state hashes.
- **Branch isolation:** add or remove optional cosmetic/AI/content draws and prove combat, loot, quest, and other domains are unchanged.
- **Address uniqueness:** property/fuzz tests generate concurrent events and assert unintended duplicate addresses never occur; intentional reuse is documented.
- **Distribution correctness:** chi-square/KS or appropriate statistical tests catch range bias, broken weights, endpoint errors, bad shuffles, and direction anisotropy. Statistical tests supplement—not replace—exact algorithm vectors.
- **Boundary tests:** empty tables, zero/one weights, total overflow, maximum ranges, negative/NaN inputs, inclusive/exclusive endpoints, rejection limits, and duplicate candidates.
- **Candidate ordering:** permute input entity/container order and prove stable sorting plus the same semantic draw yields the same selected stable ID.
- **Save/replay:** save before/after draws, restore repeatedly, migrate versions, join late, reconnect, and recover authority without rerolls or stream shifts.
- **Versioning:** old artifacts either run their pinned implementation, migrate committed outcomes, or fail with an explicit unsupported reason; silent fallback is prohibited.
- **Networking:** forge seeds, event IDs, occurrence counts, or outcomes; the server validates addresses and remains authoritative.
- **Security separation:** scan replicated schemas, logs, telemetry, crash reports, saves, and client memory interfaces for forbidden secret seeds/tokens.
- **Performance:** benchmark millions of draws, worst weighted tables, rejection rates, trace levels, cache behavior, zero warm-tick allocation, and resimulation.
- **Content audit:** designers can inspect why an outcome occurred using domain/event/slot/version without exposing server secrets to unauthorized users.
- **Failure injection:** secure RNG unavailable, audit store delayed, unsupported manifest, duplicate event ID, counter exhaustion, and trace overflow follow explicit safe policies.

## Risks and Open Decisions

- Canonical counter-based algorithm and number of rounds.
- Whether deterministic gameplay seeds are public, delayed, per-match hidden, or mode-specific.
- Exact root-seed derivation and rotation.
- Stable domain/draw-slot governance, ownership, review, and tombstone policy.
- Event identity source for attacks, periodic effects, AI decisions, loot, quests, and procedural generation.
- Address width, collision risk, and runtime collision diagnostics.
- Stateful-stream exception criteria and snapshot/migration contract.
- Integer/fixed-point versus floating-point distributions and cross-platform numeric guarantees.
- Weighted-table representation, overflow limits, alias-table determinism, and hotfix behavior.
- Candidate ordering when content uses tags, sets, maps, or dynamically spawned entities.
- Prediction disclosure: which seeds/addresses clients receive and when.
- Loot/economy fairness, auditability, commit-reveal, legal/regulatory requirements, and player-facing odds disclosure.
- Secure RNG provider, entropy health, failure policy, key/seed protection, and audit access.
- Save/replay support horizon for old algorithm/distribution versions.
- Whether long-lived worlds persist final procedural outcomes or retain old generators.
- Compatibility behavior when balance weights change but an event was already created.
- Random trace privacy/retention and whether results can reveal hidden encounter/loot content.
- Content scripting limits, draw budgets, and validation of loops/rejection.
- Statistical acceptance thresholds and false alarms from small sample sizes.

## Engineering Recommendations

The following are Operation Mythology engineering recommendations:

1. Ban mutable global RNG state from authoritative simulation.
2. Use a canonical integer-defined counter-addressed PRNG for ordinary deterministic gameplay, keyed by stable logical application identities rather than thread or storage order.
3. Treat domain ID, event ID, occurrence/tick identity, and draw slot as part of the gameplay contract. Give every ID durable manifest governance and never reuse retired IDs.
4. Prefer named draw slots over sequential “next” calls so added branches do not perturb unrelated outcomes.
5. Permit stateful streams only for strictly owned sequential algorithms with explicit state, draw count, snapshot, save, migration, and cancellation policy.
6. Separate authoritative, presentation, editor/test, and secure namespaces/roots. Presentation randomness must never affect gameplay truth.
7. Use a dedicated OS/approved cryptographic random service for tokens, authentication material, secrets, and sensitive unpredictable server outcomes. Do not derive these from gameplay seeds.
8. Do not assume seeded engine RNGs are cross-version/platform contracts. Pin the algorithm, mixing, conversions, distributions, and test vectors owned by the project.
9. Build typed versioned distribution APIs. Avoid direct raw-bit modulo range reduction and floating probability comparisons with unspecified bounds/precision.
10. Sort weighted candidates by stable semantic ID before drawing; never depend on hash-map, chunk, job, or pointer order.
11. Preserve committed durable outcomes when generator migration would reroll a long-lived world. Pin old implementations only for a deliberate support horizon.
12. In multiplayer, let clients predict only intentionally disclosed deterministic streams. The server validates addresses and commits outcomes; clients never submit authoritative rolls.
13. Record compact per-domain draw counts/digests continuously in validation builds and expose bounded address/outcome traces on trigger.
14. Make reference vectors, randomized schedule tests, rollback branch isolation, address collision tests, distribution tests, save/replay migration, and secret-leak scans release gates.
15. Review RNG changes as gameplay-schema changes because algorithm, slot, candidate-order, and weight modifications can alter balance, saves, replays, and network outcomes.

## Source Links

- Epic Games, [Random Streams in Unreal Engine 5.8](https://dev.epicgames.com/documentation/unreal-engine/random-streams-in-unreal-engine?lang=en-US)
- Epic Games, [`FRandomStream` API](https://dev.epicgames.com/documentation/unreal-engine/API/Runtime/Core/FRandomStream?lang=en-US)
- Unity Technologies, [`UnityEngine.Random` API](https://docs.unity3d.com/6000.0/Documentation/ScriptReference/Random.html)
- Unity Technologies, [`UnityEngine.Random.State` API](https://docs.unity3d.com/6000.0/Documentation/ScriptReference/Random.State.html)
- Unity Technologies, [`Unity.Mathematics.Random` 1.3.3 API](https://docs.unity3d.com/Packages/com.unity.mathematics@1.3/api/Unity.Mathematics.Random.html)
- Salmon, Moraes, Dror, and Shaw, [Parallel Random Numbers: As Easy as 1, 2, 3 (SC11)](https://users.cs.utah.edu/~hari/teaching/bigdata/random123sc11.pdf)
- D. E. Shaw Research, [Random123 counter-based RNG overview and library](https://random123.com/)
- Daniel Lemire, [Fast Random Integer Generation in an Interval](https://doi.org/10.1145/3230636)
- NIST, [SP 800-90A Rev. 1: Deterministic Random Bit Generators](https://csrc.nist.gov/pubs/sp/800/90/a/r1/final)
- NIST, [Random Bit Generation publications](https://csrc.nist.gov/Projects/random-bit-generation/publications)

