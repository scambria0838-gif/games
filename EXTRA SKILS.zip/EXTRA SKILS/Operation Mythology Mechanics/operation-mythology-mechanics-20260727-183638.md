# Operation Mythology Mechanics Research

**Timestamp:** 2026-07-27T18:36:38-07:00  
**Subject:** Authoritative gameplay ropes, tethers, grapples, swing lines, ziplines, tow links, traps, and nets independent of cloth simulation

## Feature Overview

Ropes and tethers become gameplay systems when they constrain movement, attach two authoritative objects, enable grappling or swinging, reel or pay out under player input, tow or suspend objects, form ziplines, restrain targets, trigger traps, transmit load, break or cut, or persist across saves and multiplayer sessions. A rendered cable or cloth strand is not an adequate gameplay authority model: visual particles may use different solvers, time steps, LODs, collision policies, or even run only on clients.

The recommended architecture separates three representations:

1. **Authoritative semantic link:** stable link identity, endpoint identities and generations, attachment frames, owner, mode, length policy, slack/taut state, reel target/rate, load band, health, break/cut policy, permissions, persistence, and revision.
2. **Bounded gameplay constraint proxy:** one distance constraint, a small fixed chain, an analytic swing constraint, an authored zipline spline, a volume/segment approximation for traps and nets, or another deterministic gameplay approximation.
3. **Presentation simulation:** a cable, cloth strip, dense rope, particles, mesh, audio, and animation that follows the authoritative endpoints and semantic events without determining gameplay truth.

This report excludes detailed rope/cloth particle solving, rendering, garment authoring, and animation-authoring workflows. It defines the gameplay-facing contract exposed to locomotion, abilities, interactions, inventory/equipment, damage, quests, AI, networking, save/load, replay, accessibility, and testing.

## Existing Coverage and Identified Gap

The required recursive scan completed successfully before research:

- `C:\Users\steve\Desktop\GAME SKILLS`: 26 files at scan time.
- `C:\Users\steve\Desktop\EXTRA SKILS\Operation Mythology Mechanics`: 26 files at scan time, including the active `RESEARCH_INDEX.md`.

Two new shared reports covered cloth/garment and hair/groom simulation. Hair is outside mechanics scope. The cloth report explicitly recommends a separate simplified physics object whenever a cape or rope affects gameplay and states that only simplified gameplay-authoritative proxies should be networked. It does not define that proxy's lifecycle, endpoint authority, input contract, traversal modes, break ordering, prediction, persistence, or ECS interfaces.

Existing mechanics reports cover general traversal candidates and phases, character movement prediction, abilities, interactions, inventory/equipment, damage/status effects, semantic commands/events, save/load, networking, randomness, scripting, and content identity. The advanced traversal report covers mantles, vaults, climbing, ladders, swimming, and ledges, but contains no rope, grapple, tether, swing, zipline, tow, or net architecture.

The uncovered gap is therefore genuine:

- link identity and endpoint generation fencing;
- attach/detach/reanchor, reel, slack/taut, cut, break, repair, and expiry state transitions;
- controlled-player versus world-object constraint ownership;
- grappling and swinging as predicted custom locomotion;
- zipline travel versus free swing;
- multipart rope approximation without an entity per visual segment;
- same-tick detach/break/reel/anchor-destroy conflict ordering;
- lag compensation and validation for grapple acquisition;
- save/load, replay, streaming, and late-join reconstruction;
- load measurement semantics and deterministic break policy;
- team permissions, hostile restraint, crowd-control, rescue, tow, and trap/net policies;
- accessibility alternatives and automated validation.

## Sourced Facts

The following are sourced facts; Operation Mythology recommendations are identified separately.

1. Unreal Engine 5.8 documents `UPhysicsConstraintComponent` as a joint connecting two rigid bodies. Its API exposes constrained components, current force, broken state, and an `OnConstraintBroken` notification. The Physics Constraint reference exposes actor/component endpoints and configurable constraint settings.

2. NVIDIA PhysX documents a distance joint that keeps two constraint-frame origins within an enabled minimum/maximum distance range. Standard PhysX joints can have break-force and break-torque thresholds, report force after simulation, and generate a constraint-break callback. PhysX also cautions that reported joint force is updated while actors are awake and that some actuation force is not included in reported/breakage force. Therefore a universal gameplay break rule cannot blindly depend on one backend force sample.

3. Unreal Engine's Cable Component represents a cable as particles connected by distance constraints and uses Verlet integration. It supports fixed or free endpoints, runtime endpoint attachment, rest length, segments, substep time, iterations, stiffness, and collision. Epic states that collision and stiffness substantially increase Cable Component cost and describes collision as experimental. This is evidence for treating the cable component as presentation or a bounded local proxy rather than an authoritative universal network state.

4. The shared cloth report, based on Unreal Panel Cloth, NVIDIA NvCloth, and the XPBD paper, distinguishes reusable cooked constraint data, per-instance particle state, solver ordering, LOD, and rendering. It explicitly says server gameplay must not depend on nondeterministic cloth vertices, and that gameplay ropes should use a separate simplified physics object.

5. Unreal's Character Movement Component provides replicated walking, falling, swimming, flying, and a custom movement mode. Its network flow records owning-client moves, reproduces them on the server, acknowledges or corrects results, replays saved moves after correction, and smooths simulated proxies. Epic documents that custom networked movement can extend packed saved-move data.

6. Unreal's Networked Physics Overview documents server-authoritative physics replication modes. Resimulation caches physics state for at least a round-trip-time window and rewinds/resimulates on divergence, consuming CPU and memory. Predictive interpolation is described as more performant and less network intensive than resimulation. This supports selective rather than universal rope-chain rollback.

7. Unreal's general Movement Component documentation provides swept movement, sliding, penetration resolution, and component ownership primitives. It notes that attached components may teleport to the moved component's final location without independent collision during swept movement. This is another reason not to model a gameplay tether as a purely attached visual component.

8. Neither Unreal, PhysX, nor the shared cloth sources define project rules for grapple target authorization, hostile restraint, party towing, objective credit, save ownership, accessibility alternatives, or deterministic conflict ordering. Those are engineering policy.

## Industry-Standard API or Pattern

Adopt a **revisioned link aggregate plus mode-specific gameplay constraint adapter**.

### Link aggregate and endpoint descriptors

Each link has:

- stable `LinkId`, immutable `DefinitionRevision`, `AuthorityEpoch`, and monotonic `LinkRevision`;
- `EndpointA` and `EndpointB`, each described by stable entity/world-anchor ID, entity generation, socket/region ID, local attachment frame, and streaming cell;
- `LinkMode`: slack rope, taut distance tether, grapple swing, pull/reel, zipline, tow, suspension, restraint, tripwire, net volume, scripted link, or presentation-only;
- current lifecycle state: proposed, attaching, active-slack, active-taut, reeling, blocked, breaking, broken, detaching, detached, expired;
- natural/current/target/minimum/maximum length and quantized reel rate;
- health, cut resistance, load policy, break band, grace/dwell state, and last authoritative evidence;
- controller/owner/team and attach/detach/reel/cut permissions;
- persistence, replication, interest, and prediction classes;
- bounded gameplay proxy handle and independent presentation handle.

Endpoints never store raw entity, component, bone, or solver pointers. Every use resolves the stable ID and verifies the entity generation, socket revision, world generation, and authority epoch.

### Attachment transaction

Attachment is not an immediate client-supplied point:

1. Client or AI submits `RequestLinkAttach` with input sequence, target hint, hit evidence, desired mode, and optional equipment instance.
2. Authority reconstructs or queries against the approved world snapshot, validates range, line of sight, target material/tags, attach region, team/permission, inventory/ability cost, endpoint capacity, world readiness, and content revision.
3. Authority reserves both endpoints and any exclusive equipment resource.
4. At the fixed commit barrier it revalidates endpoints, spends costs, creates the aggregate, assigns stable frames, selects the gameplay proxy, and emits one attach event atomically.
5. Client prediction may display a tentative line and enter a reversible provisional movement state, but it cannot choose final anchor identity, length, break state, or target ownership.

The initial length comes from policy: measured distance plus slack, authored fixed length, equipment capacity, or a clamped requested value. It is not an unchecked client scalar.

### Mode-specific proxy

- **Grapple swing:** analytic or single distance-limit constraint between character and anchor. Character movement owns velocity integration, collision sweeps, air control, pumping, and detach impulse; the tether supplies radial constraint, length, anchor velocity, and load evidence.
- **Pull/reel:** reel command changes target length at a bounded rate. Solver/character movement proposes motion or force subject to mass ratio, obstruction, stamina/resource, and target permission.
- **Zipline:** an authored or validated spline/segment owns a parametric travel coordinate and direction. It is not simulated as a flexible rope for authoritative travel.
- **Tow/suspension:** simplified joint/constraint proxy connects authoritative bodies. Policy limits chains of coupled bodies and chooses predictive interpolation, resimulation, or server-only authority.
- **Tripwire:** authoritative swept segment/capsule or portal crossing test; visual sag is presentation only.
- **Net/restraint:** bounded authored volume, capsule set, or target status/ability state after validated capture; never collision-test every visual cloth triangle.
- **Multipart physical rope:** reserved for capped hero cases using a fixed maximum node/constraint chain. Nodes live in a specialized pool, not one ECS entity per segment.

### Slack, taut, and reel semantics

Quantize length and compare endpoint separation using hysteresis:

- slack below `length - enterSlackMargin`;
- taut above `length - enterTautMargin`;
- retain the current band between thresholds.

Reel input is an action intent with sequence and analog value. The authority applies an acceleration/rate limit, minimum/maximum length, obstruction policy, energy/stamina/equipment cost, and over-capacity result. Do not change length directly from frame-rate-dependent input.

When shortening would place an endpoint inside collision, policy chooses: stop reeling, slide through approved sweeps, move the lighter endpoint, split correction by mass class, or fail with a typed obstruction reason. Never teleport a controlled character through geometry.

### Load, cut, break, and detach

Separate three concepts:

- **solver load sample:** backend-dependent diagnostic force/impulse;
- **gameplay load evidence:** quantized, filtered measure derived at a declared fixed step;
- **break policy:** authoritative health/threshold/dwell decision with idempotent event identity.

Break conditions may include explicit cut damage, endpoint destruction, maximum geometric error, overload band for a dwell duration, scripted command, expired equipment, or world unload policy. Because solver reporting differs by backend and timestep, content declares whether breakage uses backend force, analytic tension approximation, accumulated damage, or explicit events.

Break and detach produce different attribution and cooldown outcomes. Break may damage equipment or trigger objectives; voluntary detach may preserve it. Both revoke the active constraint before presentation cleanup.

### Fixed-barrier conflict order

For the same link and tick:

1. authority epoch/world-generation invalidation;
2. endpoint destruction or streaming invalidation;
3. accepted explicit cut/break damage;
4. overload break;
5. voluntary detach/cancel;
6. reanchor/attach completion;
7. reel/length change;
8. locomotion integration;
9. presentation and telemetry.

Projects may choose another order, but it must be exhaustive, deterministic, and tested. All commands use link revision and idempotency keys.

### Character locomotion integration

Grapple and zipline are explicit traversal modes, not forces injected invisibly into ordinary falling:

- movement snapshot includes link ID/revision, anchor snapshot, length, reel state, mode parameters, input sequence, and detach flag;
- owning client predicts bounded movement from the same quantized inputs;
- server reproduces and validates;
- correction restores authoritative link/movement state and replays saved inputs;
- simulated proxies receive compact mode plus anchor/length and interpolate presentation;
- anchor revision change, unload, break, or invalid socket forces a reasoned exit transition.

Camera perspective never changes anchor, length, collision, or input physics. FP/TP adapters alter framing, line visibility, comfort roll, field of view, reticle, and animation only.

### Persistence, replay, and networking

Persist links only when their policy requires it:

- link ID/revision/definition revision;
- endpoint stable IDs/generations or durable world-anchor IDs;
- local frames/socket IDs;
- mode, lifecycle state, current/target length, health, and break/detach state;
- minimal fixed-chain state only for explicitly persistent hero ropes;
- owner/permission and equipment provenance;
- pending transactions are either journaled or rolled back to a declared safe state.

On load, resolve endpoints before activating the proxy. Missing endpoints yield detach, fallback anchor, tombstone migration, or load failure according to content policy. Late join receives active link aggregates before dependent movement snapshots. Replay records accepted commands and committed link transitions; dense presentation particles are regenerated locally.

Network important semantic changes reliably or through revisioned state deltas: attach, anchor, mode, length target, break, detach, owner, and permissions. Movement packets carry compact predicted input and link revision. Only hero multipart proxies receive bounded physics state; cosmetic cable particles never replicate.

## Performance Considerations

### Asymptotic complexity

Let `L` be active authoritative links, `Q` attach/acquisition queries, `N` nodes in capped multipart proxies, `I` constraint iterations, `K` collision candidates, `A` affected endpoints, and `R` interested recipients.

- Dense aggregate update is `O(L)`, with dormant event/deadline links skipped.
- Attach broad phase is approximately `O(Q log M + candidates)` using a spatial index, not `O(Q*M)` over all targets.
- Analytic grapple/zipline/tow proxies are `O(1)` per link per fixed step.
- Multipart constraint solving is `O(I*N)` plus collision work `O(K)` after spatial culling; uncontrolled self-collision can approach quadratic and is not allowed for baseline gameplay ropes.
- Endpoint adjacency lookup is expected `O(1 + degree)` and lets endpoint destruction detach only incident links.
- Serialization is `O(Lp + Np)` for persistent links and retained proxy nodes.
- Network cost is `O(R)` recipients times compact link deltas plus selected movement/proxy state, not visual segment count.

### Allocations and garbage collection

Store aggregates in fixed-capacity or slab pools, endpoints in compact descriptors, per-tick commands/events in bounded rings, acquisition candidates in reusable buffers, and multipart nodes/constraints in specialized arenas. Warm fixed-step and prediction paths allocate nothing from the general heap and trigger no managed garbage collection. Creation/destruction returns generation-tagged slots. Overflow returns typed capacity errors; it never creates an unbounded fallback chain or drops a break/detach transition.

### Cache behavior

Use structure-of-arrays hot data for state, revisions, endpoint indices, lengths, reel rates, health/load bands, and dirty masks. Keep cold definition, provenance, migration, audit, and presentation metadata separate. Batch links by proxy mode and owner, group incident links by endpoint, and keep node/constraint ranges contiguous. Avoid pointer chains across ECS entities for visual segments.

### Update frequency

Controlled grapple/tow links update at the authoritative fixed step and on client prediction steps. Dormant static ziplines, slack decorative links, armed tripwires without nearby candidates, and persistent detached links update through events or coarse deadlines. Acquisition queries run only on relevant input/AI requests. Load sampling may run each physics step but semantic band/health updates commit once per fixed tick. Persistence is dirty-driven and asynchronous; network semantic deltas are event-driven with periodic state checkpoints.

### Concurrency

Endpoint/world snapshots are immutable during parallel link evaluation. Independent links can run concurrently, but links sharing a dynamic endpoint require graph coloring, island ownership, or deterministic sequential commit. Character movement and tether constraint must have one declared integration owner to prevent double application. Workers emit proposals; a fixed barrier resolves conflicts and mutates ECS/physics ownership. Prediction history is connection-local. Save/network extraction reads immutable committed snapshots.

### Fixed-step cost

Budget attach queries, active analytic links, multipart nodes, constraint iterations, collision candidates, shared-endpoint islands, breaks, events, and resimulated links. Cap recursion/cascade when one endpoint break invalidates many links. Critical detach/break operations always execute; optional load diagnostics, presentation impulses, and noncritical collision tiers degrade first. Measure worst-case cascades such as a net containing many actors or a towing chain entering collision.

### Serialization cost

Serialize aggregate fields with stable IDs, varint revisions, quantized attachment frames/lengths, bit-packed modes/states, and sparse persistent proxy state. Do not serialize visual particles, render vertices, per-iteration multipliers, contact manifolds, or backend handles. Incremental saves write dirty links and endpoint dependencies. Validate definition hashes and endpoint tombstones before activation. Bound journal size for commands pending at checkpoint time.

### Networking cost

Replicate semantic link state and controlled-character movement, not cable particles. Interest includes either endpoint, owner/party, relevant objectives, nearby observers, and spectators. Attach/detach/break require idempotent revisioned delivery; frequent reel input can be packed into saved movement commands and acknowledged cumulatively. Quantize anchors, frames, length, rates, and load bands. Resimulation history cost is `O(predicted links * RTT ticks * state size)` and should be restricted to controlled or high-value links. Measure bytes/link/second, attach RPC rate, correction magnitude, resimulation ticks, late-join bytes, and important-proxy state.

## Pros and Cons

### Analytic single-link gameplay proxy

Pros:

- bounded `O(1)` cost;
- compact prediction, save, replay, and replication;
- stable across physics backends;
- easy to validate against character collision;
- independent visual rope quality.

Cons:

- cannot wrap naturally around arbitrary obstacles;
- limited sag/contact behavior;
- needs explicit obstruction and reanchor rules.

### Fixed multipart physical proxy

Pros:

- supports selected wrapping, suspension, towing, and moving-contact behavior;
- can produce richer shared-object interactions.

Cons:

- iterative cost and collision complexity;
- coupled-island prediction and rollback are expensive;
- more nondeterminism and correction;
- persistence and late join require more state.

Recommendation: treat this as a capped hero tier with a deterministic analytic fallback.

### Full cloth/cable simulation as authority

Pros:

- high visual correspondence;
- emergent curves and contacts.

Cons:

- LOD, GPU execution, solver ordering, collision, and timestep can change outcomes;
- large state for networking and saves;
- visual segment count drives cost;
- hostile to deterministic prediction and authoritative validation.

Recommendation: prohibit dense cloth/cable vertices from directly deciding hit, restraint, break, or traversal.

### Client prediction

Pros:

- responsive attach, swing, reel, and detach;
- leverages established saved-move/reconciliation patterns.

Cons:

- moving anchors and coupled bodies increase error;
- denial/correction can be visually disruptive;
- more history memory and replay work.

Recommendation: predict controlled-character analytic modes; keep multipart shared-object constraints server-authoritative or selectively resimulated only after budget validation.

## ECS Architectural Integration

Components:

- `GameplayLink`: stable ID, definition/revision, authority epoch, lifecycle state, mode, owner, policy indices.
- `LinkEndpointPair`: compact endpoint descriptors or handle into a pooled endpoint table.
- `LinkLengthState`: current/target/min/max length, reel rate, slack/taut band.
- `LinkIntegrity`: health, load band, break/cut state, dwell deadline, last evidence.
- `LinkPermission`: attach, detach, reel, cut, transfer, team and hostility policy.
- `LinkPredictionState`: prediction class, last acknowledged input, correction generation.
- `LinkPersistence`: persistence class, dirty revision, journal state.
- `TraversalLinkBinding`: controlled character's active link, movement submode, exit policy.
- `MultipartProxyHandle`: generation-tagged handle only for capped proxy service state.
- `LinkPresentationState`: read-only hints for FP/TP and visual/audio adapters.

Resources:

- `GameplayLinkDefinitionRegistry`;
- `GameplayLinkStableIdMap`;
- `EndpointAdjacencyIndex`;
- `LinkCommandRing`;
- `LinkEventRing`;
- `LinkProxyPool`;
- `GrappleAcquisitionSpatialIndex`;
- `LinkConflictPolicyTable`;
- `LinkPredictionHistoryPool`;
- `LinkPersistenceJournal`;
- `LinkReplicationBudget`;
- `LinkTelemetry`.

Systems:

1. `LinkRequestAdmissionSystem`
2. `GrappleAcquisitionSystem`
3. `EndpointReservationSystem`
4. `LinkAttachCommitSystem`
5. `LinkInputAndReelSystem`
6. `AnalyticLinkConstraintSystem`
7. `MultipartProxyAdapterSystem`
8. `LinkLoadEvidenceSystem`
9. `LinkBreakDetachResolutionSystem`
10. `TraversalLinkMovementSystem`
11. `LinkInteractionAbilityAdapterSystem`
12. `LinkPersistenceSystem`
13. `LinkReplicationPredictionSystem`
14. `LinkPresentationProjectionSystem`
15. `LinkValidationTelemetrySystem`

The gameplay-link domain owns semantic state. Character movement owns controlled-character collision and final motion. The physics service owns bounded rigid constraints and proxy nodes. Cloth/cable rendering owns dense particles and meshes. Inventory/equipment owns consumable grapple items and durability. Abilities own activation/cost/cooldown. No domain mutates another directly; proposals commit through typed events and commands.

## Component, System, Resource, and Event Interfaces

Conceptual interfaces only:

- `RequestLinkAttach(RequestId, InputSequence, SourceEndpoint, TargetHint, Mode, DefinitionId, EquipmentInstanceId, DesiredLength)`
- `LinkAttachResult(RequestId, ResultCode, LinkId, LinkRevision, AcceptedEndpoints, InitialLength)`
- `CreateEndpointReservation(ReservationId, EndpointId, Generation, LinkMode, ExpiryTick)`
- `CommitLinkAttached(LinkId, LinkRevision, EndpointA, EndpointB, Mode, LengthState, Owner, FixedTick)`
- `RequestLinkInput(LinkId, ExpectedRevision, InputSequence, ReelAxis, PumpAxis, DetachPressed, ReanchorHint)`
- `ProposeLinkMotion(LinkId, LinkRevision, FixedTick, EndpointDeltas, ConstraintImpulse, ObstructionResult)`
- `SubmitLinkLoadEvidence(LinkId, LinkRevision, EvidenceId, QuantizedLoadBand, SourceKind, FixedTick)`
- `RequestLinkDamage(LinkId, ExpectedRevision, DamageEventId, Amount, DamageTags, Attribution)`
- `CommitLinkBroken(LinkId, NewRevision, Reason, EvidenceId, Attribution, FixedTick)`
- `CommitLinkDetached(LinkId, NewRevision, Endpoint, Reason, FixedTick)`
- `TraversalLinkModeChanged(CharacterId, LinkId, LinkRevision, FromMode, ToMode, EffectiveTick, ExitVelocityPolicy)`
- `EndpointInvalidated(EndpointId, Generation, Reason, EffectiveTick)`
- `PromoteMultipartProxy(LinkId, ExpectedRevision, ProxyProfileId, CapacityResult)`
- `DemoteMultipartProxy(LinkId, ExpectedRevision, AnalyticFallbackState)`
- `SerializeGameplayLink(LinkId, LinkRevision, DefinitionRevision, Endpoints, State, Length, Integrity, Ownership, PersistentProxyState)`
- `ApplyGameplayLinkCheckpoint(WorldRevision, LinkRecords[])`
- `ApplyGameplayLinkDelta(LinkId, ExpectedRevision, NewRevision, Transition)`

Required typed failures include target not found, stale endpoint generation, stale link revision, invalid attach material/region, obstructed, out of range, permission denied, endpoint capacity, equipment unavailable, world not ready, link capacity, invalid length, already attached, duplicate request, prediction rejected, anchor moved, definition mismatch, migration required, and safe fallback applied.

Events are bounded and idempotent. Raw solver callbacks, component pointers, particle arrays, and render vertices are internal implementation data.

## Integration Plan

1. **Define product modes.** Decide which of grapple swing, pull/reel, zipline, tow, suspension, tripwire, restraint/net, and hero multipart rope are actually required.
2. **Freeze link schemas.** Define stable IDs, endpoint frames, length units/quantization, lifecycle, permissions, break evidence, persistence, networking, and migration.
3. **Build analytic reference.** Implement the conceptual single-distance-link evaluator and deterministic headless reference before binding any physics backend.
4. **Integrate attachment.** Reuse interaction/ability command admission, authoritative spatial queries, endpoint reservations, equipment transactions, and world readiness.
5. **Integrate traversal.** Add grapple/zipline as explicit movement modes with saved input, correction, exit reasons, moving-anchor snapshots, collision sweeps, and FP/TP-independent behavior.
6. **Integrate break and damage.** Map cut damage, endpoint destruction, overload, expiry, and scripted events into one fixed conflict matrix.
7. **Integrate inventory and abilities.** Define ammunition/charges, cooldowns, stamina/energy, ownership, pickup/drop, durability, and recovery.
8. **Integrate AI and quests.** Provide the same attach/reel/detach commands to AI, expose bounded tactical affordances, and consume stable attach/break/rescue/capture events for objectives.
9. **Add persistence and streaming.** Restore endpoint dependencies before activation and generation-fence streamed anchors.
10. **Add networking.** Predict local analytic traversal, replicate semantic state, pack reel/detach into movement commands, and benchmark selective physics resimulation.
11. **Add presentation adapters.** Drive cable/cloth visuals, animation, camera, audio, haptics, prompts, and accessibility cues from semantic state.
12. **Gate multipart proxies.** Add only after analytic modes meet budgets; enforce node, collision, island, history, and bandwidth caps plus fallback.
13. **Certify content.** Validate endpoints, sockets, ranges, occlusion, collision clearance, break policy, persistence dependencies, and accessible alternatives.

## Verification Strategy

### State-machine and conflict tests

- Exhaustively test every legal and illegal lifecycle transition.
- Permute same-tick attach, detach, cut, overload, endpoint destruction, reanchor, reel, equipment loss, death, pause, travel, and unload.
- Duplicate/reorder commands and solver callbacks; one semantic transition commits.
- Change authority epoch, endpoint generation, definition revision, and socket revision at every phase.

### Geometry and traversal tests

- Sweep attach range, aim cone, line of sight, thin/concave/moving targets, doors, destructibles, water, vehicles, elevators, rotating anchors, slopes, ceilings, and world-origin shifts.
- Test zero length, min/max length, excessive slack, taut boundary hysteresis, obstruction while reeling, wrapping denial, penetration, high velocity, and teleport.
- Verify detach velocity, fall transitions, landing, ledge/mantle conflicts, ladder/water entry, knockback, downed/death, carry, and camera perspective switches.
- FP and TP produce identical authoritative outcomes.

### Multiplayer and prediction tests

- Simulate latency, jitter, loss, duplication, reordering, bandwidth caps, cheating targets/lengths, and moving anchors.
- Correct at every predicted attach, reel, pump, detach, break, and mode transition; replay saved inputs without duplicate cost or event.
- Test two players linking the same endpoint, towing each other, opposing reel inputs, hostile restraint, owner disconnect, host migration, reconnect, late join, and spectating.
- Compare server-only, predictive interpolation, and resimulation budgets for hero proxies.

### Persistence, replay, and streaming tests

- Save/load in every state and during pending attach/break/detach transactions.
- Unload either or both endpoints, then reload in every order.
- Reconstruct late join and replay from checkpoint plus every delta prefix.
- Test removed/moved anchors, content redirects, definition migration, missing equipment, cross-level links, and tombstones.
- Confirm visual cable state may diverge without changing collision, traversal, break, restraint, or objectives.

### Performance and capacity tests

- Sweep active links, attach queries, shared-endpoint degree, analytic constraints, multipart nodes, iterations, collision candidates, interested clients, RTT history, and persistent links.
- Verify allocation-free warm ticks and no managed GC.
- Randomize worker order and validate deterministic commits.
- Force every pool/event/history/network overflow and verify typed degradation.
- Record fixed-step time, constraint time, cache misses, allocations, query candidates, correction error, resimulation ticks, save bytes, late-join time, and network bytes.

### Accessibility, telemetry, and validation

- Support hold/toggle options, simplified aim, generous but policy-bounded target acquisition, auto-release safety, camera-roll reduction, motion/haptic intensity, nonvisual tension/break cues, and alternative paths for rope-required objectives.
- Prevent color-only slack/load/break communication.
- Telemetry distinguishes acquisition failure, permission denial, obstruction, correction, overload, voluntary detach, endpoint loss, and capacity fallback.
- Headless content tests exercise every authored endpoint and zipline, verify reachability/clearance, and certify maximum shared-endpoint degree.

## Risks and Open Decisions

- Which link modes ship in the first release?
- Is grapple acquisition hitscan, swept projectile, simulated projectile, authored anchor targeting, or a hybrid?
- What lag-compensation window and historical geometry apply to grapple hits?
- Which surfaces/entities/characters can be anchors, and who may attach?
- Can anchors move, stream, teleport, be destroyed, change scale, or transfer ownership?
- Does the character use analytic constraint movement, rigid-body physics, or mode-specific hybrids?
- How much air control, pumping, reel acceleration, stamina, and detach impulse is allowed?
- Is rope wrapping unsupported, authored through guide points, or enabled only for hero proxies?
- What load measure drives breakage, and how is it normalized across timestep/backend?
- Which breaks are damage, overload, cut, expiry, endpoint loss, or voluntary detach?
- Can ropes be repaired, reattached, picked up, traded, or recovered?
- What happens to links on downing, death, respawn, travel, checkpoint reload, disconnect, or party change?
- Are tow/restraint links consensual, team-only, hostile crowd-control, or immunity-gated?
- How do multiple reelers or linked-body islands resolve authority and input?
- What is the maximum endpoint degree, chain depth, node count, collision count, and resimulation history?
- Which link state persists, and who owns cross-cell or cross-session links?
- Are persistent links allowed to target procedural/destructible anchors?
- Which semantic events grant quest credit and to whom?
- What anti-cheat evidence and retention are required?
- Which accessibility assists are allowed in competitive modes?

## Engineering Recommendations

These are engineering recommendations, not sourced facts.

1. Create a dedicated gameplay-link domain; do not treat rope as a visual component, inventory boolean, or untyped physics joint.
2. Separate stable semantic link state, bounded gameplay constraint proxy, and dense presentation simulation.
3. Use stable generation-fenced endpoints and revisioned idempotent attach/reel/detach/break commands.
4. Start with analytic single-distance grapple/tether and parametric zipline proxies; defer multipart physical ropes until a proven gameplay need survives performance and networking tests.
5. Integrate grapple and zipline as explicit predicted traversal modes with anchor/length/revision in saved moves.
6. Let authority reconstruct attach acquisition and validate range, line of sight, material, permissions, capacity, costs, world readiness, and endpoint generation.
7. Quantize length and input, apply fixed-step reel rates, use slack/taut hysteresis, and define obstruction behavior without teleporting characters.
8. Separate backend force samples from gameplay load evidence and break policy; never assume one solver callback is a portable deterministic break decision.
9. Freeze an exhaustive same-tick conflict order, with endpoint invalidation and accepted break evidence preceding voluntary detach and reel.
10. Replicate compact semantic link state and controlled movement, not cable/cloth particles. Restrict resimulation to controlled or high-value links.
11. Persist semantic aggregates and minimal proxy state only; rebuild presentation and ordinary solver state after load.
12. Store visual particles and multipart nodes outside ECS; ECS holds aggregate components and generation-tagged proxy handles.
13. Provide bounded AI, quest, damage, equipment, status-effect, and interaction adapters through typed events.
14. Require hard budgets for link count, endpoint degree, attach queries, proxy nodes, collision candidates, shared islands, history, serialization, and bandwidth.
15. Ship link inspectors, endpoint visualization, prediction history, break evidence traces, deterministic race tests, capacity tests, and content certification.
16. Make authoritative behavior perspective-independent and provide camera comfort, simplified targeting, nonvisual cues, and alternate-objective accessibility policies.

## Source Links

1. Epic Games, **Physics Constraints — Unreal Engine 5.8**  
   https://dev.epicgames.com/documentation/en-us/unreal-engine/physics-constraints-in-unreal-engine
2. Epic Games, **Physics Constraint Component API — Unreal Engine 5.8**  
   https://dev.epicgames.com/documentation/en-us/unreal-engine/API/Runtime/Engine/UPhysicsConstraintComponent
3. Epic Games, **Physics Constraint Reference — Unreal Engine 5.8**  
   https://dev.epicgames.com/documentation/unreal-engine/physics-constraint-reference-in-unreal-engine
4. Epic Games, **Cable Components — Unreal Engine 5.8**  
   https://dev.epicgames.com/documentation/unreal-engine/cable-components-in-unreal-engine
5. Epic Games, **Networked Movement in the Character Movement Component — Unreal Engine 5.8**  
   https://dev.epicgames.com/documentation/en-us/unreal-engine/understanding-networked-movement-in-the-character-movement-component-for-unreal-engine
6. Epic Games, **Networked Physics Overview — Unreal Engine 5.8**  
   https://dev.epicgames.com/documentation/unreal-engine/networked-physics-overview
7. Epic Games, **Movement Components — Unreal Engine 5.8**  
   https://dev.epicgames.com/documentation/en-us/unreal-engine/movement-components-in-unreal-engine
8. NVIDIA, **PhysX 5.1.1 Joints**  
   https://nvidia-omniverse.github.io/PhysX/physx/5.1.1/docs/Joints.html
9. NVIDIA, **PhysX 5.3.1 PxDistanceJoint API**  
   https://nvidia-omniverse.github.io/PhysX/physx/5.3.1/_api_build/class_px_distance_joint.html
10. Epic Games, **Physics Components — Unreal Engine 5.8**  
    https://dev.epicgames.com/documentation/unreal-engine/physics-components-in-unreal-engine
11. Macklin, Müller, and Chentanez, **XPBD: Position-Based Simulation of Compliant Constrained Dynamics**  
    https://matthias-research.github.io/pages/publications/XPBD.pdf

