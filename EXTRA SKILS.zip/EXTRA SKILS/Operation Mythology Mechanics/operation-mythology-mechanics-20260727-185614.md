# Operation Mythology Mechanics Research

**Timestamp:** 2026-07-27T18:56:14-07:00  
**Subject:** Gameplay-to-presentation cue architecture: prediction, confirmation, rejection, deduplication, audience filtering, accessibility, replay, and bounded VFX/audio/UI adapters

## Feature Overview

Gameplay cues translate semantic state changes into perceivable feedback: hit confirmation, damage direction, status activation, cooldown completion, interaction progress, objective updates, traversal transitions, warnings, death/revive, equipment changes, and environmental events. The cue architecture must keep gameplay authority independent of particles, audio, animation, camera, haptics, and UI while still providing responsive predicted feedback and reliable information through multiple sensory channels.

The proposed separation is:

1. **Authoritative semantic event or state:** damage committed, effect added, ability activated, objective advanced, interaction claimed, traversal changed, and similar gameplay truth.
2. **Cue intent:** a small typed, revisioned, audience-filtered description of what information should be conveyed, with source/target, prediction identity, spatial context, importance, lifetime semantics, and privacy class.
3. **Presentation adapters:** VFX, audio, haptic, camera, UI, subtitle/text, icon, animation, and accessibility renderers that independently express the cue under local settings and budgets.

GPU particles and visual event graphs may generate internal presentation events, but they never apply damage, grant rewards, advance objectives, change collision, or create authoritative commands. When a visual event must affect gameplay, gameplay schedules the semantic event first and presentation follows it.

## Existing Coverage and Identified Gap

The mandatory recursive scan succeeded:

- `C:\Users\steve\Desktop\GAME SKILLS`: 29 files at scan time.
- `C:\Users\steve\Desktop\EXTRA SKILS\Operation Mythology Mechanics`: 28 files at scan time, including `RESEARCH_INDEX.md`.

The new shared GPU particle/VFX report covers compiled effect graphs, GPU simulation, bounded GPU/CPU events, collision tiers, significance, multiview rendering, and hard budgets. It explicitly states that CPU-facing effect events are bounded and non-authoritative. The new shader report is outside mechanics scope.

Existing mechanics reports cover gameplay tags/events/commands, abilities/effects, prediction and rollback, camera, accessibility, telemetry, multiplayer, and replay. They mention gameplay cues and presentation events incidentally, but no report defines:

- one cross-domain cue envelope;
- predicted, confirmed, rejected, corrected, persistent, and removed cue lifecycles;
- deduplication between local prediction and server confirmation;
- reliable semantic state versus lossy cosmetic notifications;
- audience, privacy, occlusion, spatial, and ownership filtering;
- multichannel accessibility requirements;
- cue importance, concurrency, rate, pooling, and degradation budgets;
- late join, replay, killcam, pause, time dilation, world travel, and streaming behavior;
- tooling to trace a semantic event through all presentation adapters;
- prohibition and validation of GPU-to-gameplay authority.

This is a direct gameplay-facing interface and is not duplicate VFX research.

## Sourced Facts

These are sourced facts; recommendations are separated below.

1. Unreal Engine 5.8 describes Gameplay Cues as Actors and UObjects that run visual and sound effects and calls them the preferred method for replicating cosmetic feedback in multiplayer.

2. Epic explicitly states that Gameplay Cues do not use reliable replication and warns that gameplay code tied to them can desynchronize. Epic recommends replicated Ability Tasks for gameplay-relevant feedback that must reach clients. This establishes a critical distinction between cosmetic cue delivery and authoritative/reliable state.

3. Unreal's Gameplay Ability System supports locally predicted abilities where the server has final authority. Epic states that a rejected predicted ability must undo local changes, and that many non-instant Gameplay Effects can roll back while instantaneous damage is a notable exception. A cue system must therefore distinguish reversible predicted presentation from confirmed irreversible outcomes.

4. Gameplay Cues may be associated with Gameplay Effect tags or triggered independently; Epic cites Lyra weapon firing feedback as an independent example. This supports a data-driven cue registry not limited to status effects.

5. Unreal's Gameplay Ability System replicates only selected information rather than full ability/effect state to every client, in part for bandwidth and cheating concerns. Cue audiences likewise cannot assume every observer receives identical hidden context.

6. The shared GPU particle/VFX report establishes that full particle state should not synchronously return to CPU, GPU events require bounded append buffers and delivery rules, and gameplay collision uses a separate proxy. It recommends delayed or diagnostic readback only and treats VFX as service-owned presentation state.

7. Microsoft Xbox Accessibility Guideline 103 says important visual and audio cues should be conveyed through multiple sensory methods so players with vision or hearing loss can perceive information such as gunfire, incoming damage, interactables, and objectives. It also warns against relying on color alone.

8. Microsoft's general game-accessibility guidance recommends useful 3D audio cues, separate volume controls, and meaningful spoken information. These are presentation choices driven by semantic cue data.

9. Engine APIs do not define one universal cue reliability, priority, privacy, prediction, deduplication, replay, or degradation policy. Those are project-specific.

## Industry-Standard API or Pattern

Use a **semantic cue-intent bus with prediction-aware lifecycle and local multichannel routing**.

### Cue definition and envelope

Each immutable cue definition declares:

- stable `CueTypeId` and `DefinitionRevision`;
- semantic source event/state kinds;
- lifecycle: one-shot, duration, persistent-until-removed, loop, progress, or state snapshot;
- prediction policy: never predicted, provisional, promotable, replace-on-confirm, or local-only;
- confirmation/rejection/correction behavior;
- audience policy: owner, instigator, target, team, nearby, relevant observers, spectators, replay, or custom authorized set;
- privacy class and parameter redaction rules;
- spatial policy: world point, source/target entity, attachment socket, screen-space, nonspatial, or directional;
- importance, concurrency group, rate class, cooldown/coalescing window, and maximum instances;
- required information channels such as visual, audio, haptic, text/icon, directional indicator, or screen-reader narration;
- local presentation variants and fallbacks;
- save/replay/late-join behavior;
- telemetry and content-validation requirements.

Cue envelopes contain:

- stable `CueInstanceId` or event ID;
- `CueTypeId` and definition revision;
- authoritative source event ID, fixed tick, and semantic revision;
- prediction key and phase: predicted, confirmed, rejected, corrected, removed;
- source/target stable IDs and generations;
- quantized location/direction/magnitude/duration/progress;
- compact typed parameters using an allowlisted schema;
- audience/privacy classification;
- importance and expiry;
- clock domain and world/travel generation.

No arbitrary object pointers, particle handles, hidden gameplay objects, or free-form maps cross this interface.

### Prediction and deduplication

For locally predicted actions:

1. Local gameplay prediction emits a provisional cue with a prediction key and predicted source event.
2. The cue router starts only variants declared reversible or promotable.
3. Server confirmation carries the same prediction key plus authoritative event/cue ID and corrected parameters.
4. Router promotes the provisional instance without replaying it, or smoothly corrects the declared fields.
5. Server rejection emits a rejection/absence result; router cancels, fades, retracts, or replaces the provisional cue according to definition.
6. A confirmation received without the provisional instance starts normally.

Deduplication key includes connection/participant generation, prediction key, cue type, source/target generation, and semantic phase. Server event IDs prevent duplicate confirmed delivery. Do not deduplicate unrelated repeated hits merely because they share a type and target.

Persistent cues use desired state rather than unreliable one-shot delivery: `ApplyOrUpdate(CueInstanceId, Revision, Parameters)` and `Remove(CueInstanceId, Revision)`. Clients entering relevance reconstruct active cue snapshots. Lossy notifications may embellish state but never own it.

### Reliability classes

- **Authoritative state projection:** tags, effect state, objective state, health, interaction claim, or another reliable/reconstructible channel. Cue derives locally.
- **Reliable informational event:** a bounded event whose absence would deny required gameplay information but does not mutate gameplay. Deliver through the established reliable/event journal, not a cosmetic-only cue RPC.
- **Loss-tolerant cosmetic event:** muzzle flash, minor debris, incidental sound, and similar embellishment.
- **Local prediction cue:** reversible immediate feedback.
- **Local-only UI/accessibility cue:** derived from authorized local state and settings.

The cue service never upgrades a lossy visual callback into authoritative state.

### Audience and privacy

Authority or an authorized projection service determines recipients from semantic visibility, ownership, party/team, distance/interest, occlusion policy, spectator rules, and anti-cheat constraints. Then it redacts parameters:

- owner can receive exact cooldown completion or treatment progress;
- allies may receive coarse revive/help states;
- enemies may receive only observable audiovisual evidence;
- hidden damage source, stealth status, quest branch, or exact health must not leak through cue payloads, asset variants, timing, logs, or telemetry.

Client presentation may further suppress or substitute cues for accessibility, comfort, photosensitivity, gore, streamer, or performance settings, but cannot reveal more information.

### Multichannel accessibility routing

Definitions classify semantic importance and required information, not one hardwired effect. A local accessibility router selects:

- visual world effect or HUD indicator;
- spatialized/nonspatial audio or speech;
- haptic pattern with intensity control;
- directional damage/threat indicator;
- subtitle, icon, text, or screen-reader message;
- simplified low-motion/low-flash replacement;
- persistent state indicator if a transient cue could be missed.

Critical cues require at least two configured perceptual channels where appropriate. Color is paired with shape, text, position, pattern, or audio. Local settings may reduce particle density without suppressing the semantic warning.

### Concurrency, coalescing, and degradation

Route by priority and concurrency group:

- critical state/warning cues are reserved and cannot be displaced by cosmetics;
- repeated low-importance hits may aggregate magnitude/count within a short window;
- mutually exclusive loops replace by revision;
- same-source footstep/impact families rate-limit;
- closest/highest/owner-important cues win within declared caps;
- offscreen cues may convert to directional HUD/audio rather than disappear;
- VFX degradation may reduce particles while audio/UI/haptic remain.

Every overflow has observable counts and a deterministic fallback. Do not allow one combat burst to allocate or spawn unbounded actors, audio voices, UI widgets, or GPU emitters.

### Clocks, pause, travel, replay, and late join

Cue definitions declare game, real, UI, audio, cinematic, or fixed-simulation clock. Pause and time dilation follow that clock. World-attached cues carry world/travel generation and end or migrate explicitly on unload/travel.

Replay records authoritative semantic events/cue intents required for faithful communication, not particle state. Scrubbing reconstructs persistent cue state at the target time and restarts only appropriate loops; one-shots use replay-window policy. Late join receives persistent cue snapshots and current semantic state, not historical cosmetic one-shots.

## Performance Considerations

### Asymptotic complexity

Let `E` be cue intents this tick, `S` active persistent cues, `A` adapters/channels, `R` recipients, and `K` local candidate variants.

- Intent admission/dedup is expected `O(E)` with hash tables; stable ordering may add `O(E log E)`.
- Audience construction should reuse interest/team/ownership sets and costs approximately `O(relevant recipients)` rather than scanning all clients per cue.
- Local routing is `O(E*A)` with a small fixed adapter count.
- Concurrency selection is `O(K)` per bounded group or `O(K log K)` with priority heaps.
- Persistent reconciliation is `O(Sdirty)` per delta and `O(Srelevant)` for late-join snapshots.
- Network cost is `O(R * compact payload)` for transmitted intents, but most cues should derive from already replicated semantic state.

### Allocations and garbage collection

Use pooled fixed-size cue envelopes, bounded per-tick rings, stable interned IDs, typed parameter unions, fixed concurrency slots, pooled presentation instances, and adapter-owned arenas. Warm gameplay and presentation routing allocate nothing from the general heap and trigger no managed garbage collection. Avoid spawning an Actor/UObject/widget/audio component per transient cue when a pool or batched service suffices. Overflow coalesces or degrades by declared policy and records telemetry.

### Cache behavior

Store hot envelope fields in structure-of-arrays batches by cue type/audience/channel. Keep cold localization, asset references, privacy explanations, author notes, and debug history separate. Compile definitions to numeric IDs, compact routing masks, variant tables, and parameter offsets. Sort/bucket adapter work by asset/program/concurrency class. Avoid tag-string lookup, reflection, and pointer traversal on the hot path.

### Update frequency

One-shots route on event arrival. Persistent cues update only when semantic revision or relevant parameter changes. Progress cues use quantized rate-limited updates and local interpolation. Cue lifetime/expiry uses deadline wheels instead of scanning all instances each frame. VFX/audio/UI adapters update at their natural frequencies. Telemetry aggregates per interval. Network messages are event/state-driven.

### Concurrency

Semantic systems emit immutable cue intents after commit. Audience filtering and local routing can parallelize by batch/recipient, but per-cue lifecycle transitions serialize by `CueInstanceId` revision. Adapters own their mutable instances. GPU VFX receives command buffers asynchronously and cannot call back into gameplay. Audio/UI/haptics consume read-only envelopes. Replay/save extraction reads committed cue state. Pool allocation uses per-worker caches or staged single-writer commits.

### Fixed-step cost

Gameplay fixed step should only create compact intents and persistent-state deltas; asset lookup, object creation, audio mixing, widget layout, and GPU work occur outside the authoritative barrier. Cap intents, parameters, audience expansion, and reliable informational events per tick. Critical intents reserve capacity; low-priority cosmetics coalesce/drop. Cascading cues may not emit unbounded new semantic or cue events.

### Serialization cost

Most transient local cues are not saved. Reliable/replay cue intents serialize stable IDs, revisions, fixed ticks, quantized parameters, and redacted audience data. Persistent cue snapshots serialize desired state, not adapter handles or particle/audio/UI state. Use bit masks, varints, fixed schemas, and definition revisions. Replay compression can dictionary-code type/source IDs and delta ticks.

### Networking cost

Prefer local cue derivation from replicated semantic state. When transmitting cue intents, quantize spatial/parameter data, batch by tick/recipient, apply interest/privacy filtering, and choose reliable or loss-tolerant transport according to information class. Prediction keys deduplicate confirmations. Persistent snapshots are sparse. Track bytes by cue type/audience, reliable queue pressure, duplicate/promote/reject rates, late-join size, and information-leak tests. Never replicate GPU particle state.

## Pros and Cons

### Central semantic cue-intent bus

Pros:

- consistent prediction, deduplication, privacy, replay, accessibility, and budgeting;
- gameplay remains independent of presentation engines;
- cross-channel fallback is testable;
- one trace connects source event to all outputs.

Cons:

- schema/definition governance cost;
- risk of an overly generic payload;
- central router can become a bottleneck without compiled data and bounded adapters.

### Direct effects from gameplay code

Pros:

- fast for prototypes and isolated cases.

Cons:

- duplicates logic across VFX/audio/UI/camera;
- inconsistent multiplayer and accessibility;
- difficult to cancel prediction or deduplicate confirmation;
- bypasses budgets and privacy;
- hard to replay and test.

### Derive cues only from replicated state

Pros:

- naturally reconstructible and robust to packet loss;
- minimal separate networking.

Cons:

- may lose event provenance, direction, magnitude, or timing;
- state polling can repeat cues;
- some one-shot events need an explicit journal.

Recommendation: derive persistent/ongoing cues from state and use bounded event intents for genuinely transient information.

### Reliable delivery for all cues

Pros:

- fewer missed events.

Cons:

- queue pressure, head-of-line delay, excess bandwidth, and stale cosmetics.

Recommendation: reserve reliability for required information not otherwise reconstructible.

## ECS Architectural Integration

Components:

- `CueSourceProjection`: source entity stable ID/generation and allowed semantic cue mask.
- `PersistentCueSetHandle`: generation-tagged handle to compact active desired-state records.
- `CueAudienceClass`: ownership/team/privacy/interest policy.
- `CuePredictionContext`: participant generation, prediction key range, acknowledgement state.
- `CuePresentationHints`: perspective-independent spatial/importance data only.
- `CueAccessibilityClass`: required information category and allowed substitutions.

Resources:

- `CueDefinitionRegistry`;
- `CueIntentRing`;
- `CuePersistentStateStore`;
- `CueDeduplicationTable`;
- `CueAudienceResolver`;
- `CuePrivacySchema`;
- `CueDeadlineWheel`;
- `CueConcurrencyBudget`;
- `CueAdapterRegistry`;
- `CueReplayJournal`;
- `CueTelemetry`;

Systems:

1. `SemanticCueProjectionSystem`
2. `PredictedCueLifecycleSystem`
3. `CueAudienceAndPrivacySystem`
4. `CueAdmissionDeduplicationSystem`
5. `PersistentCueReconciliationSystem`
6. `CueAccessibilityRoutingSystem`
7. `CueConcurrencyBudgetSystem`
8. `CueAdapterDispatchSystem`
9. `CueExpiryAndCleanupSystem`
10. `CueReplayLateJoinSystem`
11. `CueValidationTelemetrySystem`

ECS owns compact semantic projections and handles. The cue service owns instances and routing. VFX, audio, haptics, camera, UI, subtitles, screen-reader, and animation adapters own their presentation state. None can mutate gameplay.

## Component, System, Resource, and Event Interfaces

Conceptual interfaces:

- `EmitCueIntent(CueTypeId, DefinitionRevision, SourceEventId, FixedTick, Source, Target, SpatialContext, TypedParameters, AudienceClass, Importance)`
- `EmitPredictedCue(PredictionKey, CueTypeId, Source, TargetHint, Parameters)`
- `ConfirmPredictedCue(PredictionKey, AuthoritativeCueId, SourceEventId, CorrectedParameters, Revision)`
- `RejectPredictedCue(PredictionKey, Reason, ReplacementCueId?)`
- `ApplyOrUpdatePersistentCue(CueInstanceId, Revision, CueTypeId, Owner, Parameters, AudienceClass)`
- `RemovePersistentCue(CueInstanceId, ExpectedRevision, Reason)`
- `ResolveCueAudience(CueId, SemanticVisibility, InterestSnapshot, PrivacyClass)`
- `RouteCueLocally(CueEnvelope, LocalSettings, DeviceCapabilities, ActiveViewSet)`
- `CueAdapterResult(CueId, Channel, Started|Promoted|Corrected|Suppressed|Degraded|Dropped|Completed, Reason)`
- `SerializeCueReplayEvent(CueId, FixedTick, Type, Phase, RedactedParameters)`
- `BuildLateJoinCueSnapshot(ConnectionId, RelevantSemanticStateRevision)`

Typed outcomes include stale revision, duplicate, predicted promoted, rejected, privacy redacted, audience empty, definition missing, parameter invalid, world generation stale, concurrency suppressed, capacity degraded, accessibility fallback, adapter unavailable, and replay-only suppression.

## Integration Plan

1. Inventory all existing hit, ability, status, interaction, traversal, objective, lifecycle, equipment, and environment feedback.
2. Classify each as authoritative state projection, reliable information, loss-tolerant cosmetic, predicted local, or local-only accessibility/UI.
3. Define the compact cue envelope, prediction identity, revision semantics, audience/privacy schemas, clock domains, and parameter types.
4. Compile cue definitions and validate required channels, fallbacks, caps, and redaction.
5. Integrate predicted ability/input events with promote/reject/correct lifecycle.
6. Derive persistent cues from existing tags/effects/objectives/interactions rather than parallel booleans.
7. Build VFX, audio, haptic, camera, UI, subtitle, screen-reader, and animation adapters.
8. Add importance/concurrency groups, pools, coalescing, deadlines, and deterministic overflow.
9. Add late join, replay, scrubbing, pause, time dilation, travel, streaming, spectating, and killcam policy.
10. Add privacy/security tests and prevent hidden parameters/assets/timing from leaking state.
11. Add multichannel accessibility presets and per-channel controls.
12. Ship a cue inspector tracing semantic event, network delivery, prediction, routing, suppression, and adapter outcomes.

## Verification Strategy

- Schema tests reject missing revisions, arbitrary payloads, invalid spatial references, absent privacy policy, no critical fallback, and unbounded concurrency.
- Prediction tests cover confirm-before-local, local-before-confirm, duplicate confirmation, rejection, correction, timeouts, reconnect, participant-generation change, and prediction-key wrap.
- Persistent tests reorder/duplicate/drop apply/update/remove messages and rebuild from authoritative state/late-join snapshots.
- Network tests simulate loss, jitter, reliable backlog, interest entry/exit, team change, spectator, replay, and travel.
- Privacy tests verify hidden attacker, stealth, health, cooldown, quest, and inventory data cannot leak through parameters, asset choice, timing, logs, or telemetry.
- Accessibility tests disable each channel in turn; critical information remains perceivable through configured alternatives and never relies on color alone.
- Performance sweeps cover intents/tick, persistent cues, recipients, adapters, concurrency groups, pooled instances, UI widgets, audio voices, VFX emitters, and replay events.
- Assert warm routing is allocation-free with no managed GC; force every overflow and verify deterministic degradation.
- GPU event tests prove delayed, duplicated, missing, or overflowing VFX callbacks never change gameplay.
- Replay scrubbing tests persistent reconstruction and one-shot window behavior.
- FP/TP, split-screen, spectator, multi-view, and camera transitions change local presentation only.

## Risks and Open Decisions

- Which cue classes are required information versus cosmetic?
- Which events need reliable delivery instead of state derivation?
- Which predicted cues may promote, correct, retract, or never predict?
- How long are prediction/dedup entries retained?
- What audience and privacy rules apply to enemies, allies, spectators, replays, and streamers?
- Which parameters may be redacted or quantized?
- Which critical cues require visual, audio, haptic, text, directional, or screen-reader alternatives?
- What photosensitivity, motion, gore, audio, haptic, and clutter controls ship?
- How are repeated hits, damage ticks, footsteps, objective spam, and crowd effects coalesced?
- What are per-type, per-source, per-view, per-channel, per-frame, and per-connection caps?
- How do pause, time dilation, loading, travel, cinematic, split-screen, and replay clocks behave?
- Which persistent cues survive pawn death, respawn, possession, reconnect, or level transition?
- Is cue telemetry permitted to contain source/target identity and sensitive game state?
- What release gates ensure gameplay never depends on cosmetic delivery?

## Engineering Recommendations

These are engineering recommendations, not sourced facts.

1. Establish one typed semantic cue-intent contract between gameplay and all presentation channels.
2. Keep authoritative state and required reliable information outside loss-tolerant cosmetic cue delivery.
3. Give predicted cues explicit promote, correct, reject, timeout, and deduplication behavior keyed by participant generation and prediction key.
4. Model ongoing cues as revisioned desired state so late join and packet loss reconstruct correctly.
5. Resolve audience and redact parameters before local presentation; test assets, timing, logs, and telemetry for information leaks.
6. Require multiple sensory channels for critical information and prohibit color-only meaning.
7. Let local accessibility and performance settings substitute presentation without altering semantic state or exposing hidden information.
8. Use hard concurrency, rate, instance, memory, voice, widget, GPU, and network budgets with reserved critical capacity and deterministic degradation.
9. Derive persistent feedback from existing tags/effects/objectives/interactions instead of maintaining duplicate cue truth.
10. Record semantic/reliable cue events for replay, not particles or adapter objects.
11. Treat GPU/visual events as presentation-local; any gameplay consequence must originate from an authoritative scheduled event or proxy.
12. Keep cue hot paths compiled, numeric, pooled, typed, allocation-free, and independent of reflection/string tag lookup.
13. Ship end-to-end cue tracing, prediction diagnostics, audience/privacy inspection, accessibility validation, overflow injection, replay scrubbing, and network-loss tests.

## Source Links

1. Epic Games, **Understanding the Gameplay Ability System — Unreal Engine 5.8**  
   https://dev.epicgames.com/documentation/en-us/unreal-engine/understanding-the-unreal-engine-gameplay-ability-system
2. Epic Games, **Gameplay Ability System — Unreal Engine 5.8**  
   https://dev.epicgames.com/documentation/unreal-engine/gameplay-ability-system-for-unreal-engine
3. Epic Games, **Using Gameplay Abilities — Unreal Engine 5.8**  
   https://dev.epicgames.com/documentation/unreal-engine/using-gameplay-abilities-in-unreal-engine
4. Epic Games, **Ability System Component and Gameplay Attributes — Unreal Engine 5.8**  
   https://dev.epicgames.com/documentation/en-us/unreal-engine/gameplay-ability-system-component-and-gameplay-attributes-in-unreal-engine
5. Microsoft, **Xbox Accessibility Guideline 103: Additional channels for visual and audio cues**  
   https://learn.microsoft.com/en-us/xbox/accessibility/xbox-accessibility-guidelines/103
6. Microsoft, **Making games accessible**  
   https://learn.microsoft.com/en-us/windows/uwp/gaming/accessibility-for-games
7. Microsoft, **Xbox Accessibility Guidelines**  
   https://learn.microsoft.com/en-us/xbox/accessibility/guidelines
8. Microsoft, **Gaming and Disability Player Experience Guide**  
   https://learn.microsoft.com/en-us/xbox/accessibility/gadpeg

