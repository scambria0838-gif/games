# Operation Mythology Mechanics Delta Research — Session Continuity, Reconnect, Late Join, and Host Migration

**Timestamp:** 2026-07-27T02:38:37-07:00  
**Scope:** Lobby/session/match separation, participant continuity, disconnect grace, authenticated reconnect, duplicate login, late join, join-in-progress snapshots, dedicated-server recovery, peer-host election, authoritative state migration, ownership transfer, security, ECS interfaces, performance, and validation.

## Feature Overview

Operation Mythology needs an explicit continuity policy for temporary disconnects, application restart, late join, server travel, host loss, and backend outage. These are not one generic “reconnect” feature.

The governing model separates:

- **Lobby continuity:** social group, invitations, membership, leader, desired activity, and current match locator.
- **Online-session continuity:** authenticated membership, connection route, join policy, reserved slots, and reconnect eligibility.
- **Participant continuity:** durable in-match player identity and authoritative gameplay state independent of socket, controller, or pawn.
- **Match continuity:** authoritative world state, tick/configuration epoch, rules, objectives, ownership, and history.
- **Presentation continuity:** loading, reconnect UI, local input suppression, progress, failure choices, and cue deduplication.

Recommended product baseline:

1. Prefer a dedicated authoritative server for competitive or progression-sensitive matches.
2. Support authenticated participant reconnect and late join through versioned authoritative snapshots plus ordered catch-up.
3. Treat replacement-server recovery as checkpoint-and-journal restoration, not peer host election.
4. If peer hosting is required, make host migration an explicitly bounded mode with periodic migration snapshots, deterministic election policy, state-loss bounds, and stricter eligibility/security rules.
5. Never infer that lobby leader migration also migrates the authoritative simulation.

## Existing Coverage and Identified Gap

The mandatory recursive scan for this batch found 14 files in `C:\Users\steve\Desktop\GAME SKILLS` and 13 files in the dedicated mechanics folder. No filesystem error occurred. The shared tree contains a new general networking report covering authoritative snapshots, prediction, bounded rollback, interest, quantization, and command transport. Mechanics reports already establish:

- participant identity independent of connection and pawn;
- reconnect tombstones and versioned transfer manifests;
- hierarchical session/match/player flow;
- authoritative snapshots, command history, replay, and deterministic state hashes;
- idempotent inventory, quest, reward, and save transactions;
- private/public replication projections;
- server rewind and anti-cheat boundaries.

However, reconnect, duplicate login, late join, host migration, ownership during disconnect, session restoration, and host-loss recovery remain open across multiple reports. No report defines which state is required, how a replacement authority is selected and fenced, how a reconnect differs from a new join, how clients are caught up, or what loss/duplication/security limits apply.

This is a new cross-system contract. It does not duplicate snapshot replication or rollback algorithms; it specifies how those facilities are used at continuity boundaries.

## Sourced Facts

The following are sourced facts, not Operation Mythology recommendations:

- Unity Multiplayer Services separates host election from data migration and explicitly states that host election does not migrate network-synchronized data. Its host-migration workflow exposes separate host-changed and migration-completed events.
- Unity documents host migration for both voluntary and involuntary loss. Its session integration can periodically upload migration snapshots, with configurable snapshot interval and upload timeout, and requires a migration-data handler to capture and apply synchronized state.
- Unity's current documentation states that reconnect is available only while the disconnected player remains a session member. Once removed, the player must join again. Session configuration exposes separate disconnect-removal and disconnected-host-migration timing.
- Unity distinguishes session-scoped data from player-scoped data and applies different visibility and write permissions. It also warns clients that a session can be removed or become unavailable and that session-targeting calls can fail.
- Epic's Unreal Online Services Lobbies interface separates a lobby from a game session: a lobby can span several matches and can carry the current match session ID as an attribute. It exposes lobby restoration, member disconnect reasons, leader promotion, and leader-change notification.
- Epic's `RestoreLobbies` is intended to rejoin lobbies previously joined by a local player at application startup. This restores lobby participation; the documentation does not claim that it restores an authoritative match world.
- Valve Steamworks states that a Steam lobby always has an owner and automatically assigns another member if the current owner leaves. It also permits the current owner to transfer ownership to another member.
- Steam lobby metadata is group metadata distributed to lobby members. Steam's lobby documentation directs higher-volume game traffic to the networking APIs; lobby ownership is not an authoritative game-state snapshot protocol.

Together, these sources demonstrate a consistent industry boundary: group/session leadership can be reassigned by a service, but live gameplay continuity additionally requires authoritative state capture, transfer, restoration, connection rerouting, and validation.

## Industry-Standard API or Pattern

### Continuity identity hierarchy

Use distinct stable identities and epochs:

- `lobby_id`: social grouping, potentially spanning matches;
- `session_id`: online membership and connection contract;
- `match_id`: one authoritative rules/world history;
- `participant_id`: durable player slot within a match;
- `authority_epoch`: monotonically increasing generation of the authoritative host/server;
- `world_epoch`: world/travel/origin generation;
- `connection_id`: ephemeral transport binding;
- `pawn_id`: replaceable avatar projection.

Every authoritative message and snapshot carries the relevant match and authority epochs. A newly elected or restored authority must use a strictly newer epoch. Clients reject old-authority traffic after accepting the new epoch.

### Reconnect versus rejoin

**Reconnect** resumes an existing participant before its grace/tombstone expires. It requires:

`authenticate account/platform -> locate joined session/match -> present single-use resume proof -> reserve connection generation -> fence prior connection -> validate compatibility -> bind connection to participant -> send sectional resync -> activate input after ready barrier`

**Rejoin** creates or reactivates membership after removal. It follows current join policy, capacity, anti-abuse, team balancing, and late-join rules and may create a new participant identity.

Do not allow a transport connection alone to claim an old participant. Resume proof binds account, participant, session/match, authority epoch, expiry, nonce, and intended device/session policy. Rotate or consume it after use.

### Disconnect grace and tombstones

On unexpected disconnect, keep a bounded participant tombstone:

- participant/account identity and connection generation;
- disconnect tick and monotonic expiry;
- match/team/party role;
- pawn disposition;
- inventory/equipment/quest/ability state references;
- last accepted command and committed transaction revisions;
- resume-token generation;
- cleanup and forfeiture policy.

Gameplay policy decides whether the pawn freezes, continues under AI, becomes invulnerable, remains vulnerable, retreats, or is removed. This must be mode-specific and authoritative. Tombstone expiry commits leave/forfeit cleanup exactly once.

### Sectional join-in-progress

A late join or reconnect should not block on one monolithic world blob. Build a manifest:

1. protocol/schema/content compatibility;
2. match metadata, rules, authority/world epochs, and current phase;
3. participant/private state;
4. required world-cell/entity baseline by interest;
5. durable gameplay state such as objectives and inventories;
6. bounded ordered changes after the baseline cut;
7. presentation-only readiness and cue suppression data.

Capture a consistent baseline at authoritative tick `T`, stream it in dependency order, buffer changes newer than `T`, then apply catch-up through tick `N`. Publish the participant as input-ready only after required sections, dependencies, hashes, and ownership bindings validate.

### Dedicated-server continuity

For a dedicated server, “host migration” is normally not a client election. Recovery is:

`detect authority loss -> stop/fence old epoch -> allocate replacement -> load last committed checkpoint -> replay durable journal/commands as supported -> validate state -> publish new endpoint and epoch -> reconnect/resync clients`

Choose and disclose the recovery-point objective:

- no match recovery; return to lobby;
- checkpoint rollback with bounded progress loss;
- warm standby with replicated state;
- deterministic event/command replay from a checkpoint;
- service-level process migration if the hosting platform supplies it.

Exactly-once external effects—rewards, purchases, quest commits, trades—use transaction IDs and durable ledgers so replay or restoration cannot duplicate them.

### Peer-host migration

Peer migration requires all of:

- authoritative migration snapshots created at a fixed interval or on controlled handoff;
- storage outside the departing host or replication to eligible peers/service;
- deterministic candidate eligibility and election;
- cryptographic/session authorization for the new host;
- authority-epoch fencing;
- endpoint/relay reallocation;
- snapshot integrity and schema/content validation;
- reconstruction of timers, RNG, ownership, interests, transactions, and participant state;
- reconnect and readiness barrier;
- explicit maximum rollback/data-loss window.

Election inputs may include connectivity/NAT suitability, platform constraints, build/content compatibility, performance headroom, session tenure, trust/anti-cheat eligibility, and snapshot availability. Do not choose solely by lowest latency or lobby order.

### Duplicate-login policy

Define one policy per mode:

- reject the new connection;
- replace/fence the old connection;
- allow multiple local devices under one account but unique participant identities;
- transfer the participant only after explicit confirmation;
- place the new connection in spectator/read-only state.

Replacement is a generation transaction. Increment connection generation, revoke old resume proof, stop accepting old commands, complete resync, then enable the new connection. Simultaneous command authority is forbidden.

## Performance Considerations

- **Asymptotic complexity:** Session/member lookup is expected `O(1)` by stable ID. Candidate election is `O(p)` for `p` eligible peers, or `O(p log p)` if fully sorted; a deterministic min-reduction is sufficient for fixed ranking keys. Snapshot capture/restore is `O(s)` for serialized authoritative state. Sectional resync is `O(r + d)` for relevant baseline records `r` and post-cut deltas `d`. Journal replay is `O(j)` in entries since checkpoint. Tombstone expiry is `O(log n)` with a deadline heap or amortized `O(1)` with a timing wheel.
- **Allocations and garbage collection:** Preallocate participant/tombstone tables, resync section descriptors, chunk buffers, catch-up rings, and election candidates. Snapshot capture writes to bounded pooled pages from immutable published state. Warm reconnect bookkeeping and ordinary fixed ticks allocate zero general heap memory. Compression/encryption buffers are pooled and budgeted.
- **Cache behavior:** Keep hot connection generation, participant state, command cursors, expiry, readiness bits, and authority epoch in dense tables. Migration/checkpoint blobs, lobby attributes, account metadata, and diagnostic histories stay cold. Serialize ECS chunks/components in schema order rather than pointer-chasing entity objects.
- **Update frequency:** Membership and connection changes are event-driven. Disconnect deadlines use a bounded timer service. Migration snapshots run at a configured low frequency or controlled handoff, never every render frame. Join catch-up advances under byte/time budgets. Authority heartbeats and failure detection have explicit cadence and false-positive tolerance.
- **Concurrency:** Transport/service callbacks enter bounded inboxes. The authoritative simulation alone commits membership, ownership, and epoch changes at barriers. Snapshot capture reads immutable published state or a copy-on-write/checkpoint view. Compression, encryption, upload, and chunk transmission run asynchronously. Restoration builds a staging world and publishes only after complete validation.
- **Fixed-step cost:** At a tick barrier, limit work to marking membership state, capturing lightweight metadata, freezing a snapshot generation, and swapping buffers. Serialization, compression, upload, and disk/service I/O must not extend the fixed step. Cap catch-up deltas, joins, reconnects, migrations, and ownership changes processed per tick; admission control protects the server.
- **Serialization cost:** Full migration state can dominate. Use versioned component schemas, quantization where safe, chunk/page deduplication, section hashes, compression, and incremental snapshots. Cost is proportional to authoritative state selected for continuity, not the rendered world. Never serialize pointers, sockets, tasks, presentation cues, or uncommitted transient buffers. Measure capture time, bytes, compression ratio, upload time, restore time, and peak memory.
- **Networking cost:** Normal reconnect control is small, but baseline resync is `O(relevant state)` and can burst bandwidth. Prioritize required sections, enforce per-connection byte budgets, and share immutable serialized chunks across simultaneous joiners where privacy allows. Peer migration adds periodic snapshot upload/replication cost roughly `snapshot_bytes / interval`, plus election and endpoint renegotiation. Dedicated recovery may cause all clients to resync simultaneously; stagger admission and preserve control-channel priority.

## Pros and Cons

### Dedicated authoritative servers

Pros:

- stable authority and anti-cheat boundary;
- no player-selected host advantage;
- simpler client trust and ownership model;
- late join/reconnect use the same authoritative resync path;
- recovery can use managed replacement, checkpoint, or standby infrastructure.

Cons:

- hosting cost and regional capacity;
- recovery still requires state persistence if matches must survive process loss;
- fleet replacement can take longer than a local peer election;
- service outages remain a dependency.

### Peer hosting with migration

Pros:

- lower infrastructure cost;
- private/co-op sessions can survive a voluntary or involuntary host departure;
- controlled handoff can be fast when state is small.

Cons:

- election, NAT/relay, security, snapshot distribution, restoration, and resync complexity;
- bounded state loss between snapshots;
- new host may be slow, incompatible, malicious, or unable to accept connections;
- migration pause and simultaneous reconnect can damage experience;
- external transactions and anti-cheat require stronger fencing;
- testing matrix grows with every failure point and platform combination.

### Return-to-lobby on host loss

Pros:

- simplest and most reliable contract;
- no untrusted peer becomes authority;
- avoids false promises of lossless migration.

Cons:

- current match progress may be lost;
- poor fit for long co-op sessions unless checkpoints are frequent;
- abandonment and reward policy must be fair.

## ECS Architectural Integration

Place social/session service state outside the authoritative world ECS, represented by stable handles and immutable published snapshots. Inside the gameplay ECS:

- participant entities survive connection and pawn replacement;
- connection entities are ephemeral projections with generation fencing;
- match and authority epochs are compact resources;
- reconnect tombstones are bounded records, not dormant full worlds;
- join baselines serialize only authoritative components registered in a continuity schema;
- restoration creates a staging world, runs migrations/invariants, then publishes readiness;
- lobby leader changes emit service facts but cannot mutate match authority directly;
- external durable transactions remain in idempotent ledgers and are reconciled after restore.

System ordering:

1. ingest authenticated service/transport events;
2. validate epoch, account, token, and connection generation;
3. submit membership/authority transition proposals;
4. commit transitions at a fixed barrier;
5. capture or restore authoritative sections;
6. build connection-specific interest and privacy projections;
7. transmit baseline/catch-up;
8. validate client readiness;
9. enable command acceptance;
10. emit committed continuity events and telemetry.

## Component, System, Resource, and Event Interfaces

Conceptual interfaces, not production code:

### Components

- `ParticipantContinuity { participant_id, account_id, status, team, join_generation }`
- `ConnectionBinding { connection_id, participant_id, generation, connected_at, last_command }`
- `ReconnectTombstone { participant_id, disconnected_tick, expiry_time, resume_generation, cleanup_policy }`
- `JoinReadiness { manifest_id, required_sections, applied_sections, baseline_tick, catchup_tick, state }`
- `AuthorityCandidate { participant_id, eligibility_bits, snapshot_generation, rank_key }`
- `ExternalCommitCursor { domain, last_committed_revision, reconciliation_state }`

### Resources

- `MatchIdentity { match_id, session_id, authority_epoch, world_epoch, protocol_version }`
- `ContinuityPolicy`: reconnect grace, late-join rules, pawn policy, duplicate-login policy, recovery mode, loss bound.
- `ContinuitySchemaRegistry`: component/section versions, privacy, dependencies, migration functions, restore order.
- `SnapshotStore`: bounded checkpoint/migration generations, hashes, tick, authority epoch, upload state.
- `CatchupJournal`: bounded ordered committed deltas/events after snapshot cuts.
- `ResumeTokenService`: issuer, validation keys, nonce/revocation state, expiry policy.
- `ContinuityBudgets`: capture, upload, restore, join bandwidth, concurrent joins, replay ticks, memory, deadlines.

### Systems

- `SessionAndLobbyAdapterSystem`
- `ConnectionAuthenticationAndFencingSystem`
- `ParticipantReconnectSystem`
- `LateJoinAdmissionSystem`
- `ContinuitySnapshotCaptureSystem`
- `JoinManifestBuildSystem`
- `SectionalResyncSystem`
- `AuthorityElectionSystem`
- `AuthorityRestoreAndValidationSystem`
- `ExternalTransactionReconciliationSystem`
- `ContinuityTelemetryAndAuditSystem`

### Events and commands

- `ParticipantDisconnected { participant, connection_generation, reason }`
- `ReconnectRequested/Accepted/Rejected { participant, session, resume_generation, reason }`
- `ConnectionReplaced { participant, old_generation, new_generation }`
- `ParticipantTombstoneExpired { participant, cleanup_revision }`
- `LateJoinRequested/Admitted/Rejected`
- `JoinBaselineCaptured { manifest, tick, hash }`
- `JoinSectionApplied { manifest, section, revision }`
- `ParticipantInputReady { participant, authority_epoch, ready_tick }`
- `LobbyLeaderChanged { lobby, leader }`
- `AuthorityLossSuspected/Confirmed { match, old_epoch, evidence }`
- `AuthorityCandidateSelected { match, candidate, snapshot_generation }`
- `AuthorityEpochAdvanced { match, old_epoch, new_epoch }`
- `AuthorityRestoreCommitted/Failed`
- `MatchRecoveryAborted { reason, safe_outcome }`

## Integration Plan

1. Choose the product topology per mode: dedicated authoritative, peer hosted without migration, or peer hosted with bounded migration. Do not expose one universal toggle.
2. Finalize lobby/session/match/participant/connection/pawn identity and authority/world epoch fields using the existing lifetime lattice.
3. Specify disconnect grace, pawn behavior, duplicate-login handling, resume-token security, tombstone expiry, and post-expiry rejoin rules.
4. Implement one sectional baseline-plus-catch-up protocol for initial join, late join, reconnect, travel recovery, and replacement-server recovery.
5. Register continuity-eligible authoritative components with version, privacy, dependency, capture, restore, migration, and invariant metadata.
6. Connect inventory, equipment, abilities/effects, quests/objectives, timers, cooldowns, match flow, ownership, RNG, and external commit cursors to the schema.
7. Add generation-fenced connection replacement and prevent input until readiness commit.
8. For dedicated recovery, define checkpoint frequency, durable journal scope, replacement allocation, endpoint publication, rollback/loss disclosure, and abort-to-lobby behavior.
9. Only if peer migration is required, add migration snapshot distribution, candidate eligibility/ranking, controlled handoff, involuntary election, new-epoch fencing, relay/NAT reroute, and security review.
10. Add privacy-filtered continuity traces, admin diagnostics, failure reason taxonomy, and player-facing recovery states.
11. Gate shipping support by automated fault-matrix results and measured recovery objectives, not by a successful happy-path demo.

## Verification Strategy

- Identity tests: connection and pawn replacement never change participant identity; stale connection generations cannot issue commands.
- Token tests: expiry, reuse, theft, wrong account/session/match, old authority epoch, replay, clock skew, revocation, and key rotation.
- Grace tests: disconnect just before/at/after expiry; reconnect races cleanup; repeated flapping; explicit leave versus loss; kicked/banned users cannot resume.
- Duplicate-login tests: old and new connections race commands, acknowledgements, inventory operations, rewards, and chat; exactly one generation remains authoritative.
- Join tests: baseline cut while entities spawn/despawn, travel, objective transition, inventory trade, effect expiry, or ownership transfer; catch-up converges to the same state hash.
- Privacy tests: late join and migration blobs expose only permitted private/team/public sections.
- Failure injection: authority loss before, during, and after snapshot capture/upload, election, endpoint allocation, restore, validation, epoch publication, client reconnect, and external reconciliation.
- Split-brain tests: old host returns after new epoch; delayed old packets, snapshots, rewards, and service writes are rejected or idempotently reconciled.
- Snapshot tests: corruption, truncation, missing section, unknown schema, migration failure, wrong content version, hash mismatch, dependency cycle, excessive size, and decompression limits.
- Determinism tests: restore and replay from the same checkpoint across builds/platforms only where support is claimed; otherwise prove authoritative correction and safe abort.
- External transaction tests: crash around reward/trade/quest/save commits; restoration never duplicates or silently loses a committed external effect.
- Scale tests: simultaneous reconnect after server loss, many late joins, largest relevant world, maximum participant tombstones, slow clients, packet loss, and service throttling.
- Performance gates: fixed-step capture cost, snapshot bytes, peak memory, compression/upload latency, restore time, catch-up ticks, join bandwidth, time-to-input-ready, and server admission tails.
- User-experience tests: recovery messaging, progress indication, cancellation, fallback to lobby, party preservation, accessibility/narration, and no misleading “reconnected” state before input readiness.

## Risks and Open Decisions

- Dedicated, listen-server, or hybrid topology for each game mode.
- Whether any competitive/ranked mode permits peer authority or migration.
- Recovery-point objective and maximum acknowledged gameplay loss.
- Reconnect grace duration, reserved-slot behavior, and AFK/abandonment policy.
- Pawn behavior while disconnected and exploit prevention.
- Resume-token issuer, storage, lifetime, rotation, revocation, and platform-account binding.
- Duplicate-login replacement, rejection, confirmation, and split-screen exceptions.
- Reconnect versus rejoin identity and whether expired participants retain progress/team slots.
- Late-join cutoff by match phase, team balance, spawn safety, catch-up assistance, and quest state.
- Snapshot section scope, capture interval, compression, storage location, encryption, and retention.
- Journal scope and whether deterministic replay is trusted across builds/platforms.
- Candidate eligibility/ranking and voluntary versus involuntary peer migration.
- Split-brain fencing and recovery if the old authority returns.
- Relay/NAT endpoint migration and platform cross-play restrictions.
- External rewards, trades, purchases, achievements, and cloud-save compensation.
- Host advantage, cheating, privacy, and exposure of private state in peer snapshots.
- Simultaneous recovery admission and bandwidth/memory protection.
- What happens when restore validation fails: retry older snapshot, cold reconstruct, or abort.
- Party/lobby preservation when a match cannot be recovered.
- Player-facing disclosure of rollback, lost progress, host change, or recovery failure.

## Engineering Recommendations

These are engineering recommendations, not direct claims from the sources:

1. Make dedicated authoritative servers the default for progression-sensitive, competitive, or long-lived shared matches.
2. Treat lobby leadership, session ownership, transport endpoint, and simulation authority as separate roles with separate events and epochs.
3. Build reconnect around durable participant identity and generation-fenced connections; never attach authority to a socket or pawn.
4. Reuse one versioned sectional baseline-plus-catch-up protocol for initial join, late join, reconnect, travel recovery, and server replacement.
5. Authenticate resume with short-lived, single-use, account-bound proof and fence the prior connection before accepting commands.
6. Keep bounded tombstones and commit expiry cleanup idempotently. Make disconnected-pawn policy data-driven per mode.
7. Carry authority epoch on all authoritative snapshots, commands, ownership changes, and durable transactions. Reject old-epoch work after transition.
8. For dedicated servers, call recovery “server recovery,” not host migration; restore from a validated checkpoint/journal or return safely to the lobby.
9. Support peer host migration only when its infrastructure and test cost are justified. Define an explicit maximum state-loss window and exclude ineligible peers.
10. Never equate a service-elected lobby owner with a restored game authority. Election without synchronized state is not migration.
11. Restore into staging, validate schemas/dependencies/hashes/invariants/external cursors, then atomically publish the new authority.
12. Keep irreversible external effects behind idempotent transaction ledgers so replay, reconnect, and split-brain cannot duplicate them.
13. Budget and stagger resync work. A mass reconnect must not cause a second outage through snapshot serialization, bandwidth, or fixed-step overload.
14. Ship continuity only after adversarial split-brain, token, corruption, failure-phase, and simultaneous-reconnect tests meet measured recovery objectives.

## Source Links

- [Unity Multiplayer Services — Migrate Session Host](https://docs.unity.com/en-us/mps-sdk/session-host-migration)
- [Unity Multiplayer Services — Find, Join, and Reconnect to a Session](https://docs.unity.com/en-us/mps-sdk/join-session)
- [Unity Multiplayer Services — Session Configuration Options](https://docs.unity.com/mps-sdk/config-options)
- [Unity Multiplayer Services — Session and Player Data](https://docs.unity.com/en-us/mps-sdk/session-data-and-player-data)
- [Unity Multiplayer Services — Update Session Data](https://docs.unity.com/en-us/mps-sdk/update-session-data)
- [Unity Multiplayer Services — Delete a Session and Failure Expectations](https://docs.unity.com/en-us/mps-sdk/delete-a-session)
- [Epic Games — Lobbies Interface in Unreal Engine 5.8](https://dev.epicgames.com/documentation/en-us/unreal-engine/lobbies-interface-in-unreal-engine)
- [Epic Games — Multiplayer Travel in Unreal Engine](https://dev.epicgames.com/documentation/en-us/unreal-engine/travelling-in-multiplayer-in-unreal-engine)
- [Epic Games — APlayerState API](https://dev.epicgames.com/documentation/en-us/unreal-engine/API/Runtime/Engine/APlayerState)
- [Valve Steamworks — Matchmaking and Lobbies](https://partner.steamgames.com/doc/features/multiplayer/matchmaking)
- [Valve Steamworks — ISteamMatchmaking](https://partner.steamgames.com/doc/api/ISteamMatchmaking?language=english)
