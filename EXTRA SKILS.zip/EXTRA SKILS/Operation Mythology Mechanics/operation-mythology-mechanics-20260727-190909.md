# Operation Mythology Mechanics Research

**Timestamp:** 2026-07-27T19:09:09-07:00  
**Subject:** Authoritative aquatic-state gameplay: water membership, immersion, breath/drowning, hazardous media, wetness, currents, rescue, persistence, and multiplayer

## Feature Overview

Aquatic gameplay is more than swimming locomotion. It requires a stable authoritative answer to which medium a character occupies, how deeply relevant body regions are submerged, whether the character is surface-swimming or underwater, which water body/current/hazard applies, when breath drains or recovers, how drowning damage interacts with downing/death/revive, how equipment and status effects react to wetness, and how rescue, checkpoints, replay, streaming, and multiplayer treat those states.

The recommended model separates:

1. **Water query service:** versioned, perspective-independent body membership and sampled surface/depth/current/media data from a CPU-stable proxy.
2. **Aquatic state machine:** dry, contact, wading, surface-swimming, submerged, breath-depleted, drowning, rescued/exiting, plus explicit invalid/unloaded fallback.
3. **Resource and effect policy:** breath/air reserve, drain/recovery clocks, drowning damage, hazardous-medium exposure, wetness, temperature, contamination, buoyancy aids, and equipment modifiers.
4. **Movement adapter:** consumes committed aquatic state and current to drive the existing predicted swimming/surface/exit modes.
5. **Presentation:** underwater visuals, bubbles, splashes, audio filtering, camera, UI, haptics, and warnings. Presentation never determines immersion or drowning.

Detailed ocean simulation, rendering, fluid solving, and rigid-body boats remain outside scope. This report defines the gameplay-facing interface revealed but not completed by the shared water research.

## Existing Coverage and Identified Gap

The mandatory recursive scan succeeded before research:

- `C:\Users\steve\Desktop\GAME SKILLS`: 31 files at scan time.
- `C:\Users\steve\Desktop\EXTRA SKILS\Operation Mythology Mechanics`: 29 files at scan time, including `RESEARCH_INDEX.md`.

The new shared water report already covers authoritative water-body/query assets, CPU-stable batched queries, currents, underwater classification, pontoon buoyancy, streaming, rendering, and simulation. It does not define breath, drowning, hazardous media, wetness, rescue, lifecycle ordering, equipment consequences, or accessibility.

The existing advanced traversal report covers underwater 3D movement, surface constraint, buoyancy/vertical control, currents, and exits. Generic damage/status reports cover resources and periodic effects. The downed/revive report covers incapacitation and team recovery. Searches found no dedicated drowning, oxygen/breath, water-hazard, submerged-state, or boat gameplay architecture.

The uncovered delta is:

- semantic water-body membership with overlap/exclusion/priority resolution;
- multiple immersion probes and hysteresis rather than one camera or origin test;
- breath clocks, grace, drain, recovery, pause, and difficulty/accessibility policy;
- deterministic transition to drowning damage, downed, death, or rescue;
- hazardous media such as toxic, freezing, electrified, hot, deep-pressure, or fast-current volumes;
- wetness and equipment/item consequences without per-frame inventory scans;
- buoyancy aids, carried/downed actors, mounts, vehicles, and rescue interactions;
- disconnect, save/load, respawn, checkpoint, travel, and streaming while submerged;
- privacy-aware networking and cue requirements;
- validation against visual/query divergence.

## Sourced Facts

These are sourced facts; recommendations are separated later.

1. Unreal Engine 5.8 Character Movement supports swimming as a movement mode and includes water speed, buoyancy, and fluid-related movement behavior. Its networked movement framework reproduces moves on the server, acknowledges/corrects owning clients, and smooths simulated proxies.

2. Unreal's Physics Volume can be marked as a water volume, defines fluid friction, supports overlap priority, and can apply physics on contact rather than only when an actor is inside. This shows that medium membership and overlap policy are explicit gameplay inputs.

3. Unreal's Water plugin exposes Water Body actors, exclusion volumes, runtime query APIs, entered/exited-water events, and an exclusion volume specifically described as preventing surface swimming when touching a water volume. Engine primitives therefore distinguish rendered water, body topology, exclusions, and gameplay state.

4. Epic's Water Buoyancy Component uses a configurable array of spherical pontoons as a low-cost volumetric approximation. It exposes water velocity, river forces, drag, shore push, maximum forces, and per-pontoon entry/exit candidates for user-implemented audiovisual effects.

5. Epic describes the buoyancy approximation as supporting multiple objects at low cost. This supports significance-capped sampling rather than detailed per-triangle fluid simulation for ordinary gameplay objects.

6. Epic's Water plugin and Buoyancy API include experimental components and explicitly advise caution for shipping. A generic engine architecture should wrap them behind a stable project query interface rather than expose plugin types in persistent ECS/gameplay state.

7. Microsoft Xbox Accessibility Guidelines include requirements for additional visual/audio cue channels, game-difficulty options, input accessibility, time limits, haptics, motion, and photosensitivity. Breath warnings and underwater escape can create timed, sensory, and motor barriers, so they require tunable and redundant communication.

8. Neither engine documentation nor accessibility guidance specifies one universal breath duration, drowning damage cadence, rescue policy, water-hazard taxonomy, or save behavior. Those are project policies.

## Industry-Standard API or Pattern

Use a **revisioned aquatic membership snapshot plus explicit lifecycle/resource state machine**.

### Water body and medium definition

Each immutable body/profile declares:

- stable `WaterBodyId`, definition revision, world/streaming generation, shape/exclusions, and priority;
- body kind: ocean, lake, river, pool, custom volume, transient flood, or scripted medium;
- surface/depth/current query capabilities and validity/fallback policy;
- medium tags such as fresh, salt, toxic, freezing, hot, electrified, corrosive, deep-pressure, breathable fantasy fluid, or safe;
- surface-swim, underwater, wade, dive, buoyancy, and exit permissions;
- breath drain/recovery and hazard exposure profile references;
- wetness/equipment interaction classes;
- audio/visual cue class but no presentation authority;
- persistence, replay, networking, and migration policy.

Overlaps resolve by authored priority and explicit combination rules. Exclusions are first-class. Do not infer water membership from render meshes or post-process volumes.

### Character probe set

Characters use a small authored probe set:

- feet/base for wading and ground contact;
- pelvis/center for swimming-mode threshold;
- airway/head for breath and drowning;
- optional upper-body probe for surface posture;
- carried/downed target airway probe where relevant.

At each fixed movement step, the query service returns for each probe: body ID/revision, inside/contact, signed surface distance, depth, surface normal, current/velocity, medium tags, query validity, and world generation. The state resolver combines probes with enter/exit hysteresis and dwell windows.

Camera location never controls authoritative underwater state. FP/TP cameras consume the same semantic state and may use a separate local visual transition.

### Aquatic state machine

Recommended semantic states:

- `Dry`
- `ContactOrSplash`
- `Wading`
- `SurfaceSwimming`
- `SubmergedBreathing`
- `SubmergedHoldingBreath`
- `BreathCritical`
- `BreathDepleted`
- `DrowningDamage`
- `AquaticDowned`
- `RescueClaimed`
- `ExitingRecovering`
- `InvalidWaterDataSafeFallback`

Movement mode and aquatic survival state are related but separate. A character can be downed while floating, walking through shallow toxic water, mounted on a boat while wet, or submerged while using a breathing device.

Transitions contain fixed tick, previous/new state, body ID/revision, immersion snapshot revision, reason, and resource/effect deltas.

### Breath resource

Breath is a policy-driven resource with:

- maximum reserve;
- optional pre-drain grace;
- drain rates by exertion, depth/pressure, wound/status, equipment, and medium;
- recovery delay/rate and whether recovery requires airway clearance or dry state;
- critical thresholds;
- explicit clock domain;
- quantized fixed-step accumulation or deadline representation;
- difficulty/accessibility modifier class;
- prediction and replication visibility.

Use deadline/event scheduling when drain is constant and fixed-step integration when rates change frequently. Never tie drain to render frames. A full reserve may remain latent while dry and only become an ECS component/state when relevant.

### Drowning and hazardous media

Breath depletion does not directly mutate health inside the water query system. It emits a revisioned hazard/effect proposal consumed by the existing damage/status/lifecycle domains.

Examples:

- drowning applies periodic or escalating authoritative damage;
- toxic water applies exposure stacks independent of breath;
- freezing water accumulates cold and movement impairment;
- electrified water uses authored event/area state, not particle collisions;
- fast current adds bounded movement input/force and escape difficulty;
- pressure uses depth bands from stable body queries;
- hot/corrosive media applies contact/submersion-scaled effects.

Each hazard declares affected probe/immersion fraction, grace, accumulation, decay, stack cap, effect cadence, resistance tags, equipment protection, and whether exiting stops or merely begins recovery.

### Rescue, downing, death, and revive

Water-state ordering integrates with the existing lifecycle:

1. resolve authoritative body/probe membership;
2. commit aquatic state and breath/exposure changes;
3. submit hazard damage/status proposals;
4. damage domain commits health/injury;
5. lifecycle resolves alive/downed/dead;
6. rescue/revive claims revalidate airway, body/current, reachability, capability, and target revision;
7. completion moves or stabilizes the target through existing movement/interaction transactions;
8. post-rescue recovery/protection begins according to policy.

Define whether downed characters float, sink, retain breath, immediately drown, can self-rescue, or require towing. A rescue completion cannot simply teleport through collision; it selects an authored exit/candidate, reserves it, and revalidates at commit.

### Wetness and equipment

Do not scan every inventory item each tick. Aquatic transitions emit coarse `WetnessChanged` and `MediumExposureChanged` events. Equipment/inventory definitions subscribe by category:

- waterproof containers prevent contents from changing;
- electronics may disable, drain, or require drying;
- clothing/armor may add drag, buoyancy, warmth, or breath capacity;
- flotation devices project buoyancy/surface-assist capabilities;
- consumable air tanks have authoritative charges;
- fire/burning effects may extinguish according to medium/profile;
- quest items declare explicit water resistance.

Use owner-level wetness bands plus sparse exceptional item state, deadlines for drying, and idempotent transition transactions.

### Multiplayer, save/load, replay, and streaming

Server owns membership, breath, hazards, damage, and rescue. Owning clients may predict swimming and locally display provisional water entry/breath change from the same stable proxy, but authority corrects body/revision/resource state. Do not expose hidden exact breath/equipment state to enemies.

Persist stable body ID/revision, aquatic state, breath/exposure, wetness, active hazards, rescue claims according to transaction policy, and deadlines. Never persist water-render tiles, FFT state, camera-underwater flags, splashes, or plugin pointers.

On load/late join:

1. restore durable character state;
2. resolve water body and query generation;
3. revalidate probe membership;
4. reconcile saved body/state with current topology;
5. install safe fallback if fine water data is unavailable;
6. rebuild movement, effects, cues, and presentation.

Globally resident body summaries must answer coarse membership while fine streamed data is absent. If authoritative membership cannot be established, choose a conservative policy—pause breath drain briefly, block control transition, or use last valid bounded state—rather than oscillating or killing a player from missing data.

## Performance Considerations

### Asymptotic complexity

Let `C` be relevant characters, `P` probes per character, `B` water-body candidates from spatial lookup, `H` active hazards, `D` deadlines, and `R` interested recipients.

- Batched membership queries are approximately `O(C*P*(log bodies + B))`; hard candidate and probe caps prevent scanning all bodies.
- State resolution is `O(C*P)`.
- Hazard evaluation is `O(active exposures)`, not `O(all hazard definitions)`.
- Deadline insert/remove is `O(log D)` or amortized `O(1)` in a timing wheel; processing is `O(expired)`.
- Sparse equipment reactions are `O(subscribed categories/items changed)` only on transitions.
- Serialization is `O(dirty aquatic characters + exceptional wet items)`.
- Networking is `O(R * compact state delta)` under interest/privacy filtering.

### Allocations and garbage collection

Use fixed per-archetype probe arrays, batched query buffers, pooled membership snapshots, compact state components, bounded hazard slots, and pooled deadline nodes. Warm fixed-step processing allocates nothing from the general heap and triggers no managed garbage collection. Query overflow returns typed invalid/capacity state and applies safe fallback; it never allocates an unbounded body list.

### Cache behavior

Store hot body summary data and character probe inputs in structure-of-arrays batches. Keep cold media definitions, localization, presentation, migration, and audit metadata separate. Compile hazard and equipment policies to numeric tables/bitmasks. Batch by spatial cell/body/profile and write contiguous result ranges. Avoid per-probe entity/pointer traversal or querying render objects.

### Update frequency

Controlled and nearby characters query at the fixed movement step. Dormant AI may use lower-frequency body membership only if hazard deadlines and critical transitions remain exact. Breath/hazard changes use fixed-step or deadlines. Wetness updates on transitions and drying deadlines. Buoyant object sampling is significance-capped. Persistence is dirty-driven and asynchronous; network deltas are event/state-driven; UI interpolates locally.

### Concurrency

Water queries read immutable body snapshots. Probe batches and independent character state proposals run in parallel. One logical writer commits aquatic state per character at the fixed barrier. Damage/status/lifecycle/rescue systems consume immutable committed transitions in ordered phases. Streaming publishes new body-query generations atomically. Save/network extraction reads committed snapshots. Visual water and GPU simulation cannot write gameplay state.

### Fixed-step cost

Budget characters, probes, body candidates, state transitions, hazard proposals, deadlines, rescue validations, buoyant samples, and emitted cues per tick. Critical breath depletion/drowning and exit transitions reserve capacity. Under overload, reduce noncritical buoyancy/AI query frequency and presentation; do not skip owner breath or lethal hazard state. Coalesce repeated exposure events by entity/body/profile.

### Serialization cost

Use stable IDs, varint revisions/ticks, bit-packed states/tags, quantized breath/exposure, and deadline deltas. Serialize only active/relevant data. Owner-level wetness plus sparse exceptional items avoids inventory-wide records. Save migrations resolve body/profile redirects and removed hazards. Large water geometry and simulation state never enters character saves.

### Networking cost

Swimming movement uses the existing packed prediction/reconciliation channel. Replicate aquatic semantic state, body/revision, coarse immersion band, breath thresholds or exact owner value, hazard/status revisions, rescue state, and relevant current parameters only when needed. Derive VFX/audio locally. Quantize and audience-filter. Track bytes per aquatic character, correction rate, body mismatch, breath threshold latency, late-join size, and rescue events.

## Pros and Cons

### Multi-probe semantic state

Pros:

- stable airway and wading decisions;
- supports downed/carried poses;
- independent of camera and render surface;
- bounded and debuggable.

Cons:

- authored probes per body type;
- surface/query discrepancies require hysteresis;
- transformations and unusual anatomy need variants.

### Single origin/camera test

Pros:

- minimal cost and implementation.

Cons:

- perspective-dependent, pose-sensitive, and unstable near surfaces;
- poor for wading, carried, downed, large, or nonhumanoid actors.

### Per-frame resource drain

Pros:

- straightforward.

Cons:

- frame-rate risk, unnecessary dormant work, and harder save/replay.

Recommendation: fixed-step quantized accumulation or deadline scheduling.

### Full visual-water authority

Pros:

- apparent visual match.

Cons:

- GPU/readback latency, cross-platform divergence, streaming gaps, and camera dependence.

Recommendation: CPU-stable water proxy is authoritative; measure and bound visual mismatch.

## ECS Architectural Integration

Components:

- `AquaticProbeSetRef`: immutable probe profile and local offsets.
- `AquaticMembership`: body ID/revision, world generation, immersion bands, current, validity, snapshot revision.
- `AquaticLifecycleState`: semantic state, previous state, transition tick/reason.
- `BreathState`: current/max, threshold band, drain/recovery profile, deadline/revision.
- `MediumExposureSet`: bounded hazard exposures and accumulated bands.
- `WetnessState`: owner band, medium class, drying deadline.
- `AquaticCapabilityProjection`: surface assist, dive, flotation, breathing device, rescue/tow flags.
- `AquaticPredictionState`: last acknowledged body/snapshot/input revision.
- `RescueClaim`: claimant, target, body, exit candidate, expiry/revision.
- `AquaticPersistenceState`: dirty revision and migration class.

Resources:

- `WaterBodyGameplayRegistry`;
- `WaterQuerySnapshot`;
- `AquaticProbeBatch`;
- `AquaticStatePolicyTable`;
- `MediumHazardRegistry`;
- `AquaticDeadlineWheel`;
- `AquaticEquipmentPolicyTable`;
- `AquaticRescueClaimRegistry`;
- `AquaticReplicationBudget`;
- `AquaticTelemetry`.

Systems:

1. `AquaticProbeQuerySystem`
2. `WaterOverlapExclusionResolutionSystem`
3. `AquaticStateProposalSystem`
4. `AquaticStateCommitSystem`
5. `BreathAndExposureSystem`
6. `AquaticHazardEffectAdapterSystem`
7. `SwimmingMovementAdapterSystem`
8. `WetnessEquipmentReactionSystem`
9. `AquaticRescueInteractionSystem`
10. `AquaticLifecycleAdapterSystem`
11. `AquaticPersistenceMigrationSystem`
12. `AquaticReplicationPredictionSystem`
13. `AquaticCueProjectionSystem`
14. `AquaticValidationTelemetrySystem`

The water service owns body/query data; aquatic gameplay owns membership/resources/exposure; movement owns collision/motion; damage/status/lifecycle own consequences; inventory/equipment own items; interactions own rescue; presentation owns visuals/audio/UI/camera.

## Component, System, Resource, and Event Interfaces

Conceptual interfaces:

- `QueryAquaticProbes(EntityId, Generation, FixedTick, ProbeProfileId, WorldGeneration)`
- `AquaticProbeResults(EntityId, QueryRevision, ProbeResults[], CandidateBodies[], Validity)`
- `ProposeAquaticTransition(EntityId, ExpectedRevision, FromState, ToState, BodyId, ImmersionBands, Reason)`
- `CommitAquaticState(EntityId, NewRevision, State, Membership, FixedTick)`
- `UpdateBreath(EntityId, ExpectedRevision, QuantizedDeltaOrDeadline, ProfileId)`
- `SubmitMediumExposure(EntityId, AquaticRevision, BodyId, HazardProfileId, ImmersionBand, ExposureEventId)`
- `WetnessChanged(EntityId, Revision, FromBand, ToBand, MediumTags, DryingDeadline)`
- `RequestAquaticRescue(RequestId, RescuerId, TargetId, TargetAquaticRevision, ExitHint)`
- `AquaticRescueClaimed(ClaimId, TargetId, ExitCandidateId, ExpiryTick)`
- `AquaticRescueCompleted(ClaimId, Result, TargetTransformRevision, AquaticRevision)`
- `AquaticBodyInvalidated(BodyId, BodyRevision, WorldGeneration, Reason)`
- `SerializeAquaticState(EntityId, DefinitionRevisions, State, Membership, Breath, Exposures, Wetness, Deadlines)`
- `ApplyAquaticCheckpoint(EntityId, Record, CurrentWorldGeneration)`

Typed outcomes include dry/no body, excluded, overlap resolved, query invalid, fine data unavailable, stale body/world/entity revision, probe capacity, breathing device active, breath critical/depleted, hazard immune, rescue blocked/claimed/interrupted, exit unavailable, migration required, and safe fallback applied.

## Integration Plan

1. Define shipping water/body types, hazards, breath, wetness, and rescue scope.
2. Freeze stable water-body/media schemas and overlap/exclusion priorities.
3. Author character probe profiles for standing, crouched, swimming, downed, carried, and relevant nonhumanoids.
4. Bind the shared CPU-stable water query service behind the project interface.
5. Add aquatic semantic state alongside, not inside, swimming locomotion.
6. Implement breath via fixed-step/deadline policy and route depletion through status/damage/lifecycle.
7. Add selected hazardous media with bounded exposure slots.
8. Project equipment, flotation, air supplies, extinguishing, wetness, and drying through inventory/effects.
9. Implement rescue/tow/exits using interaction claims and reserved traversal candidates.
10. Add multiplayer prediction/correction, privacy, persistence, replay, reconnect, streaming, and migration.
11. Route cues through the newly defined semantic cue system with redundant critical warnings.
12. Certify every water body, exclusion, shoreline exit, current, hazard, checkpoint, and streamed boundary.

## Verification Strategy

- Sweep every probe across flat, wavy, moving, overlapping, excluded, streamed, and invalid water boundaries; verify hysteresis and stable body selection.
- Test standing, crouched, prone/downed, carried, climbing, jumping, falling, surface-swimming, diving, vehicles, and perspective changes.
- Property-test breath grace, drain, recovery, thresholds, clock domains, difficulty modifiers, equipment, and save/load at every tick boundary.
- Permute same-tick entry, exit, breath depletion, damage, downing, death, revive, rescue, teleport, travel, body unload, and checkpoint.
- Duplicate/reorder network updates and rescue/treatment commands; no duplicate damage, costs, or rewards.
- Test toxic/freezing/hot/electrified/corrosive/pressure/current profiles independently and in declared overlaps.
- Test disconnect/reconnect, late join, save/load, server migration, and body definition redirects while submerged.
- Compare authoritative query surface to visual surface across platforms/settings; mismatch stays within content thresholds.
- Force missing fine tiles and query-capacity overflow; safe fallback never oscillates or kills from unavailable data.
- Sweep characters, probes, bodies, candidates, hazards, deadlines, rescue claims, buoyant objects, and clients; record fixed-step time, allocations/GC, cache misses, save bytes, and network bytes.
- Accessibility tests cover breath-warning channels, non-color UI, screen-reader/text, haptics/audio controls, extended/disabled breath pressure where allowed, simplified swim input, camera/motion reduction, and alternative objective routes.

## Risks and Open Decisions

- Does breath/drowning exist in all modes, only survival/difficulty profiles, or not at all?
- Which probes and thresholds define wading, surface, underwater, and airway clearance?
- How are overlapping water bodies, exclusions, moving volumes, and floods prioritized?
- Which media hazards ship and how do they combine?
- What clocks, grace periods, drain/recovery rates, and pause rules apply?
- Is exact breath private to the owner; what do allies/enemies observe?
- What happens when breath depletes: damage, stamina loss, forced surfacing, downing, or death?
- Do downed characters float, sink, retain breath, or receive special grace?
- Can rescuers tow, carry, revive in water, or reserve shoreline exits?
- Which equipment changes buoyancy, drag, warmth, breath, hazard immunity, or wetness?
- Which inventory items track individual wetness versus owner/container bands?
- How do fire, electricity, contamination, temperature, wounds, and status effects interact?
- Are boats/mounts/vehicles in this domain or a separate vehicle-water module?
- What persists across death, respawn, checkpoint, travel, and reconnect?
- What safe fallback applies during streaming/query invalidity?
- What are probe, hazard, deadline, rescue, buoyancy, serialization, and networking caps?
- Which difficulty/accessibility assists are allowed in competitive modes?

## Engineering Recommendations

These are engineering recommendations, not sourced facts.

1. Build aquatic survival as a semantic domain layered on the stable water query service and existing swimming movement, not as camera/post-process logic.
2. Use a small authored multi-probe set with stable body IDs, revisions, overlap/exclusion rules, hysteresis, and query validity.
3. Separate aquatic lifecycle, movement mode, breath, hazardous exposure, wetness, and presentation.
4. Use fixed-step quantized resource changes or deadlines; never render-frame timers.
5. Route drowning and media hazards through existing status/damage/lifecycle barriers with deterministic ordering and idempotent events.
6. Implement rescue through claimed interactions and reserved/revalidated exit candidates, not unchecked teleports.
7. Project equipment and inventory consequences on semantic transitions; use owner/container bands and sparse exceptional items.
8. Keep exact owner breath and hidden equipment private; replicate coarse observable bands to other audiences.
9. Persist semantic state and deadlines only; revalidate water membership after load and streaming.
10. Provide conservative, time-bounded fallback when authoritative fine water data is unavailable.
11. Use the cue-intent system for critical breath/drowning/current warnings with visual, audio, haptic, text/icon, and accessibility fallbacks.
12. Hard-cap probes, candidates, exposures, deadlines, rescue claims, buoyant samples, save data, and bandwidth.
13. Ship water-state inspectors, probe/body visualizers, query-versus-visual error heatmaps, clock/deadline traces, race/fault tests, and automated shoreline/streaming certification.

## Source Links

1. Epic Games, **Movement Components — Unreal Engine 5.8**  
   https://dev.epicgames.com/documentation/en-us/unreal-engine/movement-components-in-unreal-engine
2. Epic Games, **Networked Character Movement — Unreal Engine 5.8**  
   https://dev.epicgames.com/documentation/en-us/unreal-engine/understanding-networked-movement-in-the-character-movement-component-for-unreal-engine
3. Epic Games, **Character Movement Component API — Unreal Engine 5.8**  
   https://dev.epicgames.com/documentation/en-us/unreal-engine/API/Runtime/Engine/UCharacterMovementComponent
4. Epic Games, **Physics Volume Actor — Unreal Engine 5.8**  
   https://dev.epicgames.com/documentation/unreal-engine/physics-volume-actor-in-unreal-engine
5. Epic Games, **Water Buoyancy Component — Unreal Engine 5.8**  
   https://dev.epicgames.com/documentation/unreal-engine/water-buoyancy-component-in-unreal-engine
6. Epic Games, **Water Plugin API — Unreal Engine 5.8**  
   https://dev.epicgames.com/documentation/unreal-engine/API/Plugins/Water
7. Epic Games, **Buoyancy Plugin API — Unreal Engine 5.8**  
   https://dev.epicgames.com/documentation/en-us/unreal-engine/API/Plugins/Buoyancy
8. Epic Games, **Water Body API — Unreal Engine 5.8**  
   https://dev.epicgames.com/documentation/unreal-engine/API/Plugins/Water/AWaterBody
9. Microsoft, **Xbox Accessibility Guidelines**  
   https://learn.microsoft.com/en-us/xbox/accessibility/guidelines
10. Microsoft, **Xbox Accessibility Guideline 103: Additional visual and audio cue channels**  
    https://learn.microsoft.com/en-us/xbox/accessibility/xbox-accessibility-guidelines/103
11. Microsoft, **Xbox Accessibility Guideline 108: Game difficulty options**  
    https://learn.microsoft.com/en-us/xbox/accessibility/xbox-accessibility-guidelines/108

