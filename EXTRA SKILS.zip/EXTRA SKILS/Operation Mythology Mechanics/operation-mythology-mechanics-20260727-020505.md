# Operation Mythology Mechanics Research — Server Rewind and Authoritative Hit Validation

**Timestamp:** 2026-07-27T02:05:05-07:00  
**Scope:** Server rewind, lag-compensated hit validation, anti-cheat trust boundaries, historical collision queries, weapon-class policies, ECS interfaces, performance, testing, and telemetry.

## Feature Overview

This batch defines a server-authoritative combat-validation layer for a modular ECS. It separates four mechanisms that are related but not interchangeable:

1. **Local prediction** gives the acting player immediate feedback.
2. **Reconciliation** corrects predicted owner state from authoritative acknowledgements.
3. **Remote interpolation** renders other entities from buffered snapshots.
4. **Server rewind** evaluates a past action against bounded authoritative history approximating what the attacker saw.

The proposed system accepts intent—not a client-declared hit—then validates ownership, action sequence, timing, weapon state, aim, range, collision, and damage on the server. It supports first-person and third-person presentation without treating either camera transform as authoritative.

## Existing Coverage and Identified Gap

The recursive inventory of `C:\Users\steve\Desktop\GAME SKILLS` and the dedicated mechanics folder was refreshed at 2026-07-27T02:03:37-07:00. Existing mechanics research covers input/movement foundations, advanced traversal, interactions and inventory, abilities/effects, quests/save-load, and FP/TP camera/aim architecture. The source folder's new shadow-map research is outside mechanics scope.

The uncovered gap was a concrete architecture for server rewind and hit validation: what history to retain, how to translate a client command into a trusted server tick, which state may be rewound, how weapon classes differ, how to avoid corrupting the live world, and how to bound fairness, CPU, memory, and abuse.

## Sourced Facts

The following are source-derived facts; product-specific choices appear later as recommendations.

- Epic documents Unreal's character movement as client prediction using saved moves, followed by server reproduction and validation. The server acknowledges acceptable moves or sends corrections, after which the client replays later saved moves. Similar saved moves can be combined to reduce traffic.
- Unreal movement timestamps are part of discrepancy detection and correction; the server maintains authority rather than accepting the client's resulting transform. Correction thresholds and frequency trade bandwidth against visible error and replay work.
- Epic's `FCharacterNetworkMoveData` is the client-to-server movement payload and is explicitly extensible with custom serialized move data.
- Valve's networking paper stores timestamped user commands, predicts from the last acknowledged authoritative state, and replays unacknowledged commands. Predicted audiovisual effects need duplicate suppression when commands are replayed.
- Valve describes lag compensation as estimating the command's execution time, restoring historical target state, evaluating the action, and then restoring current state. It includes the client's interpolation delay because remote characters were deliberately viewed in the past.
- Valve notes that historical state may need more than position, including posture and alive/dead state. Its Source implementation offers cheaper bounds-only rewind and more precise hitbox rewind, including a ray-filtered variant.
- Valve explicitly identifies the fairness paradox: a high-latency attacker can validly hit a target who, in current server time, has reached cover. The choice of maximum rewind is therefore game design policy, not merely an implementation constant.
- Valve's described treatment is primarily for instant-hit weapons; autonomous projectiles are more problematic and were not lag compensated in the cited Half-Life design.
- Unity Netcode for Entities provides `PhysicsWorldHistory`/`PhysicsWorldHistorySingleton` so the server can query the collision world from a selected tick. History size is configured, confirming that historical-query capacity is an explicit bounded resource.
- Unity warns that predicted physics can require multiple simulation steps per rendered frame and can spiral when CPU falls behind. Its batching/step limits demonstrate that resimulation budgets require hard controls.
- Unity Physics collision queries read a broadphase representation; its `CollisionWorld` exposes a deep-copied body/broadphase clone with shallow-copied colliders, illustrating both a historical-query option and its memory/lifetime implications.
- Respawn's GDC presentation on scripted weapons identifies historical local input/aim and entity positions/poses as rollback data, while excluding unrelated remote component data such as health/filtering from that historical simulation path.

## Industry-Standard API or Pattern

Use a tick-addressed authoritative command and history pipeline:

`input sample -> numbered command -> local prediction/cue -> server receipt -> trusted rewind-tick estimate -> eligibility validation -> historical spatial query -> authoritative outcome -> acknowledgement/result -> client reconciliation and cue deduplication`

The server derives rewind time from acknowledged clock synchronization, observed transport timing, command sequence, and the configured interpolation model. A client-provided timestamp is evidence for mapping—not authority. Clamp the result to retained history, action-specific maximum rewind, connection-health policy, and monotonically acceptable command windows.

Maintain two conceptually separate query spaces:

- **Live authority space:** current movement, abilities, inventory, health, cover, and physics.
- **Historical validation space:** immutable or read-only snapshots/proxies used only to answer a past geometric query.

This avoids the fragile pattern of moving live entities backward and forward around a shot. If the engine only supports live-world rewind, isolate it in a tightly scoped phase with guaranteed restoration and no concurrent readers, callbacks, gameplay events, or physics stepping.

## Performance Considerations

- **Asymptotic complexity:** Capturing one fixed-size snapshot per rewindable entity per tick is `O(R)`, where `R` is the number of relevant entities. Ring lookup is `O(1)`. A naive shot against every entity is `O(R)`; use a coarse spatial candidate pass plus historical narrow phase so typical query cost approaches `O(log R + K)` or grid-equivalent `O(1 + K)`, where `K` is the candidate count. Never scan `history_ticks × entities` per shot.
- **Allocations and garbage collection:** Preallocate history rings, query collectors, result buffers, and per-connection command windows. Avoid per-shot object creation, temporary collider clones, variable-length lists, strings, and boxing. Overflow must follow an explicit truncate/reject/degrade rule and emit telemetry.
- **Cache behavior:** Store hot history fields in dense SoA or chunked arrays keyed by stable rewind slot: position, rotation, stance/shape ID, bounds, pose sample ID, flags, generation. Keep rarely used audit data and full bone/hitbox detail cold. Sequential tick capture and stable entity slots improve write locality.
- **Update frequency:** Capture authoritative query state once per simulation tick after the relevant movement/pose phase. Do not capture per render frame. Static geometry is referenced by version and need not be copied every tick; moving cover and platforms need explicit historical representations.
- **Concurrency:** History for tick `T` becomes immutable after publication. Parallel ray/sweep queries may read published snapshots, while the capture job writes the next ring slot. Use dependencies or epoch publication to prevent readers from observing partial writes or recycled storage.
- **Fixed-step cost:** Capture and validation consume the authoritative tick budget. Cap commands processed per connection/tick, historical candidates per query, melee sub-sweeps, penetration iterations, and queued late commands. Backlog policy must preserve server time rather than allowing unbounded catch-up.
- **Serialization cost:** Do not serialize the server's full history to clients. Command requests should be compact and quantized: sequence, simulation tick/offset, action ID, aim representation, and minimal action parameters. Results contain authoritative execution/outcome IDs and presentation data. Replay/audit logs may store compact commands and outcomes separately from transient collision history.
- **Networking cost:** Numbered unreliable/redundant command streams are suitable for continuous input; reliable semantics are appropriate only for sparse state that must arrive. Rate-limit fire/action requests, reject implausible sequence/timestamp ranges, and deduplicate by execution ID. Interest-manage outcome replication without hiding locally relevant confirmation.
- **Memory bound:** Approximate history memory is `R × H × S`, with rewindable entities `R`, retained ticks `H`, and bytes per snapshot `S`, plus spatial structures. At 60 Hz, even a modest time window multiplies rapidly; measure exact platform layouts and configure entity/action tiers.
- **Precision:** Tick quantization and interpolation create spatial error proportional to target speed and time error. Record estimated mapping error and define tolerance deliberately; do not enlarge hitboxes silently.

## Pros and Cons

**Server historical validation**

- Pros: preserves server authority; substantially improves hitscan feel under latency; supports deterministic audit inputs; separates visual prediction from damage commitment.
- Cons: costs memory and server CPU; creates “shot after cover” cases; depends on clock/interpolation estimates; complicates moving geometry and pose history.

**Dedicated historical query proxies**

- Pros: read-only, concurrency-friendly, no live-world side effects, straightforward debugging of past versus present.
- Cons: additional memory and synchronization; must mirror collision filtering and geometry revisions accurately.

**Temporarily rewinding the live world**

- Pros: may reuse an existing collision scene with less initial infrastructure.
- Cons: restoration hazards, callback/event contamination, poor parallelism, nested-query risk, and difficult debugging. It should be a compatibility fallback, not the target architecture.

**Favor-the-attacker policy**

- Pros: responsive aiming and lower perceived latency.
- Cons: disadvantage to defenders behind cover and greater abuse surface at high latency. A bounded hybrid policy is generally easier to justify.

## ECS Architectural Integration

Assign a stable `RewindSlot` with generation checking to every eligible historical-query entity. Do not key long-lived history only by transient ECS entity handles. At a fixed authoritative phase, a capture system writes the next ring slice from movement/collision/stance state and publishes the tick atomically.

Combat commands enter a bounded per-connection inbox. Validation proceeds through pure or side-effect-minimized stages: protocol validation, temporal mapping, action eligibility, historical candidate query, precise hit resolution, and authoritative transaction commit. Only the commit stage changes health, effects, ammo, cooldowns, objectives, or telemetry counters.

Keep presentation events downstream. A client may predict muzzle flash, recoil, reticle response, and sound using an `ExecutionId`; the authoritative result confirms, adjusts, or rejects it without replaying the same cue.

For FP and TP, authoritative aim is derived from the validated control/aim contract established in the camera report. The camera can choose a prospective target, but the server must validate the shot from an authoritative muzzle/character origin and enforce angle, range, obstruction, weapon, stance, and fire-rate constraints.

## Component, System, Resource, and Event Interfaces

### Components

- `Rewindable { slot, generation, policy_id }`
- `HistoricalShapeSource { shape_set_id, pose_source, collision_mask }`
- `NetworkCommandSequence { last_received, last_processed, ack_mask }`
- `CombatActionState { weapon_id, cadence_state, ammo_revision, cooldown_revision }`
- `AuthoritativeAimState { control_yaw_pitch, origin_basis, stance }`
- `MovingGeometryRevision { geometry_id, revision, transform }`
- `RewindExclusion { reason }`

### Resources

- `SimulationClock { tick, fixed_dt, epoch }`
- `ConnectionTimeModel { server_tick_offset, rtt_estimate, jitter, interpolation_delay, confidence }`
- `RewindPolicyTable { history_ticks, max_rewind_by_action, tolerances, overflow_policy }`
- `HistoryRing { tick_headers, dense_snapshot_pages, published_epochs }`
- `HistoricalSpatialIndex { per_tick_or_incremental_index }`
- `CombatValidationBudget { commands, candidates, traces, penetrations, melee_segments }`
- `ValidationAuditBuffer { bounded_records, retention_policy }`

### Commands and Events

- `CombatIntentCommand { connection, sequence, claimed_tick, execution_id, action_id, aim, parameters }`
- `RewindQueryRequest { trusted_tick, origin, shape, direction, range, mask, policy_id }`
- `RewindQueryResult { candidates, hit, fraction, hit_zone, target_slot, geometry_revision }`
- `CombatAccepted { execution_id, authoritative_tick, target, outcome }`
- `CombatRejected { execution_id, reason_code, timing_delta, validation_stage }`
- `DamageTransaction { source, target, amount_spec, execution_id, causality }`
- `PredictedCue { execution_id, cue_id }`
- `AuthoritativeCueResult { execution_id, disposition, corrected_parameters }`

### Systems and Ordering

1. `ReceiveAndDeduplicateCommandsSystem`
2. `ConnectionTimeModelUpdateSystem`
3. `AuthoritativeMovementAndPoseSystem`
4. `HistoricalStateCaptureSystem`
5. `HistoryPublishSystem`
6. `CombatEligibilityValidationSystem`
7. `TrustedRewindTickMappingSystem`
8. `HistoricalBroadphaseQuerySystem`
9. `HistoricalNarrowphaseValidationSystem`
10. `CombatTransactionCommitSystem`
11. `OutcomeReplicationAndCueReconciliationSystem`
12. `ValidationTelemetrySystem`

## Integration Plan

1. Define clock synchronization, command numbering, interpolation reporting, and acknowledgement contracts; document which fields are trusted, estimated, or ignored.
2. Implement a debug-only history ring for capsules/bounds and render past/current query geometry side by side.
3. Add hitscan validation for stationary geometry and character capsules, with a very small configurable rewind bound.
4. Add stance and hitbox-pose history only after measuring capsule false positives/negatives and memory cost.
5. Introduce moving-platform/door/cover revisions. Choose per class whether to rewind transforms, validate against current obstruction, or reject ambiguous history.
6. Integrate authoritative ammo, cadence, cooldown, team, life-state, and damage transactions. A geometric hit alone must never commit damage.
7. Add weapon-specific policies:
   - **Hitscan:** historical target query with authoritative-origin obstruction validation.
   - **Projectile:** server-authoritative spawn and forward simulation; optionally compensate only launch time/origin within a strict bound, never continuously place the projectile in multiple time frames.
   - **Melee:** bounded historical swept volume using sampled attack phases and candidate caps.
   - **Explosion/area:** authoritative detonation tick; historical treatment only if explicitly designed and consistently applied to cover.
8. Add cue prediction/deduplication keyed by execution ID and correction feedback that avoids duplicate effects.
9. Add budgets, anomaly scoring, audit records, and server dashboards before broad playtests.
10. Tune maximum rewind and cover policy through latency/jitter playtests, then lock competitive presets server-side.

## Verification Strategy

- Unit-test tick mapping across wraparound, jitter, drift, reordered commands, stale history, future timestamps, and low-confidence clock estimates.
- Property-test ring generations: a query either returns the requested published tick or an explicit unavailable result, never recycled data mislabeled as valid.
- Golden-test rays, capsules, skeletal hit zones, stance transitions, moving platforms, doors, elevators, and targets crossing cover at tick boundaries.
- Run a network matrix with asymmetric latency, jitter, loss, duplication, reordering, burst loss, and deliberate client clock manipulation.
- Compare live/current and rewound outcomes in shadow mode before enabling rewind; histogram time deltas, spatial deltas, candidate counts, and disagreement reasons.
- Test cadence, ammo, cooldown, ownership, death, team, invulnerability, and duplicate execution IDs atomically with collision results.
- Verify FP and TP produce identical authoritative results from the same control/aim state despite different render cameras.
- Load-test worst-case automatic fire and melee crowds. Assert per-tick caps, no managed allocations in the hot path, stable fixed-step duration, and graceful overload rejection.
- Fuzz malformed/NaN/out-of-range aim and command payloads; disconnect or quarantine repeated protocol violations without crashing or poisoning history.
- Record sufficient audit data to reproduce a validation decision offline: server tick, trusted rewind tick, timing-model confidence, action policy, origin/aim, candidates, geometry revisions, outcome, and rejection reason.
- Provide developer visualization for current shape, historical shape, selected tick, shot ray/sweep, obstruction, and server decision. Never expose sensitive anti-cheat thresholds in shipping client telemetry.

## Risks and Open Decisions

- Maximum rewind per mode, weapon, and connection quality.
- Favor-attacker, favor-defender, or hybrid cover policy.
- Whether current-world cover blocks a shot that was clear historically, and how destructible/moving cover is versioned.
- Capsule-only versus pose/hitbox history; pose sampling rate and compression.
- Whether the shooter origin is historical, current, or constrained by both.
- Accepted clock-model uncertainty and policy for clients with unstable jitter.
- Projectile launch compensation and whether fast projectiles approximate hitscan.
- Melee phase history, sweep subdivision, and animation/gameplay authority.
- Penetration, ricochet, shotgun pellet aggregation, and area-effect semantics.
- Memory budgets by player count/platform/server density.
- Candidate-index design: per-tick BVH, refitted structures, spatial grid, or current broadphase plus historical narrow phase.
- Spectator/replay correspondence with the exact validation tick.
- Anti-cheat escalation thresholds and privacy/retention rules for audit telemetry.
- Host/listen-server parity and whether host latency needs artificial normalization.

## Engineering Recommendations

These are engineering recommendations, not claims directly mandated by the sources.

1. Build a **read-only historical query service**, not general whole-world rollback. Only data needed for validation belongs in its history.
2. Treat every client field as untrusted. Derive a **trusted rewind tick** from server-observed sequence/timing state and clamp it by server policy.
3. Accept **action intent**, never client-reported target, hit zone, damage, ammunition result, or cooldown completion.
4. Validate in two time domains where necessary: historical targets for responsiveness and authoritative/current constraints for exploit resistance. Make the cover/origin rule explicit per action.
5. Start with hitscan against capsule/bounds history, instrument disagreement, then add skeletal poses only where measured accuracy warrants the memory and capture cost.
6. Use fixed-capacity dense rings, stable rewind slots, immutable published epochs, and bounded spatial candidates. Reject/degrade predictably under overload.
7. Keep projectile, melee, hitscan, and area attacks as separate policies; a universal rewind switch will create contradictory time semantics.
8. Commit ammo, cooldown, damage, status effects, and objective consequences through one idempotent authoritative transaction keyed by `ExecutionId`.
9. Separate predicted cues from authoritative outcomes and deduplicate all replayed/confirmed presentation events.
10. Make fairness observable: track rewind milliseconds, victim displacement, cover disagreement, rejection reasons, and outcome deltas by latency cohort before tuning policy.

## Source Links

- [Epic Games — Understanding Networked Movement in Character Movement Component](https://dev.epicgames.com/documentation/en-us/unreal-engine/understanding-networked-movement-in-the-character-movement-component-for-unreal-engine)
- [Epic Games — FCharacterNetworkMoveData](https://dev.epicgames.com/documentation/unreal-engine/API/Runtime/Engine/FCharacterNetworkMoveData)
- [Epic Games — Network Debugging](https://dev.epicgames.com/documentation/unreal-engine/network-debugging-for-unreal-engine)
- [Epic Games — Mover](https://dev.epicgames.com/documentation/en-us/unreal-engine/mover-in-unreal-engine)
- [Valve — Latency Compensating Methods in Client/Server Protocol Design](https://developer.valvesoftware.com/w/index.php?title=Latency_Compensating_Methods_in_Client%2FServer_In-game_Protocol_Design_and_Optimization&uselang=en)
- [Valve — Lag Compensation](https://developer.valvesoftware.com/wiki/Lag_compensation)
- [Valve — Source Multiplayer Networking](https://developer.valvesoftware.com/wiki/Source_Multiplayer_Networking)
- [Unity — Netcode for Entities Physics and Lag Compensation](https://docs.unity.cn/Packages/com.unity.netcode%401.0/manual/physics.html)
- [Unity — LagCompensationConfig](https://docs.unity.cn/Packages/com.unity.netcode%401.0/api/Unity.NetCode.LagCompensationConfig.html)
- [Unity — PhysicsWorldHistory](https://docs.unity.cn/Packages/com.unity.netcode%401.2/api/Unity.NetCode.PhysicsWorldHistory.html)
- [Unity — CollisionWorld](https://docs.unity.cn/Packages/com.unity.physics%401.0/api/Unity.Physics.CollisionWorld.html)
- [GDC 2017 — Networking Scripted Weapons and Abilities in Titanfall 2](https://media.gdcvault.com/gdc2017/Presentations/Reed_Dan_NetworkingScriptedWeapons.pdf)
