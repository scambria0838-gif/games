# Operation Mythology Mechanics Research — Game-Flow State Machines and Transitions

**Timestamp:** 2026-07-27T02:13:52-07:00  
**Scope:** Boot, accessibility-first startup, engagement/frontend, profile/session flow, loading and activation, gameplay, pause, death, respawn, game over, travel, failure recovery, multiplayer authority, ECS interfaces, performance, and verification.

## Feature Overview

Game flow coordinates long-lived state across the title without allowing UI, loading, session services, match rules, or pawn lifetime to become one monolithic manager. The recommended architecture is a set of hierarchical, event-driven state machines with explicit ownership:

- **Application lifecycle:** cold boot, platform initialization, accessibility/settings bootstrap, engagement, frontend, shutdown/suspend/resume.
- **User/session lifecycle:** signed out, authenticating, profile ready, matchmaking/hosting/joining, connected, leaving, error recovery.
- **World lifecycle:** no world, preparing, loading, activating, ready, unloading/travelling, failed.
- **Match lifecycle:** entering, waiting, warmup, playing, post-match, leaving, aborted.
- **Per-player lifecycle:** joining, spawning, alive, downed/dead, spectating, respawning, disconnected.
- **Local presentation flow:** frontend screen stack, loading cover, gameplay HUD, pause/settings overlay, modal/error overlays.

These machines exchange typed commands and facts but do not directly own one another's internal states. This supports both first-person and third-person play because camera/pawn presentation is selected from player and world state rather than defining global flow.

## Existing Coverage and Identified Gap

The mandatory recursive inventory completed at 2026-07-27T02:13:14-07:00:

- `C:\Users\steve\Desktop\GAME SKILLS`: 11 files.
- `C:\Users\steve\Desktop\EXTRA SKILS\Operation Mythology Mechanics`: 8 files.

Prior mechanics reports define input contexts, pawn traversal/movement, camera rigs, transactions, abilities/effects, quests/checkpoints/save-load, server hit validation, and shared observability/testing. They mention death outcomes, respawn, pause-safe clocks, save legality, travel persistence, and test startup, but no report owns the overall game-flow topology.

The uncovered gap is the coordination contract: which state machine owns each decision, how asynchronous transitions complete or fail, what persists across worlds/pawns/sessions, how local pause differs from authoritative multiplayer, how loading activation is gated, and how the system recovers from cancellation, timeout, disconnect, suspend, and partial initialization.

## Sourced Facts

The following are sourced facts. Operation Mythology-specific design choices appear under Engineering Recommendations.

- The W3C SCXML recommendation formalizes hierarchical states, parallel states, initial/final states, events, guards, and ordered exit/transition/entry execution. It defines a state configuration as the active set rather than requiring one flat state.
- SCXML queues raised events until the current executable block and prior internal events finish. It also warns that transition executable content should complete quickly because events are not processed while it runs.
- Unreal's gameplay framework gives different lifetimes to core objects. Epic documents the game instance as existing from engine launch to shutdown, while a game mode is created for a world/level and is server-only in multiplayer.
- Unreal separates server-only game rules (`GameMode`) from replicated match facts (`GameState`). Its built-in match flow includes entering, waiting to start, in progress, post-match waiting, leaving, and aborted states.
- Unreal's multiplayer travel documentation distinguishes blocking non-seamless travel from non-blocking seamless travel. Seamless travel uses a small transition world to avoid retaining two large worlds simultaneously and can preserve selected controllers/actors across the transition.
- Epic recommends server-driven travel for multiplayer map changes; clients follow the server. First connection and certain hard resets still require non-seamless travel.
- Epic's Lyra game phases use hierarchical gameplay tags. Starting a sibling phase ends the previous sibling, while nested phases permit parent behavior to remain active across sub-phase changes.
- Lyra's modular initialization states—spawned, data available, data initialized, gameplay ready—were introduced to coordinate replicated/loaded dependencies and address initialization races.
- Epic's Common User/Lyra frontend material separates engagement, controller/user initialization, and hosting/joining concerns into frontend/session systems rather than treating them as pawn gameplay.
- Unity `LoadSceneAsync` loads a scene in the background and returns an asynchronous operation. Unity can delay scene activation; while activation is held, the async-operation queue may stall behind it, so activation gates must not be left unresolved.
- Unity documents that setting global `timeScale` to zero suppresses fixed updates and time-scaled waits. This demonstrates that “pause” affects clocks and scheduling, not merely input or a menu.
- Unity application-pause notifications are platform/focus lifecycle events and may occur during initialization; they are distinct from an in-game pause command.
- Microsoft's Xbox Accessibility Guidelines recommend that single-player/local gameplay and cinematics be pausable, apart from saving/loading screens, and that non-gameplay UI time limits be avoidable or extendable.
- Microsoft also recommends accessibility configuration be available at first launch before the main menu/cinematics/gameplay and warns against death/respawn UI timers that can cause progress loss.

## Industry-Standard API or Pattern

Use hierarchical statecharts and event-driven transitions, but keep orthogonal concerns in separate machines. A representative composition is:

`Application.Frontend + User.ProfileReady + Session.Offline + World.None + Presentation.MainMenu`

or:

`Application.InExperience + Session.Connected + World.Ready + Match.Playing + Player.Alive + Presentation.GameplayHUD`

Transitions are requests with lifecycle rather than immediate enum assignments:

`request -> guard validation -> transition generation allocated -> exit/freeze -> asynchronous prepare -> readiness barrier -> atomic activation/commit -> enter/publish -> cleanup`

Every asynchronous completion carries the transition generation/request ID. Late results from cancelled or superseded loads, login requests, matchmaking searches, save operations, or travel attempts are ignored or compensated rather than applied to the new state.

Treat flow output as capabilities and facts:

- `GameplayInputAllowed`
- `WorldSimulationPolicy`
- `CanOpenPauseMenu`
- `CanSave`
- `CanRespawn`
- `LoadingCoverRequired`
- `CameraPresentationPolicy`
- `NetworkJoinPolicy`

Consumers observe these results; they do not infer them from UI visibility or a single global enum.

## Performance Considerations

- **Asymptotic complexity:** Dispatch through a state/event table is normally `O(1)` per machine/event; hierarchical exit/entry is `O(depth)`. Broadcasting every event to every machine is `O(M)` and should be replaced by typed subscriptions/routing. Readiness aggregation is `O(dependencies)` when changed or `O(1)` with maintained counters.
- **Allocations and garbage collection:** Precompile transition tables, guards, and dependency IDs. Use fixed-capacity event queues, numeric state/event IDs, reusable transition records, and pooled async-operation handles. Avoid per-frame futures/tasks, closure captures, strings, reflection, and rebuilding UI/state graphs.
- **Cache behavior:** Keep active configuration, pending transition, deadlines, and readiness bits in compact resources. Authored graph metadata is cold immutable data. Do not store heavyweight scene/session/service objects in hot ECS components; store stable handles.
- **Update frequency:** Flow machines process queued events and deadline changes, not unconditional per-frame polling. Loading progress UI may sample at a presentation rate, while authoritative match/player transitions commit at fixed-tick barriers. Platform lifecycle callbacks enter a thread-safe inbox.
- **Concurrency:** Asynchronous I/O, authentication, matchmaking, load, shader/asset warmup, save, and network operations run outside the simulation thread. They publish immutable results with generation IDs. Activation and authoritative state changes occur at ordered barriers; cancellation must not race completion.
- **Fixed-step cost:** Global flow work per tick is small and bounded. Match/player state changes that affect gameplay commit at a defined phase before command acceptance or after outcome resolution. World activation must never occur midway through an authoritative tick.
- **Serialization cost:** Persist durable user/playthrough/match facts, not transient menu, loading percentage, or in-flight task objects. A resume token may record destination, checkpoint/save generation, content version, session/reconnect evidence, and last safe phase. Serialization is `O(persisted records)` and asynchronous after immutable capture.
- **Networking cost:** Replicate authoritative match phase, transition generation, relevant deadlines, and per-player life state as compact deltas. Do not replicate local UI stack or single-player pause overlay. Travel/session messages are sparse but reliability-sensitive; deduplicate requests and make join/leave/restart operations idempotent.
- **Loading memory:** Old world, transition shell, and new-world staging can overlap. Budget peak residency, dependency warmup, replication bootstrap, and rollback/failure UI. Publish readiness only after required gameplay data and authoritative dependencies—not merely file I/O—are ready.
- **Timeouts:** Use monotonic real/platform time for external services and loading deadlines; use authoritative simulation ticks for match/respawn rules. Pausing one clock must not silently pause authentication or watchdogs.

## Pros and Cons

**Separate hierarchical machines**

- Pros: clear ownership/lifetime; valid parallel states; modular testing; multiplayer/local presentation separation; avoids state explosion.
- Cons: requires an explicit coordination protocol; debugging needs a combined state view; careless cross-machine events can create cycles.

**One monolithic flow enum**

- Pros: initially simple and easy to inspect.
- Cons: combinatorial states, incorrect lifetimes, impossible split-screen/player-specific flow, UI-authority coupling, brittle async cancellation. It does not scale to the stated scope.

**Transactional asynchronous transitions**

- Pros: explicit cancellation, timeout, rollback, and stale-completion handling; reliable incident traces.
- Cons: more metadata and intermediate states; compensating actions are required for non-atomic external services.

**Seamless world travel**

- Pros: preserves selected connection/player state; smoother multiplayer continuity.
- Cons: peak-memory and persistence complexity; old/new content version overlap; harder failure recovery.

**Data-driven statecharts**

- Pros: graph validation, visualization, reusable guards/actions, content iteration.
- Cons: unrestricted scripting creates hidden side effects and poor determinism; schema/version/tooling costs.

## ECS Architectural Integration

Global machine configurations are singleton resources because they describe worlds/sessions, not per-entity composition. Per-player life flow is component state on stable player/session entities; pawns are disposable avatars. Local presentation machines live in each local-player context, enabling split-screen users to have independent menus while sharing one world.

Transitions emit commands into established subsystems:

- input context push/pop;
- save snapshot request;
- session create/join/leave;
- world load/activation/unload;
- match phase change;
- pawn spawn/despawn/possess;
- UI layer request;
- camera policy request;
- audio/presentation policy;
- telemetry capture.

Subsystem completions return typed facts. Flow systems never synchronously block on them. Cross-entity authoritative effects commit through deterministic command buffers; local UI and loading presentation update outside authoritative hashes.

Death is a per-player outcome first. It cancels or blocks action abilities, removes/changes possession, selects death/spectator camera policy, and asks match rules whether respawn or game-over conditions are satisfied. `GameOver` is a match or playthrough rule result, never an automatic synonym for `Player.Dead`.

## Component, System, Resource, and Event Interfaces

### Components

- `PlayerLifeState { state_id, entered_tick, generation, cause_id }`
- `PlayerJoinState { state_id, connection_id, readiness_bits }`
- `PawnInitializationState { spawned, data_available, initialized, gameplay_ready }`
- `FlowParticipant { machine_id, participant_id, generation }`
- `TransitionDependency { transition_id, dependency_id, status }`
- `PersistentAcrossWorld { persistence_policy_id }`
- `LocalPresentationState { local_player_id, root_layer, modal_depth }`

### Resources

- `ApplicationFlow { active_configuration, generation, pending_transition }`
- `UserSessionFlow { state, user_id, request_id, error }`
- `OnlineSessionFlow { state, session_id, join_policy, request_id }`
- `WorldFlow { state, current_world, destination, transition_id }`
- `MatchFlow { phase, phase_generation, entered_tick, deadline_tick }`
- `FlowGraphRegistry { machines, states, events, guards, actions, versions }`
- `FlowEventQueues { external_inbox, authoritative_queue, presentation_queue }`
- `ClockDomains { simulation_tick, real_monotonic, platform_lifecycle, presentation }`
- `ReadinessBarrier { required_bits, satisfied_bits, failures, deadline }`
- `TransitionJournal { bounded_records, causality, timing, result }`
- `LoadingBudget { memory, io, activation_ms, warmup_work, timeout }`

### Commands and Events

- `FlowTransitionRequest { machine_id, target_or_event, requester, request_id }`
- `FlowTransitionAccepted/Rejected { request_id, reason }`
- `AsyncOperationStarted { transition_id, operation_id, generation }`
- `AsyncOperationCompleted { operation_id, generation, result }`
- `DependencyReady/Failed { transition_id, dependency_id, evidence }`
- `WorldActivationReady { transition_id, world_id, content_hash }`
- `MatchPhaseChanged { old_phase, new_phase, generation, tick }`
- `PlayerLifeChanged { player_id, old_state, new_state, cause, tick }`
- `PauseRequested { local_player_id, reason }`
- `SimulationPolicyChanged { policy_id, effective_tick }`
- `PlatformSuspended/Resumed { monotonic_time, platform_reason }`
- `TravelCommitted/Failed { transition_id, destination, reason }`
- `FlowRecoverySelected { failure_id, recovery_action }`

### Ordering

1. ingest platform/service/network completions;
2. discard stale generations and deduplicate;
3. evaluate guards against published facts;
4. advance external/local presentation machines;
5. queue authoritative match/player transition commands;
6. commit authoritative transitions at the fixed-tick barrier;
7. publish capabilities/facts;
8. update UI/loading/camera presentation;
9. export transition telemetry asynchronously.

## Integration Plan

1. Enumerate machines, owners, lifetimes, clocks, authoritative roles, and legal cross-machine events. Ban a universal mutable `isPaused`, `isLoading`, or `gameState`.
2. Implement the small statechart kernel: hierarchical configuration, queued events, guards, entry/exit command emission, generation IDs, deadlines, and transition tracing.
3. Build application/user frontend flow with the earliest viable accessibility/settings screen, platform-user engagement, profile load, safe main-menu recovery, and controller/user reassignment.
4. Build world transition coordination with prepare, content/dependency readiness, activation barrier, failure/cancel, cleanup, and a minimal transition/loading shell.
5. Build server-authoritative match phases and replicated facts. Keep local screen flow separate.
6. Build per-player joining/initialization/life flow; require `GameplayReady` before accepting gameplay commands or showing an interactive pawn.
7. Connect death to abilities/effects, inventory policy, camera, checkpoint, objectives, match rules, respawn, and spectator flow through typed events.
8. Define clock-domain policies:
   - offline/local pause may stop authoritative simulation;
   - online pause opens local UI without stopping server ticks;
   - UI/captions/accessibility/settings use unscaled presentation time;
   - service/load/watchdog deadlines use monotonic time;
   - match/respawn rules use authoritative ticks.
9. Add suspend/resume, sign-out, controller disconnect, network loss, host migration policy, content mismatch, and corrupted-save recovery.
10. Add a combined flow debugger showing all machine configurations, pending transition graph, generations, readiness bits, deadlines, last events, and ownership.
11. Compile/lint authored graphs and generate scenario coverage for all states/transitions/error arcs.

## Verification Strategy

- Compile-time/offline validation: unique state/event IDs, valid initial/final configurations, reachable states, no unguarded ambiguous transitions, bounded hierarchy, valid dependency IDs, declared clocks, declared authority, and explicit error/timeout exits.
- Model-check or exhaustively traverse small machines for dead ends, illegal state combinations, event cycles, and missing cancellation/cleanup.
- Unit-test ordered exit/transition/entry actions, hierarchical sibling cancellation, event queue ordering, generation rejection, timeout clocks, and transition idempotency.
- Property-test arbitrary event sequences. Invariants include one active sibling per sequential region, legal parent ancestry, no gameplay capability before readiness, and no current-world handle after unload.
- Fault-inject every asynchronous stage: completion before subscription, duplicate completion, late completion after cancel, never completing, partial failure, process suspend, sign-out, disk full, content mismatch, lost connection, and server travel failure.
- Cold-boot tests start without settings/profile/network caches and verify accessibility configuration precedes skippability-dependent content.
- Loading tests measure peak memory, main/fixed-thread activation time, I/O progress stalls, dependency warmup, cancel latency, and fallback UI. Never use a fake progress percentage without distinguishable indeterminate presentation.
- Pause tests cover offline, online, local split-screen, cinematics, tutorials, menus, input buffering, cooldown/timer domains, audio, haptics, networking, and save restrictions.
- Death tests cover simultaneous deaths, last-player death, revive versus respawn race, disconnect while dead, checkpoint restore, game-over rule, post-match, spectating, and FP/TP camera changes.
- Multiplayer tests add late join, reconnect, server travel, non-seamless first connect, readiness replication delay, client loading slower/faster than server, and stale phase packets.
- Suspend/resume tests cover every externally visible flow state, repeated callbacks, background duration, invalidated credentials, device loss, and clocks that must or must not advance.
- Replay captured flow events through a reference statechart interpreter and compare transition generations/configurations.
- Assert bounded queues, zero warm-path allocations, no fixed-tick blocking, no unauthorized client phase changes, and complete transition artifacts on failure.

## Risks and Open Decisions

- Exact machine boundaries and whether playthrough/campaign flow is separate from match flow.
- Statechart data format and permitted action/guard language.
- Offline pause semantics for physics, AI, abilities, timers, camera, audio, cinematics, UI, and background save.
- Online pause/menu behavior and AFK/safety policy.
- Death states: downed, dying, dead, eliminated, spectator, respawn pending.
- Respawn ownership, delays, location selection, inventory/effect retention, and checkpoint relation.
- Game-over versus mission-failed versus post-match semantics.
- World-travel strategy, transition shell, peak memory, and actor/entity persistence allowlist.
- Late-join readiness and when the client becomes interactable/visible.
- Loading progress truthfulness, minimum display time, user-controlled continue, and accessibility.
- Cancellation support for platform/session APIs that cannot truly cancel.
- Suspend/resume and quick-resume platform guarantees.
- Sign-out/profile swap behavior in local and online play.
- Host migration or explicit return-to-frontend on host loss.
- Save legality during transitions, death, post-match, and pause.
- Error taxonomy, retry/backoff, offline fallback, and user-facing recovery copy.
- Split-screen ownership of pause, menus, confirmation dialogs, and user/session changes.

## Engineering Recommendations

These are engineering recommendations, not requirements directly mandated by the sources.

1. Use **separate hierarchical machines** for application, user/session, world, match, player life, and local presentation. Publish a combined debug view, not a combined mutable enum.
2. Make all flow changes event-driven and generation-checked. Never let a stale async completion activate a world, session, profile, or UI after cancellation.
3. Treat long transitions as transactions with prepare, readiness, commit/activation, cleanup, timeout, and recovery states.
4. Put game rules on authoritative server flow; replicate facts and deadlines. Local clients own presentation overlays, not match phase.
5. Treat pawns as disposable. Stable player/session entities own persistent progress, equipment references, reconnect state, and life-flow generation.
6. Define clock domains explicitly. A zero time scale or visible pause menu is not a complete pause architecture.
7. Require a readiness barrier beyond asset I/O: content version, world systems, required data, replication, player initialization, camera/input, and authoritative spawn must be ready before gameplay capability.
8. Model death, respawn, spectating, mission failure, and game over as separate transitions with explicit rule ownership.
9. Keep transition entry/exit actions short and side-effect-declarative. They should enqueue commands rather than perform blocking work or directly mutate unrelated systems.
10. Provide accessibility/settings access before first-run cinematics or gameplay, make local gameplay/cinematics pausable, and avoid irreversible UI timers around death/recovery.
11. Validate every graph offline and test every transition's success, cancellation, timeout, duplicate completion, and failure arc headlessly.
12. Instrument transition duration by stage, readiness stalls, retry/error reason, peak memory, activation hitch, stale completion count, and recovery outcome.

## Source Links

- [W3C — State Chart XML (SCXML) 1.0](https://www.w3.org/TR/scxml/)
- [Epic Games — Gameplay Framework](https://dev.epicgames.com/documentation/en-us/unreal-engine/gameplay-framework-in-unreal-engine)
- [Epic Games — Game Mode and Game State](https://dev.epicgames.com/documentation/en-us/unreal-engine/game-mode-and-game-state-in-unreal-engine)
- [Epic Games — Travelling in Multiplayer](https://dev.epicgames.com/documentation/unreal-engine/travelling-in-multiplayer-in-unreal-engine)
- [Epic Games — Managing Multiplayer Sessions](https://dev.epicgames.com/documentation/en-us/unreal-engine/managing-multiplayer-sessions-in-unreal-engine)
- [Epic Games — Lyra Game Phase Abilities](https://dev.epicgames.com/documentation/unreal-engine/abilities-in-lyra-in-unreal-engine)
- [Epic Games — Game Framework Component Manager and Initialization States](https://dev.epicgames.com/documentation/unreal-engine/game-framework-component-manager-in-unreal-engine)
- [Epic Games — Common User Plugin and Lyra Frontend](https://dev.epicgames.com/documentation/unreal-engine/common-user-plugin-in-unreal-engine-for-lyra-sample-game)
- [Unity — SceneManager.LoadSceneAsync](https://docs.unity3d.com/6000.0/Documentation/ScriptReference/SceneManagement.SceneManager.LoadSceneAsync.html)
- [Unity — AsyncOperation.allowSceneActivation](https://docs.unity3d.com/6000.0/Documentation/ScriptReference/AsyncOperation-allowSceneActivation.html)
- [Unity — Time.timeScale](https://docs.unity3d.com/6000.0/Documentation/ScriptReference/Time-timeScale.html)
- [Unity — MonoBehaviour.OnApplicationPause](https://docs.unity3d.com/6000.0/Documentation/ScriptReference/MonoBehaviour.OnApplicationPause.html)
- [Microsoft — Xbox Accessibility Guideline 108: Game Difficulty Options](https://learn.microsoft.com/en-us/xbox/accessibility/xbox-accessibility-guidelines/108)
- [Microsoft — Xbox Accessibility Guideline 116: Time Limits](https://learn.microsoft.com/en-us/xbox/accessibility/xbox-accessibility-guidelines/116)
- [Microsoft — Accessibility Feature Tags](https://learn.microsoft.com/en-us/xbox/accessibility/accessibility-feature-tags)
