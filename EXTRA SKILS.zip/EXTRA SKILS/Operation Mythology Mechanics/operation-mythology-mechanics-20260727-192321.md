# Operation Mythology Mechanics Research

**Timestamp:** 2026-07-27T19:23:21-07:00  
**Subject:** Authoritative cinematic and cutscene orchestration: sequence sessions, readiness, control/camera ownership, multiplayer synchronization, skipping, checkpoints, recovery, replay, and accessibility

## Feature Overview

Cinematics are gameplay sessions that coordinate world state, player agency, cameras, dialogue, streaming, choices, and presentation over time. A timeline player can animate content, but it cannot by itself own authoritative quest progress, inventory grants, player locks, multiplayer consensus, checkpoint state, or recovery after travel and disconnect.

The recommended architecture separates:

1. **Cinematic definition:** immutable sequence identity, revision, participants, semantic milestones, branches, prerequisites, streaming dependencies, accessibility metadata, and completion policy.
2. **Authoritative session:** revisioned lifecycle, participants, readiness, authoritative start tick, branch/skip decisions, completed milestones, and terminal outcome.
3. **Gameplay effect leases:** generation-tagged input, ability, AI, interaction, damage, movement, and camera-control policies that are acquired and released idempotently.
4. **Local presentation adapter:** Unreal Sequencer, Unity Timeline, video, dialogue, camera, subtitle, audio-description, and cue playback driven toward an authoritative semantic position.
5. **Durable consequences:** quests, rewards, world changes, checkpoints, and unlocks committed through ordinary transactional gameplay systems, never inferred from reaching a visual frame.

This scope excludes cinematography, animation authoring, rendering, lighting, VFX production, and detailed camera-rig construction except where they expose a gameplay-facing contract.

## Existing Coverage and Identified Gap

The mandatory recursive scan succeeded before research:

- `C:\Users\steve\Desktop\GAME SKILLS`: 32 files, 734,213 bytes at scan time.
- `C:\Users\steve\Desktop\EXTRA SKILS\Operation Mythology Mechanics`: 30 files, 854,067 bytes at scan time, including 29 reports and the active `RESEARCH_INDEX.md`.

The newly added shared UI/text/accessibility research is already covered at the gameplay boundary by the existing input, game-flow, accessibility, and gameplay-cue reports. It did not justify a duplicate mechanics report.

Archive searches found no dedicated cutscene report and no coverage of sequence-player ownership, skip voting, readiness barriers, or cinematic recovery. Existing reports define game-flow states, perspective-independent camera policy, transactional commands, stable content IDs, replay, accessibility, and multiplayer authority, but not their composition around a cinematic session.

The uncovered delta is:

- authoritative cinematic lifecycle and identity independent of an engine timeline asset;
- participant readiness, streaming barriers, authoritative start time, late join, and clock correction;
- explicit player/camera/control ownership that cannot leak after skip, abort, travel, or failure;
- semantic milestones, branches, and durable consequences;
- individual skip versus group vote policies and deterministic completion-on-skip;
- save/checkpoint, replay, reconnect, host migration, and content-revision behavior;
- accessible pause, captions, audio description, manual advance, motion controls, and sensitive-content bypass;
- bounded ECS, serialization, networking, telemetry, and automated validation interfaces.

## Sourced Facts

These are sourced facts; project recommendations appear in later sections.

1. Epic's Sequencer model separates a Level Sequence Asset, which stores tracks and animation data, from a Level Sequence Actor, which binds that data into a level. Current Epic documentation also describes runtime rebinding of a proxy player to the actual player by a binding tag.

2. Epic documents `AReplicatedLevelSequenceActor` as always relevant for networking. The Level Sequence Actor API exposes a replicate-playback option whose documented purpose is synchronizing server sequence playback across clients.

3. Unreal's client-server networking documentation states that the server owns the true state of replicated actors and replicates state at configured frequencies rather than every frame. Therefore, a replicated timeline still operates under sampled network updates rather than guaranteed identical frame execution.

4. Epic's Multi-User Sequencer documentation explicitly warns that synchronized playback events can run at different frame rates and should not be expected to be frame-accurate across computers. Although this feature concerns editor collaboration, it is direct evidence that synchronized start/playback events do not imply identical frame evaluation.

5. Unity Timeline separates reusable Timeline Assets from Timeline instances that bind scene objects. Its Playable Director controls playback, clock source, initial/current time, and end behavior. Supported clock choices include game time, unscaled game time, DSP time, and manual evaluation.

6. Unity's documented end modes include hold, loop, and restoring/resetting animated properties. Epic likewise exposes restore-state and playback controls. Engine-level end behavior concerns animated state; it does not define transactional quest/reward/world completion policy.

7. Unreal's replay system records replicated information through a replay network driver and supports pause, speed changes, and time jumps. It also carries engine and game version identifiers for compatibility handling.

8. Microsoft's current accessibility feature requirements state that single-player and local multiplayer cinematic content must be pausable for the corresponding pause feature tag. Xbox Accessibility Guideline 116 recommends enough time to read and interact, including manual advancement of cutscene dialogue. XAG 111 addresses optional localized audio descriptions for cinematic events, and XAG 123 recommends warnings and bypass options for potentially harmful content.

9. The reviewed engine and accessibility sources do not prescribe a universal multiplayer skip vote, branch authority, late-join policy, checkpoint granularity, or semantic completion transaction. Those remain game-specific engineering decisions.

## Industry-Standard API or Pattern

Use an **authoritative semantic session with a locally evaluated presentation timeline**.

### Definition

`CinematicDefinition` contains a stable `CinematicId`, immutable `DefinitionRevision`, presentation asset references, semantic duration, participant roles, required streamed regions/assets, bindings by stable role, ordered semantic milestones, branch points, required gameplay leases, pause/skip policy, accessibility metadata, terminal transactions, persistence class, and compatibility/migration rules.

Milestones are named semantic events such as `DoorOpened`, `QuestFactCommitted`, `ChoiceRequested`, or `ControlRestored`; they are not arbitrary animation notifications. Each declares whether it is reversible, durable, required on skip, replay-recorded, and safe to repeat.

### Session lifecycle

Use explicit phases:

`Requested -> Preloading -> ReadyBarrier -> Scheduled -> Playing -> BranchGate -> Completing -> Completed`

Terminal alternatives are `Skipped`, `Aborted`, and `Recovering`, each followed by a mandatory cleanup/finalization path. Every transition carries session revision, authority epoch, fixed-step tick, cause, and idempotency key.

### Synchronization

The authority validates the request, creates the session, resolves participants, and announces content requirements. Participants report readiness against the exact definition and streaming revision. The server either schedules a start tick after the barrier, applies a declared timeout fallback, or aborts.

Clients derive presentation time from the authoritative start tick and synchronized gameplay clock. Sparse authoritative phase/milestone updates correct drift. Small errors are rate-corrected; large errors seek to a safe presentation boundary. Gameplay consequences occur only from authoritative milestone commits, not from local playhead crossings.

### Control and camera ownership

Input, movement, interaction, abilities, AI, invulnerability, camera preference, and HUD changes use generation-tagged leases/tokens. Each lease names its owner session, policy, priority, and restoration behavior. Cleanup releases all leases idempotently on complete, skip, abort, travel, disconnect, entity destruction, and load recovery.

The gameplay session requests a camera role; local FP/TP presentation selects an appropriate rig. It never rewrites authoritative facing, target, or movement merely because a cinematic camera exists unless a declared gameplay command does so.

### Branches and skipping

At a branch gate, the semantic clock pauses while an ordinary authoritative command/vote service resolves the choice. Policies may be solo owner, host, majority, unanimous, role-weighted, or server scripted. Deadline and tie behavior are definition data.

A skip request never simply seeks the renderer to the end. The authority resolves skip eligibility, freezes new optional milestones, commits every required-on-skip consequence exactly once in declared order, releases leases, selects the terminal checkpoint, and broadcasts the resulting state. Local-only presentation skip is allowed only when the participant can safely resume synchronized gameplay without hiding required interaction.

### Persistence and replay

Persist definition identity/revision, session/authority identity, semantic phase, completed-milestone set or compact frontier, branch outcomes, gameplay leases or their reconstructible policy, terminal transaction keys, and clock/deadline data. Do not persist animation graphs, particles, camera blends, or rendered frames.

Replay records semantic session creation, scheduled start, milestones, choices, skip/abort outcomes, and normal replicated gameplay consequences. The presentation adapter reconstructs visuals from compatible content; missing or revised presentation content falls back to semantic replay markers.

## Performance Considerations

- **Asymptotic complexity:** with `S` active sessions, `P` participating connections, `M` pending milestones, and `R` readiness dependencies, fixed semantic work is `O(S + due milestones + changed participants)`. Readiness fan-out and terminal broadcast are `O(P)`. Do not scan all definitions, entities, or milestones every frame; use indexed sessions, sorted milestone frontiers, bitsets, and deadline queues.
- **Allocations and garbage collection:** definitions and compiled milestone tables are immutable. Pool session records, participant readiness rows, command/vote records, lease handles, and event envelopes. Avoid per-frame strings, reflection, delegates/closures, and rebuilt binding maps.
- **Cache behavior:** store hot phase, revision, clock, next-milestone index, and participant masks densely; keep variable asset metadata, localized text, and audit trails cold. Use compact bitsets for completed milestones/readiness and stable integer IDs rather than object graphs.
- **Update frequency:** authoritative semantic progression runs at the fixed gameplay step or sparse deadline/milestone boundaries. Local timeline, subtitle, camera, and audio evaluation may run each presentation frame. Drift measurement can be throttled and should not generate a network update every frame.
- **Concurrency:** preload/streaming, localization, and presentation preparation may run asynchronously. Authoritative transitions commit at one ordered barrier against immutable readiness snapshots. Background completion callbacks enqueue revision-fenced evidence and never mutate session state directly.
- **Fixed-step cost:** budget active sessions, due milestones, branch evaluations, lease changes, and commands per step. Precompile milestone ticks. If work exceeds a cap, defer only explicitly deferrable presentation work; never split an atomic terminal transaction.
- **Serialization cost:** a checkpoint is `O(P + M/word-size + active leases)`, bounded by participant and milestone caps. Store a frontier when milestones are strictly ordered; use a bitset only for optional/branching milestones. Version content IDs and serialize remaining deadlines in a declared clock domain.
- **Networking cost:** send create/prepare, readiness deltas, scheduled start, phase/milestone/branch/terminal changes, and occasional correction—not playhead frames. Cost is `O(P)` per relevant semantic change. Interest-filter spectators and redact undiscovered choices. Cap vote spam, readiness retries, correction rate, and audit retention.

## Pros and Cons

**Pros**

- Makes quest, reward, world, checkpoint, and player-control outcomes independent of frame rate and local presentation failure.
- Supports FP/TP, split-screen, spectators, late join, replay, dedicated servers, and multiple engine timeline backends.
- Produces explicit recovery and skip behavior instead of relying on fragile end callbacks.
- Enables accessible local presentation without weakening multiplayer authority.
- Keeps network and fixed-step cost proportional to semantic change rather than animation frames.

**Cons**

- Requires authored semantic milestones and a validation/export pipeline in addition to timeline authoring.
- Readiness barriers, migration, vote policy, and lease cleanup add state-machine complexity.
- Seeking or reconstructing local presentation may expose backend-specific limitations.
- Exact mid-cinematic save/resume is expensive and may be infeasible for arbitrary content.
- Cross-version replay may preserve gameplay truth while visual reconstruction degrades.

## ECS Architectural Integration

Keep the durable session in a compact authoritative ECS world or adjacent aggregate store. Timeline-player objects remain backend adapters outside persistent ECS data.

Suggested components:

- `CinematicSessionState`: IDs, definition revision, authority epoch, phase, revision, semantic clock, next milestone, terminal outcome.
- `CinematicParticipantSet`: bounded participant IDs, roles, readiness/content revisions, connection generations, vote state.
- `CinematicMilestoneState`: compact frontier/bitset and last committed transaction.
- `CinematicLeaseSet`: owned lease handles for input, movement, ability, AI, damage, camera, and HUD policies.
- `CinematicBranchState`: gate ID, options, deadline, votes, chosen outcome.
- `CinematicPersistencePolicy`: checkpoint/resume/abort/migration class.
- `LocalCinematicPresentation`: non-authoritative adapter handle, local time, drift, binding generation, caption/audio-description settings.

Systems:

- request validation and session creation;
- content/readiness barrier;
- fixed-step clock and milestone scheduling;
- branch/vote resolution;
- terminal transaction and cleanup;
- lease acquisition/release;
- persistence/recovery/migration;
- replication/interest projection;
- local binding/playback/drift correction;
- telemetry and invariant validation.

Schedule authoritative systems before quest/reward/checkpoint publication where milestones can mutate them, then publish the committed results. Local presentation consumes snapshots after simulation.

## Component, System, Resource, and Event Interfaces

### Components

- `CinematicSessionState { session_id, cinematic_id, definition_revision, authority_epoch, phase, revision, start_tick, semantic_tick, next_milestone, outcome }`
- `CinematicParticipant { participant_id, role_id, connection_generation, readiness_revision, ready_mask, vote, local_skip_state }`
- `CinematicMilestones { frontier, optional_bitset, last_transaction_id }`
- `CinematicBranch { branch_id, options_revision, deadline_tick, policy_id, result }`
- `CinematicLeases { input, movement, abilities, ai, damage, interaction, camera, hud }`
- `LocalCinematicPresentation { adapter_id, binding_generation, local_time, target_time, drift, state }`

### Resources

- immutable `CinematicDefinitionRegistry`;
- synchronized gameplay clock and fixed-step counter;
- content/streaming readiness service;
- gameplay lease arbiter;
- command, vote, transaction, checkpoint, replay, and localization services;
- per-mode budgets and accessibility policy.

### Commands

- `RequestCinematic`
- `ReportCinematicReady`
- `RequestCinematicPause`
- `RequestCinematicSkip`
- `SubmitCinematicVote`
- `SubmitCinematicChoice`
- `AcknowledgeCinematicRecovery`
- privileged `AbortCinematic`

Every command includes session ID, expected revision, participant/connection generation, idempotency key, and authority-relevant evidence.

### Events

- `CinematicCreated`
- `CinematicReadinessChanged`
- `CinematicScheduled`
- `CinematicPhaseChanged`
- `CinematicMilestoneCommitted`
- `CinematicBranchOpened`
- `CinematicBranchResolved`
- `CinematicSkipResolved`
- `CinematicLeaseChanged`
- `CinematicCorrected`
- `CinematicCompleted`
- `CinematicAborted`
- `CinematicRecovered`

Reliable durable events are distinct from lossy local cue intents.

## Integration Plan

1. Inventory all cinematics and classify them as cosmetic-only, gameplay-gating, branching, multiplayer-synchronized, checkpointable, or skippable.
2. Define stable cinematic/role/milestone IDs, revisions, clock domains, terminal outcomes, and content-validation rules.
3. Implement the backend-neutral session lifecycle and generation-tagged lease arbiter before integrating an engine timeline.
4. Build one adapter that binds stable roles, starts/seeks/pauses/stops presentation, reports local readiness, and never commits gameplay state.
5. Convert one short single-player gameplay-gating scene; verify completion, skip, pause, save/load, death, and travel cleanup.
6. Add multiplayer readiness, scheduled start, sparse drift correction, late join, disconnect/reconnect, and vote policy.
7. Integrate transactional quest/world/checkpoint milestones, replay records, and definition migration.
8. Add captions, audio-description routing, manual dialogue advance where appropriate, motion/sensory controls, and sensitive-content warnings/bypass.
9. Certify every cinematic through automated content linting, fault injection, network simulation, and lease-leak tests.

## Verification Strategy

- Model-check legal lifecycle transitions, terminal uniqueness, and cleanup from every phase.
- Property-test idempotency: duplicate/reordered readiness, milestone, choice, skip, abort, and completion messages produce one result.
- Test deterministic same-step ordering among milestone, skip, disconnect, death, checkpoint, travel, and branch-deadline events.
- Inject missing assets, failed bindings, streaming timeout, slow client, packet loss, duplication, latency, clock drift, reconnect, host migration, and content-revision mismatch.
- Assert no local timeline callback can directly grant rewards, change quests, unlock doors, or release authoritative leases.
- Assert every terminal and recovery path releases all leases and restores a valid gameplay camera/input state.
- Verify FP, TP, split-screen, spectator, possessed/unpossessed, downed/dead, mounted, swimming, and loading transitions.
- Compare uninterrupted play, skip, replay, save/resume, and abort at every semantic boundary; durable outcomes must match declared policy.
- Test majority/unanimous/host/owner votes, ties, deadlines, churn, duplicate votes, late join, and privacy filtering.
- Profile maximum concurrent sessions, participant counts, milestone density, serialization size, correction traffic, and fixed-step spikes.
- Accessibility test pause, manual text advance, caption readability, audio descriptions, remapping, reduced motion/flashing, sensitive-content warning/bypass, and recovery without timed precision.
- Content lint every milestone for stable ID, ordering, repeatability, skip behavior, transaction owner, branch reachability, binding availability, and terminal cleanup.

## Risks and Open Decisions

- Which cinematics alter gameplay, and which are local presentation only?
- Is multiplayer playback mandatory for all participants, individually dismissible, or spectatable?
- Which readiness dependencies block start, and what are timeout/fallback policies?
- What clock continues through pause, loading, disconnect grace, and replay speed changes?
- Which consequences occur at start, named milestones, completion, skip, abort, or recovery?
- Which milestones are required-on-skip, reversible, optional, or mutually exclusive?
- What skip policies apply by mode, party role, first viewing, ranked state, and sensitive-content setting?
- Can branches pause world simulation; who chooses; what are deadline, tie, and disconnect rules?
- Are players invulnerable, frozen, hidden, repositioned, or AI-controlled during each phase?
- How do downing, death, respawn, possession, vehicle, water, and traversal interact with a session?
- Is mid-sequence save supported, restricted to semantic boundaries, or converted to terminal recovery?
- How are late join, reconnect, host migration, world travel, streaming unload, and missing content handled?
- What content revisions remain replay/save compatible, and when is semantic-only fallback acceptable?
- Which local accessibility changes are always permitted in competitive multiplayer?
- What are per-session participant, milestone, lease, vote, correction, serialization, and bandwidth caps?

## Engineering Recommendations

These are engineering recommendations derived from the sourced facts and the architecture constraints:

1. Treat every gameplay-relevant cinematic as a revisioned authoritative session; never make a timeline player or finish callback the source of gameplay truth.
2. Compile authored tracks into stable semantic milestones and commit consequences through existing idempotent command/transaction systems.
3. Synchronize multiplayer with readiness revisions, an authoritative start tick, semantic changes, and bounded drift correction—not per-frame RPCs.
4. Represent input, movement, ability, AI, damage, interaction, camera, and HUD changes as generation-tagged leases with mandatory idempotent cleanup.
5. Define skip as a terminal semantic transaction that executes required consequences exactly once; never implement it as only seeking to the last frame.
6. Route branches and skip votes through the ordinary authoritative command/vote framework with explicit deadlines, tie rules, membership generations, and anti-spam limits.
7. Save at semantic boundaries by default. Permit arbitrary-time resume only for content explicitly certified with reconstructible bindings, clock, and milestone state.
8. Record semantic session events for replay and tolerate presentation degradation across content revisions while preserving gameplay outcomes.
9. Keep local FP/TP camera, subtitles, audio description, motion, flashing, and dialogue-speed choices presentation-side unless they submit an explicit gameplay command.
10. Require pausable local cinematics, readable captions, configurable/manual text progression where needed, audio-description hooks, reduced-motion/sensory options, and sensitive-content bypass policy.
11. Cap and pool all participant, readiness, milestone, vote, lease, correction, and audit storage; update semantic state sparsely at fixed barriers.
12. Block release on content lint failures, leaked leases, non-idempotent milestones, divergent skip outcomes, unbounded network traffic, or missing recovery paths.

## Source Links

- Epic Games, [AReplicatedLevelSequenceActor API](https://dev.epicgames.com/documentation/unreal-engine/API/Runtime/LevelSequence/AReplicatedLevelSequenceActor?lang=en-US)
- Epic Games, [LevelSequenceActor Python API—replicate playback](https://dev.epicgames.com/documentation/en-us/unreal-engine/python-api/class/LevelSequenceActor?application_version=5.1)
- Epic Games, [How to reference the player in Unreal Engine cinematics](https://dev.epicgames.com/documentation/en-us/unreal-engine/how-to-reference-the-player-in-unreal-engine-cinematics)
- Epic Games, [Sequences, Shots, and Takes](https://dev.epicgames.com/documentation/unreal-engine/sequences-shots-and-takes-in-unreal-engine?lang=en-US)
- Epic Games, [Actor Role and Remote Role](https://dev.epicgames.com/documentation/en-us/unreal-engine/actor-role-and-remote-role-in-unreal-engine)
- Epic Games, [Multi-User Editing Overview—Sequencer synchronization limitations](https://dev.epicgames.com/documentation/en-us/unreal-engine/multi-user-editing-overview-for-unreal-engine)
- Epic Games, [Replay System](https://dev.epicgames.com/documentation/en-us/unreal-engine/using-the-replay-system-in-unreal-engine)
- Unity Technologies, [Unity 6 PlayableDirector API](https://docs.unity3d.com/ja/6000.0/ScriptReference/Playables.PlayableDirector.html)
- Unity Technologies, [Timeline overview—asset and instance separation](https://docs.unity3d.com/cn/2018.3/Manual/TimelineOverview.html)
- Microsoft, [Accessibility Feature Tags—pause cinematic content](https://learn.microsoft.com/en-us/gaming/accessibility/accessibility-feature-tags)
- Microsoft, [Xbox Accessibility Guideline 111: Audio descriptions](https://learn.microsoft.com/en-us/gaming/accessibility/xbox-accessibility-guidelines/111)
- Microsoft, [Xbox Accessibility Guideline 116: Time limits](https://learn.microsoft.com/en-us/gaming/accessibility/xbox-accessibility-guidelines/116)
- Microsoft, [Xbox Accessibility Guideline 117: Visual distractions and motion settings](https://learn.microsoft.com/en-us/gaming/accessibility/xbox-accessibility-guidelines/117)
- Microsoft, [Xbox Accessibility Guideline 123: Potentially harmful content](https://learn.microsoft.com/en-us/xbox/accessibility/xbox-accessibility-guidelines/123)
