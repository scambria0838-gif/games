# Operation Mythology Graphics Research Report

**Timestamp:** 2026-07-27 01:53:18 America/Los_Angeles  
**Subject:** Real-time global illumination and reflection architecture  
**Status:** New architectural baseline  
**Assumptions:** Modular D3D12/Vulkan renderer, explicit render-world extraction, temporal reconstruction contract, first- and third-person cameras, and no production-code implementation.

## 1. Feature Overview

Global illumination (GI) models indirect light arriving after one or more bounces. Reflections model view-dependent indirect specular. Neither is one algorithm: production renderers combine screen traces, cached world-space radiance, probes, simplified scene representations, hardware rays, temporal reuse, and fallbacks.

**Engineering recommendation:** Build one indirect-lighting service with separate diffuse and specular outputs over shared scene, trace, radiance-cache, temporal, and quality interfaces:

1. screen-space traces for cheap, high-detail first hits;
2. world-space radiance/irradiance caches for stable diffuse and rough-specular lighting;
3. software distance-field traces as a portable high-end fallback;
4. hardware ray queries/pipelines for triangle-accurate off-screen visibility where supported;
5. reflection probes/environment maps and SSAO as lower tiers;
6. temporal/spatial reconstruction for all under-sampled signals.

Do not promise path-traced truth. The goal is bounded, measurable indirect lighting with deterministic fallbacks.

## 2. Existing Coverage and Identified Gap

The cycle began with recursive scans of `C:\Users\steve\Desktop\GAME SKILLS` and `C:\Users\steve\Desktop\EXTRA SKILS\3D Graphics Rendering Shaders`.

Existing baselines cover GPU-driven submission, render graphs, hybrid shading, memory residency, virtual geometry/textures, ECS scheduling, temporal reconstruction, and scalable virtual/hybrid shadows. They provide depth, normals, material properties, motion, histories, virtualized scene data, and optional acceleration structures.

The uncovered decisions are:

- shared scene representation for diffuse GI and reflections;
- screen-space, distance-field, probe, and hardware-ray fallback ordering;
- surface/radiance cache ownership and update policy;
- diffuse versus rough/glossy specular separation;
- material evaluation at ray hits versus cached lighting lookup;
- dynamic/skinned geometry coverage;
- disocclusion, leakage, convergence, and memory controls;
- quality tiers for non-ray-tracing and constrained hardware.

## 3. Sourced Facts

1. Epic documents Lumen as using screen traces first, followed by software distance-field or hardware triangle ray tracing [1].
2. Lumen's Surface Cache stores material properties from mesh card captures and supports amortized lighting updates over multiple frames. Epic documents coverage limits for complex interiors, view-dependent materials, and deforming skeletal meshes [1].
3. Epic states that hardware ray tracing supports more geometry types and higher-quality hit lighting, but has higher scene-update cost, particularly for many overlapping instances and skinned triangles [1][2].
4. Epic's current scalability documentation uses world-space radiance/irradiance caches, lower-resolution gathering, temporal reconstruction, and screen-space reflections/rough probe specular in lower quality modes [3].
5. NVIDIA RTXGI DDGI stores irradiance and distance statistics in world-space probes, uses ray tracing for updates, and is explicitly a low-frequency diffuse solution with temporal latency and potentially significant large-world memory [4].
6. AMD FidelityFX Brixelizer GI is a compute HLSL technique using sparse distance-field cascades, a radiance cache, screen probes, irradiance-cache projection, temporal resources, and separate diffuse/specular outputs [5][6].
7. AMD documents feeding prior composited lighting into its radiance cache for an approximate multi-bounce result and offers internal-resolution tiers down to 25 percent of native [5].

**Cross-source conclusion:** Modern real-time GI depends on hierarchical scene representations and temporally amortized radiance caches. Screen information supplies detail, probes/caches supply stability and off-screen coverage, and triangle rays increase accuracy at substantial update/traversal cost.

## 4. Industry-Standard Rendering API or Pattern

### Trace hierarchy

For each probe or selected pixel:

1. attempt a short screen-space trace using depth/Hi-Z;
2. continue or restart in a world representation when the ray leaves the screen, crosses a depth ambiguity, or fails validation;
3. choose software SDF tracing or hardware ray query by platform and material/geometry eligibility;
4. shade the hit from a surface/radiance cache by default;
5. evaluate the actual hit material and direct lighting only for high-quality glossy reflection tiers;
6. fall back to sky/environment/probe radiance on a miss.

### Diffuse GI

Spawn adaptive screen probes from visible depth, trace a bounded directional set, reproject valid probe history, filter, and project results into a world-space irradiance/radiance cache. Shade visible pixels by occlusion-aware interpolation plus contact AO.

World probes use scrolling camera-relative clipmaps or bounded volumes. Each probe stores low-frequency directional irradiance and visibility/distance moments. Update only a budgeted subset selected by visibility, age, variance, invalidation, and camera motion.

### Reflections

Classify by roughness and projected ray footprint:

- mirror/smooth: screen trace, then hardware/world fallback, followed by reflection denoising;
- medium roughness: fewer rays and radiance-cache lookup;
- very rough: prefiltered irradiance/radiance cache or environment probes;
- unsupported/translucent: authored planar/capture/environment fallback.

Keep planar reflections as a specialized correctness option for hero mirrors/water, not the general solution.

### Scene representations

- primary triangles/virtual geometry: authoritative visible surface;
- Hi-Z/depth: current-view screen tracing;
- sparse SDF/voxel cascades: portable world tracing and far field;
- TLAS/BLAS: high-quality triangle tracing;
- surface cache: material and/or lighting lookup at hits;
- radiance/irradiance probes: temporally amortized indirect signal.

Each representation has explicit coverage, version, invalidation, and fallback semantics.

## 5. CPU, GPU, Memory, and Bandwidth Considerations

Let `P` be shaded pixels, `Q` screen probes, `r` rays per updated probe/pixel, `U` updated world probes, and `T` acceleration-structure work:

- classification/gather/interpolation: **O(P)**;
- screen/world tracing: approximately **O((Q×r)+specularRays)** with traversal-dependent cost;
- probe update/filter: **O(U×r)** plus bounded spatial work;
- TLAS/BLAS update: dependent on instances and changed/deformed geometry, represented as **O(T)**;
- temporal reconstruction: **O(P)** at internal or output resolution.

### CPU and concurrency

- Dirty extraction updates scene-representation records in **O(D)**.
- GPU compaction produces probe/ray lists and indirect dispatch arguments; no frame-critical count readback.
- SDF voxelization, surface capture, AS builds, and cache updates run as bounded jobs/passes with explicit timelines.
- Use persistent contexts and pooled update records; no steady-state general-heap allocation.
- Shader/PSO variants for trace and hit-lighting classes are precompiled asynchronously and warmed.

### GPU behavior

- Screen traces are bandwidth/cache heavy but coherent.
- SDF ray marching trades triangle traversal for repeated 3D texture/AABB accesses; long grazing rays raise iteration count.
- Hardware rays depend on BVH coherence, overlap, alpha handling, and instance count.
- Hit-material evaluation introduces bindless texture traffic, shader divergence, and extra shadow rays.
- Classified rays and sorted material/light classes improve wave coherence.
- Trace/denoiser passes should report occupancy, registers, traversal iterations, cache misses, and divergence.

### VRAM and bandwidth

Budget separately:

- SDF/voxel cascades and brick metadata;
- TLAS/BLAS, scratch, and compaction buffers;
- surface material/radiance atlases;
- probe irradiance/distance/age/validity volumes;
- screen-probe, ray, variance, reservoir, and denoiser histories;
- diffuse/specular internal-resolution targets.

Persistent caches/histories are imported render-graph resources and cannot alias transiently. Hardware and software tracing representations should not both remain resident by default if the platform cannot afford their combined memory.

### Synchronization and latency

Scene updates precede traces; direct-light/shadow updates precede cache lighting; traces precede reconstruction; reconstructed indirect light precedes final lighting/post. Async compute is accepted only when it shortens the end-to-end critical path. Multi-frame cache updates intentionally add lighting latency, which must be exposed as convergence age rather than hidden.

## 6. Pros and Cons

### Screen traces

**Pros:** current high-detail geometry, no separate world structure, cache coherent.  
**Cons:** off-screen misses, disocclusion, thickness ambiguity, view dependence.

### Probe/radiance caches

**Pros:** amortized multi-view/off-screen lighting, low ray count per frame, scalable diffuse.  
**Cons:** low frequency, leakage, memory, delayed response, difficult placement/scrolling.

### Sparse SDF/voxel tracing

**Pros:** vendor-neutral compute, stable large-world cost, useful far field.  
**Cons:** thin/detail loss, representation updates, ray-march iterations, material lookup indirection.

### Hardware triangle tracing

**Pros:** accurate geometry, skinned support, strong glossy reflections.  
**Cons:** AS memory/update, overlap/alpha cost, traversal divergence, expensive hit lighting.

## 7. ECS and Render-World Integration

ECS stores logical policy only:

- `LightComponent`, `RenderableComponent`, `ReflectionProbeComponent`;
- material asset handles and GI participation flags;
- optional importance/static-dynamic classification;
- renderer-neutral camera quality policy.

Render extraction produces stable instance/material/light IDs, current/previous transforms and bounds, deformation epochs, SDF/AS/surface-cache eligibility, emissive state, and invalidation records.

The renderer owns probes, cards, bricks, acceleration structures, reservoirs, histories, and physical cache slots. FP and TP cameras use separate screen histories but may share world-space radiance caches when origin, exposure domain, and world generation match.

## 8. Resource, Pass, Material, and Visibility Interfaces

### `IndirectLightingPolicy`

- diffuse/specular quality tier;
- trace backends and fallback order;
- internal resolution and ray/probe budgets;
- maximum distance and far-field policy;
- hit-lighting eligibility;
- temporal response/convergence target;
- per-view/cache-sharing rules.

### Inputs/outputs

Inputs: depth, normals, roughness/metallic, motion, emissive/direct lighting, visibility IDs, shadow interface, Hi-Z, scene representation handles, exposure, and reset generations.

Outputs:

- diffuse irradiance/radiance;
- specular indirect radiance plus confidence/hit distance;
- optional bent normal/AO;
- debug coverage, age, variance, and trace-source classifications.

### Material contract

Materials declare cache-capture evaluator, ray-hit evaluator tier, emissive importance, two-sided/alpha behavior, and deformation support. View-dependent nodes require a defined cache approximation or hit-lighting-only classification.

### Graph passes

Scene updates → screen-probe/classification → screen/world traces → hit/cache shading → temporal validation → spatial filtering/denoise → world-cache injection → diffuse/specular resolve → lighting composition.

## 9. Asset and Runtime Integration Plan

1. Ship reflection captures, SSAO, and SSR as reference/fallback.
2. Define shared trace, hit, radiance-cache, and indirect-output contracts.
3. Implement screen tracing with confidence and debug classification.
4. Add scrolling DDGI-style diffuse probe volumes with baked preload support.
5. Add sparse SDF/voxel cascades and a GPU-budgeted scene update path.
6. Add adaptive screen probes and world radiance-cache injection.
7. Implement roughness-classified reflections with environment/probe fallback.
8. Add D3D12/Vulkan hardware-ray adapters using shared render-world IDs.
9. Add surface-cache hit lighting, then optional actual-material hit lighting.
10. Integrate temporal denoising with motion, depth, exposure, and reset contracts.
11. Connect all persistent/private memory to residency telemetry.
12. Build platform presets and automatic deterministic degradation.

## 10. Visual and Performance Verification Strategy

Test indoor/outdoor transitions, emissive changes, moving sun/lights, opening doors, camera cuts, mirrors, glossy-to-rough materials, thin geometry, foliage, skinned crowds, water, large worlds, and streamed cells.

Visualize trace source, misses, probe placement, probe age, cache coverage, SDF cascade, AS instances, hit distance, variance, disocclusion, and diffuse/specular histories.

Compare against an offline/path-traced reference for color bleeding, indirect intensity, reflection parallax, contact occlusion, leakage, energy stability, and temporal convergence.

Record:

- CPU scene update/submission and allocations;
- rays, probe updates, trace iterations, hit/miss/source rates;
- SDF update, AS build/update, trace, shade, cache, denoise, and resolve GPU times;
- draw/dispatch counts and indirect workloads;
- registers, occupancy, divergence, cache behavior, bandwidth;
- persistent/transient/private VRAM;
- barriers, queue overlap/waits, frame latency, and tails;
- lighting response/convergence frames after a change.

Acceptance gates:

- no invalid history across cuts, rebases, or streamed generations;
- bounded leakage and deterministic fallback for uncovered geometry;
- no CPU readback or steady-state heap allocation;
- stable frame time under update/ray budgets;
- every quality tier fits declared VRAM and GPU budgets;
- hardware rays beat the software/reference tier in a stated quality/performance target.

## 11. Platform and Scalability Risks

- SDF and triangle scenes can double memory and update work.
- Thin, one-sided, alpha, and deforming geometry challenge software representations.
- Large overlapping triangle scenes and skinned meshes raise AS costs.
- Probe spacing trades leaks/detail for memory and update latency.
- Low internal resolution amplifies temporal smearing and disocclusion.
- Glossy hit lighting multiplies material, texture, and shadow work.
- Tile/mobile/VR targets may require baked probes, captures, SSAO, and limited SSR.
- Dynamic resolution and camera teleport can overload probe/cache update budgets.
- Multi-view sharing may create stale or view-biased lighting.

## 12. Engineering Recommendations

1. Separate diffuse GI and specular reflection outputs while sharing tracing and caches.
2. Use screen traces as opportunistic detail, never the sole off-screen solution.
3. Make a scrolling irradiance/radiance cache the scalable diffuse backbone.
4. Establish a compute SDF/voxel fallback before requiring hardware rays.
5. Add hardware rays as a capability tier for off-screen and glossy accuracy.
6. Default ray-hit shading to cached lighting; gate actual-material hit lighting.
7. Budget probe/ray updates by variance, age, visibility, and camera motion.
8. Reuse the temporal contract and expose confidence, variance, hit distance, and reset reasons.
9. Keep reflection captures, SSR, SSAO, and baked/preloaded probes as first-class fallbacks.
10. Measure combined SDF + AS residency before enabling both simultaneously.

### Remaining open decisions

- DDGI volumes versus adaptive world-probe clipmaps.
- SDF/voxel representation, cascade scale, and update budget.
- Surface-cache parameterization and material coverage.
- Screen-probe layout/ray count and world-cache injection.
- Reflection roughness thresholds and planar-reflection policy.
- Hardware-ray floor and hit-lighting tier.
- Denoiser/reservoir design and history memory.
- Cache sharing between FP/TP, reflections, stereo, and editor views.

## 13. Source Links

1. Epic Games, **Lumen Technical Details, Unreal Engine 5.8**: https://dev.epicgames.com/documentation/en-us/unreal-engine/lumen-technical-details-in-unreal-engine
2. Epic Games, **Hardware Ray Tracing in Unreal Engine 5.8**: https://dev.epicgames.com/documentation/en-us/unreal-engine/hardware-ray-tracing-in-unreal-engine
3. Epic Games, **Lumen Performance Guide**: https://dev.epicgames.com/documentation/en-us/unreal-engine/lumen-performance-guide-for-unreal-engine
4. NVIDIA, **RTXGI DDGI Algorithms**: https://github.com/NVIDIAGameWorks/RTXGI-DDGI/blob/main/docs/Algorithms.md
5. AMD GPUOpen, **FidelityFX Brixelizer GI 1.0.1**: https://gpuopen.com/manuals/fidelityfx_sdk/techniques/brixelizer-gi/
6. AMD GPUOpen, **FidelityFX Brixelizer 1.0**: https://gpuopen.com/manuals/fidelityfx_sdk/techniques/brixelizer/

