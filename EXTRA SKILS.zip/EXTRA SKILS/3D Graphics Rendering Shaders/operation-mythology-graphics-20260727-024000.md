# Operation Mythology Graphics Research — Variable-Rate Shading, Foveation, and Resolution Domains

**Timestamp:** 2026-07-27 02:40:00 America/Los_Angeles  
**Scope:** VRS, fixed and gaze-tracked foveation, fragment-density rendering, dynamic resolution, temporal upscaling, mixed-resolution passes, UI, and platform scalability.

## 1. Feature Overview

Variable-rate shading (VRS) reduces pixel-shader invocation frequency without necessarily reducing visibility, depth, stencil, or render-target resolution. Foveation applies nonuniform quality around a fixed focus or measured gaze. Fragment-density and multi-resolution methods can also reduce raster/attachment work by changing spatial sampling density.

The engine needs one **resolution-domain contract** covering:

- native output, internal render, and dynamic-resolution extents;
- shading-rate/foveation map extent and tile alignment;
- half/quarter/custom-resolution effects;
- per-view gaze/focus state and prediction;
- motion/depth/reactive data resolution;
- pass capability, exclusion, and reconstruction rules.

## 2. Existing Coverage and Identified Gap

The recursive scan found 14 `GAME SKILLS` files and 14 dedicated graphics files. Prior reports already cover temporal upscaling, motion vectors, render graphs, post processing, transparency, performance, and platform tiers.

The remaining gap is not general upscaling. It is:

- how per-draw, per-primitive, and image-based shading rates combine;
- when coarse shading saves shader work but not fill bandwidth;
- derivative/mip/LOD consequences;
- foveation-map timing and gaze uncertainty;
- exclusions for alpha test, transparency, velocity, depth-sensitive and sample-frequency passes;
- composition across native, dynamic, foveated, and reduced-resolution domains.

## 3. Sourced Facts

The following are sourced facts:

- Microsoft defines D3D12 VRS Tier 1 as per-draw only. Tier 2 adds per-primitive and screen-space image sources plus combiners and a pixel-shader semantic exposing the final shading rate.
- D3D12 guarantees full-resolution depth, stencil, and coverage under coarse pixel shading. Coarse shading changes screen-space derivatives and therefore can select lower-detail texture mips.
- Microsoft documents Tier 2 shading-rate image granularity using hardware-queried square tiles and requires the application to size the image from render-target dimensions and tile size.
- `VK_KHR_fragment_shading_rate` likewise supports pipeline/per-draw, primitive, and framebuffer-region attachment rates that can be combined.
- `VK_EXT_fragment_density_map` permits fewer fragment invocations and subsampled attachments; Khronos identifies lens-distorted edges and gaze periphery as principal use cases.
- AMD FidelityFX Variable Shading builds a control image from prior linear color and motion data. AMD states that VRS primarily reduces expensive pixel-shader work; it does not reduce pixels written, so fill-rate-bound passes benefit little.
- NVIDIA distinguishes VRS from multi-resolution/lens-matched shading: VRS can decouple shading rate from visibility rate. NVIDIA also documents spatial shading-rate control and foveated supersampling/quality regions.
- OpenXR’s foveation extensions expose swapchain foveation profiles and fixed/dynamic level policy. The documented dynamic mode changes foveation according to available performance headroom up to a desired maximum.

## 4. Industry-Standard Rendering API or Pattern

Build one per-view `ResolutionDomainPlan` before graph compilation:

1. Query platform capabilities: VRS tier/rates/tile size/combiners, fragment-density support, eye tracking, multiview, and upscaler constraints.
2. Choose output and internal render extents.
3. Predict gaze/focus at the expected photon/display time; fall back to fixed center or content-adaptive focus if confidence is low.
4. Generate a conservative shading-rate map from:
   - foveal rings and gaze uncertainty;
   - motion and luminance/edge variance;
   - material/pass exclusion masks;
   - UI, text, thin geometry, alpha test, specular highlights, and first-person priority;
   - GPU headroom hysteresis.
5. Apply rate sources with explicit combiners. “Force fine” exclusions must win over coarse scene suggestions.
6. Keep visibility/depth/velocity at full required resolution when reconstruction depends on them.
7. Reproject/upscale each lower-resolution effect exactly once into a documented composition domain.
8. Render UI, reticles, readable text, and critical overlays at native/full rate after scene reconstruction unless a platform compositor owns them.

Recommended pass classes:

- `FineRequired`: depth/velocity, alpha-tested thin geometry, UI, unstable highlights, transparency/deep visibility.
- `CoarseEligible`: expensive opaque material lighting, fog/volumes, selected shadow/filter passes.
- `RateAware`: shader reads delivered rate and adjusts samples/mips safely.
- `IndependentResolution`: half/quarter-resolution effect with its own reconstruction.

## 5. CPU, GPU, Memory, and Bandwidth Considerations

**CPU complexity:** feature/capability selection is constant per view; rate-map policy is linear in shading-rate tiles. Generate maps on GPU to avoid CPU readback. CPU builds immutable per-pass domain descriptors and barriers, with no per-tile heap objects.

**GPU complexity and draw/dispatch counts:** content-adaptive/foveated map generation adds one or more compute dispatches per view. VRS does not reduce draw count or primitive processing. It saves work only when pixel shading dominates. Independent-resolution passes add reconstruction dispatches; excessive domains can erase savings.

**Allocations and VRAM residency:** rate images are small, but mixed-resolution systems accumulate color, depth, history, confidence, masks, and reconstruction targets. Track all extents in bytes, not just scale ratios. Fragment-density/subsampled attachments may save more bandwidth/storage than VRS but require different render-pass resource declarations.

**Memory bandwidth and cache behavior:** VRS still writes fine-resolution targets on conventional paths, so color/depth bandwidth and ROP pressure remain. Coarse shading can improve texture/constant cache reuse, yet derivative-driven lower mips alter quality. True lower-resolution attachments reduce bandwidth but require resampling and may reduce cache coherence at domain boundaries.

**Shader divergence:** the rate itself is spatially coherent by tiles, but branches on `SV_ShadingRate`/equivalent, material exclusions, or foveal rings can diverge near boundaries. Prefer separate pass variants or arithmetic sample-count selection. Do not let coarse footprints cross discontinuities that require per-pixel evaluation.

**Synchronization and concurrency:** the rate image must finish and transition to the API’s required source/attachment state before dependent raster passes. A previous-frame adaptive map avoids a same-frame critical path but must use motion/gaze prediction and invalidation. Async generation is valuable only if it does not introduce queue waits before the base pass.

**Batching:** per-draw VRS can become a PSO/command-state bucketing dimension. Tier 2 image-based VRS preserves batching better. Use per-primitive rates only where mesh/vertex data already carries a stable quality semantic.

**Streaming:** texture mip bias and material LOD must account for delivered shading rate. Foveal movement can rapidly increase demanded texture detail; streaming prediction should expand around predicted gaze and retain a guard band to prevent visible mip pumping.

**Frame latency and concurrency:** gaze age includes sensor, filtering, application, render queue, compositor, and scanout latency. Late-latched gaze/foveation is desirable, but changing a rate/density map after command generation must obey API/runtime synchronization. Record gaze-to-photon age, prediction error, missed deadlines, and foveal-region movement.

## 6. Pros and Cons

| Method | Pros | Cons |
|---|---|---|
| Per-draw VRS | Simple, broad Tier 1 path | Coarse granularity; hurts mixed-detail draws; more state buckets |
| Image-based VRS | Fine spatial policy; preserves geometry/visibility | Map generation/sync; tile artifacts; no fill-rate reduction |
| Per-primitive VRS | Content-aware geometry policy | Mesh data/viewport restrictions; small triangles gain little |
| Fragment-density/multi-resolution | Can reduce shading and attachment bandwidth | More platform-specific; coordinate/resampling complexity |
| Fixed foveation | No eye tracker or gaze latency | User may look into coarse region |
| Eye-tracked foveation | Quality follows attention; larger savings potential | Prediction, privacy, calibration, failure modes, temporal artifacts |
| Dynamic resolution | Broad GPU-work reduction | Changes all sampling/history domains; reconstruction cost |
| Mixed-resolution effects | Strong targeted savings | Extra buffers, filters, barriers, halos, domain bugs |

## 7. ECS and Render-World Integration

VRS and foveation are view/render policy, not gameplay ECS state.

View-facing data:

- `RenderViewQuality`: output/internal extent, dynamic-resolution target, camera role;
- `ViewFocusState`: gaze/fixed focus, confidence, sample time, prediction time, validity;
- `ViewImportanceMask`: first-person weapon, reticle, interaction target, accessibility exclusions;
- platform capability handle and user comfort/privacy policy.

Render extraction converts relevant world bounds/material flags into a compact fine-rate exclusion/importance stream. Render-world records should expose:

- `VrsEligibility`;
- thin/alpha-tested/translucent/specular-risk flags;
- projected bounds and motion;
- first-person/world layer;
- history and resolution-domain IDs.

Do not store shading-rate tiles as ECS components. They are transient renderer resources derived per view.

## 8. Resource, Pass, Material, and Visibility Interfaces

```text
ResolutionDomain {
  logicalExtent, physicalExtent, viewport, scale,
  samplePattern, shadingRateMode, historyDomainId
}

ShadingRatePolicy {
  baseRate, supportedRates, tileSize, combiners,
  foveaCenter, confidenceRadius, ringThresholds,
  motionThreshold, varianceThreshold, forceFineMasks
}

PassResolutionContract {
  inputDomains[], outputDomain,
  vrsClass, derivativePolicy, reconstructionMode,
  depthVelocityRequirement, historyPolicy
}
```

Core resources:

- shading-rate or fragment-density image per view;
- gaze/focus history and prediction constants;
- motion/luminance/edge reduction inputs;
- fine-rate exclusion/importance mask;
- domain-specific depth, motion, reactive, confidence, color, and history resources;
- debug overlays for delivered rate, gaze age, and domain boundaries.

Pass APIs:

- `BuildRateInputs(previousColor, motion, exclusions, gaze) -> tileMetrics`
- `GenerateShadingRate(tileMetrics, policy) -> rateImage`
- `BindResolutionDomain(pass, domain, rateImage)`
- `ReconstructDomain(source, sourceDepthMotion, destination) -> composedOutput`
- `ValidateDomainEdges(graph) -> diagnostics`

## 9. Asset and Runtime Integration Plan

1. Add material metadata for VRS eligibility, thin detail, alpha test, derivative sensitivity, specular instability, and minimum rate.
2. Cook conservative defaults; artists may request finer shading but should not force unsafe coarse shading.
3. Add platform capability tables for D3D12/Vulkan/OpenXR tiers, rates, tiles, combiners, multiview, and density attachments.
4. Introduce resolution-domain types into render-graph resource descriptors and validation.
5. Implement per-draw 1x1/2x2 experiments, then Tier 2 image-based maps with a force-fine mask.
6. Add motion/variance adaptive generation using already-produced buffers.
7. Integrate fixed foveation; add eye-tracked prediction only when runtime support and privacy/comfort policy exist.
8. Make temporal upscaling consume delivered-rate/confidence data where useful and reset histories on domain-policy discontinuities.
9. Feed gaze-expanded demand to texture streaming.
10. Add dynamic headroom control with hysteresis and rate-of-change limits.

## 10. Visual and Performance Verification Strategy

Test scenes:

- fine text, fences, foliage, wires, hair, particles, and specular microdetail;
- slow/fast camera motion and motion blur;
- depth-of-field and fog;
- first-person weapon/reticle over moving world;
- high-contrast edges crossing VRS tile/foveal boundaries;
- eye-tracked saccades, tracking loss, calibration error, and late gaze;
- dynamic-resolution changes combined with foveation.

Visual checks:

- native 1x1 reference and platform captures;
- derivative/mip differences, shimmer, block boundaries, thin-detail loss, highlight breakup;
- temporal ghosting and history confidence;
- binocular consistency and comfort for XR;
- UI/text legibility and first-person stability.

Performance captures must include:

- CPU policy/graph/command time and allocations;
- GPU rate-map, raster, lighting, reconstruction, and post time;
- draws, dispatches, pixel-shader invocations, coarse/fine pixel distribution;
- VRAM allocations/residency by resolution domain;
- render-target/texture bandwidth and cache counters;
- wave occupancy and shader divergence;
- barriers, queue waits, synchronization, async overlap, and concurrency;
- streaming mip demand/misses around gaze;
- frame latency, gaze-to-photon age, prediction error, and percentile pacing.

Acceptance requires measurable shader-bound savings, no regression in fill-bound scenes, bounded domain memory, zero warm-frame heap allocation, correct full-rate exclusions, stable temporal output, and deterministic fallback when VRS/gaze is unavailable.

## 11. Platform and Scalability Risks

- VRS tiers, tile sizes, extra rates, combiners, fragment-density features, and XR extensions differ by device.
- Coarse derivatives change texture mip choice and procedural filtering.
- Small triangles, alpha test, transparency, sample-frequency shaders, and fill-bound passes may gain little or regress.
- Gaze tracking can fail, drift, arrive late, or be unavailable; privacy and accessibility policy are required.
- Rapidly moving foveal regions can expose coarse history and texture mips.
- Mixed resolution creates coordinate, jitter, viewport, depth, motion, and history conversion bugs.
- Multiview/instanced stereo may require per-eye maps and capability-specific binding.
- Debug captures must record delivered rather than merely requested rate.

Scalability controls: internal resolution, base rate, allowed coarse rates, foveal radii, gaze guard band, fixed/dynamic mode, variance/motion thresholds, per-pass enablement, fragment-density tier, reconstruction quality, streaming guard band, and headroom target.

## 12. Engineering Recommendations

The following are engineering recommendations:

1. Make resolution domains and coordinate transforms first-class render-graph metadata.
2. Start with a conservative force-fine exclusion mask and image-based Tier 2 VRS; retain per-draw fallback.
3. Apply VRS only to measured shader-bound passes; do not expect fill-rate, geometry, draw-count, or bandwidth savings.
4. Preserve full-quality depth, velocity, alpha-tested detail, transparency, UI, reticles, and unstable specular unless validated otherwise.
5. Account for coarse derivatives explicitly through shader rate awareness, mip policy, or feature exclusion.
6. Generate content-adaptive maps from existing color/motion data and combine them with foveation and material rules.
7. Predict gaze to display time, expand the fovea by uncertainty, and fall back smoothly on tracking loss.
8. Integrate foveal texture-streaming guard bands and prevent policy oscillation with hysteresis.
9. Reconstruct each reduced-resolution effect once into a named domain and validate every cross-domain edge.
10. Instrument delivered rates, shader invocations, VRAM, bandwidth, cache, divergence, synchronization, streaming, latency, and concurrency before enabling by default.

Open decisions: supported platform floor; VRS versus density-map hierarchy; rate combiners; fine-mask producers; derivative/mip policy; temporal-upscaler integration; gaze predictor and privacy policy; foveal radii/guard band; dynamic headroom controller; per-pass eligibility; multiview binding; and platform budgets.

## 13. Source Links

- [Microsoft — Direct3D 12 Variable-Rate Shading](https://learn.microsoft.com/en-us/windows/win32/direct3d12/vrs)
- [Khronos — VK_KHR_fragment_shading_rate](https://registry.khronos.org/VulkanSC/specs/1.0-extensions/man/html/VK_KHR_fragment_shading_rate.html)
- [Khronos — VK_EXT_fragment_density_map](https://registry.khronos.org/vulkan/specs/latest/man/html/VK_EXT_fragment_density_map.html)
- [AMD GPUOpen — FidelityFX Variable Shading](https://gpuopen.com/manuals/fidelityfx_sdk/techniques/variable-shading/)
- [AMD GPUOpen — FidelityFX Variable Shading Sample](https://gpuopen.com/manuals/fidelityfx_sdk/samples/variable-shading/)
- [NVIDIA — Variable Rate Shading](https://developer.nvidia.com/vrworks/graphics/variablerateshading)
- [NVIDIA — Advanced API Performance: Variable Rate Shading](https://developer.nvidia.com/blog/advanced-api-performance-variable-rate-shading/)
- [Khronos — XR_FB_foveation](https://registry.khronos.org/OpenXR/specs/1.0/man/html/XR_FB_foveation.html)
- [Khronos — XR_FB_foveation_configuration](https://registry.khronos.org/OpenXR/specs/1.0/man/html/XR_FB_foveation_configuration.html)
- [Khronos — XR_VARJO_foveated_rendering capability](https://registry.khronos.org/OpenXR/specs/1.0/man/html/XrSystemFoveatedRenderingPropertiesVARJO.html)
