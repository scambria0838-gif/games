# Operation Mythology — 3D Graphics, Rendering, and Shaders Research Index

This index covers reports saved in `C:\Users\steve\Desktop\EXTRA SKILS\3D Graphics Rendering Shaders`.

Before every new batch, recursively scan:

1. `C:\Users\steve\Desktop\GAME SKILLS`
2. `C:\Users\steve\Desktop\EXTRA SKILS\3D Graphics Rendering Shaders`

Research only uncovered subjects, unresolved architectural decisions, source corrections, or meaningful technical updates.

## 2026-07-27 01:49:09 America/Los_Angeles

- **Report path:** `C:\Users\steve\Desktop\EXTRA SKILS\3D Graphics Rendering Shaders\operation-mythology-graphics-20260727-014909.md`
- **Timestamp:** `20260727-014909`
- **Subjects covered:** Directional and local-light shadow architecture; virtual shadow pages; directional clipmaps; local-light mips; receiver-driven allocation; cache invalidation; physical page pools; GPU caster binning; filtering; conventional compatibility maps; inline ray queries; hybrid classification and denoising; ECS/render-world interfaces; profiling and scalability.
- **Major sourced claims:**
  - Epic documents 128×128 virtual shadow pages allocated from visible receiver demand and cached until invalidated.
  - Epic identifies light/caster movement and position-modifying materials as major invalidation sources and exposes allocated/cached/invalidated page telemetry.
  - D3D12 Tier 1.1 and Vulkan `VK_KHR_ray_query` support inline ray queries from existing shader stages.
  - AMD demonstrates 8×4-tile shadow classification, compact ray masks, interval reduction, hybrid raster/ray shadows, and denoising.
  - NVIDIA NRD provides SIGMA temporal/spatial denoisers for infinite and local-light shadow signals.
- **Engineering recommendations:**
  - Use a unified tiered shadow service.
  - Retain conventional cascades/atlases as reference and compatibility.
  - Make receiver-driven virtual shadow maps the high-end raster destination.
  - Generate page requests, caster lists, indirect draws, and ray counts on the GPU.
  - Treat cache invalidation and overflow behavior as first-class correctness and telemetry.
  - Use classified ray queries only for measured high-value cases.
  - Share temporal and acceleration-structure infrastructure with GI/reflections where contracts align.
- **Sources:**
  - Epic Virtual Shadow Maps documentation
  - Epic Nanite SIGGRAPH 2021 presentation
  - Microsoft DirectX Raytracing functional specification
  - Khronos `VK_KHR_ray_query` reference and sample
  - AMD FidelityFX Classifier and Hybrid Shadows documentation
  - NVIDIA NRD documentation
- **Remaining open decisions:** Physical page/depth format and pool budget; directional clipmaps; local-light projection; static/dynamic cache split; filtering and bias; local-light shadow cap; foliage invalidation; ray-query floor/classifier/denoiser; acceleration-structure ownership; VR/MSAA policy.

## 2026-07-27 01:53:18 America/Los_Angeles

- **Report path:** `C:\Users\steve\Desktop\EXTRA SKILS\3D Graphics Rendering Shaders\operation-mythology-graphics-20260727-015318.md`
- **Timestamp:** `20260727-015318`
- **Subjects covered:** Real-time diffuse global illumination and specular reflections; screen traces; scrolling irradiance/radiance caches; DDGI-style probes; surface caches; sparse SDF/voxel tracing; hardware triangle rays; hit lighting; denoising; temporal convergence; ECS, render-world, material, pass, memory, and scalability contracts.
- **Major sourced claims:**
  - Epic Lumen combines screen traces with software distance-field or hardware triangle tracing and uses a Surface Cache with amortized lighting updates.
  - Epic documents higher geometry/quality coverage and higher scene-update cost for hardware rays, especially with overlap and skinned geometry.
  - NVIDIA RTXGI describes DDGI as low-frequency diffuse irradiance with temporal latency and potentially significant large-world memory.
  - AMD Brixelizer GI uses sparse distance-field cascades, screen probes, radiance/irradiance caches, temporal resources, and separate diffuse/specular outputs.
- **Engineering recommendations:** Separate diffuse/specular outputs while sharing trace and cache infrastructure; make world-space radiance/irradiance caches the diffuse backbone; use screen traces opportunistically; establish a compute SDF/voxel fallback; add hardware rays for measured off-screen/glossy quality; default to cached hit lighting; retain SSR, SSAO, captures, and baked/preloaded probes as fallbacks.
- **Sources:** Epic Lumen technical/performance and hardware-ray documentation; NVIDIA RTXGI DDGI algorithms; AMD FidelityFX Brixelizer and Brixelizer GI manuals.
- **Remaining open decisions:** World-probe layout; SDF/voxel cascades; surface cache; screen-probe rays; roughness/planar thresholds; hardware floor/hit lighting; denoiser/reservoir memory; multi-view cache sharing.

## 2026-07-27 01:57:06 America/Los_Angeles

- **Report path:** `C:\Users\steve\Desktop\EXTRA SKILS\3D Graphics Rendering Shaders\operation-mythology-graphics-20260727-015706.md`
- **Timestamp:** `20260727-015706`
- **Subjects covered:** HLSL/DXC shader toolchain; DXIL/SPIR-V artifacts; permutation constraints; canonical shader and pipeline keys; offline derived data; manifests; asynchronous compilation; fallback PSOs; D3D12 pipeline libraries; Vulkan pipeline caches, graphics pipeline libraries, and pipeline binaries; memory, batching, CI, and hitch telemetry.
- **Major sourced claims:**
  - D3D12 pipeline libraries serialize/recreate PSOs, and Microsoft's sample uses an uber-shader fallback while specialized compilation completes.
  - Vulkan pipeline caches are persistent but device/driver dependent.
  - Vulkan graphics pipeline libraries split reusable state; pipeline binaries expose explicit implementation-specific key/data persistence.
  - Epic documents severe runtime PSO hitches and tracks hits, misses, untracked, and too-late precache states.
  - DXC can compile shared HLSL sources to DXIL and SPIR-V.
- **Engineering recommendations:** Use content-addressed, versioned shader/pipeline keys; pin compiler/validator versions; constrain static features in CI; compile offline; generate and validate pipeline manifests; prohibit synchronous shipping compilation; keep fallback PSOs resident; use bounded background creation; treat API caches as accelerators rather than authoritative coverage.
- **Sources:** Microsoft D3D12 PSO and pipeline-library documentation/sample; Khronos Vulkan pipeline cache, graphics pipeline library, and pipeline binary documentation; Epic PSO caching/precaching guidance; Microsoft DXC repository.
- **Remaining open decisions:** DXC/profile baseline; root-layout schema; static-feature budgets; critical manifest partitions; fallback visuals; in-memory PSO LRU; Vulkan library/binary tier; editor/mod isolation; ray-pipeline caching.

## 2026-07-27 02:00:33 America/Los_Angeles

- **Report path:** `C:\Users\steve\Desktop\EXTRA SKILS\3D Graphics Rendering Shaders\operation-mythology-graphics-20260727-020033.md`
- **Timestamp:** `20260727-020033`
- **Subjects covered:** Mesh/texture asset build DAG; glTF import/validation; coordinate, topology, tangent, UV, skin, and PBR validation; signal-aware mip generation; alpha coverage; BC/ASTC/ETC/KTX2 format policy; mesh cache/overdraw/fetch optimization; LODs, meshlets, quantization, streaming chunks; content-addressed derived-data caching.
- **Major sourced claims:** glTF specifies vertex/tangent/PBR channel semantics; Khronos validator emits machine-readable asset validation; KTX2 supports mip and BasisLZ universal payloads; DirectXTex supports mips, compression, color/alpha handling, and alpha-coverage preservation; meshoptimizer supplies mesh optimization/analyzer stages; Epic documents regenerable hierarchical DDCs.
- **Engineering recommendations:** Keep source assets/recipes authoritative; make build nodes pure and content-addressed; enforce engine semantic validation; generate signal-aware mips before compression; select formats per platform/semantic; optimize geometry offline in a fixed measured order; publish immutable streamable runtime blobs through checksummed local/shared DDC tiers.
- **Sources:** Khronos glTF specification/validator and KTX2 specification; Microsoft DirectXTex; meshoptimizer; Epic Derived Data Cache documentation.
- **Remaining open decisions:** Interchange/exporter versions; tangent implementation; UV limits; format/encoder matrix; channel packing; simplifier/meshlet/page targets; runtime containers; DDC topology/security; deterministic worker requirements.

## 2026-07-27 02:04:54 America/Los_Angeles

- **Report path:** `C:\Users\steve\Desktop\EXTRA SKILS\3D Graphics Rendering Shaders\operation-mythology-graphics-20260727-020454.md`
- **Timestamp:** `20260727-020454`
- **Subjects covered:** Scene-referred color contract; manual, basic, and histogram exposure; weighted metering; temporal adaptation; pre-exposure; local exposure; creative grading; unified tone/gamut output transforms; SDR, FP16/scRGB, and HDR10/PQ presentation; UI paper white; first-/third-person render-view exposure ownership; display changes; validation and scalability.
- **Major sourced claims:** Epic documents 64-bin histogram exposure, middle-gray metering, f-stop adaptation, metering masks, local exposure, and previous-frame pre-exposure; Microsoft documents FP16/scRGB and 10-bit HDR10 Windows paths and cautions against relying on static HDR metadata delivery; ACES 2 uses a perceptual color-correlate output transform; AMD LPM maps HDR/WCG while preserving luminance relationships; Vulkan exposes extended swap-chain color spaces and HDR metadata extensions.
- **Engineering recommendations:** Adopt one versioned scene-referred working-space contract; keep exposure per stable render view; use weighted histogram exposure with Basic and Manual fallbacks; separate exposure, grading, and display transforms; audit all scene/history consumers before enabling pre-exposure; validate SDR first, then FP16/scRGB and HDR10 paths; tone map to queried/calibrated display capability; fuse compatible fullscreen stages; make camera/display changes explicit history epochs.
- **Sources:** Epic Auto Exposure, Filmic Tonemapper, and Physical Lighting Units documentation; Microsoft Windows HDR guidance, `SetHDRMetaData` reference, and D3D12 HDR sample; ACES Output Transforms; AMD FidelityFX LPM; Khronos swap-chain color-space and HDR-metadata references.
- **Remaining open decisions:** Working gamut; HDR scene format; histogram parameters; adaptation/cut policy; pre-exposure adoption; local-exposure algorithm; paper white and target peak; platform scRGB/HDR10 matrix; UI/capture encoding.

## 2026-07-27 02:08:34 America/Los_Angeles

- **Report path:** `C:\Users\steve\Desktop\EXTRA SKILS\3D Graphics Rendering Shaders\operation-mythology-graphics-20260727-020834.md`
- **Timestamp:** `20260727-020834`
- **Subjects covered:** Low-overhead renderer telemetry; hierarchical CPU/GPU zones; per-queue timestamp queries; GPU critical-path reconstruction; presentation pacing and latency; PIX, Nsight, RGP, and PresentMon capture workflows; workload, allocation, residency, bandwidth, cache, divergence, synchronization, batching, streaming, concurrency, and regression metrics.
- **Major sourced claims:** PIX Timing Captures correlate CPU, GPU queues, I/O, allocations, markers, and counters; PIX GPU Capture replay timing does not reproduce cross-queue overlap; D3D12 timestamps are queue ticks resolved using queue frequency; Nsight GPU Trace exposes utilization and synchronization; RGP exposes barriers, async compute, pipelines, instructions, and measured wavefront occupancy; AMD cautions that theoretical occupancy is only an upper bound; PresentMon traces CPU/GPU/display frame durations and latencies; Vulkan calibrated timestamps correlate device and host time domains.
- **Engineering recommendations:** Use one stable marker/ID registry across engine and external tools; keep bounded allocation-free frame ledgers and asynchronous query rings; reconstruct multi-queue critical paths; record workload and state beside timings; gate percentile pacing, latency, CPU/GPU, VRAM, allocation, draw/dispatch, upload, PSO, and streaming regressions; require controlled vendor captures for material GPU regressions; maintain separate lab, CI, and field baselines.
- **Sources:** Microsoft PIX Timing/GPU Captures and D3D12 Timing; NVIDIA Nsight Graphics GPU Trace; AMD Radeon GPU Profiler and Occupancy Explained; Intel/GameTechDev PresentMon; Khronos calibrated timestamps.
- **Remaining open decisions:** Telemetry schema/format; timestamp sampling density; retail overhead and storage budget; latency instrumentation; benchmark scenarios; statistical thresholds; baseline hardware/driver matrix; capture retention; field privacy policy.

## 2026-07-27 02:12:12 America/Los_Angeles

- **Report path:** `C:\Users\steve\Desktop\EXTRA SKILS\3D Graphics Rendering Shaders\operation-mythology-graphics-20260727-021212.md`
- **Timestamp:** `20260727-021212`
- **Subjects covered:** Physically based planetary atmosphere and aerial perspective; atmosphere lookup tables; camera-aligned froxel fog; local participating media; clustered volumetric lighting; ray-marched cloud layers; cloud lighting and sun-transmittance shadows; temporal/spatial reconstruction; sparse volume assets; first-/third-person view history; rendering, memory, bandwidth, streaming, and scalability contracts.
- **Major sourced claims:** Epic documents physically based Sky Atmosphere, low-resolution temporally reconstructed Volumetric Fog, ray-marched 3D volumetric clouds, and page-table-backed Sparse Volume Textures; Epic warns that fast-changing volumetric lights can trail and that volume resolution is a primary cost control; Bruneton's atmosphere implementation adds tested configurable precomputed scattering; Frostbite presents unified physically based participating media and coupled sky/atmosphere/cloud rendering; Guerrilla's Nubis material demonstrates production cloud authoring and optimization.
- **Engineering recommendations:** Use one physical media coefficient contract; update tested atmosphere LUTs by dependency generation; use froxel fog with analytic fallback; bound cloud layers and ray steps with empty-space skipping and early termination; classify fast-changing volumetric lights for reduced history; share slow world resources but retain per-view histories; budget shadowed volumetric lights; stream sparse volumes through the central residency service; expose all passes/resources to the render graph and telemetry.
- **Sources:** Epic Sky Atmosphere, Volumetric Fog, Volumetric Cloud, Sparse Volume Texture, and Heterogeneous Volume documentation; Bruneton and Neyret precomputed scattering; Frostbite SIGGRAPH volumetric/sky/cloud material; Guerrilla Nubis SIGGRAPH presentation.
- **Remaining open decisions:** Spectral versus RGB atmosphere; LUT sizes/formats; froxel distribution; phase model; volume blending; cloud representation/layers; temporal filter; cloud/fog shadow cadence; sparse brick/channel formats; transparency integration; platform budgets.
- **Coverage reconciliation:** The recursive scan found `C:\Users\steve\Desktop\GAME SKILLS\2026-07-27_animation-pose-evaluation-sharing-gpu-deformation.md`; GPU skinning, pose sharing, deformation graphs, and related render integration are now covered there and were removed from this index's uncovered list without duplicating that research.

## 2026-07-27 02:16:07 America/Los_Angeles

- **Report path:** `C:\Users\steve\Desktop\EXTRA SKILS\3D Graphics Rendering Shaders\operation-mythology-graphics-20260727-021607.md`
- **Timestamp:** `20260727-021607`
- **Subjects covered:** Ocean/lake/river/pool surface representation; quadtree/clipmap tile LOD and morphing; deterministic Gerstner and spectral FFT waves; macro/micro frequency split; flow/depth fields; reflection/refraction hierarchy; single-layer physical optics; foam, wakes, caustics, waterline, and underwater media; first-/third-person integration; performance and scalability.
- **Major sourced claims:** Epic documents unified tiled water bodies, per-frame quadtree LOD, morphing between tile levels, GPU-driven Gerstner waves, and a dedicated Single Layer Water pass with physical scattering/absorption and tile-classified indirect reflection/composition; Tessendorf establishes spectral/Fourier ocean synthesis for broad deep-water waves; NVIDIA documents separating geometry waves from dynamically generated normal detail and presents real-time procedural caustic approximations.
- **Engineering recommendations:** Keep gameplay authority separate from renderer displacement while sharing deterministic wave descriptors; use a shared tiled large-water surface; begin with Gerstner waves and add FFT only for measured ocean requirements; split resolvable geometry energy from filtered normal detail; use a dedicated single-layer optical pass; reuse the hybrid reflection hierarchy and cap planar/ray tiers; generate bounded regional foam/wake fields; integrate underwater rendering with common volumetric/exposure contracts; retain current/previous rendered water state for temporal consumers.
- **Sources:** Epic Water System, Water Body Actors, Water Meshing, Water Waves, Single Layer Water, and scalability documentation; Jerry Tessendorf's SIGGRAPH ocean course notes; NVIDIA GPU Gems water simulation and caustics chapters.
- **Remaining open decisions:** Gerstner/FFT content matrix; cascade/grid sizes; mesh topology/LOD; authoritative query subset; flow/depth resolution; foam representation; reflection selection; refraction resolution; underwater media/caustics; translucency ordering; multi-view policy; platform budgets.

## 2026-07-27 02:19:56 America/Los_Angeles

- **Report path:** `C:\Users\steve\Desktop\EXTRA SKILS\3D Graphics Rendering Shaders\operation-mythology-graphics-20260727-021956.md`
- **Timestamp:** `20260727-021956`
- **Subjects covered:** Compiled VFX graph execution; CPU/GPU simulation boundary; particles, sprites, mesh particles, ribbons/trails, decals, lights, and volume injection; pooling/capacity; compaction, radix sorting, indirect submission, transparency/OIT, collision/query latency, destruction-event handoff, temporal integration, overdraw, budgeting, and platform scalability.
- **Major sourced claims:** Epic documents CPU/GPU Niagara execution, GPU instance/readback managers, multiple renderer types, fixed bounds, effect-type budget culling, and latency in asynchronous GPU queries/data communication; Epic describes DBuffer and post-base-pass GBuffer decal paths and screen-coverage-dependent cost; AMD Parallel Sort provides multi-pass GPU radix sorting and explicitly supports particles; weighted blended OIT uses bounded memory without explicit depth sorting; NVIDIA Blast leaves graphics/physics mapping to the application; Chaos destruction integrates clustered pre-fractured assets with Niagara events.
- **Engineering recommendations:** Compile bounded stage-specific CPU/GPU programs; keep gameplay authority off delayed GPU simulation; pool global/per-class heaps with deterministic admission; batch, compact, and generate indirect work on GPU; sort only selected effects and use OIT where acceptable; budget projected overdraw; build ribbons from stable IDs; cap and receiver-filter decals; map destruction through generation-checked render handles; require motion/reactive/transparency outputs; integrate DDC, streaming, PSO, and telemetry before expanding graph features.
- **Sources:** Epic Niagara overview/API/renderers/budget/system settings, decals, and Chaos destruction; AMD FidelityFX Parallel Sort; McGuire and Bavoil weighted blended OIT; NVIDIA Blast.
- **Remaining open decisions:** VFX graph IR/type system; CPU/GPU compatibility subset; heap partitioning; collision/query tiers; sort/OIT policy; ribbon geometry; decal representation; destruction LOD; transparent lighting/shadows; multi-view sharing; retail telemetry; platform budgets.

## 2026-07-27 02:23:44 America/Los_Angeles

- **Report path:** `C:\Users\steve\Desktop\EXTRA SKILS\3D Graphics Rendering Shaders\operation-mythology-graphics-20260727-022344.md`
- **Timestamp:** `20260727-022344`
- **Subjects covered:** Typed camera/post-process graph; physical/artistic camera parameters; velocity-buffer motion blur; thin-lens CoC depth of field; tile classification; standard and FFT convolution bloom; chromatic aberration, vignette, grain, and lens effects; temporal-upscaler ordering; HDR/exposure domains; custom-pass constraints; first-/third-person policy; transient memory, bandwidth, and scalability.
- **Major sourced claims:** Epic documents one-vector-per-pixel velocity blur and its inability to capture secondary/multiple motion; NVIDIA describes depth-reconstructed camera velocity and separate dynamic-object velocity; AMD DoF uses signed CoC, half-resolution inputs, tile range/dilation/classification, near/far gathers, and bounded ring quality while noting single-depth limitations for translucency/volumes; Epic distinguishes game-oriented Standard bloom from high-end FFT convolution; AMD recommends late lens/grain effects after upscaling/sharpening; Epic cautions that custom post materials create intermediates.
- **Engineering recommendations:** Make post processing a typed render-graph subgraph; derive shutter/CoC physically then clamp artistically; reuse canonical velocity and tile-classify bounded blur; use half-resolution layered DoF with explicit limitations; ship Standard bloom by default and gate convolution; calibrate bloom in a documented pre-tone/exposure domain; fuse lightweight late lens effects; define first-person blur/DoF and accessibility policy; restrict custom insertion points; profile full-resolution intermediates and bandwidth.
- **Sources:** Epic Post Process Effects, Depth of Field, Bloom, Post Process Materials, Temporal Upscalers, and Motion Blur; AMD FidelityFX DoF and Lens; NVIDIA GPU Gems motion blur and practical DoF.
- **Remaining open decisions:** Shutter convention; motion tiles/samples; DoF/upscaler ordering; CoC limits; translucency/volume DoF; bloom domain/pyramid/convolution; lens/flare model; pass fusion; first-person/accessibility policy; custom extension points; platform budgets.

## 2026-07-27 02:27:38 America/Los_Angeles

- **Report path:** `C:\Users\steve\Desktop\EXTRA SKILS\3D Graphics Rendering Shaders\operation-mythology-graphics-20260727-022738.md`
- **Timestamp:** `20260727-022738`
- **Subjects covered:** Baked surface lightmaps; adaptive irradiance/volumetric probes; reflection captures; static, stationary, and movable light contribution semantics; rectangular and polygonal area-light approximation with LTC; world-cell streaming; render-world integration; performance and scalability.
- **Major sourced claims:** Epic documents path-traced texture-space GPU Lightmass, unique non-overlapping lightmap UVs, virtual-texture tile prioritization, CPU encoding/denoising, and steep probe-memory growth from finer detail cells; Volumetric Lightmaps use adaptive bricks and third-order spherical harmonics with per-pixel GPU interpolation; reflection captures blend by spatial influence and can use lightmaps to reduce leaking; rectangular lights provide true multi-sample area behavior in baked modes while dynamic paths can approximate diffuse emission; Heitz et al. show that linearly transformed cosines enable analytic polygon-light integration.
- **Engineering recommendations:** Share physical light/material definitions across baked and dynamic tiers; publish immutable versioned lighting generations transactionally; use surface lightmaps, adaptive probes, and reflection captures as an explicit fallback hierarchy; encode contribution flags to prevent double counting; keep LTC evaluation independent from shadow selection; stream coarse-valid illumination before fine pages, bricks, and captures.
- **Sources:** Epic GPU and CPU Lightmass, Volumetric Lightmaps, Reflection Captures, Static/Stationary Light Mobility, Rectangular Area Lights; Heitz LTC polygon, line, and disk-light material; Unity light-probe technical documentation.
- **Remaining open decisions:** Baker/toolchain; virtual versus conventional lightmaps; basis and formats; probe layout, SH order, and leak prevention; capture blending/parallax; mixed-light semantics; LTC shapes, lobes, and LUT resolution; area-shadow method; cell packaging; time-of-day policy; platform tiers.

## 2026-07-27 02:32:02 America/Los_Angeles

- **Report path:** `C:\Users\steve\Desktop\EXTRA SKILS\3D Graphics Rendering Shaders\operation-mythology-graphics-20260727-023202.md`
- **Timestamp:** `20260727-023202`
- **Subjects covered:** Coverage versus optical transmission; premultiplied composition; thin and closed-volume refraction; sorted transparency; weighted, stochastic, and bounded exact OIT; layered closures; transparent lighting, fog, temporal, DoF, first-person, streaming, and scalability integration.
- **Major sourced claims:** Khronos separates alpha coverage from thin transmission and closed homogeneous volume behavior; Epic separates coverage from transmittance and documents slab layering, classification, and rising multi-slab cost; Microsoft documents premultiplied source-over and independent target blending; McGuire/Bavoil provide bounded-memory approximate WBOIT; NVIDIA documents fixed-memory stochastic transparency; Vulkan fragment interlock enables ordered per-pixel critical sections.
- **Engineering recommendations:** Use a classified hybrid pipeline; make coverage and transmission distinct; validate manifold volume assets; compile bounded layered closures; use sorted premultiplied blending by default, WBOIT for high overlap, and exact/stochastic methods only under explicit budgets; require overflow telemetry; integrate transparent depth, velocity, and temporal masks through render-graph contracts.
- **Sources:** Khronos glTF transmission, volume, and IOR extensions; Epic Substrate; McGuire and Bavoil WBOIT; NVIDIA stochastic transparency; Microsoft premultiplied alpha and D3D12 blending; Vulkan fragment interlock; AMD raster ordering material.
- **Remaining open decisions:** WBOIT weights/formats; exact-OIT technique and budget; transparent depth; refraction fallbacks; nested media; colored-transmission floor; closure byte/layer caps; alpha-to-coverage temporal policy; transparent shadows; fog/DoF ordering; first-person composition; overflow behavior; platform budgets.

## 2026-07-27 02:36:32 America/Los_Angeles

- **Report path:** `C:\Users\steve\Desktop\EXTRA SKILS\3D Graphics Rendering Shaders\operation-mythology-graphics-20260727-023632.md`
- **Timestamp:** `20260727-023632`
- **Subjects covered:** Skin diffusion and transmission; strand/card/mesh hair and fur; groom visibility, density, shadows, and composition; eye geometry/material coupling; cloth sheen; tangent-space anisotropy; character render-world extraction; streaming, temporal integration, and scalability.
- **Major sourced claims:** Epic documents screen-space profile-filtered skin diffusion with separated specular, a 64-bit full-resolution representation, and deferred/screen-space limitations; its groom pipeline includes simulation, interpolation, voxelization, visibility, lighting, and composition with strand/card fallbacks; Disney’s Chiang model provides an energy-conserving controllable fiber response; Epic’s eye model depends strongly on geometry, UV, and shader conventions; Khronos specifies layered energy-aware sheen and tangent-space anisotropy inputs.
- **Engineering recommendations:** Use classified bounded character closures; keep skin specular sharp while filtering diffuse; make strands/cards/mesh a matched representation family; amortize density voxelization; budget deep visibility and ray hair explicitly; version eye geometry/UV/material conventions; require explicit validated tangents for anisotropy; transactionally publish groom topology, binding, deformation, and materials; reserve first-person budgets separately.
- **Sources:** Epic Subsurface Profile, Groom Scalability, Hair Rendering, Shading Models, Material Inputs, MetaHuman materials, and Digital Humans; Disney Chiang et al. hair/fur model; Khronos glTF sheen and anisotropy extensions.
- **Remaining open decisions:** Skin kernel/profile and mobile fallback; backscatter; profile count; strand visibility capacity; density and shadow hierarchy; fiber model/LUT; groom interchange/cards; eye convention/LOD; closure packing; tangent standard; platform budgets.

## 2026-07-27 02:40:00 America/Los_Angeles

- **Report path:** `C:\Users\steve\Desktop\EXTRA SKILS\3D Graphics Rendering Shaders\operation-mythology-graphics-20260727-024000.md`
- **Timestamp:** `20260727-024000`
- **Subjects covered:** D3D12/Vulkan VRS; fragment-density rendering; fixed and gaze-tracked foveation; dynamic resolution; resolution-domain graph contracts; derivatives/mips; exclusions; temporal reconstruction; streaming, latency, multiview, and platform scalability.
- **Major sourced claims:** D3D12 and Vulkan support per-draw, per-primitive, and attachment/image-based rate sources at higher tiers; D3D12 retains full-resolution depth/stencil/coverage and coarse shading affects derivatives and mip selection; Vulkan fragment-density maps may reduce fragment and attachment density; AMD states VRS saves shader work but not render-target fill; NVIDIA distinguishes VRS shading rate from visibility resolution; OpenXR exposes fixed/dynamic foveation profiles.
- **Engineering recommendations:** Make resolution domains first-class graph metadata; prefer conservative image-based VRS with force-fine masks and per-draw fallback; enable only on measured shader-bound passes; keep depth, velocity, alpha-test, transparency, UI, and unstable highlights fine; predict gaze with uncertainty; expand streaming around gaze; instrument delivered rates rather than requests.
- **Sources:** Microsoft D3D12 VRS; Khronos Vulkan fragment shading rate and fragment density map; AMD FidelityFX Variable Shading; NVIDIA VRS engineering material; Khronos OpenXR foveation and Varjo capability references.
- **Remaining open decisions:** Platform floor; VRS/density hierarchy; combiners; exclusion producers; derivative/mip policy; temporal integration; gaze prediction/privacy; foveal radii; headroom control; per-pass eligibility; multiview binding; budgets.

## 2026-07-27 02:43:30 America/Los_Angeles

- **Report path:** `C:\Users\steve\Desktop\EXTRA SKILS\3D Graphics Rendering Shaders\operation-mythology-graphics-20260727-024330.md`
- **Timestamp:** `20260727-024330`
- **Subjects covered:** Terrain clipmaps/chunked/virtualized hierarchy; seams and material layers; deterministic procedural vegetation; GPU cluster culling, LOD, compaction, and indirect submission; geometry/cards/impostor/aggregate representations; wind deformation; two-sided leaf transmission; forest shadows; streaming and scalability.
- **Major sourced claims:** Geometry clipmaps use nested incrementally shifted regular grids and reusable patch geometry; Epic documents hardware-instanced foliage and cluster fade/culling, thin-leaf transmission, alpha-mask overdraw, arbitrary-WPO bound/raster costs, experimental assembly/voxel/skinning aggregate foliage, duplicate conventional/virtualized landscape residency, and deterministic procedural placement.
- **Engineering recommendations:** Use regular-grid terrain fallback with explicit edge/version/coarse residency; reduce material layers per tile; keep decorative vegetation as stable compact renderer instances; GPU-drive culling/LOD/commands; require matched representation chains; prefer geometry when it reduces empty alpha but use aggregates/impostors at distance; bound wind deformation; separate main-view and shadow density budgets; publish cell generations transactionally.
- **Sources:** Losasso/Hoppe geometry clipmaps; GPU-based geometry clipmaps; NVIDIA GPU Gems; Epic Foliage Mode, Shading Models, Nanite Foliage, Nanite Technical Details, Nanite Landscapes, and procedural foliage documentation.
- **Remaining open decisions:** Terrain hierarchy, tile/error sizes, seams, edits, layer limit, placement policy, cluster granularity, species representations, aggregate method, wind rig, leaf transmission, shadow hierarchy, promotion, and platform budgets.

## 2026-07-27 02:46:53 America/Los_Angeles

- **Report path:** `C:\Users\steve\Desktop\EXTRA SKILS\3D Graphics Rendering Shaders\operation-mythology-graphics-20260727-024653.md`
- **Timestamp:** `20260727-024653`
- **Subjects covered:** Exact HDR/SDR and multi-buffer frame dumps; window/display capture; GPU-resident hardware video encode; timestamps/audio/drop policy; graphics API capture; deterministic/tolerance-based engine visual replay; hashes, manifests, privacy, retention, and performance.
- **Major sourced claims:** Windows Graphics Capture supplies pooled GPU frames and QPC timestamps with floating-point HDR guidance; DXGI duplication provides GPU display images plus move/dirty/pointer metadata; PIX and Nsight capture API events/state/resources for replay/debugging; D3D12/Vulkan expose optional video-encode capability; OpenEXR supports float HDR, arbitrary typed channels, multipart/multiview, premultiplied alpha, and multiple compression modes.
- **Engineering recommendations:** Separate exact dumps, video, engine replay, and API capture guarantees; name capture domains and color metadata; use asynchronous bounded copy/readback/encode rings; keep video GPU-resident; use EXR/lossless images for truth; record immutable content/shader/config/view/streaming/history generations; hash pass outputs to locate divergence; bound and secure all capture artifacts.
- **Sources:** Microsoft Windows Graphics Capture, DXGI Desktop Duplication, PIX programmatic/GPU/timing capture, D3D12 video encode; NVIDIA Nsight Graphics; Khronos Vulkan Video; OpenEXR technical documentation; AMD Radeon GPU Profiler.
- **Remaining open decisions:** Domains/channels, EXR compression, hash/tolerance rules, checkpoints, nondeterminism tier, video API/codec, audio clock, HDR signaling, backpressure/drop policy, tool adapters, privacy, retention, and budgets.

## 2026-07-27 02:50:53 America/Los_Angeles

- **Report path:** `C:\Users\steve\Desktop\EXTRA SKILS\3D Graphics Rendering Shaders\operation-mythology-graphics-20260727-025053.md`
- **Timestamp:** `20260727-025053`
- **Subjects covered:** OpenXR predicted frame timing and variable-count view families; stereo/multiview and D3D12 view instancing; array-layer swapchains; shared/per-view visibility; compositor layers and reference spaces; safe late view updates; depth- and motion-assisted reprojection; pose-to-display latency; first-/third-person XR presentation; streaming and scalability.
- **Major sourced claims:** OpenXR supplies predicted display timing, runtime-authored view poses/FOVs, swapchain subimages, and composition; view configurations are not universally fixed at two; depth layers may improve runtime reprojection; FB space warp accepts motion/depth plus application-space pose delta; Vulkan multiview broadcasts draws to selected attachment layers with `ViewIndex`; D3D12 Tier 3 can share pre-raster work independent of `SV_ViewID`; vendor multiview and late-latch material supports the optimization pattern but not a portable performance guarantee.
- **Engineering recommendations:** Make view families variable-count and runtime-authored; establish sequential correctness before selecting multiview; extract once and produce family candidates plus per-view masks; isolate late latching to fence-safe immutable view constants; key temporal history by view and pose generation; gate depth/motion reprojection independently; use compositor layers selectively; merge view frusta for predictive streaming; measure pose age, queue depth, and deadline misses alongside conventional GPU time.
- **Sources:** Khronos OpenXR 1.1, OpenXR reference guide, composition-layer depth, FB space warp, and Vulkan multiview; Microsoft D3D12 view-instancing descriptor and tiers; NVIDIA VRWorks/Turing multiview; AMD LiquidVR.
- **Remaining open decisions:** Minimum runtime/version and view configurations; reference-space policy; late-locate timing; multiview tier floor; union/per-view culling threshold; depth/space-warp matrix; compositor-layer policy; first-person rendering policy; maximum frames in flight; attachment/VRAM and latency/deadline budgets.

## 2026-07-27 02:54:29 America/Los_Angeles

- **Report path:** `C:\Users\steve\Desktop\EXTRA SKILS\3D Graphics Rendering Shaders\operation-mythology-graphics-20260727-025429.md`
- **Timestamp:** `20260727-025429`
- **Subjects covered:** DXGI flip model and Vulkan swapchains; FIFO/mailbox/immediate/tearing/VRR policy; present queue depth and completion; display encoding and current HDR metadata guidance; mixed-display migration; resize/minimize/occlusion/hot-plug; surface recreation; generation-safe D3D12/Vulkan device-loss diagnostics and recovery.
- **Major sourced claims:** DXGI flip model is required for modern HDR paths and needs an explicit MSAA resolve; tearing support is queried at creation and is required for borderless VRR; waitable swapchains expose queue-depth control; Vulkan FIFO is universally required while mailbox replaces pending work and immediate may tear; present-wait/fence extensions close pacing and resource-lifetime gaps; FP16 scRGB doubles swapchain bandwidth versus 32-bit output; Microsoft now advises tone-mapping to reported display gamut/luminance instead of relying on HDR metadata delivery; DRED supplies breadcrumbs/page-fault data after removal.
- **Engineering recommendations:** Make presentation a generation-safe state machine; use flip-discard and Vulkan FIFO baselines; map user intent only to supported modes; bound queue depth; distinguish render and display extents; fuse final conversion work; select SDR8/scRGB/PQ at the boundary; re-query after output migration; distinguish suboptimal/out-of-date/surface-lost/device-lost; capture diagnostics before teardown and progressively rehydrate immutable assets after recovery.
- **Sources:** Microsoft DXGI flip model, Present, swapchain flags/effects, latency APIs, Advanced Color/HDR, SetHDRMetaData, multi-monitor guidance, and DRED; Khronos Vulkan present modes, present wait, swapchain maintenance, semaphore reuse, and HDR metadata.
- **Remaining open decisions:** OS/API floor; borderless/exclusive policy; default VSync/VRR and queue depth; render/display scaling; output formats; paper white/calibration; primary-output rule; event debounce; diagnostic level; retry/adapter fallback; recovery time and peak-VRAM budgets.

## 2026-07-27 03:00:53 America/Los_Angeles

- **Report path:** `C:\Users\steve\Desktop\EXTRA SKILS\3D Graphics Rendering Shaders\operation-mythology-graphics-20260727-030053.md`
- **Timestamp:** `20260727-030053`
- **Subjects covered:** Projected-volume decals; DBuffer/pre-base-pass and direct-GBuffer attribute modification; clustered/forward/mobile fallbacks; receiver filtering and material-channel contracts; mesh decals; spline/trail marks; sparse virtual-texture terrain/static-surface stamping; persistence, streaming, ordering, batching, and GPU-driven submission.
- **Major sourced claims:** Epic documents DBuffer accumulation before the base pass and direct GBuffer blending before lighting; DBuffer enables baked-light integration but requires a depth prepass and adds receiver/material cost; screen coverage and material complexity dominate decal cost; excessive unique sort values harm batching; mesh decals avoid planar projection but add geometry/depth/LOD/occlusion limitations; RVT is an on-demand GPU shading cache suited to static landscape/decal layering rather than continuously moving receivers; Frostbite and Doom production material corroborate volume and geometry decal patterns.
- **Engineering recommendations:** Select representation by lifetime, receiver motion, shape, density, and platform; use a DBuffer-like high-end baseline with explicit receiver channel masks; keep named forward/mobile tiers; reconstruct inside tight volumes with early rejection; standardize material/normal blends; use coarse priority bands and GPU compaction; reserve mesh decals for conforming authored detail; use deterministic stamp-command journals plus disposable sparse pages for persistent terrain/static marks; implement generation-safe transient-to-page handoff.
- **Sources:** Epic Decal Materials, Mesh Decals, Material Properties, Runtime/Streaming Virtual Texturing, Landscape Splines, and rendering-path support; Frostbite SIGGRAPH 2010; Doom Eternal SIGGRAPH 2020; I3D 2021 decal/ray-tracing research.
- **Remaining open decisions:** DBuffer formats/channels; normal blend; receiver-mask width; forward/mobile tiers; priority bands and per-tile capacity; atlas/bindless textures; mesh-decal skinning/LOD; virtual-page size/pool/journal compaction; persistence limits; ray-tracing behavior; draw, bandwidth, VRAM, and latency budgets.

## 2026-07-27 03:05:20 America/Los_Angeles

- **Report path:** `C:\Users\steve\Desktop\EXTRA SKILS\3D Graphics Rendering Shaders\operation-mythology-graphics-20260727-030520.md`
- **Timestamp:** `20260727-030520`
- **Subjects covered:** D3D12 SM 6.6 direct heap indexing and descriptor-table fallback; Vulkan descriptor indexing, deprecated descriptor-buffer compatibility, and ratified descriptor heaps; typed logical resource handles; physical descriptor allocation; immutable sampler families; transactional publication, streaming fallback, residency, validation, recovery, and performance.
- **Major sourced claims:** D3D12 direct heap indexing requires binding Tier 3/SM 6.6 and matching root flags, treats descriptors/data as volatile, and requires non-uniform annotation; D3D12 exposes one shader-visible resource heap and sampler heap with a 2,048 sampler maximum; Vulkan descriptor-indexing features are granular; Khronos now deprecates descriptor buffer in favor of ratified descriptor heap, which provides explicit resource/sampler heaps with more portable constraints; descriptor validity does not establish memory residency or resource state/layout.
- **Engineering recommendations:** Put a typed generation-checked logical table between materials and physical descriptors; use one long-lived resource/sampler heap; support D3D12 direct indexing plus tables and Vulkan descriptor indexing plus capability-selected descriptor heaps; keep descriptors, state/layout, residency, and mip availability separate; publish uploads/descriptors/table records transactionally; canonicalize finite samplers; require typed shader accessors and non-uniform annotations; retain material bins for locality; reconstruct physical descriptors from view keys after device loss.
- **Sources:** Microsoft DirectX SM 6.6 Dynamic Resources, D3D12 resource binding, descriptors/tables, root limits, and hardware tiers; Khronos descriptor arrays/indexing, descriptor buffer, descriptor heap specification/proposal/guide.
- **Remaining open decisions:** Handle bit allocation/wrap; logical/physical capacities; D3D12 table floor; Vulkan feature floor and descriptor-heap adoption telemetry; sampler taxonomy; transient/global split; update transport; validation cost; fallback palette; compaction; ray-tracing mapping; CPU/VRAM/bandwidth/latency budgets.

## 2026-07-27 03:12:01 America/Los_Angeles

- **Report path:** `C:\Users\steve\Desktop\EXTRA SKILS\3D Graphics Rendering Shaders\operation-mythology-graphics-20260727-031201.md`
- **Timestamp:** `20260727-031201`
- **Subjects covered:** DXR/Vulkan BLAS/TLAS lifecycle; geometry classification and build flags; update versus rebuild; scratch/result pools; post-build queries and compaction; TLAS admission; deforming/skinned geometry; alpha/opacity policy; minimal bindless SBTs; streaming, synchronization, validation, recovery, and scalability.
- **Major sourced claims:** Acceleration-structure allocation/build/update/copy/synchronization is application-owned; update operations preserve topology/count/format/flag contracts and large deformation can degrade traversal; AS compaction requires a flagged build, size query, allocation, and copy and changes the address referenced by TLAS; D3D12 orders AS accesses through UAV barriers while Vulkan exposes AS build/copy stages and access masks; SBT indexing combines instance, geometry, ray offset/stride, and buffer stride; opaque geometry avoids any-hit work; vendor guidance favors static fast-trace compacted BLAS and measured rebuilds after large deformation.
- **Engineering recommendations:** Use one shared ray-scene service; classify static, rigid, bounded-deforming, rebuild-only, procedural, and proxy BLAS; pool scratch/results and batch dependencies; rebuild TLAS by default; update only legally bounded deformation and schedule quality rebuilds; compact long-lived BLAS through new address generations; validate every TLAS BLAS generation; use explicit alpha budgets; prefer ray queries for simple visibility and minimal class-based SBTs for pipelines; keep proxy/software/screen fallbacks throughout streaming.
- **Sources:** Microsoft DXR functional specification and compacted-size documentation; Khronos Vulkan acceleration structures, ray tracing/SBT, synchronization guide, and tutorial; NVIDIA RT best practices, compaction, validation, SBT optimization; AMD Radeon Raytracing Analyzer.
- **Remaining open decisions:** RT capability floor; BLAS grouping/build flags; scratch/result budgets; compaction threshold; TLAS rebuild/update; admission volume; deformation metric/rebuild cadence; alpha/micromap policy; SBT class/ray layout; multiple TLASes; serialization; CPU/GPU/bandwidth/VRAM/latency budgets.

## 2026-07-27 16:14:19 America/Los_Angeles

- **Report path:** `C:\Users\steve\Desktop\EXTRA SKILS\3D Graphics Rendering Shaders\operation-mythology-graphics-20260727-161419.md`
- **Timestamp:** `20260727-161419`
- **Subjects covered:** Physical light units and exposure-independent truth; directional/point/spot/area/emissive canonical emission; IES import and normalization; cookies/gobos; restricted atlas-cached dynamic light functions; analytic/emissive light database; clustered deterministic and stochastic many-light evaluation; streaming, validation, and scalability.
- **Major sourced claims:** Photometry distinguishes lumens, candela, lux, and cd/m²; cone/solid-angle changes distinguish fixed-flux from fixed-intensity spots; IES stores measured angular fixture distribution and is cheaper than general light functions; unrestricted light functions incur sequential passes/synchronization while an eligible GPU-generated atlas can be shared across views and lighting/fog/GI consumers; stochastic many-light paths bound sample cost while quality declines with influential-light complexity.
- **Engineering recommendations:** Store canonical physical light truth independent of exposure; separate source shape, normalized analytic distribution, IES, cookie, dynamic function, and finite range; require energy-preserving versus artistic normalization metadata; cook/validate IES offline; compile a restricted atlas-eligible function language; feed deterministic clustered and stochastic paths from one stable light database; generate emissive groups from renderer geometry/material generations; enforce capacities with importance-ranked overflow and complete generation tracking.
- **Sources:** Epic Physical Lighting Units, IES Profiles, Light Functions/Atlas, Point Lights, MegaLights, and UE 5.8 release notes; Khronos glTF KHR_lights_punctual; IES LM-63; ReSTIR and Dynamic Many-Light Sampling research.
- **Remaining open decisions:** Canonical spectral/RGB convention; unit defaults; IES variants/orientation/normalization; cookie mappings; function graph/atlas capacity; area-light flux convention; emissive grouping/PDF; deterministic/stochastic threshold; cluster overflow; bounds policy; CPU/GPU/draw/dispatch/VRAM/bandwidth/latency budgets.

## Covered topics

- Scalable directional and local-light shadows
- Virtual shadow maps and cache invalidation
- Hybrid raster/ray-query shadowing
- Real-time diffuse global illumination and specular reflection architecture
- Screen, probe-cache, software-trace, and hardware-ray fallback hierarchy
- Shader permutation, compilation, cache, and PSO lifecycle architecture
- D3D12 and Vulkan pipeline persistence and precaching policy
- Mesh and texture asset validation, optimization, cooking, and derived-data architecture
- Camera exposure, pre-exposure, grading, tone/gamut mapping, and SDR/HDR presentation
- Per-view exposure history and first-/third-person color integration
- Renderer profiling, low-overhead telemetry, frame pacing, latency, and regression gates
- Cross-vendor PIX, Nsight, RGP, and PresentMon capture workflow
- Physically based atmosphere, aerial perspective, froxel fog, volumetric clouds, and sparse volumes
- Participating-media lighting, temporal reconstruction, render-world integration, and scalability
- Tiled water surfaces, analytic/spectral waves, physical water shading, reflections/refraction, foam, and underwater rendering
- Water simulation-to-render extraction, temporal history, streaming, and platform scalability
- Compiled CPU/GPU VFX graphs, particle pooling, compaction, sorting, and indirect rendering
- Sprites, meshes, ribbons/trails, decals, destruction-event integration, transparency, and VFX scalability
- Motion blur, thin-lens depth of field, standard/convolution bloom, and post-process graph composition
- Late lens effects, first-person camera policy, temporal-upscaler integration, and post-process scalability
- Baked surface lightmaps, adaptive irradiance/volumetric probes, and reflection captures
- Mixed static/stationary/dynamic light semantics and LTC area-light approximation
- Transactional lighting-generation streaming, validation, performance, and scalability
- Coverage versus optical transmission, premultiplied composition, and thin/volume refraction
- Sorted, weighted, stochastic, and bounded exact order-independent transparency
- Layered material closures, simplification, transparent temporal data, and platform scalability
- Skin diffusion/profile lighting and character-surface material classification
- Strand/card/mesh hair visibility, density, shadows, fiber shading, and temporal integration
- Eye geometry/material contracts, cloth sheen, and tangent-space anisotropy
- Variable-rate shading, fragment-density rendering, fixed/gaze foveation, and headroom policy
- Resolution-domain render-graph contracts, force-fine exclusions, derivative policy, and temporal composition
- Terrain clipmaps, virtualized/chunked hierarchy, seams, material-layer reduction, and coarse residency
- Deterministic vegetation instances, GPU culling/LOD/indirect rendering, representation chains, wind, leaf transmission, and forest shadows
- Exact HDR/SDR diagnostic dumps, typed auxiliary channels, display capture, and GPU-resident video encode
- Engine visual replay, pass hashing, graphics API capture integration, capture manifests, privacy, and retention
- OpenXR frame timing, runtime-authored variable-count view families, swapchain arrays, and composition
- Stereo/multiview, D3D12 view instancing, shared/per-view visibility, and conventional fallback
- Late view constants, depth/motion-assisted reprojection, compositor layers, pose-age telemetry, and XR scalability
- DXGI flip-model and Vulkan swapchain presentation policy, VRR/tearing, queue depth, and present completion
- SDR/HDR display encoding, mixed-monitor migration, resize/occlusion, and current metadata guidance
- Surface recreation, device-fault diagnostics, device generations, and progressive GPU-resource recovery
- Projected-volume, DBuffer, direct-GBuffer, forward/mobile, and mesh-decal representation tiers
- Receiver/channel filtering, stable priority ordering, GPU decal culling/batching, and material blending
- Sparse page-backed terrain/static-world stamps, deterministic journals, and transient-to-persistent handoff
- Typed logical bindless handles, physical descriptor heaps/tables, generations, and transactional publication
- D3D12 SM 6.6 direct indexing and Vulkan descriptor-indexing/descriptor-heap capability tiers
- Canonical sampler families, residency fallbacks, shader-access validation, and device-generation reconstruction
- Shared DXR/Vulkan ray-scene service, BLAS/TLAS lifecycle, pooled build scratch/results, and compaction
- Dynamic/skinned update-versus-rebuild policy, TLAS admission, alpha/opacity classification, and streaming
- Minimal bindless SBT architecture, address generations, synchronization, validation, and device recovery
- Physical light units, exposure-independent light truth, analytic area/emissive source records, and conversions
- IES angular profiles, cookie/gobo filtering, restricted atlas-cached light functions, and normalization
- Unified clustered/stochastic light database, emissive sampling hierarchy, overflow, streaming, and validation

## High-priority uncovered graphics subjects

- Material/shader graph compiler architecture: typed IR, derivative legality, parameter ABI, previews, hot reload, and permutation control
