# Operation Mythology Graphics Research — Ray-Tracing Scene, BLAS/TLAS, and Shader Tables

**Timestamp:** 20260727-031201  
**Scope:** D3D12 DXR and Vulkan acceleration-structure construction, update/rebuild/compaction, deforming geometry, TLAS membership, shader binding tables, streaming, synchronization, memory, validation, and fallback.

## 1. Feature Overview

A hardware-ray-tracing renderer needs a scene-maintenance subsystem before it needs more ray effects. The subsystem converts the immutable render-world snapshot into:

- bottom-level acceleration structures (BLAS) over geometry;
- top-level acceleration structures (TLAS) over transform/mask/BLAS instances;
- compact hit-shading records or bindless material/geometry tables;
- shader binding tables (SBTs) only for workloads using ray-tracing pipelines;
- explicit build scratch, result storage, compaction, retirement, and telemetry.

The earlier GI, reflection, and shadow reports define where rays are useful and how to fall back. This batch defines the shared scene representation those features consume. It supports static world geometry, rigid instances, skinned characters, foliage, alpha-tested surfaces, procedural AABBs where justified, streamed cells, first-/third-person cameras, ray queries, and full ray pipelines.

The system must make “not admitted to hardware RT” a valid state with a screen-space, software-trace, proxy, or unshadowed fallback. It must never stall the frame waiting for a BLAS.

## 2. Existing Coverage and Identified Gap

The required recursive scan inventoried 17 `GAME SKILLS` files and 21 files in the dedicated graphics folder. Existing GI/reflection and shadow reports recommend a shared acceleration structure, batched builds, compaction, stable IDs, scratch budgets, and explicit build-to-trace synchronization. The animation report identifies deformation epochs. The residency and open-world reports define generation-safe streaming.

Still uncovered were:

- BLAS grouping and build-flag selection by geometry lifetime/deformation;
- update eligibility versus rebuild quality degradation;
- scratch pooling, post-build size query, compaction moves, and address change propagation;
- TLAS rebuild/update policy, instance masks, stable IDs, and multiple view/feature subsets;
- skinned/deforming geometry deadlines and stale/proxy behavior;
- alpha testing, opacity policy, any-hit cost, and material classification;
- SBT indexing/layout, minimal records, bindless integration, and rebuild triggers;
- world-cell admission/retirement transactions;
- serialization portability, device loss, validation, and failure isolation.

Those are the subjects of this report; it does not repeat GI, shadow, reflection, denoising, or sampling recommendations.

## 3. Sourced Facts

The following are sourced facts:

- D3D12 DXR and Vulkan expose opaque acceleration structures whose allocation, build/update/copy, lifetime, and synchronization are application responsibilities.
- TLAS instances reference BLAS addresses. A referenced BLAS must remain valid for every TLAS access that can reach it.
- Vulkan update operations require the full structure description but permit changes only to instance definitions, transforms, and vertex/AABB positions. Geometry/instance counts, formats, flags, primitive counts, and active/inactive state cannot change through an update.
- DXR similarly restricts BLAS updates: vertex data/eligible transforms may change, but the built structure's topology contract remains. Increasing divergence from the source build can degrade traversal performance.
- D3D12 acceleration structures stay in the ray-tracing acceleration-structure resource state; build/copy/read ordering uses UAV barriers rather than ordinary state transitions. Vulkan defines distinct build/copy stages and acceleration-structure read/write access masks.
- Both APIs expose prebuild/build-size queries. Compaction requires a build flag, a post-build compacted-size query, destination allocation, and an acceleration-structure copy. The compacted result is no larger than the uncompacted source, but compacted sizes do not preserve a simple monotonic relationship with primitive count.
- NVIDIA recommends fast-trace builds plus compaction for static BLAS, pooling small AS allocations, spatially coherent BLAS grouping, and rebuilds after large or topology-changing deformation. This is vendor guidance requiring target-hardware measurement.
- NVIDIA reports that static BLAS compaction can materially reduce storage and may improve tracing, but the size readback and allocation/copy sequence make it most practical for long-lived structures.
- NVIDIA recommends batching vertex deformation and BLAS builds with unique scratch ranges, then using a single dependency before TLAS construction, rather than serializing every BLAS build.
- Marking geometry opaque permits traversal to skip any-hit invocation. Alpha-tested/non-opaque geometry can impose any-hit and divergence cost.
- Vulkan defines SBTs as application-managed buffers. Each record contains a shader-group handle plus optional application data, with API-queried size/alignment and explicit indexing using instance record offsets, geometry index, ray SBT offset, and stride.
- NVIDIA shows that per-instance/per-material SBT records duplicate headers and data. Moving geometry/material parameters to bindless global tables can reduce SBT size to a small set of shader classes.
- Acceleration-structure serialization is semi-opaque and implementation/device compatibility must be checked. It is not a portable cooked-asset truth across arbitrary GPU/driver changes.

## 4. Industry-Standard Rendering API or Pattern

### Geometry classes and build modes

Classify every ray-visible geometry representation at cook/extraction:

| Class | Typical build | Update | Compaction | Example |
|---|---|---:|---:|---|
| Static immutable | Prefer fast trace | No | Yes | Buildings, rocks |
| Rigid instance | Shared static BLAS; TLAS transform changes | BLAS no | Yes | Props, vehicles |
| Bounded deforming | Fast trace/build chosen by measurement | Yes | Long-lived only | Hero skin, wind foliage |
| Wild/topology-changing | Prefer fast build, rebuild | No | Usually no | Destruction, generated debris |
| Procedural AABB | Workload-specific | Constraint-specific | Measure | Analytic primitives |
| Proxy | Static simple BLAS | No | Yes | Distant/skipped dynamic asset |

Build flags are part of the BLAS identity. `ALLOW_UPDATE`, fast-build/fast-trace preference, compaction eligibility, opacity/micromap/data-access features, and geometry layout must not change silently across an update.

### BLAS lifecycle

```text
Unloaded
 -> InputsResident
 -> BuildQueued
 -> BuiltUncompacted
 -> CompactionSizeReady
 -> CompactCopyQueued
 -> CompactPublished
 -> Resident
 -> Retiring
 -> Freed
```

A structure may publish at `BuiltUncompacted` when latency matters, then replace its address with a compacted generation later. Every address change invalidates TLAS instances that reference the old address and requires a new TLAS generation before the old BLAS can retire.

### TLAS lifecycle

Build a fresh TLAS from a compact GPU instance array each frame or whenever the admitted set/transform data changes, unless measurement proves update quality and complexity worthwhile. TLAS construction consumes only BLAS generations already published and fence-valid. Use instance masks for coarse feature/ray-class exclusion, not as a substitute for material filtering.

Multiple TLASes are justified only for materially distinct geometry sets or latency domains—for example, a stable world TLAS and a small late first-person/hero structure—after measuring duplicated memory/build/traversal cost. Views normally share one world TLAS.

### Ray pipeline/SBT

Prefer ray queries/inline traversal for simple visibility and hit-ID workloads. For a ray pipeline, keep SBT records minimal:

- raygen record per dispatch class;
- small miss record set;
- hit-group records by shader/geometry class rather than instance × material where possible;
- callable records only when measured beneficial.

Put stable instance, geometry, and material IDs in TLAS/geometry metadata and resolve payload through the bindless tables defined in the preceding report. SBT generation is pipeline-generation data, not ordinary per-frame material data.

## 5. CPU, GPU, Memory, and Bandwidth Considerations

**CPU complexity.** Dirty extraction is O(changed instances + changed geometry). Prebuild queries, allocation decisions, compaction readback processing, and retirement operate on batches. TLAS instance generation is O(admitted instances) and should be a compact GPU or parallel CPU pass. Do not create an API object or heap allocation per instance per frame.

**GPU build complexity.** AS build cost depends on primitive count, spatial distribution, build flags, geometry type, and implementation; it is not exposed as a portable simple Big-O guarantee. Track primitives and bytes built/updated, not only structure count. Tiny builds underutilize the GPU, while one enormous BLAS reduces streaming/deformation granularity.

**Draw and dispatch counts.** Acceleration-structure commands are neither raster draws nor ordinary compute dispatches, so telemetry reports them separately: BLAS builds, BLAS updates, TLAS builds/updates, compact copies, serialization copies, and trace/query dispatches. Skinning/morph/deformation compute dispatches precede dynamic BLAS work. Batch compatible deformation and build commands.

**Scratch and allocations.** Query build/update scratch requirements and suballocate fence-safe aligned ranges from per-queue scratch arenas. Concurrent builds need non-overlapping scratch. Result storage uses large pooled heaps/buffers with a suballocator rather than one committed allocation per BLAS. Warm frames allocate no general heap memory; bursts defer low-priority structures when scratch/result pools are full.

**VRAM residency.** Budget separately: uncompacted BLAS, compacted BLAS, overlapping source/destination during compaction, TLAS generations, scratch peak, input vertex/index/AABB buffers, instance arrays, SBTs, material/geometry tables, micromaps, and debug metadata. Compaction can temporarily increase peak residency before reclaiming it. Streaming must reserve this overlap.

**Memory bandwidth and cache.** Builds read vertex/index/instance data and write opaque AS storage; compaction adds read+write traffic. Skinning followed by BLAS build reads deformed vertices again, making bandwidth and producer/consumer locality important. Ray traversal is sensitive to BLAS/TLAS spatial quality, AABB overlap, thin triangles, material/any-hit divergence, and SBT/resource locality.

**Shader divergence.** Mixed opaque/alpha/procedural geometries, divergent hit shaders, large payloads, recursive rays, and random materials reduce coherence. Separate geometry classes or use ray flags/masks when it improves traversal. Mark truly opaque geometry opaque. Prefer compact hit shaders and queued wave-friendly ray workloads; measure any shader-execution-reordering feature independently.

**Synchronization.** The dependency chain is deformation/upload → BLAS build/update → BLAS read/TLAS build → TLAS read/trace. Compaction is build → size query/readback → copy → TLAS rebuild → trace → old-address retirement. SBT writes must complete before ray-tracing shader reads. Barriers can cover batches; per-BLAS barriers destroy concurrency.

**Concurrency.** Async compute may hide deformation and AS builds behind independent graphics work, but TLAS and ray consumers create a hard deadline. Queue ownership transfers, shared memory bandwidth, and critical-path waits can make async slower. Build scheduling needs a deadline-aware queue, not “all RT on async.”

**Streaming and frame latency.** World cells publish raster assets independently from RT admission. A new object renders with screen/software/proxy fallback until inputs, BLAS, TLAS, and material records are all published. Compaction may trail initial visibility. Eviction first removes the instance from a future TLAS, waits for old TLAS consumers, then retires BLAS/input residency.

**CPU/GPU latency metrics.** Record request-to-input-resident, resident-to-build, build-to-TLAS-admission, compaction delay, deformation age at build, TLAS age at trace, and retirement delay. Avoid CPU readback on the frame-critical path; compacted-size readbacks feed later frames/jobs.

## 6. Pros and Cons

**Large merged BLAS**

- Pros: fewer TLAS instances; fewer small builds/allocations; can improve traversal when geometry bounds overlap closely.
- Cons: coarse streaming/rebuild unit; one moving part invalidates more work; empty spatial regions hurt traversal; poor destruction granularity.

**Small split BLAS**

- Pros: precise streaming, culling, deformation, and rebuild; easy instancing.
- Cons: more TLAS instances, allocations, metadata, and underfilled build calls; overlapping instance AABBs may hurt traversal.

**BLAS update/refit**

- Pros: substantially cheaper for bounded deformation; stable storage/address; good for bending without topology change.
- Cons: requires build-time update permission and unchanged topology contract; traversal quality degrades after large deformation; harder quality budgeting.

**BLAS rebuild**

- Pros: restores spatial quality; supports active/topology/count changes; simpler correctness.
- Cons: higher build time, scratch, bandwidth, and spikes; may change address/size.

**Compaction**

- Pros: lower long-lived VRAM; possible traversal/cache benefit.
- Cons: size query/readback, second allocation/copy, temporary overlap, fragmentation, TLAS address republish; poor value for ephemeral per-frame BLAS.

**Minimal class-based SBT**

- Pros: low memory/update bandwidth; fewer duplicated shader identifiers; stable under material streaming; better cache behavior.
- Cons: extra bindless table indirection; depends on a disciplined common hit-shader ABI.

**Per-instance SBT records**

- Pros: flexible local data and shader selection; straightforward mapping.
- Cons: memory/header duplication; CPU/GPU update cost; fragile indexing; record churn on material changes.

## 7. ECS and Render-World Integration

ECS owns semantic renderables and animation/destruction state, never acceleration-structure objects or addresses.

Extraction emits:

```text
RayGeometryIntent {
  renderInstanceId, geometryAssetId, geometryGeneration,
  transform, previousTransform, deformationEpoch,
  topologyEpoch, materialClassMask, rayVisibilityMask,
  importance, residencyState
}
```

The renderer owns:

- `RayGeometryRecord` — geometry/index/attribute handles, BLAS policy, bounds, primitive ranges;
- `BLASRecord` — logical ID, address generation, build source generation, flags, state, storage/scratch sizes, last build/update, deformation metric;
- `RayInstanceRecord` — stable renderer instance ID, current BLAS generation, transform, mask, flags, material/geometry table IDs, SBT class;
- `TLASRecord` — instance-buffer generation, admitted instance set, build fence, device generation;
- `SBTRecordSet` — pipeline generation, shader class IDs, strides/ranges, GPU buffer generation.

Animation publishes deformed vertex buffers and a deformation epoch. The AS scheduler never reads mutable ECS pose arrays. A BLAS update references one immutable deformation output; the TLAS cannot publish that BLAS generation until the build completes.

First-person hands/weapons can use a distinct importance/deadline and ray mask. Third-person characters follow world visibility/importance. Do not put view-dependent camera transforms into shared world BLAS; camera/view affects TLAS selection and ray generation, not geometry truth.

## 8. Resource, Pass, Material, and Visibility Interfaces

```text
BLASBuildRequest {
  blasId, expectedGeneration, geometryInputs[],
  sourceBLAS, operation, buildFlags,
  resultCapacity, scratchCapacity, deadline, priority
}

BLASPublication {
  blasId, newGeneration, deviceAddress,
  resultRange, geometryGeneration, deformationEpoch,
  buildFlags, completionFence
}

TLASInstance {
  transform3x4, instanceId, visibilityMask,
  sbtClassOffset, flags, blasAddressGeneration
}

RaySceneSnapshot {
  deviceGeneration, tlasGeneration, tlasHandle,
  instanceTableGeneration, geometryTableGeneration,
  materialTableGeneration, sbtGeneration
}
```

Render-graph pass sequence:

1. `RaySceneDirtyExtract/Upload`
2. `DeformRayGeometry`
3. `BuildOrUpdateBLAS`
4. `EmitCompactedSizes` where eligible
5. batch AS dependency
6. `BuildTLASInstances`
7. `BuildTLAS`
8. `CompactBLASCopies` on later frames
9. `BuildSBT` only when pipeline/class generation changes
10. ray query/pipeline consumers
11. timestamp/query readback and retirement.

Every pass declares input vertex/index/instance buffers, scratch ranges, AS read/write/copy access, SBT read, and queue. The graph compiler understands AS operations as first-class accesses rather than generic UAV guesses.

Material interfaces classify geometry as opaque, alpha-tested, transmissive, or excluded and provide a stable bindless material ID. Alpha-tested hit evaluation uses the same alpha/cutout convention and texture/mip fallback as raster. A missing alpha texture must choose a conservative declared fallback, not random opacity.

Visibility admission uses world-cell residency, ray-feature masks, distance/significance, primitive count, update cost, last trace usefulness, and budget. Raster frustum visibility alone is insufficient because off-screen geometry can affect rays. Use an expanded interest volume and feature-specific range, with hysteresis.

## 9. Asset and Runtime Integration Plan

1. Extend mesh cooking with RT eligibility, triangle/AABB ranges, opacity/material classes, bounds-quality metrics, stable geometry indices, and recommended BLAS grouping.
2. Add API-neutral BLAS/TLAS records, pooled result storage, scratch arenas, post-build queries, and generation-safe retirement.
3. Ship static opaque geometry first: fast-trace build, batched compaction, bindless hit tables, and ray-query validation.
4. Add rigid instancing and per-frame TLAS rebuild from compact instance records.
5. Add alpha-tested geometry under explicit any-hit/opacity budgets; evaluate opacity micromaps only as an optional capability after correctness.
6. Integrate streamed world cells: input residency → BLAS build → TLAS admission; eviction reverses that order with fences.
7. Add skinned hero geometry using deform → update/rebuild deadlines, periodic/metric rebuild policy, and stale/proxy fallback. Add foliage and crowds only after measured budgets.
8. Add full ray pipelines and a minimal SBT if workloads require programmable hit/miss stages; keep ray queries for simple visibility.
9. Add compaction scheduling/readback outside the critical frame and defragment result pools by generation replacement, never in-place address mutation.
10. Integrate device-loss reconstruction. Rebuild from cooked geometry/view keys; treat serialized AS blobs only as a checked platform cache.

## 10. Visual and Performance Verification Strategy

Correctness fixtures:

- static, instanced, moving, skinned, morphing, wind-deformed, topology-changing, generated, and destroyed geometry;
- opaque, alpha-tested, double-sided, transmissive, procedural AABB, missing-texture, and proxy classes;
- shared BLAS with many transforms/materials; merged versus split geometries; zero/maximum instance masks;
- compaction address replacement during active traces; cell load/unload; device loss; origin rebasing;
- SBT record boundaries, instance offsets, geometry indices, ray-type offsets/strides, pipeline hot reload, and minimal/bindless records;
- rapid camera switch between first- and third-person, multi-view, reflection cameras, and off-screen occluders.

Compare ray-query and ray-pipeline hits to a CPU reference/BVH and raster visibility where equivalent. Validate instance ID, primitive/geometry ID, barycentrics, object/world position, normal orientation, material ID, alpha decision, and hit distance. Randomize input order to expose accidental ID/address coupling.

Use D3D12 GPU-based/DXR validation, Vulkan validation and synchronization validation, PIX, Nsight, and Radeon Raytracing Analyzer where supported. Debug builds poison retired AS ranges and SBT records, validate every TLAS BLAS-address generation, and record the first invalid instance/record.

Performance telemetry:

- CPU extraction/scheduling/prebuild/allocation/publication/retirement time and allocations;
- BLAS builds/updates, primitives, input bytes, TLAS instances/builds, compact copies, and trace/query dispatches;
- GPU deformation/build/update/TLAS/compaction/SBT/trace time;
- build/update/trace throughput, traversal steps/counters where available, any-hit rate, divergence, occupancy, cache misses, and incoherent rays;
- result/scratch/TLAS/SBT/input/micromap VRAM, source+compacted peak, fragmentation, and residency;
- input/build/compaction bandwidth; AS/SBT barriers, queue waits, async overlap, latency, and concurrency;
- streaming admission/eviction counts and ages; stale/proxy/fallback hit counts;
- first-person, third-person, and worst-case destruction/streaming percentiles.

Acceptance:

- zero warm-frame general allocations;
- no TLAS references a retired/unpublished BLAS generation;
- no update violates topology/build-flag constraints;
- build storms stay within scratch/result/time budgets and degrade by importance;
- static compaction lowers steady-state memory enough to justify peak/copy cost;
- dynamic update/rebuild policy prevents unbounded traversal degradation;
- SBT indices remain in range across pipeline/material streaming;
- no CPU wait/readback in the normal frame-critical path.

## 11. Platform and Scalability Risks

- DXR/Vulkan RT capability tiers, build flags, scratch sizes, alignment, compaction ratio, update quality, and traversal performance vary by GPU/driver.
- Async AS construction competes for compute units and memory bandwidth; “overlap” can lengthen the graphics critical path.
- Skinned characters, foliage, hair, particles, and destruction can consume more build bandwidth than the rays save.
- Updating badly deformed BLAS preserves correctness but can silently degrade traversal. Rebuild metrics need vendor-specific calibration.
- Alpha-tested geometry can dominate any-hit work and texture divergence. Missing or coarse streamed alpha mips can change visibility.
- Large merged BLAS hurts world streaming; excessively split BLAS inflates TLAS and build overhead.
- Compaction creates temporary double residency and changes addresses, requiring TLAS regeneration and fence-safe retirement.
- AS serialization is not a universal asset format and may invalidate after adapter/driver changes.
- SBT record sizes/alignments and shader identifiers are backend/pipeline specific. Raw SBT bytes cannot be shared across APIs or pipeline generations.
- Ray queries avoid SBT management but still require all AS lifetime/synchronization and can consume substantial per-thread private storage.
- First-person geometry may require special masks/ranges to prevent self-intersection or missing near-field reflections.
- Origin rebasing, large worlds, and floating precision affect TLAS transforms and ray distances.
- Emerging cluster AS, partitioned TLAS, opacity/displacement micromaps, position fetch, and SER are optional optimization paths, not a stable minimum architecture.

Scalability controls include RT admission range/importance, geometry LOD/proxy, update frequency, per-frame rebuild budget, scratch/result pools, alpha-tested inclusion, BLAS grouping, TLAS subset, ray count/range, SBT pipeline complexity, and static compaction budget.

## 12. Engineering Recommendations

These are engineering recommendations:

1. Build one renderer-owned ray-scene service shared by GI, reflections, shadows, AO, and diagnostics. Effects consume immutable `RaySceneSnapshot` generations.
2. Classify BLAS policy at cook/extraction: static compacted fast-trace, shared rigid, bounded-update deforming, rebuild-only wild deformation, procedural, or proxy.
3. Pool result storage and scratch; batch deformation and BLAS work; use one/few batch dependencies before TLAS rather than per-structure serialization.
4. Rebuild TLAS from compact admitted instances by default. Adopt TLAS update only if target measurements prove a benefit without traversal-quality loss.
5. Use update only when topology/count/flags remain legal and deformation stays bounded. Schedule metric/periodic rebuilds to restore quality.
6. Compact long-lived static BLAS asynchronously. Publish uncompacted data first when latency matters, then replace via a new address generation and TLAS.
7. Keep TLAS instance IDs stable and separate from ECS IDs, memory addresses, and SBT offsets. Validate BLAS address generations on every TLAS build.
8. Mark opaque geometry opaque. Admit alpha-tested/deforming geometry under explicit budgets and share raster alpha/material semantics.
9. Prefer ray queries for simple visibility. When a ray pipeline is required, keep SBTs class-based and minimal; resolve geometry/material data through bindless tables.
10. Treat raster visibility, RT admission, input residency, BLAS publication, TLAS membership, and SBT readiness as separate states. Always provide a proxy/software/screen fallback.
11. Rebuild opaque AS and SBT data after device loss; serialized AS is a checked local cache only.
12. Keep open decisions explicit: minimum RT tier; BLAS grouping/cook rules; build flags; scratch/result budgets; compaction threshold; TLAS rebuild/update; admission volume; dynamic deformation metric/rebuild cadence; alpha policy/micromaps; SBT class/ray-type layout; multiple-TLAS policy; serialization; and per-platform CPU/GPU/bandwidth/VRAM/latency/concurrency budgets.

## 13. Source Links

- [Microsoft DirectX Specs: DXR Functional Specification](https://microsoft.github.io/DirectX-Specs/d3d/Raytracing.html)
- [Microsoft: D3D12 compacted acceleration-structure size](https://learn.microsoft.com/en-us/windows/win32/api/d3d12/ns-d3d12-d3d12_raytracing_acceleration_structure_postbuild_info_compacted_size_desc)
- [Khronos Vulkan Specification: Acceleration Structures](https://docs.vulkan.org/spec/latest/chapters/accelstructures.html)
- [Khronos Vulkan Specification: Ray Tracing and Shader Binding Tables](https://docs.vulkan.org/spec/latest/chapters/raytracing.html)
- [Khronos Vulkan Guide: Ray Tracing and Synchronization](https://docs.vulkan.org/guide/latest/extensions/ray_tracing.html)
- [Khronos Vulkan Tutorial: BLAS and TLAS](https://docs.vulkan.org/tutorial/latest/courses/18_Ray_tracing/02_Acceleration_structures.html)
- [NVIDIA: Updated RTX Ray-Tracing Best Practices](https://developer.nvidia.com/blog/best-practices-for-using-nvidia-rtx-ray-tracing-updated/)
- [NVIDIA: Ray-Tracing Acceleration-Structure Compaction](https://developer.nvidia.com/blog/tips-acceleration-structure-compaction/)
- [NVIDIA: Practical Tips for Optimizing Ray Tracing](https://developer.nvidia.com/blog/practical-tips-for-optimizing-ray-tracing/)
- [NVIDIA: Driver-Level Ray-Tracing Validation for D3D12 and Vulkan](https://developer.nvidia.com/blog/ray-tracing-validation-at-the-driver-level/)
- [NVIDIA: Efficient Shader Binding Table Organization](https://developer.nvidia.com/blog/efficient-ray-tracing-with-nvidia-optix-shader-binding-table-optimization/)
- [AMD Radeon Raytracing Analyzer](https://gpuopen.com/rra/)
