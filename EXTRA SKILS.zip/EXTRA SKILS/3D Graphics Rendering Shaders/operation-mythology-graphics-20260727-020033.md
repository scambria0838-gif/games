# Operation Mythology Graphics Research Report

**Timestamp:** 2026-07-27 02:00:33 America/Los_Angeles  
**Subject:** Mesh and texture asset build pipeline, validation, compression, and derived-data cache  
**Status:** New architectural baseline  
**Assumptions:** Authoring sources are immutable inputs; runtime formats are platform-derived artifacts; renderer uses PBR materials, virtualized streaming, GPU-driven visibility, and D3D12/Vulkan.

## 1. Feature Overview

The graphics asset pipeline converts DCC-authored meshes, UVs, textures, materials, and metadata into deterministic platform-ready data. Runtime performance and visual correctness depend on decisions made during this build:

- coordinate system, units, transforms, topology, normals, tangents, and skin data;
- UV validity, seams, texel density, padding, and lightmap/virtual-texture constraints;
- PBR channel meaning and color space;
- mip filtering and alpha coverage;
- GPU block-compression format and quality;
- index/vertex locality, overdraw order, LODs, meshlets, bounds, and streaming pages;
- content-addressed derived-data keys and cache distribution.

**Engineering recommendation:** Preserve editable source assets and recipes; generate immutable, versioned platform artifacts through a deterministic build DAG. Runtime never parses DCC interchange formats or compresses production textures/meshes.

## 2. Existing Coverage and Identified Gap

The required recursive scans found existing baselines for runtime residency, virtual geometry/textures, GPU-driven rendering, shading, temporal reconstruction, shadows, GI/reflections, and shader/PSO derived data.

Those reports define runtime page caches and stable handles but do not establish:

- canonical import/interchange semantics;
- geometry/UV/tangent validation gates;
- PBR texture color-space and packing rules;
- mip generation by signal type;
- platform texture-compression selection;
- mesh optimization/cooking order;
- content-addressed asset build keys;
- shared/local cache hierarchy and reproducibility.

This batch fills the offline-to-runtime boundary.

## 3. Sourced Facts

1. glTF 2.0 defines standard vertex semantics including position, normal, tangent, texture coordinates, joints, and weights. Tangent `w` encodes handedness; the specification defines metallic in the blue channel and roughness in green using a linear transfer function [1].
2. glTF defines tangent-space normal textures as linear data, not color data [1].
3. Khronos provides a glTF validator that checks schema, references, accessors, buffers, animations, images, and supported extensions and emits machine-readable reports [2].
4. KTX2 can store mip levels and BasisLZ supercompressed universal texture data intended for transcoding to GPU block formats [3].
5. Microsoft's DirectXTex `texconv` supports resizing, mip generation, block compression, sRGB/color handling, alpha modes, and alpha-coverage preservation for cutout mipmaps [4].
6. Meshoptimizer documents offline vertex-cache, overdraw, vertex-fetch, simplification, and meshlet processing plus analyzers for resulting statistics [5].
7. Epic describes derived data as disposable/regenerable output stored outside source assets, with a fastest-to-slowest cache hierarchy that promotes found data locally and asynchronously publishes newly built data [6].

**Cross-source conclusion:** Interchange specifications define semantics, not a complete game-ready cook. A production pipeline must validate author intent, generate signal-aware mips, choose platform formats, optimize geometry, and cache every result from a fully versioned recipe.

## 4. Industry-Standard Rendering API or Pattern

### Build DAG

1. Ingest source bytes and import settings.
2. Validate interchange format and external dependencies.
3. Normalize coordinates, units, transforms, topology, and material semantics.
4. Produce canonical high-precision intermediate mesh/texture/material data.
5. Validate geometry, UVs, tangents, skinning, and texture channels.
6. Generate or verify normals/tangents, LODs, meshlets, collision/render bounds, and streaming hierarchy.
7. Generate signal-aware mip chains before block compression.
8. Encode target GPU formats and streaming chunks/pages.
9. Package immutable runtime blobs plus compact metadata.
10. Publish blobs into local/shared content-addressed derived-data caches.

Every node is a pure function of declared inputs and tool/version/configuration identity.

### Canonical import

Use glTF/GLB as a supported interchange baseline, not the internal runtime format. DCC-native files remain source-controlled alongside export recipes. Normalize:

- handedness/up axis;
- meters-per-unit;
- transform bake policy;
- triangle winding;
- indexed triangle topology;
- tangent basis convention;
- bone/joint limits;
- material texture semantics.

Reject NaN/Inf, degenerate/non-manifold geometry where forbidden, invalid indices, zero-length normals, non-normalized skin weights, singular transforms, and bounds inconsistent with data.

### Texture semantic classes

- base color/emissive: color-managed source, sampled as sRGB/declared gamut;
- normal: linear vector data, renormalized during mip generation;
- roughness/metallic/AO/masks: linear scalar data;
- height/displacement: linear scalar with min/max-aware filtering where needed;
- HDR environment/emissive: linear float;
- alpha cutout: coverage-preserving mip policy;
- UI/data/LUT: explicit no-generic-mip or special filter policy.

Packing channels is a platform/material decision after semantic validation, not an artist-side implicit convention.

### Platform texture formats

Typical starting policy:

- BC7 for high-quality desktop color/alpha;
- BC5 for two-channel tangent normals;
- BC4 for single-channel masks;
- BC6H for HDR;
- BC1/BC3 only where quality/compatibility/budget justify them;
- ASTC/ETC2 capability-selected for mobile/tile platforms;
- KTX2/Basis universal payload for distribution workflows requiring runtime transcode, not automatically for latency-critical native builds.

Choose by measured quality, decode support, block size, package size, transcode/upload latency, and platform policy.

### Geometry cook order

1. weld only where all required attributes agree;
2. generate/validate normals and MikkTSpace-compatible tangents;
3. optimize index order for post-transform cache;
4. optionally reorder for overdraw within locality constraints;
5. optimize vertex fetch/remap;
6. generate LOD hierarchy with attribute/border constraints;
7. partition meshlets/clusters and compute conservative bounds/cones/errors;
8. quantize/compress per target;
9. page/chunk for streaming and emit resident fallback roots.

Re-run analyzers after every lossy transformation.

## 5. CPU, GPU, Memory, and Bandwidth Considerations

### Offline CPU, memory, and concurrency

Let `Nv`, `Nt`, and `Px` be vertices, triangles, and source texels:

- validation is generally **O(Nv + Nt + Px)**;
- mip generation is **O(Px)** over the geometric series;
- vertex/cache/fetch remapping is approximately **O(Nv + Nt)**;
- simplification and clustering are implementation dependent, commonly near-linear or **O(N log N)**;
- compression cost is **O(Px × encoder effort)**.

Use a bounded build worker pool. Texture encoders and simplifiers can consume large RAM; schedule from estimated peak memory, CPU, GPU-encoder availability, and I/O bandwidth. Avoid launching one task per tiny asset; batch small work.

### Runtime CPU and allocations

Runtime loads compact headers and bulk payloads, validates version/hash, reserves/upload pages, and publishes stable handles. It does not:

- parse JSON/DCC scenes;
- regenerate tangents/LODs/mips;
- compress textures;
- reorder meshes;
- allocate one object per vertex/tile.

Use batched asynchronous I/O, bounded staging pools, and zero steady-state general-heap allocation in streaming/render threads.

### GPU and draw efficiency

- Vertex-cache optimization lowers repeated vertex shader work.
- Vertex-fetch optimization improves sequential memory access.
- Meshlets bound work for GPU culling and virtual geometry.
- Excessive vertex splitting from UV/normal/material seams increases vertex bandwidth.
- Overdraw ordering trades depth efficiency against vertex locality; profile by content.
- Quantization reduces bandwidth/cache footprint but can expand bounds or create cracks/normal errors.
- Alpha-tested textures remain overdraw/bandwidth heavy even when compressed.

### Texture bandwidth and mipmaps

A full mip chain adds roughly one third over the top-level uncompressed/block-compressed footprint. It usually reduces runtime bandwidth and cache thrash by sampling appropriately sized levels. Missing or incorrect mips cause aliasing, shimmer, and bandwidth waste.

Block compression reduces residency and sampling bandwidth, but artifacts depend on signal and encoder effort. Normal/mask channels need objective angular/scalar error metrics, not only RGB PSNR.

### Derived-data storage

Separate:

- small metadata/manifests;
- large immutable bulk blobs;
- local hot cache;
- shared team cache;
- optional cloud/regional cache;
- packaged/cooked artifacts.

Use atomic put-if-absent, checksums, compression, deduplication, access-time/size GC, and negative/corruption telemetry. Cache hits promote into the fastest local tier. Cache failure must rebuild from authoritative source and recipe.

## 6. Pros and Cons

### Strict validation

**Pros:** failures occur before runtime; consistent PBR; prevents corrupt streaming data.  
**Cons:** requires author tooling, exceptions, and migration work.

### Platform-native cooking

**Pros:** no runtime transcode; optimal formats/layouts.  
**Cons:** more build/storage variants.

### Universal KTX2/Basis distribution

**Pros:** compact cross-platform delivery; flexible transcode.  
**Cons:** runtime/install transcode cost and potentially lower endpoint quality than slow native encoders.

### Channel packing

**Pros:** fewer textures/descriptors/samples.  
**Cons:** coupled resolution/mip/compression semantics and harder reuse.

### Shared DDC

**Pros:** amortizes expensive builds across team/CI.  
**Cons:** service/storage/GC/security complexity; stale-key bugs are severe.

## 7. ECS and Render-World Integration

ECS stores stable logical mesh/material/texture handles only. Import settings, source paths, UV reports, compression jobs, DDC keys, GPU formats, physical pages, and descriptors remain in asset/build/renderer services.

The asset registry publishes:

- logical asset ID and generation;
- runtime artifact version;
- bounds, LOD/page metadata;
- material domain and texture semantic bindings;
- platform residency sizes and fallback handles.

Render extraction copies logical handles into the render world. Streaming resolves them to current resident LOD/mips/pages. Artifact hot reload increments generations and publishes only after upload completion; old resources retire by fences.

## 8. Resource, Pass, Material, and Visibility Interfaces

### `AssetBuildRecipe`

- source content hashes and dependency list;
- importer/tool versions;
- coordinate/unit/tangent policy;
- validation rule set;
- mesh LOD/cluster/quantization settings;
- texture semantic, color space, mip filter, alpha policy, format/encoder effort;
- target platform/capabilities;
- runtime schema/page/package versions.

### `DerivedArtifactManifest`

- content-addressed key;
- artifact type/version;
- input dependency keys;
- payload hashes/sizes;
- runtime metadata;
- validation metrics/warnings;
- tool provenance;
- platform compatibility.

### `MaterialTextureBinding`

- semantic rather than filename convention;
- color-transfer/gamut;
- channel mapping;
- UV set and transform;
- sampler/address policy;
- fallback value/resource;
- virtual/conventional streaming class.

### Runtime mesh interface

- vertex/index/meshlet streams;
- attribute decode layout;
- LOD hierarchy/projected-error data;
- bounds/cones;
- material sections;
- virtual page dependencies;
- fallback/root residency.

## 9. Asset and Runtime Integration Plan

1. Define authoritative source, interchange, canonical intermediate, and runtime schemas.
2. Integrate glTF validation plus engine-specific semantic validators.
3. Establish coordinate, scale, tangent, UV, skin, and PBR rules with DCC export presets.
4. Build content-addressed recipe/dependency hashing and local DDC.
5. Add shared cache with atomic publication, checksum verification, and GC.
6. Implement signal-aware texture conversion/mips and desktop BC targets.
7. Add ASTC/ETC/mobile and KTX2/Basis workflows where justified.
8. Add mesh cache/fetch/overdraw optimization and metric reports.
9. Add LOD simplification, meshlet/cluster generation, quantization, and virtual pages.
10. Cook compact runtime containers with independently streamable chunks.
11. Integrate artifact manifests with residency/upload services.
12. Add CI farm validation, deterministic rebuild checks, golden images/meshes, and budget dashboards.

## 10. Visual and Performance Verification Strategy

### Geometry/UV

- validate finite positions, topology, winding, degenerates, manifold policy, normals/tangents, skin weights, bounds;
- detect mirrored/overlapping/zero-area UVs by semantic policy;
- measure UV stretch, texel-density deviation, island gutter at each target mip, seam count, and vertex splits;
- compare LOD silhouettes, normals, UV seams, skin deformation, and meshlet bounds against source.

### Texture/material

- verify declared color space and PBR channel ranges;
- inspect normal angular error and renormalization;
- measure scalar RMSE/max error for roughness/masks;
- test alpha coverage across mip chain;
- evaluate compression with PSNR/SSIM/FLIP plus semantic metrics and artist review;
- render golden spheres/meshes under controlled HDR lighting.

### Determinism/cache

- rebuild identical recipes on different workers and compare artifact hashes;
- perturb one dependency/tool/config field and require a new key;
- corrupt/truncate cache blobs and verify rejection/rebuild;
- test concurrent duplicate builds and atomic publication;
- measure local/shared hit rate, bytes, latency, build time, queue depth, RAM, CPU, I/O, and cache churn.

### Runtime performance

Record:

- draw/dispatch count and batching;
- vertex/triangle/meshlet counts by LOD;
- post-transform cache metrics, vertex-fetch bytes, overdraw;
- texture residency, requested mip error, block-format bytes, sampling bandwidth/cache;
- streaming I/O, decompression/transcode, upload bytes/latency;
- allocations and frame-time tails during traversal/teleport.

### Acceptance gates

- No runtime import or production transcoding on native cooked builds.
- All artifacts reproduce from declared sources/recipes.
- Zero validator errors; warnings require explicit waiver.
- No NaN/invalid bounds/indices/tangents.
- Alpha, normal, and color-space golden tests pass.
- Cache corruption never becomes a runtime artifact.
- Runtime blobs meet per-platform memory, bandwidth, LOD, and streaming budgets.

## 11. Platform and Scalability Risks

- GPU format support differs across desktop, console, mobile, and HDR targets.
- Slow high-quality encoders increase cook latency and CI cost.
- UV/tangent conventions can differ across DCC/export/import/render stages.
- Channel packing can force unrelated signals to share resolution/mips/compression.
- Mesh simplification can break hard edges, UV borders, skinning, morphs, or material IDs.
- Quantized/page-local geometry can crack at boundaries.
- Universal texture transcode consumes install/runtime CPU/GPU memory and staging bandwidth.
- DDC key omissions create silently stale artifacts; over-keying destroys hit rate.
- Shared cache outages must degrade to local build without blocking the entire team.
- Source licenses and provenance must travel with asset metadata.

## 12. Engineering Recommendations

1. Treat source assets and recipes as authoritative; derived artifacts are disposable.
2. Make every build node pure, content-addressed, versioned, and reproducible.
3. Adopt glTF semantics/validation as interchange baseline, then enforce stricter engine rules.
4. Standardize units, axes, tangent basis, PBR channels, and color space.
5. Generate mips by signal type before block compression.
6. Preserve alpha coverage and renormalize normal-map mips.
7. Choose GPU formats per platform and semantic using measured error.
8. Optimize geometry offline in a documented cache/overdraw/fetch/LOD/meshlet order.
9. Store compact independent streaming chunks with resident fallbacks.
10. Use hierarchical local/shared DDC with checksums, atomic publication, and telemetry.
11. Reject invalid content in CI; provide DCC-facing diagnostics and automatic fixes only when deterministic/safe.
12. Track artifact size, build cost, runtime bandwidth, and visual error as one budget system.

### Remaining open decisions

- Canonical interchange/DCC exporter versions.
- MikkTSpace implementation/version and tangent regeneration policy.
- UV overlap/gutter/texel-density limits by material class.
- Desktop/mobile texture format matrix and encoder effort.
- Channel-packing rules.
- LOD simplifier and meshlet/page targets.
- Runtime container/chunk format.
- Local/shared/cloud DDC topology, quota, GC, and authentication.
- Deterministic cross-platform worker requirements.

## 13. Source Links

1. Khronos, **glTF 2.0 Specification**: https://registry.khronos.org/glTF/specs/2.0/glTF-2.0.html
2. Khronos, **glTF Validator**: https://github.com/KhronosGroup/glTF-Validator
3. Khronos, **KTX 2.0 Specification**: https://github.khronos.org/KTX-Specification/ktxspec.v2.html
4. Microsoft, **DirectXTex texconv**: https://github.com/microsoft/DirectXTex/wiki/texconv
5. Arseny Kapoulkine, **meshoptimizer**: https://meshoptimizer.org/
6. Epic Games, **Derived Data Cache, Unreal Engine 5.8**: https://dev.epicgames.com/documentation/en-us/unreal-engine/using-derived-data-cache-in-unreal-engine

