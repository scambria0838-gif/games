# Operation Mythology Graphics Research — GPU-Driven Particles, Decals, Trails, and Destruction VFX

**Timestamp:** 20260727-021956  
**Scope:** CPU/GPU effect execution, sprites, meshes, ribbons/trails, decals, translucent composition, collision/query interfaces, destruction-event handoff, pooling, culling, sorting, indirect rendering, temporal data, budgeting, and scalability.  
**Assumptions:** Modular data-oriented engine; explicit render-world extraction; render graph; existing GPU-driven submission, temporal, volumetric, physics, and destruction boundaries; first- and third-person cameras; VFX are non-authoritative unless explicitly promoted; no production-code implementation.

## 1. Feature Overview

Operation Mythology needs a programmable VFX service that can express weapon impacts, sparks, smoke, dust, fire, magic, rain, debris, beams, ribbons, decals, shell fragments, and destruction embellishment without turning every effect into a unique engine subsystem.

The core architecture should compile authored effect graphs into fixed execution stages:

- spawn and initialization;
- per-step simulation;
- event/data-channel ingestion and emission;
- culling, LOD, compaction, and optional sorting;
- renderer expansion into sprites, meshes, ribbons, decals, lights, and volume injection;
- indirect draw/dispatch generation;
- bounded history, collision, and output interfaces.

CPU simulation is the semantic/low-count path. GPU simulation is the high-count visual path. GPU particles must not become hidden gameplay authority because readback and asynchronous scene queries add latency.

## 2. Existing Coverage and Identified Gap

The recursive inventory found GPU-driven opaque submission, render graphs, memory/residency, temporal reconstruction, shadows, GI, volumetrics, water, animation/deformation, physics/controller integration, asset cooking, PSO management, exposure, and profiling. A newly added physics report covers authoritative collision and character behavior but not visual destruction or particle simulation.

The uncovered gap is the VFX execution/rendering contract:

- graph compilation and parameter/data interfaces;
- CPU-versus-GPU ownership;
- capacity, pooling, spawn admission, and overflow;
- GPU compaction, sort, ribbon generation, and indirect submission;
- decal pass selection and receiver filtering;
- destruction-to-VFX event handoff;
- transparency/overdraw and temporal behavior;
- deterministic degradation under CPU, GPU, VRAM, and bandwidth pressure.

## 3. Sourced Facts

The following are sourced facts:

- Epic describes Niagara systems as containers of emitters, modules, parameters, and renderers, with emitters able to execute on CPU or GPU.
- Epic's Niagara API includes GPU compute dispatch/data managers, GPU instance-count management, asynchronous GPU readback, data interfaces, render-target interfaces, and sprite, mesh, ribbon, decal, light, and component renderers.
- Epic documents asynchronous GPU scene traces with one frame of latency and Niagara Data Channel GPU communication that can likewise introduce a frame of latency.
- Epic's Effect Type assets apply shared scalability policy across effect classes and can cull by global budget, distance, global instance count, and per-system instance count.
- Epic exposes fixed bounds and automatic emitter deactivation. Fixed bounds permit culling without deriving bounds from every live GPU particle but require correct authoring.
- Epic's Niagara ribbon renderer connects particles in ribbon order and exposes tessellation/shape/UV controls; GPU initialization can generate ribbon geometry for CPU systems.
- Epic's decal documentation describes two deferred paths: DBuffer decals accumulated before the base pass and decals blended into the GBuffer after the base pass but before lighting. Epic states that decal cost increases with screen coverage.
- AMD FidelityFX Parallel Sort is a compute radix sort supporting 32-bit keys and optional payloads, direct or indirect execution, D3D12/Vulkan, and multiple count/reduce/scan/scatter stages. AMD explicitly identifies particles as a use case.
- McGuire and Bavoil's weighted blended order-independent transparency uses bounded memory and streaming blending without per-fragment depth sorting, trading exact order for an approximation useful for particle systems and other partial-coverage effects.
- NVIDIA Blast intentionally leaves physics and graphics integration to the application and emits destruction changes that the engine maps into its own physics and rendering representation.
- Epic Chaos Destruction uses pre-fractured Geometry Collections and clustering and can integrate destruction events with Niagara and audio.

## 4. Industry-Standard Rendering API or Pattern

Compile each effect asset into:

- immutable module bytecode/IR or shader kernels;
- a fixed particle attribute layout;
- CPU and/or GPU execution programs;
- resource/data-interface bindings;
- renderer descriptors;
- capacity and scratch requirements;
- platform/scalability variants;
- shader/PSO manifest entries.

Execute through a staged frame graph:

1. collect and compact effect-system commands/events;
2. admit/reject spawns by priority and capacity;
3. simulate CPU effects in jobs and GPU effects in batched compute;
4. perform bounded collision/query sampling;
5. cull dead/offscreen/low-significance particles;
6. compact surviving renderer instances;
7. generate sort keys only for renderers that require them;
8. radix-sort selected key/payload ranges;
9. build ribbon topology/tessellation and mesh/sprite/decal/light instance streams;
10. generate indirect dispatch/draw arguments;
11. render by domain and material/pipeline class;
12. resolve delayed readback/events outside the frame-critical path.

Use per-effect-class pools and global arenas, not a GPU allocation per emitter. Keep particle attributes structure-of-arrays or carefully packed AoSoA according to kernel access. Renderers consume views over attributes rather than owning duplicate particle state.

## 5. CPU, GPU, Memory, and Bandwidth Considerations

**CPU complexity.** Command collection is `O(S + E)` for active systems and incoming events. CPU simulation is proportional to live CPU particles times active modules. Render extraction should emit compact system descriptors, not copy every GPU particle. Batch graph instances sharing compiled programs and parameter layouts. Use job granularity per costly system or batches of small systems.

**GPU complexity and dispatch counts.** Naive work is proportional to live capacity, but compaction can make renderer work proportional to survivors. Each program class may require spawn/update, event, cull/compact, sort, renderer expansion, and argument-generation dispatches. Avoid a dispatch per tiny emitter by batching compatible systems and using offsets/counts. Sorting is multi-pass; sort only translucent groups whose artifacts justify it.

**Draw-call reduction and batching.** Generate indirect sprite/mesh/ribbon/decal draws by renderer, material, depth mode, and pipeline class. Use bindless/indexed materials where available. Consolidate tiny bins into generic pipelines. Mesh particles should use instancing or shared meshlet/indirect infrastructure.

**Allocations and VRAM residency.** Preallocate particle attribute heaps, alive/dead lists, counters, event rings, sort keys/payload/scratch, ribbon points/vertices, indirect arguments, and history buffers. Track high-water marks and overflow. Attribute bloat is multiplicative: one unused 16-byte attribute across one million particles costs about 15.3 MiB before allocator overhead.

**Memory bandwidth and cache behavior.** Particle simulation is often bandwidth-bound because many simple modules repeatedly read/write attributes. Fuse compatible modules, keep hot attributes compact, split cold/custom attributes, and avoid writing values unused by renderers. Compaction and radix sort add full-buffer traffic. Sprite overdraw adds render-target bandwidth well beyond simulation cost.

**Shader divergence.** Divergence arises from per-particle module branches, collisions, event types, renderer modes, alive/dead paths, and material features. Compile coherent variants, partition heterogeneous work, and use masks/compaction. Do not interpret a highly dynamic graph in a divergent megakernel on shipping GPU paths.

**Synchronization and concurrency.** Simulation writes precede cull/sort/renderer expansion; sort precedes translucent draw; destruction transforms precede debris rendering; depth/HZB precedes depth collision/culling. Keep counters GPU-resident and generate indirect arguments without CPU readback. Async compute is useful only when it overlaps without delaying depth, translucency, or bandwidth-heavy graphics.

**Streaming.** Effect graphs, textures, flipbooks, meshes, vector fields, volume assets, materials, and PSOs should prefetch by encounter/level and effect class. Missing resources use resident neutral assets or suppress the renderer while simulation remains valid. Limit first-use shader/PSO stalls through manifests and warm-up.

**Frame latency.** GPU queries/readback are delayed. Visual effects can tolerate this if contracts label event age and scene generation; gameplay cannot. Motion vectors require previous rendered particle/ribbon positions or analytic reconstruction. Temporal upscalers need reactive/transparency masks for rapidly changing emissive/translucent effects.

## 6. Pros and Cons

**CPU particles**

- Pros: immediate gameplay/world queries, straightforward deterministic events, easy debugging, good for low counts.
- Cons: CPU simulation/extraction/upload cost, poor scaling to dense effects, increased draw preparation.

**GPU particles**

- Pros: massive parallelism, GPU-resident state, direct compaction/sort/indirect rendering, high counts.
- Cons: delayed readback/query results, difficult determinism/debugging, buffer-capacity management, synchronization and bandwidth cost.

**Exact depth sorting**

- Pros: correct conventional alpha order at particle/primitive granularity.
- Cons: key generation, multi-pass sort, scratch memory, bandwidth, and imperfect results for intersecting geometry.

**Weighted blended OIT**

- Pros: bounded memory, no explicit order, stable for dense smoke/fire-like coverage.
- Cons: approximate color/depth ordering, tuning sensitivity, incompatibility with some refractive/high-opacity effects.

**DBuffer/deferred decals**

- Pros: integrate with material properties and lighting; efficient for localized damage/grime.
- Cons: screen-coverage/overdraw cost, receiver/order limitations, extra buffers, normal reprojection/history concerns.

**Ribbons/trails**

- Pros: coherent continuous beams, weapon trails, and motion paths with fewer logical particles.
- Cons: ordering, topology construction, tessellation, sharp turns, discontinuities, UV stretching, and motion-vector complexity.

**Pre-fractured destruction**

- Pros: predictable assets, clusters/LOD, robust physics/render mapping.
- Cons: asset/storage cost, many bodies/instances, visible repetition, bursty events, debris lifetime and collision budgets.

## 7. ECS and Render-World Integration

ECS holds effect intent and stable handles:

- `EffectInstanceComponent`: compiled asset handle, parameter block, time state, priority, seed, and execution policy.
- `EffectTransformComponent`: attachment/local/world transform and previous transform.
- `EffectParameterSource`: renderer-neutral bindings to gameplay values.
- `VfxEventEmitter`: bounded typed event records such as impact, damage, fracture, footstep, or weather.
- `DecalInstanceComponent`: material, transform, receiver mask, lifetime/fade, and priority for persistent gameplay-visible decals.
- `DestructionVisualComponent`: source collection/cluster handle, render mapping, debris/particle policy, and generation.

Large particle arrays, GPU counters, sort buffers, ribbon geometry, decal bins, histories, and indirect arguments remain renderer/VFX-service owned.

Render extraction snapshots system transforms, parameters, events, visibility hints, and asset generations. GPU simulations use stable `EffectInstanceId` plus generation; slot reuse is fence-delayed. First-person effects can use a dedicated view layer/near-field policy but must declare depth interaction, lighting, motion, and compositing. Third-person/world effects use normal world visibility. Shared world simulations can render into multiple views, while view-dependent collision, sorting, and ribbons may require per-view work.

## 8. Resource, Pass, Material, and Visibility Interfaces

Core resources:

- compiled effect program/parameter layouts;
- particle attribute heaps and alive/dead/free lists;
- system descriptor, spawn-command, and event buffers;
- collision/depth/SDF/physics query inputs and delayed results;
- visible/survivor indices;
- sort keys/payload and scratch;
- sprite/mesh/ribbon/decal/light instance streams;
- indirect argument/count buffers;
- previous-state and reactive/transparency masks;
- destruction chunk-to-render-instance mapping.

Core pass interfaces:

- `AdmitVfxSpawns(commands, budgets, capacity)`;
- `SimulateParticles(programBins, attributes, events, sceneQueries)`;
- `CullAndCompactParticles(viewOrSharedVisibility, bounds/HZB)`;
- `SortTransparentSubset(keys, payload, count)`;
- `BuildRibbonGeometry(points, ribbonIds, view, tessellationPolicy)`;
- `BuildVfxIndirectArgs(rendererBins, counts)`;
- `RenderVfxDomain(domain, materialBins, indirectArgs)`;
- `ProjectDecals(decalBins, receiverData)`;
- `ConsumeDestructionEvents(fractureEvents, chunkTransforms)`.

Materials declare opaque/masked/additive/alpha/OIT/decal/volume domains, soft-particle depth behavior, lighting mode, shadow policy, motion-vector support, and reactive-mask contribution. Visibility uses fixed/dynamic system bounds, per-renderer bounds, distance/significance, frustum/HZB, screen size, receiver masks, effect budgets, and first-/third-person view layers.

## 9. Asset and Runtime Integration Plan

1. Define effect graph IR, typed attributes, stage restrictions, data-interface contract, and deterministic seed/time semantics.
2. Implement CPU reference execution and sprite/mesh renderers with pooled fixed-capacity storage.
3. Add GPU attribute heaps, batched program dispatch, alive/dead compaction, indirect counts, and overflow telemetry.
4. Integrate scene depth/HZB collision first, then optional SDF and asynchronous ray/physics query adapters with explicit latency.
5. Add GPU radix sorting as a shared service and weighted blended OIT as an opt-in dense-transparency path.
6. Add ribbons/trails with stable IDs, discontinuity markers, adaptive screen-space tessellation, and previous geometry.
7. Add decal rendering with DBuffer/deferred paths, receiver masks, lifetime pooling, screen-size fade, and persistent-decal caps.
8. Connect physics/destruction fracture events and transform generations to mesh debris, dust, sparks, decals, audio hooks, and pooled effect systems.
9. Cook flipbooks, meshes, volume textures, vector fields, graph variants, shaders, and PSOs through DDC and residency systems.
10. Add effect-type budgets, platform variants, fixed/dynamic bounds validation, automatic deactivation, and capture/profiling views.

## 10. Visual and Performance Verification Strategy

Correctness tests:

- CPU/GPU reference comparison for each deterministic module at fixed time steps;
- spawn/death/free-list conservation and buffer-overflow behavior;
- generation poisoning for recycled systems/particles/events;
- compaction count/contents and indirect-argument validation;
- radix-sort comparison against CPU stable sort over zero, small, max, duplicate, reverse, and random keys;
- ribbon topology across spawn/death, cuts, teleport, branching IDs, sharp turns, and camera crossings;
- decal receiver masks, normal blending, overlap order, animated/skinned receivers, and lifetime fade;
- destruction chunk creation/split/remove mappings under delayed/reordered events.

Visual tests:

- dense smoke/fire, sparks, rain, dust, shell casings, magic, beams, weapon trails, impact decals, and large destruction bursts;
- first-person muzzle/weapon effects versus third-person/world versions;
- depth intersections, soft particles, high overdraw, bright emissives, fog/water interaction, motion blur, DOF, exposure, and temporal upscaling;
- camera cuts, teleport, origin rebasing, pause/time dilation, slow motion, and effect hot reload.

Performance tests:

- sweep systems, live particles, spawn bursts, attribute counts, module counts, meshes, ribbon points, decals, lights, sort keys, and destruction chunks;
- record CPU jobs/extraction, general allocations, GPU dispatches/draws, alive/survivor counts, sort passes, indirect bins, overdraw, pixel invocations, barriers, queue overlap, readback latency, and frame pacing;
- record resident/transient VRAM, attribute/sort/ribbon/decal bytes, bandwidth/cache counters, register pressure, occupancy, divergence, upload/streaming, and PSO misses;
- test 1080p/1440p/4K, dynamic resolution, first-/third-person, split screen, low-end/mobile, and constrained VRAM;
- gate p95/p99 effect cost and verify deterministic degradation under simultaneous combat/destruction/weather stress.

## 11. Platform and Scalability Risks

- GPU feature/data-interface support differs across desktop, console, mobile, and VR.
- Large fixed capacities waste VRAM; small capacities overflow during bursts.
- Dynamic bounds or GPU readback can cost CPU/GPU synchronization; incorrect fixed bounds pop effects.
- Transparent pixel overdraw can dominate after simulation and draw calls are optimized.
- Full particle sorting adds multiple buffer passes and scratch; OIT is approximate.
- Decals have platform/pass/receiver limitations and scale with screen coverage.
- Mesh particles/destruction can explode instance, physics-body, shadow, and ray-tracing costs.
- GPU collision against depth misses off-screen geometry; SDF/ray/physics queries differ in cost, coverage, and latency.
- Temporal upscaling, motion blur, and frame generation expose missing motion/reactive data.
- Multi-view sorting and ribbon facing can multiply work even when simulation is shared.
- User-authored graphs can create unbounded attributes, permutations, texture traffic, or divergence without compile-time budgets.

Scalability should control spawn rate, lifetime, maximum live count, update frequency, simulation domain, collision tier, sort/OIT mode, ribbon tessellation, decal count/size, light/shadow contribution, mesh LOD, volume resolution, destruction debris/chunk representation, and distance/significance culling.

## 12. Engineering Recommendations

The following are engineering recommendations:

1. Compile VFX graphs into bounded CPU/GPU programs with explicit stages, attribute layouts, scratch sizes, capabilities, and platform variants.
2. Keep gameplay authority on CPU/fixed-tick systems; treat GPU simulation, collision, events, and readback as latency-bearing visual data.
3. Use global/per-class particle heaps and counter/free-list arenas with deterministic admission, high-water telemetry, and visible overflow policy.
4. Batch compatible systems, compact survivors, generate indirect arguments on GPU, and consolidate tiny material/program bins.
5. Sort only selected high-value transparency; use weighted blended OIT for dense low-to-moderate-opacity effects where approximation is acceptable.
6. Make overdraw, not particle count alone, a first-class budget. Cull by projected coverage, distance, significance, and effect class with hysteresis.
7. Build ribbons from stable IDs and discontinuity metadata with screen-space adaptive tessellation and explicit previous geometry.
8. Use DBuffer/deferred decals according to shading path/platform, cap persistent decals, apply receiver masks, and fade/cull by screen size and age.
9. Translate destruction events into generation-checked render mappings and pooled debris/effects; reduce old/small chunks to instanced visual debris or particles.
10. Require VFX to output motion/reactive/transparency data and declare fog, water, lighting, shadow, ray-tracing, and first-person depth behavior.
11. Integrate graph/resource/PSO cooking, streaming, profiling, and regression tests before expanding the node library.
12. Preserve open decisions: graph IR and type system; CPU/GPU compatibility subset; heap/capacity partitioning; collision/query tiers; sort/OIT policy; ribbon geometry method; decal pass/receiver representation; destruction chunk LOD; transparent lighting/shadows; multi-view sharing; retail telemetry; and platform budgets.

## 13. Source Links

- [Epic Games — Niagara Overview](https://dev.epicgames.com/documentation/en-us/unreal-engine/overview-of-niagara-effects-for-unreal-engine)
- [Epic Games — Niagara API](https://dev.epicgames.com/documentation/en-us/unreal-engine/API/Plugins/Niagara)
- [Epic Games — Niagara Renderer Reference](https://dev.epicgames.com/documentation/unreal-engine/render-module-reference-for-niagara-effects-in-unreal-engine?lang=en-US)
- [Epic Games — Performance Budgeting Using Niagara Effect Types](https://dev.epicgames.com/documentation/en-us/unreal-engine/performance-budgeting-using-effect-types-in-niagara-for-unreal-engine)
- [Epic Games — Niagara System Settings](https://dev.epicgames.com/documentation/en-us/unreal-engine/system-settings-reference-for-niagara-effects-in-unreal-engine)
- [Epic Games — Decal Materials](https://dev.epicgames.com/documentation/en-us/unreal-engine/decal-materials-in-unreal-engine)
- [Epic Games — Chaos Destruction Overview](https://dev.epicgames.com/documentation/unreal-engine/destruction-overview?lang=en-US)
- [AMD GPUOpen — FidelityFX Parallel Sort](https://gpuopen.com/manuals/fidelityfx_sdk/techniques/parallel-sort/)
- [McGuire and Bavoil — Weighted Blended Order-Independent Transparency](https://www.jcgt.org/published/0002/02/09/)
- [NVIDIA — Blast Destruction Library](https://docs.nvidia.com/gameworks/content/gameworkslibrary/blast/blast.htm)
