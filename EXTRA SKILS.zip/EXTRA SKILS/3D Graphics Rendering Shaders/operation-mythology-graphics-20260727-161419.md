# Operation Mythology Graphics Research — Photometric Lights, IES, Cookies, and Emissive Sampling

**Timestamp:** 20260727-161419  
**Scope:** Physical light units, exposure-stable authoring, IES photometric profiles, cookies/gobos, dynamic light functions, analytic area lights, emissive geometry, clustered and stochastic direct-light evaluation, streaming, validation, and scalability.

## 1. Feature Overview

This batch defines a unified authoring/runtime contract for directional, point, spot, rectangular/disk/line area, sky, emissive, and textured/procedural lights. Its purpose is not merely to add more light types; it is to make their energy, distribution, visibility, and cost predictable.

The renderer treats a light as:

```text
emitted quantity × normalized angular/spatial distribution
× distance/geometry term × visibility × material response
```

IES profiles provide measured angular intensity. Cookies/gobos provide authored spatial filtering. Light functions provide bounded dynamic modulation. Analytic area lights expose physical shape. Emissive geometry is converted into sampleable surface emitters or cached GI input. All feed the same renderer-owned light database while preserving distinct sampling PDFs and fallbacks.

The recommended runtime is hybrid:

- clustered/tiled deterministic evaluation for a bounded set of important analytic lights;
- stochastic fixed-budget sampling for dense local/area/emissive sets on capable hardware;
- baked/cached indirect contribution where appropriate;
- explicit fallback ranks rather than unbounded per-light work.

## 2. Existing Coverage and Identified Gap

The required recursive scan found 18 files under `C:\Users\steve\Desktop\GAME SKILLS` and 22 files in the dedicated graphics folder. The newly added file is an audio-engine report and does not overlap graphics lighting. Existing graphics research covers clustered/forward/deferred paths, shadow selection, stochastic many-light visibility, area-light LTC evaluation, baked lighting, GI/reflections, exposure, and ray-scene maintenance.

No existing batch defined:

- canonical physical units by light type and conversion rules;
- exposure-independent light truth versus camera-dependent appearance;
- IES parsing, normalization, orientation, texture cooking, and validation;
- cookie/gobo versus IES versus procedural light-function semantics;
- energy-preserving or artistic modulation modes;
- analytic area light and emissive-mesh sampling records;
- light-function atlas eligibility, update cadence, and cross-view reuse;
- clustered overflow, stochastic sampling, streaming, and authoring diagnostics for these features.

This report fills that gap without repeating the existing shadow, LTC, GI, or exposure architectures.

## 3. Sourced Facts

The following are sourced facts:

- Photometry distinguishes luminous flux in lumens (lm), luminous intensity in candelas (cd = lm/sr), illuminance in lux (lx = lm/m²), and luminance in cd/m².
- Epic's physical-units workflow uses lux for directional-light direct normal illuminance, cd/m² for sky/emissive luminance, and candela or lumens for inverse-square point/spot/rect lights.
- For an isotropic point source, total flux is distributed over `4π` steradians. For a conical distribution, the affected solid angle depends on the cone half-angle. Thus a fixed lumen value and a fixed candela value behave differently when the spot cone changes.
- Physically based inverse-square falloff separates emitted intensity from an artistic finite influence radius; the radius is a culling/truncation policy, not a different physical attenuation law.
- IES LM-63 photometric files describe measured luminaire intensity distribution, including fixture/lamp/lensing effects. Epic imports them as an angular profile representation and can use either the profile's brightness or the light's authored intensity.
- Epic describes IES lookup as significantly cheaper than general light functions. A spot cone can clip angular content present in an IES distribution.
- Epic light functions are material-driven modulation evaluated for dynamic/stationary lights. Its legacy path requires sequential screen-space accumulation/evaluation comparable to shadowed-light passes, with synchronization and cache cost.
- Epic's light-function atlas bakes eligible animated functions into shared 2D tiles on the GPU. The atlas is shared across views and can be consumed by deferred lighting, volumetric fog, GI/reflections, and optionally translucency/water.
- Atlas eligibility excludes arbitrary scene-depth, world-position, and GBuffer reads and constrains texture-coordinate manipulation, illustrating the value of a restricted cacheable light-function language.
- Epic MegaLights is a stochastic direct-light path that traces a fixed number of samples/rays per pixel. Its GPU cost is comparatively bounded while quality decreases as the number/complexity of influential lights grows; light bounds and guiding quality matter.
- ReSTIR and dynamic many-light sampling research demonstrate fixed-sample direct-light selection across very large analytic/emissive light sets using importance selection and spatiotemporal reuse, with temporal validity and bias/variance tradeoffs.

## 4. Industry-Standard Rendering API or Pattern

### Canonical photometric representation

Store source truth in SI-derived units:

- directional: illuminance at a perpendicular receiver, lux;
- point: luminous intensity, candela, or total flux converted to a normalized angular distribution;
- spot/projector: total flux or peak intensity plus normalized cone/profile;
- area surface: luminance/radiance-equivalent engine value derived from cd/m² and emitting area/orientation;
- emissive material: surface luminance/radiance in a documented color space;
- sky/environment: calibrated luminance/radiance scale.

At import/editor time, convert author-facing units into a canonical runtime spectral/color-weighted emission representation. Store the original unit and value for round-tripping and diagnostics. Do not bake exposure, pre-exposure, tone mapping, or camera EV into the light.

### Distribution stack

Compose these independently:

1. geometric emission shape and orientation;
2. normalized analytic cone/area distribution;
3. optional IES angular distribution;
4. optional cookie/gobo spatial texture projection;
5. optional dynamic light-function multiplier;
6. range/bounds fade used for finite rendering cost.

Each modulator declares one of two modes:

- **Energy preserving:** distribution is normalized so changing shape/filter redistributes a specified flux.
- **Artistic multiplier:** authored filter scales output directly and can change total energy.

The mode and normalization integral are asset metadata. This prevents a narrower cookie or IES profile from silently changing brightness in inconsistent ways.

### Runtime light database

Extract all analytic and sampled emissive sources into stable SoA records. Build:

- view-independent source records;
- per-view projected bounds and importance;
- clustered/tiled compact lists for deterministic paths;
- a global/hierarchical importance distribution for stochastic sampling;
- shadow/visibility policy references;
- atlas/profile/bindless texture handles;
- change generations for temporal reservoirs and caches.

The renderer chooses deterministic cluster evaluation, stochastic selection, baked-only, or excluded/fallback per light and platform.

## 5. CPU, GPU, Memory, and Bandwidth Considerations

**CPU complexity.** Dirty extraction is O(changed lights + changed emissive groups). Profile/function/cookie assets are preprocessed off the frame path. Per-view light-bound setup is parallel and SoA. Cluster binning may run CPU-side for small scenes or GPU-side at scale. Avoid per-light heap objects and callbacks; use stable slots and dirty ranges.

**Draw and dispatch counts.** Deferred volume lighting can add a draw per large/exceptional light or batch instanced volumes by PSO/class. Clustered compute builds typically use count, scan, and fill dispatches plus lighting dispatches. Stochastic many-light paths add candidate/guiding, visibility, temporal/spatial reuse, denoise, and composite dispatches. A light-function atlas batches function generation; it must not dispatch once per pixel/light combination.

**GPU complexity.** Deterministic clustered lighting is approximately proportional to pixels × lights in their cluster. Stochastic lighting holds samples per pixel approximately fixed, shifting failure from time growth to variance/denoising as complexity rises. IES/cookie lookups add texture samples. General procedural functions can add arbitrary ALU/texture cost and synchronization unless atlas-cached.

**Allocations.** Preallocate light records, cluster counts/offsets/indices, overflow lists, atlas tiles, IES/cookie handles, emissive primitive records, importance hierarchy, reservoirs, shadow records, and histories. Warm frames allocate nothing. Overflow truncates/merges/demotes using importance with explicit counters rather than growing buffers.

**VRAM residency.** Budget light database, cluster lists, cookie/IES textures, function atlas and animation frames, emissive tables/hierarchies, reservoirs/histories, shadow data, and debug buffers. Texture arrays/atlases require padding/mips; bindless textures require descriptor and mip residency. A grayscale function/IES representation is cheaper than RGB, but colored projection requires separate capacity.

**Memory bandwidth.** Cluster lists and light records should be compact and coherently traversed. Random cookies, IES profiles, emissive triangles, and shadow maps can thrash caches. Sort/bin lights by profile/material where it does not compromise importance. Atlas functions and common IES profiles amortize reads across views/lights. Stochastic histories add read/write bandwidth and should use measured compact formats.

**Cache behavior and divergence.** Per-pixel loops diverge on light type, shadow mode, texture/profile, and receiver material. Use a common parameter layout and small shader classes. Avoid a separate permutation for every IES/cookie combination. Non-uniform bindless sampling remains correct but may serialize/cache-miss; cluster coherence and light-class binning still matter.

**Synchronization.** Atlas generation precedes all lighting/fog/translucency consumers. GPU light-list/importance writes precede shading or ray dispatch. Shadow/RT visibility data precedes light evaluation. Temporal reservoirs consume exact light-generation and transform/material generations. Async compute is useful only when these dependencies and shared bandwidth do not extend the critical path.

**Batching.** Batch profile/cookie uploads, light-function tiles, cluster work, emissive hierarchy rebuilds, and shadow requests. Coarse priority bands preserve stable results while enabling PSO/texture locality. Unique procedural functions, unique samplers, or forced per-light passes are visible authoring costs.

**Streaming.** Cook IES and cookie assets with mips, integral/normalization metadata, orientation, and fallbacks. Stream profiles/functions before promoting the light to full fidelity. Until ready, use analytic distribution or average filter energy. Emissive geometry joins the sample set only after geometry/material/texture generations are resident; cached indirect lighting can remain as an older valid generation.

**Frame latency and concurrency.** A changed light can publish analytic intensity immediately while cookie/function/importance/shadow updates arrive in later generations. Never stall the frame for a profile texture, shadow, or emissive hierarchy. Track edit/event-to-light-record, record-to-cluster, atlas, shadow, and visible-result latency.

## 6. Pros and Cons

**Physical units**

- Pros: measurable authoring; consistent scale/exposure; transferable fixture data; predictable inverse-square behavior.
- Cons: realistic magnitudes expose weak HDR/exposure pipelines; imported tools may disagree; artists still need creative controls.

**IES profiles**

- Pros: compact measured fixture distribution; inexpensive lookup; realistic beam/lobe shape; good manufacturer workflow.
- Cons: file variants/metadata quality; orientation ambiguity; axisymmetric approximations can lose detail; spot cones may clip data; normalization choices affect energy.

**Cookies/gobos**

- Pros: direct art control; colored/projected patterns; simple texture workflow.
- Cons: projection/stretch/mip aliasing; additional texture bandwidth; energy may change; point lights need cube/octahedral representation.

**Procedural light functions**

- Pros: animated caustics, clouds, flicker, patterns, and world effects.
- Cons: arbitrary shader cost; multi-pass/synchronization overhead; hard to batch; scene-dependent functions cannot be atlas cached easily.

**Atlas-cached functions**

- Pros: amortized generation; cross-view reuse; compact lookup; compatible with clustered lighting and volumes.
- Cons: finite slots/resolution; latency/temporal sampling; restricted function language; atlas churn and aliasing.

**Clustered deterministic lights**

- Pros: stable noise-free quality; broad hardware support; straightforward debugging.
- Cons: cost grows with per-cluster light count; overflow; shadow work can remain per light.

**Stochastic many-light/emissive sampling**

- Pros: bounded sample/ray count; handles huge analytic/emissive sets; natural area-light shadows.
- Cons: noise, blur, ghosting, reservoir validity, denoising and ray-scene requirements; quality degrades with local complexity.

## 7. ECS and Render-World Integration

Gameplay/authoring components express intent:

```text
LightComponent {
  type, transform, colorSpecification,
  intensityValue, intensityUnit,
  shape, rangePolicy, mobility,
  profileAsset, cookieAsset, functionAsset,
  shadowPolicy, lightingChannels, importance
}
```

They do not contain cluster indices, GPU descriptors, atlas slots, reservoir state, shadow allocations, or emissive hierarchy nodes.

Extraction produces an immutable canonical `RenderLightRecord`:

- stable light ID/generation;
- transform/shape/bounds;
- linear color and canonical emission;
- normalized distribution parameters/integral;
- IES/cookie/function handles and generations;
- shadow/visibility policy;
- receiver masks;
- first-/third-person relevance and scalability class.

Emissive materials remain mesh/material truth. A renderer service groups eligible emissive triangles/meshlets into sample records linked to stable geometry/material generations. ECS does not spawn one light entity per emissive triangle.

First-person cameras may reserve a small light budget for muzzle flashes, lamps, or weapon emissives and may exclude self-lighting through channel/mask policy. Third-person/world cameras share the global database. Multi-view shares source/function/profile data while building per-view clusters and temporal histories.

## 8. Resource, Pass, Material, and Visibility Interfaces

```text
PhotometricLightDesc {
  lightId, generation, type, shape,
  canonicalEmission, sourceUnit, sourceValue,
  distributionMode, rangePolicy,
  iesHandle, cookieHandle, functionHandle,
  shadowPolicy, receiverMask
}

PhotometricProfile {
  assetId, generation, angularDomain,
  sampleLayout, peakCandela, integratedFlux,
  normalization, orientation, textureHandle
}

LightFunctionRecord {
  shaderClass, atlasEligibility, tileGeneration,
  updateRate, averageMultiplier, colorMode,
  parameterBlock
}

EmissiveSampleGroup {
  geometryGeneration, materialGeneration,
  bounds, primitiveRange, emittedPowerEstimate,
  importanceNode, residency
}
```

Render-graph passes:

1. dirty light/profile/function/emissive uploads;
2. function-atlas tile generation;
3. per-view light bounds and importance;
4. cluster count/scan/fill or tiled bins;
5. emissive/global sampling hierarchy update;
6. shadow/visibility preparation;
7. deterministic or stochastic direct-light evaluation;
8. temporal/spatial reconstruction where required;
9. fog/translucency/water/indirect consumers;
10. debug/telemetry.

Materials consume physically scaled incident lighting; they never know the light's authoring unit. Lighting channels are coarse masks. Profile/cookie/function evaluation occurs in the light domain before the BRDF, while colored transmission/shadowing belongs to visibility/material evaluation.

Visibility ranks lights using conservative bounds, projected contribution, luminance/power, distance, shadow importance, receiver overlap, camera role, and recent selection. Huge bounds reduce cluster and stochastic guiding efficiency and are reported to content authors.

## 9. Asset and Runtime Integration Plan

1. Define canonical units, color-space/temperature policy, conversion/round-trip metadata, and calibrated test scenes.
2. Implement validated inverse-square point/spot/directional/area records and connect them to existing deferred/clustered lighting.
3. Add IES LM-63 importer: robust parse limits, orientation, absolute/relative brightness policy, angular resampling, integral/peak metadata, visualization, and cooked lookup texture.
4. Add cookie import classes for 2D spot/projector and omnidirectional mappings, with alpha/luminance/RGB modes, mip/gutter rules, and energy normalization.
5. Define a restricted light-function intermediate graph. Compile eligible functions to atlas tiles; route scene-dependent or unsupported functions to a bounded legacy/procedural tier.
6. Connect atlas/profile/cookie handles to bindless resource generations and fallbacks.
7. Extend clustered light records and overflow policy; add per-light/profile/function diagnostics.
8. Add emissive sample grouping from cooked mesh/material data and incremental importance hierarchy updates.
9. Integrate the existing stochastic many-light path for dense analytic/emissive sets; preserve deterministic hero-light fallback.
10. Add baked-light/GI invalidation, streaming-cell ownership, device-loss regeneration, and cross-platform feature tiers.

## 10. Visual and Performance Verification Strategy

Photometric fixtures:

- calibrated point source at known distances and perpendicular receivers;
- spot cone sweeps comparing fixed candela versus fixed lumens;
- directional lux and emissive/sky cd/m² under locked manual exposure;
- area shapes with equal luminance, area, flux, and distance variants;
- color temperature/tint and high-intensity HDR/pre-exposure stress.

IES/cookie/function tests:

- asymmetric and symmetric profiles, multiple LM-63 variants, malformed/extreme counts, zero/negative metadata, orientation transforms, narrow peaks, and full-sphere lobes;
- compare cooked angular samples/integral/peak against a CPU reference viewer;
- spot cone clipping, point/rect use, IES intensity versus mask-only mode;
- cookie border/mips, cube seams, grazing projection, animation, normalization, missing/streaming fallback;
- atlas slot overflow, update cadence, cross-view consistency, restricted-node rejection, scene-dependent fallback, fog/translucency/water consumption.

Emissive/many-light tests:

- thousands to millions of emissive triangles with controlled area/power/color;
- moving/deforming emissives, topology/material changes, streaming, and origin rebasing;
- deterministic versus stochastic reference, light selection PDF, visibility, temporal reuse, camera cuts, disocclusion, and rapidly toggled lights;
- first-/third-person and multi-view history isolation.

Performance telemetry:

- CPU extraction, conversion, profile/function compilation/update, bounds, cluster setup, and hierarchy time;
- logical/visible/evaluated lights, cluster indices/overflows, volume draws, lighting/cluster/atlas/stochastic dispatch counts, PSO/texture batches;
- GPU atlas, cluster, deterministic lighting, candidate/guiding, visibility, denoise, fog/translucency, and composite time;
- per-pixel/cluster light count, samples/rays, any-hit/shadow rate, divergence, occupancy, cache misses, overdraw;
- allocations, atlas/profile/cookie/reservoir/hierarchy/shadow VRAM residency, transient high-water;
- light-record/list/profile/cookie/history bandwidth, queue waits/barriers, async overlap and concurrency;
- streaming misses/fallbacks, update/event-to-visible latency, temporal age, and frame-time percentiles.

Acceptance:

- unit/reference fixtures match analytical results within documented tolerance;
- exposure changes alter appearance, not stored light truth;
- IES import is bounded, deterministic, and round-trip traceable;
- no unbounded per-light draw/dispatch/allocation path;
- cluster/atlas/sampler/descriptor overflow degrades deterministically;
- stochastic histories reject changed light/profile/function generations;
- missing assets use declared average/analytic fallback without NaNs or black flashes;
- first-/third-person budgets and output remain independently measurable.

## 11. Platform and Scalability Risks

- Photometric unit support across DCC, glTF, fixtures, and engine importers is inconsistent; preserve source metadata and show conversion diagnostics.
- Realistic intensities require correct HDR, pre-exposure, auto/manual exposure, tone mapping, and sufficient buffer precision.
- IES files can be malformed, huge, asymmetric, relative, or oriented unexpectedly. Never trust unbounded counts or assume a 1D axisymmetric profile.
- Narrow IES/cookie peaks alias without sufficient angular/spatial resolution and mip strategy.
- Colored cookies/functions multiply texture bandwidth and may violate an artist's intended total flux.
- Light-function atlas slots/resolution/update frequency are finite; unique material instances can create unique tiles.
- Forward/mobile paths may not support arbitrary light functions, many textures, area shapes, or stochastic ray visibility.
- Cluster overflow causes missing or reordered lights unless explicitly handled; oversized bounds harm both deterministic and guided stochastic paths.
- Emissive geometry with tiny bright triangles produces high variance and unstable power estimates.
- Alpha-tested/transmissive shadowing complicates stochastic visibility and can dominate RT cost.
- Temporal reuse can ghost after light/profile/function/emissive changes if generation tracking is incomplete.
- Area lights evaluated with approximate LTC/raster shadows differ from stochastic ray-traced reference.
- Physical correctness does not guarantee desired art direction; creative exposure, grading, and explicitly labeled multipliers remain necessary.

Scalability knobs include maximum deterministic lights per cluster, overflow tier, stochastic samples, visibility method, shadow rank, IES/cookie resolution and color, light-function atlas size/tile/update rate, emissive subdivision/grouping, temporal reuse, fog/translucency support, and per-camera importance.

## 12. Engineering Recommendations

These are engineering recommendations:

1. Store light truth in canonical physical units and linear color independent of exposure. Preserve original unit/value and conversion provenance.
2. Separate source shape, normalized analytic distribution, IES, cookie, dynamic function, and finite range. Do not collapse them into one ambiguous “intensity texture.”
3. Require each profile/filter to declare energy-preserving normalization or artistic multiplication and expose its integral/average in tooling.
4. Parse and cook IES offline with strict validation, orientation metadata, angular lookup data, peak/integrated values, and CPU-reference tests.
5. Use IES for measured angular distribution, cookies/gobos for authored projection, and restricted atlas-cacheable functions for animation. Reserve unrestricted scene-dependent functions for a bounded exceptional tier.
6. Maintain one stable light database feeding deterministic clustered and stochastic many-light paths. Selection changes the evaluation strategy, not the authored light.
7. Enforce cluster/list/atlas/profile/sampler capacities with importance-ranked overflow and visible diagnostics. Report oversized bounds and unique-function costs to authors.
8. Generate emissive sample groups from renderer geometry/material generations, not ECS light entities. Use power/area-aware hierarchical selection and explicit streaming validity.
9. Reuse existing shadow/ray-scene infrastructure. Prefer deterministic hero lights and fixed-budget stochastic dense lights, with platform fallbacks.
10. Track light/profile/cookie/function/emissive generations through temporal reservoirs, GI, fog, translucency, and captures.
11. Calibrate first-/third-person examples under locked exposure and provide physical reference presets without forbidding labeled creative multipliers.
12. Keep open decisions explicit: canonical spectral/RGB convention; unit defaults; IES variants/orientation/normalization; cookie mappings; function graph/atlas capacity; area-light flux convention; emissive grouping/PDF; deterministic/stochastic threshold; cluster overflow; bounds policy; and per-platform CPU/GPU/draw/dispatch/VRAM/bandwidth/latency/concurrency budgets.

## 13. Source Links

- [Epic Games: Physical Lighting Units](https://dev.epicgames.com/documentation/en-us/unreal-engine/using-physical-lighting-units-in-unreal-engine)
- [Epic Games: IES Light Profiles](https://dev.epicgames.com/documentation/unreal-engine/using-ies-light-profiles-in-unreal-engine)
- [Epic Games: Light Functions and Light Function Atlas](https://dev.epicgames.com/documentation/en-us/unreal-engine/using-light-functions-in-unreal-engine)
- [Epic Games: Point Light profiles and functions](https://dev.epicgames.com/documentation/unreal-engine/point-lights-in-unreal-engine)
- [Epic Games: MegaLights](https://dev.epicgames.com/documentation/en-us/unreal-engine/megalights-in-unreal-engine)
- [Epic Games: Unreal Engine 5.8 MegaLights updates](https://dev.epicgames.com/documentation/unreal-engine/unreal-engine-5-8-release-notes)
- [Khronos glTF: KHR_lights_punctual](https://github.com/KhronosGroup/glTF/tree/main/extensions/2.0/Khronos/KHR_lights_punctual)
- [Illuminating Engineering Society: LM-63 photometric data format](https://www.ies.org/standards/definitions/ies-standard-file-format-for-electronic-transfer-of-photometric-data-and-related-information/)
- [Bitterli et al.: ReSTIR](https://research.nvidia.com/labs/rtr/publication/bitterli2020spatiotemporal/)
- [Moreau et al.: Dynamic Many-Light Sampling for Real-Time Ray Tracing](https://research.nvidia.com/publication/2019-07_dynamic-many-light-sampling-real-time-ray-tracing)
