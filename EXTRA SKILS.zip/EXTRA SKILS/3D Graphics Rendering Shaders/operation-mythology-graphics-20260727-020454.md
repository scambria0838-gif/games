# Operation Mythology Graphics Research — Exposure, Tone Mapping, HDR Output, and Color Management

**Timestamp:** 20260727-020454  
**Scope:** Camera exposure, scene-referred color, tone mapping, wide-gamut/HDR presentation, first-/third-person camera consistency, render-world integration, and performance/scalability.  
**Assumptions:** Modular data-oriented engine; explicit simulation-to-render-world extraction; D3D12 and Vulkan-class explicit APIs; physically based lighting; no production-code implementation in this report.

## 1. Feature Overview

This batch defines a single color-and-exposure contract from physically based lighting through display presentation. The pipeline needs to preserve scene-referred HDR values through lighting and transparent composition, derive a stable camera exposure, apply artistic grading in a defined working space, map the result through one versioned output transform, and present it through an SDR or HDR swap chain with the correct color-space declaration.

The feature is not merely a post-process effect. Exposure changes temporal-history interpretation, bloom thresholds, translucency appearance, UI composition, capture output, and camera cuts. The output transform affects every authored light and material. First- and third-person cameras therefore require explicit per-view exposure state rather than relying on an implicit global value.

## 2. Existing Coverage and Identified Gap

The recursive scan of `C:\Users\steve\Desktop\GAME SKILLS` and the dedicated `EXTRA SKILS` graphics folder found coverage for render graphs, GPU-driven rendering, memory, temporal reconstruction, GI/reflections, shadows, shader/PSO management, and asset cooking. The existing temporal research discusses history ownership, but it does not establish a complete scene-to-display color contract.

The uncovered decision was how Operation Mythology should:

- define scene-linear units and the rendering working gamut;
- meter and temporally adapt exposure without camera-cut or bright-VFX pumping;
- separate exposure, creative grading, and display rendering;
- support SDR, scRGB/FP16 HDR, and HDR10/PQ output;
- compose UI and captures consistently across first- and third-person views;
- validate display capability changes and prevent silent gamut/range clipping.

This report fills that gap. It does not repeat the already-covered temporal AA/upscaling architecture except where exposure metadata must be supplied to temporal consumers.

## 3. Sourced Facts

The following are sourced facts, not project-specific recommendations:

- Unreal Engine 5.8 documents Histogram, Basic, and Manual exposure modes. Histogram uses a 64-bin luminance histogram; Histogram and Basic modes treat the selected average scene luminance as middle gray. It also documents EV100-based manual exposure and the relationship `B = Exposure × L` between pre-tonemap pixel brightness and scene luminance.
- Unreal documents an exposure metering mask and recommends center-weighted influence as a way to reduce abrupt adaptation caused by bright objects entering the frame. Its adaptation traverses exposure in f-stops per second and combines linear and exponential movement.
- Unreal's pre-exposure applies the previous frame's exposure inside shaders before writing scene color. Epic states that this remaps scene color around the camera exposure, reduces overflow risk in limited-precision scene-color formats, and can improve Basic auto-exposure quality.
- Epic documents Local Exposure as a local adjustment intended to preserve highlights and shadow detail when a single global exposure is insufficient.
- Microsoft documents two principal Windows Advanced Color presentation paths: FP16/scRGB and 10-bit HDR10 using BT.2100/PQ. For an HDR10 swap chain, the application declares the appropriate color space with `IDXGISwapChain3::SetColorSpace1`.
- Microsoft now cautions against depending on explicit `SetHDRMetaData` metadata delivery because the OS does not guarantee that metadata reaches the monitor and display behavior is inconsistent. It recommends tone mapping content to the display luminance range reported through the output description.
- Microsoft's D3D12 HDR sample demonstrates runtime display-capability detection and rendering/presentation with 8-bit, 10-bit, and 16-bit formats.
- ACES 2 output transforms operate through a perceptual color-correlate representation and combine tone scaling, appearance handling, and gamut compression so that multiple output targets can be matched through a controlled transform.
- AMD's FidelityFX Luminance Preserving Mapper is an HDR/wide-color-gamut tone-and-gamut mapper designed to preserve luminance relationships while mapping into the target output.
- Vulkan exposes extended swap-chain color spaces through `VK_EXT_swapchain_colorspace` and HDR display metadata through `VK_EXT_hdr_metadata`; support remains dependent on the surface, platform, and display path.

## 4. Industry-Standard Rendering API or Pattern

The common pattern is a scene-referred pipeline followed by an output-referred transform:

1. Lighting produces linear HDR scene color in a declared working gamut.
2. A luminance reduction or histogram pass measures the metering region.
3. A small adaptation pass updates persistent per-view exposure state.
4. Scene effects that require physical intensity operate before tone mapping.
5. Creative color grading is applied at a documented point in the pipeline.
6. A single output transform performs tone scale, gamut mapping, and output encoding for the selected display mode.
7. Display-referred UI is composited according to an explicit paper-white policy.
8. The swap chain is created with a compatible format and color space, then revalidated when the window changes output or display capabilities change.

A practical render-graph shape is:

`HDR scene color → luminance histogram/reduction → exposure adaptation → bloom/local exposure → grade + output transform → UI composite → present`

Pre-exposure adds a per-view scalar to scene rendering and requires downstream effects to know whether their inputs are pre-exposed. History buffers either store the exposure associated with their samples or are rescaled into the current exposure domain before reuse.

## 5. CPU, GPU, Memory, and Bandwidth Considerations

**CPU complexity and allocations.** Display enumeration, capability changes, camera-cut flags, mode selection, and constant-buffer updates are low-frequency work. Cache display descriptors and rebuild presentation resources only on an actual mode/output change. Avoid per-frame heap allocation by keeping fixed per-view exposure records and pooled histogram/readback storage.

**GPU complexity and dispatch counts.** A histogram implementation normally adds one luminance/histogram dispatch and one small reduction/adaptation dispatch per independently metered view. Tone mapping should remain one fullscreen compute dispatch or draw; local exposure can add downsample/filter/apply passes. Split-screen, mirrors, scopes, and scene captures multiply those costs unless views explicitly share exposure.

**Draw and batching behavior.** The core output transform is a single fullscreen operation. Fold compatible grade, tone/gamut mapping, vignette, grain, and output encoding into one pass when this does not create unbounded shader permutations. Composite display-referred UI in a deliberate pass rather than accidentally inheriting scene exposure.

**VRAM residency and allocations.** Persistent state is small: histogram bins, a few exposure scalars, LUTs, and per-view history metadata. The dominant cost is HDR scene/intermediate buffers. A 3840×2160 RGBA16F surface is approximately 63.3 MiB before alignment; every unnecessary full-resolution intermediate therefore materially affects VRAM. Aliasing transient post-process resources through the render graph is important.

**Memory bandwidth and cache behavior.** A fullscreen read/write of large HDR targets is bandwidth-heavy even when arithmetic is cheap. Prefer tiled compute, coherent image traversal, combined post stages, half/quarter-resolution bloom and local-exposure pyramids, and transient aliasing. Histograms should accumulate in group-shared memory and merge compact partial bins to reduce global atomics and cache contention.

**Shader divergence.** Avoid per-pixel branching between SDR and HDR output modes. Select an output-transform pipeline variant or specialized constants at the pass level. Local exposure and gamut compression should use branch-light math or coherent masks.

**Synchronization and concurrency.** Schedule luminance extraction as soon as its scene-color input is ready and overlap independent compute when the platform's queues and resource ownership make that profitable. The final output transform must wait for all scene-referred contributors. Keep barriers at resource-state transitions; do not force CPU readback of average luminance in the normal path.

**Streaming and latency.** Color LUTs and output-transform data are tiny and should be resident before a camera becomes active. Exposure adaptation intentionally adds temporal latency; camera cuts, respawns, photo mode, and view switching need explicit reset or initialization. Display-mode switches may incur swap-chain latency and should not occur mid-frame.

## 6. Pros and Cons

**Histogram exposure**

- Pros: robust percentile selection, rejects extreme tails, supports weighted metering.
- Cons: extra dispatch/atomics, bin-range tuning, can pump when emissive VFX dominate.

**Basic/log-average exposure**

- Pros: cheaper and simpler; useful on constrained hardware.
- Cons: more sensitive to outliers and less controllable than a histogram.

**Pre-exposure**

- Pros: keeps scene values nearer a useful numeric range and stabilizes limited-precision buffers.
- Cons: every producer, temporal history, debug view, capture, and blend path must obey the exposure-domain contract.

**scRGB/FP16 HDR presentation**

- Pros: linear, broad-range path with simpler shader encoding and good Windows compositor integration.
- Cons: higher swap-chain bandwidth/storage and platform-specific presentation behavior.

**HDR10/PQ 10-bit presentation**

- Pros: compact 10-bit presentation and direct standardized HDR signal path.
- Cons: explicit nonlinear encoding, tighter precision, target-display mapping, color-space negotiation, and unreliable dependence on static metadata.

**Unified ACES-style output transform**

- Pros: controlled tone and gamut behavior across targets; protects hue and high-saturation highlights better than independent RGB curves.
- Cons: requires careful versioning, look development, validation, and migration when the transform changes.

## 7. ECS and Render-World Integration

Simulation/world ECS components should contain only authoring intent:

- `CameraExposureSettings`: mode, compensation, histogram percentiles, EV bounds, adaptation speeds, metering-mask asset, and optional lock.
- `CameraColorSettings`: grading profile, look intensity, local-exposure tier, and output preference.
- `CameraCutState`: cut/teleport/activation epoch used to invalidate or seed temporal state.

Render-world extraction should create immutable per-frame `RenderViewColorState` records containing resolved matrices, physical camera parameters, view rectangle, pre-exposure/current exposure, previous exposure, metering parameters, output-transform ID, display target, and history epoch.

Persistent exposure state belongs to a render-view history owner keyed by stable camera/view identity—not to a process-global singleton. A first-person weapon view may share the main view's exposure while retaining its own depth/projection. A third-person camera transition may preserve exposure if it is continuous, but a hard camera cut should seed or reset adaptation by policy. Reflection probes, minimaps, thumbnails, and offline captures must declare `shared`, `independent`, or `fixed` exposure.

## 8. Resource, Pass, Material, and Visibility Interfaces

Minimum resource interfaces:

- `SceneColorHDR`: declared working gamut, linear encoding, and exposure-domain tag.
- `LuminanceHistogram`: fixed-bin transient UAV plus compact partial buffers.
- `ExposureHistory`: persistent per-view current/previous EV or scale and validity epoch.
- `ColorGradeLUT`: immutable/versioned asset with working-space metadata.
- `DisplayProfile`: output color space, primaries, transfer function, paper white, peak/min luminance, and capability generation.
- `OutputSurface`: format/color-space pair validated against the active presentation surface.

Minimum pass contracts:

- `BuildLuminanceDistribution(SceneColorHDR, MeteringMask)`.
- `AdaptExposure(Histogram, PreviousExposure, DeltaTime, CutState)`.
- `ApplyLocalExposure` as an optional scalable branch.
- `ApplyOutputTransform(SceneColorHDR, Exposure, Grade, DisplayProfile)`.
- `CompositeUI(DisplayReferredColor, UIPaperWhitePolicy)`.

Materials emit scene-linear radiance or reflectance-derived results and must not embed display tone curves. Emissive assets need documented physical/reference-nit authoring guidance and a flag or channel policy if they should be excluded or downweighted in metering. Visibility interfaces must provide per-view masks so hidden first-person meshes, scope-only layers, and bright VFX influence only the views in which they are actually visible.

## 9. Asset and Runtime Integration Plan

1. Define and version the renderer working gamut, linear scene-color representation, luminance convention, and pre-exposure domain in an engine color specification.
2. Add import validation for LUT dimensions, gamut, shaper, encoding, and intended output-transform version. Reject untagged color assets where ambiguity affects correctness.
3. Implement Manual and Basic exposure first as reference paths, then the weighted histogram path and optional Local Exposure tier.
4. Add stable render-view identities, exposure-history ownership, camera-cut epochs, and exposure sharing policies for first-person, third-person, captures, mirrors, and scopes.
5. Implement an SDR reference output transform, then FP16/scRGB HDR and HDR10/PQ backends selected by queried platform/display support.
6. Centralize swap-chain format, color-space declaration, paper white, output luminance, and display-change handling in the presentation subsystem.
7. Version creative looks separately from the output transform so art changes do not silently redefine display rendering.
8. Bake shader/pipeline variants and LUT assets through the existing content-addressed derived-data and PSO systems.
9. Add deterministic capture modes: fixed exposure, fixed display profile, disabled adaptation, and explicit transform version.

## 10. Visual and Performance Verification Strategy

Build a controlled chart scene containing calibrated gray, black-to-superwhite ramps, saturated primaries/secondaries, skin-like reflectances, specular highlights, emissives, fog, translucency, particles, and UI reference patches.

Visual tests:

- Verify middle-gray placement and EV response under known illuminance.
- Compare first- and third-person camera transitions, cuts, respawns, indoor/outdoor traversal, and bright VFX crossing the metering mask.
- Check hue trajectory and saturation through highlight compression; detect clipping, negative values, NaNs, banding, and gamut excursions.
- Capture SDR, scRGB, and HDR10 outputs from the same scene and compare against approved reference transforms on real displays and reference scopes.
- Test hot-plug, window movement between displays, fullscreen/windowed changes, SDR desktop operation, OS HDR toggles, and unsupported HDR fallback.
- Validate UI paper white, screenshots, photo mode, streaming/video capture, and debug views independently of scene exposure.

Performance tests:

- Record per-view histogram/reduction/output-transform GPU time, dispatches, fullscreen draws, barriers, transient peak memory, bytes read/written, and async overlap.
- Measure at 1080p, 1440p, 4K, dynamic resolution, split screen, mirrors/scopes, and representative first-/third-person scenes.
- Track percentile frame times and frame pacing, not only averages; flag presentation-mode switches and shader/PSO misses.
- Add automated regression gates for peak transient VRAM, full-resolution post-process pass count, bandwidth estimates, histogram atomic pressure, and camera-cut recovery frames.

## 11. Platform and Scalability Risks

- HDR capability, compositor behavior, supported formats/color spaces, and reported luminance vary by OS, GPU driver, output, and display.
- Display peak-luminance reports may be absent or inaccurate. Static metadata is not a reliable substitute for robust runtime tone mapping and user calibration.
- FP16 presentation increases bandwidth; HDR10 reduces storage but adds PQ encoding, quantization, and gamut-mapping sensitivity.
- Histogram atomics and local-exposure filters may be disproportionately expensive on tile-based or low-end GPUs.
- A pre-exposure mismatch can cause temporal trails, bloom discontinuities, translucency errors, or debug/capture inconsistency.
- Multiple active views can multiply histogram, post-processing, and history costs.
- Poorly constrained emissive particles, muzzle flashes, portals, or sky pixels can destabilize exposure.
- Tone-transform changes invalidate visual baselines and may require material/light/look re-approval.
- HDR screenshots and video paths may silently downconvert or clip unless their metadata and transform are explicit.

Scalability should offer: fixed/manual exposure; Basic exposure; histogram exposure; histogram plus local exposure; reduced histogram resolution/binning; reduced LUT precision where validated; SDR-only output on unsupported paths; and independently selectable HDR presentation backends.

## 12. Engineering Recommendations

The following are engineering recommendations derived from the facts and constraints above:

1. Adopt one versioned, scene-referred color contract and make exposure-domain metadata mandatory on scene-color and temporal-history resources.
2. Use weighted histogram auto exposure as the default quality path, Basic exposure as a constrained fallback, and Manual/fixed exposure as the deterministic validation path.
3. Store exposure per stable render view. Explicitly share the main camera's exposure with first-person weapon rendering unless art direction proves a separate domain is necessary.
4. Implement pre-exposure only with a renderer-wide audit of particles, translucency, bloom, history reprojection, captures, and debug passes; never treat it as a local post-process toggle.
5. Separate physical exposure, creative grading, and the display output transform into distinct versioned stages.
6. Choose output transforms by display profile/pass-level pipeline selection, avoiding divergent SDR/HDR branches per pixel.
7. Support SDR first as the visual reference, then FP16/scRGB HDR as the preferred Windows HDR path where practical, with HDR10/PQ as an explicitly validated platform path.
8. Tone map to queried/calibrated display capability and provide user calibration; do not make correctness depend on HDR static metadata reaching the panel.
9. Fuse compatible full-resolution post operations, keep local exposure scalable, and require render-graph transient aliasing to control 4K VRAM and bandwidth.
10. Make camera cuts, view activation, display changes, and transform-version changes explicit history epochs with tested reset behavior.
11. Ship exposure, gamut, clipping, display-mode, pass-time, bandwidth, transient-memory, and PSO telemetry in graphics diagnostics.
12. Keep open decisions recorded: working gamut; scene-color format; histogram bin/range/percentiles; adaptation policy; pre-exposure adoption; local-exposure algorithm; paper white/default peak; scRGB versus HDR10 platform matrix; UI composition space; and capture encoding.

## 13. Source Links

- [Epic Games — Auto Exposure in Unreal Engine 5.8](https://dev.epicgames.com/documentation/unreal-engine/auto-exposure-in-unreal-engine?lang=en-US)
- [Epic Games — Color Grading and the Filmic Tonemapper](https://dev.epicgames.com/documentation/en-us/unreal-engine/color-grading-and-the-filmic-tonemapper-in-unreal-engine)
- [Epic Games — Physical Lighting Units](https://dev.epicgames.com/documentation/unreal-engine/using-physical-lighting-units-in-unreal-engine?lang=en-US)
- [Microsoft — High dynamic range and wide color gamut](https://learn.microsoft.com/en-us/windows/win32/direct3darticles/high-dynamic-range)
- [Microsoft — IDXGISwapChain4::SetHDRMetaData](https://learn.microsoft.com/en-us/windows/win32/api/dxgi1_5/nf-dxgi1_5-idxgiswapchain4-sethdrmetadata)
- [Microsoft — D3D12 HDR sample](https://learn.microsoft.com/en-us/samples/microsoft/directx-graphics-samples/d3d12-hdr-sample-win32/)
- [Academy Color Encoding System — Output Transforms](https://docs.acescentral.com/system-components/output-transforms/)
- [AMD GPUOpen — FidelityFX Luminance Preserving Mapper](https://gpuopen.com/manuals/fidelityfx_sdk/samples/luminance-preserving-mapper/)
- [Khronos — VK_EXT_swapchain_colorspace](https://registry.khronos.org/vulkan/specs/latest/man/html/VK_EXT_swapchain_colorspace.html)
- [Khronos — VK_EXT_hdr_metadata](https://registry.khronos.org/vulkan/specs/latest/man/html/VK_EXT_hdr_metadata.html)
