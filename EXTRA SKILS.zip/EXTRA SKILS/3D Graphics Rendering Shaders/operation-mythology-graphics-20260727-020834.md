# Operation Mythology Graphics Research — Renderer Profiling, Frame Pacing, and Regression Gates

**Timestamp:** 20260727-020834  
**Scope:** Low-overhead runtime telemetry, CPU/GPU correlation, presentation pacing, vendor deep profiling, automated performance captures, and regression policy.  
**Assumptions:** Modular data-oriented engine; explicit render-world extraction; D3D12/Vulkan-class APIs; first- and third-person cameras; no production-code implementation.

## 1. Feature Overview

Operation Mythology needs a renderer observability system that can answer three different questions without confusing them:

1. Did the player receive evenly paced frames at the target latency?
2. Which engine work, queue dependency, allocation, upload, draw, dispatch, or present interval caused a regression?
3. Which shader/hardware resource—ALU, texture, bandwidth, cache, registers, occupancy, raster, ray traversal, or synchronization—limits the selected workload?

These require layered measurements. Always-on counters and timestamp queries provide trend and regression data. Event traces correlate CPU jobs, render-graph passes, GPU queues, streaming, memory, and presentation. Vendor profilers supply architecture-specific counters for selected captures. External presentation telemetry verifies what reached the display rather than assuming `Present` equals display.

## 2. Existing Coverage and Identified Gap

The recursive scan of `GAME SKILLS` and the dedicated graphics folder found detailed work on render graphs, transient aliasing, GPU-driven submission, shading architecture, memory residency, temporal rendering, GI, shadows, PSOs, asset cooking, and color output. Those reports recommend telemetry, but none defines a unified instrumentation schema, frame-pacing measurement model, capture workflow, or automated regression gates.

This batch fills that architectural gap. It does not repeat individual feature optimizations. It defines how their CPU, GPU, memory, bandwidth, synchronization, streaming, latency, and concurrency costs should be observed and compared.

## 3. Sourced Facts

The following are sourced facts:

- Microsoft PIX Timing Captures correlate CPU threads/cores, API queues, GPU work, file I/O, allocations, title markers, and title-defined counters. Microsoft states that these captures are designed for running-game analysis with minimal overhead and can cover long durations.
- PIX GPU Captures replay D3D12 work and expose events, timings, pipeline state, resources, shader debugging, and hardware counters. Microsoft cautions that GPU captures are not generally portable across GPU/driver versions.
- PIX distinguishes execution duration from end-of-pipe duration because adjacent GPU operations can overlap. It also cautions that GPU Capture timing does not reproduce cross-queue overlap; Timing Captures are the appropriate view for async-compute overlap.
- D3D12 timestamp queries return queue ticks. Microsoft requires resolving them, dividing by the command queue frequency using floating-point arithmetic, and using the copy-queue-specific timestamp heap only when supported.
- NVIDIA Nsight Graphics GPU Trace measures live GPU-unit utilization, queue synchronization, occupancy/throughput, work submissions, and underutilization. NVIDIA recommends controlled capture conditions and locked clocks for comparable runs.
- AMD Radeon GPU Profiler supports D3D12 and Vulkan on RDNA hardware and visualizes queue synchronization, fences/semaphores, asynchronous compute, barrier timings, event timing, pipelines, instruction timing, and wavefront occupancy.
- AMD explains that theoretical occupancy is only an upper bound: measured occupancy can be limited by too little work, launch rate, barriers, register/LDS pressure, or workload tails. High occupancy alone therefore does not prove good performance.
- Intel's open-source PresentMon captures CPU, GPU, and display frame durations and latencies across graphics APIs. Its documentation records measurement caveats for Vulkan/OpenGL process instrumentation and Hardware-Accelerated GPU Scheduling.
- Vulkan calibrated timestamps correlate device timestamps with another time domain and report maximum deviation; base Vulkan timestamps alone do not establish wall-clock correlation.

## 4. Industry-Standard Rendering API or Pattern

Use a four-layer instrumentation pattern:

1. **Always-on frame ledger:** one fixed-size record per frame/view containing CPU begin/end, simulation-to-render latency, render submission, GPU frame interval, present request, display interval when available, dynamic resolution, quality tier, camera mode, and anomaly flags.
2. **Hierarchical CPU/GPU zones:** stable IDs for frame phases, ECS extraction, render-graph passes, queue batches, streaming jobs, and presentation. Emit API-compatible PIX/debug labels from the same registry.
3. **Asynchronous query pools:** per-queue timestamp ranges and pipeline-statistics samples resolved several frames later without blocking the CPU.
4. **Triggered deep capture:** preserve a rolling pre-trigger window, detect a hitch/budget violation, then capture surrounding telemetry and optionally request a PIX/vendor trace in development builds.

Frame time must be treated as a timeline:

`input/sample → simulation → extraction → command recording → queue submit → GPU execution → present → display`

Separate CPU frame time, GPU critical-path time, present-to-present time, display-to-display time, and end-to-end latency. A single “FPS” number cannot diagnose pacing or queued latency.

## 5. CPU, GPU, Memory, and Bandwidth Considerations

**CPU complexity.** Markers and counters must be O(events) with bounded constant work. Use numeric IDs, thread-local append buffers, and deferred symbolization. Avoid formatting strings, locks, and stack capture in retail telemetry. Track render-thread wait, job starvation, command-list recording time, submit time, present blocking, and frames queued.

**GPU complexity.** Timestamp writes are lightweight but not free; query every major pass in profiling builds and sample/coarsen in retail. Measure the critical path across graphics, compute, and copy queues rather than summing overlapping durations. Record draw/dispatch/indirect-execute counts and workload dimensions beside time so a cost change can be attributed to quantity or per-unit expense.

**Allocations and VRAM.** Record committed/resident bytes, transient peak, aliasing efficiency, heap fragmentation, allocation/eviction counts, and per-feature residency. Telemetry buffers must be preallocated rings with explicit caps. Deep captures can be large and belong outside the frame-critical storage path.

**Bandwidth and cache behavior.** Hardware counters are vendor-specific; normalize only concepts, never raw counter values. Correlate bytes read/written, compression, cache hit/miss behavior, render-target traffic, sampler traffic, and copy/upload volume with the exact pass and resolution. A fullscreen pass regression may be bandwidth rather than arithmetic.

**Shader divergence and occupancy.** Store shader/pipeline hashes with pass samples. Inspect wave/warp divergence, instruction mix, register pressure, LDS/shared-memory use, achieved occupancy, and stall reasons in vendor captures. Do not use occupancy as a universal score.

**Synchronization and concurrency.** Log barriers by type/resource, queue signals/waits, ownership transfers, and GPU bubbles. Compute queue-overlap percentage and critical-path contribution. Compare event traces, not replay-only timings, when async concurrency matters.

**Batching and streaming.** Track submitted/visible/culled instances, draw merging, material/PSO switches, indirect buffer occupancy, upload bytes, I/O latency, decompression time, copy-queue utilization, residency misses, and fallback-LOD events.

**Frame latency.** Record frames in flight, input/sample timestamp when possible, queue-submit delay, render completion, present mode, missed refresh deadlines, displayed-frame interval, dropped/discarded presents, and frame-generation classification where applicable.

## 6. Pros and Cons

**Always-on lightweight telemetry**

- Pros: catches intermittent hitches and supports field distributions.
- Cons: constrained detail; careless markers can add CPU, memory, and privacy cost.

**In-engine GPU timestamps**

- Pros: stable pass ownership, automatable, cross-vendor, available in CI.
- Cons: delayed results, limited architectural diagnosis, multi-queue correlation complexity.

**API/frame captures**

- Pros: resources, commands, shaders, and exact frame reconstruction.
- Cons: intrusive, large, driver/hardware sensitive, and replay timing can distort concurrency.

**Vendor hardware profilers**

- Pros: deepest cache, occupancy, stall, divergence, and unit-utilization evidence.
- Cons: vendor/architecture-specific metrics and controlled capture requirements.

**External presentation tracing**

- Pros: measures delivered pacing and latency outside engine assumptions.
- Cons: OS-mode caveats, incomplete causal engine context, and occasional metric limitations.

## 7. ECS and Render-World Integration

Simulation ECS should publish compact workload facts during extraction: visible entity counts, animated/skinned counts, lights, decals, particles, active cameras, and streaming transitions. The render world adds extracted-instance counts, culling results, LOD distribution, material/mesh bins, and per-view feature flags.

Use stable `FrameId`, `ViewId`, `RenderPassId`, `QueueBatchId`, `ResourceId`, `PipelineKey`, and `CaptureScenarioId` values. The IDs must survive asynchronous job execution and delayed GPU query resolution. First- and third-person views should be tagged independently so their culling, skinning, shadow, VFX, and post-process costs can be compared while still attributing shared work once.

Instrumentation is observational: profiling components must not become simulation authority. Extraction copies counters into the render-frame ledger; the telemetry consumer reads completed ledgers after fences establish validity.

## 8. Resource, Pass, Material, and Visibility Interfaces

Required interfaces:

- `ProfilerZoneRegistry`: stable names, categories, colors, and source ownership.
- `GpuQueryPool[QueueType]`: frame-ring allocation, begin/end indices, resolve range, frequency/calibration metadata, and validity.
- `FrameLedger`: CPU/GPU/present timings, quality state, counts, memory, streaming, and anomaly flags.
- `RenderPassTelemetry`: pass ID, queue, view mask, pipeline hashes, draws, dispatches, triangles/meshlets/rays, bytes, barriers, and timestamp range.
- `ResourceTelemetry`: format, dimensions, committed/transient/resident bytes, lifetime, alias group, and per-frame traffic estimates.
- `VisibilityTelemetry`: candidates, frustum/occlusion/LOD rejects, surviving instances, and indirect command counts.
- `CaptureController`: ring-buffer policy, trigger reason, scenario metadata, and external-tool hooks.

Materials and PSOs need stable content hashes in telemetry, not verbose names alone. Visibility and indirect buffers need capacity/high-water/overflow counters. Every pass should expose its logical work count and output resolution so timing remains interpretable under dynamic resolution and scalability.

## 9. Asset and Runtime Integration Plan

1. Establish the stable ID registry and a versioned telemetry schema.
2. Add fixed-size per-thread CPU event rings and per-queue GPU query rings.
3. Instrument frame, extraction, render-graph pass, queue-submit, streaming, allocation, and present boundaries.
4. Resolve GPU queries asynchronously after the owning fence; never wait in the measured frame.
5. Add JSON/binary capture export with build, map, scenario, settings, GPU, driver, display mode, and commit metadata.
6. Emit PIX-compatible markers and retain compatible Vulkan debug labels from the same zones.
7. Integrate scripted PresentMon/PIX/RGP/Nsight capture workflows for controlled performance labs.
8. Build deterministic benchmark rails and representative gameplay captures for first- and third-person cameras.
9. Add a rolling hitch recorder and budget-triggered dump in development/profile builds.
10. Feed derived distributions and comparisons into CI without uploading raw captures unless a gate fails.

## 10. Visual and Performance Verification Strategy

Create benchmark scenarios for: quiet interior; dense exterior; rapid traversal/streaming; combat with particles/decals/lights; shadow-heavy foliage; GI/reflection stress; first-person weapon effects; third-person crowd/animation; camera cut; and VRAM pressure.

For each scenario:

- warm shaders, PSOs, streaming, and temporal histories under a declared policy;
- capture at fixed resolution/quality and at dynamic-resolution targets;
- run enough frames for median, p95, p99, p99.9, worst-window, and consecutive-missed-deadline statistics;
- compare CPU critical thread, GPU critical path, display pacing, latency, allocations, residency, bandwidth proxies, draws/dispatches, barriers, and queue overlap;
- preserve a small representative frame capture when a regression gate fails;
- visually inspect the exact hitch frame, using frame-aligned video where available, for missing LODs, temporal resets, or fallback rendering.

Validate query correctness with synthetic known-duration workloads and cross-check in-engine totals against PIX/RGP/Nsight timelines. Test ring overflow, device loss, timestamp disjoint/calibration error, paused/minimized windows, multi-monitor transitions, VSync/VRR, frame caps, and GPU scheduling modes.

## 11. Platform and Scalability Risks

- Timestamp frequency, valid bits, calibration, copy-queue support, and presentation telemetry differ by API/platform.
- GPU/driver updates can invalidate capture replay and shift baselines.
- Background activity, power management, temperature, clock variation, overlays, and capture tools introduce noise.
- Vendor counter names and meanings are not portable.
- Frame generation separates application frames, presented frames, and displayed frames; regression schemas must identify each.
- Dynamic resolution and adaptive quality can hide cost regressions unless work-normalized metrics are retained.
- Split-screen, mirrors, scopes, and captures multiply per-view costs and can distort “frame” attribution.
- Excess instrumentation can change scheduling, memory pressure, batching, or cache behavior.
- Retail telemetry needs strict privacy, storage, bandwidth, and retention limits.

Maintain platform-specific budgets and comparable fixed-clock lab baselines, while using wider statistical thresholds for uncontrolled field data.

## 12. Engineering Recommendations

The following are engineering recommendations:

1. Build one stable, hierarchical marker/ID system shared by in-engine telemetry, PIX labels, Vulkan labels, and vendor tools.
2. Treat display pacing and latency as first-class outputs; never use average FPS as the sole gate.
3. Use asynchronous per-queue timestamp rings and reconstruct the GPU critical path from queue dependencies instead of summing pass times.
4. Record workload counts, resolution, quality, pipeline hash, and memory/streaming state beside every timing.
5. Keep always-on telemetry allocation-free after initialization and bounded under overflow.
6. Gate representative scenarios on p95/p99 frame time, missed deadlines, CPU/GPU budgets, transient/resident VRAM, allocation spikes, draw/dispatch growth, upload bandwidth, and PSO/streaming misses.
7. Require vendor captures for material GPU regressions; interpret occupancy together with utilization, stalls, divergence, cache, bandwidth, and dependency evidence.
8. Keep separate lab, CI, and field baselines. Bind every result to hardware, driver, OS, display/present mode, settings, build, and scenario version.
9. Add automatic hitch-triggered rolling captures and make capture generation scriptable.
10. Preserve unresolved choices in the index: telemetry schema/format, timestamp sampling density, retail overhead budget, frame-latency instrumentation, benchmark scenes, statistical gate thresholds, baseline hardware matrix, capture retention, and field privacy policy.

## 13. Source Links

- [Microsoft PIX — Timing Captures](https://devblogs.microsoft.com/pix/timing-captures-new/)
- [Microsoft PIX — GPU Captures](https://devblogs.microsoft.com/pix/gpu-captures/)
- [Microsoft — Direct3D 12 Timing](https://learn.microsoft.com/en-us/windows/win32/direct3d12/timing)
- [NVIDIA — Nsight Graphics GPU Trace Overview](https://docs.nvidia.com/nsight-graphics/UserGuide/gpu-trace-overview.html)
- [NVIDIA — Nsight Graphics GPU Trace UI Reference](https://docs.nvidia.com/nsight-graphics/UserGuide/gpu-trace-ui.html)
- [AMD GPUOpen — Radeon GPU Profiler Manual](https://gpuopen.com/manuals/rgp_manual/)
- [AMD GPUOpen — Occupancy Explained](https://gpuopen.com/learn/occupancy-explained/)
- [Intel/GameTechDev — PresentMon](https://github.com/GameTechDev/PresentMon)
- [Khronos — VK_KHR_calibrated_timestamps](https://docs.vulkan.org/refpages/latest/refpages/source/VK_KHR_calibrated_timestamps.html)
