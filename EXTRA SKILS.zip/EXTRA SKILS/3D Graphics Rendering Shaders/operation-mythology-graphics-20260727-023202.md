# Operation Mythology Graphics Research — Transparency, Refraction, OIT, and Layered Materials

**Timestamp:** 2026-07-27 02:32:02 America/Los_Angeles  
**Scope:** Renderer-wide transparent-surface and layered-material architecture for a modular, data-oriented engine with explicit render-world extraction and first-/third-person cameras. No production code is included.

## 1. Feature Overview

This batch defines a unified architecture for:

- binary coverage and alpha-to-coverage;
- premultiplied-alpha, additive, modulate, and colored-transmittance composition;
- thin optical transmission and thick homogeneous-volume refraction;
- sorted transparency, weighted blended order-independent transparency (WBOIT), stochastic transparency, and bounded exact OIT;
- layered surface closures such as clear coat, wetness, varnish, dust, and translucent top slabs;
- interaction with clustered lighting, shadows, reflections, fog, depth of field, temporal upscaling, and HDR composition.

The central distinction is between **coverage** (whether matter occupies the sample) and **transmittance** (how light travels through present matter). Treating both as a single opacity scalar prevents physically credible glass, creates fringes during filtering, and obscures which render path and resources a material requires.

## 2. Existing Coverage and Identified Gap

The required recursive scan found 13 files under `C:\Users\steve\Desktop\GAME SKILLS` and 12 files under the dedicated graphics-research folder. Existing work covers deferred/forward-plus paths, render graphs, GPU-driven submission, temporal reconstruction, water refraction, particles, decals, atmosphere, post processing, and material asset validation.

The VFX report already recommends particle compaction and optional approximate OIT, while the water report covers water-specific scene-color refraction. Neither defines:

- a common coverage/transmission material contract;
- thin versus closed-volume asset validation;
- renderer-wide blend and OIT selection;
- deep-fragment resource bounds and overflow behavior;
- layered-BSDF compilation and simplification;
- transparent motion, depth, shadows, fog, or post-process ordering.

This report closes that architectural gap without repeating particle-system or water-simulation findings.

## 3. Sourced Facts

The following statements are sourced facts:

- Khronos states that core glTF alpha represents coverage. `KHR_materials_transmission` exists because clear glass can still reflect while transmitting light; alpha-as-coverage cannot express reflection, refraction, absorption, or scattering. The transmission extension intentionally does not prescribe a sorting algorithm.
- Khronos defines `KHR_materials_transmission` as a thin-surface model. `KHR_materials_volume` changes a nonzero-thickness material into a homogeneous bounded volume, requires a closed/manifold mesh, and adds distance-dependent attenuation and refractive boundaries. Roughness affects both reflection and microfacet transmission.
- `KHR_materials_ior` changes the dielectric index of refraction; glTF otherwise uses 1.5. The specification lists representative values such as approximately 1.33 for water and 1.52 for window glass.
- Epic’s Substrate documentation separately defines coverage and transmittance, models a slab as an interface plus a participating medium, and supports horizontal mixing and vertical layering. Its vertical-layer operator accounts for top-layer thickness and transmittance.
- Epic reports that multi-slab cost rises with material complexity, approximately linearly for additional unblended slabs in its implementation. It uses a classification pass to group lighting complexity and documents an example whose per-pixel material footprint falls from 108 bytes to 28 bytes with parameter blending.
- Microsoft documents source-over premultiplied composition as `source.rgb + destination.rgb * (1 - source.a)` and notes that premultiplied representation filters and composes better than straight alpha.
- Direct3D exposes independent render-target blending, enabling WBOIT-style accumulation and revealage targets in one raster pass where supported.
- McGuire and Bavoil’s WBOIT replaces depth-order sorting with bounded-memory weighted accumulation using conventional blending. It guarantees correct background coverage but approximates layer color and is aimed at cases where popping from changing order is worse than soft approximation.
- NVIDIA’s stochastic transparency converts alpha into randomized subpixel sample coverage. It has fixed memory and no sorting, produces the correct result in expectation, and trades those benefits for sampling noise and substantial multisample cost.
- Vulkan’s fragment-shader interlock extension provides critical sections and ordering guarantees for overlapping fragments accessing per-pixel data. This enables programmable blending/data structures but serializes contending fragments and is an optional capability.

## 4. Industry-Standard Rendering API or Pattern

Use a **classified hybrid transparent pipeline**, not one universal algorithm:

1. **Masked/coverage path:** depth-writing opaque pass with alpha test or alpha-to-coverage for foliage, grates, and cutouts.
2. **Sorted premultiplied path:** CPU/GPU coarse sort by view-depth key, then stable back-to-front blending for ordinary glass, decals that require composition, and low-overlap surfaces.
3. **WBOIT path:** one accumulation pass to weighted color/alpha plus revealage, followed by a fullscreen or tiled resolve. Use for particles, hair cards, smoke shells, and interpenetrating translucent geometry where stable bounded cost matters.
4. **Refractive path:** capture or expose opaque scene color/depth, evaluate thin screen-space refraction or closed-volume entry/exit thickness, then composite in a documented HDR domain. Rough refraction samples an appropriate color pyramid mip.
5. **Exact/deep path:** optional per-pixel linked list, bounded k-buffer, or interlock-based programmable blending for small hero regions only. Always define a node/sample budget and overflow fallback.
6. **Stochastic path:** optional high-sample or temporally accumulated tier for hair/foliage/cloth where noise is acceptable and sample count is available.

Render-graph ordering:

`Opaque depth/G-buffer → opaque lighting → scene-color pyramid → transparent classification/culling → refractive/deep capture resources → transparent lighting/composition → fog integration → transparent velocity/reactive masks → temporal reconstruction → depth of field policy → tone map/presentation`

Some materials may be rendered before or after depth of field, but that choice must be an explicit material/pass domain rather than an incidental draw-list split.

## 5. CPU, GPU, Memory, and Bandwidth Considerations

**CPU complexity:** extraction is linear in visible transparent instances. Sorting is typically `O(n log n)` for a global list, but should use bins/radix keys and coarse object sorting; triangle-perfect sorting is generally infeasible. Classification, PSO/material bucketing, and pass-list construction should be parallel jobs. Avoid per-frame heap allocation by reusing visible-item, key, and indirect-command arenas.

**GPU complexity and draw/dispatch counts:** sorted transparency costs visible transparent fragments plus one draw stream per compatible bucket. GPU-driven bins reduce submission cost but not blending order constraints. WBOIT adds one transparent raster pass and one resolve draw/dispatch. Deep OIT adds fragment insertion plus sort/resolve compute and scales with depth complexity. Refraction adds scene-color/depth reads and often a color-pyramid build already shared with bloom/SSR.

**Allocations and VRAM residency:** WBOIT commonly needs full- or reduced-resolution accumulation and revealage targets. At 4K, even one 64-bit accumulation buffer is about 63 MiB before revealage and transient aliasing. Per-pixel linked lists add a head-pointer image, a global node pool, counters, and overflow telemetry; node memory grows with resolution times allowed depth complexity. Layered deferred closures can add tens of bytes per pixel, so classify and simplify them before allocating a worst-case universal G-buffer.

**Memory bandwidth and cache behavior:** transparent overdraw repeatedly reads textures, lighting structures, scene color, depth, and render targets while writing blended results. Back-to-front blending also inhibits early depth rejection. Use frontmost depth bounds, hierarchical-Z culling where valid, half/quarter-resolution effect tiers, compact material data, coherent bindless indices, and transient aliasing. Rough refraction should sample a mip pyramid rather than perform large divergent kernels.

**Shader divergence:** mixed material features, variable slab counts, light loops, refraction modes, and OIT insertion paths can diverge within waves. Classify by path and coarse feature mask; compile bounded closure families; use tile classification for expensive resolve and rough-refraction work. Do not build an unbounded material interpreter in the hottest transparent pixel shader.

**Synchronization and concurrency:** blend hardware provides ordered target updates for supported blend operations, but UAV deep structures require atomics, barriers, and possibly fragment interlock. Interlock serializes same-pixel work and can collapse parallelism under high overdraw. Build scene-color pyramids asynchronously only when dependencies permit; signal completion before refraction reads. Deep-OIT allocation counters and overflow flags require explicit UAV ordering before resolve.

**Batching:** bucket by composition mode, depth policy, lighting mode, refraction source, closure class, and PSO, then preserve only the ordering needed within each bucket. Bindless material resources and indirect draws reduce CPU submission, but sorting keys must keep correctness-relevant fields ahead of batching fields.

**Streaming:** transparent materials require textures, IOR/attenuation data, thickness policy, and sometimes closed-mesh adjacency or proxy thickness. Stream a conservative fallback material first. Missing normal/thickness/color-pyramid inputs must degrade predictably rather than switching composition semantics mid-frame.

**Frame latency and concurrency:** temporal stochastic or WBOIT stabilization introduces history dependence and must consume correct motion/reactive masks. Do not queue transparency so late that scene-color or velocity dependencies add an extra frame. Track async overlap, barrier stalls, transparency-to-upscaler latency, and history invalidation on cuts, resolution changes, material changes, and camera-mode transitions.

## 6. Pros and Cons

| Technique | Pros | Cons |
|---|---|---|
| Masked/alpha-to-coverage | Depth writes, early rejection, simple shadows, stable cost | Binary or sample-quantized coverage; MSAA dependence; temporal shimmer risk |
| Sorted premultiplied | Familiar, accurate for correctly ordered layers, low extra memory | Object/triangle cycles remain; sorting CPU/GPU cost; order popping; heavy overdraw |
| WBOIT | Bounded memory, no strict sort, stable interpenetration, simple blending | Approximate color/depth ordering; weight tuning; weak for strongly colored glass and distinct layers |
| Stochastic | Order independent, fixed memory, unified coverage, correct in expectation | Noise, MSAA/history cost, ghosting risk, difficult capture consistency |
| k-buffer/deep list | Can approach exact per-pixel ordering; handles crossings | Large/variable memory, atomics, overflow, resolve cost, poor worst-case behavior |
| Thin screen-space refraction | Fast and works with open meshes | Missing off-screen/occluded data, single-layer assumptions, edge artifacts |
| Closed-volume refraction | Thickness and attenuation are physically meaningful | Manifold assets, entry/exit tracking, nested media, sorting, and ray/path cost |
| Layered closures | Reusable physical authoring; coat/wetness/material continuity | More instructions/registers/bytes; permutation pressure; energy and simplification complexity |

## 7. ECS and Render-World Integration

Simulation-world components should remain declarative:

- `TransparentSurface`: composition class, coverage source, depth-write/test policy, sort priority;
- `OpticalMedium`: IOR, attenuation color/distance, thin/volume flag, thickness source;
- `LayeredMaterial`: immutable compiled material handle and instance parameters;
- `TransparencyQualityOverride`: hero/exact permission, resolution tier, max layer budget;
- existing transform, mesh, bounds, visibility, camera-layer, and streaming ownership components.

Render-world extraction resolves these into compact immutable records:

- world/view bounds and depth key;
- mesh/material/descriptor handles;
- compiled closure/path ID;
- current/previous transforms;
- transparent lighting and shadow flags;
- refraction source and history policy;
- cell/generation ID and residency state.

Maintain independent per-view lists for first-person arms/weapons and third-person/world surfaces. First-person glass, sights, particles, and weapon effects need explicit ordering against world transparency, depth of field, motion blur, and temporal masks; never inherit world sort behavior accidentally.

## 8. Resource, Pass, Material, and Visibility Interfaces

**Material interface**

```text
CoverageMode       = Opaque | Masked | AlphaToCoverage | Fractional
CompositionMode    = Premultiplied | Additive | Modulate | ColoredTransmission
OpticalModel       = None | ThinTransmission | HomogeneousVolume
RefractionMode     = None | ScreenIOR | NormalOffset | RayQuery
OITMode            = Sorted | Weighted | Stochastic | BoundedExact
DepthPolicy        = TestNoWrite | TestWrite | Custom
PostDomain         = BeforeDOF | AfterDOF | Overlay
ClosureTopology    = compiled bounded slab/lobe description
```

Keep `coverage`, `transmission`, `IOR`, `attenuation`, `thickness`, and `emission` as different quantities. Convert author-facing transmission-at-distance into runtime extinction/mean-free-path representation during cooking.

**Resources**

- opaque HDR scene color, depth, normals, motion, and color pyramid;
- transparent visible-item/key/indirect buffers;
- WBOIT accumulation and revealage targets;
- optional deep head-pointer/node/counter/overflow buffers;
- transparent depth/velocity/reactive/composition masks;
- compact closure/material tables and bindless texture/sampler tables.

**Pass interfaces**

- `ClassifyTransparent(view, visibleItems) -> bins, sortKeys, budgets`
- `BuildTransparentCommands(bins) -> indirectStreams`
- `AccumulateWeighted(scene, streams) -> accumulation, revealage`
- `ResolveWeighted(sceneColor, accumulation, revealage) -> sceneColor`
- `CaptureDeep(streams, nodePool) -> deepLists, overflow`
- `ResolveDeep(deepLists) -> sceneColor, nearestTransparentDepth`
- `RenderRefraction(sceneColorPyramid, depth, opticalData) -> sceneColor`
- `EmitTransparentTemporalData -> velocity, reactive, composition masks`

Visibility should use frustum/portal/cell culling, conservative occlusion against opaque depth, projected-size thresholds, and per-view importance. Transparent objects cannot generally occlude later transparent objects unless a path writes trusted depth.

## 9. Asset and Runtime Integration Plan

1. Add importer validation distinguishing alpha coverage from optical transmission.
2. Map glTF transmission, volume, and IOR fields into the engine schema; reject or downgrade incompatible combinations with diagnostics.
3. Require closed/manifold geometry and consistent normals for volume mode; otherwise cook as thin transmission.
4. Validate premultiplied texture/export conventions and eliminate RGB fringes in transparent mipmaps.
5. Compile material graphs into bounded closure topology plus a path capability mask. Apply energy-conserving vertical layering; expose horizontal mixing separately.
6. Generate simplified platform variants: collapse layers, grey transmittance, thin refraction, or masked fallback.
7. Build shader/PSO caches per composition, OIT, depth, lighting, and post domain without multiplying permutations by continuous material parameters.
8. During extraction, choose path from material requirement, platform capability, view quality, projected area, and overlap budget.
9. Stream immutable material generations with their textures and compiled shaders; retain the old valid generation until the new one is fully resident.
10. Feed transparent velocity, reactive, depth, and composition masks to temporal upscaling and post-processing through explicit graph edges.

## 10. Visual and Performance Verification Strategy

Create a reference suite containing:

- intersecting colored panes and alternating depth order;
- thin glass versus closed glass with identical coverage;
- nested dielectric objects and known IOR/attenuation distances;
- rough transmission across a roughness sweep;
- foliage/hair/cloth with alpha-to-coverage and stochastic tiers;
- high-depth-complexity smoke/particles;
- clear coat, wetness, varnish, and multi-slab test spheres;
- first-person sight glass crossing world glass, fog, particles, and DoF;
- camera cuts, rapid rotation, resolution changes, and streaming transitions.

Ground truth should use offline path tracing or a high-budget sorted/deep capture where appropriate. Compare linear-HDR images, transmittance curves, silhouettes, Fresnel response, temporal variance, ghost trails, and overflow masks.

Capture per pass:

- CPU extraction, classification, sort, command-build, and submission time;
- GPU raster/resolve/refraction/classification time;
- draws, indirect commands, dispatches, fragments, samples, and overdraw;
- transient and persistent allocations, VRAM residency, node-pool peak/overflow;
- texture/target bandwidth, cache misses, occupancy, register pressure, wave divergence;
- barriers, atomic/interlock contention, queue overlap, synchronization stalls;
- streaming misses, fallback frames, history rejection, frame latency, and frame-time percentiles.

Regression gates should include no deep-buffer overflow in certified scenes, bounded transparent VRAM per resolution tier, correct premultiplied edges, no missing temporal masks, stable camera-mode transitions, and image thresholds against references.

## 11. Platform and Scalability Risks

- Mobile/tile GPUs may penalize framebuffer fetches, large MRTs, high overdraw, and scene-color copies differently from desktop immediate renderers.
- Dual-source or independent blending, fragment interlock, ray queries, and practical MSAA sample counts are not universal; capability checks need deterministic fallbacks.
- WBOIT quality degrades for sharply separated, highly saturated, or strongly refractive layers.
- Deep OIT has adversarial memory and atomic contention under particle storms, hair, vegetation, or camera-inside-volume cases.
- Screen-space refraction cannot recover off-screen or hidden content and can reveal stale/incorrect backgrounds near disocclusions.
- Layer count raises shader/register/material-buffer costs and permutation pressure; unconstrained graphs damage wave coherence.
- Transparent shadows, fog integration, reflections, velocity, and DoF ordering differ across quality tiers and can create visually obvious discontinuities.
- Dynamic resolution changes OIT storage, stochastic sample behavior, and temporal history; rebuild/clear policies must be explicit.

Scalability knobs should include transparent resolution, scene-color-pyramid mip count, WBOIT format, maximum refractive area, light count, closure/layer cap, deep-node budget, stochastic samples, ray-query permission, shadow/reflection tier, sort-bin depth, and pre/post-DoF eligibility.

## 12. Engineering Recommendations

The following are engineering recommendations:

1. Establish coverage and optical transmission as separate first-class material fields.
2. Standardize premultiplied-alpha storage and source-over composition for ordinary fractional coverage; reserve additive/modulate modes for explicit intent.
3. Ship a hybrid path: masked/alpha-to-coverage, sorted premultiplied default, WBOIT for high-overlap approximation, and strictly budgeted exact/stochastic tiers.
4. Treat thin transmission and closed homogeneous volumes as separate asset contracts; validate manifold geometry before enabling volume behavior.
5. Use scene-color/depth pyramids for bounded rough refraction, with ray-query or capture fallbacks only on capable tiers.
6. Compile layered graphs into bounded closure families, classify tiles/materials, and simplify layers per platform; do not store a universal worst-case closure everywhere.
7. Make OIT node/sample capacity, overflow fallback, memory footprint, and telemetry mandatory configuration rather than hidden implementation limits.
8. Integrate transparent velocity, reactive/composition masks, fog, and pre/post-DoF placement through explicit render-graph interfaces.
9. Keep first-person and world transparency in separate per-view bins with an authored composition policy.
10. Gate the feature on cross-platform reference images plus CPU, GPU, draw/dispatch, VRAM, bandwidth, cache, divergence, synchronization, streaming, latency, and concurrency budgets.

Open decisions: default WBOIT weight function and formats; exact-OIT technique and hero budget; transparent depth representation; refraction fallback chain; nested-medium support; colored-transmission platform floor; layer-count and byte limits; alpha-to-coverage temporal policy; transparent shadow model; fog and DoF ordering; first-person composition; overflow behavior; and platform budgets.

## 13. Source Links

- [Khronos — glTF KHR_materials_transmission](https://github.com/KhronosGroup/glTF/blob/main/extensions/2.0/Khronos/KHR_materials_transmission/README.md)
- [Khronos — glTF KHR_materials_volume](https://github.com/KhronosGroup/glTF/blob/main/extensions/2.0/Khronos/KHR_materials_volume/README.md)
- [Khronos — glTF KHR_materials_ior](https://github.com/KhronosGroup/glTF/blob/main/extensions/2.0/Khronos/KHR_materials_ior/README.md)
- [Epic Games — Overview of Substrate Materials](https://dev.epicgames.com/documentation/unreal-engine/overview-of-substrate-materials-in-unreal-engine?lang=en-US)
- [McGuire and Bavoil — Weighted Blended Order-Independent Transparency](https://www.jcgt.org/published/0002/02/09/)
- [NVIDIA Research — Stochastic Transparency](https://research.nvidia.com/publication/2011-08_stochastic-transparency)
- [Microsoft — Premultiplied Alpha](https://learn.microsoft.com/en-us/windows/apps/develop/win2d/premultiplied-alpha)
- [Microsoft — D3D12 Blend State](https://learn.microsoft.com/en-us/windows/win32/api/d3d12/ns-d3d12-d3d12_blend_desc)
- [Khronos — VK_EXT_fragment_shader_interlock](https://registry.khronos.org/VulkanSC/specs/1.0-extensions/man/html/VK_EXT_fragment_shader_interlock.html)
- [AMD GPUOpen — Unlock the Rasterizer with Out-of-Order Rasterization](https://gpuopen.com/learn/unlock-the-rasterizer-with-out-of-order-rasterization/)
