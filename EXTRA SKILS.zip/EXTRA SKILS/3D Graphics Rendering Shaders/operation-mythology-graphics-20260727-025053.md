# Operation Mythology Graphics Research — XR Stereo, Multiview, Composition, and Pose Latency

**Timestamp:** 20260727-025053  
**Scope:** Stereo and variable-view rendering, OpenXR composition, late view updates, reprojection inputs, and pose-to-display latency for a modular data-oriented renderer.

## 1. Feature Overview

This batch defines an XR rendering architecture that treats a headset as a runtime-owned, predicted, variable-count view family rather than as two ordinary cameras. It covers OpenXR frame timing and projection layers; per-view poses, fields of view, swapchain subimages, depth, and optional motion vectors; Vulkan multiview and D3D12 view instancing; compositor-native UI/video layers; late camera updates; and instrumentation of the path from tracking sample to displayed frame.

The target supports first-person and third-person cameras. First-person presentation may include separately budgeted hands, tools, and weapon geometry, but the world remains spatially tracked. Third-person camera logic remains a simulation concern while the final head-relative view transform is supplied by the XR runtime.

## 2. Existing Coverage and Identified Gap

The recursive inventory of `C:\Users\steve\Desktop\GAME SKILLS` and `C:\Users\steve\Desktop\EXTRA SKILS\3D Graphics Rendering Shaders` found adjacent coverage for render graphs, visibility, temporal reconstruction, VRS/foveation, profiling, frame pacing, and multi-view telemetry. It found no dedicated report specifying:

- the OpenXR frame and composition contract;
- variable view counts, asymmetric fields of view, canted displays, or array-layer ownership;
- which work may be shared and which must remain per-view;
- safe late-latching boundaries relative to ECS extraction and command recording;
- depth- and motion-assisted runtime reprojection;
- XR compositor layers and their spatial anchoring;
- a complete pose-to-photon measurement and fallback policy.

The gap is therefore architectural integration, not a repetition of the prior VRS/foveation research. Foveation is referenced only where it changes the view-family or swapchain contract.

## 3. Sourced Facts

The following are sourced facts, not project recommendations:

- OpenXR `xrWaitFrame` returns a predicted display time, predicted display period, and `shouldRender`. `xrLocateViews` locates view poses and fields of view for a requested time and reference space. The normal loop coordinates wait, begin, image acquisition/render/release, and `xrEndFrame`; the runtime owns final composition and presentation.
- A primary stereo projection configuration has two views ordered left then right, but OpenXR also defines configurations with additional views. The 1.1 foveated-inset configuration has outer and inset views for each eye, demonstrating why engines must not hard-code a view count of two.
- Each `XrCompositionLayerProjectionView` supplies a pose, field of view, and swapchain subimage. A projection layer can be associated with `LOCAL`, `STAGE`, or another world-oriented space; content intentionally locked to the viewer uses `VIEW`.
- OpenXR runtimes may reproject submitted layers. `XR_KHR_composition_layer_depth` lets an application attach per-view depth to projection color so the runtime may perform more accurate depth-aware reprojection.
- `XR_FB_space_warp` accepts per-view motion-vector and depth subimages. Its motion vectors are expressed as current minus previous normalized-device coordinates, and the structure also carries the application-space pose delta needed for artificial locomotion.
- Vulkan multiview broadcasts draws and clears to every view bit in a subpass view mask. Attachments use corresponding array layers and shaders receive `ViewIndex`. Correlation masks are performance hints for views with spatial coherence and cannot change results.
- Vulkan documents that multiview support can be constrained when combined with mesh, geometry, or tessellation shaders. Capability queries and a conventional per-view fallback are therefore required.
- D3D12 declares view instancing in the PSO with view-instance locations and a view count. Shaders can consume `SV_ViewID`. Tier 3 can share pre-raster work that does not depend on `SV_ViewID`; lower tiers may implement draw-level looping.
- NVIDIA describes single-pass stereo as processing one geometry stream for two projections and its Turing Multi-View Rendering as supporting four position-independent projection centers, including canted wide-field displays. This is vendor evidence for geometry-sharing potential, not a portable performance guarantee.
- AMD LiquidVR's historical Late-Latch facility updates constant data after original D3D11 calls. It is useful evidence for the late-constant-update pattern, but OpenXR plus explicit-API synchronization should be the portability baseline.

## 4. Industry-Standard Rendering API or Pattern

Use OpenXR as the platform-neutral XR lifecycle and compositor interface. A frame should follow this conceptual order:

1. `xrWaitFrame`, capture `predictedDisplayTime`, then `xrBeginFrame`.
2. Locate the view family for that predicted time and selected application space.
3. Acquire and wait for the runtime swapchain images.
4. Extract immutable render-world data, build conservative visibility, and record shared/per-view graph work.
5. Re-locate or consume the freshest permitted view pose near submission when the runtime/platform path supports a safe late update.
6. Patch only designated view constants, execute, release swapchain images, and call `xrEndFrame` with projection and optional compositor layers.

Represent the frame internally as a `ViewFamily` whose count, extents, FOVs, poses, array slices, sample counts, resolution domains, and feature flags come from runtime enumeration. Do not synthesize a symmetric projection or derive the right eye by offsetting the left.

For Vulkan, prefer dynamic rendering or compatible render passes with `viewMask`, array attachments, and `ViewIndex` where the device and chosen shader stages support multiview. For D3D12, use PSO view instancing and `SV_ViewID` where the reported tier is worthwhile. Preserve a per-view loop using the same material shaders and graph declarations as the correctness fallback.

Use projection layers for world rendering. Use compositor-native quad, cylinder, equirect, or video-appropriate layers for high-resolution UI/video when runtime support, layer-count limits, occlusion semantics, and visual testing justify them. Reference spaces are semantic: world content belongs in `LOCAL`/`STAGE`; only intentionally head-locked content belongs in `VIEW`.

## 5. CPU, GPU, Memory, and Bandwidth Considerations

**CPU complexity and concurrency.** A per-eye implementation roughly repeats culling, draw construction, state sorting, validation, and submission. Shared view-family culling plus per-view visibility masks can reduce those costs, while multiview can reduce API draw counts. Extraction must run once from an immutable simulation snapshot. Visibility, shadow preparation, streaming requests, and render-graph compilation may run concurrently, but final view-constant publication is a small ordered operation. Avoid per-frame allocations by reserving arrays for the runtime's maximum enumerated views and by reusing composition structures.

**GPU complexity, draws, and dispatches.** Multiview may turn two or more graphics draws into one API draw and may share vertex or mesh work, but rasterization and pixel shading remain view-dependent. Compute post-processing normally dispatches across array slices or once per view. Report logical draws, submitted draws, view instances, primitives, fragments, and dispatches separately; a lower API draw count does not imply half the GPU time. Tier, shader-stage use of the view index, view divergence, and architecture determine shared work.

**VRAM residency and allocations.** Color, depth, velocity, exposure, temporal history, distortion-supporting intermediates, and sometimes transparency buffers scale with view count and resolution. MSAA multiplies attachment cost further. Shadows, reflection data, probes, and static geometry may be shared when their spatial contract permits. Maintain a per-view/per-family residency ledger, preallocate bounded swapchain-dependent resources, and rebuild only after runtime view-configuration or extent changes.

**Memory bandwidth and cache behavior.** Stereo duplicates color/depth traffic even when geometry is shared. Array-layer adjacency can improve submission and descriptor locality but does not eliminate render-target bandwidth. Tile/local-memory GPUs benefit when per-view attachments remain within a render region. Interleaving views can hurt texture and constant cache behavior if material paths or foveation rates diverge. Measure multiview against sequential views rather than assuming it wins.

**Divergence and batching.** Keep material permutations view-count agnostic and obtain the view index through a small platform abstraction. Avoid eye-specific material branches. Batch by PSO/material across the whole view family, then apply visibility masks. A union frustum reduces CPU work but can submit geometry visible to only one eye; per-view masks recover pixel and geometry efficiency where supported.

**Synchronization and latency.** Swapchain acquire/wait/release rules are hard ordering points. Late constants must not be overwritten while prior frames still read them; use frame-indexed upload slices or timeline/fence-protected ring entries. Excessive queue overlap can increase latency even if throughput improves. Schedule critical projection work ahead of optional async compute, and cap queued frames. Track graphics/compute/copy queue waits, compositor handoff time where exposed, and the age of the pose actually used.

**Streaming.** Merge predicted view frusta plus a head-motion uncertainty margin for texture, mesh, terrain, and VFX requests. Do not issue duplicate eye requests. Prioritize both foveal/high-density regions when gaze foveation is active, but retain a conservative peripheral residency floor to tolerate saccades and tracking error.

## 6. Pros and Cons

**Multiview/view instancing**

- Pros: fewer API draws; lower CPU submission overhead; possible shared vertex/mesh work; natural array-layer rendering; coherent per-family pass scheduling.
- Cons: feature-tier differences; shader-interface complexity; weaker savings when fragment-bound; union visibility overdraw; possible incompatibility with some geometry/tessellation/mesh paths; harder captures and counters.

**Sequential per-view rendering**

- Pros: universal fallback; straightforward debugging; independent per-eye visibility and scheduling; easier legacy shader integration.
- Cons: repeated command generation and state work; more draw calls; duplicated geometry processing; greater synchronization and graph overhead.

**Compositor layers**

- Pros: sharp UI/video at runtime-selected resolution; independent reprojection; reduced scene-render bandwidth for suitable content.
- Cons: runtime layer-count and shape limits; differing blend/occlusion behavior; capture complexity; visual discontinuity if exposure, color, filtering, or latency differs from the projection layer.

**Late view updates**

- Pros: reduces pose age and rotational error at display time; can improve comfort and apparent stability.
- Cons: cannot safely repair stale simulation, visibility, shadows, or arbitrary temporal data; requires tightly controlled constant lifetime and synchronization; excessive translation after culling can expose missing objects.

## 7. ECS and Render-World Integration

Keep tracking and runtime session objects outside gameplay ECS authority. At extraction, emit:

- `XRSessionSnapshot`: state, predicted time/period, blend mode, tracking validity, runtime feature bits;
- `ViewFamilySnapshot`: generation, variable view count, per-view pose/FOV/extent/slice, reference-space identity, and camera role;
- `CameraPresentationSnapshot`: simulation camera transform, first-/third-person mode, comfort settings, and render-only first-person layers;
- immutable renderables with bounds, visibility category, previous/current transforms, material handles, and streaming IDs.

Maintain three transforms explicitly:

1. simulation/world camera transform;
2. render pose used for culling and most graph work;
3. freshest display-predicted pose used only by declared late-update consumers.

Late update must not mutate ECS components or the extracted render world. It publishes a new version of a small `LateViewConstants` block containing per-view view/projection transforms and derived camera vectors. A pass declares whether it consumes early or late view state. World visibility uses conservative early poses; final projection of opaque/transparent geometry and selected first-person presentation may use late matrices. Screen-space histories must record the exact matrices and pose generation that produced them.

For a third-person camera, gameplay supplies the rig/avatar-relative camera basis, while the tracked head pose adds the runtime-predicted local view. For first person, hands/tools can have their own depth, clipping, LOD, and motion-vector policy, but they must remain stereo-correct and should not become a generic head-locked overlay.

## 8. Resource, Pass, Material, and Visibility Interfaces

Recommended interfaces:

```text
XRFrameTiming {
  predictedDisplayTime, predictedDisplayPeriod, shouldRender,
  waitCpuTime, beginCpuTime, submitCpuTime
}

ViewFamilyDesc {
  generation, configurationType, viewCount,
  views[], colorSwapchain, optionalDepthSwapchain,
  multiviewMode, referenceSpace, blendMode
}

ViewDesc {
  pose, fov, recommendedExtent, imageArrayIndex,
  viewport, visibilityMask, resolutionDomain
}

LateViewConstants {
  poseGeneration, sampleTime, targetDisplayTime,
  view[], projection[], viewProjection[], previousDisplayedViewProjection[]
}

XRCompositionSubmission {
  projectionLayer, optionalDepth[], optionalMotionVectors[],
  auxiliaryLayers[], environmentBlendMode
}
```

Render-graph pass metadata should include `viewDomain` (`Shared`, `PerView`, `Multiview`, `CompositorOnly`), view mask, late-update eligibility, attachment array layers, queue, temporal-history key, and required XR extension. The graph compiler expands `PerView`, validates array-layer ranges, and chooses multiview only after capability and shader compatibility checks.

Material interfaces expose `ViewIndex` without defining eye-specific feature permutations. View-independent material parameters remain shared; per-view sampling, projection, fog, reflection vectors, and screen-space coordinates derive from the indexed view constants. Pipeline cache keys include multiview enablement/view count only where the graphics API makes it part of the PSO.

Visibility produces a family candidate list and a compact per-object view mask. Occlusion is evaluated per view or conservatively combined; an object must not be rejected merely because it is occluded in one eye. Hidden-area/visibility meshes supplied by the runtime may reject pixels that lens distortion will never display.

## 9. Asset and Runtime Integration Plan

1. Add an OpenXR backend that enumerates view configurations, environment blend modes, swapchain formats/extents/sample counts, reference spaces, and optional extensions.
2. Introduce the variable-count `ViewFamily` and array-layer resource model before enabling multiview. Validate using sequential views first.
3. Convert camera-, culling-, material-, fog-, shadow-, temporal-, and post-process code from implicit singleton camera state to indexed view-family inputs.
4. Build shared visibility plus per-view masks; retain a strict per-view culling debug mode.
5. Implement Vulkan multiview and D3D12 view instancing behind one capability-selected policy, with automated equivalence tests against sequential rendering.
6. Add frame-indexed late constant buffers and an explicit publish point after the last permitted pose locate and before dependent GPU execution.
7. Add depth composition where supported. Add motion-vector space warp only after motion/depth conventions, locomotion pose deltas, transparency exclusions, and runtime-specific validation are correct.
8. Move suitable HUD panels, subtitles, and video to compositor layers selectively. Keep world occlusion and color/exposure consistency testable.
9. Extend asset budgets for XR: first-person LODs, two-eye silhouette checks, stereo-safe normals/reflections, peripheral readability, and view-family streaming priorities.
10. Ship sequential, multiview, depth-reprojection, space-warp, and compositor-layer features as independent capability flags with remote-safe fallbacks.

## 10. Visual and Performance Verification Strategy

Create a matrix across D3D12/Vulkan, sequential/multiview, two/four-view configurations where available, first-/third-person cameras, opaque/additive/alpha blend modes, tracking-valid/lost states, fixed/dynamic resolution, and foveation on/off.

Visual tests must include:

- asymmetric and canted projections; near objects crossing eye frusta; extreme IPD/runtime calibration;
- per-eye occlusion, shadows, screen-space reflections/AO, fog, particles, decals, transparencies, and first-person geometry;
- stereo motion vectors, disocclusion, TAA/upscaling histories, depth submission, and artificial locomotion;
- compositor UI anchoring, alpha, color, exposure, sharpness, world occlusion, and layer ordering;
- rapid head rotation/translation, crouching, room-scale boundary motion, tracking loss/recovery, pause/resume, and swapchain recreation.

Performance telemetry must record CPU extraction/culling/build/submit time; logical and submitted draw/dispatch counts; view instances; GPU pass time per view/family; primitive and fragment counts; overdraw; attachment and sampled bandwidth; cache misses where exposed; shader divergence/occupancy; transient allocations; VRAM residency; streaming misses; queue overlap/waits; swapchain waits; frames in flight; missed predicted deadlines; frame latency; and pose age at GPU start, submission, and predicted display.

Timestamp these milestones on one correlated clock where APIs permit: sensor/pose sample, `xrWaitFrame` return, view locate, extraction, late locate/update, GPU begin/end, `xrEndFrame`, compositor/present timing if exposed, and predicted display time. Report percentiles and consecutive misses, not just averages.

Correctness tests compare sequential and multiview outputs with a defined tolerance, verify every shader path propagates the correct view index, poison unused array slices, and assert that late-updated buffers are neither in flight nor read by early-only passes. Capture exact per-view color/depth/velocity plus view matrices, pose generations, extension state, and runtime metadata.

## 11. Platform and Scalability Risks

- View count, FOV symmetry, canted orientation, recommended extent, and sample count are runtime data. Assuming two matching eyes breaks current and future devices.
- D3D12 view-instancing tier and Vulkan multiview limits differ. Some shader stages or platform drivers erase expected geometry savings or require fallback.
- Mobile tile GPUs are sensitive to attachment count, MSAA, resolves, transient-store decisions, and bandwidth. Desktop GPUs may instead be geometry, shader, or compositor-bound.
- Depth and motion-vector reprojection require exact convention agreement, including reversed depth, near/far distances, NDC direction, alpha, invalid pixels, and application-space locomotion.
- Runtime compositor-layer counts, shapes, formats, alpha rules, color spaces, protected-content rules, and capture visibility differ.
- Extra async work, buffering, or frame generation can improve throughput while worsening latency. XR policy must prioritize deadline reliability and low queue depth.
- Tracking loss, runtime focus/session changes, display hot-plug, device loss, and swapchain resize require generation-safe teardown and reconstruction.
- First-person content can violate stereo convergence, clipping, scale, or comfort if treated as a conventional flat-screen weapon layer.
- Head-locked content can be uncomfortable and should be reserved for intentional minimal presentation.
- Foveated inset or future view configurations can multiply histories and pass expansion; resource sizing must follow enumerated maximums and degrade gracefully.

Scalability order should be measured per platform: reduce expensive per-view reflections/volumetrics/transparency; reduce MSAA or view resolution within runtime guidance; simplify first-person effects; select cheaper shadows; then disable optional depth/motion composition or compositor embellishments. Never reduce tracking accuracy or substitute a stale pose to save work.

## 12. Engineering Recommendations

These are engineering recommendations derived from the sourced facts and project constraints:

1. Adopt OpenXR as the authoritative frame-timing, view-enumeration, swapchain, reference-space, and composition layer contract.
2. Make `ViewFamily` variable-count and runtime-authored. Ban hard-coded left/right extents, symmetric projections, and eye-offset reconstruction.
3. Establish correctness with sequential per-view rendering, then capability-select Vulkan multiview or D3D12 view instancing. Treat gains as measured, pass-specific results.
4. Extract the render world once. Use family-wide candidates plus per-view masks; never let one eye's occlusion reject the other eye's visible object.
5. Isolate late latching to fence-safe, frame-indexed view constants. Do not re-run or mutate gameplay, ECS extraction, world transforms, or arbitrary temporal state during late update.
6. Key temporal histories by view-family generation, view index, resolution domain, and exact producing pose. Reset or resample explicitly on configuration changes.
7. Submit depth composition when validated and supported. Gate motion-vector space warp separately behind strict convention tests and transparent/particle policy.
8. Use compositor layers selectively for UI/video that materially benefit. Declare anchoring and blend semantics, budget layer counts, and maintain an in-scene fallback.
9. Instrument pose age and predicted-deadline misses alongside conventional CPU/GPU time. Keep queue depth bounded and prevent optional async work from delaying projection submission.
10. Merge predicted view frusta for streaming with motion uncertainty, foveal priority, and a peripheral residency floor.
11. Require per-platform budgets for view attachments, histories, MSAA, VRAM, bandwidth, draws, dispatches, and compositor layers. Test first- and third-person presentation independently.
12. Keep open decisions explicit: minimum OpenXR/runtime versions; supported view configurations; reference-space policy; late-locate timing; multiview tier floor; union versus per-view culling thresholds; depth/motion extension matrix; compositor-layer use; first-person rendering policy; maximum frames in flight; and latency/deadline budgets.

## 13. Source Links

- [Khronos OpenXR 1.1 specification](https://registry.khronos.org/OpenXR/specs/1.1/html/xrspec.html)
- [Khronos OpenXR 1.0 reference guide](https://registry.khronos.org/OpenXR/specs/1.0/refguide/openxr-10-reference-guide.pdf)
- [Khronos XR_KHR_composition_layer_depth](https://registry.khronos.org/OpenXR/specs/1.1/man/html/XR_KHR_composition_layer_depth.html)
- [Khronos XrCompositionLayerSpaceWarpInfoFB](https://registry.khronos.org/OpenXR/specs/1.1/man/html/XrCompositionLayerSpaceWarpInfoFB.html)
- [Khronos XrSystemSpaceWarpPropertiesFB](https://registry.khronos.org/OpenXR/specs/1.1/man/html/XrSystemSpaceWarpPropertiesFB.html)
- [Khronos Vulkan multiview structure and semantics](https://docs.vulkan.org/refpages/latest/refpages/source/VkRenderPassMultiviewCreateInfo.html)
- [Microsoft D3D12 view-instancing descriptor](https://learn.microsoft.com/en-us/windows/win32/api/d3d12/ns-d3d12-d3d12_view_instancing_desc)
- [Microsoft D3D12 view-instancing tiers](https://learn.microsoft.com/en-us/windows/win32/api/d3d12/ne-d3d12-d3d12_view_instancing_tier)
- [NVIDIA VRWorks Multi-View Rendering](https://developer.nvidia.com/vrworks/graphics/multiview)
- [NVIDIA Turing Multi-View Rendering](https://developer.nvidia.com/blog/turing-multi-view-rendering-vrworks/)
- [AMD LiquidVR](https://gpuopen.com/liquidvr/)
