# Operation Mythology Graphics Research — Decals, Projectors, Surface Marks, and Terrain Stamping

**Timestamp:** 20260727-030053  
**Scope:** Projected and mesh decals, pre-base-pass material buffers, forward/deferred fallbacks, terrain and virtual-texture stamping, persistent surface marks, receiver filtering, sorting, streaming, and bounded GPU-driven submission.

## 1. Feature Overview

Decals locally modify an already-authored surface without requiring a unique base material or destructive mesh edit. Uses include grime, leaks, painted signs, footprints, blood, bullet damage, scorch marks, tire tracks, construction guides, roads, and large terrain variation.

These uses have different persistence, projection, lighting, deformation, and density needs. The recommended feature family therefore has four representations:

1. **Projected volume decals** for sparse, local, transient or moderately persistent marks.
2. **Mesh decals** for authored detail that must wrap edges or follow a known static/skinned surface.
3. **Trail/ribbon or spline marks** for elongated dynamic features such as tires and dragged objects.
4. **Page-backed surface stamps** for dense persistent terrain/static-world changes.

The system modifies material attributes before lighting where supported so that decals participate in baked and dynamic lighting consistently. Emissive-only and scene-color effects remain later, explicitly separate paths.

## 2. Existing Coverage and Identified Gap

The required recursive scan found 17 files under `C:\Users\steve\Desktop\GAME SKILLS` and 19 files in the dedicated graphics folder. The new `GAME SKILLS` report concerns AI navigation and does not overlap this subject. Existing graphics reports mention VFX decals, transparency, material layers, terrain virtual textures, GPU culling, and render graphs, but no report defines a complete surface-mark architecture.

Uncovered decisions were:

- projected-volume reconstruction and receiver rejection;
- DBuffer-like pre-base-pass attribute storage versus direct GBuffer blending;
- forward-renderer and mobile fallback;
- channel masks, normal blending, energy/material validity, and layered-material interaction;
- stable ordering without destroying PSO/material batching;
- mesh-decal depth/LOD/skinning behavior;
- local transient marks versus persistent page-backed terrain/static-surface stamps;
- world-partition ownership, save identity, rebasing, and regeneration;
- bounded allocation, visibility, overdraw, streaming, and temporal verification.

This report fills those gaps and treats the earlier GPU-VFX event system as a producer, not as the owner of decal rendering or persistence.

## 3. Sourced Facts

The following are sourced facts:

- Epic documents two main deferred decal paths: accumulate base color, normal, and roughness-like attributes into a DBuffer before the base pass and sample it from receiving materials; or blend directly into the GBuffer after the base pass and before lighting.
- Epic states DBuffer decals are its default high-end method, require a depth prepass, and are applied early enough to interact correctly with baked indirect lighting. Direct GBuffer decals applied after baked lighting can appear inconsistent.
- Decal receivers can opt out or select which DBuffer channels they accept. Epic notes that enabling only necessary response channels reduces receiving-material complexity.
- Projected decal volumes affect intersecting receiver geometry unless filtered. Screen coverage and decal-material complexity are documented as the largest performance factors.
- Epic warns that excessive unique sort-order values reduce state sorting and harm batching. Its DBuffer material-expression path also has overlap limitations: sorted overlapping decals do not provide arbitrary commutative material blending.
- Epic's mesh decals use separate geometry, do not write depth, and update DBuffer/GBuffer material data after opaque geometry. They avoid planar projection distortion and can wrap edges, but have depth-precision, LOD, tangent, ordering, occlusion, and overdraw limitations.
- Epic reports that projected DBuffer normal access can require previous-frame reprojection because the same current normal target cannot simply be read and written in one pass; errors can produce faceting when motion/depth information is insufficient.
- Epic documents mobile limitations and simplified decal behavior, confirming that DBuffer/GBuffer capabilities cannot be assumed across all forward/mobile paths.
- Runtime virtual texturing is documented as a GPU-generated, on-demand cache for layered materials and is used for landscape splines, decal-like effects, landscape/object blending, and static scene primitives. It has explicit tile/page-table/physical-pool costs and can thrash under aggressive mip demand.
- Epic describes RVT content as a shading cache not fully updated every frame, making static primitives better candidates than skeletal or continuously moving geometry.
- The Frostbite SIGGRAPH material describes deferred decals analogously to deferred light volumes: draw a convex projection volume and reconstruct the affected surface from depth.
- The Doom Eternal SIGGRAPH rendering material documents production use of geometry decals, corroborating mesh/geometry decals as a distinct high-end representation.

## 4. Industry-Standard Rendering API or Pattern

### Projected volume path

Rasterize a conservative box, frustum, capsule, or convex volume. The pixel shader reads scene depth, reconstructs the world position, transforms it into decal-local space, rejects pixels outside the projection bounds, applies angle/depth/edge fades, validates receiver metadata, samples decal textures, and writes selected material attributes.

Choose front/back face culling and depth tests based on whether the camera is inside the volume. A stencil or compact receiver-class texture may avoid expensive material evaluation for invalid receivers. The volume bounds drive CPU/GPU visibility and screen-coverage estimates.

### Pre-base-pass attribute buffer

For the principal deferred/high-end path, allocate transient DBuffer-like attachments only when visible decals require them. Store bounded, format-defined contributions such as:

- base-color blend contribution and coverage;
- encoded world/tangent normal contribution and coverage;
- roughness/metallic/specular/AO contribution and coverage;
- optional height/microdetail or material-layer identifiers only if justified.

Opaque receivers sample these attachments in the base/material pass and apply a single standardized blend function. This makes lighting see the modified attributes. Clear values must represent “no decal” without ambiguity, and channel write masks should prevent unused bandwidth.

### Direct GBuffer path

For compatible deferred platforms, direct post-base-pass GBuffer blending can support late/transient marks without adding DBuffer sampling to every receiver. It is less suitable for baked-light integration and for arbitrary read/modify/write material composition. Treat it as a declared feature tier, not as identical output.

### Forward/mobile path

Options, in descending preference:

1. clustered/tiled decal lists consumed by the forward material shader;
2. a prepass decal attribute buffer sampled by forward receivers;
3. mesh decals or baked/page-backed stamps;
4. color/emissive-only scene-color projection;
5. disable nonessential dynamic marks.

Each platform selects a tested contract. Do not silently drop normal/roughness changes while claiming full decal equivalence.

### Persistent stamp path

For terrain and static-world surfaces, project a stamp into a sparse virtual-texture or clipmapped material-overlay page set. Dirty only intersecting pages, composite stamps deterministically in page space, generate gutters/mips, and publish a new page generation. Store stamp commands or authoritative gameplay descriptors rather than treating the ephemeral GPU cache as saved state.

## 5. CPU, GPU, Memory, and Bandwidth Considerations

**CPU complexity and draw counts.** Naively, every visible projected decal adds a draw and state transition. Cull by world cell, frustum, distance, screen size, receiver class, and lifetime. Then sort by pass, channel mask, material/texture table, PSO, and only coarse priority bands. Use instanced volume meshes or GPU-generated indirect commands for large homogeneous sets. Track submitted decals, culled decals, batches, logical draws, API draws, and forced order breaks.

**GPU complexity and overdraw.** Volume decals shade projected pixels, not just visible mark texels. Cost scales with volume screen coverage, depth complexity, receiver rejection timing, texture samples, and overlapping layers. A camera-inside large volume can cover the screen. Use tight bounds, conservative depth/stencil, alpha bounds, angle rejection, screen-size fading, and per-tile/bin caps. Report shaded volume pixels, accepted receiver pixels, empty-alpha pixels, and overlap depth.

**Dispatch counts.** A GPU-driven path may dispatch culling, binning, prefix-sum/compaction, indirect-command generation, and optional virtual-texture page stamping/mip generation. Batch page work across all new stamps. Avoid one compute dispatch per mark.

**Allocations.** Use fixed-capacity instance pools, generational handles, bounded event queues, per-cell persistent-command storage, compact visible lists, indirect-command buffers, and dirty-page lists. Warm frames allocate nothing. On overflow, discard or merge low-priority cosmetic marks according to policy; never grow an unbounded container.

**VRAM residency.** Transient DBuffer cost is resolution × bytes per pixel × samples and exists only for declared lifetime ranges. At high resolution, three full-size attachments are material. Page-backed stamps require page tables, physical pools, borders, low-mip fallback, and optional CPU command history. Mesh decals add vertex/index data and, for ray/path tracing, may add acceleration-structure residency.

**Memory bandwidth.** A DBuffer path writes decal attributes and reads them again in the base pass; receivers also pay extra instructions/samples. Direct GBuffer modification avoids receiver reads but can create read/write hazards and poor overlap semantics. Minimize formats and enabled channels; use transient memory/tiling where supported; skip clears with generation or render-pass load semantics only when correctness is proven. Virtual-texture updates consume copy/write/mip bandwidth but amortize many persistent marks.

**Cache behavior.** Texture arrays/atlases and bindless descriptor tables improve batching but random decal materials can thrash texture cache. Sort within priority bands by material and cluster stamps spatially. Page stamping has strong spatial locality when dirty pages are grouped. Decal receiver reads should be contiguous screen-space attachments.

**Shader divergence.** Per-pixel receiver, angle, channel, and material branches can diverge heavily near projection boundaries. Move invariants to instance data and PSO variants, use early bounds tests, and keep a small reviewed set of channel-mask permutations. Do not create arbitrary per-decal shader graphs that explode PSO permutations.

**Synchronization and concurrency.** The depth prepass must finish before projected reconstruction; DBuffer writes must finish before receivers sample; direct GBuffer writes must be ordered before lighting; page updates must publish before sampling the new generation. Cull/build jobs can run concurrently on immutable render-world instances. Virtual-texture page composition and streaming can use async compute/copy only if queue transfers do not delay the base pass or create same-frame waits.

**Streaming and latency.** Transient impacts should appear within the same or next visual frame from the VFX event, using a preallocated slot. Persistent page stamps may first appear as a temporary projected decal, then hand off to the page cache once committed. Stream authored decal textures, mesh geometry, and persistent command chunks by world cell. Keep a coarse low-mip/material fallback to prevent pop-out.

## 6. Pros and Cons

**Projected volume decals**

- Pros: arbitrary placement; no receiver UV requirement; small instance data; excellent for impacts and local grime; easy spawn/fade.
- Cons: projection stretch; receiver leakage; volume overdraw; overlap ordering; screen-space dependence; awkward curved surfaces.

**DBuffer/pre-base-pass decals**

- Pros: material attributes participate in later lighting and baked-light evaluation; receiver-selectable channels; compatible with layered material evaluation.
- Cons: extra attachments, bandwidth, depth-prepass dependency, receiver shader work, normal read/write complications.

**Direct GBuffer decals**

- Pros: no decal sampling in all base materials; simple deferred integration; useful for transient post-base modifications.
- Cons: baked-light mismatch; attachment hazards; blend/order restrictions; harder layered-material correctness.

**Mesh decals**

- Pros: conform to complex surfaces and edges; predictable authored shape; useful for characters, seams, panels, and long geometry.
- Cons: added geometry/draws; z-fighting and depth precision; LOD/skinning binding; weak self-occlusion; ray-tracing acceleration cost.

**Virtual-texture/page stamps**

- Pros: amortizes many persistent marks; stable terrain projection; streamable sparse coverage; inexpensive steady-state sampling.
- Cons: page latency, physical-pool pressure, mip/gutter work, stamp-history storage, cache invalidation, unsuitable for rapidly moving receivers.

**Baked/cooked marks**

- Pros: lowest runtime overhead and deterministic quality.
- Cons: no dynamic changes; increases derived asset data; recook required.

## 7. ECS and Render-World Integration

Gameplay ECS may own only semantic mark intent:

```text
SurfaceMark {
  stableId, archetypeId, transformOrAttachment,
  receiverMask, lifetimePolicy, persistencePolicy,
  spawnTick, fade, gameplayTags
}
```

Do not store GPU descriptors, atlas coordinates, render-list indices, page pointers, or raw receiver mesh pointers in ECS.

Extraction resolves each mark to a render representation:

- `ProjectedDecalInstance` with tight volume, projection transform, material-table index, channel mask, receiver mask, priority band, fade, and stable tie-break;
- `MeshDecalInstance` with mesh/material/skinning binding, bounds, LOD group, and base-surface association;
- `TrailMarkSegment` owned by the prior GPU-VFX trail system but emitted to a decal/material path;
- `PersistentStampCommand` with world-cell ownership, projection/shape, material parameters, layer/priority, and content generation.

Static authored marks are compact renderer instances owned by world-partition cells. Dynamic cosmetic marks use a renderer-side pool fed by VFX events. Gameplay-relevant persistent marks have stable IDs and authoritative descriptors; the render cache is derived.

First-person and third-person cameras share the same mark world, but visibility and LOD budgets differ. First-person weapon/hand mesh decals attach to the render representation and skinning generation rather than to a world-space projector. Camera-near surfaces need conservative depth bias and stereo-safe projection.

## 8. Resource, Pass, Material, and Visibility Interfaces

```text
DecalMaterialDesc {
  materialId, textureSet, channelMask, normalBlendMode,
  blendOperator, projectionMode, alphaBounds,
  platformTier, shaderVariant
}

DecalReceiverDesc {
  receiverClassMask, acceptedChannels, materialModelMask,
  decalLayerMask, receivesProjected, receivesMesh,
  persistentStampSurface
}

ProjectedDecalInstance {
  generation, localToWorld, worldToDecal, bounds,
  materialIndex, receiverMask, priorityBand,
  stableOrderKey, spawnTime, fadeParams
}

PersistentStampCommand {
  stableId, worldCell, surfaceDomain, bounds,
  projection, materialId, parameters,
  layer, orderKey, contentGeneration
}
```

Render-graph passes:

1. `DecalCullAndBin` — family/per-view visibility, projected-area estimate, tile bins, capacity selection.
2. `DBufferDecals` — depth read; material-attribute attachments write.
3. `BasePass` — depth/opaque attributes; optional DBuffer read and standardized apply.
4. `GBufferDecals` — optional post-base attribute modification.
5. `DecalEmissive` — optional HDR scene-color additive path.
6. `PersistentStampUpdate` — dirty virtual pages write and mip/gutter generation.
7. `DecalDebug` — bounds, receiver masks, coverage, page state.

Materials declare accepted channels and a single blend contract. Normal blending should use a reviewed reorientation method or explicit replacement mode, then normalize. Metallic/specular/roughness changes must remain within the engine's material model. A decal cannot introduce a fundamentally incompatible shading closure unless the layered-material architecture declares that capability.

Visibility uses tight instance bounds, layer masks, frustum/occlusion, screen coverage, distance/fade, cell residency, and receiver availability. GPU bins contain compact indices, never pointers. Stable order is `(priorityBand, receiver/domain, materialBatch, stableOrderKey)`; exact ordering is reserved for rare authored conflicts.

## 9. Asset and Runtime Integration Plan

1. Define decal material channels, texture packing, color-space rules, normal convention, alpha bounds, receiver masks, and platform tiers in the asset cooker.
2. Add validation for projection bounds, texture dimensions/mips/compression, channel use, material closure compatibility, and sort-band abuse.
3. Implement projected decals with per-view culling and a sequential per-material baseline. Add DBuffer attachments and receiver sampling behind render-graph declarations.
4. Add GPU compaction/indirect instancing only after capture-based correctness and overdraw counters exist.
5. Implement mesh decals as authored derived assets linked to base mesh/skinning/LOD generations. Generate or validate conforming geometry and explicit offsets offline.
6. Connect the GPU-VFX event stream to bounded transient mark pools with lifetime/fade and importance eviction.
7. Add spline/trail conversion for tire marks and dragged paths, using segment merging and distance-based representation.
8. Add persistent static/terrain stamp commands, per-cell journals, sparse page composition, gutters/mips, and low-mip fallback. Use a temporary projected mark until page publication.
9. Integrate save/load by stable semantic mark IDs and world-cell command chunks. Rebuild GPU pages deterministically after load; do not serialize physical cache pages as truth.
10. Add forward/mobile degradation profiles and baked/cooked alternatives before content depends on unavailable channels.

## 10. Visual and Performance Verification Strategy

Visual fixtures:

- planar, curved, sharp-edge, thin, concave, moving, skinned, terrain, foliage, water, translucent, and non-receiver surfaces;
- normal-only, color-only, roughness-only, combined, emissive, height/microdetail, and invalid closure changes;
- grazing projection, projector behind receiver, camera inside volume, near-plane intersection, large coordinate/origin shift, and stereo views;
- hundreds of overlaps across priority bands, deterministic equal-priority ordering, fade/eviction, and handoff from projected to page-backed form;
- static/baked and dynamic lighting, shadows, AO, reflections, GI, TAA/upscaling, motion blur, and ray/path-traced modes;
- mesh-decal LOD, morph/skinning, depth precision, self-occlusion, attachment loss, and receiver topology changes;
- terrain stamp page borders, mips, anisotropy, streaming eviction, save/reload, world-cell unload/reload, and journal compaction.

Performance telemetry:

- CPU extraction, culling, sorting, batching, command generation, page-journal, and page-build time;
- decal counts by type/state, logical/API draw counts, indirect command count, compute dispatch count, PSO/material batches, exact-order breaks;
- GPU pass time, volume pixels, accepted pixels, alpha-empty pixels, overlap depth, early-depth/stencil rejection, texture samples, divergence, occupancy, and cache misses;
- DBuffer/GBuffer and page-update bandwidth, attachment bytes, transient allocations, pool occupancy, VRAM residency, dirty/resident/missing pages, and page churn;
- queue waits/barriers, async overlap, streaming requests/misses, event-to-visible latency, stamp-to-page latency, and frames delayed;
- first- and third-person camera costs separately.

Automated comparison renders the same fixture using projected, mesh, baked, and page-backed reference paths where semantically equivalent. Validate attributes before lighting, final HDR output, motion vectors, and temporal stability. Poison unused DBuffer channels and page borders to catch accidental reads.

Acceptance gates:

- zero warm-frame allocations;
- bounded instances, bins, order lists, and dirty pages under storms;
- no decal on a rejected receiver;
- no stale cell/device/material/page generation use;
- deterministic persistent output for identical ordered commands;
- no unbounded sort-order cardinality;
- platform fallback is visually classified, not silently wrong;
- transient-to-persistent handoff has no missing or double-dark frame.

## 11. Platform and Scalability Risks

- Tile-based/mobile GPUs may make multiple full-resolution DBuffer attachments and their load/store traffic prohibitive.
- Forward paths lack a conventional GBuffer and require clustered receiver evaluation, a prepass buffer, or reduced features.
- MSAA complicates depth reconstruction, edge coverage, attribute blending, and per-sample correctness.
- Decal normals need a clear coordinate space and may require previous-frame information, creating motion/disocclusion artifacts.
- Bindless texture-table capacity and sampler restrictions vary; atlas padding/mips can bleed neighboring decals.
- Mesh decals can z-fight at distance, separate across LODs, or fail to follow deformation. Ray tracing may require extra BLAS/TLAS instances.
- Projectors leak onto unrelated geometry unless receiver filtering and depth/normal bounds are robust.
- Large volumes and overlapping decals cause extreme overdraw even with low instance counts.
- Virtual-texture stamps can thrash physical pools during rapid traversal, teleportation, or widespread updates; page-border and low-mip inconsistency is conspicuous.
- World-origin rebasing and streamed-cell coordinates must preserve persistent stamp identity and projection.
- Arbitrary decal material graphs can multiply shader permutations and violate layered-material energy/closure assumptions.
- Persistent blood/damage can have content-rating, accessibility, privacy/capture, and save-size implications outside pure rendering; expose policy hooks without putting gameplay logic in the renderer.

Scalability knobs should independently control maximum visible projected marks, minimum screen size, lifetime, normal/roughness channels, per-tile overlap, mesh-decal distance/LOD, trail segment density, virtual-page resolution/pool/update budget, ray-traced visibility, and fallback representation.

## 12. Engineering Recommendations

These are engineering recommendations:

1. Treat decals as a representation family selected by lifetime, receiver motion, shape, density, and platform—not as one actor type.
2. Use a DBuffer-like pre-base-pass material-attribute path as the high-end baseline, with explicit receiver channel masks and transient graph allocation.
3. Keep direct GBuffer, clustered-forward, scene-color-only, mesh, baked, and page-backed paths as named feature tiers with tested differences.
4. Reconstruct projected decals from depth inside tight volumes; reject by local bounds, receiver mask, material model, angle, and depth before expensive samples.
5. Standardize channel packing and blend functions. Permit only a small reviewed set of normal/material operators and preserve physically valid parameter ranges.
6. Use coarse priority bands and stable tie-breaks, then sort by PSO/material inside bands. Reserve exact per-item ordering for exceptional authored overlaps.
7. GPU-cull, bin, compact, and indirect-submit high-count decals, but keep fixed capacities and importance-based overflow.
8. Use mesh decals for wraparound/authored/skinned detail only with explicit LOD, deformation, offset, and ray-tracing policy.
9. Use sparse page-backed stamps for persistent terrain/static-world coverage. Store deterministic stamp commands as truth; GPU pages are disposable derived cache.
10. Bridge transient impacts to persistent pages with a generation-tracked handoff so marks do not pop or double-apply.
11. Integrate cell ownership, origin rebasing, save identity, streaming, and page journals from the start. Never keep persistent cosmetic truth only in a frame-local VFX pool.
12. Keep open decisions explicit: DBuffer formats/channels; normal blend; receiver mask width; forward/mobile tiers; priority bands; per-tile capacity; texture atlas versus bindless; mesh-decal skinning/LOD derivation; virtual-page size/pool/journal compaction; persistence limits; ray-tracing behavior; and per-platform draw, bandwidth, VRAM, and latency budgets.

## 13. Source Links

- [Epic Games: Decal Materials in Unreal Engine 5.8](https://dev.epicgames.com/documentation/en-us/unreal-engine/decal-materials-in-unreal-engine)
- [Epic Games: Using Mesh Decals in Unreal Engine 5.8](https://dev.epicgames.com/documentation/unreal-engine/using-mesh-decals-in-unreal-engine)
- [Epic Games: Material Properties and Decal Response](https://dev.epicgames.com/documentation/en-us/unreal-engine/unreal-engine-material-properties)
- [Epic Games: Runtime Virtual Texturing Quick Start](https://dev.epicgames.com/documentation/unreal-engine/runtimevirtual-texturing-quick-start-in-unreal-engine)
- [Epic Games: Virtual Texturing overview](https://dev.epicgames.com/documentation/unreal-engine/virtual-texturing-in-unreal-engine)
- [Epic Games: Virtual Texturing settings and properties](https://dev.epicgames.com/documentation/unreal-engine/virtual-texturing-settings-and-properties-in-unreal-engine)
- [Epic Games: Landscape Splines](https://dev.epicgames.com/documentation/en-us/unreal-engine/landscape-splines-in-unreal-engine)
- [Epic Games: Desktop rendering-path feature support](https://dev.epicgames.com/documentation/unreal-engine/supported-features-by-rendering-path-for-desktop-with-unreal-engine)
- [SIGGRAPH 2010: Destruction in Frostbite](https://advances.realtimerendering.com/s2010/Kihl-Destruction%20in%20Frostbite%28SIGGRAPH%202010%20Advanced%20RealTime%20Rendering%20Course%29.pdf)
- [SIGGRAPH 2020: Rendering Doom Eternal](https://advances.realtimerendering.com/s2020/RenderingDoomEternal.pdf)
- [I3D 2021: Rendering Decals and Many Lights with Ray Tracing Acceleration Structures](https://i3dsymposium.org/2021/posters/hansen2021_rendering_decals_and_many_lights_paper.pdf)
