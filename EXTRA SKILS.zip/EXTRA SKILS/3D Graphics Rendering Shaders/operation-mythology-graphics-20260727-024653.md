# Operation Mythology Graphics Research — Diagnostic Capture and Visual Replay

**Timestamp:** 2026-07-27 02:46:53 America/Los_Angeles  
**Scope:** Exact screenshots, multi-buffer frame dumps, video/display capture, hardware encoding, graphics API captures, deterministic visual replay, metadata, performance, and privacy.

## 1. Feature Overview

Renderer diagnosis needs three distinct capture products:

1. **Exact diagnostic frame dump:** lossless or controlled-loss HDR/SDR color plus optional depth, normals, motion, IDs, exposure, masks, and pass outputs.
2. **Continuous video/display capture:** bounded-overhead frame extraction, color conversion, hardware encode, timestamps, audio synchronization, dropped-frame policy, and container output.
3. **Visual replay package:** deterministic or diagnostically repeatable simulation inputs/state, camera/view state, render configuration, asset/shader generations, random seeds, streaming decisions, and hashes that reproduce a scene without recording every API call.

External graphics debuggers remain essential for API state/resource replay, but they are not a replacement for an engine-owned replay that can run across builds, platforms, and automated tests.

## 2. Existing Coverage and Identified Gap

The required recursive scan found 15 `GAME SKILLS` files and 16 dedicated graphics files. The new asset-pipeline report provides deterministic DAG, CAS, action-manifest, toolchain-generation, and package-integrity patterns. Existing graphics reports provide profiler captures, image-regression gates, render-graph resources, temporal state, and frame pacing.

The uncovered gap is:

- which image domain is captured and how HDR metadata is preserved;
- asynchronous GPU readback/encode without stalling rendering;
- exact versus display/window capture semantics;
- frame/audio timestamp and drop/duplicate policy;
- diagnostic auxiliary channel formats;
- replay capture of view, assets, shaders, streaming, randomness, temporal history, and GPU nondeterminism;
- data volume, privacy, and compatibility policy.

## 3. Sourced Facts

The following are sourced facts:

- Windows Graphics Capture supplies window/display frames through a Direct3D frame pool with QPC-based system-relative timestamps. Microsoft warns that HDR capture needs a floating-point pipeline such as `R16G16B16A16_FLOAT` or explicit HDR-to-SDR tone mapping to avoid washed-out/clipped results.
- DXGI Desktop Duplication returns GPU-resident display images plus move rectangles, dirty rectangles, and pointer metadata. It captures composed desktop/display output rather than the engine’s pre-present internal buffers.
- PIX GPU captures record D3D12 API calls and parameter data. PIX can trigger present-to-present captures programmatically; its documentation recommends considering pending GPU work around capture boundaries.
- PIX timing captures can collect CPU/GPU timing, allocations, file I/O, samples, and context-switch data, with optional data increasing capture overhead.
- NVIDIA Nsight Graphics provides D3D12/Vulkan capture/replay, event/API state, resource, shader, synchronization, memory, and pixel-history inspection. Tool support and replay fidelity remain tied to supported APIs, drivers, and extensions.
- Vulkan defines distinct video encode queue capability and H.264/HEVC extensions; D3D12 also exposes video encoder codec capability. Hardware video encode is therefore an optional queue/device capability, not universally available.
- OpenEXR stores 16- or 32-bit floating-point HDR data, arbitrary channels, tiled/multipart/multiview data, and lossless or lossy compression. It can store diagnostic channels such as depth, motion, normals, and integer IDs.
- OpenEXR explicitly supports premultiplied alpha conventions and configurable size limits, relevant to correct compositing and safe ingestion of captured files.

## 4. Industry-Standard Rendering API or Pattern

### Exact engine frame dump

Insert a render-graph `CaptureExport` node at a named domain:

- pre-exposure scene-linear;
- post-exposure/pre-tone;
- post-tone display-linear;
- encoded swapchain/presentation output;
- selected intermediate pass.

The graph declares source layouts/states and copies selected subresources into renderer-owned staging/readback rings. A background encoder writes:

- EXR multipart/typed channels for HDR and diagnostic data;
- PNG or lossless platform image for SDR presentation;
- a JSON/binary manifest containing matrices, jitter, exposure, color primaries/transfer, dimensions, view, pass/resource IDs, frame/tick, asset/shader/config generations, and hashes.

### Continuous video

Use a GPU-only path where possible:

`capture source → scale/letterbox → tone/gamut map → RGB-to-YUV → encoder input surface → hardware video queue/session → bounded bitstream ring → mux/audio worker`

Never route each frame through CPU-readable memory unless platform constraints require it. Define constant-frame-rate versus variable-frame-rate behavior, encoder backpressure, maximum queue age, keyframe cadence, bitrate/rate control, HDR signaling, and protected-content behavior.

### Deterministic visual replay

Record a replay epoch:

- build/protocol/schema and renderer configuration;
- stable asset/content/shader/PSO generations;
- fixed-tick input/event/state stream and world-cell activation decisions;
- view/camera matrices, FOV, jitter sequence, exposure mode, dynamic-resolution/VRS policy;
- RNG seeds and deterministic ordering keys;
- temporal history reset events and optional checkpoint state;
- expected per-pass/output hashes and reference images.

Replay runs with asynchronous timing normalized or explicitly recorded. GPU API captures are attached only for a narrow divergent frame.

## 5. CPU, GPU, Memory, and Bandwidth Considerations

**CPU complexity:** capture requests and manifest assembly are linear in selected resources/channels. Encoding/muxing runs on background workers. Replay serialization should append compact tick records and periodic checkpoints, avoiding full-world snapshots every frame.

**GPU complexity and draw/dispatch counts:** exact dumps add copy/resolve and optional format-conversion dispatches, not draws. Video adds scale/color-conversion dispatches and video-encode submissions. Auxiliary pass exports can extend resource lifetimes and prevent transient aliasing. External API capture instrumentation can materially perturb workloads.

**Allocations and VRAM residency:** use fixed rings for capture surfaces, readback buffers, encode inputs, bitstreams, and manifests. A 4K RGBA16F image is roughly 63 MiB before auxiliary channels; several in-flight frames can consume hundreds of MiB. Multipart dumps and deep/OIT channels require explicit caps. Encoder reconstructed-picture/reference pools add separate residency.

**Memory bandwidth and cache behavior:** copying full-resolution HDR and diagnostic buffers is bandwidth-heavy. Schedule after last producer/consumer, copy only requested rects/mips/layers, and use GPU-native tiled conversions before readback. Video RGB-to-YUV conversion reads full source and writes chroma planes; avoid redundant presentation copies.

**Shader divergence:** conversion shaders should use separate fixed SDR/HDR/YUV variants. Diagnostic channel packing is better as typed copy/compute passes than a branch-heavy universal exporter.

**Synchronization and concurrency:** capture copies wait on source completion and signal a capture timeline; CPU encoders wait only on capture completion, never a global device idle. Hardware encode queue ownership/layout transitions are explicit. Rings must not overwrite surfaces still used by copy, encode, mux, or disk workers.

**Batching:** batch selected diagnostic resources into a small number of copy command lists and contiguous readback allocations while preserving typed metadata. Multiple small screenshot requests for one frame should share the same source copy.

**Streaming:** a deterministic replay either pins exact content generations or records immutable package/CAS digests. Missing assets invalidate reproduction rather than silently substituting newer data. Continuous video never blocks world streaming; capture backpressure drops capture frames, not render/streaming work.

**Frame latency and concurrency:** in-game recording must not deepen the render queue unpredictably. Timestamp the source frame, GPU copy completion, encoder submission/completion, mux write, audio clock, and present. Bound encoder queue age; drop or duplicate according to declared CFR/VFR policy and report it in metadata.

## 6. Pros and Cons

| Method | Pros | Cons |
|---|---|---|
| Internal exact dump | Known render domain, HDR/auxiliary channels, deterministic metadata | Large bandwidth/storage; can extend resource lifetimes |
| Window/display capture | Captures compositor-visible truth and overlays | OS consent/platform-specific; loses internal HDR/pass semantics |
| Hardware video encode | Low CPU, GPU-native surfaces, long recordings | Capability/codec/driver variance; lossy and queue-sensitive |
| CPU readback encode | Portable and inspectable | Stalls/bandwidth/CPU cost; poor high-resolution throughput |
| Graphics API capture | Exact API/resource/event diagnosis | Huge, invasive, driver/tool specific, not cross-build simulation replay |
| Engine visual replay | CI automation and cross-tool reproduction | Requires deterministic boundaries and exact content/config capture |
| Full state snapshots | Fast seek and robust checkpoints | Large files and serialization cost |
| Input/event replay | Compact | Diverges if simulation, content, scheduling, or random state is incomplete |

## 7. ECS and Render-World Integration

ECS-facing capture data should be minimal:

- `VisualReplayTag` or stable entity IDs for diagnostic labeling;
- fixed-tick replay input/event stream produced by simulation systems;
- optional per-entity debug-channel selection;
- camera/view intent and confirmed world epoch.

Capture and replay services live outside ECS:

- `CaptureCoordinator`;
- `FrameExportService`;
- `VideoCaptureService`;
- `ReplayRecorder/Player`;
- `CaptureArtifactStore`.

Render extraction snapshots stable object/material/instance IDs, current/previous transforms, cell/origin epochs, and view state into the render world. Diagnostic object IDs must be generation-checked and must not expose raw pointers or private gameplay data.

## 8. Resource, Pass, Material, and Visibility Interfaces

```text
CaptureRequest {
  frameSelector, viewSelector, captureDomain,
  channelMask, rect, formatPolicy, compressionPolicy,
  includeManifest, privacyPolicy, priority
}

CaptureManifest {
  build/content/shader/config IDs,
  frame/tick/view/origin epochs,
  dimensions/color/exposure/jitter/camera,
  resource/channel descriptors and hashes,
  droppedFrames, timings, tool/driver/device identity
}

ReplayCheckpoint {
  tick, worldGeneration, deterministicStateDigest,
  cameraState, streamingState, rendererHistoryEpoch
}
```

Render-graph interfaces:

- `ExportResource(resource, subresource, domain, format) -> captureTicket`
- `ConvertForVideo(source, colorPolicy, extent) -> encoderSurface`
- `SubmitVideoEncode(surface, timestamp, policy) -> bitstreamTicket`
- `EmitDiagnosticIDs(visibleItems) -> object/material/instance channels`
- `HashResource(resource, canonicalization) -> GPU/CPU digest`

All capture resources have explicit lifetime, queue ownership, maximum bytes, and cancellation behavior.

## 9. Asset and Runtime Integration Plan

1. Define capture domains, color metadata, channel names/types, and canonical hash rules.
2. Add bounded screenshot requests and a renderer-owned copy/readback ring.
3. Implement EXR multipart HDR/diagnostic export plus SDR PNG and manifests.
4. Add fixed-resource video pipeline with GPU color conversion and capability-selected hardware encoding.
5. Integrate audio timestamps and muxing with clear CFR/VFR/drop policy.
6. Record stable asset/shader/PSO/config digests using the asset-pipeline manifest patterns.
7. Add replay checkpoints and fixed-tick input/event recording.
8. Record view, exposure, jitter, dynamic resolution, VRS, origin, streaming, and history-reset events.
9. Add programmatic PIX/Nsight/RenderDoc-style capture triggers through optional development adapters.
10. Store artifacts atomically: payloads first, manifest last; apply retention, quotas, encryption, and redaction.

## 10. Visual and Performance Verification Strategy

Correctness tests:

- dump pre-exposure, post-tone, SDR, HDR, depth, normals, motion, IDs, and masks;
- compare CPU/GPU canonical hashes and decode/re-encode round trips;
- validate color primaries, transfer, luminance, alpha, orientation, crop, and stereo/view metadata;
- test dynamic resolution, HDR toggles, resize, device loss, alt-tab, multiple windows/displays;
- record video with audio under frame hitches and encoder backpressure;
- replay identical sessions across worker counts, render rates, clean machines, and content caches;
- binary-search first divergent tick/pass/resource using hashes.

Performance tests:

- screenshots from 1080p through 8K and multi-channel EXR;
- sustained SDR/HDR video at target rates/codecs;
- burst capture during streaming and GPU pressure;
- API capture overhead compared with engine-owned replay.

Measure CPU capture/encode/mux time, GPU copy/convert/encode time, draw/dispatch counts, allocations, VRAM residency, PCIe/readback bytes, memory bandwidth/cache behavior, shader divergence, synchronization/queue waits, batching, streaming interference, frame latency, encode latency, dropped frames, disk/network throughput, and concurrency.

Acceptance gates: no render-thread blocking on disk/codec, bounded capture VRAM, zero warm-frame general-heap allocation, correct HDR/SDR round trip, explicit dropped-frame accounting, deterministic manifest/hash reproduction within declared tolerance, and safe failure under quota/device/encoder loss.

## 11. Platform and Scalability Risks

- Hardware encoder codecs, profiles, HDR metadata, queue integration, and simultaneous-session limits vary.
- Display capture may require consent and may include private windows, notifications, or protected content.
- API captures can contain shaders, textures, geometry, paths, and proprietary data; access control is mandatory.
- Floating-point GPU results, atomics, unordered work, ray tracing, async streaming, and driver differences can prevent bitwise replay.
- Lossy video is unsuitable as pixel-regression ground truth.
- Exact multi-channel dumps rapidly consume storage and bandwidth.
- Transient aliasing changes when exported resources have longer lifetimes, perturbing the frame under diagnosis.
- Tool replay compatibility changes with API extensions, drivers, and device features.

Scalability controls: capture extent/rect, channel set, frequency, ring depth, EXR compression, video codec/profile/bitrate/GOP, SDR/HDR mode, diagnostic hashing granularity, checkpoint interval, retention quota, and developer/release permissions.

## 12. Engineering Recommendations

The following are engineering recommendations:

1. Separate exact frame dumps, continuous video, engine replay, and external API capture into distinct products and guarantees.
2. Name every capture domain and preserve color primaries, transfer, exposure/pre-exposure, alpha, and view metadata.
3. Use renderer-owned asynchronous copy/readback and encode rings; capture must never call a global GPU idle or block rendering on disk.
4. Keep video GPU-resident through scale, tone/gamut conversion, YUV conversion, and hardware encode where supported.
5. Use multipart OpenEXR for HDR/auxiliary diagnostic channels and lossless SDR images for presentation regression; never use compressed video as truth data.
6. Record immutable content, shader, PSO, config, camera, jitter, streaming, origin, and temporal-history generations in every replay.
7. Define deterministic replay tiers: bit-exact where proven, tolerance-based visual equivalence otherwise, and API capture for final-frame state inspection.
8. Hash named pass outputs to locate the first divergence before generating huge dumps.
9. Bound all buffers, queues, file dimensions, decompression, storage, and retention; publish manifests atomically after payload success.
10. Treat capture data as sensitive and apply user consent, redaction, encryption, access controls, and protected-content rules.
11. Instrument CPU/GPU complexity, draws/dispatches, allocations, VRAM, bandwidth, cache, divergence, synchronization, batching, streaming, frame latency, encode latency, and concurrency.

Open decisions: capture domains/channels; EXR compression; hash canonicalization/tolerances; replay checkpoint interval; nondeterminism policy; video APIs/codecs/rate control; audio clock; HDR signaling; queue depth/drop policy; external-tool adapters; privacy/redaction; artifact storage/retention; and platform budgets.

## 13. Source Links

- [Microsoft — Windows Graphics Capture](https://learn.microsoft.com/en-us/windows/apps/develop/media-authoring-processing/screen-capture)
- [Microsoft — DXGI Desktop Duplication](https://learn.microsoft.com/en-us/windows/win32/direct3ddxgi/desktop-dup-api)
- [Microsoft — PIX Programmatic Capture](https://devblogs.microsoft.com/pix/programmatic-capture/)
- [Microsoft — PIX GPU Captures](https://devblogs.microsoft.com/pix/gpu-captures/)
- [Microsoft — PIX Timing Captures](https://devblogs.microsoft.com/pix/timing-captures-new/)
- [NVIDIA — Nsight Graphics](https://developer.nvidia.com/nsight-graphics/get-started)
- [Khronos — Vulkan Specification, Video Queues](https://registry.khronos.org/vulkan/specs/latest/html/vkspec.html)
- [Microsoft — D3D12 Video Encoder Codecs](https://learn.microsoft.com/en-us/windows/win32/api/d3d12video/ne-d3d12video-d3d12_video_encoder_codec)
- [OpenEXR — Technical Introduction](https://openexr.com/en/latest/TechnicalIntroduction.html)
- [AMD GPUOpen — Radeon GPU Profiler](https://gpuopen.com/rgp/)
