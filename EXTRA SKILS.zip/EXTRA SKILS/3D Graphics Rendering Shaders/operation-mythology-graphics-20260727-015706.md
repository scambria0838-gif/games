# Operation Mythology Graphics Research Report

**Timestamp:** 2026-07-27 01:57:06 America/Los_Angeles  
**Subject:** Shader permutations, compilation, caching, and pipeline-state objects  
**Status:** New architectural baseline  
**Assumptions:** HLSL-first modular renderer targeting D3D12 and Vulkan; data-oriented render world; bindless resources; no production-code implementation in this report.

## 1. Feature Overview

Modern explicit graphics APIs bind large packages of shader and fixed-function state as pipeline-state objects (PSOs/pipelines). Creating a missing pipeline can invoke driver compilation and optimization, producing visible frame hitches. Meanwhile, unrestricted material and feature switches multiply shader variants, build time, package size, RAM, VRAM/driver memory, and validation cost.

**Engineering recommendation:** Build a deterministic shader/PSO service with:

- one HLSL source system compiled by a pinned DXC toolchain to DXIL and SPIR-V;
- explicit static versus dynamic feature policy;
- canonical variant and pipeline keys;
- offline compilation for all build-known shaders;
- manifest-driven PSO discovery and precaching;
- D3D12 pipeline libraries and Vulkan cache/binary capability paths;
- bounded asynchronous runtime compilation only for editor/mod workflows;
- always-ready fallback pipelines for shipping misses;
- telemetry that treats every runtime miss or late compile as a regression.

## 2. Existing Coverage and Identified Gap

Recursive scans of `C:\Users\steve\Desktop\GAME SKILLS` and the dedicated graphics folder found coverage for GPU-driven submission, render graphs, shading paths, residency, virtual assets, temporal reconstruction, shadows, and GI/reflections.

Those reports require cached shader variants and PSOs, but do not define:

- how feature switches become compile-time permutations versus runtime branches;
- stable shader and PSO keys;
- compiler/toolchain versioning;
- offline derived-data artifacts;
- dependency invalidation;
- D3D12/Vulkan cache portability rules;
- asynchronous compilation and fallback behavior;
- packaging, warmup, memory budgets, or regression gates.

This report supplies that missing lifecycle.

## 3. Sourced Facts

1. D3D12 groups most graphics state into `ID3D12PipelineState` objects for rapid binding during command recording [1].
2. Microsoft pipeline libraries can store PSOs, serialize a library to a contiguous blob, and recreate PSOs in later runs. Microsoft's current sample uses an already-compiled uber shader while a specialized PSO compiles, trading temporary GPU efficiency for smoother frame pacing [2][3].
3. Vulkan pipeline caches can be persisted between runs, but their contents depend on vendor, device, driver, and implementation identity; incompatible cache data is ignored [4][5].
4. `VK_EXT_graphics_pipeline_library` divides graphics state into reusable vertex-input, pre-raster, fragment-shader, and fragment-output libraries, reducing repeated compilation/link work [6].
5. `VK_KHR_pipeline_binary` exposes explicit implementation-specific binary keys/data for application-managed persistence; Khronos warns that binaries are device/driver specific and implementations may return no storable data [7][8].
6. Epic documents that on-demand PSO creation can cause severe hitches and uses recorded/bundled caches plus automatic precaching. Epic also tracks hits, misses, untracked states, and requests that completed too late [9][10].
7. Epic documents the tradeoff between retaining precached PSOs in memory and deleting them while relying on the driver's compressed cache, which can still make first retrievals cost milliseconds [10].
8. Microsoft's DXC compiles HLSL to DXIL and also contains a SPIR-V backend, enabling a shared HLSL source toolchain with backend-specific validation [11].

**Cross-source conclusion:** Offline shader bytecode does not eliminate driver pipeline compilation. Reliable hitch avoidance needs application-level variant keys/manifests, API-specific persistent caches, precaching, fallback policy, and device/driver-aware invalidation.

## 4. Industry-Standard Rendering API or Pattern

### Layered artifact model

1. **Source module:** HLSL files, includes, generated material code, and source hashes.
2. **Shader variant:** entry point, stage, target profile, compiler version/options, static defines, capability tier, layout/interface version.
3. **Shader package:** validated DXIL/SPIR-V plus reflection stripped into engine metadata.
4. **Pipeline descriptor:** shader hashes plus root signature/pipeline layout, vertex/mesh input, raster, depth/stencil, blend, attachment formats, sample count, topology, specialization values, and render-pass compatibility.
5. **Driver artifact:** D3D12 pipeline library entry or Vulkan cache/pipeline binary tied to device/driver identity.

Never use memory addresses, unordered-map iteration, or raw compiler timestamps in keys.

### Canonical keys

`ShaderVariantKey` hashes:

- normalized transitive source content;
- generator/material graph version;
- entry point and stage;
- target API/profile/capabilities;
- static feature vector;
- compiler executable/version, flags, validator, and optimization/debug mode;
- resource-layout and shared-header schema versions.

`PipelineKey` hashes the shader variant IDs and every API-visible state field affecting compatibility. Serialize fields explicitly with fixed endianness; do not hash padded native structs.

### Permutation policy

Use static variants only when they:

- remove whole resources/stages/control-flow regions;
- change interfaces/layouts or wave/mesh/ray capabilities;
- materially reduce register pressure or divergence;
- represent platform-incompatible features.

Use runtime uniform branches for low-cost, spatially coherent choices. Use material classification and separate dispatch/draw bins when branching would be divergent. Prefer data-driven texture/constant parameters for artistic variation.

Define a feature-constraint solver so illegal combinations are never generated. Count reachable combinations in CI before compilation.

### Shipping lifecycle

1. Compile source variants offline into a content-addressed derived-data cache.
2. Enumerate pipeline descriptors from renderer feature manifests, material domains, mesh formats, passes, and platform tiers.
3. Run representative automated content traversal to discover remaining states.
4. Merge/deduplicate stable pipeline manifests.
5. Prebuild/warm pipelines during install, first boot, loading screens, or streaming-cell preload.
6. Persist API caches with application build, shader schema, device, and driver identity.
7. During gameplay, request through an asynchronous priority queue.
8. If missing, use an already-resident compatible fallback; never synchronously compile on the frame thread in shipping.

## 5. CPU, GPU, Memory, and Bandwidth Considerations

### Complexity and CPU cost

Let `F` be feature bits, `V` reachable shader variants, `P` pipeline descriptors, and `M` misses:

- naive permutations are **O(2^F)**;
- constraint-pruned enumeration is **O(V)** plus constraint evaluation;
- content-addressed lookup is average **O(1)**;
- offline compilation is approximately **O(V × compiler cost)**;
- pipeline creation is **O(P)** with opaque driver cost;
- runtime priority scheduling is **O(log M)** per request using a heap.

Compilation and driver linking are CPU- and memory-intensive. Use a bounded worker pool separate from latency-sensitive render/job workers. Cap concurrent compiles by measured RAM, not core count alone.

### Allocations and cache memory

- Store immutable keys/descriptors in packed arrays and content-addressed blobs.
- Pool runtime request, completion, and deferred-destruction records.
- Allocate compilation scratch on worker arenas/processes.
- Keep a bounded in-memory PSO LRU divided by graphics/compute/ray class and priority.
- Persist driver blobs atomically with size, checksum, schema, build, device, and driver metadata.
- No steady-state frame-thread heap allocation or managed GC.

Hundreds or thousands of retained PSOs can consume hundreds of MiB or more depending on driver and content. Measure actual process/driver memory rather than assuming serialized blob size equals resident cost.

### GPU performance and divergence

An uber shader reduces variant/PSO count but can increase:

- register pressure and reduce occupancy;
- instruction-cache footprint;
- divergent branches;
- unused descriptor/constant traffic;
- longer compile/optimization time.

Excessive specialization improves a single pipeline but fragments batches and instruction caches. Benchmark representative bins using wave occupancy, registers, instruction count, branch efficiency, cache misses, and total pass time.

### Draw/dispatch and batching

Pipeline keys are the primary GPU-driven binning class. Generate visible lists by compact `PipelineClassId`, then material/geometry locality. Avoid pipeline changes per entity. Consolidate tiny specialized bins into a generic pipeline when dispatch/draw and state-switch cost exceeds specialization gain.

### Synchronization, latency, and concurrency

- Publishing a completed PSO is a CPU synchronization event; use lock-free/bounded completion queues and atomic handle publication.
- Pipeline destruction is fence-retired if command lists can still reference it.
- Vulkan pipeline-cache host synchronization follows creation flags; use per-worker caches and merge when contention measurements justify it.
- Do not serialize all compile jobs behind one global cache mutex.
- Loading screens wait only for declared critical manifests; optional PSOs continue in bounded background work.
- Track request-to-ready latency, queue depth, memory high-water, and impact on frame/job worker utilization.

## 6. Pros and Cons

### Specialized permutations

**Pros:** lower shader work/registers; clear capability separation; better hot-path optimization.  
**Cons:** combinatorial growth; longer builds; larger packages/caches; discovery risk.

### Uber shaders/runtime branching

**Pros:** fewer PSOs; immediate fallback; simpler content coverage.  
**Cons:** divergence, registers, instruction-cache pressure, weaker optimization.

### Offline manifests

**Pros:** deterministic shipping coverage; loading/install-time work; CI validation.  
**Cons:** content traversal can miss states; manifests grow stale; driver compilation remains platform-specific.

### Runtime asynchronous compilation

**Pros:** editor iteration, mods, unknown hardware; spreads work.  
**Cons:** CPU/RAM contention; visible fallback; too-late requests; unsafe if frame thread blocks.

### Pipeline libraries/binaries

**Pros:** reduce repeated driver work and hitches.  
**Cons:** opaque/device-specific artifacts, invalidation, storage and memory policy, optional support.

## 7. ECS and Render-World Integration

ECS components store logical material, mesh, render-domain, and feature-tier handles only. They never store shader modules, permutations, PSOs, pipeline layouts, compiler jobs, or cache entries.

During asset loading/extraction, immutable material and mesh metadata resolve to:

- `MaterialClassId`;
- `GeometryClassId`;
- `PassEligibilityMask`;
- `PipelineClassId`;
- fallback class.

The renderer-owned feature registry maps these classes plus view/pass formats to pipeline descriptors. GPU visible records carry compact pipeline/material IDs. A missing specialized PSO changes renderer presentation policy, not gameplay state.

FP and TP camera changes may alter passes and quality tiers; preload both camera-mode manifests before switching when predictable.

## 8. Resource, Pass, Material, and Visibility Interfaces

### `ShaderVariantDescriptor`

- source/generator ID;
- entry point/stage/profile;
- static feature vector and constraints;
- capability/backend target;
- interface/layout schema;
- compiler/validator identity and options.

### `PipelineDescriptor`

- shader variant IDs;
- root signature/pipeline layout;
- vertex/mesh input class;
- raster/depth/stencil/blend/topology;
- attachment formats/count/sample count;
- dynamic-state mask;
- render-pass/subpass compatibility;
- specialization constants;
- debug provenance.

### `PipelineRequest`

- canonical key;
- priority/deadline;
- critical/optional;
- fallback key;
- requesting feature/pass/material;
- view/streaming-cell preload context.

### Material interface

Material graphs emit a bounded feature declaration, resource layout, generated evaluator, and valid domains. Static switches require an explicit justification/category. The build reports each material's variant contribution and rejects forbidden combinations.

### Render-graph and visibility interface

Pass registration declares the pipeline classes it may use and attachment signatures. The graph can preload pipelines after compilation fixes formats. Visibility bins reference stable `PipelineClassId`; resolved backend handles are accessed only during command recording.

## 9. Asset and Runtime Integration Plan

1. Pin DXC/validator versions and define canonical HLSL-to-DXIL/SPIR-V build recipes.
2. Create content-addressed shader variant keys, dependency scanning, reflection extraction, and backend validation.
3. Define versioned root-signature/pipeline-layout schemas shared with bindless material records.
4. Add permutation constraints and CI variant-count budgets.
5. Implement canonical graphics/compute/ray pipeline descriptors and keys.
6. Build an offline manifest from renderer features, materials, geometry classes, passes, and platform tiers.
7. Add representative automated traversal/telemetry to find manifest misses.
8. Implement D3D12 pipeline libraries and Vulkan pipeline caches first.
9. Add Vulkan graphics pipeline library/pipeline binary capability paths after device testing.
10. Implement bounded background creation, fallback PSOs, atomic publication, and fence retirement.
11. Preload critical manifests during boot/loading and streaming-cell activation.
12. Add hot reload only for editor builds, with generation-safe replacement and error shaders.

## 10. Visual and Performance Verification Strategy

### Correctness

- Compile every reachable variant for D3D12 and Vulkan in CI.
- Validate DXIL/SPIR-V and descriptor/root-layout compatibility.
- Render material/pass golden scenes across opaque, masked, transparent, shadow, velocity, depth, visibility, GI, particles, skinning, and post effects.
- Force empty/corrupt/stale caches and driver/build changes; require safe invalidation.
- Force missing/failed/late pipelines; verify fallback visibility and later atomic replacement.
- Hot-reload shaders while frames are in flight in editor stress tests.

### Coverage

Record every runtime pipeline key and classify it:

- manifest hit;
- driver-cache hit;
- precached;
- missed;
- untracked;
- too late;
- fallback used;
- compile failed.

CI replays deterministic camera paths, feature toggles, FP/TP switching, streaming, destruction, weather, and quality changes. A shipping candidate must have zero unexpected keys across the corpus.

### Performance

Measure:

- shader variants and PSOs by feature/material/pass/platform;
- compile CPU time, peak workers, RAM, package/cache bytes;
- pipeline creation/link/load latency distributions;
- in-memory PSO count/bytes and driver process memory;
- miss/late/fallback counts and request-to-ready latency;
- frame-time hitches, 1%/0.1% tails, job-worker contention;
- draw/dispatch count, pipeline switches, bin sizes;
- GPU registers, occupancy, divergence, instruction/cache behavior, pass time.

Compare specialized, generic, and pipeline-library modes on representative GPUs/drivers.

### Acceptance gates

- Zero synchronous gameplay pipeline compilation in shipping.
- Zero unexpected runtime keys in the release corpus.
- Every request has an always-ready compatible fallback or is declared load-blocking.
- Deterministic cache invalidation across build/compiler/layout/device/driver changes.
- No steady-state frame-thread allocation.
- Critical preload fits boot/loading budget; optional compile work cannot starve render/simulation/I/O.
- Variant, package, RAM, and resident PSO budgets enforced in CI.

## 11. Platform and Scalability Risks

- Driver caches/binaries are not generally portable across vendors, devices, or driver updates.
- Console/platform APIs may provide proprietary offline compilation; backend policy must remain pluggable.
- Mobile Vulkan devices can be especially sensitive to runtime creation and storage limits.
- Vulkan graphics pipeline libraries and pipeline binaries are optional; keep monolithic cache fallback.
- Root-layout changes invalidate broad portions of the cache.
- Render-target format/sample-count diversity multiplies graphics pipelines.
- Ray-tracing pipelines add shader-group and recursion/payload dimensions.
- Editor/mod shader compilation expands the attack/resource surface; sandbox and bound it.
- Hot reload can exhaust memory if generations are not retired.
- Overaggressive preload increases startup time and RAM even when gameplay is hitch-free.

## 12. Engineering Recommendations

1. Make shader and pipeline identity content-addressed, versioned, and deterministic.
2. Pin the compiler/validator per build and include them in every cache key.
3. Use one HLSL source system, but validate DXIL and SPIR-V independently.
4. Require explicit justification and CI accounting for every static feature dimension.
5. Generate offline variants and manifests; use runtime discovery only to close coverage gaps.
6. Treat driver caches as accelerators, never as the only record of required pipelines.
7. Prohibit synchronous shipping compilation on the frame thread.
8. Keep generic/error/fallback PSOs resident for every render domain.
9. Use bounded background workers and memory-aware scheduling.
10. Bin GPU work by compact pipeline class and consolidate tiny variants.
11. Adopt Vulkan pipeline libraries/binaries only after capability/driver validation.
12. Make misses, late compiles, fallback frames, compile latency, and memory first-class regression metrics.

### Remaining open decisions

- DXC release/profile baseline and SPIR-V options.
- Root-signature/pipeline-layout schema and bindless compatibility.
- Static-feature budget and material graph restrictions.
- Critical versus optional manifest partitioning.
- Fallback visual policy: generic material, skip, or load-block.
- D3D12/Vulkan in-memory PSO LRU sizes.
- Vulkan pipeline library/binary minimum tier.
- Editor/mod compilation isolation and hot-reload retirement.
- Ray-tracing pipeline caching scope.

## 13. Source Links

1. Microsoft, **Managing Graphics Pipeline State in D3D12**: https://learn.microsoft.com/en-us/windows/win32/direct3d12/managing-graphics-pipeline-state-in-direct3d-12
2. Microsoft, **ID3D12Device1::CreatePipelineLibrary**: https://learn.microsoft.com/en-us/windows/win32/api/d3d12/nf-d3d12-id3d12device1-createpipelinelibrary
3. Microsoft, **D3D12 Pipeline State Cache Sample**: https://learn.microsoft.com/en-us/samples/microsoft/directx-graphics-samples/d3d12-pipeline-state-cache-sample-win32/
4. Khronos, **Vulkan Pipeline Cache Guide**: https://docs.vulkan.org/guide/latest/pipeline_cache.html
5. Khronos, **Vulkan Pipelines Specification**: https://docs.vulkan.org/spec/latest/chapters/pipelines.html
6. Khronos, **Graphics Pipeline Library Sample**: https://docs.vulkan.org/samples/latest/samples/extensions/graphics_pipeline_library/README.html
7. Khronos, **VK_KHR_pipeline_binary Proposal**: https://docs.vulkan.org/features/latest/features/proposals/VK_KHR_pipeline_binary.html
8. Khronos, **Pipeline Binary Sample**: https://docs.vulkan.org/samples/latest/samples/extensions/pipeline_binary/README.html
9. Epic Games, **Optimizing Rendering with PSO Caches**: https://dev.epicgames.com/documentation/en-us/unreal-engine/optimizing-rendering-with-pso-caches-in-unreal-engine
10. Epic Games, **PSO Precaching**: https://dev.epicgames.com/documentation/en-us/unreal-engine/pso-precaching-for-unreal-engine
11. Microsoft, **DirectX Shader Compiler**: https://github.com/microsoft/DirectXShaderCompiler

