# Operation Mythology Graphics Research — Bindless Descriptor Heaps, Samplers, and Resource Handles

**Timestamp:** 20260727-030520  
**Scope:** Cross-API bindless resource binding for D3D12 and Vulkan; descriptor heaps/tables/indexing; sampler policy; stable handles, generations, updates, residency fallback, shader ABI, validation, and performance.

## 1. Feature Overview

Bindless rendering replaces frequent per-material descriptor rebinding with stable integer references into large shader-visible resource and sampler domains. Materials, instances, indirect commands, lighting records, VFX, decals, virtual geometry, and ray tracing can then reference textures, buffers, acceleration structures, and samplers through compact data records.

The earlier GPU-driven rendering report established bindless lookup as a baseline. This batch supplies the missing concrete architecture:

- portable capability tiers for D3D12 and evolving Vulkan descriptor models;
- an engine-owned handle ABI distinct from physical descriptor offsets;
- safe publication, update, retirement, and device-generation recovery;
- a bounded immutable sampler family;
- resident, pending, evicted, failed, and fallback resource behavior;
- shader-side non-uniform access rules and debug validation;
- heap/table sizing, fragmentation, cache locality, and update synchronization.

Bindless removes binding churn; it does not remove resource lifetime, state, residency, synchronization, or type correctness.

## 2. Existing Coverage and Identified Gap

The required recursive scan inventoried 17 `GAME SKILLS` files and 20 files in the dedicated graphics folder. The GPU-driven opaque report already recommends persistent SRV/UAV/CBV heaps, Vulkan descriptor indexing, fence-safe reuse, generation counters, and material sorting for cache behavior. Other reports reference bindless textures for VFX, decals, terrain, transparency, and shader PSOs.

No existing report specifies:

- a stable engine handle versus raw heap-index policy;
- D3D12 Shader Model 6.6 direct heap indexing and its volatility/non-uniform rules;
- Vulkan descriptor-indexing, descriptor-buffer, and newly ratified descriptor-heap tiers;
- descriptor publication and update-after-bind concurrency;
- sampler canonicalization under hard heap limits;
- resource type/view identity, null/fallback descriptors, mip residency, or eviction semantics;
- device-loss remapping and stale-handle validation;
- shader ABI reflection/linting and GPU fault isolation.

The newly documented `VK_EXT_descriptor_heap` is also a meaningful technical update: Khronos describes it as a portable, more constrained replacement for issues found in `VK_EXT_descriptor_buffer`, with explicit resource and sampler heaps.

## 3. Sourced Facts

The following are sourced facts:

- D3D12 descriptors are opaque GPU-specific data. The application owns the lifetime and correctness of resources referenced by descriptors; the driver does not retain resource references for ordinary descriptors.
- D3D12 permits at most one shader-visible CBV/SRV/UAV heap and one shader-visible sampler heap bound at a time. Hardware documentation lists up to roughly one million shader-visible CBV/SRV/UAV descriptors in standard tiers and a hard maximum of 2,048 shader-visible samplers.
- Shader Model 6.6 exposes `ResourceDescriptorHeap` and `SamplerDescriptorHeap`. It requires resource-binding Tier 3, Shader Model 6.6, and matching root-signature direct-index flags.
- D3D12 SM 6.6 treats direct-heap descriptors and pointed-to data as volatile. If an index varies within a wave, HLSL requires `NonUniformResourceIndex`; omitting it for a non-uniform index may produce undefined results.
- D3D12 root signatures are limited to 64 DWORDs. Microsoft describes root constants, root descriptors, descriptor tables, and static samplers as different cost/indirection choices; static samplers do not consume root-signature DWORDs.
- Vulkan 1.2 descriptor indexing exposes runtime descriptor arrays and separately queried features for non-uniform indexing, partially bound arrays, variable descriptor counts, and update-after-bind behavior. Support must be queried by descriptor type rather than assumed as one monolithic capability.
- Khronos states update-after-bind is a lifetime model, not permission for arbitrary unsynchronized overwrite of descriptors being consumed.
- `VK_EXT_descriptor_buffer` makes descriptor memory explicit and removes descriptor pools/sets from that path, but has device-specific sizes, alignments, binding limits, sampler/image caveats, and synchronization requirements.
- Khronos now marks `VK_EXT_descriptor_buffer` as deprecated by ratified `VK_EXT_descriptor_heap`. The newer extension explicitly provides one sampler heap and one resource heap, is intended as a full replacement on newer hardware, and places more constraints on implementations for portable performance.
- `VK_EXT_descriptor_heap` treats heaps as bound device-address ranges containing opaque descriptor data. Khronos advises avoiding heap switching because it can be expensive and documents explicit access masks when GPU writes must become heap reads.
- Descriptor heaps describe how shaders access resources, but they do not make the underlying texture/buffer memory resident or establish its image layout/resource state.

## 4. Industry-Standard Rendering API or Pattern

### Engine abstraction

Expose a typed, generation-checked `ResourceHandle`, not a permanent raw physical descriptor index:

```text
ResourceHandle = { logicalSlot, generation, viewClass }
SamplerHandle  = canonical immutable sampler-family index
```

The logical slot indexes a GPU-visible resource-record table. That record contains the current physical descriptor index, resource generation, residency/fallback flags, type/view metadata, and optional streaming information. This one indirection permits descriptor compaction, eviction fallback, device recovery, and debug generation checks without rewriting every material and instance record.

For highly stable resources on constrained platforms, an optimized ABI may collapse logical and physical indices, but only as a backend choice. Serialized assets and ECS/render-world records keep logical handles.

### D3D12 tiers

- **Modern tier:** one long-lived shader-visible CBV/SRV/UAV heap and one sampler heap; SM 6.6 direct indexing; compact root constants/root CBV for per-draw/view addresses and IDs.
- **Compatibility tier:** large descriptor tables rooted in the same long-lived heaps; identical logical resource table and material ABI where possible.
- RTV/DSV descriptors remain separate CPU-visible allocation domains and are not part of shader bindless indexing.

Bind heaps once per command list before a directly indexed root signature and avoid heap switches. Reserve permanent fallback/null ranges, long-lived descriptors, and frame-transient ranges separately.

### Vulkan tiers

- **Tier V1:** Vulkan 1.2 descriptor indexing with runtime arrays and only the individually supported non-uniform/partially-bound/update-after-bind features.
- **Tier V2:** `VK_EXT_descriptor_buffer` where available and already justified; treat it as a compatibility extension now that Khronos has superseded it.
- **Tier V3:** `VK_EXT_descriptor_heap`, with one resource heap and one sampler heap, capability/property queries, descriptor blob sizes/alignment, reserved implementation range, and explicit heap-read synchronization.

Do not require V3 until shipping hardware/driver telemetry proves coverage. Preserve V1 as the broad explicit-API fallback. Pipeline/shader reflection maps the common engine ABI to descriptor sets/bindings, descriptor-buffer offsets, or descriptor-heap access.

## 5. CPU, GPU, Memory, and Bandwidth Considerations

**CPU complexity and draws.** Bindless lookup reduces descriptor-table construction, copying, and per-material binds, allowing draw batching primarily by PSO/pass/geometry class. Descriptor creation/update cost becomes proportional to resource/view changes rather than visible draws. A hash map may canonicalize view descriptions at asset publication time, but warm render frames use fixed arrays/free lists with no allocations.

**GPU complexity.** Direct indexing adds handle/table/descriptor loads before the final resource access. A logical-to-physical table adds one extra coherent buffer read, typically amortized by wave/cache reuse. Measure it against the flexibility it provides. Root/push data should carry frequently changed small constants or addresses rather than allocating a new global descriptor for every draw.

**Draw and dispatch counts.** Bindless should reduce descriptor-induced draw splits and command-list breaks. It need not add a per-frame dispatch. Optional GPU descriptor-heap copies/compaction, residency-table updates, or validation scans should batch into one/few dispatches or copy ranges. Record draw count, descriptor-induced batch count, heap binds, descriptor writes/copies, and table-update dispatches.

**Allocations and fragmentation.** Pre-size global logical tables and physical heaps from platform budgets. Partition stable, streaming, transient, and reserved fallback ranges. Use index free lists/slabs; retire slots through fences/timeline values. Do not compact a physical heap by changing raw indices unless all consumers use the indirection table. Track capacity, live/high-water, holes, pending retirements, and allocation failures.

**VRAM and system memory.** Descriptor storage is smaller than resource data but million-entry heaps and mirrored CPU metadata are not free. Vulkan descriptor sizes and alignment vary by implementation. The logical resource table, generation/type table, debug names, residency state, and CPU view cache may outweigh descriptor blobs. Budget both shader-visible/device-local and staging/system copies.

**Memory bandwidth and cache behavior.** Highly divergent material indices cause descriptor, resource-table, texture, and sampler cache misses. Bin/sort by material when it improves locality without excessive GPU sorting. Keep the resource record compact and split cold debug/streaming fields. Prefer one descriptor for a stable view reused by many materials rather than duplicate views.

**Shader divergence.** A wave can legally access different resources when the API/shader marks the index non-uniform, but execution and cache efficiency can degrade. Divergent texture types, sampler modes, mip residency, and control flow compound the cost. Enforce typed shader accessors and material-class bins; “bindless” is not license for arbitrary resource-type branching inside a wave.

**Sampler policy.** D3D12's 2,048 shader-visible sampler limit makes unbounded per-material sampler creation untenable. Canonicalize a small immutable family over filter, address, comparison, anisotropy tier, LOD bias/clamp, and border-color policy. Prefer static/embedded samplers for universal fixed patterns and heap samplers for the reviewed dynamic family. Reject or quantize authoring combinations outside the family.

**Synchronization and concurrency.** A descriptor must not be modified or reused while any submitted shader can access it. Resource upload completion, state/layout transition, descriptor write, resource-table publication, and material visibility form an ordered transaction. Worker threads may build CPU descriptors and staging records independently; one publication phase assigns versions and records copy/barrier work. Update-after-bind does not bypass host/device data races.

**Residency and streaming.** Descriptor validity and VRAM residency are separate. A logical record points to a guaranteed type-correct fallback until the full resource and required mip range are resident and synchronized. Eviction first atomically republishes fallback, waits for old readers, then releases residency and eventually retires the physical descriptor. Never leave a descriptor referencing destroyed or nonresident memory.

**Frame latency.** Publishing a new resource one frame later is preferable to stalling graphics for upload/descriptor visibility. Track request-to-resident, resident-to-published, and published-to-first-sample latency. Urgent first-person resources use reserved bandwidth and slots, not unsafe in-place overwrite.

## 6. Pros and Cons

**Raw physical indices**

- Pros: no logical-table load; simplest shader; minimal metadata.
- Cons: indices leak backend layout; compaction/recovery requires rewriting all references; stale index aliases another resource; unsafe for serialization.

**Logical handle plus indirection**

- Pros: stable material records; generation/type validation; transparent fallback/eviction; device recovery and heap migration; instrumentation.
- Cons: extra memory/load; table publication synchronization; finite logical namespace.

**D3D12 SM 6.6 direct indexing**

- Pros: no root descriptor-table mapping; heterogeneous resource access; natural GPU-driven records.
- Cons: Tier 3/SM 6.6 floor; volatile semantics; explicit non-uniform correctness; heap switches constrained.

**Vulkan descriptor indexing**

- Pros: Vulkan 1.2 baseline on broad hardware; familiar set/layout validation; per-feature capability selection.
- Cons: descriptor pools/sets and update rules remain complex; feature/limit matrix; update-after-bind caveats.

**Vulkan descriptor heap**

- Pros: portable two-heap model; explicit memory management; direct CPU/GPU copies; alignment/size properties; designed to address descriptor-buffer portability issues.
- Cons: new extension and limited deployed coverage; opaque variable-size data; manual allocation/barriers; reserved ranges; heap switching cost.

**Finite canonical sampler family**

- Pros: predictable capacity; cache reuse; simpler material ABI; portable quality tiers.
- Cons: limits unusual authoring; requires quantization and review; some specialized effects need explicit exceptions.

## 7. ECS and Render-World Integration

ECS components store only asset/material handles. They never store D3D12/Vulkan descriptors, device addresses, heap offsets, or sampler objects.

The render-world extraction resolves:

```text
MaterialRecord {
  materialGeneration, shaderClass,
  textureHandles[], bufferHandles[],
  samplerHandles[], scalarParameters,
  featureMask
}

ResourceRecord {
  physicalDescriptorIndex, generation,
  viewClass, residencyState, fallbackClass,
  minResidentMip, contentGeneration
}
```

Resource ownership belongs to a renderer asset/residency service. It consumes immutable cooked assets and streaming results, then publishes generation-tagged records at a render boundary. The render world snapshots logical handles and material generations; command recording reads an immutable resource-table generation.

First-person and third-person cameras share resource handles but may drive different mip/LOD priorities. First-person hands, weapons, reticles, and close materials receive a priority class in streaming, not a separate unsafe heap. Multi-view rendering uses the same table; view divergence is measured separately.

Device loss increments `DeviceGeneration`, recreates physical heaps/fallbacks, and repopulates descriptors from the CPU asset/view registry. Logical handles remain stable if their asset identity remains valid, while GPU records publish a new device generation.

## 8. Resource, Pass, Material, and Visibility Interfaces

```text
ResourceViewKey {
  assetId, contentGeneration, viewClass,
  format, dimension, subresourceRange, flags
}

LogicalResourceEntry {
  generation, viewClass, fallbackClass,
  physicalIndex, residency, contentGeneration,
  deviceGeneration
}

DescriptorPublication {
  logicalSlot, expectedGeneration,
  newPhysicalIndex, newResidency,
  uploadDependency, publishEpoch
}

DescriptorRetirement {
  physicalIndex, logicalGeneration,
  lastGraphicsFence, lastComputeFence,
  lastCopyFence, deviceGeneration
}

SamplerKey {
  filterClass, addressClass, comparisonClass,
  anisotropyTier, lodBiasClass, minMaxLodClass,
  borderClass
}
```

The render graph declares resource states/layouts as usual; descriptor tables never substitute for graph resource-use declarations. Each pass declares shader-visible logical table generations and whether it can access UAVs, acceleration structures, or transient graph views.

Transient graph resources should use pass/frame-local descriptor arenas with fence retirement, not permanent global logical handles unless their identity escapes the frame. Persistent materials reference only published long-lived slots. Ray-tracing shader tables use the same logical handles where possible, with backend-specific descriptor mappings generated during SBT construction.

Shader accessors are typed:

```text
SampleTexture2D(ColorTextureHandle, SamplerHandle, uv)
LoadBuffer(StructuredBufferHandle, index)
WriteStorage(StorageImageHandle, coord, value)
TraceScene(AccelerationStructureHandle, ray)
```

They apply non-uniform annotations, optional generation/type checks, fallback rules, and backend mapping. Raw heap access outside this library fails shader linting except in audited platform code.

## 9. Asset and Runtime Integration Plan

1. Define handle bit layout, logical capacities, generation wrap policy, view classes, fallback classes, and sampler family.
2. Extend the asset cooker to enumerate required texture/buffer views, validate format/dimension compatibility, deduplicate view keys, and quantize samplers.
3. Implement the logical resource table and CPU registry with permanent fallback descriptors first.
4. Implement D3D12 descriptor-table compatibility, then SM 6.6 direct indexing behind capability checks.
5. Implement Vulkan 1.2 descriptor indexing as the baseline. Add `VK_EXT_descriptor_heap` as the preferred modern backend only where capability/driver tests pass; retain descriptor-buffer support only if a shipping platform requires it.
6. Add transactional upload → state/layout → descriptor → logical-table publication with fence-safe rollback on failure.
7. Connect texture/mesh/AS streaming residency. Pending/evicted/failed entries remain type-correct through fallbacks.
8. Convert materials, instances, lights, VFX, decals, terrain, and ray tracing incrementally to typed logical handles.
9. Add GPU validation tables, poison descriptors, capture metadata, heap high-water telemetry, and fault-package integration.
10. Add device-loss rebuild from CPU view keys and deterministic repopulation before warming full pipelines.

## 10. Visual and Performance Verification Strategy

Correctness tests:

- every resource/view type, format, mip/layer range, SRV/UAV distinction, acceleration structure, comparison sampler, and fallback class;
- uniform and deliberately non-uniform wave indices in every shader stage;
- stream-in, mip promotion, eviction, content replacement, hot reload, rapid destroy/recreate, and slot-generation wrap simulation;
- simultaneous graphics/compute/copy use across multiple frames in flight;
- descriptor update during recorded/not-submitted/submitted work, ensuring only legal publication paths succeed;
- device loss and heap reconstruction while material/logical handles persist;
- shader reflection verifies handle/view types and root/pipeline layout flags;
- D3D12 debug layer/GPU-based validation and Vulkan validation with best-practice and synchronization checks.

Debug builds should maintain a GPU metadata table `{generation, type, residency, deviceGeneration}`. Typed accessors compare it against the handle before use and route mismatches to a conspicuous typed fallback while atomically recording the first fault. A slower validation mode scans material/resource records before draw generation. Retired slots receive poison descriptors until safe reuse.

Performance matrix:

- 1K, 10K, 100K, and maximum-capacity resources;
- coherent single-material, moderately diverse, random divergent, and adversarial sampler/view patterns;
- raw physical indices versus logical indirection;
- descriptor tables/indexing/heap backends;
- CPU-driven and GPU-indirect rendering;
- one to several frames in flight and streaming storms.

Record CPU descriptor creation/copy/update/publication time; allocations; logical/physical capacity/high-water/fragmentation; draw/dispatch count and descriptor-induced batch splits; heap/set binds; root/push data size; GPU table/descriptor lookup time where isolatable; cache miss rates; wave divergence/occupancy; texture bandwidth; table/heap VRAM and system memory; update copy bandwidth; barriers/queue waits; slot-retirement latency; streaming request/resident/publish latency; fallback sample counts; and cross-queue concurrency.

Acceptance:

- zero warm-frame descriptor allocations for unchanged resources;
- no stale descriptor reaches destroyed/nonresident memory;
- every non-uniform access is annotated by generated accessors;
- no raw heap index in serialized content/ECS;
- deterministic overflow with visible telemetry;
- sampler family stays below platform budgets with reserved emergency capacity;
- descriptor publication never stalls the main graphics queue under normal streaming;
- D3D12/Vulkan visual outputs match for equivalent resource/view types.

## 11. Platform and Scalability Risks

- D3D12 SM 6.6 direct heap access requires binding Tier 3 and SM 6.6; older hardware needs descriptor tables.
- Vulkan descriptor-indexing features and limits are granular. “Vulkan 1.2” alone does not prove every desired update/non-uniform behavior.
- `VK_EXT_descriptor_heap` is current and ratified but new; shipping driver availability and validation/tool support may lag.
- Descriptor blob sizes, alignments, reserved ranges, and heap address limits vary on Vulkan.
- Shader-visible sampler capacity is far smaller than resource capacity. Uncontrolled anisotropy, LOD bias, border color, or comparison variants can exhaust it.
- Non-uniform resource access can be correct but slow due to wave serialization and cache thrashing.
- Generation counters can wrap. Bit widths and quarantine/reuse policy must make alias probability negligible and testable.
- Partially bound/null behavior and robustness differ. Always provide type-correct fallbacks rather than depending on undefined invalid access.
- Buffer device addresses and heap-direct access weaken bounds/type protection; validation must move into engine tooling/debug shaders.
- A descriptor can be valid while its resource is in the wrong layout/state, absent from residency, or missing required mips.
- GPU-written descriptor heaps need precise barriers and are harder for capture/replay tools.
- Large heaps can increase memory and capture size; full snapshots should be optional, deduplicated, and privacy-safe.
- Device recovery must reconstruct opaque descriptors; saved raw descriptor bytes or indices are not portable truth.

Scalability knobs include logical/physical capacity, transient arena size, descriptor backend tier, material sorting/binning, sampler-family anisotropy tier, validation level, residency mip floor, and debug-name/metadata retention.

## 12. Engineering Recommendations

These are engineering recommendations:

1. Preserve the existing bindless/GPU-driven direction, but introduce a typed logical handle table between asset/material records and physical descriptor storage.
2. Bind one long-lived resource heap and one sampler heap per command list/backend where possible. Avoid heap switching.
3. Use D3D12 SM 6.6 direct heap indexing on Tier 3 hardware, with a descriptor-table fallback sharing the same logical ABI.
4. Use Vulkan 1.2 descriptor indexing as the compatibility floor. Prefer `VK_EXT_descriptor_heap` on proven modern drivers; treat deprecated descriptor buffer as a targeted compatibility path, not new default architecture.
5. Keep descriptors, resource state/layout, memory residency, and content-mip availability as separate explicit states joined by a transactional publication.
6. Never overwrite or recycle a descriptor until all graphics/compute/copy consumers retire. Update-after-bind does not waive synchronization.
7. Canonicalize a finite immutable sampler family and reserve heap capacity. Prefer static/embedded samplers for globally fixed patterns.
8. Require typed shader accessors that inject non-uniform annotations and debug generation/type/residency validation. Ban unaudited raw heap indexing.
9. Store view keys and logical handles as truth; raw API descriptors, opaque blobs, device addresses, and physical indices are derived per device generation.
10. Publish type-correct fallbacks for pending, evicted, failed, and stale resources before any material becomes visible.
11. Measure descriptor/table cache behavior and material divergence. Retain material binning when it improves GPU locality even though binding changes disappear.
12. Keep open decisions explicit: handle bit allocation and wrap policy; logical/physical capacities; D3D12 table floor; Vulkan descriptor-indexing feature floor; descriptor-heap adoption telemetry; sampler taxonomy; transient/global split; update transport; validation overhead; fallback palette; compaction; ray-tracing mapping; and per-platform CPU, VRAM, bandwidth, latency, and concurrency budgets.

## 13. Source Links

- [Microsoft DirectX Specs: HLSL Shader Model 6.6 Dynamic Resources](https://microsoft.github.io/DirectX-Specs/d3d/HLSL_SM_6_6_DynamicResources.html)
- [Microsoft: D3D12 Resource Binding Overview](https://learn.microsoft.com/en-us/windows/win32/direct3d12/resource-binding-flow-of-control)
- [Microsoft: D3D12 Descriptors Overview](https://learn.microsoft.com/en-us/windows/win32/direct3d12/descriptors-overview)
- [Microsoft: D3D12 Descriptor Tables Overview](https://learn.microsoft.com/en-us/windows/win32/direct3d12/descriptor-tables-overview)
- [Microsoft: D3D12 Root Signature Limits](https://learn.microsoft.com/en-us/windows/win32/direct3d12/root-signature-limits)
- [Microsoft: D3D12 Hardware Resource-Binding Tiers](https://learn.microsoft.com/en-us/windows/win32/direct3d12/hardware-support)
- [Khronos Vulkan Guide: Descriptor Arrays and Runtime Descriptor Arrays](https://docs.vulkan.org/guide/latest/descriptor_arrays.html)
- [Khronos Vulkan Guide: Descriptor Indexing](https://docs.vulkan.org/guide/latest/extensions/VK_EXT_descriptor_indexing.html)
- [Khronos Vulkan: VK_EXT_descriptor_buffer](https://docs.vulkan.org/refpages/latest/refpages/source/VK_EXT_descriptor_buffer.html)
- [Khronos Vulkan: Descriptor Buffer Proposal](https://docs.vulkan.org/features/latest/features/proposals/VK_EXT_descriptor_buffer.html)
- [Khronos Vulkan: VK_EXT_descriptor_heap](https://docs.vulkan.org/refpages/latest/refpages/source/VK_EXT_descriptor_heap.html)
- [Khronos Vulkan: Descriptor Heap Proposal](https://docs.vulkan.org/features/latest/features/proposals/VK_EXT_descriptor_heap.html)
- [Khronos Vulkan Guide: Descriptor Heap](https://docs.vulkan.org/guide/latest/descriptor_heap.html)
