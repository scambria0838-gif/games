# Operation Mythology Graphics Research — Character-Surface Rendering

**Timestamp:** 2026-07-27 02:36:32 America/Los_Angeles  
**Subjects:** Skin, hair/fur, eyes, cloth/fuzz, anisotropic highlights, visibility, shading, assets, render-world extraction, and scalability.  
**Assumptions:** Modular engine, data-oriented scene representation, explicit render-world extraction, no production-code writing, and first-/third-person camera support.

## 1. Feature Overview

Character surfaces require specialized light transport while still fitting a bounded material and visibility architecture:

- **Skin:** dielectric surface reflection over spatially diffused subsurface lighting, with optional thin-feature transmission/backscatter.
- **Hair/fur:** oriented dielectric fibers with longitudinal and azimuthal scattering, absorption, multiple scattering, fractional visibility, and transmittance-aware shadows.
- **Eyes:** a wet reflective corneal interface, refractive iris depth/parallax, sclera scattering, limbus/tear-line details, and geometry/UV conventions.
- **Cloth/fuzz:** base cloth response plus grazing-angle microfiber sheen; optional woven anisotropy.
- **General anisotropy:** tangent-oriented elliptical specular lobes for fibers, brushed surfaces, and directional microstructure.

These features should be compiled as bounded closure families and selected through material classification. They should not become a single unconstrained “character uber-shader.”

## 2. Existing Coverage and Identified Gap

The required recursive inventory found 14 files in `C:\Users\steve\Desktop\GAME SKILLS` and 13 files in `C:\Users\steve\Desktop\EXTRA SKILS\3D Graphics Rendering Shaders`.

Existing coverage includes:

- GPU deformation, skinning caches, animation LOD, and motion-vector ownership;
- deferred/forward-plus shading architecture and material classification;
- mesh/texture validation and streaming;
- shadows, temporal upscaling, transparency/OIT, layered materials, and performance telemetry.

The newly added networking report explicitly excludes rendering from rollback and does not alter graphics architecture.

The uncovered gap is the **surface-lighting and visibility contract** after deformation: no prior report specifies skin diffusion buffers/profiles, strand/card hair representations and shadows, eye asset invariants, cloth sheen, anisotropic tangent encoding, character-material LOD, or how these paths degrade coherently by distance and platform.

## 3. Sourced Facts

The following are sourced facts:

- Epic’s Subsurface Profile path performs skin scattering in screen space after lighting. It separates non-view-dependent lighting from specular, applies profile-dependent spatial filtering, and recombines the result so specular detail remains sharp.
- Epic documents full-resolution skin lighting packed into a 64-bit scene-color representation; incompatible 32-bit formats fall back to a checkerboard approach. Its documented implementation supports at most 255 active profiles and requires temporal antialiasing for the Burley profile path.
- Epic describes screen-space SSS limitations including no backscatter in that path, non-deferred/mobile limitations, and artifacts at very large scatter radii.
- Epic’s groom pipeline consists of simulation, interpolation from guides to render strands, voxelization for density/transmittance/shadows, primary visibility/sample allocation, lighting, and composition.
- Epic states that strand cost grows with groom curve/point count across simulation, interpolation, voxelization, and visibility. It supports strand-to-card/mesh LOD fallback because strand geometry is not supported or affordable everywhere.
- Epic’s hair visibility supports multisampling and an expensive per-pixel linked-list option; its documentation limits the latter to specialized linear-media or cinematic cases. Animated ray-tracing hair also has significant memory and update cost.
- Disney’s Chiang et al. hair/fur model represents principal fiber paths such as reflection and internal transmission, explicitly conserves energy, and offers artist-facing controls derived from multiple-scattering albedo rather than requiring direct absorption-coefficient authoring.
- Epic’s Hair shading inputs expose fiber tangent, scatter, and backlighting because hair highlights and transmission depend on strand direction.
- Epic’s Eye shading model has strong dependencies among shader code, mesh shape, material, and UV layout. It exposes iris mask and iris distance/concavity controls.
- Khronos `KHR_materials_sheen` layers a sheen BRDF over a base metallic-roughness material, uses independent sheen color/roughness, and specifies energy compensation so the sheen layer does not simply add energy.
- Khronos `KHR_materials_anisotropy` defines strength, rotation, and a tangent-space direction texture. It recommends explicit normal/tangent data because tangent derivation is not standardized, and correlating normal and anisotropy textures in the same UV space.

## 4. Industry-Standard Rendering API or Pattern

Use a classified multi-representation pipeline:

1. **Opaque character base pass**
   - write material class, profile/closure ID, base diffuse, normal/tangent, roughness, specular parameters, SSS mask, and motion;
   - keep view-dependent specular separate from diffusible irradiance.
2. **Skin diffusion**
   - classify skin tiles;
   - filter only diffuse/non-view-dependent lighting using a normalized, world-scale-aware profile;
   - use bilateral depth/normal/material-ID rejection;
   - recombine unblurred specular and emissive.
3. **Hair deformation and visibility**
   - consume current/previous deformed guide/strand data from the established deformation pipeline;
   - choose strands, cards, or mesh shell by projected size, platform, and budget;
   - generate fractional visibility/sample data or render premultiplied cards through the transparency architecture.
4. **Hair density/shadows**
   - voxelize or build an equivalent density representation once when shared by lighting, AO, GI, and shadow transmittance;
   - allow per-light deep opacity only for important lights;
   - use coarse opaque/card shadows at lower tiers.
5. **Character lighting**
   - evaluate bounded skin, eye, hair, sheen, and anisotropic closure families;
   - classify tiles/waves to avoid every pixel executing every model.
6. **Composition and temporal data**
   - compose hair with scene color;
   - emit coverage, nearest/deep depth policy, motion, reactive, and composition masks;
   - feed post-processing and upscaling through explicit graph dependencies.

Keep eye/cornea rendering as a dedicated two-interface or approved single-surface approximation. Maintain consistent IOR, geometric radius, iris plane/concavity, limbus mask, and UV conventions across LODs.

## 5. CPU, GPU, Memory, and Bandwidth Considerations

**CPU complexity:** character extraction is linear in visible character sections, grooms, groups, and material instances. LOD selection, material classification, groom bounds, and shadow eligibility should be parallel jobs. Avoid per-frame graph traversal by cooking immutable closure and groom descriptors.

**GPU complexity and draw/dispatch counts:** skin adds tile classification plus one or two diffusion dispatches and recomposition, preferably restricted to skin tiles. Strand hair adds deformation/interpolation, optional simulation, voxelization, visibility, lighting, composition, and shadow work. Cards reduce geometry/sample cost but add transparent overdraw and sorting/OIT work. Eyes and cloth should remain in shared opaque/forward lighting streams where their closure class permits.

**Allocations and VRAM residency:** skin needs profile tables and transient diffuse/SSS targets; full-resolution formats materially affect scene-color storage. Hair requires guide/render-strand buffers, current/previous positions, attributes, cluster/LOD data, visibility samples, density voxels, and possibly ray-tracing geometry. PPLL visibility scales with pixels times sample capacity and must be hard-bounded. Card fallbacks add textures but can release large strand/voxel buffers.

**Memory bandwidth and cache behavior:** full-screen SSS is wasteful when skin coverage is small; compact tile lists and separable/bilateral filters improve locality. Strand data is irregular and can thrash caches if attributes are array-of-structures or if lighting repeatedly chases per-strand data. Use structure-of-arrays, compact quantized attributes, cluster-local ordering, shared-light lists, and half-resolution density/lighting where visually acceptable.

**Shader divergence:** divergent closure types, variable hair samples, light counts, shadow techniques, and layer counts reduce wave utilization. Sort/classify by closure and representation; use fixed upper bounds and separate simple/complex variants. Do not dynamically branch between strand, card, eye, skin, and cloth models in one monolithic pixel shader.

**Synchronization and concurrency:** guide simulation must finish before interpolation; interpolation before visibility and correct motion; voxelization before hair shadow/transmittance lighting; skin lighting before diffusion. Async compute may overlap skin classification/filtering or groom work with independent raster passes, but queue transfers and UAV barriers can erase gains. Previous-frame groom data must not be overwritten until motion consumers finish.

**Batching:** batch opaque character sections by compiled closure/PSO and bindless resource layout. Hair groups can batch only when representation, visibility mode, lighting/shadow mode, and sample formats match. Preserve per-character first-person layering and transparency order.

**Streaming:** stream coarse skin/eye/cloth textures and card hair first; strand clusters, high-resolution micro-normal maps, density data, and ray geometry are optional refinements. Publication must be generation-safe so a groom never pairs new topology with old binding or previous-position buffers.

**Frame latency and concurrency:** character simulation, deformation, and render extraction must publish current/previous states within the same frame contract. One-frame-late hair simulation may be acceptable only when declared and motion vectors correspond to displayed geometry. First-person head/arms, eyelashes, and sights need lower latency and separate quality policy from distant third-person characters.

## 6. Pros and Cons

| Technique | Pros | Cons |
|---|---|---|
| Screen-space skin diffusion | Efficient, artist-friendly profiles, sharp separated specular | Screen-boundary leakage, missing off-screen transport/backscatter, extra bandwidth/history |
| Preintegrated/wrap skin | Cheap, forward/mobile friendly | Less physical, weak spatial scattering, lighting-dependent approximation |
| Strand hair | Fine silhouettes, natural motion and fiber response | High geometry, visibility, shadow, memory, and simulation cost |
| Hair cards | Broad platform support, predictable assets, good distance LOD | Overdraw, sorting, mip/alpha artifacts, baked direction/detail |
| Hair density voxels | Shared transmittance/AO/shadow representation | Voxelization, memory, resolution bias, temporal update cost |
| Deep-opacity/PPLL hair | Better layered visibility/transmittance | Large bounded storage, atomics, resolve cost, overflow risk |
| Dedicated eye model | Convincing corneal reflection and iris parallax | Strong geometry/UV/material coupling; difficult LOD/import validation |
| Cloth sheen | Low-cost grazing microfiber cue | Can over-brighten without energy compensation; limited weave detail |
| Anisotropic GGX | Reuses familiar microfacet pipeline | Requires trustworthy tangent frame and more ALU/registers |

## 7. ECS and Render-World Integration

Simulation/ECS-facing components should be declarative:

- `CharacterSurfaceSet`: skin, eye, teeth, cloth, and accessory material handles;
- `SubsurfaceProfileRef`: immutable profile handle plus per-instance scale/mask;
- `GroomInstance`: groom asset, binding generation, representation policy, simulation handle;
- `EyeSurfaceParams`: approved eye asset/profile handle and bounded customization;
- `CharacterRenderLOD`: importance, first-person/third-person role, representation bias;
- existing mesh, skinning, transform, bounds, visibility, and streaming components.

Render-world extraction resolves:

- current/previous deformed-buffer handles and epochs;
- compiled closure IDs and compact material parameters;
- SSS profile index and tile-classification flags;
- groom group/cluster descriptors, LOD, density/shadow policy;
- eye geometry/profile invariant ID;
- tangent availability/validity;
- per-view first-/third-person visibility and temporal policy.

Large groom buffers, profile tables, voxel grids, visibility nodes, and transient diffusion resources belong to renderer-owned pools, not ECS component storage.

## 8. Resource, Pass, Material, and Visibility Interfaces

**Material/asset schema**

```text
SkinClosure {
  surfaceAlbedo, normal, microNormal, roughnessLobes,
  profileId, scatterMask, worldScale, transmissionTier
}
HairClosure {
  fiberTangent, melaninOrAbsorption, longitudinalRoughness,
  azimuthalRoughness, IOR, scatterScale, backlightScale
}
EyeClosure {
  corneaIOR, corneaRoughness, irisMask, irisDepth,
  scleraProfile, limbusMask, geometryConventionId
}
ClothClosure {
  baseClosure, sheenColor, sheenRoughness,
  optionalAnisotropyDirection, anisotropyStrength
}
```

**Core resources**

- compact character material/closure table;
- SSS profile LUT/table and skin tile list;
- diffusible-light and recombination targets;
- groom guide/render-strand current and previous buffers;
- groom cluster/LOD/attribute/binding buffers;
- hair visibility/sample and density/transmittance resources;
- transparent depth, motion, coverage, and reactive masks.

**Pass contracts**

- `ClassifyCharacterMaterials(gbuffer) -> skinTiles, closureTiles`
- `DiffuseSkin(diffuseLighting, depth, normal, profileId, skinTiles) -> scatteredDiffuse`
- `SelectGroomLOD(view, clusters, budgets) -> representationCommands`
- `InterpolateGroom(guides, binding, previous) -> strands, strandMotion`
- `BuildHairDensity(strands) -> density/transmittance`
- `RenderHairVisibility(strands/cards, view) -> samples/coverage`
- `ShadeComposeHair(samples, lights, shadows, density) -> sceneColor, temporalMasks`

Visibility must support conservative groom cluster bounds, per-view LOD, opaque-depth occlusion, shadow-only policy, and deterministic budget shedding. Eye and skin surfaces use standard mesh visibility but keep closure classification.

## 9. Asset and Runtime Integration Plan

1. Define canonical real-world unit scale for skin profiles and eye geometry.
2. Add texture validation for skin albedo/specular separation, normals, masks, color spaces, and mip behavior.
3. Add tangent-frame validation; anisotropic materials should ship explicit stable tangents and matching normal/anisotropy UVs.
4. Define groom import with stable groups, roots, guides, attributes, binding topology, strand/card/mesh LODs, bounds, and material slots.
5. Cook card atlases with premultiplied-safe dilation, alpha coverage preservation, strand direction, depth/thickness proxies, and normal/tangent data.
6. Validate eye meshes against a versioned geometry/UV convention; reject incompatible iris/cornea assets instead of silently mis-shading.
7. Compile surface graphs into bounded closure families and platform simplifications.
8. Prebuild PSOs and shader caches for skin, hair representations, eye, cloth/sheen, and anisotropy tiers.
9. Package high-cost strand, density, and ray data as optional streaming sections; keep cards/mesh fallback independently activatable.
10. Publish groom topology, binding, current/previous buffers, and materials as one generation-checked runtime set.

## 10. Visual and Performance Verification Strategy

Reference scenes should include:

- calibrated skin spheres/heads across light size, color, angle, and exposure;
- pores/wrinkles under moving highlights to verify specular remains unblurred;
- ears/nose against backlight and screen edges to expose SSS limitations;
- blonde, brown, black, red, grey, and dyed hair under key, environment, and backlight;
- strand/card/mesh LOD transitions at matched exposure and motion;
- wet/dry eye, iris-depth/parallax, limbus, eyelid occlusion, and rapid gaze;
- velvet, wool, satin, woven cloth, and anisotropy-direction test patches;
- first-person arms/hair/accessories and third-person crowds.

Compare against path-traced or calibrated reference renders for albedo, Fresnel, scatter falloff, hair lobe placement, transmittance, iris parallax, and grazing sheen. Test temporal stability under camera cuts, animation, wind, resolution changes, and LOD swaps.

Performance captures must record:

- CPU extraction, groom LOD/bounds, command building, and allocation;
- GPU deformation, interpolation, simulation, voxelization, visibility, lighting, SSS, shadows, and composition;
- draw/dispatch counts, visible curves/points/cards, samples, overdraw, and shadowed lights;
- transient/persistent allocations, VRAM residency, ray geometry, and PPLL overflow;
- memory bandwidth, texture/vertex cache behavior, occupancy, registers, divergence;
- synchronization, barriers, queue overlap, async-compute benefit, and concurrency;
- streaming bytes/misses, representation transition time, temporal resets, frame latency, and frame-time percentiles.

Acceptance gates include zero warm-frame general-heap allocations, no visibility-buffer overflow in certified scenes, bounded character VRAM, stable silhouettes/highlights through LOD, correct previous deformation, no SSS leakage across material/depth boundaries beyond tolerance, and deterministic fallback activation.

## 11. Platform and Scalability Risks

- Deferred screen-space diffusion may be unavailable or too bandwidth-heavy on mobile/forward paths.
- Strand rasterization, deep visibility, density voxels, and ray-tracing hair vary sharply by platform.
- Hair/card LOD transitions can alter silhouette, color, shadow density, and temporal response.
- SSS profile indexing and packed scene-color formats constrain material variety and bandwidth.
- Eye shaders are fragile when mesh proportions, iris plane, UVs, or tangent frames drift across LODs.
- High-frequency skin/hair textures can dominate streaming and anisotropic filtering cost in close first-person views.
- Hair density and screen-space skin methods can fail near screen edges, disocclusions, or rapid motion.
- Character crowds multiply deformed vertices, hair groups, shadow views, material diversity, and draw/dispatch counts.

Scalability controls: skin profile/sample tier, full/half-resolution diffusion, transmission/backscatter tier, strand/card/mesh threshold, curve/point decimation, hair sample capacity, voxel size/ray steps, groom shadow-light count, ray-hair permission, texture resolution, closure complexity, sheen/anisotropy tier, and first-person reservation.

## 12. Engineering Recommendations

The following are engineering recommendations:

1. Use an energy-conserving skin closure with separated sharp specular and profile-filtered diffuse lighting; provide preintegrated/wrap fallbacks.
2. Express skin scatter distance in physical world units and validate profile/albedo pairs with calibrated references.
3. Treat hair as a representation family—strands, cards, and mesh—not a single asset path; require matched LOD appearance and temporal behavior.
4. Reuse hair density only when its voxelization cost is amortized across shadows, transmittance, AO, or GI; otherwise select cheaper per-light/card shadows.
5. Reserve deep/PPLL visibility and animated ray hair for explicit hero budgets with capacity/overflow telemetry.
6. Adopt a bounded energy-aware fiber model with tangent, absorption/albedo, longitudinal/azimuthal roughness, scatter, and backlight controls.
7. Make eye geometry, UV, material, IOR, and iris-depth conventions a versioned asset contract.
8. Implement cloth sheen and general anisotropy as classified closure features with energy compensation and mandatory tangent validation.
9. Publish groom topology, binding, current/previous deformation, density, and material resources transactionally by generation.
10. Reserve first-person character-surface budgets independently from third-person crowds and test their post/temporal ordering separately.
11. Gate quality tiers on CPU/GPU cost, draws/dispatches, allocations, VRAM, bandwidth, cache, divergence, synchronization, batching, streaming, frame latency, and concurrency.

Open decisions: skin diffusion kernel/profile format; forward/mobile fallback; backscatter/transmission method; maximum profile count; strand visibility method/sample capacity; hair density representation; hair shadow hierarchy; fiber model/LUTs; groom import interchange; card-generation pipeline; eye geometry convention; eye LOD approximation; closure packing; tangent-generation standard; and per-platform character budgets.

## 13. Source Links

- [Epic Games — Subsurface Profile Shading Model](https://dev.epicgames.com/documentation/en-us/unreal-engine/subsurface-profile-shading-model-in-unreal-engine)
- [Epic Games — Groom Scalability and Performance](https://dev.epicgames.com/documentation/unreal-engine/groom-scalability-and-performance-with-unreal-engine?lang=en-US)
- [Epic Games — Hair Rendering and Simulation](https://dev.epicgames.com/documentation/unreal-engine/hair-rendering-and-simulation-in-unreal-engine?lang=en-US)
- [Epic Games — Shading Models](https://dev.epicgames.com/documentation/en-us/unreal-engine/shading-models-in-unreal-engine)
- [Epic Games — Material Inputs](https://dev.epicgames.com/documentation/en-us/unreal-engine/material-inputs-in-unreal-engine)
- [Epic Games — MetaHuman Materials and Textures](https://dev.epicgames.com/documentation/metahuman/metahuman-materials-and-textures)
- [Chiang et al. — A Practical and Controllable Hair and Fur Model for Production Path Tracing](https://media.disneyanimation.com/uploads/production/publication_asset/147/asset/siggraph2015Fur.pdf)
- [Khronos — glTF KHR_materials_sheen](https://github.com/KhronosGroup/glTF/blob/main/extensions/2.0/Khronos/KHR_materials_sheen/README.md)
- [Khronos — glTF KHR_materials_anisotropy](https://github.com/KhronosGroup/glTF/blob/main/extensions/2.0/Khronos/KHR_materials_anisotropy/README.md)
- [Epic Games — Digital Humans](https://dev.epicgames.com/documentation/en-us/unreal-engine/digital-humans?application_version=4.27)
