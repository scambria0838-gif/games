# Operation Mythology Graphics Research — Display Presentation, VRR, HDR, Multi-Monitor, and Device Recovery

**Timestamp:** 20260727-025429  
**Scope:** Desktop swapchain architecture and policy for D3D12/DXGI and Vulkan, including presentation modes, latency, tearing/VRR, HDR output, window/display changes, resize, and recoverable device failure.

## 1. Feature Overview

Presentation is a renderer subsystem, not a final unstructured `Present` call. It owns the contract among render resolution, swapchain images, the operating-system compositor, physical displays, pacing policy, HDR/color state, and failure recovery.

This batch defines a `PresentationSurface` abstraction for windowed/borderless output on D3D12/DXGI and Vulkan. It deliberately separates:

- render resolution from swapchain extent and physical display resolution;
- internal scene-linear color from swapchain encoding/color space;
- user intent (`VSync`, `LowLatencyVRR`, `UncappedTearing`, `PowerSaving`) from API-specific present modes;
- transient surface changes from GPU device loss;
- recoverable GPU resources from persistent gameplay/ECS state.

XR runtime presentation remains covered by the preceding OpenXR report and does not pass through this desktop policy.

## 2. Existing Coverage and Identified Gap

The required recursive scan inventoried 16 files under `C:\Users\steve\Desktop\GAME SKILLS` and 18 files in the dedicated graphics research folder. Existing reports cover exposure, tone/gamut mapping, SDR/HDR transforms, profiling, frame pacing, latency, diagnostic capture, resource residency, and render-graph lifetimes.

No report specified the desktop window-system integration contract for:

- DXGI flip-model swapchains and Vulkan surface capability negotiation;
- FIFO/mailbox/immediate presentation and DXGI sync/tearing flags;
- VRR detection and low-latency queue control;
- swapchain color-space/format choice, display migration, and current HDR guidance;
- resize, occlusion, minimize, rotation, DPI, output hot-plug, and multi-monitor changes;
- separation of swapchain recreation from full device-loss recovery;
- present-completion synchronization and safe destruction;
- fault capture, resource rehydration, and degradation after repeated removal.

This batch fills that integration and recovery gap without repeating the existing tone-mapping mathematics.

## 3. Sourced Facts

The following are sourced facts:

- Microsoft recommends DXGI flip-model swapchains. Flip model requires at least two buffers, does not directly support MSAA swapchain buffers (the application resolves before presentation), enables modern fullscreen optimizations, and is required for HDR swapchain formats/color spaces.
- `DXGI_SWAP_EFFECT_FLIP_DISCARD` can permit reverse composition. A frame-latency waitable object lets an application wait until the presentation system can accept another frame; Microsoft documents latency of one frame in suitable Independent Flip paths and graceful fallback when composed.
- DXGI tearing support must be queried. `DXGI_SWAP_CHAIN_FLAG_ALLOW_TEARING` requires a flip-model swapchain and cannot be added or removed by `ResizeBuffers`. `DXGI_PRESENT_ALLOW_TEARING` is used on eligible presents; Microsoft states allowing tearing is required for VRR operation in borderless-window scenarios.
- `IDXGISwapChain2::SetMaximumFrameLatency` limits queued back buffers for waitable swapchains. The documented default is one. Increasing it can restore CPU/GPU concurrency but increases potential input-to-display latency.
- Vulkan requires querying surface capabilities, formats/color spaces, and supported present modes. `VK_PRESENT_MODE_FIFO_KHR` is the only universally required mode and does not tear. Mailbox replaces a pending image at vblank and does not tear. Immediate need not wait for vblank and may tear. FIFO-relaxed may tear when late.
- `VK_KHR_present_wait` and present IDs allow waiting for a presentation to reach the user-facing presentation stage, enabling control of outstanding presentations. Vulkan states that the notification need not have a precise temporal relation to the first displayed pixel, though implementations should make it close.
- Vulkan swapchain-maintenance extensions add present fences, compatible dynamic present-mode selection, explicit scaling/gravity, deferred image allocation, and release of acquired images. Present fences close an otherwise difficult lifetime gap for semaphores used by presentation.
- Windows Advanced Color documentation recommends FP16 scRGB for general-purpose composited advanced-color applications and identifies RGB10/PQ/BT.2020 as a 32-bit optimization for suitable non-alpha HDR game/video cases. FP16 consumes 64 bits per pixel, twice the memory/bandwidth of a 32-bit format.
- Microsoft now warns against relying on `SetHDRMetaData`: metadata delivery is not guaranteed and displays process it inconsistently. The current recommendation is to tone-map into luminance and gamut reported by `IDXGIOutput6::GetDesc1`; color-space interpretation is set separately using `SetColorSpace1`.
- On Windows, when a window straddles displays with different Advanced Color capabilities, reported behavior follows the main display containing the window center, and DWM may downconvert content for SDR.
- DXGI `Present` can return occlusion, device-reset, or device-removed status. Microsoft DRED provides GPU auto-breadcrumbs and page-fault information after device removal, with some system-memory and object-lifecycle overhead when enabled.
- Vulkan acquire/present/wait operations can return `VK_SUBOPTIMAL_KHR`, `VK_ERROR_OUT_OF_DATE_KHR`, `VK_ERROR_SURFACE_LOST_KHR`, or `VK_ERROR_DEVICE_LOST`, requiring different scopes of response.

## 4. Industry-Standard Rendering API or Pattern

Use a capability-negotiated presentation state machine:

```text
NoSurface
  -> CreatingSurface
  -> Active
  -> OccludedOrMinimized
  -> RecreatePending
  -> Active

Any state -> DeviceFaulted -> CapturingFault -> RebuildingDevice
          -> RehydratingResources -> WarmingPipelines -> Active
          -> FatalFallback
```

The desktop frame loop should:

1. wait on the selected frame-latency/pacing primitive;
2. process window/display events and coalesce configuration changes;
3. acquire a swapchain image;
4. simulate/extract/render using an immutable surface-generation snapshot;
5. transition/resolve/encode to the swapchain image;
6. submit and present with a monotonically increasing present ID;
7. collect completion, timing, status, and fault telemetry asynchronously.

For Windows, create a windowed/borderless flip-discard swapchain, query tearing support before creation, and use a frame-latency waitable object when supported. Prefer borderless presentation as the standard path; keep exclusive fullscreen only for an evidenced platform need.

For Vulkan, query the exact surface before every creation/recreation. Map policy to supported modes: FIFO as guaranteed safe fallback; mailbox for non-tearing low-latency replacement when supported; immediate only for explicitly enabled tearing; FIFO-relaxed only as a distinct tested choice. Use present IDs/wait and swapchain-maintenance present fences where supported, otherwise conservatively bind semaphore lifetime to reacquisition of the corresponding swapchain image.

## 5. CPU, GPU, Memory, and Bandwidth Considerations

**CPU complexity, allocations, and concurrency.** Normal presentation should allocate nothing. Store fixed-capacity swapchain image records, semaphores/fences, timing records, and output descriptors. Coalesce move/resize/DPI/HDR events and rebuild once after a stable boundary. A dedicated presentation coordinator may observe events and completions, but actual surface/device mutations must serialize against render submission. Pipeline compilation and resource rehydration can run concurrently after core fallback pipelines exist.

**GPU complexity.** Presentation itself is usually dominated by final conversion/upscale/composition plus synchronization rather than draw count. The final path normally adds zero scene draws and one or more compute/fullscreen dispatches for scaling, tone mapping, gamut mapping, UI composition, dithering, and capture. Track those dispatches separately. MSAA must resolve before a DXGI flip-model present target. Avoid a redundant full-resolution copy when the render graph can write/resolve directly into an eligible swapchain image.

**VRAM and allocations.** Swapchain residency is `imageCount × width × height × bytesPerPixel`, plus any driver/compositor allocation. At 3840×2160, one 32-bit image is about 31.6 MiB while one FP16 image is about 63.3 MiB before alignment; triple buffering is roughly 94.9 versus 189.8 MiB. Resizing can temporarily overlap old/new swapchains, histories, and render-resolution targets. Budget peak transition residency, not only steady state. Vulkan deferred allocation can reduce unused image cost where supported.

**Memory bandwidth and cache behavior.** FP16 doubles swapchain read/write traffic relative to 32-bit formats. Separate render and display resolution introduces an additional source read and destination write. Fuse tone/gamut mapping, upscale/sharpen, UI where semantically valid, and dithering to reduce bandwidth. Final passes are commonly bandwidth-bound; use GPU counters rather than shader-instruction estimates. Presentable images are poor long-term cache anchors because their ownership and contents rotate.

**Synchronization.** A back buffer may be reused only after its GPU work and presentation ownership permit it. Distinguish render-complete fences from present-complete signals. Vulkan present-wait semaphores must not be recycled merely because the submitting graphics fence signaled; use present fences or swapchain-image-indexed semaphores. Device-wide idle waits during routine resize create severe stalls and frame-latency spikes; prefer generation retirement with precise fences where API/platform behavior permits.

**Pacing, batching, and frame latency.** Present queue depth is an explicit budget. One queued frame minimizes latency but can reduce CPU/GPU overlap; two may improve throughput on split CPU/GPU workloads. Unlimited producer pacing increases latency, memory pressure, and wasted work. Rendering faster than the display under FIFO can queue/stall; mailbox may discard completed frames; immediate may tear. Measure input sample to present call, GPU completion, present-visible estimate, and actual display telemetry where available.

**Streaming.** Window moves, minimize, output change, and display-mode transitions must not flush content streaming. Surface resources are a small independent residency domain. Device loss invalidates GPU residency but not CPU asset identity or cache content; rehydration prioritizes swapchain, fallback shaders, UI, camera-visible coarse geometry/textures, then quality layers.

**Shader divergence.** Presentation shaders should select SDR/scRGB/PQ paths by pipeline/permutation or uniform specialization, not per-pixel monitor branches. Keep mixed-display policy outside the shader. Test wave occupancy and cache behavior for fused conversion kernels.

## 6. Pros and Cons

**Flip model / modern swapchain**

- Pros: efficient compositor integration; HDR eligibility; waitable latency control; tearing/VRR support; present statistics; borderless fullscreen optimization.
- Cons: MSAA resolve required; buffer lifecycle differs from legacy blit paths; format/flags constrain later reconfiguration.

**FIFO/VSync**

- Pros: universal Vulkan fallback; tear-free; predictable display cadence; lower power when correctly paced.
- Cons: missed deadlines can cause cadence jumps; deep queues add latency; producer may block.

**Mailbox / low-latency non-tearing**

- Pros: newest ready frame replaces pending work; no visible tearing; good fit when rendering faster than refresh.
- Cons: rendered frames may never display, wasting GPU/power; support and image-count requirements vary; frame completion is not presentation completion.

**Immediate/allow tearing**

- Pros: low queueing delay; supports VRR policy on Windows; useful for explicit uncapped mode.
- Cons: visible tearing outside effective VRR range; higher power; user/platform policy and capture behavior vary.

**FP16 scRGB**

- Pros: broad Windows Advanced Color composition, headroom, blending, and common linear-like interchange with DWM.
- Cons: doubles swapchain VRAM/bandwidth versus 32-bit; negative/out-of-unit values require disciplined processing; SDR downconversion behavior must be tested.

**RGB10 PQ**

- Pros: 32-bit storage; direct HDR10-oriented output; lower bandwidth.
- Cons: unsuitable when alpha composition is needed; quantization and nonlinear blending constraints; explicit color-space setup; display tone mapping variability.

**Recover-in-process after device loss**

- Pros: preserves user session and diagnostic context; avoids restart for transient driver/display failures.
- Cons: complex ownership reset; latent CPU pointers to invalid GPU objects; pipeline warm-up hitch; recovery cannot be guaranteed for repeated hardware/driver failure.

## 7. ECS and Render-World Integration

Presentation state is not ECS gameplay state. Extract a small immutable `PresentationSnapshot` into the render world:

- surface generation and status;
- logical window size, drawable extent, DPI/rotation;
- selected adapter/output identity;
- swapchain format/color space/present policy;
- HDR luminance/gamut capability and user paper-white/max-output settings;
- render scale, display transform, and frame-latency target.

Camera projection uses the drawable/render extent from that snapshot. Both first- and third-person cameras invalidate aspect-ratio-dependent projection and temporal histories when the effective render extent or orientation changes. They do not own swapchain recreation.

On device loss, freeze or continue simulation according to application policy, but never retain render-world GPU handles. ECS entities, transforms, camera modes, quests, and save data persist. The renderer increments `DeviceGeneration`; every GPU handle, bindless index allocation, PSO, descriptor heap/pool, query heap, swapchain, and temporal history belongs to one generation. Stale generations fail validation rather than dereferencing destroyed devices.

## 8. Resource, Pass, Material, and Visibility Interfaces

```text
PresentationPolicy {
  pacingMode, allowTearing, preferVrr, maxFramesQueued,
  fullscreenMode, renderScalePolicy, hdrPolicy
}

PresentationCapabilities {
  formats[], colorSpaces[], presentModes[],
  tearingSupported, waitablePresent, presentWait,
  presentFence, scalingModes[], minMaxImageCount,
  currentExtent, hdrDisplayDesc
}

PresentationSurface {
  surfaceGeneration, deviceGeneration, state,
  swapchain, images[], extent, format, colorSpace,
  presentMode, imageCount, outputIdentity
}

PresentRecord {
  frameId, presentId, surfaceGeneration,
  acquireCpu, submitCpu, presentCpu, gpuComplete,
  visibleEstimate, status, syncInterval, flags
}

DeviceFaultRecord {
  api, adapter, driver, reason, lastFrameId,
  breadcrumbs, pageFault, debugMessages,
  residentResourceManifest, recentPresentRecords
}
```

The render graph imports the acquired swapchain image with a surface/device generation, required initial/final state, ownership, and color encoding. A `DisplayEncodePass` consumes scene-linear output and monitor/profile settings and produces the selected swapchain encoding. UI declares whether it is composed scene-linearly before display encoding or supplied already referenced to display luminance.

Materials never inspect monitor state. Visibility and scene draws are independent of presentation except through render extent/dynamic resolution. Capture interfaces tag whether a dump is pre-tone-map scene-linear, post-tone-map display-linear, or exact swapchain encoded.

## 9. Asset and Runtime Integration Plan

1. Introduce the presentation state machine and generation-tagged handles without changing output.
2. Implement DXGI flip-discard plus tearing capability query and waitable latency control. Implement Vulkan FIFO baseline with correct image-indexed present synchronization.
3. Add a policy mapper that selects only supported modes and records the exact effective result.
4. Separate render-size resources from swapchain extent; implement fused upscale/display encoding and an explicit no-scaling path.
5. Connect OS window/display notifications. Debounce resize/move events, pause expensive rendering while minimized/occluded, and re-query capabilities after output migration.
6. Implement SDR8, FP16 scRGB, and RGB10 PQ output contracts. Reuse the existing exposure/tone-mapping system; retrieve current display luminance/gamut and avoid depending on HDR metadata.
7. Add present IDs/completion telemetry and platform-specific latency instrumentation.
8. Implement surface-only rebuild first, then full device-loss recovery with `DeviceGeneration`, CPU asset registry rehydration, fallback pipelines, and progressive quality restoration.
9. Enable DRED/debug breadcrumbs in development and configurable diagnostic cohorts; capture bounded fault packages before destroying the failed device.
10. Add repeated-failure policy: one controlled retry on the same adapter, then safer format/features or alternate adapter where valid, then a clear fatal path.

## 10. Visual and Performance Verification Strategy

Test Windows D3D12 and Vulkan across windowed, borderless, and any retained exclusive mode; SDR/HDR; 8-bit/10-bit/FP16; VSync/VRR/tearing; double/triple buffering; 60/120/144/variable refresh; integrated/discrete/multi-adapter; single/mixed-HDR multi-monitor; and first-/third-person cameras.

Visual tests:

- gradients, near-black detail, saturated primaries, paper white, specular peaks, UI white, alpha, and dithering;
- drag a window across SDR/HDR and differently scaled/rotated displays, including straddling the boundary;
- resize continuously, minimize/restore, change DPI, toggle HDR, hot-plug output, sleep/wake, remote-session change, and fullscreen transitions;
- compare captured pre-encode, post-encode, and exact swapchain outputs with known color patches;
- verify no stale borders, stretching, one-frame old extent, temporal-history smear, or UI scale jumps.

Performance instrumentation must include CPU wait/acquire/build/submit/present/event/recreate time; GPU display-encode/copy/resolve time; scene draw and final dispatch counts; allocations; old/new swapchain peak VRAM residency; presentation and final-pass bandwidth; cache counters; shader occupancy/divergence; queue depth; frames acquired/submitted/presented/replaced/dropped; present-mode changes; synchronization waits; streaming continuity; input-to-present latency; present-to-visible estimate; deadline misses; and CPU/GPU concurrency.

Automated pacing tests should graph frame-time intervals and latency percentiles, detect FIFO sawtooth/cadence errors, verify VRR operation within the monitor range using external/present telemetry when available, and distinguish CPU, GPU, compositor, and display-bound stalls.

Fault injection:

- resize/out-of-date and surface-lost results at every acquire/present boundary;
- simulated device removal after each major pass and queue submission;
- invalid shader, page-fault test in controlled development builds, allocation failure, adapter disable, driver reset, and output removal;
- assert one fault owner, bounded waits, complete fault record, no stale-generation use, deterministic rebuild order, and restored visual baselines;
- soak repeated device/surface recreation while streaming and compiling pipelines.

## 11. Platform and Scalability Risks

- “VSync off,” tearing, and VRR are not synonyms. Effective behavior depends on OS compositor path, fullscreen mode, monitor range, driver, flags, and present mode.
- Presentation-mode support and minimum image count are surface-specific and can change after display/window events.
- A window crossing outputs has one swapchain but potentially conflicting HDR, gamut, refresh, scale, and rotation capabilities. Select a documented primary-output rule and update atomically.
- HDR metadata may be ignored; display-reported luminance may also be imperfect. Preserve calibration controls and safe tone-map defaults.
- FP16 can materially increase VRAM and bandwidth at 4K/8K. RGB10 PQ has composition/alpha and nonlinear-processing constraints.
- Queue depth that improves throughput can worsen input latency. Mailbox can waste entire rendered frames; tearing can become visible below/outside VRR range.
- Present completion is not graphics-fence completion. Incorrect semaphore reuse can be intermittent and driver-dependent.
- Resize recreation can double peak swapchain memory and collide with streaming residency budgets.
- Device recovery is not guaranteed. Driver bugs may recur immediately; adapter migration can invalidate feature/format assumptions and shader caches.
- Laptop hybrid-GPU/output topology, remote desktop, capture/overlay software, and HDR desktop state can change the compositor path and pacing.

Scalability should vary final output format, render resolution, frame queue depth, present mode, UI composition path, and optional display filters independently. Presentation changes must never silently change scene exposure semantics.

## 12. Engineering Recommendations

These are engineering recommendations:

1. Make presentation a generation-safe subsystem with an explicit state machine, capability snapshot, policy mapper, and telemetry.
2. Use DXGI flip-discard for Windows desktop and Vulkan FIFO as the universal fallback. Select mailbox/immediate/tearing only when supported and requested.
3. Query tearing before swapchain creation; creation-time flags are immutable across resize. Treat VRR as a verified operating mode, not a checkbox inferred from “VSync off.”
4. Default the queued-frame budget to one for low-latency modes, with a measured option for two where CPU/GPU overlap is necessary. Never allow unbounded producer queueing.
5. Separate render extent from swapchain extent. Fuse upscale, tone/gamut mapping, and dithering where quality permits to reduce dispatches and bandwidth.
6. Keep scene-linear rendering output-independent. Choose SDR8, FP16 scRGB, or RGB10 PQ at the display boundary and re-query when the window's primary output changes.
7. Follow current Windows guidance: tone-map to reported gamut/luminance and do not rely on HDR metadata delivery. Store exact effective format, color space, display descriptor, and paper-white policy in captures.
8. Use precise present-lifetime synchronization: waitable objects/present IDs on Windows as applicable; present wait/fences or swapchain-image-indexed semaphores on Vulkan.
9. Distinguish `Suboptimal`, `OutOfDate`, `SurfaceLost`, `Occluded`, and `DeviceLost`. Rebuild only the narrowest valid scope.
10. On device loss, capture DRED/Vulkan fault diagnostics before teardown, increment `DeviceGeneration`, recreate core presentation and fallback pipelines, then progressively rehydrate visible resources.
11. Preserve ECS/game state across renderer recovery and validate every GPU-facing handle against its device generation.
12. Keep unresolved decisions explicit: supported OS/API floor; borderless versus exclusive policy; default VSync/VRR mode; queue-depth thresholds; render/display scaling ownership; SDR/HDR formats; paper white and calibration; primary-output rule; event debounce; fault diagnostic level; retry/adapter fallback; and recovery-time/peak-VRAM budgets.

## 13. Source Links

- [Microsoft: For best performance, use DXGI flip model](https://learn.microsoft.com/en-us/windows/win32/direct3ddxgi/for-best-performance--use-dxgi-flip-model)
- [Microsoft: DXGI swap effects](https://learn.microsoft.com/en-us/windows/win32/api/dxgi/ne-dxgi-dxgi_swap_effect)
- [Microsoft: DXGI Present](https://learn.microsoft.com/en-us/windows/win32/api/dxgi/nf-dxgi-idxgiswapchain-present)
- [Microsoft: DXGI swapchain flags](https://learn.microsoft.com/en-us/windows/win32/api/dxgi/ne-dxgi-dxgi_swap_chain_flag)
- [Microsoft: SetMaximumFrameLatency](https://learn.microsoft.com/en-us/windows/win32/api/dxgi1_3/nf-dxgi1_3-idxgiswapchain2-setmaximumframelatency)
- [Microsoft: GetFrameLatencyWaitableObject](https://learn.microsoft.com/en-us/windows/win32/api/dxgi1_3/nf-dxgi1_3-idxgiswapchain2-getframelatencywaitableobject)
- [Microsoft: Advanced Color and HDR with DirectX](https://learn.microsoft.com/en-us/windows/win32/direct3darticles/high-dynamic-range)
- [Microsoft: SetHDRMetaData current guidance](https://learn.microsoft.com/en-us/windows/win32/api/dxgi1_5/nf-dxgi1_5-idxgiswapchain4-sethdrmetadata)
- [Microsoft: DXGI multi-monitor best practices](https://learn.microsoft.com/en-us/windows/win32/direct3darticles/dxgi-best-practices)
- [Microsoft: Use DRED to diagnose GPU faults](https://learn.microsoft.com/en-us/windows/win32/direct3d12/use-dred)
- [Khronos: Vulkan present modes](https://docs.vulkan.org/refpages/latest/refpages/source/VkPresentModeKHR.html)
- [Khronos: VK_KHR_present_wait](https://docs.vulkan.org/refpages/latest/refpages/source/VK_KHR_present_wait.html)
- [Khronos: Vulkan swapchain-maintenance proposal](https://docs.vulkan.org/features/latest/features/proposals/VK_EXT_swapchain_maintenance1.html)
- [Khronos: Vulkan swapchain semaphore reuse](https://docs.vulkan.org/guide/latest/swapchain_semaphore_reuse.html)
- [Khronos: VK_EXT_hdr_metadata](https://docs.vulkan.org/refpages/latest/refpages/source/VK_EXT_hdr_metadata.html)
