# Operation Mythology Graphics Research Report

**Timestamp:** 2026-07-27 01:49:09 America/Los_Angeles  
**Subject:** Scalable shadow architecture for directional and local lights  
**Status:** New architectural baseline  
**Assumptions:** Modular D3D12/Vulkan renderer, data-oriented scene representation, explicit render-world extraction, GPU-driven visibility, first- and third-person cameras, and no production-code implementation in this report.

## 1. Feature Overview

Real-time shadows answer whether and how much a light is occluded at a visible surface. A scalable engine must support:

- directional-light shadows over large worlds;
- point- and spot-light shadows with bounded per-light cost;
- hard and soft shadow appearance;
- static, rigid, skinned, masked, and vertex-deformed casters;
- cached and newly visible shadow data;
- graceful operation without hardware ray tracing;
- optional ray queries for contact refinement or soft shadows;
- independent quality policies for main, reflection, stereo, and editor views.

The key architectural problem is allocation. Conventional fixed-resolution cascades or per-light atlases reserve work for regions that may not affect visible pixels. Virtual shadow maps instead allocate small shadow-depth pages based on visible receiver demand and cache those pages across frames. Ray-traced shadows avoid a shadow atlas but replace raster cost with acceleration-structure maintenance, traversal, stochastic sampling, and denoising.

**Engineering recommendation:** Use a hybrid, tiered shadow system:

1. virtualized raster shadow maps as the high-end default for opaque directional and local lights;
2. conventional cascaded/atlas shadow maps as the compatibility and low-memory path;
3. optional inline ray queries for selected contact, penumbra, or high-value lights;
4. baked/static shadowing and non-shadowed light tiers for constrained platforms and distant content.

Virtual pages, ray queries, and denoisers should share light, caster, receiver, temporal, and quality contracts rather than becoming separate renderer silos.

## 2. Existing Coverage and Identified Gap

The required recursive scan of `C:\Users\steve\Desktop\GAME SKILLS` found baselines for:

- GPU-driven indirect submission and bindless resources;
- render-graph synchronization and transient aliasing;
- visibility/deferred/Forward+ shading;
- GPU memory residency and streaming;
- virtual geometry and virtual textures;
- archetype ECS/job scheduling;
- temporal upscaling and motion-vector contracts.

The new dedicated folder `C:\Users\steve\Desktop\EXTRA SKILS\3D Graphics Rendering Shaders` contained no prior reports at the start of this batch.

Existing work provides the required GPU render world, clustered light database, page scheduler concepts, stable handles, temporal histories, and render-graph ownership. It does not decide:

- directional clipmaps versus fixed cascades;
- local-light shadow page allocation and prioritization;
- receiver-driven page marking;
- cache invalidation for moving, skinned, masked, or world-position-offset casters;
- page overflow and fallback behavior;
- shadow filtering and bias policy;
- when ray queries replace or refine raster shadows;
- acceleration-structure and denoiser costs;
- ECS/render-world interfaces for shadow policy and invalidation.

This report fills that uncovered dependency.

## 3. Sourced Facts

The following are sourced facts; recommendations appear in later sections.

1. Epic documents virtual shadow maps as high-resolution virtualized shadow depth maps divided into 128×128 pages. Pages are allocated from visible receiver demand, cached between frames, and redrawn when invalidated [1][2].
2. Epic uses clipmaps for directional virtual shadows and mip selection for local lights. Its documentation identifies light movement, caster movement/add/remove, and position-modifying materials such as world-position offset as common cache invalidation sources [1].
3. Epic's published diagnostics separate allocated, cached, cleared, and invalidated pages and warn that high page counts plus frequent invalidation lead to poor shadow-depth performance [1].
4. The Nanite SIGGRAPH presentation describes allocating virtual shadow pages by projecting visible pixels into each affecting light's shadow space and selecting a mip where approximately one shadow texel corresponds to one screen pixel [2].
5. DirectX Raytracing Tier 1.1 supports inline ray queries from existing shader stages. Microsoft's functional specification describes an opaque, accept-first-hit query as a basic shadow-determination use case, while noting that inline query state can consume significant registers and coherence strongly affects performance [3].
6. Khronos `VK_KHR_ray_query` exposes ray queries to graphics, compute, and ray-tracing shader stages without launching separate hit shaders. The official sample demonstrates first-hit shadow testing against an acceleration structure [4][5].
7. AMD's FidelityFX Shadow Classifier divides the screen into 8×4 tiles, rejects pixels using depth, normals, and cascaded shadow information, and emits compact tile/ray masks and ray intervals for a later ray-tracing pass [6].
8. AMD's Hybrid Shadows sample combines raster shadow maps, hardware ray tracing, classification, and a shadow denoiser; AMD documents D3D12 and Vulkan support for the sample [7].
9. NVIDIA NRD includes SIGMA shadow denoisers for infinite and local lights and requires temporal/spatial inputs and history management appropriate to denoising [8].

**Cross-source conclusion:** Receiver-driven virtual pages reduce unused raster work, but their success depends on caching and precise invalidation. Ray queries are a complementary path whose cost depends on acceleration structures, ray coherence, classification, and denoising; they are not a universal replacement for shadow maps.

## 4. Industry-Standard Rendering API or Pattern

### Shared light and shadow selection

Clustered lighting first identifies lights affecting visible pixels. A GPU shadow-selection/classification stage then chooses per light or per receiver tile:

- unshadowed;
- baked/static;
- cached virtual shadow;
- newly rasterized virtual shadow;
- conventional map fallback;
- ray-query refinement;
- fully ray-traced and denoised.

The selection uses light importance, projected influence, penumbra target, caster dynamics, platform tier, current cache pressure, and measured cost.

### Virtual shadow map pattern

1. Import depth/visibility and clustered light lists.
2. For each visible receiver tile/pixel and relevant light, project the receiver into light space.
3. Choose directional clipmap level or local-light mip from projected footprint.
4. Mark required virtual pages in GPU bitsets.
5. Add conservative neighboring pages required by filtering and guard bands.
6. Resolve virtual-to-physical mappings; allocate missing pages from the physical pool.
7. Build per-page caster lists using light-space bounds, GPU instance data, and page masks.
8. Rasterize only new or invalidated pages using indirect draws/meshlet lists.
9. Publish page-table entries after depth writes complete.
10. Sample and filter virtual shadow data during lighting.
11. Retain mappings and content until invalidation or eviction policy removes them.

Directional lights use camera-relative clipmaps with stable snapping to limit page churn. Spot lights use perspective maps. Point lights use a cube/octahedral representation or six faces; the chosen layout must be hidden behind the same page-table interface.

### Cache invalidation

Maintain two concepts:

- **mapping validity:** the virtual page points to a live physical slot;
- **content validity:** the stored depth still represents every relevant caster.

Generate invalidation records from render-world changes:

- light transform/projection change;
- caster bounds change;
- caster created, removed, enabled, disabled, streamed, or changes shadow material;
- skinned/deformed bounds or vertex-animation epoch change;
- world-origin rebase not absorbed by camera-relative coordinates;
- shadow LOD/culling policy change.

Project changed caster bounds into affected light/page space on the GPU. Avoid invalidating an entire light unless its transform or projection truly changes.

### Ray-query path

For selected receiver pixels:

1. reconstruct position and normal;
2. classify whether a ray is required;
3. compute a conservative origin, `TMin`, direction, and `TMax`;
4. issue opaque first-hit inline ray queries when material semantics permit;
5. handle alpha-tested/translucent cases through opacity micromaps, any-hit-equivalent candidate handling, or raster fallback;
6. pack binary/visibility results compactly;
7. denoise only classified tiles when stochastic soft shadows are used.

Use the same TLAS instance IDs, visibility masks, and generation-checked render-world handles as reflections/GI where feasible.

## 5. CPU, GPU, Memory, and Bandwidth Considerations

### Complexity

Let `P` be visible pixels/tiles, `K` average relevant lights per receiver cluster, `V` required virtual pages, `I` invalidated pages, `C` caster/page associations, and `R` shadow rays:

- page marking: approximately **O(P × K)**, bounded by clustered-light occupancy;
- bitset compaction/allocation: **O(pageWords)** or **O(V)** with hierarchical dirty blocks;
- caster binning: approximately **O(C)** after broad light/caster rejection;
- virtual-page rasterization: proportional to geometry overlapping `new + I` pages, not total shadow-map capacity;
- sampling/filtering: **O(P × K × taps)** for shadowed lights;
- ray-query work: traversal-dependent, approximately **O(R × traversal cost)**;
- temporal/spatial denoising: normally **O(Pd)** over classified or display-resolution tiles with bounded kernels.

Worst cases remain severe: many overlapping shadowed lights, large invalidating bounds, camera cuts, moving sun/light transforms, and fully dynamic foliage can make most pages new every frame.

### CPU and allocations

- The CPU updates dirty light/caster records in **O(D)** and submits pass/pipeline classes, not one draw per page or light.
- GPU compaction must produce page draws and indirect counts without frame-critical readback.
- Use persistent light, page-table, cache metadata, and invalidation buffers.
- Use frame arenas for pass parameters and bounded GPU/CPU overflow records.
- Do not allocate per light-page association from the general heap.
- Shadow PSOs and material variants must be compiled and cached outside first use.

### Draw and dispatch counts

Target:

- one/few page-mark and compact dispatches across all active views;
- one allocation/eviction dispatch;
- one caster-bin dispatch;
- indirect raster batches by shadow pipeline class, not by page;
- one/few filter/classifier/denoiser dispatches;
- a compact ray-query dispatch for selected tiles.

Multi-view rendering or mesh shaders may render one caster into several compatible pages per task, but this is a benchmark-gated optimization.

### VRAM

For a 16-bit depth pool, each 128×128 page contains 32 KiB before alignment or metadata. A 4096-page pool therefore contains about 128 MiB of raw depth. Double static/dynamic caches, page tables, page masks, caster lists, ray results, denoiser histories, and driver alignment add more.

**Recommendation:** Budget shadows by physical pages, not virtual resolution. Report:

- physical pool bytes;
- mapped, cached, invalidated, and evicted pages;
- page-table/mask/list bytes;
- acceleration-structure bytes attributable to shadow-capable geometry;
- denoiser persistent/transient bytes.

Page tables and current-frame work lists can often be compact integer buffers. Persistent page depth and denoiser histories cannot be transiently aliased while cached.

### Bandwidth, caches, and overdraw

- Cached pages avoid shadow raster traffic but still incur page-table and depth sampling.
- New pages require clearing/writing depth and reading caster vertices/indices.
- Fine alpha-tested foliage creates heavy shadow overdraw and texture bandwidth.
- Wide PCF/PCSS filters multiply random depth reads and require guard-page allocation.
- Sorting page work by light, physical locality, pipeline, and material can improve cache reuse.
- Front-end triangle cost can dominate shadow rasterization; shadow-specific LOD and meshlet culling are mandatory.

### Divergence and occupancy

- Variable filter widths, blocker searches, and light types cause wave divergence.
- Inline `RayQuery` objects may consume substantial registers; avoid embedding several simultaneous queries in an already register-heavy lighting uber-shader.
- Prefer classified compute workloads with coherent light/ray types over unconditional per-light inline queries.
- Alpha candidate processing and procedural geometry increase divergence; use separate capability/material classes.

### Synchronization, concurrency, and latency

- Page marking reads depth/light lists; allocation writes mappings; page raster reads mappings and caster lists; lighting reads depth pages.
- Acceleration-structure build/update must complete before shadow ray queries.
- Cross-queue async compute only helps when page marking/classification overlaps independent raster work without delaying page raster or lighting.
- Cache reuse reduces frame latency variance; cache misses and camera cuts must be visible in tail metrics.
- Never wait on CPU page counts or ray counts. Use indirect dispatch/draw arguments.

## 6. Pros and Cons

### Virtual shadow maps

**Pros**

- Allocate resolution from visible receiver demand.
- Cache static and unchanged depth across frames.
- Share a physical budget among many lights.
- Fit GPU-driven geometry and virtualized assets.
- Support high near-camera detail without permanently enormous maps.

**Cons**

- Cache invalidation can erase the benefit in dynamic scenes.
- Filtering across unmapped pages and clipmap/mip boundaries is complex.
- Page-table, mask, and physical-pool memory is substantial.
- Overflow needs explicit degradation rather than corruption.
- Directional, spot, and point projections require different mapping details.

### Conventional cascades/atlases

**Pros**

- Mature, broadly supported, simple to capture/debug.
- Predictable memory and draw structure.
- Suitable for low-end, mobile, VR/MSAA, and compatibility paths.

**Cons**

- Wastes resolution outside visible receiver demand.
- Atlas fragmentation and per-light resolution policy are difficult.
- Cascades exhibit transitions and perspective aliasing.
- Many local lights multiply raster passes and draw submission.

### Ray-traced shadows

**Pros**

- Natural contact and area-light visibility.
- No shadow-depth atlas for selected lights.
- Can query current geometric visibility at the receiver.

**Cons**

- Requires acceleration-structure memory/builds and supported hardware.
- Stochastic soft shadows need temporal/spatial denoising.
- Incoherent rays, alpha geometry, and large scenes are expensive.
- Adds histories, disocclusion handling, latency, and provider variation.

## 7. ECS and Render-World Integration

### ECS-facing components

- `LightComponent`: type, color/intensity, range/shape, logical shadow policy, importance, channel mask.
- `RenderableComponent`: logical mesh/material handles and shadow-cast/receive flags.
- `ShadowImportanceComponent`: optional authored override, used sparingly.
- `CameraComponent`: renderer-neutral view and scalability policy.

Do not store page IDs, physical slots, atlas rectangles, API acceleration structures, cache-valid bits, or backend shadow modes in ECS.

### Render extraction

Dirty extraction produces renderer-owned:

- stable `RenderLightId` and generation;
- light projection/bounds and current/previous transform;
- shadow technique eligibility and quality ceiling;
- stable caster instance ID;
- current/previous conservative caster bounds;
- shadow material class: opaque, masked, deforming, translucent, non-caster;
- deformation/invalidation epoch;
- per-view importance.

The renderer compares extracted generations/epochs to emit compact invalidation records. The ECS does not iterate lights to invalidate pages.

### Render-world ownership

The shadow system owns light page tables, physical pools, invalidation queues, caster bins, TLAS references, and denoiser histories. It consumes immutable render-world snapshots and returns shadow visibility resources/interfaces to lighting passes.

## 8. Resource, Pass, Material, and Visibility Interfaces

### `ShadowPolicy`

- preferred technique and allowed fallbacks;
- resolution/error target;
- maximum physical page/ray budget;
- cache priority;
- update frequency ceiling;
- soft-source angular/radius parameter;
- static/dynamic caster inclusion;
- main/reflection/stereo view weights.

### Graph resources

- `ShadowPageRequests`
- `ShadowPageTableCurrent`
- `ShadowPhysicalDepthPool`
- `ShadowPageMetadata`
- `ShadowInvalidationRecords`
- `ShadowCasterPageLists`
- `ShadowIndirectArgs`
- optional `ShadowRayTileList`
- optional `ShadowRayHitMask`
- optional denoiser history/output

Persistent cache resources are imported. Request lists, compaction buffers, indirect arguments, and some classifier outputs are transient.

### Material interface

Shadow material compilation exposes only required opacity/deformation behavior:

- fully opaque depth-only;
- alpha-tested with a minimal opacity evaluator;
- two-sided;
- vertex-deformed with current shadow position;
- ray-query opaque eligible;
- opacity-micromap eligible;
- raster-only fallback;
- no shadow.

Share deformation and opacity logic with primary visibility through generated functions. Avoid a hand-maintained shadow shader that can diverge from visible geometry.

### Visibility interface

GPU visibility supplies caster candidates, LOD/meshlet data, and stable IDs. Shadow selection supplies receiver-driven page/light demand. The intersection of these sets produces page work; neither system owns the other's internal data.

## 9. Asset and Runtime Integration Plan

1. Define the shared light/shadow policy and compatibility shadow-atlas path.
2. Add shadow-specific GPU-driven caster culling, LOD, indirect submission, and masked-material variants.
3. Implement directional cascades as a correctness reference with stable snapping and debug views.
4. Implement a physical page pool, page table, receiver-driven marking, and a single spot-light virtual map.
5. Add cache generations, fence-safe slot reuse, invalidation projection, and overflow telemetry.
6. Add directional clipmaps and local-light mip selection.
7. Add point-light projection and multi-light global page prioritization.
8. Separate static and dynamic page content only if measurements justify the additional memory and merge work.
9. Add filtering tiers: hard compare, compact PCF, and controlled contact-hardening/soft path with guard pages.
10. Integrate shadow page/caster priorities with virtual geometry residency and the GPU memory service.
11. Add D3D12/Vulkan ray-query capability paths, shared acceleration-structure instances, tile classification, and optional shadow denoising.
12. Cook opacity micromaps or equivalent compact alpha data only for content/hardware where traversal benefit is demonstrated.
13. Establish per-platform presets and fallback ladders before content authoring depends on one technique.

## 10. Visual and Performance Verification Strategy

### Correctness

- Compare virtual and conventional maps against a high-resolution raster reference.
- Test clipmap/mip boundaries, page borders, point-light seams, and filter guard pages.
- Move/add/remove casters and lights; every affected page must invalidate, while unrelated pages remain cached.
- Test skinned characters, foliage wind, vertex displacement, alpha cutouts, negative scale, LOD transitions, streamed pages, and origin rebasing.
- Poison retired pages and validate generation mismatches.
- Force page/request/caster-list overflow and verify deterministic fallback.
- Compare ray-query hit/miss against raster reference for opaque geometry.

### Artifact corpus

- sun at grazing and overhead angles;
- first-person weapon/arms near the camera;
- third-person character self-shadowing;
- dense forest and grass;
- thin fences and wires;
- large interiors with many spot/point lights;
- camera cuts, teleports, rapid rotation, doors, and destruction;
- large soft lights and contact shadows;
- high-speed animated/skinned crowds.

Track acne, peter-panning, light leaks, detached contacts, temporal boiling, cache pop, penumbra instability, and cross-technique transitions.

### Performance

Record per view and light class:

- CPU extraction/submission and allocations;
- page-mark, allocation, binning, raster, filter, ray, and denoiser GPU time;
- draws, indirect commands, dispatches, rays, and acceleration-structure builds/updates;
- required/new/cached/invalidated/evicted pages;
- caster-page associations and culled casters;
- shadow triangles, alpha-tested samples, overdraw, vertex/index traffic;
- physical/persistent/transient VRAM;
- page-table/filter bandwidth and cache counters;
- ray-query occupancy, register pressure, divergence, traversal steps where available;
- barriers, cross-queue waits, idle time, end-to-end frame latency, and 1%/0.1% tails.

Benchmark static, lightly dynamic, foliage-heavy, fully dynamic, many-local-light, and camera-cut scenes. Compare conventional, virtual, ray-query, and hybrid modes at matched visual targets.

### Acceptance gates

- No invalid page access or corrupt output under pool pressure.
- Static views converge to high cache reuse and negligible page redraw.
- Dynamic invalidation is spatially bounded and attributable in diagnostics.
- No frame-critical CPU readback.
- No steady-state general-heap allocation.
- Compatibility shadow mode remains correct on non-ray-tracing hardware.
- Ray/hybrid mode must improve a declared quality metric or frame time on representative hardware; capability alone is not approval.

## 11. Platform and Scalability Risks

- Tile-based/mobile GPUs may favor conventional atlases, baked lighting, and tightly grouped render passes over desktop-style virtual pages.
- Forward/MSAA and VR paths may require conventional maps or reduced filtering because virtual shadow sampling and temporal denoisers may not fit.
- Physical page size and depth format interact with backend allocation granularity and cache behavior.
- Many overlapping local lights inflate receiver page requests even when caster counts are low.
- Dynamic foliage can continuously invalidate large projected regions.
- Large penumbra filters need neighboring page data and can defeat sparse allocation.
- Hardware ray tracing support, traversal rate, opacity behavior, and acceleration-structure build cost vary widely.
- TLAS/BLAS memory competes with virtual geometry, textures, histories, and render targets.
- Vendor denoisers have input, history, licensing, and version-update obligations.
- Bias values are not globally portable across projection, depth precision, normal maps, and scale; use bounded per-technique policy and automated scenes.

## 12. Engineering Recommendations

1. Build a unified shadow service, not independent sun, local, ray-traced, and baked systems.
2. Ship conventional cascades/atlases first as reference and compatibility.
3. Make receiver-driven virtual pages the high-end raster destination.
4. Use stable directional clipmaps, local-light mips, and a single physical page budget.
5. Treat content invalidation as first-class telemetry. Cache hit rate is a shadow quality/performance feature.
6. Generate page work and indirect draws on the GPU; never read counts back to the CPU.
7. Use shadow-specific geometry LOD/culling and minimal generated opacity/deformation shaders.
8. Reserve explicit page and work-list overflow behavior: lower resolution, drop low-priority local shadows, fall back to cached/coarser data, or mark a light unshadowed.
9. Add ray queries only through classification and per-platform budgets. Prefer opaque first-hit queries; keep complex alpha/translucency on measured paths.
10. Share acceleration structures with reflections/GI when lifetimes and masks align, but account for their update cost separately.
11. Denoise stochastic shadows with the existing temporal contract: motion, depth, normals, disocclusion, per-view histories, and reset reasons.
12. Gate static/dynamic cache splitting, multi-view page rendering, soft filters, opacity micromaps, and async compute on captured evidence.

### Remaining open decisions

- Physical page size, depth format, and page-pool budget per platform.
- Directional clipmap count, extent progression, and snapping policy.
- Spot and point-light virtual projection/layout.
- Static/dynamic cache split and merge strategy.
- Shadow filtering tiers, guard-page dilation, and bias policy.
- Maximum shadowed local lights and per-light/cluster priority.
- Deforming foliage invalidation granularity.
- Ray-query hardware floor, classifier threshold, and denoiser choice.
- Acceleration-structure ownership shared with GI/reflections.
- VR/MSAA shadow path and multi-view cache-sharing rules.

## 13. Source Links

1. Epic Games, **Virtual Shadow Maps in Unreal Engine 5.8**: https://dev.epicgames.com/documentation/en-us/unreal-engine/virtual-shadow-maps-in-unreal-engine
2. Brian Karis et al., Epic Games, **Nanite: A Deep Dive, SIGGRAPH 2021**: https://advances.realtimerendering.com/s2021/Karis_Nanite_SIGGRAPH_Advances_2021_final.pdf
3. Microsoft, **DirectX Raytracing Functional Specification**: https://microsoft.github.io/DirectX-Specs/d3d/Raytracing.html
4. Khronos, **VK_KHR_ray_query Reference**: https://docs.vulkan.org/refpages/latest/refpages/source/VK_KHR_ray_query.html
5. Khronos, **Vulkan Basic Ray Queries Sample**: https://docs.vulkan.org/samples/latest/samples/extensions/ray_queries/README.html
6. AMD GPUOpen, **FidelityFX Classifier 1.3 — Shadow Classifier**: https://gpuopen.com/manuals/fidelityfx_sdk/techniques/classifier/
7. AMD GPUOpen, **FidelityFX Hybrid Shadows**: https://gpuopen.com/manuals/fidelityfx_sdk/fidelityfx_sdk-page_samples_hybrid-shadows/
8. NVIDIA, **NVIDIA Real-Time Denoisers (NRD), SIGMA Shadow Denoiser**: https://github.com/NVIDIA-RTX/NRD

