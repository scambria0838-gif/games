# Operation Mythology Graphics Research — Baked Lighting, Probes, Reflection Captures, and Area Lights

**Timestamp:** 20260727-022738  
**Scope:** Static/stationary/movable lighting policy, lightmap baking/runtime sampling, volumetric/light probes, reflection captures, mixed-light invalidation, world-partition streaming, rectangular/polygonal area-light shading, shadow approximations, memory/bandwidth, and scalability.  
**Assumptions:** Modular data-oriented engine; explicit render-world extraction; existing dynamic GI/reflection/shadow systems; physical light units; first- and third-person cameras; no production-code implementation.

## 1. Feature Overview

Operation Mythology needs a precomputed-lighting tier for hardware and content where fully dynamic GI is too expensive or unnecessary. The tier should not be a disconnected legacy renderer. It should share the same physical light/material definitions, render-world light database, probes, exposure, world streaming, and verification references as dynamic lighting.

The practical system combines:

- surface lightmaps for static geometry;
- volumetric or tetrahedral irradiance probes for dynamic objects and fog;
- reflection captures for rough/specular environment fallback;
- baked direct/indirect/shadow masks according to light mobility;
- analytic real-time direct lighting for movable objects and changeable lights;
- LTC-class rectangular/polygonal area-light BRDF integration;
- capability-selected shadowing that is clearly separate from area-light BRDF evaluation.

## 2. Existing Coverage and Identified Gap

The recursive scan found hybrid real-time GI/reflections, virtual shadows, clustered/many-light rendering, physical exposure, world partition, streaming/residency, asset cooking, and profiling. Those reports define dynamic solutions but do not establish a baked-lighting pipeline, mixed-light ownership, runtime probe/capture interfaces, or area-light approximation policy.

The newly added world-partition report establishes transactional cell activation and recommends lighting/probe/reflection sections, but it does not define their formats or rendering semantics. This report supplies that missing graphics contract without repeating the world-streaming state machine.

## 3. Sourced Facts

The following are sourced facts:

- Epic's Lightmass computes surface lightmaps containing diffuse interreflection, shadowing, and area-shadow effects for static geometry; baked static lights have no ongoing dynamic-light runtime cost.
- Epic GPU Lightmass path traces lighting in lightmap texture space, supports full and view-prioritized tile baking modes, uses virtual-texture tiles for interactive display, and performs encoding/denoising work after rendering.
- Epic requires unique non-overlapping lightmap UV charts inside 0–1 and sufficient per-object lightmap resolution.
- Epic notes that reducing a three-dimensional volumetric-lightmap cell size by half can increase memory by as much as eight times.
- Epic Volumetric Lightmaps use adaptive 4×4×4-cell bricks, add density near static geometry, store third-order spherical harmonics, and interpolate indirect lighting per pixel on the GPU for dynamic objects and volumetric fog.
- Epic reports that denser volumetric lightmaps improve leaking/detail but can materially increase memory; it also documents streaming constraints requiring participating levels to be built together in its implementation.
- Epic reflection captures provide prefiltered environment cubemaps and spatial influence; smaller captures can override larger captures. Epic uses baked lightmap data to reduce reflection leaking on rough surfaces.
- Epic documents a limitation for lit translucency where only one reflection capture is applied, causing transitions to pop instead of blending.
- Epic rectangular lights bake true multi-sample area behavior for static/stationary lighting, while a movable rectangular light may use the rectangle mainly for specular shape and emit direct diffuse light from its center in some paths.
- Heitz, Dupuy, Hill, and Neubelt's LTC method approximates a BRDF lobe with a linearly transformed cosine and analytically integrates it over a transformed polygon, enabling real-time polygonal area-light shading.
- Epic distinguishes static, stationary, and movable mobility: stationary commonly combines baked indirect lighting with runtime direct lighting/shadows, while movable lighting is fully dynamic and generally most expensive.

## 4. Industry-Standard Rendering API or Pattern

Use one versioned lighting build manifest:

1. classify lights and geometry by mobility/bake policy;
2. validate lightmap UVs, charts, texel density, material emissive, and world/cell dependencies;
3. trace direct/indirect transport into high-precision working buffers;
4. denoise with albedo/normal/visibility guidance while preserving chart boundaries;
5. encode surface lightmaps, shadow masks, probe SH, reflection cubemaps, and metadata;
6. package immutable lighting sections per world cell plus shared/global dependencies;
7. stream and transactionally publish complete lighting generations at runtime.

Runtime shading:

- static surface diffuse reads a lightmap or virtual-lightmap page;
- dynamic objects sample a volumetric/tetrahedral irradiance field;
- rough/specular fallback samples blended, parallax-corrected captures;
- dynamic direct lights evaluate the normal BRDF;
- polygonal/rectangular area lights evaluate LTC diffuse/specular terms using small fitted LUTs;
- shadows come from baked masks, shadow maps/pages, or ray queries according to mobility/tier.

The renderer must prevent double counting when a light contributes to both baked and dynamic paths. Every light carries direct, indirect, shadow, reflection-capture, and volumetric contribution flags plus a bake generation.

## 5. CPU, GPU, Memory, and Bandwidth Considerations

**Offline CPU/GPU complexity.** Bake time scales with lightmap texels, probe samples, rays/samples, material evaluation, light count, bounces, and denoising. Texture-space GPU baking trades workstation VRAM for throughput. Distributed/multi-GPU work needs deterministic tile ownership, compatible caches, seam validation, and a CPU encoding/denoising budget.

**Runtime CPU complexity.** Static lightmap lookup adds little CPU work. Probe/capture selection and cell publication must avoid per-object scans: use spatial acceleration, precomputed cell lists, and GPU-readable indices. Reflection-capture updates are dirty-generation work, not per-frame default. Batch lighting resource/descriptor publication per streamed cell.

**GPU complexity and draw/dispatch counts.** Surface lightmaps add texture samples to opaque shading rather than new draws. Probe SH evaluation is bounded arithmetic per shaded pixel/object. Capture blending adds cubemap samples and parallax work. Each dynamic area light still participates in tiled/clustered light lists; LTC adds LUT fetches and polygon edge integration. Dynamic area-light shadows are a separate and potentially dominant pass/ray cost.

**Allocations and VRAM residency.** Surface lightmaps usually dominate static-lighting VRAM/storage. Other residents include shadow masks, probe bricks/SH, reflection-capture cubemaps/mips, light lists, LTC LUTs, and page tables. Use streamable/virtual tiles, compressed runtime formats, immutable page blobs, and fixed probe/capture pools. Do not allocate per-object probe records when an index/brick reference suffices.

**Memory bandwidth and cache behavior.** Lightmap and capture sampling occur in core shading and can dominate texture traffic. Pack directional/SH coefficients by tier, use block compression where error permits, keep chart padding/mips correct, and spatially cluster pages. Capture samples should follow material roughness mip selection. Probe brick indirection must remain cache coherent.

**Shader divergence.** Avoid per-pixel branches over all static/stationary/movable combinations. Resolve light/material policy into pipeline/material flags and clustered records. Partition LTC-capable shapes from point/spot lights or use coherent light-type loops. Cap polygon edges and texture-light features by tier.

**Synchronization and concurrency.** Streaming copy completion precedes lightmap/probe/capture descriptor publication. A new lighting generation must not mix surface pages from one build with probes/captures from another unless explicitly compatible. Dynamic capture rendering and convolution require graph dependencies before use. Async capture convolution is useful only when it does not contend with frame-critical bandwidth.

**Streaming.** Package lightmaps, probe bricks, captures, and shadow masks as world-cell sections with coarse fallback. Activate a child cell's lighting before hiding its HLOD parent's lighting. Retain old generations through fences and cross-fade only when energy accounting remains valid.

**Frame latency.** Baked data has no temporal convergence at runtime, but capture recapture/convolution and page streaming are delayed. Visibility changes, data-layer transitions, and teleports need prefetch/fallback. Never block the render thread waiting for a fine lightmap or capture.

## 6. Pros and Cons

**Surface lightmaps**

- Pros: high diffuse-GI quality, soft static shadows, very low runtime ALU, broad platform support.
- Cons: UV authoring/storage, static-scene restriction, bake iteration time, seams/leaks, streaming complexity.

**Volumetric/tetrahedral probes**

- Pros: light movable objects and fog cheaply; compact directional diffuse representation.
- Cons: interpolation leakage, placement/tetrahedralization/brick memory, low-frequency lighting, difficult visibility discontinuities.

**Reflection captures**

- Pros: cheap rough/specular fallback, stable off-screen content, reusable across many pixels.
- Cons: parallax/leakage, spatial blending/priority artifacts, static capture content, cubemap storage.

**Stationary/mixed lights**

- Pros: baked indirect quality with runtime color/intensity/direct shadows.
- Cons: baked indirect cannot follow runtime changes correctly, double-counting risk, shadow-mask/overlap limits, complex authoring semantics.

**LTC area-light shading**

- Pros: plausible real-time polygonal/rectangular specular and diffuse response with small LUTs and bounded work.
- Cons: fitted approximation, special handling for shapes/material lobes, no free area-light shadow solution, texture-emission complexity.

**Fully dynamic fallback**

- Pros: no bake invalidation, supports destruction/time-of-day.
- Cons: higher runtime GPU/VRAM/AS cost, temporal noise/cache latency, reduced low-end scalability.

## 7. ECS and Render-World Integration

ECS components:

- `LightComponent`: physical intensity/units, color/spectrum, shape, range, mobility, contribution flags, shadow policy, and stable light ID.
- `StaticLightingComponent`: lightmap binding, UV channel, texel-density policy, bake participation, and lighting-generation ID.
- `ProbeVolumeComponent`: world bounds, density/quality policy, priority, and baked resource handle.
- `ReflectionCaptureComponent`: shape, influence/blend bounds, priority, parallax mode, resolution, recapture policy, and resource handle.
- `LightingScenarioComponent`: data-layer/scenario identity and activation generation.

Render extraction produces immutable light records, static-lighting instance bindings, probe/capture spatial records, and cell/generation tags. The renderer owns GPU page tables, physical tiles, descriptors, SH bricks, cubemap arrays, capture convolution state, LTC LUTs, and transient build/capture resources.

First- and third-person views share baked world data. View models may use probe/capture overrides or dominant-light policy to avoid lighting discontinuities near the camera, but should remain in the same exposure/color system. Reflection, scene-capture, and editor views declare whether captures can recurse or use only prior/prebaked environment data.

## 8. Resource, Pass, Material, and Visibility Interfaces

Required resources:

- surface-lightmap and directional-lightmap page tables/physical tiles;
- baked shadow-mask channels and light/channel mapping;
- probe volume brick/page data, SH coefficients, validity/visibility;
- reflection-capture cubemap arrays, mip chains, influence/parallax metadata;
- LTC transform/amplitude LUTs and light polygon/shape records;
- lighting-build manifest, per-cell dependencies, hashes, formats, and generations;
- coarse HLOD/fallback lighting.

Required interfaces:

- `SampleSurfaceLightmap(instance, uv, pageGeneration)`;
- `SampleIrradianceField(worldPosition, normal, probeVolume)`;
- `SelectAndBlendReflectionCaptures(worldPosition, roughness, captureGrid)`;
- `EvaluateAreaLightLTC(lightShape, materialLobe, N, V)`;
- `ResolveMixedLighting(lightRecord, bakedMask, dynamicShadow)`;
- `PublishLightingCell(cell, generation, completedCopyFence)`;
- `RecaptureAndConvolveEnvironment(capture, dirtyGeneration)`.

Materials declare whether they consume baked diffuse, probes, captures, dynamic GI, or a hybrid; the build compiler validates unsupported combinations. Visibility includes light influence, capture/probe volume intersection, page residency, HLOD/cell state, and material mobility.

## 9. Asset and Runtime Integration Plan

1. Define mobility and contribution semantics that prevent direct/indirect/shadow double counting.
2. Extend asset validation with lightmap UV overlap, padding, chart orientation, texel density, material emissive, and bake compatibility.
3. Implement a CPU/reference baker or integrate a pinned production baker behind a versioned build interface.
4. Produce surface lightmaps and shadow masks first; validate against path-traced references.
5. Add volumetric/probe bricks with adaptive density, SH encoding, visibility/leak controls, and debug visualization.
6. Add reflection-capture placement, cubemap filtering, influence blending, parallax correction, and roughness/lightmap leak suppression.
7. Integrate LTC rectangle/polygon evaluation into clustered deferred/Forward+ lighting using versioned fitted LUT assets.
8. Package lighting by world cell/scenario with manifests, hashes, coarse fallback, transactional activation, and fence-safe retirement.
9. Connect lighting outputs to DDC, distributed build workers, streaming/residency, PSO manifests, and telemetry.
10. Add mobile/low-end formats and a fully dynamic/no-bake profile sharing the same material/light authoring schema.

## 10. Visual and Performance Verification Strategy

Bake correctness:

- compare lightmap/probe/capture output against high-sample path-traced references using linear HDR error, perceptual metrics, and approved visual review;
- test UV chart seams, padding/mips, thin walls, emissives, interiors/windows, high-contrast corners, foliage, and mirrored/nonuniform instances;
- validate deterministic build hashes and tile results across worker counts/machines where required;
- poison missing/stale pages and generation mismatches to prove fallback.

Runtime visual tests:

- static, stationary, and movable light combinations; runtime color/intensity changes; destruction/moved geometry; data-layer changes;
- dynamic first-/third-person characters moving through probe/capture cells, doors, interiors/exteriors, and world-partition boundaries;
- rough-to-mirror materials, capture overlap, parallax, translucent receivers, volumetric fog, and water;
- rectangle size/orientation/near field, polygon shape, roughness/view angle, barn doors/textures, and soft-shadow expectations.

Performance:

- bake: texels/rays/samples, tiles, denoise/encode time, peak CPU RAM/VRAM, cache hit, distributed-worker utilization, output bytes;
- runtime CPU: cell publication, capture/probe selection, descriptor updates, recapture scheduling, allocations;
- runtime GPU: lightmap/probe/capture/LTC samples, dynamic light counts, draws/dispatches, shadow work, barriers, cache misses, bandwidth, divergence, and critical path;
- memory: resident/streamed lightmap pages, probe bricks, capture cubemaps, shadow masks, transient capture targets;
- frame pacing: teleport/cell activation, capture recapture, scenario swaps, and VRAM pressure at p95/p99.

## 11. Platform and Scalability Risks

- Large open worlds can generate prohibitive bake data and iteration times.
- Static lightmaps conflict with destructible/movable geometry and dynamic time of day.
- Probe interpolation leaks across walls and from exterior to interior without visibility/placement controls.
- Reflection captures leak/parallax and can pop where blending is limited.
- Stationary/mixed semantics create invalid lighting when indirect intensity/color changes at runtime.
- Area-light BRDF evaluation does not solve area-light visibility/shadows.
- Forward/mobile paths may have different rect-light, capture, shadow-mask, or probe capabilities.
- Lightmap compression can band or corrupt directional data; mips can bleed across charts.
- Scenario/cell generations can mix incompatible baked datasets if publication is not transactional.
- Virtual lightmaps reduce residency but add feedback/page-table/cache complexity.

Scalability controls: lightmap resolution/page pool; directional coefficient tier; probe density/SH order; capture resolution/count/blend/parallax; recapture cadence; stationary shadow quality; LTC shape/material support; dynamic-light/shadow cap; and baked-versus-dynamic project profile.

## 12. Engineering Recommendations

The following are engineering recommendations:

1. Treat baked lighting as a capability tier sharing physical light/material definitions with dynamic lighting.
2. Use versioned immutable lighting generations containing surface lightmaps, shadow masks, probes, captures, and metadata; publish them transactionally per cell/scenario.
3. Make surface lightmaps the static diffuse backbone and probes the dynamic-object/fog fallback; never sample a coarse object-wide probe when affordable per-pixel interpolation is available.
4. Use adaptive probe density with explicit visibility/leak prevention and memory caps; visualize discarded/coarse bricks.
5. Use blended/parallax-corrected reflection captures as a stable fallback beneath SSR/ray/dynamic reflection tiers, with roughness and baked-diffuse leak suppression.
6. Encode direct, indirect, shadow, probe, capture, and dynamic contribution flags so mixed lights cannot double count.
7. Use LTC for rectangle/polygon diffuse/specular evaluation on supported paths, but select baked, raster, or ray-query shadows independently.
8. Stream lighting with world cells and HLODs, keeping coarse valid illumination resident until fine pages/bricks/captures are ready.
9. Gate every bake on UV/chart, texel density, probe leakage, deterministic manifest, page residency, and reference-image validation.
10. Instrument offline build time/RAM/VRAM/cache/output size and runtime samples, bandwidth, cache, VRAM, synchronization, streaming, and frame pacing.
11. Preserve open decisions: baker/toolchain; virtual versus conventional lightmaps; encoded basis/formats; probe layout/SH/visibility; capture blending/parallax; mixed-light semantics; LTC shapes/lobes/LUT resolution; area shadows; world-cell packaging; dynamic-time-of-day policy; platform tiers.

## 13. Source Links

- [Epic Games — GPU Lightmass Global Illumination](https://dev.epicgames.com/documentation/en-us/unreal-engine/gpu-lightmass-global-illumination-in-unreal-engine)
- [Epic Games — CPU Lightmass Global Illumination](https://dev.epicgames.com/documentation/unreal-engine/cpu-lightmass-global-illumination-in-unreal-engine?lang=en-US)
- [Epic Games — Volumetric Lightmaps](https://dev.epicgames.com/documentation/en-us/unreal-engine/volumetric-lightmaps-in-unreal-engine)
- [Epic Games — Reflection Captures](https://dev.epicgames.com/documentation/unreal-engine/reflections-captures-in-unreal-engine?lang=en-US)
- [Epic Games — Static Light Mobility](https://dev.epicgames.com/documentation/en-us/unreal-engine/static-light-mobility-in-unreal-engine)
- [Epic Games — Stationary Light Mobility](https://dev.epicgames.com/documentation/en-us/unreal-engine/stationary-light-mobility-in-unreal-engine)
- [Epic Games — Rectangular Area Lights](https://dev.epicgames.com/documentation/unreal-engine/rectangular-area-lights-in-unreal-engine)
- [Heitz et al. — Real-Time Polygonal-Light Shading with Linearly Transformed Cosines](https://eheitzresearch.wordpress.com/415-2/)
- [Heitz and Hill — Real-Time Line- and Disk-Light Shading with LTC](https://eheitzresearch.wordpress.com/757-2/)
- [Unity — Light Probe Technical Information](https://docs.unity3d.com/2019.4/Documentation/Manual/LightProbes-TechnicalInformation.html)
