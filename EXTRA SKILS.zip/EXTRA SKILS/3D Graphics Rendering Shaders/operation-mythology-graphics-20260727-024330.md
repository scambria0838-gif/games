# Operation Mythology Graphics Research — Terrain and Vegetation Rendering

**Timestamp:** 2026-07-27 02:43:30 America/Los_Angeles  
**Scope:** Terrain geometry/material LOD, procedural vegetation instances, wind deformation, thin-leaf shading, shadows, virtualized aggregate geometry, streaming, and scalability. This report complements rather than repeats the existing world-partition and virtual-asset reports.

## 1. Feature Overview

An open-world landscape renderer needs two related but distinct systems:

- **Terrain:** large continuous surfaces represented by regular-grid clipmaps, chunked meshes, virtualized geometry, or a hybrid; height/displacement, holes, material layers, decals, runtime deformation, and collision/render correspondence.
- **Vegetation:** deterministic distributions of trees, shrubs, grass, leaves, and debris rendered through GPU-visible instance clusters, representation LOD, wind deformation, thin-surface light transmission, and density-aware shadows.

The proposed architecture uses world cells for ownership and streaming, but renderer-owned hierarchical tiles/clusters for per-view LOD, culling, indirect submission, and temporal continuity.

## 2. Existing Coverage and Identified Gap

The recursive inventory found 14 files in `GAME SKILLS` and 15 files in the dedicated graphics folder. Existing research already defines:

- cell manifests, transactional activation, origin-relative coordinates, and HLOD;
- virtual geometry/texture streaming and GPU-driven indirect submission;
- shadows, GI, atmosphere, temporal upscaling, material assets, and VRS;
- water, character deformation, transparency, and performance instrumentation.

No report defines the terrain-specific nested-grid/mesh hierarchy, geometric seam policy, terrain material layer reduction, vegetation distribution and cluster records, wind bounds/motion, thin-leaf shading, aggregate-distance representation, density fade, or forest shadow policy. This batch fills those rendering gaps and treats world partition only as an upstream ownership boundary.

## 3. Sourced Facts

The following are sourced facts:

- Losasso and Hoppe’s geometry clipmaps cache terrain in nested regular grids centered on the viewer and incrementally shift them as the viewer moves. The design targets steady rendering rate, smooth transitions, compact regular data, and graceful degradation.
- The GPU clipmap implementation stores elevation as textures and reuses common grid vertex/index geometry across translated/scaled blocks, reducing CPU mesh rebuilding and permitting block-level frustum culling.
- Epic documents static-mesh foliage batching through hardware instancing. Its cluster-level occlusion/cull behavior can make groups disappear abruptly, so it provides per-instance fade over a start/end distance.
- Epic’s two-sided foliage shading adds transmission for thin leaves; default opaque lighting can make leaf undersides unnaturally dark.
- Epic documents that alpha-masked foliage causes overdraw and mask-shader cost, while fully modeled leaves can also produce poor distant simplification and storage cost.
- Epic’s current experimental Nanite Foliage design uses reusable assemblies, near-pixel aggregate voxels, and skeletal wind deformation. It identifies arbitrary material world-position offset as a cause of conservative bounds and extra programmable-raster bins.
- Epic states that foliage aggregate voxels preserve material and normal-distribution information, and that triangle clusters transition to voxels with distance. Because this is experimental, the concept is evidence for aggregate representation, not a stable API dependency.
- Epic’s Nanite landscape documentation notes that retaining both virtualized and conventional landscape data can double relevant streaming/residency because other systems still need the conventional representation.
- Epic recommends foliage-preserving simplification that redistributes lost area where disjoint leaves would otherwise shrink.
- Epic’s procedural foliage tile separates deterministic placement determination from actual instance spawning, demonstrating the value of storing a compact reproducible distribution rather than one heavyweight actor per plant.

## 4. Industry-Standard Rendering API or Pattern

### Terrain

Use a view-centered or view-demanded hierarchy:

1. select nested rings/tiles from projected geometric error;
2. request height, normal, splat/material, hole, and displacement pages;
3. render regular reusable grid patches or virtualized clusters;
4. stitch rings using fixed transition strips, skirts, or geomorphing;
5. sample identical edge data/version on both sides of cell boundaries;
6. retain a coarse valid surface until fine pages and material layers are resident.

Support multiple cameras by merging tile demand, not by rebuilding a single camera-owned terrain state. Reflection/shadow views use coarser error thresholds and independent budgets.

### Vegetation

Use deterministic world-cell instance data plus renderer clusters:

1. decode species seed/distribution or cooked instances;
2. build compact instance records and cluster bounds;
3. GPU frustum/Hi-Z/distance/size cull;
4. choose full mesh, simplified mesh/cards, aggregate voxel/impostor, or removal;
5. compact visible instances by representation/material;
6. issue indirect draws/mesh dispatches;
7. generate wind-deformed current and previous positions;
8. shade thin leaves with front/back normal handling and transmission;
9. fade density/representation stochastically or temporally rather than popping whole clusters.

For near vegetation, prefer geometry that minimizes masked empty area. For far dense crowns, use an aggregate representation that preserves coverage, average normal distribution, color, and transmittance rather than simplifying into isolated vanishing triangles.

## 5. CPU, GPU, Memory, and Bandwidth Considerations

**CPU complexity:** terrain demand is proportional to active rings/tiles and views, not world size. Vegetation extraction is proportional to resident changed cells/clusters; per-frame instance visibility and LOD should be GPU-driven. Procedural placement is offline or asynchronous and deterministic. Do not instantiate an ECS entity/actor for every decorative blade.

**GPU complexity and draw/dispatch counts:** terrain uses a bounded number of reusable patches or indirect cluster draws. Vegetation requires cull, LOD, compact, wind, and command-generation dispatches plus draws/mesh dispatches per representation/material bin. Shadow views can multiply work; reuse instance culling where view compatibility permits and cap shadow species/distance.

**Allocations and VRAM residency:** terrain residency includes height/displacement, material weights, virtual texture pages, normal/error metadata, mesh/cluster data, and transient update/upload buffers. Vegetation includes compact instances, clusters, species tables, geometry/cards/impostors/aggregate data, wind skeleton/phase, visible lists, commands, and previous deformation. Double representations during transitions must be budgeted explicitly.

**Memory bandwidth and cache behavior:** terrain is texture-bandwidth heavy; coherent grid sampling, packed weights, material-layer reduction, virtual texture locality, and reusable indices improve cache behavior. Foliage is vulnerable to vertex fetch, alpha-test overdraw, texture sampling, and shadow bandwidth. Sort clusters by species/LOD/material, keep instance records compact, use array/atlas locality, and perform a depth or coverage prepass only where measurement justifies it.

**Shader divergence:** terrain materials diverge when many biome layers are evaluated per pixel. Precompute/cook a small active-layer set per tile and classify expensive features. Vegetation divergence comes from species, wind tier, two-sided shading, alpha mask, and representation; bin these rather than branching across one megashader.

**Synchronization and concurrency:** uploaded terrain pages and instance generations become visible only after copy/decompression and descriptor updates complete. GPU culling must precede indirect execution; wind current/previous buffers must remain valid through velocity and shadow consumers. Async compute can overlap culling/wind with unrelated raster work, but graph barriers must prevent stale Hi-Z or overwritten history.

**Batching:** reuse common terrain patch geometry. Vegetation batches by representation, material/closure, wind tier, and shadow policy; bindless resources avoid splitting merely for texture identity. Keep cull granularity small enough for visibility but large enough to avoid excessive commands.

**Streaming:** terrain and vegetation are separate cell sections with shared activation generation. Load a coarse terrain and low-cost vegetation representation first. Predict demand from camera speed, teleport destinations, shadow/reflection views, and first-/third-person camera changes. Never expose instance data whose species/material/geometry dependencies are missing.

**Frame latency and concurrency:** wind and interactive bending must align with displayed transforms and emit correct previous positions. A one-frame-late far-wind tier is acceptable only with matching velocity/history policy. Origin shifts and cell swaps must invalidate or translate terrain/vegetation histories coherently.

## 6. Pros and Cons

| Technique | Pros | Cons |
|---|---|---|
| Geometry clipmaps | Stable topology, bounded CPU, smooth nested LOD, natural height texture streaming | Best for height fields; seams/holes/multi-view updates need care |
| Chunked adaptive mesh | Local error adaptivity and caves/overhang flexibility | More CPU/metadata, cracks, draw/cluster complexity |
| Virtualized terrain geometry | Detailed geometry and automatic cluster LOD | Additional representation/storage; platform fallback; runtime edits harder |
| Masked foliage cards | Low vertex count and mature authoring | Empty-area overdraw, alpha-test shimmer, poor silhouettes close-up |
| Modeled leaf geometry | Strong silhouettes, less empty alpha | Vertex/cluster/storage cost; distant aggregate collapse |
| Impostors | Very cheap far representation | View/light mismatch, popping, memory, wind limitations |
| Aggregate voxels/normal distributions | Preserves crown volume and density at distance | Build/storage/shader complexity; stochastic noise; experimental designs |
| Material WPO wind | Flexible and artist accessible | Per-vertex cost, conservative bounds, shader variants, difficult motion ownership |
| Skeletal/hierarchical wind | Bounded transforms, accurate bounds, shared animation tiers | Rig/build complexity and bone/transform storage |

## 7. ECS and Render-World Integration

ECS/world-facing data:

- `TerrainCellSurface`: stable cell/generation, terrain asset, transform/origin epoch, edit layer;
- `VegetationCell`: deterministic distribution/instance-generation handle;
- `WindFieldSource`: global/local field inputs, not per-leaf transforms;
- `InteractiveVegetationEvent`: bounded impulses/cut/burn/state changes for promoted instances;
- `VegetationPromotion`: maps selected gameplay-relevant plants to ECS entities while decorative population stays renderer-owned.

Render-world data:

- terrain tile/ring descriptors, page residency, error metrics, material-layer masks;
- compact vegetation instances and hierarchical cluster bounds;
- species/representation/material/wind/shadow tables;
- current/previous wind state and origin epoch;
- per-view demand, visible bins, indirect commands, and density fade state.

Decorative vegetation remains renderer-owned. Only interactive or persistent specimens are promoted to gameplay ECS identity; removal/state deltas map back to deterministic instance IDs.

## 8. Resource, Pass, Material, and Visibility Interfaces

```text
TerrainTile {
  cellGeneration, level, coord, worldBounds, geometricError,
  heightPages, materialPages, holeMask, activeLayerSet, residency
}

VegetationInstance {
  stableId, speciesId, cellLocalTransform, variationSeed,
  windPhase, stateFlags
}

VegetationCluster {
  instanceRange, bounds, speciesMask, lodError, maxWindDisplacement
}

VegetationSpecies {
  representationChain[], materialClosure, windRig,
  densityCurve, shadowCurve, interactionPolicy
}
```

Pass contracts:

- `SelectTerrainTiles(views, residency, budget) -> patches`
- `BuildTerrainCommands(patches) -> indirectStreams`
- `CullVegetation(clusters, views, hiz, budgets) -> visibleClusters`
- `SelectVegetationRepresentation(visibleClusters) -> instanceBins`
- `EvaluateWind(instanceBins, field, previousState) -> deformation`
- `BuildVegetationCommands(instanceBins) -> indirectStreams`
- `RenderFoliageDepthVisibility -> depth/coverage`
- `ShadeFoliage(lights, transmission, shadows) -> scene outputs`

Visibility must track logical instance count, visible clusters, surviving instances, rasterized triangles/cards, shaded samples, and shadow-only population separately.

## 9. Asset and Runtime Integration Plan

1. Establish terrain coordinate, height/displacement precision, edge-version, and material-layer conventions.
2. Cook terrain tiles with min/max bounds, error metrics, edge-safe mip data, holes, collision reference, and coarse fallback.
3. Limit terrain runtime shader layers using per-tile active sets and bake distant blended material pages.
4. Define vegetation species assets with deterministic IDs, full/simplified/card/impostor/aggregate representations, material, wind, bounds, density, and shadow tiers.
5. Validate card empty-area ratio, alpha coverage mips, geometry surface preservation, normals/tangents, two-sided behavior, and maximum wind displacement.
6. Build hierarchical instance clusters and deterministic procedural placement per world cell.
7. Cook hierarchical wind rigs/weights or bounded analytic wind attributes with known maximum displacement and previous-state reconstruction.
8. Precompile shader/PSO variants for terrain layer counts, vegetation representation, wind tier, two-sided transmission, depth/velocity, and shadow paths.
9. Package terrain and vegetation sections independently but publish against the same world-cell generation.
10. Provide promotion/demotion tooling for gameplay-relevant plants while retaining stable decorative instance identity.

## 10. Visual and Performance Verification Strategy

Visual tests:

- slow/fast traversal, teleports, multiple cameras, origin shifts, and cell boundaries;
- steep terrain, holes, decals, water intersections, displacement, and material-layer transitions;
- forest/grass density from ground, aerial, first-person, and third-person views;
- wind from calm to storms, gust propagation, camera cuts, and LOD transitions;
- sunrise/backlit leaves, overcast crowns, wet foliage, snow/dust overlays;
- shadow cascades/virtual maps, reflections, GI/AO, fog, and temporal upscaling.

Reference checks:

- no terrain cracks, swimming, normal discontinuities, or material seam;
- stable vegetation coverage, hue, volume, wind phase, and shadow density across representations;
- correct current/previous deformation and reactive masks;
- deterministic placement and stable instance IDs across reload.

Performance captures must record:

- CPU demand, placement, extraction, streaming, promotion, and command time;
- GPU terrain selection, vegetation culling/LOD/compaction/wind, depth, shading, and shadows;
- draw/dispatch counts, indirect commands, clusters, instances, triangles, overdraw, alpha-test kills;
- allocations, VRAM residency, double-representation transition peaks;
- vertex/texture/render-target bandwidth, cache behavior, occupancy, and shader divergence;
- synchronization, barriers, queue overlap, concurrency, and Hi-Z dependencies;
- streaming bytes/misses/latency and frame-time percentiles.

Acceptance gates include zero cracks, bounded LOD error, no certified-scene command/visible-buffer overflow, stable density under camera motion, zero warm-frame general-heap allocation, bounded terrain/vegetation VRAM, and graceful degradation under I/O or GPU pressure.

## 11. Platform and Scalability Risks

- Mesh/virtualized geometry, bindless access, indirect counts, ray tracing, and subgroup features vary by platform.
- Mobile/tile GPUs may favor simpler instanced cards and compact forward shading over virtualized/full-geometry foliage.
- Alpha-tested foliage can dominate overdraw and temporal shimmer; full geometry can dominate vertex/cluster/storage cost.
- Arbitrary WPO expands bounds and invalidates occlusion assumptions.
- Forest shadows can exceed main-view cost due to multiple lights/views and offscreen casters.
- Terrain duplicate representations or collision/runtime-virtual-texture dependencies can double memory.
- Procedural density changes can affect gameplay/navigation/persistence if renderer and simulation ownership are not separated.
- Aggregate representations may lose species-specific silhouettes, normal response, or seasonal state.

Scalability controls: terrain error/pixel threshold, ring/tile count, height/material page budgets, active material layers, tessellation/displacement, vegetation density, cluster size, representation distances, wind tier/update rate, two-sided transmission, shadow species/distance/light count, alpha cutoff, aggregate/impostor quality, and first-person reserve.

## 12. Engineering Recommendations

The following are engineering recommendations:

1. Use regular-grid clipmap or equivalent reusable terrain patches as the broad fallback; allow virtualized geometry as a higher tier without duplicating unbounded data.
2. Make terrain edge data/versioning and coarse-valid fallback explicit to eliminate cracks during partial residency.
3. Reduce terrain material layers per tile and bake distant blends to cap shader divergence and bandwidth.
4. Store decorative vegetation as deterministic compact instances with stable IDs, not one ECS entity per plant.
5. Perform vegetation culling, LOD, density selection, compaction, and indirect command generation on GPU.
6. Require a representation chain per species and verify coverage, volume, color, wind, and shadows through transitions.
7. Prefer modeled geometry where it reduces masked empty area, but switch dense distant crowns to an aggregate/impostor representation rather than isolated simplified leaves.
8. Use hierarchical/bounded wind deformation with accurate cluster bounds and previous-state ownership; restrict arbitrary WPO.
9. Use energy-aware two-sided leaf transmission and species-specific thickness/color masks.
10. Apply independent main-view and shadow density/LOD budgets; do not update invisible wind solely for negligible shadows.
11. Publish terrain pages, vegetation instances, dependencies, and origin epoch transactionally per cell generation.
12. Gate the system on CPU/GPU complexity, draw/dispatch counts, allocations, VRAM, bandwidth, cache, divergence, synchronization, batching, streaming, frame latency, and concurrency telemetry.

Open decisions: terrain representation/platform hierarchy; tile/ring/error sizes; seam method; runtime edit policy; material-layer limit; procedural versus cooked placement; cluster granularity; species representation chain; aggregate technique; wind model/rig; leaf transmission; shadow hierarchy; interactive promotion; and platform budgets.

## 13. Source Links

- [Losasso and Hoppe — Geometry Clipmaps](https://hhoppe.com/geomclipmap.pdf)
- [Asirvatham and Hoppe — GPU-Based Geometry Clipmaps](https://hhoppe.com/gpugcm.pdf)
- [NVIDIA GPU Gems 2 — Terrain Rendering Using GPU-Based Geometry Clipmaps](https://developer.nvidia.com/gpugems/gpugems2/part-i-geometric-complexity/chapter-2-terrain-rendering-using-gpu-based-geometry)
- [Epic Games — Foliage Mode](https://dev.epicgames.com/documentation/en-us/unreal-engine/foliage-mode-in-unreal-engine)
- [Epic Games — Shading Models: Two-Sided Foliage](https://dev.epicgames.com/documentation/unreal-engine/shading-models-in-unreal-engine?lang=en-US)
- [Epic Games — Nanite Foliage](https://dev.epicgames.com/documentation/en-us/unreal-engine/nanite-foliage)
- [Epic Games — Nanite Technical Details](https://dev.epicgames.com/documentation/en-us/unreal-engine/nanite-technical-details)
- [Epic Games — Using Nanite with Landscapes](https://dev.epicgames.com/documentation/en-us/unreal-engine/using-nanite-with-landscapes-in-unreal-engine?application_version=5.7)
- [Epic Games — Procedural Foliage Tile API](https://dev.epicgames.com/documentation/unreal-engine/API/Runtime/Foliage/UProceduralFoliageTile?lang=en-US)
- [Epic Games — Procedural Foliage Tool](https://dev.epicgames.com/documentation/unreal-engine/procedural-foliage-tool-in-unreal-engine?lang=en-US)
