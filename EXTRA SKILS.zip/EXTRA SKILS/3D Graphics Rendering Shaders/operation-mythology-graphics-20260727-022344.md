# Operation Mythology Graphics Research — Motion Blur, Depth of Field, Bloom, and Post-Process Composition

**Timestamp:** 20260727-022344  
**Scope:** Camera/post-process graph, motion blur, depth of field, bloom, lens flare/aberration/vignette/grain, temporal-upscaler ordering, HDR/exposure domains, custom effects, first-/third-person policy, memory/bandwidth, and scalability.  
**Assumptions:** Modular data-oriented engine; explicit render-world extraction; existing motion-vector, exposure/HDR, render-graph, temporal-upscaling, and profiling contracts; no production-code implementation.

## 1. Feature Overview

Operation Mythology needs a camera-image pipeline that transforms the temporally reconstructed scene into the final display image while preserving coherent physical units, temporal data, depth, and artistic control. Motion blur, depth of field (DoF), bloom, lens effects, grading, tone mapping, sharpening, upscaling, UI, and output encoding cannot be independent unordered full-screen materials.

The system should:

- represent physical camera parameters separately from artistic overrides;
- schedule effects according to scene-referred/display-referred and render/display resolution;
- share pyramids, tile classification, transient targets, and histories where valid;
- prevent exposure-domain and motion-vector mismatches;
- keep first-person weapons/readability independently controllable without corrupting the world view;
- provide deterministic capture/reference modes and platform tiers.

## 2. Existing Coverage and Identified Gap

The recursive scan found detailed coverage for motion-vector semantics, TAA/upscaling, exposure, color grading, tone mapping, HDR output, render graphs, and renderer telemetry. It did not define the downstream camera-effects architecture: shutter interpretation and blur classification, thin-lens CoC and near/far separation, bloom extraction/pyramids/convolution, late lens effects, pass fusion, or custom-post-process constraints.

This report fills that gap without reopening the already established velocity and color-output contracts. It assumes the renderer supplies valid depth, motion, exposure, reactive masks, and temporally reconstructed color.

## 3. Sourced Facts

The following are sourced facts:

- Epic documents motion blur as a full-screen velocity-map effect and exposes blur amount, maximum screen distortion, target frame rate, and a minimum projected object size for velocity-pass participation.
- Epic states that its Velocity GBuffer stores one motion vector per pixel; this cannot represent secondary motion such as moving shadows/reflections and can artifact where fast objects cross.
- Epic's temporal-upscaler documentation reconstructs static-geometry velocity from depth and camera motion while separately rasterizing moving-object velocity, and provides motion/reprojection visualizers.
- NVIDIA GPU Gems describes reconstructing static-scene velocity from depth plus current/previous view-projection matrices and gathering color along the resulting motion direction. It requires separate dynamic-object velocity for accurate object motion.
- AMD FidelityFX DoF derives signed circle-of-confusion (CoC) radii from a thin-lens model, differentiates near/far fields, works on half-resolution buffers, builds/dilates per-tile CoC ranges, classifies tiles, gathers near/far blur, and composites at full resolution.
- AMD states that DoF sample count grows approximately quadratically with configured ring quality, and recommends bounding CoC radius. It notes that blur amplifies temporal instability.
- AMD recommends passing a temporally stabilized image into DoF, but applying DoF at render resolution before upscaling because CoC/depth are normally available there. This ordering is an integration tradeoff that must be validated against the chosen upscaler.
- AMD documents that single-depth image-space DoF cannot correctly handle translucency or volumetrics because one depth value cannot represent all layers.
- Epic documents Standard bloom as the game-oriented path and FFT convolution bloom as a higher-cost high-end/cinematic path. Epic notes that convolution bloom can be energy-conserving while Standard bloom can brighten the image.
- AMD FidelityFX Lens combines chromatic aberration, vignette, and film grain in a lightweight late pass and recommends applying it after upscaling/sharpening because noise and lens alterations can interfere with those algorithms.
- Epic cautions that custom post-process materials often create intermediate render targets and recommends optimized built-in effects where possible.

## 4. Industry-Standard Rendering API or Pattern

Use a declarative camera-effects graph with explicit domains:

1. **Scene-referred, pre-exposed HDR at render resolution:** physically luminous bloom source, DoF inputs, motion vectors, depth, transparencies according to policy.
2. **Temporal reconstruction/upscaling boundary:** chosen per effect and upscaler contract; preserve exposure and jitter metadata.
3. **Motion blur:** tile-max/neighbor-max velocity classification, bounded directional gather, depth/velocity rejection, and separate policies for camera, world, and first-person layers.
4. **Depth of field:** CoC generation, bilateral downsample/pyramid, tile min/max/dilation/classification, near/far gather, fill/occlusion approximation, and composite.
5. **Bloom/lens flare:** threshold-optional or physically scaled extraction, downsample pyramid, separable/dual-filter upsample or convolution tier, and HDR composite.
6. **Color/output transform:** grading, tone/gamut mapping, and display encoding under the existing contract.
7. **Late display effects:** chromatic aberration, vignette, film grain, optional sharpening policy, UI, and final output.

The exact order of motion blur, DoF, translucency, bloom, and temporal upscaling must be an engine profile, not user-defined arbitrary ordering. Custom passes declare required inputs, color/exposure domain, resolution, history, and compositing point.

## 5. CPU, GPU, Memory, and Bandwidth Considerations

**CPU complexity.** Per-view setup is constant: resolve camera/lens parameters, blend volume overrides, select quality paths/PSOs, and populate graph constants. Cache blended post-process stacks and recompute only when relevant volumes/settings change. Avoid per-frame material lists and heap allocation through fixed render-view records and graph arenas.

**GPU complexity and dispatch counts.** Motion blur commonly adds velocity reduction/classification and one or more gather/composite passes. DoF adds CoC/downsample mips, tile generation/dilation, blur, optional filtering, and composite. Standard bloom adds a downsample/upsample pyramid; convolution bloom adds FFT transforms and kernel work. Lens effects can be one late pass. Costs scale with pixels, blur radius, tile dilation, sample rings, pyramid levels, HDR bandwidth, and active views.

**Draw/dispatch counts and batching.** These are primarily full-screen/tiled compute dispatches or draws. Use indirect/classified work only when skipped tiles offset classification overhead. Fuse compatible pixel-in/pixel-out late effects—vignette, grain, simple aberration, output dithering—while keeping algorithms with different resolution/history requirements separate.

**Allocations and VRAM residency.** Persistent data includes histories, small kernels/LUTs, and per-view state. Transient HDR color, velocity tiles, CoC maps, near/far buffers, bloom pyramids, FFT scratch, and upscaler intermediates dominate. A 4K RGBA16F full-resolution intermediate is about 63.3 MiB before alignment; unnecessary copies are unacceptable. Use render-graph lifetime aliasing and shared pyramids only when format/semantics match.

**Memory bandwidth and cache behavior.** Post processing repeatedly reads/writes large images and is frequently bandwidth-bound. Prefer half/quarter-resolution work, tiled coherent traversal, bilinear-gather reductions, mip sampling for large kernels, pass fusion, and compact formats validated for HDR/CoC/velocity. Avoid copying scene color merely to satisfy custom-pass APIs.

**Shader divergence.** Tile-classify no/near/far/mixed DoF and short/long/no motion. Choose pass-level variants for SDR/HDR and quality. Clamp radii and separate pathological tiles rather than divergent unbounded loops. Lens effects should be coherent pixel-in/pixel-out operations.

**Synchronization and concurrency.** Depth, velocity, transparencies, and temporal reconstruction must meet the selected ordering before consumers run. Pyramids and FFT stages require explicit UAV/texture dependencies. Async compute can overlap independent post work with late graphics only if it does not extend the presentation critical path or saturate bandwidth.

**Streaming.** Lens kernels, dirt masks, flare assets, grade LUTs, and custom-pass resources are small but visually conspicuous when missing; prefetch with camera/profile activation and keep neutral fallbacks resident. Convolution kernels must be fully resident at intended quality.

**Frame latency.** Most effects are spatial and do not add queued frames, but they consume temporal histories/velocity and can amplify input lag visually through excessive blur. Frame generation/present latency is separate. Camera cuts, focus jumps, resolution changes, exposure epochs, and effect enable changes need explicit reset or smooth transitions.

## 6. Pros and Cons

**Velocity-buffer motion blur**

- Pros: one main rendered frame, scalable, works with existing motion vectors, good world/camera motion.
- Cons: one vector per pixel, missing secondary motion/hidden samples, crossing silhouettes and rotations artifact, gather bandwidth.

**Tile-max classified blur**

- Pros: bounds sample regions and skips static tiles.
- Cons: reduction/dilation passes, velocity leakage, large-radius tiles remain expensive.

**Half-resolution layered DoF**

- Pros: strong cost reduction, separate near/far behavior, physically meaningful CoC.
- Cons: halo/hole/bleeding approximations, difficult thin geometry, translucency and volumes lack sufficient depth layers.

**Standard bloom pyramid**

- Pros: fast, stable, scalable, easy wide glow.
- Cons: approximate point-spread function and potentially non-conservative energy.

**FFT convolution bloom**

- Pros: expressive non-symmetric optical kernels and energy-conserving response.
- Cons: FFT scratch, transforms, wrap/padding concerns, full kernel residency, high-end cost.

**Late fused lens pass**

- Pros: low dispatch/bandwidth overhead and avoids contaminating temporal upscalers with grain.
- Cons: effects may operate in display space and must be calibrated across SDR/HDR; strong aberration harms readability.

## 7. ECS and Render-World Integration

ECS authoring data:

- `CameraPhysicalSettings`: focal length, sensor/filmback, aperture, focus distance, shutter angle/time, ISO linkage, and lens profile.
- `CameraPostProcessSettings`: effect enable/tier, artistic blur limits, bloom profile, vignette, grain, aberration, flare, and grading references.
- `PostProcessVolume`: bounds, priority, blend radius/weight, and override mask.
- `CameraLayerPolicy`: world, first-person/view-model, cinematic, UI, photo mode, or capture behavior.

Render extraction creates immutable `RenderViewPostState` with resolved physical/artistic values, current/previous camera state, exposure domain, render/display extent, jitter, velocity contract, history epoch, output profile, and PSO/asset handles.

First-person weapon/hands often need reduced motion blur and DoF to preserve aiming/readability, but must still composite consistently with bloom/exposure. Third-person uses world camera settings. Scope/portal/mirror/capture views declare independent or inherited post state and resolution. Post-process volumes do not own GPU resources or graph handles.

## 8. Resource, Pass, Material, and Visibility Interfaces

Required resources:

- temporally stabilized HDR scene color;
- depth and canonical motion vectors with validity;
- exposure/current-previous pre-exposure metadata;
- CoC full/half-resolution and tile min/max/dilated maps;
- DoF near/far colors, opacity/validity, and filter scratch;
- velocity tile-max/neighbor-max and blur masks;
- bloom pyramid or convolution FFT/kernel/scratch;
- lens/grading assets and late-effect constants;
- per-view history/epoch and custom-pass inputs.

Required pass contracts:

- `ResolveCameraPostState(view, volumes, profile)`;
- `ClassifyMotion(velocity, depth, masks)`;
- `ApplyMotionBlur(color, depth, velocity, shutter, layerPolicy)`;
- `BuildCoC(depth, lens)`;
- `ApplyDepthOfField(color, CoC, depth, quality)`;
- `BuildAndCompositeBloom(HDRColor, exposureDomain, profile)`;
- `ApplyColorOutputTransform(color, exposure, display)`;
- `ApplyLateLens(color, aberration, vignette, grain, dither)`.

Custom post materials declare input resource semantics, pre/post-tone domain, render/display resolution, alpha meaning, filtering, history, and whether in-place/fusion is legal. Visibility is primarily per-view fullscreen/tile classification, plus projected-size masks for velocity rendering and first-person layer masks.

## 9. Asset and Runtime Integration Plan

1. Publish a canonical camera/lens/post-process schema with units and physical-versus-artistic override rules.
2. Build a reference post graph that visualizes every intermediate, domain, extent, format, and history dependency.
3. Integrate motion blur using the established canonical velocity buffer, camera-depth reconstruction, dynamic-object motion, tile classification, and bounded shutter.
4. Integrate a thin-lens CoC DoF reference with half-resolution near/far layers, tile dilation, and explicit translucency/volume limitations.
5. Add standard bloom with a shared validated pyramid and physically scaled pre-tone input; add convolution only as a high tier.
6. Place grading/tone/output through the existing color contract, then fuse lightweight late lens effects.
7. Add first-person/world layer policy and camera-cut/focus/exposure/resolution epochs.
8. Restrict custom pass insertion to named extension points with declared resource contracts.
9. Cook lens kernels, dirt/flare textures, LUTs, shaders, PSOs, and platform variants through DDC/residency systems.
10. Add deterministic fixed-camera/fixed-exposure/fixed-focus capture profiles and performance gates.

## 10. Visual and Performance Verification Strategy

Correctness/reference:

- compare motion vectors and blur lengths against analytic camera/object motion and shutter duration;
- test translation, rotation, deformation, particles, water, camera cuts, origin shifts, and crossing silhouettes;
- compare CoC signs/radii against thin-lens calculations over randomized depth/focus/aperture/focal-length inputs;
- render high-sample multi-camera accumulation references for DoF and motion blur;
- test bloom impulse response, energy, kernel centering, edge padding, and exposure invariance;
- verify color/exposure domains with HDR ramps and emissive reference values.

Visual matrix:

- first-person aiming/recoil/sprint, third-person traversal/combat, vehicles, cutscenes, photo mode, scopes, and split screen;
- thin foreground objects, hair/foliage, translucent particles/glass, volumetrics, bright emissives, reflections, UI, and waterlines;
- focus pulls, rack focus across occlusion, fast camera pans, rotating wheels, bright objects crossing frame edges, and camera cuts;
- SDR/scRGB/HDR10, dynamic resolution, TAA/upscaler variants, sharpening, motion blur/DoF before-versus-after upscaling experiments.

Performance:

- record CPU view-stack resolution and allocations; GPU pass/dispatch count, pixels/tiles, blur radii, DoF classes/rings, bloom levels, FFT size, barriers, overlap, and critical path;
- record transient/resident VRAM, full-resolution HDR intermediates, bytes read/written, cache counters, occupancy/divergence, frame latency, and p95/p99 pacing;
- benchmark 1080p/1440p/4K, render scales, first-/third-person, split screen, cinematic tiers, and low-end/mobile fallbacks;
- regression-gate image metrics and approved perceptual comparisons together with memory/bandwidth/time limits.

## 11. Platform and Scalability Risks

- Mobile/VR may omit cinematic DoF, full motion blur, convolution bloom, or expensive lens effects.
- Full-screen HDR bandwidth grows sharply at 4K and with multiple views.
- Dynamic resolution changes the pixel-space meaning of CoC and blur radius.
- Upscaler ordering differs by vendor and can trade depth correctness against temporal stability.
- One-depth-buffer DoF cannot correctly reconstruct obscured backgrounds, translucent layers, particles, or volumes.
- One-vector motion blur cannot represent secondary motion or multiple layers.
- First-person readability/accessibility may require user-controlled reduction or disabling of blur, grain, aberration, and camera shake.
- HDR presentation changes perceptual bloom/lens intensity and highlight headroom.
- Custom post materials can force scene-color copies, extra formats, barriers, and untracked history.
- Aggressive pass fusion increases shader permutations and register pressure.

Quality tiers should independently control motion-blur radius/samples, velocity-object threshold, DoF enable/radius/rings/resolution, bloom levels/method, flare quality, late-lens enable/intensity, and custom-pass availability.

## 12. Engineering Recommendations

The following are engineering recommendations:

1. Make post processing a typed render-graph subgraph with explicit color domain, resolution, alpha, history, and extension points.
2. Derive physical shutter/CoC from camera parameters, then apply bounded artistic limits for gameplay comfort and performance.
3. Reuse the canonical velocity contract; reconstruct static camera velocity from depth and require explicit motion for dynamic/deforming/particle content.
4. Tile-classify motion and DoF, clamp radii, and keep sample counts bounded.
5. Use half-resolution layered DoF with explicit known limitations; do not claim correct translucency/volumetric focus from one depth layer.
6. Use standard bloom as the shipping default and FFT convolution only for high-end/cinematic profiles.
7. Apply bloom in a documented pre-tone/exposure domain and calibrate it across SDR/HDR instead of thresholding arbitrary post-tone values.
8. Run grain/vignette/aberration late, preferably fused, after temporal upscaling/sharpening unless the selected pipeline provides contrary validated guidance.
9. Give first-person/view-model layers explicit blur/DoF policy and accessibility controls.
10. Disallow arbitrary custom-pass ordering; require declared inputs and report forced intermediates/copies in diagnostics.
11. Profile dispatches, full-resolution intermediates, transient VRAM, bandwidth, cache, divergence, synchronization, latency, and multi-view multiplication.
12. Preserve open decisions: shutter convention; motion tile layout/samples; DoF/upscaler order; CoC limits/quality; translucency/volume DoF; bloom domain/pyramid/convolution; lens/flare model; pass fusion; first-person policy; custom extension points; and platform budgets.

## 13. Source Links

- [Epic Games — Post Process Effects](https://dev.epicgames.com/documentation/en-us/unreal-engine/post-process-effects-in-unreal-engine)
- [Epic Games — Depth of Field](https://dev.epicgames.com/documentation/en-us/unreal-engine/depth-of-field-in-unreal-engine)
- [Epic Games — Bloom](https://dev.epicgames.com/documentation/unreal-engine/bloom-in-unreal-engine?lang=en-US)
- [Epic Games — Post Process Materials](https://dev.epicgames.com/documentation/unreal-engine/post-process-materials-in-unreal-engine?lang=en-US)
- [Epic Games — Temporal Upscaler Motion Visualization](https://dev.epicgames.com/documentation/en-us/unreal-engine/temporal-upscalers-in-unreal-engine)
- [Epic Games — Setting Up Motion Blur](https://dev.epicgames.com/documentation/en-us/unreal-engine/setting-up-motion-blur)
- [AMD GPUOpen — FidelityFX Depth of Field](https://gpuopen.com/manuals/fidelityfx_sdk/techniques/depth-of-field/)
- [AMD GPUOpen — FidelityFX Lens](https://gpuopen.com/manuals/fidelityfx_sdk/techniques/lens/)
- [NVIDIA GPU Gems 3 — Motion Blur as a Post-Processing Effect](https://developer.nvidia.com/gpugems/gpugems3/part-iv-image-effects/chapter-27-motion-blur-post-processing-effect)
- [NVIDIA GPU Gems 3 — Practical Post-Process Depth of Field](https://developer.nvidia.com/gpugems/gpugems3/part-iv-image-effects/chapter-28-practical-post-process-depth-field)
