# Operation Mythology Graphics Research — Atmosphere, Volumetric Fog, and Clouds

**Timestamp:** 20260727-021212  
**Scope:** Physically based planetary atmosphere, aerial perspective, froxel volumetric fog, local participating media, volumetric clouds, cloud/fog lighting and shadows, temporal reconstruction, sparse volume assets, and platform scalability.  
**Assumptions:** Modular data-oriented engine; explicit render-world extraction; render graph; physically based lighting/exposure; first- and third-person cameras; no production-code implementation.

## 1. Feature Overview

Operation Mythology needs one participating-media model shared by the sky, aerial perspective, ground fog, local fog volumes, clouds, smoke-compatible volume assets, lights, shadows, exposure, and transparent surfaces. The practical real-time architecture should combine:

- precomputed or amortized atmosphere lookup tables for planetary-scale Rayleigh, Mie, and absorption effects;
- a camera-aligned froxel grid for local fog density and lighting;
- bounded ray marching for cloud layers and selected heterogeneous volumes;
- lower-frequency shadow/transmittance maps and environment-light updates;
- temporal and spatial reconstruction with explicit invalidation;
- analytic height fog and sky fallbacks for constrained platforms.

The system must remain coherent from ground-level first-person views through elevated third-person views and large camera transitions. It should not make clouds, fog, and aerial perspective three unrelated color overlays: they exchange extinction, in-scattering, sunlight transmittance, shadows, and sky illumination.

## 2. Existing Coverage and Identified Gap

The required recursive scan found prior coverage for render graphs, GPU-driven submission, shading paths, memory/residency, virtual assets, temporal reconstruction, GI/reflections, shadows, animation/deformation, asset cooking, shader/PSO management, exposure/HDR, and renderer profiling. No existing report defines the atmosphere/fog/cloud transport model, volume interfaces, pass ordering, history contract, or scalability hierarchy.

The scan also found a newly added `GAME SKILLS` animation/deformation baseline. That topic is therefore no longer an uncovered graphics subject and is not duplicated here.

This report addresses:

- shared physical parameterization and units;
- separation of static atmosphere LUTs from dynamic weather/light state;
- fog froxel injection, light integration, and compositing;
- cloud density authoring, lighting, shadowing, and temporal reconstruction;
- volume-asset streaming and local-volume composition;
- memory, bandwidth, divergence, synchronization, and multi-view behavior.

Particles, decals, trails, water, and destruction VFX remain separate future batches except where a particle or sparse-volume source injects density into the common volume system.

## 3. Sourced Facts

The following are sourced facts:

- Epic describes Sky Atmosphere as a physically based atmosphere renderer supporting Rayleigh and Mie scattering, absorption, aerial perspective, time of day, planetary curvature, and ground-to-space transitions.
- Epic exposes multiple atmosphere lookup tables, including fast-sky and aerial-perspective resources, and notes that their resolution controls trade quality for performance.
- Bruneton and Neyret's precomputed atmospheric-scattering method reproduces daylight/twilight sky color, aerial perspective for arbitrary view/light directions, and planet/mountain shadows. Bruneton's 2017 implementation adds dimensional-unit checks, automated tests, configurable spectral/luminance handling, and removes Earth-specific ad hoc mapping constants.
- Frostbite's SIGGRAPH 2015 volumetric framework unifies participating media using physically based parameters, a cascaded extinction volume, particle voxelization, volumetric shadowing, and integrated media rendering.
- Frostbite's SIGGRAPH 2016 work presents practical physically based sky, atmosphere, and cloud solutions intended for dynamic time of day and weather and describes interactions among the media systems.
- Epic's Volumetric Fog uses a low-resolution camera-frustum volume, sub-voxel jitter, and heavy temporal reprojection. Epic explicitly warns that rapidly changing lights such as flashlights or muzzle flashes can leave trails.
- Epic states that volumetric-fog cost is primarily controlled by volume-texture resolution; increasing view distance without increasing depth slices undersamples the volume. It also reports that shadowed point and spot lights are substantially more expensive than unshadowed contributions in its implementation.
- Epic's volumetric clouds ray march a three-dimensional volume texture and integrate with atmosphere, sky lighting, directional lights, and dynamic time of day.
- Epic's Sparse Volume Textures store only occupied/interesting regions through a page table and physical tile textures; they support static or animated volume data and volume-material use cases. Page-table plus physical-data sampling introduces multiple texture lookups.
- The Nubis/Decima SIGGRAPH material demonstrates production-oriented authored real-time volumetric cloudscapes based on layered weather/layout data, procedural density, lighting, and aggressive temporal/spatial optimization.

## 4. Industry-Standard Rendering API or Pattern

Use a layered participating-media pipeline with shared coefficients:

1. **Atmosphere setup:** derive scattering/absorption profiles and planet geometry from immutable settings.
2. **Atmosphere LUT update:** compute transmittance, multiple scattering, sky-view, and aerial-perspective data only when their dependencies change.
3. **Volume classification/injection:** compact visible local fog volumes, volume particles, and streamed volume assets; inject extinction, albedo/scattering, emission, and phase data into a camera-aligned froxel grid.
4. **Volumetric lighting:** inject clustered local lights, directional light, sky/indirect light, and shadow visibility into froxels.
5. **Fog integration:** front-to-back integrate in-scattering and transmittance along view rays and temporally reconstruct the result.
6. **Cloud rendering:** intersect view rays with bounded spherical or planar cloud layers, skip empty space, ray march density, evaluate approximate multiple scattering, and terminate when transmittance is negligible.
7. **Cloud shadow/environment update:** render lower-frequency sun transmittance maps and update sky-light/cloud ambient data on a budget.
8. **Composition:** combine sky, opaque scene, aerial perspective, fog, clouds, heterogeneous volumes, transparencies, and tone mapping under one exposure-domain contract.

Represent all participating media with:

- extinction coefficient `σt`;
- scattering coefficient or `albedo × σt`;
- emission;
- phase-function parameters;
- optional spectral/RGB absorption;
- world-space bounds and density source.

Use the render graph to own froxel textures, LUT dependencies, shadow/transmittance maps, histories, barriers, and transient aliasing.

## 5. CPU, GPU, Memory, and Bandwidth Considerations

**CPU complexity.** Atmosphere parameter evaluation is constant or infrequent. Local-volume and cloud-layer extraction is `O(V)` for `V` visible media instances; clustered light assignment follows the existing light-grid complexity. Use dirty generations so unchanged atmosphere LUTs and weather resources do not rebuild. Avoid per-frame material-instance and volume-list allocations through pooled render-world arrays.

**GPU complexity and dispatch counts.** A practical frame adds atmosphere LUT updates only when dirty, one or more volume-clear/injection dispatches, clustered-light injection, fog integration, optional local-volume voxelization, cloud ray march, cloud shadow update, temporal reconstruction, and composition. Costs scale with froxel count, lights touching froxels, cloud pixels, ray-march steps, shadow samples, and active volume overdraw—not merely screen resolution.

**Draw/dispatch batching.** Compact volumes and lights on the GPU or during render extraction. Batch density injection by volume representation/material class. Avoid one dispatch per small fog sphere. Use indirect dispatch for variable cloud/volume tiles only if compaction saves more than it costs.

**VRAM residency and allocations.** Froxel grids, integrated fog, atmosphere LUTs, cloud histories, weather maps, noise volumes, shadow maps, and sparse-volume tiles are the main residents. Prefer compact formats validated against extinction/dynamic range. A `160×90×128` RGBA16F froxel texture is about 14.1 MiB before alignment; several coefficient/light/history volumes multiply this quickly. Pool persistent histories and alias transient injection/integration resources when lifetimes permit.

**Memory bandwidth and cache.** 3D texture traversal and full-screen temporal reconstruction are bandwidth-heavy. Arrange froxel Z so integration reads coherently, use tiled/group-shared light lists, minimize independent 3D texture samples, pack coefficients by consumer, and keep cloud density/noise samples at coherent scales. Sparse volumes save empty-space storage but add indirection and can become cache-latency limited.

**Shader divergence.** Cloud and heterogeneous-volume rays differ in entry distance, empty-space spans, step count, shadow work, and early termination. Classify tiles, bound steps, skip empty macro-cells, use coherent quality tiers, and terminate on high opacity. Avoid arbitrary dynamic volume-material branches in a single megakernel.

**Synchronization and concurrency.** Atmosphere LUTs can update asynchronously when no same-frame consumer dependency is violated. Fog injection must finish before lighting/integration; cloud shadow data must be ready before consumers use the new generation. Schedule independent shadow/LUT/cloud work on async compute only after measuring graphics-queue contention and ownership/barrier cost.

**Streaming.** Noise/weather resources should be resident before a weather state activates. Animated sparse-volume tiles need look-ahead, bounded upload/decompression, fallback mips/frames, and fence-safe page publication. Do not block the render thread on missing volume pages.

**Frame latency and temporal behavior.** Temporal accumulation reduces ray/froxel cost but adds convergence latency. Store view/projection, origin, exposure, weather, light, and resource generations with history. First-/third-person cuts, teleports, rapid sun changes, resolution changes, and volume topology changes require rejection or controlled reseeding.

## 6. Pros and Cons

**Precomputed atmosphere LUTs**

- Pros: physically coherent sky/aerial perspective at low steady-state cost; supports large view/light changes.
- Cons: multidimensional mapping complexity, LUT update cost, precision risks, and difficult validation.

**Camera-aligned froxel fog**

- Pros: efficient integration of many local lights and media sources; natural depth distribution; reusable lighting volume.
- Cons: low spatial resolution, view dependence, temporal trails, near-camera aliasing, and multi-view duplication.

**Ray-marched volumetric clouds**

- Pros: true parallax, self-shadowing, evolving 3D weather, and convincing ground-to-air views.
- Cons: step/sample cost, divergent rays, temporal noise/ghosting, expensive shadows, and substantial texture bandwidth.

**Sparse volume textures**

- Pros: preserve detailed offline simulations without allocating dense empty space; streamable and mip-capable.
- Cons: page indirection, residency complexity, animated-frame bandwidth, platform limitations, and unpredictable cache behavior.

**Analytic height fog/skydome fallback**

- Pros: very low cost, stable, broad hardware support.
- Cons: weak local lighting, no true heterogeneous density, limited shafts/parallax, and difficult exact matching to volumetric tiers.

## 7. ECS and Render-World Integration

ECS authoring components should remain renderer-neutral:

- `AtmosphereComponent`: planet center/radius, scattering/absorption profiles, ground properties, atmosphere height, and versioned preset.
- `WeatherComponent`: coverage, cloud type, wind fields, precipitation context, transition state, and deterministic weather epoch.
- `FogVolumeComponent`: shape, density profile, albedo, emission, phase, priority, blend policy, and quality class.
- `CloudLayerComponent`: altitude bounds, coverage/weather maps, density material, shadow policy, and update cadence.
- `VolumeAssetComponent`: sparse/dense volume asset handle, transform, playback frame, channels, and streaming priority.
- `MediaLightSettings`: per-light volumetric intensity, shadow eligibility, and budget priority.

Render extraction resolves immutable `RenderAtmosphereState`, `RenderCloudLayer`, `RenderFogVolume`, and `RenderVolumeAsset` records with bounds, handles, generations, visibility masks, and physical coefficients.

The renderer owns froxel coordinates, LUT slots, physical sparse-volume tiles, histories, temporal epochs, shadow atlases, and queue resources. A stable `AtmosphereId`/`ViewId` pair owns history. Main first- and third-person views normally share world atmosphere/weather but keep independent camera-aligned fog/cloud histories. Reflection, probe, minimap, and shadow views must declare whether they evaluate, reuse, approximate, or omit volumetrics.

## 8. Resource, Pass, Material, and Visibility Interfaces

Required resources:

- atmosphere parameter buffer and LUT set;
- compact visible-media and volumetric-light lists;
- froxel extinction/scattering/emission grid;
- froxel lighting and integrated transmittance/in-scattering;
- cloud weather/layout maps, noise volumes, macro-cell/min-max data, and histories;
- cloud/fog shadow or sun-transmittance maps;
- sparse-volume page tables, physical tiles, residency map, and fallback mip/frame;
- per-view temporal metadata and rejection masks.

Required pass contracts:

- `UpdateAtmosphereLUTs(parameters, dirtyMask)`;
- `CullAndCompactMedia(view, renderWorld)`;
- `InjectMedia(froxelGrid, compactMedia)`;
- `InjectVolumetricLighting(froxelGrid, clusteredLights, shadows, atmosphere)`;
- `IntegrateFog(froxelGrid, depth, history)`;
- `RenderClouds(view, layerData, atmosphere, shadows, history)`;
- `UpdateCloudTransmittance(lightView, cloudData)`;
- `CompositeParticipatingMedia(sceneColor, depth, transparencies, exposureDomain)`.

Volume materials output physical coefficients, not pre-tonemapped color overlays. Visibility must include camera/frustum intersection, projected coverage, depth bounds, cloud-layer ray intervals, shadow relevance, and history validity. Opaque depth should clip fog/cloud integration; translucent materials must choose per-vertex, per-pixel, or integrated-volume fogging explicitly.

## 9. Asset and Runtime Integration Plan

1. Publish a versioned participating-media specification defining units, coefficients, phase convention, working color space, and exposure domain.
2. Implement a tested Bruneton/Hillaire-class atmosphere reference with CPU validation and LUT debug visualization.
3. Ship analytic height fog and static-sky fallbacks before adding the froxel path.
4. Add per-view froxel grids, clustered light injection, integration, and temporal history with deterministic reset reasons.
5. Implement local analytic volumes, then particle/mesh injection using compact batched lists.
6. Add one bounded cloud layer using weather maps, 3D noise, macro-cell empty-space skipping, directional lighting, and temporal reconstruction.
7. Add cloud sun-transmittance shadows and lower-frequency sky/environment-light coupling.
8. Integrate sparse-volume import/cooking: channel semantics, quantization, mips, brick occupancy, page tables, animation chunks, and fallback frames.
9. Connect atmosphere/cloud/fog resources to asset DDC, streaming/residency, shader manifests, PSO precaching, exposure, shadows, and diagnostics.
10. Add platform tiers and measured quality budgets before supporting arbitrary volume graphs or multiple expensive cloud layers.

## 10. Visual and Performance Verification Strategy

Reference tests:

- compare atmosphere transmittance and radiance LUT samples against a double-precision CPU/reference implementation over randomized altitudes, directions, sun angles, and planet parameters;
- validate dimensional units, non-negativity, energy behavior, horizon continuity, ground shadow, sun disk, twilight, and aerial perspective;
- compare fog integration against analytic homogeneous-media solutions and high-sample offline ray marching;
- compare clouds at selected viewpoints against a high-step, high-shadow-sample reference.

Temporal/visual tests:

- static-camera convergence and noise;
- slow/fast translation, rotation, camera cuts, first-/third-person switches, origin rebasing, and ground-to-cloud/space traversal;
- fast flashlights, muzzle flashes, lightning, moving shadow casters, and rapid sun/weather transitions;
- depth edges, thin geometry, translucency, water horizons, sky composition, and exposure changes;
- history poisoning and generation changes for streamed sparse volumes.

Performance capture:

- record atmosphere LUT dispatches, froxel dimensions, injected volumes/lights, cloud pixels/steps, shadow samples, early exits, history rejection, draw/dispatch counts, barriers, async overlap, and queue waits;
- measure CPU extraction/culling, allocations, GPU pass time, VRAM resident/transient bytes, sparse-tile residency, upload/decompression, 3D texture traffic, cache counters, divergence/occupancy, and frame pacing;
- test 1080p/1440p/4K, dynamic resolution, low/high FOV, first-/third-person views, split screen, dense local lights, storms, and constrained streaming;
- gate p95/p99 rather than average-only cost and include weather transitions and camera teleports.

## 11. Platform and Scalability Risks

- Mobile/tile GPUs may not tolerate large 3D UAVs, long ray marches, many storage-texture passes, or sparse-volume streaming.
- Froxel and cloud history cost multiplies across independent views; stereo can share selected atmosphere/cloud data but requires view-correct reconstruction.
- Low-resolution grids create shafts, banding, depth-edge leakage, and near-camera artifacts.
- Temporal accumulation creates trails from rapid light/weather changes and disocclusion.
- Cloud shadow and environment-light updates can visibly lag changing weather.
- High anisotropy needs careful phase approximation and sampling to avoid unstable highlights.
- 3D noise and sparse-volume sampling can become bandwidth/cache bound.
- Ray-march step limits can miss thin density; fixed steps waste work in empty or opaque regions.
- Extreme world scale and origin rebasing threaten LUT coordinates, precision, and history.
- Alpha/holdout/capture paths can force more expensive composition.

Recommended tiers:

- Tier 0: skydome/gradient plus analytic height fog.
- Tier 1: atmosphere LUTs plus analytic/local fog without volumetric lighting.
- Tier 2: reduced froxel fog and low-resolution clouds with limited shadowed lights.
- Tier 3: full froxel lighting, temporal clouds, cloud shadows, and sparse local volumes.
- Cinematic/debug: higher LUT/froxel/step/shadow budgets, never assumed as the shipping baseline.

## 12. Engineering Recommendations

The following are engineering recommendations:

1. Define one physical media interface for atmosphere, fog, clouds, and streamed volumes; keep artistic controls as mappings into that interface.
2. Use tested precomputed/amortized atmosphere LUTs, with dirty-generation updates rather than unconditional per-frame recomputation.
3. Use a camera-aligned froxel grid for lit local fog, with analytic height fog as a compatibility and far-distance fallback.
4. Render clouds in bounded layers with macro-cell empty-space skipping, early transmittance termination, lower-resolution sampling, and temporal/spatial reconstruction.
5. Treat fast emissive/lighting events as a separate temporal class: reduce their history weight or exclude their volumetric contribution when trails are unacceptable.
6. Share atmosphere parameters and slow weather resources across views, but retain view-specific froxel/cloud histories and explicit history epochs.
7. Budget shadowed local volumetric lights separately; select them by projected influence and importance with hysteresis.
8. Integrate sparse volume assets only through the central residency/streaming service with fallback mips/frames and fixed upload/decompression budgets.
9. Require graph-visible dependencies for LUTs, injection, lighting, integration, shadows, cloud rendering, composition, and temporal histories.
10. Instrument froxel/step/sample counts, early termination, bandwidth, divergence, cache behavior, temporal rejection, VRAM, and streaming residency—not just pass milliseconds.
11. Preserve open decisions: atmosphere spectral versus RGB implementation; LUT dimensions/formats; froxel XY/Z distribution; phase model; local-volume blend semantics; cloud representation and number of layers; temporal filters; shadow representation/cadence; sparse-volume channel/brick formats; transparency integration; and per-platform budgets.

## 13. Source Links

- [Epic Games — Sky Atmosphere Component](https://dev.epicgames.com/documentation/en-us/unreal-engine/sky-atmosphere-component-in-unreal-engine)
- [Epic Games — Volumetric Fog](https://dev.epicgames.com/documentation/en-us/unreal-engine/volumetric-fog-in-unreal-engine)
- [Epic Games — Volumetric Cloud Component](https://dev.epicgames.com/documentation/unreal-engine/volumetric-cloud-component-in-unreal-engine?lang=en-US)
- [Epic Games — Sparse Volume Textures](https://dev.epicgames.com/documentation/unreal-engine/sparse-volume-textures-in-unreal-engine?lang=en-US)
- [Epic Games — Heterogeneous Volumes](https://dev.epicgames.com/documentation/en-us/unreal-engine/heterogeneous-volumes-in-unreal-engine)
- [Eric Bruneton — Precomputed Atmospheric Scattering: A New Implementation](https://ebruneton.github.io/precomputed_atmospheric_scattering/)
- [Bruneton and Neyret — Precomputed Atmospheric Scattering](https://onlinelibrary.wiley.com/doi/pdf/10.1111/j.1467-8659.2008.01245.x)
- [Frostbite — Physically Based and Unified Volumetric Rendering](https://www.ea.com/news/physically-based-unified-volumetric-rendering-in-frostbite)
- [Frostbite — Physically Based Sky, Atmosphere and Cloud Rendering](https://www.ea.com/news/physically-based-sky-atmosphere-and-cloud-rendering)
- [Guerrilla Games — Nubis: Authoring Real-Time Volumetric Cloudscapes](https://advances.realtimerendering.com/s2017/Nubis%20-%20Authoring%20Realtime%20Volumetric%20Cloudscapes%20with%20the%20Decima%20Engine%20-%20Final%20.pdf)
