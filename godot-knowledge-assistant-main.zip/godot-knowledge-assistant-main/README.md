# Godot 知识助手

基于 Tauri 2.x 的桌面端 Godot 引擎知识库 AI 对话助手，支持知识库检索、多轮工具调用 Agent、MCP 服务器连接、知识库蒸馏等功能。

## 截图

![首页 - 亮色](screenshots/首页.png)
![首页 - 暗色](screenshots/首页-暗.png)
![对话演示](screenshots/对话演示-暗.png)
![知识库浏览](screenshots/数据库-暗.png)
![图片库管理](screenshots/图片库-暗.png)
![蒸馏页面](screenshots/蒸馏页面-暗.png)
![资源索引](screenshots/资源索引.png)
![对话栏](screenshots/对话栏.png)
![设置页面](screenshots/设置-暗.png)
![设置 - 上](screenshots/设置-上-暗.png)

## 功能

- **AI 对话** — 基于 OpenAI/DeepSeek/Ollama API 的智能问答，自动检索知识库
- **深度思考模式** — 开启后 AI 进行逐步推理后再回答，提供更深入的分析
- **搜索工具开关** — 可单独控制是否启用联网搜索/图片搜索工具
- **知识库浏览** — 按分类/难度浏览 1700+ 份 Godot 教程文件，快速预览
- **知识库蒸馏** — 将任意 .txt 文件夹自动构建为知识库索引（分类/分块/关键词）
- **图片库管理** — 浏览、搜索、管理本地图片，支持标签筛选和删除
- **多轮 Agent** — 支持工具调用循环：知识搜索 → 网络搜索 → 图片搜索 → 本地图片 → MCP 工具
- **MCP 服务器** — 通过 stdio JSON-RPC 连接 MCP 服务器，动态注册工具
- **本地图片搜索** — 扫描本地图片目录，按文件名/标签搜索
- **图片代理下载** — 自动将在线图片转为 data URL 嵌入显示，防止裂图
- **对话管理** — 多会话持久化保存/加载、复制/引用/导出（md/txt/doc/png）、重试、赞踩反馈
- **暗色/亮色主题** — 跟随系统或手动切换

## 快速开始

### 第一步：下载文件

打开 [Releases 页面](https://github.com/qingshanjiluo/godot-knowledge-assistant/releases)，找到最新版本（如 `v1.0.1`），下载以下 **两个文件**：

| 文件 | 大小 | 用途 |
|------|------|------|
| `Godot-Knowledge-Assistant-v1.0.0-x64-setup.exe` | ~5 MB | 程序安装包 |
| `godot-knowledge-database-v1.0.1.zip` | ~8 MB | 知识库数据包 |

### 第二步：安装程序

1. 双击运行 `Godot-Knowledge-Assistant-v1.0.0-x64-setup.exe`
2. 安装全程自动完成，无需手动配置
3. 安装完成后自动在**桌面**和**开始菜单**创建快捷方式
4. 如需卸载：**设置 → 应用 → 应用和功能 → Godot 知识助手 → 卸载**

### 第三步：解压知识库

1. 将 `godot-knowledge-database-v1.0.1.zip` 解压到任意本地文件夹（如 `D:\godot-knowledge-db`）
2. 解压后该文件夹内应包含两个文件：
   - `godot_index.json`
   - `godot_chunks.json`

### 第四步：配置并启动

1. 双击桌面快捷方式打开应用
2. 点击左下角**齿轮图标**进入设置页
3. 在 **AI 配置** 区域：
   - 选择 AI 提供商（如 OpenAI / DeepSeek / Ollama）
   - 输入 API Key 和模型名称
   - 点击"测试连接"确保可用
4. 在 **知识库路径** 区域：
   - 点击"浏览" → 选择第三步解压的文件夹
   - 点击"加载"（等待加载完成）
5. 加载成功后可在左侧"知识库"面板浏览 1700+ 份教程的分类和预览

### 第五步：开始提问

在对话面板输入关于 Godot 引擎的问题，AI 会自动检索知识库并生成带引用来源的回答。

## 知识库蒸馏

1. 点击左侧的"蒸馏"按钮（实验管图标）
2. 选择源文件夹（包含 .txt 教程文件）
3. 选择输出文件夹
4. 点击"开始蒸馏"自动生成索引

## 开发

### 环境要求

- Node.js 18+
- Rust 1.75+
- Tauri 2.x

### 构建

```bash
# 安装前端依赖
npm install

# 开发模式
npm run tauri dev

# 生产构建（NSIS 安装包）
npm run tauri build
```

### 技术栈

| 层 | 技术 |
|----|------|
| 桌面框架 | Tauri 2.x (Rust) |
| 前端 | React 18 + TypeScript + Vite |
| UI 组件 | Ant Design 5 |
| 状态管理 | Zustand |
| 流式渲染 | ReactMarkdown + rehype |
| 代码高亮 | Prism (react-syntax-highlighter) |
| 搜索引擎 | TF-IDF 关键词评分（Rust） |
| MCP 协议 | stdio JSON-RPC（Rust） |
| 持久化 | Tauri Plugin Store (JSON) |
| 数据格式 | JSON (Index + Chunks) |

### 项目结构

```
godot-knowledge-assistant/
├── src/                    # React 前端
│   ├── components/         # UI 组件
│   │   ├── Chat/           # 对话面板、消息渲染
│   │   ├── Chat/           # 对话面板、消息渲染
│   │   ├── ImageLibrary/   # 图片库管理
│   │   ├── KnowledgeBase/  # 知识库浏览、蒸馏面板
│   │   ├── Layout/         # 主布局、导航
│   │   └── Settings/       # 设置面板
│   ├── services/           # 服务（AI、搜索、MCP、Skills）
│   ├── stores/             # Zustand 状态
│   ├── types/              # TypeScript 类型
│   └── utils/              # 常量、配置
├── src-tauri/              # Rust 后端
│   └── src/
│       ├── commands/       # Tauri 命令
│       ├── knowledge/      # 知识库搜索引擎
│       ├── distill.rs      # 知识库蒸馏
│       └── mcp.rs          # MCP 客户端
└── scripts/                # 构建工具脚本
```

## 配置

### MCP 服务器

支持添加 MCP 服务器以扩展 AI 工具能力。MCP 服务器通过 stdio 协议通信，配置格式：

| 字段 | 说明 |
|------|------|
| 命令 | 可执行文件路径（如 `npx`、`node`） |
| 参数 | 命令行参数（如 `-y @godot/mcp-server`） |
| 自动连接 | 启动时自动连接 |

### 环境变量

- `PEXELS_API_KEY` — Pexels 图片搜索 API Key

## 许可证

MIT
