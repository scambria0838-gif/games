use serde::{Deserialize, Serialize};
use std::sync::Mutex;

pub mod commands;
pub mod distill;
pub mod embeddings;
pub mod knowledge;
pub mod mcp;

use commands::mcp::MCPState;
use knowledge::KnowledgeBase;

pub struct AppState {
    pub knowledge_base: Mutex<Option<KnowledgeBase>>,
}

#[derive(Debug, Serialize, Deserialize)]
pub struct KnowledgeFile {
    pub id: String,
    pub filename: String,
    pub path: String,
    pub title: String,
    pub size: i64,
    pub line_count: i64,
    pub summary: String,
    pub category: Vec<String>,
    pub difficulty: String,
    pub keywords: Vec<String>,
    pub chunk_count: usize,
}

#[derive(Debug, Serialize, Deserialize)]
pub struct KnowledgeChunk {
    pub chunk_id: String,
    pub file_id: String,
    pub file_title: String,
    pub file_path: String,
    pub summary: String,
    pub keywords: Vec<String>,
    pub start_line: usize,
    pub end_line: usize,
    pub chunk_text: String,
}

#[derive(Debug, Serialize, Deserialize)]
pub struct SearchResult {
    pub file_id: String,
    pub title: String,
    pub path: String,
    pub summary: String,
    pub category: Vec<String>,
    pub difficulty: String,
    pub keywords: Vec<String>,
    pub score: f64,
    pub chunks: Vec<KnowledgeChunk>,
}

#[derive(Debug, Serialize, Deserialize)]
pub struct CategoryIndex {
    pub name: String,
    pub count: usize,
    pub files: Vec<String>,
}

#[derive(Debug, Serialize, Deserialize)]
pub struct IndexOverview {
    pub total_files: usize,
    pub categories: Vec<CategoryInfo>,
    pub difficulties: Vec<DifficultyInfo>,
    pub loaded: bool,
}

#[derive(Debug, Serialize, Deserialize)]
pub struct CategoryInfo {
    pub name: String,
    pub count: usize,
}

#[derive(Debug, Serialize, Deserialize)]
pub struct DifficultyInfo {
    pub name: String,
    pub count: usize,
}

#[cfg_attr(mobile, tauri::mobile_entry_point)]
pub fn run() {
    tauri::Builder::default()
        .plugin(tauri_plugin_dialog::init())
        .plugin(tauri_plugin_fs::init())
        .plugin(tauri_plugin_shell::init())
        .plugin(tauri_plugin_store::Builder::default().build())
        .plugin(tauri_plugin_sql::Builder::default().build())
        .manage(AppState {
            knowledge_base: Mutex::new(None),
        })
        .manage(MCPState {
            manager: Mutex::new(mcp::MCPManager::new()),
        })
        .invoke_handler(tauri::generate_handler![
            commands::knowledge::load_knowledge_base,
            commands::knowledge::search_knowledge,
            commands::knowledge::get_file_content,
            commands::knowledge::get_index_overview,
            commands::knowledge::get_files_by_category,
            commands::knowledge::get_related_files,
            commands::knowledge::distill_knowledge,
            commands::knowledge::search_knowledge_hybrid,
            commands::knowledge::compute_knowledge_embeddings,
            commands::image::download_image_as_data_url,
            commands::image::scan_local_images,
            commands::image::delete_local_image,
            commands::mcp::connect_mcp,
            commands::mcp::disconnect_mcp,
            commands::mcp::list_mcp_tools,
            commands::mcp::call_mcp_tool,
        ])
        .run(tauri::generate_context!())
        .expect("error while running tauri application");
}
