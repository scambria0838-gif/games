use serde::{Deserialize, Serialize};
use std::collections::HashMap;
use std::io::{BufRead, BufReader, Write};
use std::process::{Child, Command, Stdio};

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct MCPServerConfig {
    pub id: String,
    pub name: String,
    pub command: String,
    pub args: Vec<String>,
    pub env: Option<HashMap<String, String>>,
    pub auto_connect: bool,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct MCPTool {
    pub name: String,
    pub description: String,
    pub input_schema: serde_json::Value,
}

struct MCPConnection {
    process: Child,
    tools: Vec<MCPTool>,
}

impl Drop for MCPConnection {
    fn drop(&mut self) {
        let _ = self.process.kill();
        let _ = self.process.wait();
    }
}

pub struct MCPManager {
    connections: HashMap<String, MCPConnection>,
    next_id: u64,
}

impl MCPManager {
    pub fn new() -> Self {
        MCPManager {
            connections: HashMap::new(),
            next_id: 1,
        }
    }

    pub fn connect(&mut self, config: &MCPServerConfig) -> Result<Vec<MCPTool>, String> {
        if self.connections.contains_key(&config.id) {
            return Err(format!("Server '{}' is already connected", config.name));
        }

        let mut process = Command::new(&config.command)
            .args(&config.args)
            .stdin(Stdio::piped())
            .stdout(Stdio::piped())
            .stderr(Stdio::piped())
            .spawn()
            .map_err(|e| format!("Failed to start MCP server '{}': {}", config.name, e))?;

        let tools = Self::initialize(&config.name, &mut process)?;

        self.connections.insert(config.id.clone(), MCPConnection {
            process,
            tools: tools.clone(),
        });

        Ok(tools)
    }

    fn initialize(_name: &str, process: &mut Child) -> Result<Vec<MCPTool>, String> {
        let stdin = process.stdin.as_mut().ok_or("No stdin")?;
        let reader = process.stdout.as_mut().ok_or("No stdout")?;
        let mut stdout = BufReader::new(reader);

        let req_id = 1u64;

        let init_request = serde_json::json!({
            "jsonrpc": "2.0",
            "id": req_id,
            "method": "initialize",
            "params": {
                "protocolVersion": "2024-11-05",
                "clientInfo": { "name": "godot-knowledge-assistant", "version": "1.0.0" },
                "capabilities": {}
            }
        });

        Self::send_jsonrpc(stdin, &init_request)?;
        let init_response = Self::read_jsonrpc(&mut stdout, req_id)?;

        let _capabilities = init_response["result"]["capabilities"].clone();

        let initialized_notification = serde_json::json!({
            "jsonrpc": "2.0",
            "method": "notifications/initialized",
            "params": {}
        });
        Self::send_jsonrpc(stdin, &initialized_notification)?;

        let tools_request = serde_json::json!({
            "jsonrpc": "2.0",
            "id": req_id + 1,
            "method": "tools/list",
            "params": {}
        });
        Self::send_jsonrpc(stdin, &tools_request)?;
        let tools_response = Self::read_jsonrpc(&mut stdout, req_id + 1)?;

        let tools = tools_response["result"]["tools"]
            .as_array()
            .map(|arr| {
                arr.iter().map(|t| MCPTool {
                    name: t["name"].as_str().unwrap_or("unknown").to_string(),
                    description: t["description"].as_str().unwrap_or("").to_string(),
                    input_schema: t["inputSchema"].clone(),
                }).collect()
            })
            .unwrap_or_default();

        Ok(tools)
    }

    pub fn call_tool(&mut self, server_id: &str, tool_name: &str, args: serde_json::Value) -> Result<String, String> {
        let conn = self.connections.get_mut(server_id)
            .ok_or_else(|| format!("MCP server '{}' not connected", server_id))?;

        let stdin = conn.process.stdin.as_mut().ok_or("No stdin")?;
        let reader = conn.process.stdout.as_mut().ok_or("No stdout")?;
        let mut stdout = BufReader::new(reader);

        let req_id = self.next_id;
        self.next_id += 1;

        let request = serde_json::json!({
            "jsonrpc": "2.0",
            "id": req_id,
            "method": "tools/call",
            "params": {
                "name": tool_name,
                "arguments": args
            }
        });

        Self::send_jsonrpc(stdin, &request)?;
        let response = Self::read_jsonrpc(&mut stdout, req_id)?;

        if let Some(error) = response.get("error") {
            return Err(format!("MCP tool call error: {}", error));
        }

        let result = &response["result"];
        if let Some(content) = result["content"].as_array() {
            let texts: Vec<String> = content.iter()
                .filter_map(|c| c["text"].as_str().map(|s| s.to_string()))
                .collect();
            Ok(texts.join("\n"))
        } else {
            Ok(serde_json::to_string_pretty(result).unwrap_or_default())
        }
    }

    pub fn list_tools(&self, server_id: &str) -> Result<Vec<MCPTool>, String> {
        self.connections.get(server_id)
            .map(|c| c.tools.clone())
            .ok_or_else(|| format!("MCP server '{}' not connected", server_id))
    }

    pub fn disconnect(&mut self, server_id: &str) -> Result<(), String> {
        if let Some(mut conn) = self.connections.remove(server_id) {
            let _ = conn.process.kill();
            let _ = conn.process.wait();
        }
        Ok(())
    }

    fn send_jsonrpc(stdin: &mut impl Write, request: &serde_json::Value) -> Result<(), String> {
        let mut line = serde_json::to_string(request).map_err(|e| e.to_string())?;
        line.push('\n');
        stdin.write_all(line.as_bytes()).map_err(|e| format!("Failed to write to MCP: {}", e))?;
        stdin.flush().map_err(|e| format!("Failed to flush MCP: {}", e))?;
        Ok(())
    }

    fn read_jsonrpc(stdout: &mut impl BufRead, expected_id: u64) -> Result<serde_json::Value, String> {
        let mut line = String::new();
        loop {
            line.clear();
            stdout.read_line(&mut line).map_err(|e| format!("Failed to read from MCP: {}", e))?;
            if line.trim().is_empty() { continue; }
            let value: serde_json::Value = serde_json::from_str(&line)
                .map_err(|e| format!("Failed to parse MCP response: {}", e))?;
            if value.get("id").and_then(|id| id.as_u64()) == Some(expected_id) {
                return Ok(value);
            }
        }
    }
}
