use serde::{Deserialize, Serialize};
use std::collections::HashMap;
use std::fs;

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct EmbeddingData {
    pub chunk_id: String,
    pub vector: Vec<f32>,
    pub model: String,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct EmbeddingStore {
    pub total_chunks: usize,
    pub model: String,
    pub dimension: usize,
    pub embeddings: HashMap<String, Vec<f32>>,
}

/// Call an OpenAI-compatible embedding API
pub async fn fetch_embeddings(
    texts: &[&str],
    api_base: &str,
    api_key: &str,
    model: &str,
) -> Result<Vec<Vec<f32>>, String> {
    if texts.is_empty() {
        return Ok(Vec::new());
    }

    let url = format!("{}/embeddings", api_base.trim_end_matches('/'));
    let client = reqwest::Client::new();

    // Batch: max 20 texts per request
    let mut all_embeddings: Vec<Vec<f32>> = Vec::with_capacity(texts.len());
    let batch_size = 20;

    for batch in texts.chunks(batch_size) {
        let body = serde_json::json!({
            "input": batch,
            "model": model,
            "encoding_format": "float",
        });

        let resp = client
            .post(&url)
            .header("Authorization", format!("Bearer {}", api_key))
            .header("Content-Type", "application/json")
            .json(&body)
            .send()
            .await
            .map_err(|e| format!("Embedding API request failed: {}", e))?;

        if !resp.status().is_success() {
            let status = resp.status();
            let text = resp.text().await.unwrap_or_default();
            return Err(format!("Embedding API error ({}): {}", status, text));
        }

        let result: serde_json::Value = resp
            .json()
            .await
            .map_err(|e| format!("Failed to parse embedding response: {}", e))?;

        let data = result["data"]
            .as_array()
            .ok_or("Embedding response missing 'data' field")?;

        // Sort by index to maintain order
        let mut sorted = data.clone();
        sorted.sort_by(|a, b| {
            let ai = a["index"].as_u64().unwrap_or(0);
            let bi = b["index"].as_u64().unwrap_or(0);
            ai.cmp(&bi)
        });

        for item in &sorted {
            let vec: Vec<f32> = item["embedding"]
                .as_array()
                .ok_or("Missing embedding vector")?
                .iter()
                .map(|v| v.as_f64().unwrap_or(0.0) as f32)
                .collect();
            all_embeddings.push(vec);
        }
    }

    Ok(all_embeddings)
}

/// Compute cosine similarity between two vectors
pub fn cosine_similarity(a: &[f32], b: &[f32]) -> f32 {
    if a.len() != b.len() || a.is_empty() {
        return 0.0;
    }
    let dot: f32 = a.iter().zip(b.iter()).map(|(x, y)| x * y).sum();
    let norm_a: f32 = a.iter().map(|x| x * x).sum::<f32>().sqrt();
    let norm_b: f32 = b.iter().map(|x| x * x).sum::<f32>().sqrt();
    if norm_a == 0.0 || norm_b == 0.0 {
        return 0.0;
    }
    dot / (norm_a * norm_b)
}

/// Save embeddings to disk
pub fn save_embeddings(
    store: &EmbeddingStore,
    path: &str,
) -> Result<(), String> {
    let json = serde_json::to_string_pretty(store)
        .map_err(|e| format!("Failed to serialize embeddings: {}", e))?;
    fs::write(path, &json)
        .map_err(|e| format!("Failed to write embeddings: {}", e))?;
    Ok(())
}

/// Load embeddings from disk
pub fn load_embeddings(path: &str) -> Result<Option<EmbeddingStore>, String> {
    if !std::path::Path::new(path).exists() {
        return Ok(None);
    }
    let content = fs::read_to_string(path)
        .map_err(|e| format!("Failed to read embeddings: {}", e))?;
    let store: EmbeddingStore = serde_json::from_str(&content)
        .map_err(|e| format!("Failed to parse embeddings: {}", e))?;
    Ok(Some(store))
}
