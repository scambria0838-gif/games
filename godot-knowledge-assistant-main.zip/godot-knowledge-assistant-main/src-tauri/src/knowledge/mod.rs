use crate::{IndexOverview, CategoryInfo, DifficultyInfo};
use crate::embeddings::{self, EmbeddingStore, cosine_similarity};
use serde::{Deserialize, Serialize};
use std::collections::HashMap;
use std::fs;

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct IndexFile {
    pub id: String,
    pub filename: String,
    pub path: String,
    pub title: String,
    pub size: i64,
    pub line_count: i64,
    pub summary: String,
    pub category: Vec<String>,
    pub difficulty: String,
    pub keywords: Vec<String>,
    pub chunks: Vec<ChunkRef>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ChunkRef {
    pub chunk_id: String,
    pub summary: String,
    pub keywords: Vec<String>,
    pub start_line: usize,
    pub end_line: usize,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ChunkData {
    pub chunk_id: String,
    pub file_id: String,
    pub file_title: String,
    pub file_path: String,
    pub summary: String,
    pub keywords: Vec<String>,
    pub start_line: usize,
    pub end_line: usize,
    pub chunk_text: String,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct IndexRoot {
    pub total_files: usize,
    pub files: HashMap<String, IndexFile>,
    pub categories: HashMap<String, Vec<String>>,
    pub keywords: HashMap<String, Vec<String>>,
    pub difficulty_levels: HashMap<String, Vec<String>>,
    #[serde(default)]
    pub source_dir: String,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ChunksRoot {
    pub total_chunks: usize,
    pub chunks: Vec<ChunkData>,
}

type InvertedIndex = HashMap<String, Vec<(usize, f64)>>; // term -> [(chunk_idx, tf)]

#[derive(Debug, Clone)]
pub struct KnowledgeBase {
    pub index: IndexRoot,
    pub chunks: Vec<ChunkData>,
    pub base_dir: String,
    pub source_dir: String,
    inverted_index: Option<InvertedIndex>,
    avg_chunk_len: f64,
    num_chunks: usize,
    pub embeddings: Option<EmbeddingStore>,
}

impl KnowledgeBase {
    pub fn load(index_path: &str, chunks_path: &str, base_dir: &str) -> Result<Self, String> {
        let index_content = fs::read_to_string(index_path)
            .map_err(|e| format!("无法读取索引文件: {}", e))?;
        let index: IndexRoot = serde_json::from_str(&index_content)
            .map_err(|e| format!("解析索引文件失败: {}", e))?;

        let source_dir = if index.source_dir.is_empty() {
            base_dir.to_string()
        } else {
            index.source_dir.clone()
        };

        let chunks_content = fs::read_to_string(chunks_path)
            .map_err(|e| format!("无法读取知识块文件: {}", e))?;
        let chunks_root: ChunksRoot = serde_json::from_str(&chunks_content)
            .map_err(|e| format!("解析知识块文件失败: {}", e))?;

        let num_chunks = chunks_root.chunks.len();
        let total_chars: usize = chunks_root.chunks.iter()
            .map(|c| c.chunk_text.chars().count())
            .sum();
        let avg_chunk_len = if num_chunks > 0 {
            total_chars as f64 / num_chunks as f64
        } else {
            1.0
        };

        let mut kb = KnowledgeBase {
            index,
            chunks: chunks_root.chunks,
            base_dir: base_dir.to_string(),
            source_dir,
            inverted_index: None,
            avg_chunk_len,
            num_chunks,
            embeddings: None,
        };
        kb.build_inverted_index();

        // Try loading embeddings
        if let Some(emb_path) = std::path::Path::new(index_path).parent() {
            let emb_file = emb_path.join("godot_embeddings.json");
            if let Ok(Some(store)) = embeddings::load_embeddings(emb_file.to_str().unwrap_or("")) {
                kb.embeddings = Some(store);
                println!("  Loaded embeddings for {} chunks", kb.embeddings.as_ref().map(|e| e.total_chunks).unwrap_or(0));
            }
        }

        Ok(kb)
    }

    fn build_inverted_index(&mut self) {
        let mut index: InvertedIndex = HashMap::new();
        for (i, chunk) in self.chunks.iter().enumerate() {
            let mut text_to_index = chunk.chunk_text.clone();

            // Also index the file's keywords (including Chinese equivalents) for better cross-language match
            if let Some(file) = self.index.files.get(&chunk.file_id) {
                let kw_text = file.keywords.join(" ");
                text_to_index.push_str(" ");
                text_to_index.push_str(&kw_text);
                // Also add title for title matching in BM25
                text_to_index.push_str(" ");
                text_to_index.push_str(&file.title);
                // Add keywords again weighted by repetition
                text_to_index.push_str(" ");
                text_to_index.push_str(&kw_text);
            }

            let tokens = tokenize(&text_to_index);
            let mut tf_map: HashMap<String, usize> = HashMap::new();
            for t in &tokens {
                *tf_map.entry(t.clone()).or_insert(0) += 1;
            }
            for (term, count) in tf_map {
                let tf = count as f64;
                index.entry(term).or_default().push((i, tf));
            }
        }
        self.inverted_index = Some(index);
    }

    pub fn search(&self, query: &str, category: Option<&str>, difficulty: Option<&str>, limit: usize) -> Vec<SearchMatch> {
        let query_lower = query.to_lowercase();
        let query_terms: Vec<String> = tokenize(&query_lower);
        let query_chars: Vec<String> = split_query_chars(&query_lower);

        let mut chunk_scores: HashMap<usize, f64> = HashMap::new();
        let inv_index = match &self.inverted_index {
            Some(idx) => idx,
            None => return vec![],
        };
        let k1 = 1.5;
        let b = 0.75;

        for term in &query_terms {
            if let Some(postings) = inv_index.get(term) {
                let df = postings.len() as f64;
                let idf = ((self.num_chunks as f64 - df + 0.5) / (df + 0.5) + 1.0).ln();
                for &(chunk_idx, tf) in postings {
                    let doc_len = self.chunks[chunk_idx].chunk_text.chars().count() as f64;
                    let bm25_score = idf * (tf * (k1 + 1.0)) / (tf + k1 * (1.0 - b + b * doc_len / self.avg_chunk_len));
                    *chunk_scores.entry(chunk_idx).or_insert(0.0) += bm25_score;
                }
            }
        }

        for term in &query_chars {
            if let Some(postings) = inv_index.get(term) {
                let df = postings.len() as f64;
                let idf = ((self.num_chunks as f64 - df + 0.5) / (df + 0.5) + 1.0).ln();
                let char_bonus = 0.3;
                for &(chunk_idx, tf) in postings {
                    let doc_len = self.chunks[chunk_idx].chunk_text.chars().count() as f64;
                    let bm25_score = idf * (tf * (k1 + 1.0)) / (tf + k1 * (1.0 - b + b * doc_len / self.avg_chunk_len));
                    *chunk_scores.entry(chunk_idx).or_insert(0.0) += bm25_score * char_bonus;
                }
            }
        }

        let query_lower_str = query_lower.as_str();
        let mut file_scores: HashMap<String, FileScore> = HashMap::new();

        for (chunk_idx, bm25_score) in &chunk_scores {
            let chunk = &self.chunks[*chunk_idx];
            let entry = file_scores.entry(chunk.file_id.clone()).or_insert(FileScore {
                title: chunk.file_title.clone(),
                score: 0.0,
                matched_chunks: Vec::new(),
            });
            let chunk_text_lower = chunk.chunk_text.to_lowercase();
            if chunk_text_lower.contains(query_lower_str) {
                entry.score += bm25_score * 1.5;
            } else {
                entry.score += *bm25_score;
            }
            entry.matched_chunks.push(*chunk_idx);
        }

        for (fid, file) in &self.index.files {
            let mut bonus = 0.0;
            let file_lower_title = file.title.to_lowercase();
            let file_lower_path = file.path.to_lowercase();
            let file_lower_summary = file.summary.to_lowercase();

            if file_lower_title.contains(query_lower_str) || query_lower_str.contains(&file_lower_title) {
                bonus += 8.0;
            }
            if file_lower_path.contains(query_lower_str) {
                bonus += 4.0;
            }

            for w in &query_chars {
                if file_lower_title.contains(w.as_str()) {
                    bonus += 2.0;
                    break;
                }
            }

            for kw in &file.keywords {
                let kw_lower = kw.to_lowercase();
                for t in &query_terms {
                    if kw_lower.contains(t.as_str()) || t.contains(kw_lower.as_str()) {
                        bonus += 3.0;
                        break;
                    }
                }
            }

            // Boost official documentation files
            if file.path.starts_with("官方文档/") || file.path.starts_with("official_docs/") {
                bonus += 15.0;
                // Extra boost for exact title matches
                let title_lower = file.title.to_lowercase();
                for t in &query_terms {
                    if title_lower.contains(t.as_str()) || t.contains(title_lower.as_str()) {
                        bonus += 5.0;
                        break;
                    }
                }
            }
            // Boost class reference files
            if file.path.contains("/classes/") || file.filename.starts_with("class_") {
                bonus += 10.0;
            }
            // Penalize video subtitle files (poor quality chunks)
            if file.filename.contains("P") && file.filename.contains('【') {
                bonus *= 0.3;
            }

            for cat in &file.category {
                let cat_lower = cat.to_lowercase();
                for t in &query_terms {
                    if cat_lower.contains(t.as_str()) || t.contains(cat_lower.as_str()) {
                        bonus += 1.0;
                        break;
                    }
                }
            }

            for w in &query_chars {
                if file_lower_summary.contains(w.as_str()) {
                    bonus += 0.3;
                }
            }

            let entry = file_scores.entry(fid.clone()).or_insert(FileScore {
                title: file.title.clone(),
                score: 0.0,
                matched_chunks: Vec::new(),
            });
            entry.score += bonus;
        }

        let mut scored: Vec<SearchMatch> = Vec::new();

        // Validate category/difficulty against known values — silently drop invalid filters
        let cat_valid = category.as_deref().map_or(true, |c| self.index.categories.contains_key(c));
        let diff_valid = difficulty.as_deref().map_or(true, |d| self.index.difficulty_levels.contains_key(d));

        for (fid, fs) in &file_scores {
            if fs.score <= 0.0 {
                continue;
            }

            if cat_valid {
                if let Some(cat) = category {
                    if let Some(file) = self.index.files.get(fid) {
                        if !file.category.iter().any(|c| c == cat) {
                            continue;
                        }
                    }
                }
            }
            if diff_valid {
                if let Some(diff) = difficulty {
                    if let Some(file) = self.index.files.get(fid) {
                        if file.difficulty != diff {
                            continue;
                        }
                    }
                }
            }

            let mut matched_chunks: Vec<ChunkData> = fs.matched_chunks.iter()
                .map(|&idx| self.chunks[idx].clone())
                .collect();
            matched_chunks.sort_by(|a, b| {
                let sa = chunk_scores.get(&find_chunk_idx(&self.chunks, &a.chunk_id)).copied().unwrap_or(0.0);
                let sb = chunk_scores.get(&find_chunk_idx(&self.chunks, &b.chunk_id)).copied().unwrap_or(0.0);
                sb.partial_cmp(&sa).unwrap_or(std::cmp::Ordering::Equal)
            });
            matched_chunks.truncate(3);

            let file = self.index.files.get(fid);
            scored.push(SearchMatch {
                file_id: fid.clone(),
                title: fs.title.clone(),
                path: file.map(|f| f.path.clone()).unwrap_or_default(),
                summary: file.map(|f| f.summary.clone()).unwrap_or_default(),
                category: file.map(|f| f.category.clone()).unwrap_or_default(),
                difficulty: file.map(|f| f.difficulty.clone()).unwrap_or_default(),
                keywords: file.map(|f| f.keywords.clone()).unwrap_or_default(),
                score: fs.score,
                chunks: matched_chunks,
            });
        }

        scored.sort_by(|a, b| b.score.partial_cmp(&a.score).unwrap_or(std::cmp::Ordering::Equal));
        scored.truncate(limit);
        scored
    }

    pub fn get_file_chunks(&self, file_id: &str) -> Vec<ChunkData> {
        self.chunks.iter()
            .filter(|c| c.file_id == file_id)
            .cloned()
            .collect()
    }

    pub fn get_files_by_category(&self, category: &str) -> Vec<&IndexFile> {
        self.index.categories.get(category)
            .map(|fids| {
                fids.iter()
                    .filter_map(|fid| self.index.files.get(fid))
                    .collect()
            })
            .unwrap_or_default()
    }

    pub fn get_overview(&self) -> IndexOverview {
        let categories: Vec<CategoryInfo> = self.index.categories.iter()
            .map(|(name, files)| CategoryInfo {
                name: name.clone(),
                count: files.len(),
            })
            .collect();

        let difficulties: Vec<DifficultyInfo> = self.index.difficulty_levels.iter()
            .map(|(name, files)| DifficultyInfo {
                name: name.clone(),
                count: files.len(),
            })
            .collect();

        IndexOverview {
            total_files: self.index.total_files,
            categories,
            difficulties,
            loaded: true,
        }
    }

    /// Rerank search results using embedding cosine similarity
    /// Combines BM25 score + normalized cosine similarity score
    pub fn rerank_with_embeddings(
        &self,
        results: &mut [SearchMatch],
        query_vec: &[f32],
        bm25_weight: f32,
        vec_weight: f32,
    ) {
        let emb = match &self.embeddings {
            Some(e) => e,
            None => return,
        };

        if query_vec.is_empty() {
            return;
        }

        // Collect all chunk IDs from results
        let result_chunks: Vec<String> = results.iter()
            .flat_map(|r| r.chunks.iter().map(|c| c.chunk_id.clone()))
            .collect();

        // Compute cosine similarity for each result based on its chunks
        let mut chunk_sims: HashMap<String, f32> = HashMap::new();
        for chunk_id in &result_chunks {
            if let Some(vec) = emb.embeddings.get(chunk_id) {
                let sim = cosine_similarity(query_vec, vec);
                chunk_sims.insert(chunk_id.clone(), sim);
            }
        }

        // Rerank: combine BM25 score with max chunk cosine similarity
        for result in results.iter_mut() {
            let max_chunk_sim = result.chunks.iter()
                .filter_map(|c| chunk_sims.get(&c.chunk_id))
                .cloned()
                .fold(f32::NEG_INFINITY, f32::max);

            if max_chunk_sim.is_finite() {
                // Normalize BM25 score to [0,1] range using sigmoid-like
                let norm_bm25 = 1.0 - 1.0 / (1.0 + result.score as f32 * 0.1);
                let combined = norm_bm25 * bm25_weight + max_chunk_sim * vec_weight;
                result.score = combined as f64;
            }
        }

        // Re-sort
        results.sort_by(|a, b| b.score.partial_cmp(&a.score).unwrap_or(std::cmp::Ordering::Equal));
    }

    pub fn get_related_files(&self, file_id: &str, limit: usize) -> Vec<&IndexFile> {
        let file = match self.index.files.get(file_id) {
            Some(f) => f,
            None => return vec![],
        };

        let mut scored: Vec<(&str, f64)> = Vec::new();
        for (fid, other) in &self.index.files {
            if fid == file_id {
                continue;
            }
            let mut score = 0.0;
            for cat in &file.category {
                if other.category.contains(cat) {
                    score += 2.0;
                }
            }
            for kw in &file.keywords {
                if other.keywords.contains(kw) {
                    score += 1.0;
                }
            }
            if std::path::Path::new(&file.path).parent() == std::path::Path::new(&other.path).parent() {
                score += 3.0;
            }
            if score > 0.0 {
                scored.push((fid, score));
            }
        }

        scored.sort_by(|a, b| b.1.partial_cmp(&a.1).unwrap_or(std::cmp::Ordering::Equal));
        scored.truncate(limit);

        scored.iter()
            .filter_map(|(fid, _)| self.index.files.get(*fid))
            .collect()
    }
}

fn find_chunk_idx(chunks: &[ChunkData], chunk_id: &str) -> usize {
    chunks.iter().position(|c| c.chunk_id == chunk_id).unwrap_or(0)
}

struct FileScore {
    title: String,
    score: f64,
    matched_chunks: Vec<usize>,
}

/// Tokenize text: extract meaningful terms including English words, Chinese bigrams, and single CJK chars
fn tokenize(text: &str) -> Vec<String> {
    let mut terms: Vec<String> = Vec::new();
    let chars: Vec<char> = text.chars().collect();
    let mut ascii_buf = String::new();
    let mut cjk_buf: Vec<char> = Vec::new();

    for &ch in &chars {
        if ch.is_ascii_alphanumeric() {
            if !cjk_buf.is_empty() { flush_cjk(&cjk_buf, &mut terms); cjk_buf.clear(); }
            ascii_buf.push(ch);
        } else if ch >= '\u{4e00}' && ch <= '\u{9fff}' {
            if !ascii_buf.is_empty() { terms.push(ascii_buf.clone().to_lowercase()); ascii_buf.clear(); }
            cjk_buf.push(ch);
        } else {
            if !ascii_buf.is_empty() { terms.push(ascii_buf.clone().to_lowercase()); ascii_buf.clear(); }
            if !cjk_buf.is_empty() { flush_cjk(&cjk_buf, &mut terms); cjk_buf.clear(); }
        }
    }
    if !ascii_buf.is_empty() { terms.push(ascii_buf.to_lowercase()); }
    if !cjk_buf.is_empty() { flush_cjk(&cjk_buf, &mut terms); }

    terms.sort();
    terms.dedup();
    terms
}

fn flush_cjk(buf: &[char], terms: &mut Vec<String>) {
    if buf.is_empty() {
        return;
    }
    for &ch in buf {
        terms.push(ch.to_string().to_lowercase());
    }
    for window in buf.windows(2) {
        let bigram: String = window.iter().collect();
        terms.push(bigram.to_lowercase());
    }
    if buf.len() >= 3 {
        let trigram: String = buf.iter().collect();
        terms.push(trigram.to_lowercase());
    }
}

/// Split query into individual CJK chars and ASCII alphanumeric words for metadata matching
fn split_query_chars(query: &str) -> Vec<String> {
    let mut words: Vec<String> = Vec::new();
    for token in query.split_whitespace() {
        let mut ascii_buf = String::new();
        for ch in token.chars() {
            if ch.is_ascii_alphanumeric() {
                ascii_buf.push(ch);
            } else if ch >= '\u{4e00}' && ch <= '\u{9fff}' {
                if !ascii_buf.is_empty() {
                    words.push(ascii_buf.clone().to_lowercase());
                    ascii_buf.clear();
                }
                words.push(ch.to_string().to_lowercase());
            } else {
                if !ascii_buf.is_empty() {
                    words.push(ascii_buf.clone().to_lowercase());
                    ascii_buf.clear();
                }
            }
        }
        if !ascii_buf.is_empty() {
            words.push(ascii_buf.to_lowercase());
        }
    }
    words.sort();
    words.dedup();
    words
}

#[derive(Debug, Clone)]
pub struct SearchMatch {
    pub file_id: String,
    pub title: String,
    pub path: String,
    pub summary: String,
    pub category: Vec<String>,
    pub difficulty: String,
    pub keywords: Vec<String>,
    pub score: f64,
    pub chunks: Vec<ChunkData>,
}
