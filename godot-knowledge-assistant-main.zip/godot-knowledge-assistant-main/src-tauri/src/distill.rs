use serde::{Deserialize, Serialize};
use std::collections::HashMap;
use std::fs;
use std::path::Path;

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct DistillProgress {
    pub phase: String,
    pub current: usize,
    pub total: usize,
    pub message: String,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct DistillResult {
    pub total_files: usize,
    pub total_chunks: usize,
    pub index_path: String,
    pub chunks_path: String,
    pub categories: Vec<String>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
struct IndexFile {
    id: String,
    filename: String,
    path: String,
    title: String,
    size: i64,
    line_count: i64,
    summary: String,
    category: Vec<String>,
    difficulty: String,
    keywords: Vec<String>,
    chunks: Vec<ChunkRef>,
    modified: String,
    prerequisites: Vec<String>,
    related_files: Vec<String>,
    chunk_count: usize,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
struct ChunkRef {
    chunk_id: String,
    summary: String,
    keywords: Vec<String>,
    start_line: usize,
    end_line: usize,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
struct IndexRoot {
    total_files: usize,
    files: HashMap<String, IndexFile>,
    categories: HashMap<String, Vec<String>>,
    keywords: HashMap<String, Vec<String>>,
    difficulty_levels: HashMap<String, Vec<String>>,
    source_dir: String,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
struct ChunkData {
    chunk_id: String,
    file_id: String,
    file_title: String,
    file_path: String,
    summary: String,
    keywords: Vec<String>,
    start_line: usize,
    end_line: usize,
    chunk_text: String,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
struct ChunksRoot {
    total_chunks: usize,
    chunks: Vec<ChunkData>,
}

/// Excluded file patterns (meta-index, auto-generated summaries)
const EXCLUDED_PATTERNS: &[&str] = &[
    "godot_fulltext",
    "fulltext",
    "全文检索",
    "全文索引",
];

pub fn distill(source_dir: &str, index_path: &str, chunks_path: &str) -> Result<DistillResult, String> {
    let source = Path::new(source_dir);
    if !source.is_dir() {
        return Err(format!("Source directory not found: {}", source_dir));
    }

    let mut txt_files: Vec<std::path::PathBuf> = Vec::new();
    collect_txt_files(source, &mut txt_files, source)?;

    if txt_files.is_empty() {
        return Err("No .txt files found in source directory".to_string());
    }

    txt_files.sort();
    let mut files_map: HashMap<String, IndexFile> = HashMap::new();
    let mut all_chunks: Vec<ChunkData> = Vec::new();
    let mut categories: HashMap<String, Vec<String>> = HashMap::new();
    let mut keywords: HashMap<String, Vec<String>> = HashMap::new();
    let mut difficulty_levels: HashMap<String, Vec<String>> = HashMap::new();
    let mut skipped = 0usize;

    for (i, file_path) in txt_files.iter().enumerate() {
        let relative_path = file_path.strip_prefix(source).map_err(|e| e.to_string())?;
        let relative_str = relative_path.to_string_lossy().replace("\\", "/");

        let filename = file_path.file_name()
            .and_then(|n| n.to_str())
            .unwrap_or("unknown.txt")
            .to_string();

        let content = match fs::read_to_string(file_path) {
            Ok(c) => c,
            Err(e) => {
                eprintln!("  Warning: cannot read {}: {}", file_path.display(), e);
                skipped += 1;
                continue;
            }
        };
        let lines: Vec<&str> = content.lines().collect();

        if lines.is_empty() {
            skipped += 1;
            continue;
        }

        let title_lower = filename.to_lowercase();
        if EXCLUDED_PATTERNS.iter().any(|p| title_lower.contains(p)) {
            println!("  Skipping excluded file: {}", filename);
            skipped += 1;
            continue;
        }

        let fid = format!("f{:04}", i + 1 - skipped);

        // ---- 1. Content analysis ----
        let cleaned = clean_content(&lines);
        let cleaned_lines: Vec<&str> = cleaned.lines().collect();

        // ---- 2. Title extraction ----
        let title = extract_title(&filename, &lines);

        // ---- 3. Structure detection ----
        let sections = detect_sections(&cleaned_lines, &lines);

        // ---- 4. Summary generation ----
        let summary = extract_summary(&cleaned, &lines, &title);

        // ---- 5. Metadata inference ----
        let file_cats = infer_categories(&title, &cleaned);
        let diff = infer_difficulty(&cleaned);
        let file_kws = extract_keywords_full(&title, &cleaned);

        // ---- 6. Smart chunking ----
        let mut file_chunks: Vec<ChunkRef> = Vec::new();
        let mut chunk_idx = 0;

        if !sections.is_empty() {
            for sec in &sections {
                if sec.end_line <= sec.start_line { continue; }
                let chunk_text = cleaned_lines[sec.start_line..sec.end_line].join("\n");
                let chunk_text = chunk_text.trim();
                if chunk_text.len() < 20 { continue; }

                chunk_idx += 1;
                let chunk_id = format!("{}-c{:02}", fid, chunk_idx);
                let chunk_summary = make_chunk_summary(chunk_text, &sec.heading);
                let chunk_kws = extract_chunk_keywords(chunk_text, &file_kws);

                all_chunks.push(ChunkData {
                    chunk_id: chunk_id.clone(),
                    file_id: fid.clone(),
                    file_title: title.clone(),
                    file_path: relative_str.clone(),
                    summary: chunk_summary.clone(),
                    keywords: chunk_kws.clone(),
                    start_line: sec.start_line + 1,
                    end_line: sec.end_line + 1,
                    chunk_text: chunk_text.to_string(),
                });
                file_chunks.push(ChunkRef {
                    chunk_id,
                    summary: chunk_summary,
                    keywords: chunk_kws,
                    start_line: sec.start_line + 1,
                    end_line: sec.end_line + 1,
                });
            }
        }

        if file_chunks.is_empty() {
            let paragraph_chunks = split_by_paragraphs(&cleaned_lines, 2000);
            for pc in &paragraph_chunks {
                if pc.text.len() < 20 { continue; }
                chunk_idx += 1;
                let chunk_id = format!("{}-c{:02}", fid, chunk_idx);
                let chunk_summary = make_chunk_summary(&pc.text, "");
                let chunk_kws = extract_chunk_keywords(&pc.text, &file_kws);

                    all_chunks.push(ChunkData {
                        chunk_id: chunk_id.clone(),
                        file_id: fid.clone(),
                        file_title: title.clone(),
                        file_path: relative_str.clone(),
                        summary: chunk_summary.clone(),
                        keywords: chunk_kws.clone(),
                        start_line: pc.start_line + 1,
                        end_line: pc.end_line + 1,
                        chunk_text: pc.text.clone(),
                    });
                    file_chunks.push(ChunkRef {
                        chunk_id,
                        summary: chunk_summary,
                        keywords: chunk_kws,
                        start_line: pc.start_line + 1,
                        end_line: pc.end_line + 1,
                    });
            }
        }

        if file_chunks.is_empty() {
            let fallback_chunks = split_fixed_size(&cleaned_lines, 30, 5);
            for fc in &fallback_chunks {
                if fc.text.len() < 20 { continue; }
                chunk_idx += 1;
                let chunk_id = format!("{}-c{:02}", fid, chunk_idx);
                let chunk_summary = make_chunk_summary(&fc.text, "");
                let chunk_kws = extract_chunk_keywords(&fc.text, &file_kws);

                all_chunks.push(ChunkData {
                    chunk_id: chunk_id.clone(),
                    file_id: fid.clone(),
                    file_title: title.clone(),
                    file_path: relative_str.clone(),
                    summary: chunk_summary.clone(),
                    keywords: chunk_kws.clone(),
                    start_line: fc.start_line + 1,
                    end_line: fc.end_line + 1,
                    chunk_text: fc.text.clone(),
                });
                file_chunks.push(ChunkRef {
                    chunk_id,
                    summary: chunk_summary,
                    keywords: chunk_kws,
                    start_line: fc.start_line + 1,
                    end_line: fc.end_line + 1,
                });
            }
        }

        if file_chunks.is_empty() {
            skipped += 1;
            continue;
        }

        let line_count = cleaned_lines.len() as i64;

        for cat in &file_cats {
            categories.entry(cat.clone()).or_default().push(fid.clone());
        }
        for kw in &file_kws {
            keywords.entry(kw.clone()).or_default().push(fid.clone());
        }
        difficulty_levels.entry(diff.clone()).or_default().push(fid.clone());

        files_map.insert(fid.clone(), IndexFile {
            id: fid.clone(),
            filename,
            path: relative_str,
            title,
            size: cleaned.len() as i64,
            line_count,
            summary,
            category: file_cats,
            difficulty: diff,
            keywords: file_kws,
            chunks: file_chunks,
            modified: chrono::Local::now().format("%Y-%m-%d").to_string(),
            prerequisites: vec![],
            related_files: vec![],
            chunk_count: chunk_idx,
        });

        if (i + 1) % 100 == 0 || i + 1 == txt_files.len() {
            println!("  Processed {}/{} files ({} skipped)...", i + 1 - skipped, txt_files.len(), skipped);
        }
    }

    let index_root = IndexRoot {
        total_files: files_map.len(),
        files: files_map,
        categories: categories.into_iter().map(|(k, v)| (k, {
            let mut v = v; v.sort(); v.dedup(); v
        })).collect(),
        keywords: keywords.into_iter().map(|(k, v)| (k, {
            let mut v = v; v.sort(); v.dedup(); v
        })).collect(),
        difficulty_levels: difficulty_levels.into_iter().map(|(k, v)| (k, {
            let mut v = v; v.sort(); v.dedup(); v
        })).collect(),
        source_dir: source_dir.to_string(),
    };

    let chunks_root = ChunksRoot {
        total_chunks: all_chunks.len(),
        chunks: all_chunks,
    };

    let index_json = serde_json::to_string_pretty(&index_root)
        .map_err(|e| format!("Failed to serialize index: {}", e))?;
    let chunks_json = serde_json::to_string_pretty(&chunks_root)
        .map_err(|e| format!("Failed to serialize chunks: {}", e))?;

    if let Some(parent) = Path::new(index_path).parent() {
        fs::create_dir_all(parent).map_err(|e| format!("Failed to create dir: {}", e))?;
    }

    fs::write(index_path, &index_json)
        .map_err(|e| format!("Failed to write index: {}", e))?;
    fs::write(chunks_path, &chunks_json)
        .map_err(|e| format!("Failed to write chunks: {}", e))?;

    let cat_names: Vec<String> = index_root.categories.keys().cloned().collect();
    println!("  Total: {} files, {} chunks, {} categories", index_root.total_files, chunks_root.total_chunks, cat_names.len());

    Ok(DistillResult {
        total_files: index_root.total_files,
        total_chunks: chunks_root.total_chunks,
        index_path: index_path.to_string(),
        chunks_path: chunks_path.to_string(),
        categories: cat_names,
    })
}

fn collect_txt_files(dir: &Path, files: &mut Vec<std::path::PathBuf>, base: &Path) -> Result<(), String> {
    let dir_name = dir.file_name().and_then(|n| n.to_str()).unwrap_or("");
    // Skip non-text asset directories
    if dir_name.starts_with('_') || dir_name == "node_modules" || dir_name == "target" {
        return Ok(());
    }

    let read_dir = match fs::read_dir(dir) {
        Ok(d) => d,
        Err(e) => {
            eprintln!("  Warning: cannot read dir {}: {}", dir.display(), e);
            return Ok(());
        }
    };

    for entry in read_dir.flatten() {
        let path = entry.path();
        if path.is_dir() {
            collect_txt_files(&path, files, base)?;
        } else if path.extension().and_then(|e| e.to_str()) == Some("txt") {
            // Skip empty files
            if let Ok(meta) = path.metadata() {
                if meta.len() == 0 { continue; }
            }
            files.push(path);
        }
    }
    Ok(())
}

// ─── Content Cleaning ───────────────────────────────────────────────

/// Clean raw file content: strip video metadata header, normalize whitespace
fn clean_content(lines: &[&str]) -> String {
    let n = lines.len();
    if n == 0 { return String::new(); }

    let first_lines: Vec<&str> = lines.iter().take(10).map(|l| l.trim()).collect();
    let has_video_header = first_lines.iter().any(|l| l.contains("视频"));
    let has_dash_sep = first_lines.iter().any(|l| l.starts_with("---") && l.trim().len() >= 3);
    let has_subtitle_marker = first_lines.iter().any(|l| l.contains("字幕原文") || l.contains("原文"));

    let start_line = if has_video_header && (has_dash_sep || has_subtitle_marker) {
        // Find where the transcript actually begins (after --- 字幕原文 ---)
        let mut found_sep = false;
        let mut idx = 0;
        for (i, line) in lines.iter().enumerate() {
            let t = line.trim();
            if t.starts_with("---") && t.trim().len() >= 3 {
                if found_sep { idx = i + 1; break; }
                found_sep = true;
            }
            if t.contains("字幕原文") && found_sep { idx = i + 1; break; }
        }
        idx
    } else {
        0
    };

    let mut cleaned = String::new();
    let mut prev_empty = false;
    let mut line_buf: Vec<&str> = Vec::new();

    for (i, line) in lines.iter().enumerate() {
        if i < start_line { continue; }
        let trimmed = line.trim();

        if trimmed.is_empty() {
            if !line_buf.is_empty() {
                cleaned.push_str(&line_buf.join(" "));
                cleaned.push('\n');
                line_buf.clear();
            }
            if !prev_empty {
                cleaned.push('\n');
                prev_empty = true;
            }
            continue;
        }

        prev_empty = false;

        // Preserve section headers
        if is_heading(trimmed) || trimmed.starts_with("---") || trimmed.starts_with("===") {
            if !line_buf.is_empty() {
                cleaned.push_str(&line_buf.join(" "));
                cleaned.push('\n');
                line_buf.clear();
            }
            cleaned.push_str(trimmed);
            cleaned.push('\n');
            continue;
        }

        // Accumulate short lines (transcript fragments) into paragraphs
        if trimmed.len() < 50 && !trimmed.ends_with('.') && !trimmed.ends_with('。')
            && !trimmed.ends_with('！') && !trimmed.ends_with('？') && !trimmed.ends_with(')')
            && !trimmed.ends_with('>')
        {
            line_buf.push(trimmed);
        } else {
            if !line_buf.is_empty() {
                cleaned.push_str(&line_buf.join(" "));
                cleaned.push(' ');
                line_buf.clear();
            }
            cleaned.push_str(trimmed);
            cleaned.push('\n');
        }
    }

    if !line_buf.is_empty() {
        cleaned.push_str(&line_buf.join(" "));
        cleaned.push('\n');
    }

    // Normalize multiple blank lines to max 2
    let mut result = String::new();
    let mut blank_count = 0;
    for ch in cleaned.chars() {
        if ch == '\n' {
            blank_count += 1;
            if blank_count <= 2 {
                result.push(ch);
            }
        } else {
            blank_count = 0;
            result.push(ch);
        }
    }

    result.trim().to_string()
}

fn is_heading(line: &str) -> bool {
    let t = line.trim();
    if t.starts_with('#') { return true; }
    if t.len() >= 2 && t.chars().all(|c| c == '=' || c == '-') { return true; }
    if t.len() >= 3 && t.chars().all(|c| c == '=' || c == '-') { return false; }
    false
}

// ─── Structure Detection ────────────────────────────────────────────

#[derive(Debug)]
struct Section {
    heading: String,
    start_line: usize,
    end_line: usize,
}

/// Detect logical sections in cleaned content
fn detect_sections(cleaned: &[&str], raw_lines: &[&str]) -> Vec<Section> {
    let mut sections: Vec<Section> = Vec::new();
    let mut current_start: usize = 0;
    let mut current_heading = String::new();
    // First pass: look for RST-style headers (=, - underline) and markdown headers (#)
    let cleaned_str = cleaned.join("\n");
    let clines: Vec<&str> = cleaned_str.lines().collect();
    let n = clines.len();

    for i in 0..n {
        let line = clines[i].trim();
        if line.is_empty() { continue; }

        // Detect RST header (text followed by === or --- underline)
        if i + 1 < n {
            let next = clines[i + 1].trim();
            if next.chars().all(|c| c == '=') && next.len() >= 3 && line.len() > 0 && line.len() < 80 {
                if !sections.is_empty() {
                    sections.last_mut().unwrap().end_line = i;
                }
                current_start = i;
                current_heading = line.to_string();
                sections.push(Section { heading: current_heading.clone(), start_line: i, end_line: n });
                continue;
            }
        }

        // Detect markdown header
        if line.starts_with('#') {
                if !sections.is_empty() {
                    sections.last_mut().unwrap().end_line = i;
                }
                sections.push(Section { heading: line.to_string(), start_line: i, end_line: n });
            continue;
        }

        // Detect numbered section (数字.  or 第X章/节/部分)
        if line.len() < 60 {
            let has_numbered = line.chars().next().map_or(false, |c| c.is_ascii_digit());
            let has_chapter = line.contains('\u{7b2c}') && (line.contains('\u{7ae0}') || line.contains('\u{8282}') || line.contains("\u{90e8}\u{5206}"));
            if has_numbered || has_chapter {
                if !sections.is_empty() {
                    sections.last_mut().unwrap().end_line = i;
                }
                current_start = i;
                current_heading = line.to_string();
                sections.push(Section { heading: current_heading.clone(), start_line: i, end_line: n });
                continue;
            }
        }
    }

    if sections.is_empty() {
        // Check raw lines for RST headers (some use different formatting)
        let n2 = raw_lines.len();
        let mut in_rst = false;
        for i in 0..n2.saturating_sub(1) {
            let line = raw_lines[i].trim();
            let next = raw_lines[i + 1].trim();
            if line.len() > 0 && line.len() < 80 && !line.starts_with(':') {
                if next.chars().all(|c| c == '=') && next.len() >= 3 {
                    let rst_heading = line.to_string();
                    sections.push(Section { heading: rst_heading, start_line: i, end_line: n2 });
                    in_rst = true;
                    continue;
                }
                if next.chars().all(|c| c == '-') && next.len() >= 3 && in_rst {
                    sections.last_mut().unwrap().end_line = i;
                    sections.push(Section { heading: line.to_string(), start_line: i, end_line: n2 });
                    continue;
                }
            }
        }
    }

    sections
}

// ─── Chunking Strategies ────────────────────────────────────────────

struct ChunkResult {
    text: String,
    start_line: usize,
    end_line: usize,
}

/// Split cleaned lines by paragraph boundaries with max char limit
fn split_by_paragraphs(lines: &[&str], max_chars: usize) -> Vec<ChunkResult> {
    let mut chunks: Vec<ChunkResult> = Vec::new();
    let mut current = String::new();
    let mut start = 0usize;
    let mut line_offset = 0usize;

    for (i, line) in lines.iter().enumerate() {
        let is_para_break = line.trim().is_empty() && i + 1 < lines.len() && !lines[i + 1].trim().is_empty();

        if !current.is_empty() && (is_para_break || current.len() + line.len() + 1 > max_chars) {
            chunks.push(ChunkResult {
                text: current.trim().to_string(),
                start_line: start,
                end_line: i,
            });
            current = String::new();
            start = i;
        }

        if current.is_empty() { start = i; }
        if !line.trim().is_empty() {
            if !current.is_empty() { current.push('\n'); }
            current.push_str(line);
        }
        line_offset = i;
    }

    if !current.trim().is_empty() {
        chunks.push(ChunkResult {
            text: current.trim().to_string(),
            start_line: start,
            end_line: line_offset + 1,
        });
    }

    chunks
}

/// Fixed-size chunking with overlap for documents with no structure
fn split_fixed_size(lines: &[&str], chunk_lines: usize, overlap: usize) -> Vec<ChunkResult> {
    let mut chunks: Vec<ChunkResult> = Vec::new();
    if lines.is_empty() { return chunks; }
    let step = chunk_lines.saturating_sub(overlap);
    if step == 0 { return chunks; }

    let mut start = 0usize;
    while start < lines.len() {
        let end = std::cmp::min(start + chunk_lines, lines.len());
        let text = lines[start..end].join("\n").trim().to_string();
        if !text.is_empty() {
            chunks.push(ChunkResult { text, start_line: start, end_line: end });
        }
        start += step;
    }
    chunks
}

// ─── Title Extraction ───────────────────────────────────────────────

/// Extract meaningful title from filename and content
fn extract_title(filename: &str, lines: &[&str]) -> String {
    // Try to find video title line
    for line in lines.iter().take(10) {
        let t = line.trim();
        if t.contains("视频标题") {
            let colon_pos = t.find(':').or_else(|| t.find('\u{ff1a}'));
            if let Some(idx) = colon_pos {
                let char_len = t[idx..].chars().next().map(|c| c.len_utf8()).unwrap_or(1);
                let title = t[idx + char_len..].trim();
                if !title.is_empty() { return title.to_string(); }
            }
        }
    }

    // Fallback: extract from filename
    let name = filename.strip_suffix(".txt").unwrap_or(filename);
    let mut clean = name.to_string();

    // Remove patterns: 【...】, (date), P101, trailing -number
    let remove_pats: &[&str] = &[
        "【", "】", "(", ")", "（", "）",
    ];
    for p in remove_pats {
        clean = clean.replace(p, "");
    }

    // Remove date-like patterns
    let mut result = String::new();
    let mut i = 0;
    let chars: Vec<char> = clean.chars().collect();
    while i < chars.len() {
        if i + 10 <= chars.len() {
            let slice: String = chars[i..i+10].iter().collect();
            if slice.chars().filter(|c| c.is_ascii_digit() || *c == '-').count() >= 8
                && slice.contains('-')
            {
                i += 10;
                continue;
            }
        }
        result.push(chars[i]);
        i += 1;
    }

    // Remove P-number patterns
    let mut result2 = String::new();
    i = 0;
    let chars2: Vec<char> = result.chars().collect();
    while i < chars2.len() {
        if chars2[i] == 'P' || chars2[i] == 'p' {
            let mut j = i + 1;
            while j < chars2.len() && chars2[j].is_ascii_digit() { j += 1; }
            if j > i + 1 { i = j; continue; }
        }
        result2.push(chars2[i]);
        i += 1;
    }

    let result2 = result2.trim().trim_matches(&['-', '_', ' ', '：', ':', '《', '》'][..]).to_string();
    if result2.is_empty() || result2.len() < 3 { name.to_string() } else { result2 }
}

// ─── Summary Generation ─────────────────────────────────────────────

/// Slice string safely at UTF-8 char boundary
fn safe_slice(s: &str, max_byte_len: usize) -> &str {
    if s.len() <= max_byte_len { return s; }
    let idx = s.char_indices().take_while(|(i,_)| *i < max_byte_len).last().map(|(i,_)| i).unwrap_or(0);
    &s[..idx]
}

/// Generate a meaningful file summary
fn extract_summary(cleaned: &str, raw_lines: &[&str], title: &str) -> String {
    // For transcript files, check video description line
    for line in raw_lines.iter().take(10) {
        let t = line.trim();
        if t.contains("视频简介") || t.starts_with("视频简介") {
            let desc = t.split(&['：', ':'][..]).nth(1).unwrap_or("").trim();
            if desc.len() > 10 {
                let truncated = safe_slice(desc, 200);
                return format!("{}: {}", title, truncated);
            }
        }
    }

    // Find first meaningful paragraph in cleaned text
    let paragraphs: Vec<&str> = cleaned.split("\n\n")
        .map(|p| p.trim())
        .filter(|p| p.len() > 30)
        .collect();

    if let Some(first) = paragraphs.first() {
        let s = safe_slice(first, 250);
        return s.to_string();
    }

    // Last resort: first 200 chars of cleaned content
    let s = safe_slice(cleaned, 200);
    s.to_string()
}

/// Generate a concise chunk summary using the section heading + first line
fn make_chunk_summary(chunk_text: &str, heading: &str) -> String {
    let first_line = chunk_text.lines().next().unwrap_or("").trim();
    let first_line = safe_slice(first_line, 120);

    if !heading.is_empty() && first_line.len() > 3 {
        format!("[{}] {}", heading, first_line)
    } else if first_line.len() > 3 {
        first_line.to_string()
    } else {
        let s = safe_slice(chunk_text, 150);
        s.to_string()
    }
}

// ─── Category Inference ─────────────────────────────────────────────

fn infer_categories(title: &str, content: &str) -> Vec<String> {
    let max_len = std::cmp::min(500, content.len());
    let safe_boundary = content.char_indices().take_while(|(i,_)| *i < max_len).last().map(|(i,_)| i).unwrap_or(0);
    let prefix = &content[..safe_boundary];
    let lower = format!("{} {}", title, prefix).to_lowercase();
    let mut cats = Vec::new();

    let cat_map: Vec<(&str, Vec<&str>)> = vec![
        ("基础", vec!["基础", "入门", "简介", "介绍", "overview", "基本", "getting started", "first"]),
        ("脚本", vec!["脚本", "gdscript", "语法", "函数", "变量", "类", "代码", "coding", "编程"]),
        ("场景", vec!["场景", "scen", "节点", "node", "树", "tree", "instance"]),
        ("动画", vec!["动画", "animat", "帧", "tween", "骨骼", "skeleton", "spine"]),
        ("物理", vec!["物理", "physics", "碰撞", "rigid", "body", "力", "force", "gravity"]),
        ("UI", vec!["ui", "界面", "按钮", "label", "text", "menu", "button", "control", "gui"]),
        ("着色器", vec!["shader", "材质", "material", "着色", "纹理", "texture", "shading"]),
        ("信号", vec!["信号", "signal", "连接", "emit", "connect"]),
        ("性能优化", vec!["性能", "优化", "performance", "profiling", "optimize"]),
        ("资源管理", vec!["资源", "resource", "加载", "preload", "save", "load", "file"]),
        ("3D", vec!["3d", "三维", "立体", "mesh", "camera", "light", "shadow"]),
        ("2D", vec!["2d", "二维", "sprite", "tilemap", "tile"]),
        ("音频", vec!["音频", "audio", "sound", "music", "voice"]),
        ("输入控制", vec!["输入", "input", "键盘", "鼠标", "触控", "keyboard", "mouse", "touch"]),
        ("多人游戏", vec!["多人", "multiplayer", "网络", "联网", "network", "online"]),
        ("调试", vec!["调试", "debug", "错误", "日志", "log", "error"]),
        ("导出", vec!["导出", "export", "打包", "build", "publish", "deploy"]),
        ("插件开发", vec!["插件", "plugin", "扩展", "extension"]),
        ("导航", vec!["导航", "navigation", "navmesh", "path", "寻路"]),
        ("渲染", vec!["渲染", "render", "viewport", "camera", "visual"]),
    ];

    for (cat_name, indicators) in cat_map {
        for ind in indicators {
            if lower.contains(ind) {
                cats.push(cat_name.to_string());
                break;
            }
        }
    }

    if cats.is_empty() {
        cats.push("基础".to_string());
    }

    cats.sort();
    cats.dedup();
    cats.truncate(3);
    cats
}

// ─── Difficulty Inference ───────────────────────────────────────────

fn infer_difficulty(content: &str) -> String {
    let max_len = std::cmp::min(1500, content.len());
    let preview = content[..content.char_indices().take_while(|(i,_)| *i < max_len).last().map(|(i,_)| i).unwrap_or(0)].to_lowercase();
    let advanced_indicators = vec![
        "高级", "复杂", "优化", "custom", "底层", "系统", "反射", "native",
        "advanced", "complex", "optimization", "internal",
    ];
    let intermediate_indicators = vec![
        "中级", "进阶", "技巧", "模式", "组件", "继承", "信号",
        "intermediate", "pattern", "component",
    ];

    for ind in &advanced_indicators {
        if preview.contains(ind) { return "高级".to_string(); }
    }
    for ind in &intermediate_indicators {
        if preview.contains(ind) { return "中级".to_string(); }
    }
    "初级".to_string()
}

// ─── Full Keyword Extraction ────────────────────────────────────────

/// Extract keywords from the FULL document using term frequency
fn extract_keywords_full(title: &str, content: &str) -> Vec<String> {
    let text = format!("{} {}", title, content);
    let chars: Vec<char> = text.chars().collect();
    let mut kw_scores: HashMap<String, usize> = HashMap::new();
    let ascii_stop = build_ascii_stopwords();

    let mut ascii_word = String::new();
    let mut cjk_chars: Vec<char> = Vec::new();

    for &ch in &chars {
        if ch.is_ascii_alphanumeric() || ch == '_' || ch == '-' {
            ascii_word.push(ch);
            if !cjk_chars.is_empty() {
                score_cjk_term(&cjk_chars, &mut kw_scores);
                cjk_chars.clear();
            }
        } else if ch >= '\u{4e00}' && ch <= '\u{9fff}' {
            cjk_chars.push(ch);
            if !ascii_word.is_empty() {
                score_ascii_term(&ascii_word, &ascii_stop, &mut kw_scores);
                ascii_word.clear();
            }
        } else {
            if !ascii_word.is_empty() {
                score_ascii_term(&ascii_word, &ascii_stop, &mut kw_scores);
                ascii_word.clear();
            }
            if !cjk_chars.is_empty() {
                score_cjk_term(&cjk_chars, &mut kw_scores);
                cjk_chars.clear();
            }
        }
    }
    if !ascii_word.is_empty() { score_ascii_term(&ascii_word, &ascii_stop, &mut kw_scores); }
    if !cjk_chars.is_empty() { score_cjk_term(&cjk_chars, &mut kw_scores); }

    let mut sorted: Vec<(String, usize)> = kw_scores.into_iter().collect();
    sorted.sort_by(|a, b| b.1.cmp(&a.1));
    sorted.truncate(12);
    sorted.into_iter().map(|(k, _)| k).collect()
}

fn score_ascii_term(word: &str, stopwords: &[&str], scores: &mut HashMap<String, usize>) {
    let w = word.to_lowercase();
    if stopwords.contains(&w.as_str()) || w.len() < 2 { return; }
    let score = if w.len() >= 5 { 3 } else { 2 };
    *scores.entry(word.to_string()).or_insert(0) += score;
}

fn score_cjk_term(chars: &[char], scores: &mut HashMap<String, usize>) {
    let full: String = chars.iter().collect();
    if chars.len() == 1 {
        *scores.entry(full).or_insert(0) += 1;
        return;
    }
    // Full word: high score
    *scores.entry(full).or_insert(0) += 3;
    // Bigrams: medium score
    for w in chars.windows(2) {
        let bigram: String = w.iter().collect();
        *scores.entry(bigram).or_insert(0) += 2;
    }
    // Single chars: low score (only for longer compound words)
    if chars.len() >= 3 {
        for &ch in chars {
            *scores.entry(ch.to_string()).or_insert(0) += 1;
        }
    }
}

fn build_ascii_stopwords() -> Vec<&'static str> {
    vec![
        "the", "this", "that", "these", "those", "and", "for", "with", "from",
        "are", "has", "have", "had", "was", "were", "not", "can", "all", "will",
        "its", "but", "you", "your", "our", "their", "them", "they", "she", "his",
        "class", "void", "int", "static", "const", "bool", "float", "double",
        "auto", "set", "get", "use", "using", "new", "return", "if", "else",
        "in", "to", "of", "is", "on", "at", "by", "be", "or", "an", "as", "do",
        "no", "we", "it", "so", "up", "out", "about", "just", "also", "very",
        "function", "var", "signal", "enum", "break", "continue", "while",
        "print", "true", "false", "null", "self", "super", "extends", "pass",
        "then", "than", "more", "some", "any", "each", "every", "own", "same",
        "too", "very", "just", "because", "when", "where", "what", "which",
        "who", "how", "why", "now", "here", "there", "all", "both", "each",
    ]
}

// ─── Chunk-level Keywords ───────────────────────────────────────────

/// Extract chunk-specific keywords: combine file-level keywords with terms from this chunk
fn extract_chunk_keywords(chunk_text: &str, file_kws: &[String]) -> Vec<String> {
    let mut combined: Vec<String> = file_kws.to_vec();
    let mut local_scores: HashMap<String, usize> = HashMap::new();
    let chars: Vec<char> = chunk_text.chars().collect();
    let mut cjk_buf: Vec<char> = Vec::new();

    for &ch in &chars {
        if ch >= '\u{4e00}' && ch <= '\u{9fff}' {
            cjk_buf.push(ch);
        } else if !cjk_buf.is_empty() {
            if cjk_buf.len() >= 2 {
                let full: String = cjk_buf.iter().collect();
                *local_scores.entry(full).or_insert(0) += 2;
                for w in cjk_buf.windows(2) {
                    let bg: String = w.iter().collect();
                    *local_scores.entry(bg).or_insert(0) += 1;
                }
            }
            cjk_buf.clear();
        }
    }
    if cjk_buf.len() >= 2 {
        let full: String = cjk_buf.iter().collect();
        *local_scores.entry(full).or_insert(0) += 2;
        for w in cjk_buf.windows(2) {
            let bg: String = w.iter().collect();
            *local_scores.entry(bg).or_insert(0) += 1;
        }
    }

    let mut local_terms: Vec<(String, usize)> = local_scores.into_iter().collect();
    local_terms.sort_by(|a, b| b.1.cmp(&a.1));
    for (term, _) in local_terms.iter().take(4) {
        if !combined.contains(term) {
            combined.push(term.clone());
        }
    }

    combined.truncate(10);
    combined
}
