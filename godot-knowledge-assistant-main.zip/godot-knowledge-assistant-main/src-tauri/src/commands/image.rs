use base64::{Engine as _, engine::general_purpose::STANDARD as BASE64};
use serde::Serialize;
use std::fs;
use std::path::Path;

#[derive(Debug, Serialize)]
pub struct LocalImage {
    pub path: String,
    pub name: String,
    pub url: String,
    pub tags: Vec<String>,
    pub size: u64,
}

#[tauri::command]
pub async fn download_image_as_data_url(url: String) -> Result<String, String> {
    let response = reqwest::get(&url)
        .await
        .map_err(|e| format!("Failed to download image: {}", e))?;

    let content_type = response.headers()
        .get("content-type")
        .and_then(|v| v.to_str().ok())
        .unwrap_or("image/jpeg")
        .to_string();

    let bytes = response.bytes()
        .await
        .map_err(|e| format!("Failed to read image bytes: {}", e))?;

    let b64 = BASE64.encode(&bytes);
    Ok(format!("data:{};base64,{}", content_type, b64))
}

#[tauri::command]
pub fn scan_local_images(dir: String) -> Result<Vec<LocalImage>, String> {
    let path = Path::new(&dir);
    if !path.is_dir() {
        return Err(format!("Directory not found: {}", dir));
    }

    let mut images = Vec::new();
    let image_exts = ["jpg", "jpeg", "png", "gif", "webp", "bmp", "svg"];

    scan_images_recursive(path, path, &image_exts, &mut images)?;

    Ok(images)
}

fn scan_images_recursive(base: &Path, dir: &Path, exts: &[&str], images: &mut Vec<LocalImage>) -> Result<(), String> {
    for entry in fs::read_dir(dir).map_err(|e| format!("Failed to read dir: {}", e))? {
        let entry = entry.map_err(|e| e.to_string())?;
        let entry_path = entry.path();

        if entry_path.is_dir() {
            scan_images_recursive(base, &entry_path, exts, images)?;
        } else if entry_path.is_file() {
            if let Some(ext) = entry_path.extension().and_then(|e| e.to_str()) {
                if exts.contains(&ext.to_lowercase().as_str()) {
                    let relative = entry_path.strip_prefix(base)
                        .map(|p| p.to_string_lossy().to_string())
                        .unwrap_or_default()
                        .replace("\\", "/");

                    let name = entry_path.file_stem()
                        .and_then(|n| n.to_str())
                        .unwrap_or("unknown")
                        .to_string();

                    let metadata = fs::metadata(&entry_path).ok();
                    let size = metadata.map(|m| m.len()).unwrap_or(0);

                    let tags = infer_image_tags(&name, &relative);

                    images.push(LocalImage {
                        path: entry_path.to_string_lossy().to_string(),
                        name,
                        url: format!("asset://localhost/{}", relative),
                        tags,
                        size,
                    });
                }
            }
        }
    }
    Ok(())
}

#[tauri::command]
pub fn delete_local_image(path: String) -> Result<(), String> {
    let p = std::path::Path::new(&path);
    if !p.exists() {
        return Err("文件不存在".to_string());
    }
    std::fs::remove_file(p).map_err(|e| format!("删除失败: {}", e))
}

fn infer_image_tags(name: &str, path: &str) -> Vec<String> {
    let lower = format!("{} {}", name, path).to_lowercase();
    let common_tags = vec![
        "godot", "ui", "icon", "sprite", "tile", "background", "character",
        "player", "enemy", "weapon", "item", "effect", "particle",
        "button", "menu", "logo", "font", "map", "level",
    ];
    common_tags.into_iter()
        .filter(|t| lower.contains(t))
        .map(|s| s.to_string())
        .collect()
}
