use crate::mcp::{MCPManager, MCPServerConfig, MCPTool};
use serde::Serialize;
use serde_json::Value;
use std::sync::Mutex;
use tauri::State;

pub struct MCPState {
    pub manager: Mutex<MCPManager>,
}

#[derive(Debug, Serialize)]
pub struct MCPServerInfo {
    pub id: String,
    pub connected: bool,
    pub tools: Vec<MCPTool>,
}

#[tauri::command]
pub fn connect_mcp(
    state: State<'_, MCPState>,
    config: MCPServerConfig,
) -> Result<MCPServerInfo, String> {
    let mut manager = state.manager.lock().map_err(|e| e.to_string())?;
    let tools = manager.connect(&config)?;
    Ok(MCPServerInfo {
        id: config.id,
        connected: true,
        tools,
    })
}

#[tauri::command]
pub fn disconnect_mcp(
    state: State<'_, MCPState>,
    server_id: String,
) -> Result<(), String> {
    let mut manager = state.manager.lock().map_err(|e| e.to_string())?;
    manager.disconnect(&server_id)
}

#[tauri::command]
pub fn list_mcp_tools(
    state: State<'_, MCPState>,
    server_id: String,
) -> Result<Vec<MCPTool>, String> {
    let manager = state.manager.lock().map_err(|e| e.to_string())?;
    manager.list_tools(&server_id)
}

#[tauri::command]
pub fn call_mcp_tool(
    state: State<'_, MCPState>,
    server_id: String,
    tool_name: String,
    arguments: Value,
) -> Result<String, String> {
    let mut manager = state.manager.lock().map_err(|e| e.to_string())?;
    manager.call_tool(&server_id, &tool_name, arguments)
}
