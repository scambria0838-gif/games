use crate::distill;
use crate::embeddings;
use crate::knowledge::KnowledgeBase;
use crate::{KnowledgeChunk, SearchResult, IndexOverview, AppState};
use std::fs;
use tauri::State;

#[tauri::command]
pub fn load_knowledge_base(
    state: State<'_, AppState>,
    index_path: String,
    chunks_path: String,
    base_dir: String,
) -> Result<IndexOverview, String> {
    let kb = KnowledgeBase::load(&index_path, &chunks_path, &base_dir)?;
    let overview = kb.get_overview();

    let mut kb_state = state.knowledge_base.lock().map_err(|e| e.to_string())?;
    *kb_state = Some(kb);

    Ok(overview)
}

#[tauri::command]
pub fn search_knowledge(
    state: State<'_, AppState>,
    query: String,
    category: Option<String>,
    difficulty: Option<String>,
    limit: Option<usize>,
) -> Result<Vec<SearchResult>, String> {
    let kb = state.knowledge_base.lock().map_err(|e| e.to_string())?;
    let kb = kb.as_ref().ok_or("知识库未加载")?;

    let results = kb.search(&query, category.as_deref(), difficulty.as_deref(), limit.unwrap_or(10));

    Ok(results.into_iter().map(|m| {
        let chunks: Vec<KnowledgeChunk> = m.chunks.into_iter().map(|c| KnowledgeChunk {
            chunk_id: c.chunk_id,
            file_id: c.file_id,
            file_title: c.file_title,
            file_path: c.file_path,
            summary: c.summary,
            keywords: c.keywords,
            start_line: c.start_line,
            end_line: c.end_line,
            chunk_text: c.chunk_text,
        }).collect();

        SearchResult {
            file_id: m.file_id,
            title: m.title,
            path: m.path,
            summary: m.summary,
            category: m.category,
            difficulty: m.difficulty,
            keywords: m.keywords,
            score: m.score,
            chunks,
        }
    }).collect())
}

#[tauri::command]
pub fn get_file_content(
    state: State<'_, AppState>,
    file_path: String,
) -> Result<String, String> {
    let kb = state.knowledge_base.lock().map_err(|e| e.to_string())?;
    let source_dir = &kb.as_ref().ok_or("知识库未加载")?.source_dir;
    let full_path = format!("{}/{}", source_dir.trim_end_matches('/'), file_path);
    fs::read_to_string(&full_path)
        .map_err(|e| format!("无法读取文件 {}: {}", full_path, e))
}

#[tauri::command]
pub fn get_index_overview(
    state: State<'_, AppState>,
) -> Result<IndexOverview, String> {
    let kb = state.knowledge_base.lock().map_err(|e| e.to_string())?;
    let kb = kb.as_ref().ok_or("知识库未加载")?;
    Ok(kb.get_overview())
}

#[tauri::command]
pub fn get_files_by_category(
    state: State<'_, AppState>,
    category: String,
) -> Result<Vec<crate::KnowledgeFile>, String> {
    let kb = state.knowledge_base.lock().map_err(|e| e.to_string())?;
    let kb = kb.as_ref().ok_or("知识库未加载")?;

    let files = kb.get_files_by_category(&category);
    Ok(files.into_iter().map(|f| crate::KnowledgeFile {
        id: f.id.clone(),
        filename: f.filename.clone(),
        path: f.path.clone(),
        title: f.title.clone(),
        size: f.size,
        line_count: f.line_count,
        summary: f.summary.clone(),
        category: f.category.clone(),
        difficulty: f.difficulty.clone(),
        keywords: f.keywords.clone(),
        chunk_count: f.chunks.len(),
    }).collect())
}

#[tauri::command]
pub fn get_related_files(
    state: State<'_, AppState>,
    file_id: String,
) -> Result<Vec<crate::KnowledgeFile>, String> {
    let kb = state.knowledge_base.lock().map_err(|e| e.to_string())?;
    let kb = kb.as_ref().ok_or("知识库未加载")?;

    let files = kb.get_related_files(&file_id, 5);
    Ok(files.into_iter().map(|f| crate::KnowledgeFile {
        id: f.id.clone(),
        filename: f.filename.clone(),
        path: f.path.clone(),
        title: f.title.clone(),
        size: f.size,
        line_count: f.line_count,
        summary: f.summary.clone(),
        category: f.category.clone(),
        difficulty: f.difficulty.clone(),
        keywords: f.keywords.clone(),
        chunk_count: f.chunks.len(),
    }).collect())
}

#[tauri::command]
pub fn distill_knowledge(
    source_dir: String,
    target_dir: String,
) -> Result<crate::distill::DistillResult, String> {
    let index_path = format!("{}/godot_index.json", target_dir.trim_end_matches('/'));
    let chunks_path = format!("{}/godot_chunks.json", target_dir.trim_end_matches('/'));
    distill::distill(&source_dir, &index_path, &chunks_path)
}

#[tauri::command]
pub fn search_knowledge_hybrid(
    state: State<'_, AppState>,
    query: String,
    query_vec: Vec<f32>,
    category: Option<String>,
    difficulty: Option<String>,
    limit: Option<usize>,
) -> Result<Vec<SearchResult>, String> {
    let kb = state.knowledge_base.lock().map_err(|e| e.to_string())?;
    let kb = kb.as_ref().ok_or("知识库未加载")?;

    let limit = limit.unwrap_or(10);
    let mut results = kb.search(&query, category.as_deref(), difficulty.as_deref(), limit * 2);

    if !query_vec.is_empty() {
        kb.rerank_with_embeddings(&mut results, &query_vec, 0.3, 0.7);
        results.truncate(limit);
    }

    Ok(results.into_iter().map(|m| {
        let chunks: Vec<KnowledgeChunk> = m.chunks.into_iter().map(|c| KnowledgeChunk {
            chunk_id: c.chunk_id,
            file_id: c.file_id,
            file_title: c.file_title,
            file_path: c.file_path,
            summary: c.summary,
            keywords: c.keywords,
            start_line: c.start_line,
            end_line: c.end_line,
            chunk_text: c.chunk_text,
        }).collect();

        SearchResult {
            file_id: m.file_id,
            title: m.title,
            path: m.path,
            summary: m.summary,
            category: m.category,
            difficulty: m.difficulty,
            keywords: m.keywords,
            score: m.score,
            chunks,
        }
    }).collect())
}

#[tauri::command]
pub async fn compute_knowledge_embeddings(
    state: State<'_, AppState>,
    target_dir: String,
    api_base: String,
    api_key: String,
    model: String,
    force: bool,
) -> Result<String, String> {
    let chunks = {
        let kb = state.knowledge_base.lock().map_err(|e| e.to_string())?;
        let kb = kb.as_ref().ok_or("知识库未加载")?;
        kb.chunks.clone()
    };

    let emb_path = format!("{}/godot_embeddings.json", target_dir.trim_end_matches('/'));

    if !force {
        if let Ok(Some(_)) = embeddings::load_embeddings(&emb_path) {
            return Ok("Embeddings already exist. Use force=true to recompute.".to_string());
        }
    }

    let total = chunks.len();
    let model_name = if model.is_empty() { "text-embedding-3-small".to_string() } else { model };

    // Extract texts for embedding
    let texts: Vec<&str> = chunks.iter().map(|c| c.chunk_text.as_str()).collect();

    // Fetch embeddings from API
    let vectors = embeddings::fetch_embeddings(
        &texts,
        &api_base,
        &api_key,
        &model_name,
    ).await?;

    // Build embedding store
    let mut emb_map = std::collections::HashMap::new();
    for (i, vec) in vectors.iter().enumerate() {
        if i < total {
            emb_map.insert(chunks[i].chunk_id.clone(), vec.clone());
        }
    }

    let dimension = vectors.first().map(|v| v.len()).unwrap_or(0);
    let store = embeddings::EmbeddingStore {
        total_chunks: emb_map.len(),
        model: model_name.clone(),
        dimension,
        embeddings: emb_map,
    };

    embeddings::save_embeddings(&store, &emb_path)?;

    Ok(format!(
        "Computed embeddings for {} chunks using {} (dim={})",
        store.total_chunks, model_name, dimension
    ))
}
