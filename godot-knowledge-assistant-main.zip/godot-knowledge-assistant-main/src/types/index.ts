export interface KnowledgeFile {
  id: string;
  filename: string;
  path: string;
  title: string;
  size: number;
  line_count: number;
  summary: string;
  category: string[];
  difficulty: string;
  keywords: string[];
  related_files: string[];
  chunks: ChunkRef[];
  chunk_count: number;
}

export interface ChunkRef {
  chunk_id: string;
  summary: string;
  keywords: string[];
  start_line: number;
  end_line: number;
}

export interface KnowledgeChunk {
  chunk_id: string;
  file_id: string;
  file_title: string;
  file_path: string;
  summary: string;
  keywords: string[];
  start_line: number;
  end_line: number;
  chunk_text: string;
}

export interface SearchResult {
  file_id: string;
  title: string;
  path: string;
  summary: string;
  category: string[];
  difficulty: string;
  keywords: string[];
  score: number;
  chunks: KnowledgeChunk[];
}

export interface IndexOverview {
  total_files: number;
  categories: CategoryInfo[];
  difficulties: DifficultyInfo[];
  loaded: boolean;
}

export interface CategoryInfo {
  name: string;
  count: number;
}

export interface DifficultyInfo {
  name: string;
  count: number;
}

export interface Message {
  id: string;
  role: "user" | "assistant" | "system" | "tool";
  content: string;
  timestamp: number;
  tool_calls?: ToolCall[];
  sources?: SourceRef[];
  images?: string[];
  feedback?: "like" | "dislike";
}

export interface ToolCall {
  name: string;
  arguments: Record<string, any>;
  status: "running" | "done" | "error";
  result?: string;
}

export interface SourceRef {
  file_id: string;
  title: string;
  file_path?: string;
  chunk_id: string;
  summary?: string;
  preview_snippet?: string;
}

export interface Conversation {
  id: string;
  title: string;
  messages: Message[];
  created_at: number;
  updated_at: number;
  deepThink?: boolean;
  searchEnabled?: boolean;
  mode?: "qa" | "programming";
}

export interface AIConfig {
  provider: "openai" | "deepseek" | "ollama" | "custom";
  api_key: string;
  base_url: string;
  model: string;
  temperature: number;
  max_tokens: number;
  context_length: number;
}

export interface AppSettings {
  ai: AIConfig;
  theme: "light" | "dark" | "system";
  knowledge_path: string;
  enable_web_search: boolean;
  enable_image_search: boolean;
  local_image_path: string;
  mcp_servers: MCPServerConfig[];
  skill_paths: string[];
  max_tool_rounds: number;
  enable_semantic_search: boolean;
  embedding_model: string;
}

export interface MCPServerConfig {
  id: string;
  name: string;
  command: string;
  args: string[];
  env?: Record<string, string>;
  auto_connect: boolean;
}

export interface MCPServer {
  id: string;
  name: string;
  status: "disconnected" | "connecting" | "connected" | "error";
  tools: MCPTool[];
  error?: string;
}

export interface MCPTool {
  name: string;
  description: string;
  inputSchema: Record<string, any>;
}

export interface SkillDefinition {
  id: string;
  name: string;
  description: string;
  version: string;
  system_prompt?: string;
  tools: SkillTool[];
}

export interface SkillTool {
  name: string;
  description: string;
  inputSchema: Record<string, any>;
  handler: string;
}

export interface LocalImage {
  path: string;
  name: string;
  url: string;
  tags: string[];
  size: number;
}

export interface ToolDefinition {
  name: string;
  description: string;
  inputSchema: Record<string, any>;
}

export interface APIResponse {
  content: string;
  tool_calls?: { name: string; arguments: Record<string, any> }[];
}

export interface DistillProgress {
  phase: "scanning" | "indexing" | "chunking" | "writing" | "done" | "error";
  current: number;
  total: number;
  message: string;
}
