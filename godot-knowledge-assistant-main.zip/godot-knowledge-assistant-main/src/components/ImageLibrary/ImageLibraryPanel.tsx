import React, { useEffect, useState, useCallback } from "react";
import {
  Layout, Typography, Button, Input, List, Tag, Space, Spin,
  Empty, Image, Modal, message, Tooltip,
} from "antd";
import {
  PictureOutlined, FolderOpenOutlined, ReloadOutlined,
  SearchOutlined, DeleteOutlined, EyeOutlined,
} from "@ant-design/icons";
import { useSettingsStore } from "../../stores/settingsStore";
import { scanLocalImages, deleteLocalImage, getLocalImageCache } from "../../services/image";
import type { LocalImage } from "../../types";
import { open } from "@tauri-apps/plugin-dialog";
import { convertFileSrc } from "@tauri-apps/api/core";

const { Text, Title } = Typography;

const VALID_EXTS = ["jpg", "jpeg", "png", "gif", "webp", "bmp", "svg"];

const ImageLibraryPanel: React.FC = () => {
  const { settings, updateSettings, save } = useSettingsStore();
  const [images, setImages] = useState<LocalImage[]>([]);
  const [loading, setLoading] = useState(false);
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedTags, setSelectedTags] = useState<string[]>([]);
  const [previewUrl, setPreviewUrl] = useState<string | null>(null);

  const isDark = settings.theme === "dark" ||
    (settings.theme === "system" && window.matchMedia("(prefers-color-scheme: dark)").matches);

  const loadImages = useCallback(async () => {
    if (!settings.local_image_path) return;
    setLoading(true);
    try {
      const results = await scanLocalImages(settings.local_image_path);
      setImages(results);
      if (results.length > 0) {
        message.success(`共扫描到 ${results.length} 张图片`);
      }
    } catch (e) {
      console.error("Failed to scan images:", e);
      message.error("扫描图片失败");
    } finally {
      setLoading(false);
    }
  }, [settings.local_image_path]);

  useEffect(() => {
    if (settings.local_image_path) loadImages();
  }, [settings.local_image_path]);

  const handleSelectFolder = async () => {
    try {
      const selected = await open({ directory: true, multiple: false });
      if (selected) {
        updateSettings({ local_image_path: selected });
        save();
      }
    } catch (e) {
      console.error("Folder selection failed:", e);
    }
  };

  const handleDelete = async (img: LocalImage) => {
    Modal.confirm({
      title: "确认删除",
      content: `确定要删除 "${img.name}" 吗？此操作不可恢复。`,
      okText: "删除",
      okType: "danger",
      cancelText: "取消",
      onOk: async () => {
        const ok = await deleteLocalImage(img.path);
        if (ok) {
          setImages((prev) => prev.filter((i) => i.path !== img.path));
          message.success("已删除");
        } else {
          message.error("删除失败");
        }
      },
    });
  };

  const allTags = Array.from(new Set(images.flatMap((img) => img.tags))).sort();

  const filtered = images.filter((img) => {
    const matchSearch = !searchTerm ||
      img.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      img.tags.some((t) => t.toLowerCase().includes(searchTerm.toLowerCase())) ||
      img.path.toLowerCase().includes(searchTerm.toLowerCase());
    const matchTags = selectedTags.length === 0 ||
      selectedTags.every((t) => img.tags.includes(t));
    return matchSearch && matchTags;
  });

  if (!settings.local_image_path) {
    return (
      <div style={{
        display: "flex", flexDirection: "column", alignItems: "center",
        justifyContent: "center", height: "100%", gap: 16, padding: 40,
      }}>
        <PictureOutlined style={{ fontSize: 64, color: isDark ? "#555" : "#ccc" }} />
        <Text style={{ fontSize: 16, color: isDark ? "#888" : "#999" }}>
          请先设置本地图片库路径
        </Text>
        <Text style={{ color: isDark ? "#666" : "#bbb", textAlign: "center" }}>
          在设置面板中配置本地图片文件夹路径，或点击下方按钮选择
        </Text>
        <Button icon={<FolderOpenOutlined />} onClick={handleSelectFolder}>
          选择图片文件夹
        </Button>
      </div>
    );
  }

  return (
    <Layout style={{ height: "100%", background: isDark ? "#0d1117" : "#f5f7fa" }}>
      <div style={{
        padding: "12px 20px",
        borderBottom: `1px solid ${isDark ? "#2d2d3d" : "#e8e8e8"}`,
        display: "flex", justifyContent: "space-between", alignItems: "center",
        background: isDark ? "#161b22" : "#ffffff",
        flexShrink: 0,
      }}>
        <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
          <PictureOutlined style={{ fontSize: 18, color: "#4A6CF7" }} />
          <Text strong style={{ fontSize: 15 }}>
            图片库
          </Text>
          <Tag>{images.length} 张</Tag>
        </div>
        <Space>
          <Button icon={<FolderOpenOutlined />} size="small" onClick={handleSelectFolder}>
            更换目录
          </Button>
          <Button icon={<ReloadOutlined />} size="small" onClick={loadImages} loading={loading}>
            刷新
          </Button>
        </Space>
      </div>

      {/* Filters */}
      <div style={{
        padding: "8px 20px",
        borderBottom: `1px solid ${isDark ? "#2d2d3d" : "#e8e8e8"}`,
        background: isDark ? "#161b22" : "#ffffff",
        flexShrink: 0,
      }}>
        <Input
          prefix={<SearchOutlined />}
          placeholder="搜索图片名称、标签或路径..."
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          size="small"
          style={{ marginBottom: allTags.length > 0 ? 8 : 0 }}
        />
        {allTags.length > 0 && (
          <div style={{ display: "flex", gap: 4, flexWrap: "wrap" }}>
            {allTags.map((tag) => (
              <Tag
                key={tag}
                color={selectedTags.includes(tag) ? "blue" : "default"}
                style={{ cursor: "pointer" }}
                onClick={() => {
                  setSelectedTags((prev) =>
                    prev.includes(tag)
                      ? prev.filter((t) => t !== tag)
                      : [...prev, tag]
                  );
                }}
              >
                {tag} ({images.filter((i) => i.tags.includes(tag)).length})
              </Tag>
            ))}
            {selectedTags.length > 0 && (
              <Button size="small" type="link" onClick={() => setSelectedTags([])}>
                清除筛选
              </Button>
            )}
          </div>
        )}
      </div>

      {/* Image Grid */}
      <div style={{ flex: 1, overflow: "auto", padding: 16 }}>
        {loading ? (
          <div style={{ textAlign: "center", padding: 64 }}><Spin size="large" /></div>
        ) : filtered.length === 0 ? (
          <Empty
            description={searchTerm || selectedTags.length > 0 ? "无匹配图片" : "图片库为空，请选择包含图片的文件夹"}
          />
        ) : (
          <div style={{
            display: "grid",
            gridTemplateColumns: "repeat(auto-fill, minmax(180px, 1fr))",
            gap: 12,
          }}>
            {filtered.map((img) => (
              <div
                key={img.path}
                style={{
                  background: isDark ? "#161b22" : "#ffffff",
                  borderRadius: 10,
                  border: `1px solid ${isDark ? "#2d2d3d" : "#e8e8e8"}`,
                  overflow: "hidden",
                  transition: "transform 0.2s, box-shadow 0.2s",
                  cursor: "pointer",
                }}
                onMouseEnter={(e) => {
                  e.currentTarget.style.transform = "translateY(-2px)";
                  e.currentTarget.style.boxShadow = "0 4px 12px rgba(0,0,0,0.15)";
                }}
                onMouseLeave={(e) => {
                  e.currentTarget.style.transform = "none";
                  e.currentTarget.style.boxShadow = "none";
                }}
                onClick={() => setPreviewUrl(convertFileSrc(img.path))}
              >
                <div style={{
                  width: "100%",
                  height: 140,
                  overflow: "hidden",
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                  background: isDark ? "#0d1117" : "#f0f0f0",
                }}>
                  <img
                    src={convertFileSrc(img.path)}
                    alt={img.name}
                    style={{
                      maxWidth: "100%",
                      maxHeight: "100%",
                      objectFit: "cover",
                    }}
                    loading="lazy"
                    onError={(e) => {
                      (e.target as HTMLImageElement).style.display = "none";
                    }}
                  />
                </div>
                <div style={{ padding: "8px 10px" }}>
                  <Text
                    ellipsis
                    style={{
                      fontSize: 12,
                      display: "block",
                      color: isDark ? "#ccc" : "#555",
                    }}
                  >
                    {img.name}
                  </Text>
                  <div style={{ display: "flex", gap: 2, flexWrap: "wrap", marginTop: 4 }}>
                    {img.tags.slice(0, 3).map((tag) => (
                      <Tag key={tag} style={{ fontSize: 9, lineHeight: "14px", padding: "0 3px" }}>
                        {tag}
                      </Tag>
                    ))}
                  </div>
                  <div style={{
                    display: "flex",
                    justifyContent: "space-between",
                    alignItems: "center",
                    marginTop: 4,
                  }}>
                    <Text style={{ fontSize: 10, color: isDark ? "#666" : "#999" }}>
                      {(img.size / 1024).toFixed(0)}KB
                    </Text>
                    <Tooltip title="删除">
                      <Button
                        type="text"
                        size="small"
                        danger
                        icon={<DeleteOutlined />}
                        onClick={(e) => { e.stopPropagation(); handleDelete(img); }}
                        style={{ fontSize: 11, width: 20, height: 20 }}
                      />
                    </Tooltip>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Preview Modal */}
      <Image
        style={{ display: "none" }}
        preview={{
          visible: previewUrl !== null,
          src: previewUrl || undefined,
          onVisibleChange: (v) => { if (!v) setPreviewUrl(null); },
        }}
      />
    </Layout>
  );
};

export default ImageLibraryPanel;
