import React, { useState, useCallback, useMemo } from "react";
import { Typography, Tag, Dropdown, Collapse, Image } from "antd";
import {
  UserOutlined, RobotOutlined, ToolOutlined,
  CheckCircleOutlined, CloseCircleOutlined, LoadingOutlined,
  CodeOutlined, BookOutlined, PictureOutlined, BulbOutlined,
} from "@ant-design/icons";
import ReactMarkdown from "react-markdown";
import remarkGfm from "remark-gfm";
import { Prism as SyntaxHighlighter } from "react-syntax-highlighter";
import { oneDark, oneLight } from "react-syntax-highlighter/dist/esm/styles/prism";
import type { Message, ToolCall, SourceRef } from "../../types";
import { useSettingsStore } from "../../stores/settingsStore";
import { useChatStore } from "../../stores/chatStore";
import KnowledgePreview from "./KnowledgePreview";

const { Text } = Typography;

interface Props {
  message: Message;
  onQuote?: (content: string) => void;
  onRetry?: (messageId: string) => void;
}

const btnStyle = (isDark: boolean): React.CSSProperties => ({
  display: "inline-flex",
  alignItems: "center",
  justifyContent: "center",
  width: 28,
  height: 28,
  border: "none",
  borderRadius: 6,
  cursor: "pointer",
  background: "transparent",
  color: isDark ? "#666" : "#bbb",
  transition: "all 0.15s",
  padding: 0,
  lineHeight: 1,
});

const activeBtnStyle = (isDark: boolean): React.CSSProperties => ({
  ...btnStyle(isDark),
  color: "#4A6CF7",
  background: isDark ? "rgba(74,108,247,0.12)" : "rgba(74,108,247,0.08)",
});

function copySvg() { return (<svg viewBox="0 0 20 20" width="15" height="15" fill="currentColor"><path d="M6 3.5A1.5 1.5 0 017.5 2h6.879a1.5 1.5 0 011.06.44l2.122 2.12A1.5 1.5 0 0118 5.622V12.5a1.5 1.5 0 01-1.5 1.5h-1v-1h1a.5.5 0 00.5-.5V6h-2.5A1.5 1.5 0 0113 4.5V2H7.5a.5.5 0 00-.5.5V4H6V3.5z"/><path d="M2 7.5A1.5 1.5 0 013.5 6h7A1.5 1.5 0 0112 7.5v8a1.5 1.5 0 01-1.5 1.5h-7A1.5 1.5 0 012 15.5v-8z"/></svg>); }

function quoteSvg() { return (<svg viewBox="0 0 20 20" width="15" height="15" fill="currentColor"><path d="M7.5 4a.5.5 0 00-.5.5V7H4.5A1.5 1.5 0 003 8.5v5A1.5 1.5 0 004.5 15h5a1.5 1.5 0 001.5-1.5v-5A1.5 1.5 0 009.5 7H8V5.5a2.5 2.5 0 012.5-2.5h1a.5.5 0 000-1h-1A3.5 3.5 0 007.5 4z"/><path d="M11.5 8h1A1.5 1.5 0 0114 9.5v5a1.5 1.5 0 01-1.5 1.5h-5a1.5 1.5 0 01-1.5-1.5v-1h1v1a.5.5 0 00.5.5h5a.5.5 0 00.5-.5v-5a.5.5 0 00-.5-.5h-1V8z"/></svg>); }

function downloadSvg() { return (<svg viewBox="0 0 20 20" width="15" height="15" fill="currentColor"><path d="M10 1a.5.5 0 01.5.5v8.793l3.146-3.147a.5.5 0 11.708.708l-4 4a.5.5 0 01-.708 0l-4-4a.5.5 0 11.708-.708L9.5 10.293V1.5A.5.5 0 0110 1z"/><path d="M2 13.5A1.5 1.5 0 013.5 12h13a1.5 1.5 0 011.5 1.5v3a1.5 1.5 0 01-1.5 1.5h-13A1.5 1.5 0 012 16.5v-3zM3.5 13a.5.5 0 00-.5.5v3a.5.5 0 00.5.5h13a.5.5 0 00.5-.5v-3a.5.5 0 00-.5-.5h-13z"/></svg>); }

function retrySvg() { return (<svg viewBox="0 0 20 20" width="15" height="15" fill="currentColor"><path fillRule="evenodd" clipRule="evenodd" d="M4.272 6.057A7 7 0 0116.9 8.5a.5.5 0 01-.933.36 6 6 0 10-3.36 5.587.5.5 0 11.447.894A7 7 0 114.272 6.057z"/><path fillRule="evenodd" clipRule="evenodd" d="M16.5 4a.5.5 0 01.5.5v3a.5.5 0 01-.5.5h-3a.5.5 0 010-1h2.5V4.5a.5.5 0 01.5-.5z"/><path fillRule="evenodd" clipRule="evenodd" d="M10.657 9.157a.5.5 0 01.186.686l-1.5 2.5a.5.5 0 01-.872-.486l1.5-2.5a.5.5 0 01.686-.2z"/></svg>); }

function likeSvg(active: boolean) {
  return (<svg viewBox="0 0 20 20" width="15" height="15" fill={active ? "#4A6CF7" : "currentColor"}><path d="M6.956 1.746C7.618 1.07 8.548.5 9.5.5c.88 0 1.496.408 1.706.946.195.497.194 1.1-.003 1.65-.192.536-.522 1.1-.88 1.6-.379.527-.78 1-1.012 1.322l.003.002.005.006.016.02.058.07a2.616 2.616 0 01.21.28c.152.222.37.575.582 1.023.42.884.698 2.122.698 3.58 0 .403-.026.78-.073 1.11H16a2 2 0 012 2v2a2 2 0 01-2 2H5.313a3 3 0 01-2.846-1.979L.602 9.92a2 2 0 011.023-2.452l.036-.018a1.33 1.33 0 01.633-.15c.33 0 .625.072.86.163.19.074.38.176.541.31a.5.5 0 01-.7.714.534.534 0 00-.307-.175.323.323 0 00-.166.006l-.024.012a1 1 0 00-.512 1.226l2.33 6.643A2 2 0 005.313 18H14a1 1 0 001-1v-2a1 1 0 00-1-1H9.729a.5.5 0 01-.5-.5c0-.92.082-2.013.534-2.998.232-.501.436-.78.544-.93a.5.5 0 00-.094-.615l-.125-.12-.048-.046a.346.346 0 00-.026-.025l-.006-.005a.484.484 0 00-.084-.066.495.495 0 00-.065-.036.5.5 0 00-.459.007c-.239.146-.504.346-.78.567-.329.264-.684.578-1.006.739-.203.102-.437.14-.67.129a1.328 1.328 0 01-.6-.158 1.486 1.486 0 01-.48-.397 2.7 2.7 0 01-.298-.446c-.07-.14-.14-.308-.19-.477-.1-.334-.12-.75-.046-1.12.074-.374.234-.688.436-.91.196-.217.422-.348.614-.424.168-.067.324-.096.44-.105.033-.003.062-.003.088-.002.413-.528.83-1.02 1.214-1.555.21-.292.4-.614.543-.966.15-.369.248-.792.248-1.276 0-1.155-.237-2.118-.55-2.755a4.6 4.6 0 00-.463-.693l-.015-.018-.007-.008-.003-.004z"/></svg>);
}

function dislikeSvg(active: boolean) {
  return (<svg viewBox="0 0 20 20" width="15" height="15" fill={active ? "#e74c3c" : "currentColor"}><path d="M6.956 18.254C7.618 18.93 8.548 19.5 9.5 19.5c.88 0 1.496-.408 1.706-.946.195-.497.194-1.1-.003-1.65-.192-.536-.522-1.1-.88-1.6-.379-.527-.78-1-1.012-1.322l.003-.002.005-.006.016-.02.058-.07a2.615 2.615 0 01.21-.28c.152-.222.37-.575.582-1.023.42-.884.698-2.122.698-3.58 0-.403-.026-.78-.073-1.11H16a2 2 0 002-2v-2a2 2 0 00-2-2H5.313a3 3 0 00-2.846 1.979L.602 12.08a2 2 0 001.023 2.452l.036.018c.198.098.423.15.633.15.33 0 .625-.072.86-.163.19-.074.38-.176.541-.31a.5.5 0 10-.7-.714.534.534 0 01-.307.175.323.323 0 01-.166-.006l-.024-.012a1 1 0 01-.512-1.226l2.33-6.643A2 2 0 015.313 4H14a1 1 0 011 1v2a1 1 0 01-1 1H9.729a.5.5 0 00-.5.5c0 .92.082 2.013.534 2.998.232.501.436.78.544.93a.5.5 0 01-.094.615l-.125.12-.048.046-.026.025-.006.005a.484.484 0 01-.084.066.495.495 0 01-.065.036.5.5 0 01-.459-.007c-.239-.146-.504-.346-.78-.567-.329-.264-.684-.578-1.006-.739-.203-.102-.437-.14-.67-.129a1.328 1.328 0 00-.6.158 1.486 1.486 0 00-.48.397 2.7 2.7 0 00-.298.446c-.07.14-.14.308-.19.477-.1.334-.12.75-.046 1.12.074.374.234.688.436.91.196.217.422.348.614.424.168.067.324.096.44.105.033.003.062.003.088.002.413.528.83 1.02 1.214 1.555.21.292.4.614.543.966.15.369.248.792.248 1.276 0 1.155-.237 2.118-.55 2.755a4.6 4.6 0 01-.463.693l-.015.018-.007.008-.003.004z"/></svg>);
}

function exportAsMd(content: string, id: string) {
  const blob = new Blob([content], { type: "text/markdown" });
  downloadBlob(blob, `message-${id.slice(0, 8)}.md`);
}

function exportAsTxt(content: string, id: string) {
  const plain = content.replace(/```[\s\S]*?```/g, "").replace(/[*_~`#>\[\]()!-]/g, "").replace(/\n{3,}/g, "\n\n").trim();
  const blob = new Blob([plain], { type: "text/plain" });
  downloadBlob(blob, `message-${id.slice(0, 8)}.txt`);
}

function exportAsWord(content: string, id: string) {
  const html = `<!DOCTYPE html>
<html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:w="urn:schemas-microsoft-com:office:word" xmlns="http://www.w3.org/TR/REC-html40">
<head><meta charset="utf-8"><style>body{font-family:'Microsoft YaHei',Arial,sans-serif;font-size:12pt;padding:20px;line-height:1.6}pre{white-space:pre-wrap;word-wrap:break-word}code{background:#f0f0f0;padding:2px 6px;border-radius:3px}</style></head>
<body><pre>${content.replace(/</g, "&lt;").replace(/>/g, "&gt;")}</pre></body></html>`;
  const blob = new Blob([html], { type: "application/msword" });
  downloadBlob(blob, `message-${id.slice(0, 8)}.doc`);
}

function exportAsPng(content: string, id: string) {
  const canvas = document.createElement("canvas");
  const ctx = canvas.getContext("2d")!;
  const pad = 24;
  const maxW = 560;
  ctx.font = "14px 'Microsoft YaHei', sans-serif";
  const lines: string[] = [];
  for (const line of content.split("\n")) {
    if (ctx.measureText(line).width > maxW) {
      let cur = "";
      for (const ch of line) {
        if (ctx.measureText(cur + ch).width > maxW) { lines.push(cur); cur = ch; }
        else { cur += ch; }
      }
      if (cur) lines.push(cur);
    } else { lines.push(line); }
  }
  const lh = 22;
  const h = lines.length * lh + pad * 2;
  const w = maxW + pad * 2;
  canvas.width = w;
  canvas.height = Math.max(h, 80);
  ctx.fillStyle = "#ffffff";
  ctx.fillRect(0, 0, canvas.width, canvas.height);
  ctx.fillStyle = "#333333";
  ctx.font = "14px 'Microsoft YaHei', sans-serif";
  lines.forEach((line, i) => ctx.fillText(line || " ", pad, pad + (i + 1) * lh));
  canvas.toBlob((blob) => { if (blob) downloadBlob(blob, `message-${id.slice(0, 8)}.png`); }, "image/png");
}

function downloadBlob(blob: Blob, filename: string) {
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}

const MessageItem: React.FC<Props> = ({ message, onQuote, onRetry }) => {
  const isDark = useSettingsStore((s) =>
    s.settings.theme === "dark" ||
    (s.settings.theme === "system" && window.matchMedia("(prefers-color-scheme: dark)").matches)
  );

  const setFeedback = useChatStore((s) => s.setFeedback);

  const isUser = message.role === "user";
  const isAssistant = message.role === "assistant";
  const isTool = message.role === "tool";
  const feedback = message.feedback;

  const [previewSource, setPreviewSource] = useState<SourceRef | null>(null);
  const [previewOpen, setPreviewOpen] = useState(false);
  const [sourcesExpanded, setSourcesExpanded] = useState(false);

  const handleSourceClick = useCallback((s: SourceRef) => {
    setPreviewSource(s);
    setPreviewOpen(true);
  }, []);

  const handleCopy = useCallback(() => {
    navigator.clipboard.writeText(message.content);
  }, [message.content]);

  const handleQuote = useCallback(() => {
    const quoted = message.content.split("\n").map((l) => `> ${l}`).join("\n");
    onQuote?.(`${quoted}\n\n`);
  }, [message.content, onQuote]);

  const handleRetry = useCallback(() => {
    onRetry?.(message.id);
  }, [message.id, onRetry]);

  const handleLike = useCallback(() => {
    setFeedback(message.id, feedback === "like" ? undefined : "like");
  }, [message.id, feedback, setFeedback]);

  const handleDislike = useCallback(() => {
    setFeedback(message.id, feedback === "dislike" ? undefined : "dislike");
  }, [message.id, feedback, setFeedback]);

  // Deep think parsing
  const { thinkContent, answerContent } = useMemo(() => {
    const c = message.content;
    const thinkSep = "--- 深度思考过程 ---";
    const answerSep = "--- 最终答案 ---";
    const ti = c.indexOf(thinkSep);
    const ai = c.indexOf(answerSep);
    if (ti >= 0 && ai >= 0) {
      return {
        thinkContent: c.slice(ti + thinkSep.length, ai).trim(),
        answerContent: c.slice(ai + answerSep.length).trim(),
      };
    }
    if (ti >= 0) {
      return {
        thinkContent: c.slice(ti + thinkSep.length).trim(),
        answerContent: "",
      };
    }
    return { thinkContent: null, answerContent: c };
  }, [message.content]);
  const hasDeepThink = thinkContent !== null;

  const [thinkExpanded, setThinkExpanded] = useState(true);

  const renderMarkdown = (content: string) => (
    <div className="markdown-body" style={{
      color: isDark ? "#e0e0e0" : "#333",
      fontSize: 14,
    }}>
      <style>{`
        .markdown-body pre { background: ${isDark ? "#0d1117" : "#f5f7fa"} !important; border-radius: 8px; padding: 12px; overflow-x: auto; }
        .markdown-body code { font-size: 13px; font-family: 'JetBrains Mono', 'Fira Code', 'Consolas', monospace; }
        .markdown-body p { margin: 0 0 8px 0; }
        .markdown-body p:last-child { margin-bottom: 0; }
        .markdown-body ul, .markdown-body ol { margin: 4px 0; padding-left: 20px; }
        .markdown-body table { border-collapse: collapse; margin: 8px 0; }
        .markdown-body th, .markdown-body td { border: 1px solid ${isDark ? "#30363d" : "#d9d9d9"}; padding: 6px 12px; }
        .markdown-body blockquote { border-left: 3px solid #4A6CF7; margin: 8px 0; padding: 4px 12px; color: ${isDark ? "#888" : "#666"}; background: ${isDark ? "#161b22" : "#f8f9fa"}; border-radius: 0 4px 4px 0; }
      `}</style>
      <ReactMarkdown remarkPlugins={[remarkGfm]} components={markdownComponents(isDark)}>
        {content}
      </ReactMarkdown>
    </div>
  );

  const markdownComponents = (dark: boolean) => ({
    img({ src, alt }: any) {
      const imgRef = React.useRef<HTMLImageElement>(null);
      React.useEffect(() => {
        if (!imgRef.current) return;
        const handleError = () => {
          if (imgRef.current) {
            imgRef.current.style.display = "none";
            const fb = imgRef.current.nextElementSibling;
            if (fb) (fb as HTMLElement).style.display = "flex";
          }
        };
        imgRef.current.addEventListener("error", handleError);
        return () => imgRef.current?.removeEventListener("error", handleError);
      }, []);
      return (
        <span style={{ display: "inline-block", position: "relative" }}>
          <img ref={imgRef} src={src} alt={alt || ""}
            style={{ maxWidth: "100%", borderRadius: 8, margin: "8px 0" }}
            crossOrigin="anonymous" referrerPolicy="no-referrer" loading="lazy" />
          <span style={{
            display: "none", width: 200, height: 100,
            borderRadius: 8, background: dark ? "#1a2332" : "#f5f7fa",
            border: `1px dashed ${dark ? "#333" : "#ddd"}`,
            alignItems: "center", justifyContent: "center",
            fontSize: 12, color: dark ? "#666" : "#999", margin: "8px 0",
          }}>
            图片加载失败: {alt || src?.slice(0, 40)}
          </span>
        </span>
      );
    },
    code({ className, children, ...props }: any) {
      const match = /language-(\w+)/.exec(className || "");
      const codeStr = String(children).replace(/\n$/, "");
      if (match) {
        return (
          <SyntaxHighlighter
            style={dark ? oneDark : oneLight}
            language={match[1]}
            PreTag="div"
            customStyle={{ margin: 0, borderRadius: 8, fontSize: 13 }}
          >
            {codeStr}
          </SyntaxHighlighter>
        );
      }
      return (
        <code className={className} {...props} style={{
          background: dark ? "#2d2d3d" : "#f0f0f0",
          padding: "2px 6px",
          borderRadius: 4,
          fontSize: 13,
        }}>
          {children}
        </code>
      );
    },
  });

  const exportItems = [
    { key: "md", label: "Markdown (.md)", onClick: () => exportAsMd(message.content, message.id) },
    { key: "txt", label: "纯文本 (.txt)", onClick: () => exportAsTxt(message.content, message.id) },
    { key: "word", label: "Word (.doc)", onClick: () => exportAsWord(message.content, message.id) },
    { key: "png", label: "图片 (.png)", onClick: () => exportAsPng(message.content, message.id) },
  ];

  return (
    <div style={{
      display: "flex",
      flexDirection: isUser ? "row-reverse" : "row",
      gap: 12,
      marginBottom: 16,
      alignItems: "flex-start",
    }}>
      {/* Avatar */}
      <div style={{
        width: 32, height: 32, borderRadius: 8,
        background: isUser ? "#4A6CF7" : (isTool ? "#faad14" : isDark ? "#2d2d3d" : "#e8e8e8"),
        display: "flex", alignItems: "center", justifyContent: "center",
        flexShrink: 0, fontSize: 14, color: isUser ? "#fff" : (isDark ? "#ccc" : "#666"),
      }}>
        {isUser ? <UserOutlined /> : isTool ? <ToolOutlined /> : <RobotOutlined />}
      </div>

      {/* Content + Actions */}
      <div style={{ maxWidth: "75%", display: "flex", flexDirection: "column", gap: 4 }}>
        <div style={{
          padding: "10px 16px",
          borderRadius: 12,
          background: isUser
            ? "#4A6CF7"
            : (isDark ? "#1a2332" : "#ffffff"),
          color: isUser ? "#fff" : (isDark ? "#e0e0e0" : "#333"),
          border: isUser ? "none" : `1px solid ${isDark ? "#2d2d3d" : "#e8e8e8"}`,
          fontSize: 14,
          lineHeight: 1.6,
        }}>
          {isUser ? (
            <Text style={{ color: "#fff", whiteSpace: "pre-wrap" }}>{message.content}</Text>
          ) : (
            <>
              {/* Deep think panel */}
              {hasDeepThink && thinkContent && (
                <div style={{
                  marginBottom: 8,
                  border: `1px solid ${isDark ? "#3a2d5c" : "#d6c4ff"}`,
                  borderRadius: 8,
                  overflow: "hidden",
                }}>
                  <div
                    style={{
                      display: "flex", alignItems: "center", gap: 6,
                      padding: "6px 10px",
                      background: isDark ? "#1a1530" : "#f0ebff",
                      cursor: "pointer", userSelect: "none",
                    }}
                    onClick={() => setThinkExpanded(!thinkExpanded)}
                  >
                    <BulbOutlined style={{ color: "#7c3aed", fontSize: 13 }} />
                    <span style={{ fontSize: 12, fontWeight: 600, color: isDark ? "#c4b0ff" : "#7c3aed", flex: 1 }}>
                      深度思考过程
                    </span>
                    <span style={{ fontSize: 10, color: isDark ? "#666" : "#999" }}>
                      {thinkExpanded ? "收起" : "展开"}
                    </span>
                  </div>
                  {thinkExpanded && (
                    <div style={{
                      padding: "8px 12px",
                      fontSize: 13,
                      lineHeight: 1.6,
                      color: isDark ? "#b0b0c0" : "#666",
                      background: isDark ? "#12102a" : "#faf8ff",
                    }}>
                      {renderMarkdown(thinkContent)}
                    </div>
                  )}
                </div>
              )}
              {/* Final answer */}
              {(answerContent || !hasDeepThink) && renderMarkdown(answerContent || message.content)}
            </>
          )}

          {/* Tool Calls */}
          {message.tool_calls && message.tool_calls.length > 0 && (
            <div style={{ marginTop: 8, display: "flex", flexDirection: "column", gap: 4 }}>
              {message.tool_calls.map((tc, i) => (
                <ToolCallCard key={i} toolCall={tc} isDark={isDark} />
              ))}
            </div>
          )}

          {/* Image Gallery */}
          {message.images && message.images.length > 0 && (
            <div style={{ marginTop: 10, display: "flex", flexWrap: "wrap", gap: 10 }}>
              {message.images.map((url, i) => (
                <Image
                  key={i}
                  src={url}
                  alt=""
                  width={180}
                  height={120}
                  style={{ objectFit: "cover", borderRadius: 8, border: `1px solid ${isDark ? "#30363d" : "#e8e8e8"}` }}
                  preview={{ mask: <PictureOutlined style={{ fontSize: 20 }} /> }}
                  fallback="data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='180' height='120'%3E%3Crect fill='%23f0f0f0' width='180' height='120'/%3E%3Ctext x='50%25' y='50%25' fill='%23999' text-anchor='middle' dy='.3em' font-size='12'%3E加载失败%3C/text%3E%3C/svg%3E"
                />
              ))}
            </div>
          )}
        </div>

        {/* Source Reference Bar */}
        {message.sources && message.sources.length > 0 && isAssistant && (
          <div style={{
            marginTop: 4, padding: "6px 10px",
            background: isDark ? "#161b22" : "#f0f5ff",
            borderRadius: 8, border: `1px solid ${isDark ? "#1a3a5c" : "#d6e4ff"}`,
          }}>
            <div
              style={{ display: "flex", alignItems: "center", gap: 6, cursor: "pointer", userSelect: "none" }}
              onClick={() => setSourcesExpanded(!sourcesExpanded)}
            >
              <BookOutlined style={{ color: "#4A6CF7", fontSize: 12 }} />
              <span style={{ fontSize: 11, fontWeight: 600, color: isDark ? "#b0c4ff" : "#4A6CF7", flex: 1 }}>
                参考资料 ({message.sources.length})
              </span>
              {message.sources.length > 5 && (
                <span style={{ fontSize: 10, color: isDark ? "#666" : "#999" }}>
                  {sourcesExpanded ? "收起" : "展开全部"}
                </span>
              )}
            </div>
            <div
              style={{
                display: "flex", flexWrap: "wrap", gap: 4,
                maxHeight: sourcesExpanded ? "none" : 52,
                overflow: "hidden",
                transition: "max-height 0.2s",
              }}
            >
              {message.sources.map((s, i) => (
                <Tag
                  key={i}
                  color="blue"
                  style={{ fontSize: 11, cursor: "pointer", margin: 0, maxWidth: 220 }}
                  onClick={() => handleSourceClick(s)}
                  title={`${s.title} — ${s.chunk_id}`}
                >
                  {s.file_path || s.title}
                </Tag>
              ))}
            </div>
          </div>
        )}

        {/* Action Buttons — only for assistant messages */}
        {isAssistant && (
          <div style={{
            display: "flex", gap: 2, paddingLeft: 4, opacity: 0.6,
            transition: "opacity 0.15s",
          }}
            onMouseEnter={(e) => e.currentTarget.style.opacity = "1"}
            onMouseLeave={(e) => e.currentTarget.style.opacity = "0.6"}
          >
            <button title="复制" style={btnStyle(isDark)} onClick={handleCopy}>{copySvg()}</button>
            <button title="引用" style={btnStyle(isDark)} onClick={handleQuote}>{quoteSvg()}</button>
            <Dropdown menu={{ items: exportItems }} trigger={["click"]}>
              <button title="导出" style={btnStyle(isDark)} onClick={(e) => e.preventDefault()}>{downloadSvg()}</button>
            </Dropdown>
            <div style={{ width: 1, height: 18, margin: "5px 4px", background: isDark ? "#333" : "#ddd" }} />
            <button title="重试" style={btnStyle(isDark)} onClick={handleRetry}>{retrySvg()}</button>
            <button title="赞" style={feedback === "like" ? activeBtnStyle(isDark) : btnStyle(isDark)} onClick={handleLike}>{likeSvg(feedback === "like")}</button>
            <button title="踩" style={feedback === "dislike" ? activeBtnStyle(isDark) : btnStyle(isDark)} onClick={handleDislike}>{dislikeSvg(feedback === "dislike")}</button>
          </div>
        )}
      </div>

      <KnowledgePreview
        source={previewSource}
        open={previewOpen}
        onClose={() => setPreviewOpen(false)}
      />
    </div>
  );
};

// ─── ToolCallCard ─────────────────────────────────────────────
const toolNames: Record<string, string> = {
  knowledge_search: "知识库检索",
  web_search: "网络搜索",
  image_search: "图片搜索",
  local_image_search: "本地图片搜索",
};

const ToolCallCard: React.FC<{ toolCall: ToolCall; isDark: boolean }> = ({ toolCall, isDark }) => {
  const name = toolCall.name.startsWith("mcp_")
    ? `MCP: ${toolCall.name.slice(4)}`
    : (toolNames[toolCall.name] || toolCall.name);

  const isDone = toolCall.status === "done";
  const isError = toolCall.status === "error";

  const bg = isError
    ? (isDark ? "#2d1b1b" : "#fff1f0")
    : isDone
    ? (isDark ? "#1b2d1b" : "#f6ffed")
    : (isDark ? "#1b1d2d" : "#f0f5ff");

  const borderColor = isError
    ? (isDark ? "#5c1a1a" : "#ffccc7")
    : isDone
    ? (isDark ? "#1a4a1a" : "#b7eb8f")
    : (isDark ? "#2d3d5c" : "#adc6ff");

  const iconColor = isError ? "#ff4d4f" : isDone ? "#52c41a" : "#4A6CF7";

  const [expanded, setExpanded] = useState(false);

  return (
    <div style={{
      border: `1px solid ${borderColor}`,
      borderRadius: 8,
      background: bg,
      overflow: "hidden",
      fontSize: 12,
    }}>
      {/* Header */}
      <div
        style={{
          display: "flex", alignItems: "center", gap: 6,
          padding: "5px 10px",
          cursor: "pointer",
          userSelect: "none",
        }}
        onClick={() => setExpanded(!expanded)}
      >
        {!isDone && !isError ? (
          <div style={{
            width: 12, height: 12, borderRadius: "50%",
            border: `2px solid ${iconColor}`,
            borderTopColor: "transparent",
            animation: "toolspin 0.8s linear infinite",
          }} />
        ) : isError ? (
          <CloseCircleOutlined style={{ color: iconColor, fontSize: 13 }} />
        ) : (
          <CheckCircleOutlined style={{ color: iconColor, fontSize: 13 }} />
        )}
        <Text style={{ fontSize: 12, fontWeight: 500, color: isDark ? "#e0e0e0" : "#333", flex: 1 }}>
          {name}
        </Text>
        <Text style={{ fontSize: 11, color: isDark ? "#666" : "#999" }}>
          {isError ? "失败" : isDone ? "完成" : "进行中"}
        </Text>
        <CodeOutlined style={{ fontSize: 11, color: isDark ? "#666" : "#999",
          transform: expanded ? "rotate(180deg)" : "none",
          transition: "transform 0.2s",
        }} />
      </div>

      {/* Expanded Details */}
      {expanded && (
        <div style={{ padding: "0 10px 8px" }}>
          {/* Arguments */}
          {toolCall.arguments && Object.keys(toolCall.arguments).length > 0 && (
            <div style={{ marginBottom: 4 }}>
              <Text style={{ fontSize: 11, color: isDark ? "#888" : "#999", display: "block", marginBottom: 2 }}>
                参数:
              </Text>
              <pre style={{
                margin: 0, padding: "4px 8px",
                background: isDark ? "#111" : "#fafafa",
                borderRadius: 4,
                fontSize: 11, lineHeight: 1.4,
                color: isDark ? "#ccc" : "#666",
                whiteSpace: "pre-wrap", wordBreak: "break-all",
                maxHeight: 100, overflow: "auto",
              }}>
                {JSON.stringify(toolCall.arguments, null, 2)}
              </pre>
            </div>
          )}

          {/* Result */}
          {toolCall.result && (
            <div>
              <Text style={{ fontSize: 11, color: isDark ? "#888" : "#999", display: "block", marginBottom: 2 }}>
                结果:
              </Text>
              <pre style={{
                margin: 0, padding: "4px 8px",
                background: isDark ? "#111" : "#fafafa",
                borderRadius: 4,
                fontSize: 11, lineHeight: 1.4,
                color: isDark ? "#ccc" : "#666",
                whiteSpace: "pre-wrap", wordBreak: "break-all",
                maxHeight: 150, overflow: "auto",
              }}>
                {toolCall.result.length > 300
                  ? toolCall.result.slice(0, 300) + "..."
                  : toolCall.result}
              </pre>
            </div>
          )}
        </div>
      )}

      <style>{`@keyframes toolspin { to { transform: rotate(360deg); } }`}</style>
    </div>
  );
};

export default MessageItem;