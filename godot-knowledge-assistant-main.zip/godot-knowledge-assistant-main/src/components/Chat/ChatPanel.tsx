import React, { useRef, useEffect, useState, useCallback } from "react";
import { Input, Button, Typography, Alert, Tag, Tooltip } from "antd";
import {
  SendOutlined, ClearOutlined, BulbFilled, SearchOutlined,
  CheckCircleOutlined, CloseCircleOutlined, LoadingOutlined,
} from "@ant-design/icons";
import MessageItem from "./MessageItem";
import { useChatStore } from "../../stores/chatStore";
import { useSettingsStore } from "../../stores/settingsStore";
import { loadKnowledgeBase, getIndexOverview } from "../../services/knowledge";
import { streamChat } from "../../services/ai";
import type { Message, ToolCall } from "../../types";
import type { ToolCallEvent } from "../../services/ai";

const { TextArea } = Input;
const { Text } = Typography;

const ThinkingDots: React.FC = () => (
  <span className="thinking-dots">
    <span>.</span><span>.</span><span>.</span>
    <style>{`
      .thinking-dots span { animation: blink 1.4s infinite both; font-size: 24px; line-height: 1; }
      .thinking-dots span:nth-child(2) { animation-delay: 0.2s; }
      .thinking-dots span:nth-child(3) { animation-delay: 0.4s; }
      @keyframes blink { 0%, 80%, 100% { opacity: 0; } 40% { opacity: 1; } }
    `}</style>
  </span>
);

const ChatPanel: React.FC = () => {
  const { settings } = useSettingsStore();
  const chatStore = useChatStore();
  const {
    getCurrent, createConversation, addMessage, updateLastMessage,
    setThinking, isThinking, searchKnowledgeBase, removeMessagesFrom,
    setDeepThink, setSearchEnabled, setMessageSources, loaded,
  } = chatStore;

  const [input, setInput] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [toolCalls, setToolCalls] = useState<ToolCallEvent[]>([]);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  // Auto-load knowledge base at startup
  const [kbLoading, setKbLoading] = useState(false);
  useEffect(() => {
    if (!settings.knowledge_path || kbLoading) return;
    setKbLoading(true);
    getIndexOverview().then((ov) => {
      if (!ov.loaded) {
        const indexPath = `${settings.knowledge_path}/godot_index.json`;
        const chunksPath = `${settings.knowledge_path}/godot_chunks.json`;
        loadKnowledgeBase(indexPath, chunksPath, settings.knowledge_path)
          .then(() => console.log("KB loaded"))
          .catch((e) => console.error("KB load failed:", e))
          .finally(() => setKbLoading(false));
      } else {
        setKbLoading(false);
      }
    }).catch(() => {
      // First load - try loading directly
      const indexPath = `${settings.knowledge_path}/godot_index.json`;
      const chunksPath = `${settings.knowledge_path}/godot_chunks.json`;
      loadKnowledgeBase(indexPath, chunksPath, settings.knowledge_path)
        .then(() => console.log("KB loaded"))
        .catch((e) => console.error("KB load failed:", e))
        .finally(() => setKbLoading(false));
    });
  }, [settings.knowledge_path]);
  const inputRef = useRef<any>(null);
  const isStreamingRef = useRef(false);
  const userScrolledUpRef = useRef(false);
  const scrollContainerRef = useRef<HTMLDivElement>(null);
  const scrollThrottleRef = useRef<ReturnType<typeof requestAnimationFrame>>();

  const isDark = settings.theme === "dark" ||
    (settings.theme === "system" && window.matchMedia("(prefers-color-scheme: dark)").matches);

  const conv = getCurrent();

  // Track scroll direction - disable auto-scroll if user scrolled up
  const handleScroll = useCallback(() => {
    const el = scrollContainerRef.current;
    if (!el) return;
    const atBottom = el.scrollHeight - el.scrollTop - el.clientHeight < 80;
    userScrolledUpRef.current = !atBottom;
  }, []);

  useEffect(() => {
    if (userScrolledUpRef.current) return;
    if (scrollThrottleRef.current) cancelAnimationFrame(scrollThrottleRef.current);
    scrollThrottleRef.current = requestAnimationFrame(() => {
      messagesEndRef.current?.scrollIntoView({ behavior: isStreamingRef.current ? "auto" : "smooth" });
    });
  });

  useEffect(() => {
    if (loaded && !conv) createConversation();
  }, [loaded]);

  // Force save on page unload
  useEffect(() => {
    const handleUnload = () => {
      useChatStore.getState().persistConversations();
    };
    window.addEventListener("beforeunload", handleUnload);
    return () => window.removeEventListener("beforeunload", handleUnload);
  }, []);

  const toolCallResults = useRef<ToolCall[]>([]);
  const persistTimerRef = useRef<ReturnType<typeof setInterval>>();

  async function doStream(convId: string, msgsToSend: { role: string; content: string }[], deepThink: boolean, searchEnabled: boolean) {
    isStreamingRef.current = true;
    userScrolledUpRef.current = false;
    setToolCalls([]);
    toolCallResults.current = [];

    const assistantId = (Date.now() + 1).toString(36);
    const assistantMsg: Message = {
      id: assistantId,
      role: "assistant",
      content: "",
      timestamp: Date.now(),
      sources: [],
    };
    addMessage(assistantMsg);
    setThinking(true);

    // Periodic force-persist during streaming
    persistTimerRef.current = setInterval(() => {
      useChatStore.getState().persistConversations();
    }, 3000);

    try {
      // Capture current conversation ID before streaming starts
      const streamConvId = useChatStore.getState().currentId;
      let fullResponse = "";
      for await (const chunk of streamChat(msgsToSend, settings.ai, {
        deepThink,
        searchEnabled,
        onToolCall: (event: ToolCallEvent) => {
          setToolCalls((prev) => {
            const exists = prev.findIndex((t) => t.name === event.name && t.status === "running");
            if (exists >= 0 && event.status !== "running") {
              const updated = [...prev];
              updated[exists] = event;
              return updated;
            }
            if (exists >= 0) return prev;
            return [...prev, event];
          });
          if (event.status === "done" && event.arguments) {
            toolCallResults.current.push({
              name: event.name,
              arguments: event.arguments,
              status: "done",
              result: event.result,
            });
          } else if (event.status === "error" && event.arguments) {
            toolCallResults.current.push({
              name: event.name,
              arguments: event.arguments,
              status: "error",
              result: event.error,
            });
          }
        },
      })) {
        fullResponse += chunk;
        updateLastMessage(fullResponse);
      }

      // Only set tool calls if still on the same conversation
      const currentConv = useChatStore.getState().getCurrent();
      if (currentConv && currentConv.id === streamConvId && currentConv.messages.length > 0) {
        const lastMsg = currentConv.messages[currentConv.messages.length - 1];
        if (lastMsg.role === "assistant") {
          if (toolCallResults.current.length > 0) {
            useChatStore.getState().setToolCalls(lastMsg.id, toolCallResults.current);
          }
        }
      }
    } catch (e: any) {
      setError(e.message || "发送失败，请检查 API 配置和网络连接");
      updateLastMessage(`**错误**: ${e.message || "请求失败，请重试"}`);
    } finally {
      setThinking(false);
      isStreamingRef.current = false;
      if (persistTimerRef.current) {
        clearInterval(persistTimerRef.current);
        persistTimerRef.current = undefined;
      }
      useChatStore.getState().persistConversations();
    }
  }

  const handleSend = useCallback(async (overrideText?: string) => {
    const text = (overrideText ?? input).trim();
    if (!text || isThinking || !settings.ai.api_key) return;
    setError(null);
    setInput("");

    let currentConv = getCurrent();
    if (!currentConv) { createConversation(); currentConv = getCurrent(); }
    if (!currentConv) return;
    const msgId = Date.now().toString(36);

    const userMsg: Message = {
      id: msgId,
      role: "user",
      content: text,
      timestamp: Date.now(),
    };
    addMessage(userMsg);

    // Auto-search knowledge base — results as context hint, but don't suppress AI tool
    const kbResults = await searchKnowledgeBase(text);
    const contextParts: string[] = [];
    if (kbResults.length > 0) {
      const top = kbResults.slice(0, 2);
      for (const r of top) {
        contextParts.push(`--- ${r.title} [${r.file_id}] ---`);
        contextParts.push(r.summary);
        for (const chunk of r.chunks.slice(0, 1)) {
          contextParts.push(`[${chunk.chunk_id}] ${chunk.chunk_text.slice(0, 500)}`);
        }
        contextParts.push("---");
      }
    }

    // Always let AI call tools — user wants to see tool execution
    const fullPrompt = contextParts.length > 0
      ? `知识库中已找到以下相关内容供参考。你也可以调用 knowledge_search 搜索更多。\n\n${contextParts.join("\n")}\n\n用户问题: ${text}`
      : text;

    const msgs = getCurrent()?.messages.slice(-10) || [];
    const enrichedMsgs: { role: string; content: string }[] = [
      { role: "system", content: "你是一位精通 Godot 引擎的资深开发者。使用知识库内容回答，标注引用来源。" },
      ...msgs.slice(0, -1).map((m) => ({
        role: m.role === "user" ? "user" : "assistant",
        content: m.content,
      })),
      { role: "user", content: fullPrompt },
    ];

    await doStream(currentConv.id, enrichedMsgs, currentConv?.deepThink ?? false, currentConv?.searchEnabled !== false);
  }, [input, isThinking, settings.ai]);

  const handleRetry = useCallback(async (assistantMsgId: string) => {
    const conv = useChatStore.getState().getCurrent();
    if (!conv || isThinking) return;
    const msgs = conv.messages;
    const idx = msgs.findIndex((m) => m.id === assistantMsgId);
    if (idx === -1) return;
    // Remove the assistant message and everything after it
    removeMessagesFrom(assistantMsgId);
    // Build API messages from remaining messages
    const remaining = useChatStore.getState().getCurrent()?.messages.slice(-10) || [];
    if (remaining.length === 0) return;
    const enrichedMsgs: { role: string; content: string }[] = [
      { role: "system", content: "你是一位精通 Godot 引擎的资深开发者。使用知识库内容回答，标注引用来源。" },
      ...remaining.map((m) => ({
        role: m.role === "user" ? "user" : "assistant",
        content: m.content,
      })),
    ];
    await doStream(conv.id, enrichedMsgs, conv.deepThink ?? false, conv.searchEnabled !== false);
  }, [isThinking]);

  const handleQuote = useCallback((content: string) => {
    setInput((prev) => (prev ? `${prev}\n\n${content}` : content));
    setTimeout(() => inputRef.current?.focus(), 0);
  }, []);

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && (e.ctrlKey || e.metaKey)) {
      e.preventDefault();
      handleSend();
    }
  };

  if (!settings.ai.api_key && !settings.ai.base_url.includes("localhost")) {
    return (
      <div style={{
        display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center",
        height: "100%", padding: 40, gap: 16,
      }}>
        <div style={{ fontSize: 48, marginBottom: 8 }}>🎮</div>
        <Text strong style={{ fontSize: 20, color: isDark ? "#e0e0e0" : "#333" }}>
          Godot 知识助手
        </Text>
        <Text style={{ color: isDark ? "#888" : "#999", textAlign: "center", maxWidth: 400 }}>
          请先在设置中配置 AI API Key，或使用本地 Ollama 服务
        </Text>
        <Alert
          message="快速开始"
          description="支持 OpenAI / DeepSeek / Ollama 等 API。你可将知识库路径指向 Godot 教程目录即可开始提问。"
          type="info"
          showIcon
          style={{ maxWidth: 500 }}
        />
        <Button type="primary" onClick={() => useSettingsStore.getState().load()}>
          我已配置，刷新设置
        </Button>
      </div>
    );
  }

  return (
    <div style={{ display: "flex", flexDirection: "column", height: "100%" }}>
      {/* Header */}
      <div style={{
        padding: "12px 20px",
        borderBottom: `1px solid ${isDark ? "#2d2d3d" : "#e8e8e8"}`,
        display: "flex", justifyContent: "space-between", alignItems: "center",
        flexShrink: 0,
      }}>
        <Text strong style={{ fontSize: 15, color: isDark ? "#e0e0e0" : "#333" }}>
          {conv?.title || "对话"}
        </Text>
        <div style={{ display: "flex", gap: 8 }}>
          <Button size="small" icon={<ClearOutlined />} onClick={() => {
            useChatStore.getState().clearContext();
          }}>
            清空
          </Button>
        </div>
      </div>

      {/* Messages */}
      <div ref={scrollContainerRef} onScroll={handleScroll} style={{
        flex: 1, overflow: "auto", padding: "20px",
        background: isDark ? "#0d1117" : "#f5f7fa",
      }}>
        {(!conv || conv.messages.length === 0) ? (
          <div style={{
            display: "flex", flexDirection: "column", alignItems: "center",
            justifyContent: "center", height: "100%", gap: 8,
          }}>
            <div style={{ fontSize: 48 }}>📚</div>
            <Text style={{ fontSize: 16, color: isDark ? "#888" : "#aaa" }}>
              开始你的 Godot 学习之旅
            </Text>
            <Text style={{ fontSize: 13, color: isDark ? "#555" : "#ccc", textAlign: "center", maxWidth: 400 }}>
              输入关于 Godot 引擎的任何问题，AI 将结合知识库为你解答
            </Text>
            <div style={{ display: "flex", flexWrap: "wrap", gap: 8, marginTop: 16, justifyContent: "center" }}>
              {["如何创建 2D 游戏？", "什么是信号系统？", "GDScript 基础语法",
                "如何做碰撞检测？", "Godot 4 新特性", "TileMap 使用方法"].map((q) => (
                <Button
                  key={q}
                  size="small"
                  type="dashed"
                  onClick={() => { setInput(q); }}
                  style={{ borderRadius: 16 }}
                >
                  {q}
                </Button>
              ))}
            </div>
          </div>
        ) : (
          conv.messages.map((msg) => (
            <MessageItem key={msg.id} message={msg} onQuote={handleQuote} onRetry={handleRetry} />
          ))
        )}

        {isThinking && (
          <div style={{
            padding: "12px 16px", marginTop: 8,
            background: isDark ? "#1a2332" : "#ffffff",
            borderRadius: 12, border: `1px solid ${isDark ? "#2d2d3d" : "#e8e8e8"}`,
            maxWidth: 500,
          }}>
            <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: toolCalls.length > 0 ? 8 : 0 }}>
              <div style={{
                width: 20, height: 20, borderRadius: "50%",
                border: `2px solid ${isDark ? "#4A6CF7" : "#4A6CF7"}`,
                borderTopColor: "transparent",
                animation: "spin 0.8s linear infinite",
              }} />
              <Text style={{ color: isDark ? "#aaa" : "#888", fontSize: 13 }}>
                AI 思考中<ThinkingDots />
              </Text>
              <style>{`@keyframes spin { to { transform: rotate(360deg); } }`}</style>
            </div>

            {toolCalls.length > 0 && (
              <div style={{ display: "flex", flexDirection: "column", gap: 4 }}>
                {toolCalls.map((tc, i) => (
                  <div key={i} style={{
                    display: "flex", alignItems: "center", gap: 6,
                    padding: "4px 8px",
                    background: tc.status === "error"
                      ? (isDark ? "#2d1b1b" : "#fff1f0")
                      : tc.status === "done"
                      ? (isDark ? "#1b2d1b" : "#f6ffed")
                      : (isDark ? "#1b1d2d" : "#f0f5ff"),
                    borderRadius: 6,
                    fontSize: 12,
                  }}>
                    {tc.status === "running" ? (
                      <LoadingOutlined style={{ color: "#4A6CF7", fontSize: 13 }} />
                    ) : tc.status === "done" ? (
                      <CheckCircleOutlined style={{ color: "#52c41a", fontSize: 13 }} />
                    ) : (
                      <CloseCircleOutlined style={{ color: "#ff4d4f", fontSize: 13 }} />
                    )}
                    <Text style={{
                      fontSize: 12,
                      color: tc.status === "error" ? "#ff4d4f" : isDark ? "#ccc" : "#666",
                      flex: 1,
                    }}>
                      {toolLabel(tc.name)}
                    </Text>
                    {tc.arguments && tc.status === "running" && (
                      <Text style={{ fontSize: 11, color: isDark ? "#666" : "#999" }}>
                        {truncateArgs(tc.arguments)}
                      </Text>
                    )}
                  </div>
                ))}
              </div>
            )}
          </div>
        )}
        <div ref={messagesEndRef} />
      </div>

      {/* Error */}
      {error && (
        <Alert
          message={error}
          type="error"
          closable
          onClose={() => setError(null)}
          style={{ margin: "0 16px" }}
        />
      )}

      {/* Toggle Bar */}
      <div style={{
        padding: "6px 20px 0",
        display: "flex", gap: 6, alignItems: "center",
        background: isDark ? "#161b22" : "#ffffff",
      }}>
        <Tooltip title="深度思考模式：让 AI 进行逐步推理后再回答">
          <Tag
            color={conv?.deepThink ? "purple" : "default"}
            style={{ cursor: "pointer", userSelect: "none", padding: "2px 8px", borderRadius: 12 }}
            onClick={() => {
              if (conv) setDeepThink(conv.id, !conv.deepThink);
            }}
          >
            <BulbFilled style={{ marginRight: 4, fontSize: 12 }} />
            深度思考
          </Tag>
        </Tooltip>
        <Tooltip title="开启后 AI 可使用联网搜索和图片搜索工具">
          <Tag
            color={conv?.searchEnabled !== false ? "blue" : "default"}
            style={{ cursor: "pointer", userSelect: "none", padding: "2px 8px", borderRadius: 12 }}
            onClick={() => {
              if (conv) setSearchEnabled(conv.id, conv.searchEnabled === false ? true : false);
            }}
          >
            <SearchOutlined style={{ marginRight: 4, fontSize: 12 }} />
            搜索工具
          </Tag>
        </Tooltip>
        <div style={{ flex: 1 }} />
        {conv?.deepThink && (
          <Text style={{ fontSize: 11, color: isDark ? "#b388ff" : "#7c3aed" }}>
            逐步推理
          </Text>
        )}
      </div>

      {/* Input */}
      <div style={{
        padding: "8px 20px 20px",
        borderTop: `1px solid ${isDark ? "#2d2d3d" : "#e8e8e8"}`,
        background: isDark ? "#161b22" : "#ffffff",
      }}>
        <div style={{ display: "flex", gap: 8, alignItems: "flex-end" }}>
          <TextArea
            ref={inputRef}
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={handleKeyDown}
            placeholder="输入 Godot 相关问题... (Ctrl+Enter 发送)"
            autoSize={{ minRows: 1, maxRows: 6 }}
            disabled={isThinking}
            style={{
              borderRadius: 12,
              background: isDark ? "#0d1117" : "#f5f7fa",
              border: `1px solid ${isDark ? "#30363d" : "#d9d9d9"}`,
              fontSize: 14,
            }}
          />
          <Button
            type="primary"
            icon={<SendOutlined />}
            onClick={() => handleSend()}
            disabled={!input.trim() || isThinking}
            style={{ height: 40, width: 40, borderRadius: 12 }}
          />
        </div>
        <Text style={{ fontSize: 11, color: isDark ? "#555" : "#bbb", marginTop: 4, display: "block" }}>
          {settings.ai.model} · {settings.ai.provider} · {conv?.searchEnabled !== false ? "搜索开启" : "搜索关闭"}
        </Text>
      </div>
    </div>
  );
};

function toolLabel(name: string): string {
  const labels: Record<string, string> = {
    knowledge_search: "知识库检索",
    web_search: "网络搜索",
    image_search: "图片搜索",
    local_image_search: "本地图片搜索",
  };
  if (name.startsWith("mcp_")) return `MCP: ${name.slice(4)}`;
  return labels[name] || name;
}

function truncateArgs(args: Record<string, any>): string {
  const v = Object.values(args)[0];
  if (typeof v === "string") return v.length > 30 ? v.slice(0, 30) + "..." : v;
  return "";
}

export default ChatPanel;
