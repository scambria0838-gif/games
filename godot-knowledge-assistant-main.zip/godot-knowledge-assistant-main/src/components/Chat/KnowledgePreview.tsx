import React, { useEffect, useState } from "react";
import { Modal, Spin, Typography, Tag, Alert } from "antd";
import { FileTextOutlined, CloseOutlined } from "@ant-design/icons";
import type { SourceRef } from "../../types";
import { getFileContent } from "../../services/knowledge";

const { Text, Paragraph } = Typography;

interface Props {
  source: SourceRef | null;
  open: boolean;
  onClose: () => void;
}

const KnowledgePreview: React.FC<Props> = ({ source, open, onClose }) => {
  const [content, setContent] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  useEffect(() => {
    if (!source || !open) return;
    setLoading(true);
    setError("");
    setContent("");
    const filePath = source.file_path || source.file_id;
    getFileContent(filePath)
      .then((text) => {
        setContent(text);
      })
      .catch((e) => {
        setError(e.message || "无法加载文件内容");
      })
      .finally(() => setLoading(false));
  }, [source, open]);

  return (
    <Modal
      title={
        <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
          <FileTextOutlined />
          <span>{source?.title || "知识预览"}</span>
          {source?.chunk_id && (
            <Tag color="blue" style={{ fontSize: 11 }}>{source.chunk_id}</Tag>
          )}
        </div>
      }
      open={open}
      onCancel={onClose}
      footer={null}
      width={700}
      style={{ top: 40 }}
      closeIcon={<CloseOutlined />}
    >
      {loading ? (
        <div style={{ textAlign: "center", padding: 40 }}>
          <Spin />
          <div style={{ marginTop: 12, color: "#888", fontSize: 13 }}>加载中...</div>
        </div>
      ) : error ? (
        <Alert type="error" message={error} />
      ) : (
        <pre style={{
          background: "#f5f7fa",
          padding: 16,
          borderRadius: 8,
          fontSize: 13,
          lineHeight: 1.6,
          whiteSpace: "pre-wrap",
          wordBreak: "break-word",
          maxHeight: 500,
          overflow: "auto",
          margin: 0,
        }}>
          {content}
        </pre>
      )}
    </Modal>
  );
};

export default KnowledgePreview;
