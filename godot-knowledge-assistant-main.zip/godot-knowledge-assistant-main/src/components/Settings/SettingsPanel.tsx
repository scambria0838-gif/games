import React, { useEffect, useState, useCallback } from "react";
import {
  Layout, Typography, Form, Input, Select, Switch, Button,
  Slider, Divider, Card, Alert, Tag, Space, Spin, theme,
} from "antd";
import {
  SettingOutlined, ApiOutlined, FolderOpenOutlined,
  DatabaseOutlined, CheckCircleOutlined, PictureOutlined,
} from "@ant-design/icons";
import { useSettingsStore } from "../../stores/settingsStore";
import { PROVIDER_CONFIGS, CATEGORY_OPTIONS } from "../../utils/consts";
import type { IndexOverview, AppSettings } from "../../types";
import { loadKnowledgeBase, getIndexOverview, computeKnowledgeEmbeddings } from "../../services/knowledge";
import { open } from "@tauri-apps/plugin-dialog";

const { Text, Title } = Typography;

const SettingsPanel: React.FC = () => {
  const { settings, overview, updateSettings, updateAI, save, setOverview } = useSettingsStore();
  const [testing, setTesting] = useState(false);
  const [testResult, setTestResult] = useState<{ ok: boolean; msg: string } | null>(null);
  const [loadingKB, setLoadingKB] = useState(false);
  const [kbError, setKbError] = useState<string | null>(null);
  const [computingEmb, setComputingEmb] = useState(false);
  const [embResult, setEmbResult] = useState<string | null>(null);

  const isDark = settings.theme === "dark" ||
    (settings.theme === "system" && window.matchMedia("(prefers-color-scheme: dark)").matches);

  // Auto-load knowledge base when path is already configured
  useEffect(() => {
    if (settings.knowledge_path && !overview && !loadingKB) {
      loadKB(settings.knowledge_path);
    }
  }, [settings.knowledge_path]);

  const handleTestConnection = async () => {
    setTesting(true);
    setTestResult(null);
    try {
      const response = await fetch(`${settings.ai.base_url}/models`, {
        headers: { Authorization: `Bearer ${settings.ai.api_key}` },
      });
      if (response.ok) {
        const data = await response.json();
        setTestResult({ ok: true, msg: `连接成功！可用模型: ${(data.data || []).slice(0, 3).map((m: any) => m.id).join(", ")}` });
      } else {
        setTestResult({ ok: false, msg: `API 错误: ${response.status}` });
      }
    } catch (e: any) {
      setTestResult({ ok: false, msg: `连接失败: ${e.message}` });
    } finally {
      setTesting(false);
    }
  };

  const loadKB = useCallback(async (path: string) => {
    if (!path) return;
    setLoadingKB(true);
    setKbError(null);
    try {
      const indexPath = `${path}/godot_index.json`;
      const chunksPath = `${path}/godot_chunks.json`;
      const ov = await loadKnowledgeBase(indexPath, chunksPath, path);
      setOverview(ov);
    } catch (e: any) {
      setKbError(e?.message || String(e) || "加载失败，请检查路径是否正确");
      setOverview(null);
    } finally {
      setLoadingKB(false);
    }
  }, []);

  const handleSelectFolder = async () => {
    try {
      const selected = await open({ directory: true, multiple: false });
      if (selected) {
        updateSettings({ knowledge_path: selected });
        await loadKB(selected);
        save();
      }
    } catch (e) {
      console.error("Folder selection failed:", e);
    }
  };

  const handleProviderChange = (value: string) => {
    const provider = value as AppSettings["ai"]["provider"];
    const config = PROVIDER_CONFIGS[provider];
    if (config) {
      updateAI({ provider, base_url: config.base_url });
    }
  };

  return (
    <Layout style={{ height: "100%", overflow: "auto", background: isDark ? "#0d1117" : "#f5f7fa" }}>
      <div style={{ maxWidth: 700, margin: "0 auto", padding: "24px 32px", width: "100%" }}>
        <div style={{ display: "flex", alignItems: "center", gap: 12, marginBottom: 24 }}>
          <SettingOutlined style={{ fontSize: 28, color: "#4A6CF7" }} />
          <Title level={4} style={{ margin: 0, color: isDark ? "#e0e0e0" : "#333" }}>
            设置
          </Title>
        </div>

        {/* AI Configuration */}
        <Card
          title={<span><ApiOutlined style={{ marginRight: 8 }} />AI 服务配置</span>}
          style={{ marginBottom: 16, background: isDark ? "#161b22" : "#ffffff" }}
        >
          <Form layout="vertical" size="middle">
            <Form.Item label="AI 提供商">
              <Select
                value={settings.ai.provider}
                onChange={handleProviderChange}
                options={[
                  { value: "openai", label: "OpenAI" },
                  { value: "deepseek", label: "DeepSeek" },
                  { value: "ollama", label: "Ollama (本地)" },
                  { value: "custom", label: "自定义" },
                ]}
              />
            </Form.Item>
            <Form.Item label="API Base URL">
              <Input
                value={settings.ai.base_url}
                onChange={(e) => updateAI({ base_url: e.target.value })}
                placeholder="https://api.openai.com/v1"
                onBlur={() => save()}
              />
            </Form.Item>
            <Form.Item label="API Key">
              <Input.Password
                value={settings.ai.api_key}
                onChange={(e) => updateAI({ api_key: e.target.value })}
                placeholder="sk-..."
                onBlur={() => save()}
              />
            </Form.Item>
            <Form.Item label="模型名称">
              <Input
                value={settings.ai.model}
                onChange={(e) => updateAI({ model: e.target.value })}
                placeholder="gpt-4o-mini"
                onBlur={() => save()}
              />
            </Form.Item>
            <Space size="large">
              <Form.Item label="Temperature">
                <Slider
                  min={0} max={2} step={0.1}
                  value={settings.ai.temperature}
                  onChange={(v) => updateAI({ temperature: v })}
                  onAfterChange={() => save()}
                  style={{ width: 160 }}
                />
              </Form.Item>
              <Form.Item label="上下文轮数">
                <Slider
                  min={1} max={50} step={1}
                  value={settings.ai.context_length}
                  onChange={(v) => updateAI({ context_length: v })}
                  onAfterChange={() => save()}
                  style={{ width: 160 }}
                />
              </Form.Item>
            </Space>
            <div style={{ display: "flex", gap: 8, marginTop: 8 }}>
              <Button onClick={handleTestConnection} loading={testing}>
                测试连接
              </Button>
              <Button type="primary" onClick={() => save()}>
                保存配置
              </Button>
            </div>
            {testResult && (
              <Alert
                type={testResult.ok ? "success" : "error"}
                message={testResult.msg}
                showIcon
                style={{ marginTop: 12 }}
              />
            )}
          </Form>
        </Card>

        {/* Knowledge Base */}
        <Card
          title={<span><DatabaseOutlined style={{ marginRight: 8 }} />知识库配置</span>}
          style={{ marginBottom: 16, background: isDark ? "#161b22" : "#ffffff" }}
        >
          <Form layout="vertical">
            <Form.Item label="知识库路径">
              <div style={{ display: "flex", gap: 8 }}>
                <Input
                  value={settings.knowledge_path}
                  onChange={(e) => updateSettings({ knowledge_path: e.target.value })}
                  placeholder="选择包含 godot_index.json 的文件夹"
                  onBlur={() => save()}
                />
                <Button icon={<FolderOpenOutlined />} onClick={handleSelectFolder}>
                  浏览
                </Button>
                <Button
                  type="primary"
                  loading={loadingKB}
                  onClick={() => loadKB(settings.knowledge_path)}
                >
                  加载
                </Button>
              </div>
            </Form.Item>

            {loadingKB && <Spin style={{ display: "block", margin: "12px 0" }} />}

            {kbError && (
              <Alert
                message="加载失败"
                description={kbError}
                type="error"
                showIcon
                closable
                onClose={() => setKbError(null)}
                style={{ marginTop: 8 }}
              />
            )}

            {overview && (
              <div style={{
                padding: 12,
                background: isDark ? "#0d1117" : "#f0f5ff",
                borderRadius: 8,
                marginTop: 8,
              }}>
                <Space direction="vertical" size={4}>
                  <Text><CheckCircleOutlined style={{ color: "#52c41a" }} /> 知识库已加载</Text>
                  <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
                    <Tag>{overview.total_files} 个文件</Tag>
                    {overview.categories.slice(0, 5).map((c) => (
                      <Tag key={c.name}>{c.name} ({c.count})</Tag>
                    ))}
                  </div>
                </Space>
              </div>
            )}

            {!overview && !loadingKB && !kbError && settings.knowledge_path && (
              <Alert
                message="未检测知识库"
                description={'请点击"加载"按钮或使用"浏览"选择文件夹。需包含 godot_index.json'}
                type="info"
                showIcon
                style={{ marginTop: 8 }}
              />
            )}
          </Form>
        </Card>

        {/* Features */}
        <Card
          title={<span>功能开关</span>}
          style={{ marginBottom: 16, background: isDark ? "#161b22" : "#ffffff" }}
        >
          <Space direction="vertical" size="middle" style={{ width: "100%" }}>
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
              <Text>网络搜索</Text>
              <Switch
                checked={settings.enable_web_search}
                onChange={(v) => { updateSettings({ enable_web_search: v }); save(); }}
              />
            </div>
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
              <Text>图片搜索（Pexels）</Text>
              <Switch
                checked={settings.enable_image_search}
                onChange={(v) => { updateSettings({ enable_image_search: v }); save(); }}
              />
            </div>
            <Divider style={{ margin: "4px 0" }} />
            <Form.Item label="本地图片库路径">
              <div style={{ display: "flex", gap: 8 }}>
                <Input
                  value={settings.local_image_path}
                  onChange={(e) => updateSettings({ local_image_path: e.target.value })}
                  placeholder="包含图片的文件夹路径"
                  onBlur={() => save()}
                />
                <Button icon={<FolderOpenOutlined />} onClick={async () => {
                  try {
                    const { open } = await import("@tauri-apps/plugin-dialog");
                    const selected = await open({ directory: true, multiple: false });
                    if (selected) { updateSettings({ local_image_path: selected }); save(); }
                  } catch {}
                }}>浏览</Button>
              </div>
            </Form.Item>
            <Divider style={{ margin: "4px 0" }} />
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
              <Text>语义搜索（使用 AI 嵌入向量提升搜索准确度）</Text>
              <Switch
                checked={settings.enable_semantic_search}
                onChange={(v) => { updateSettings({ enable_semantic_search: v }); save(); }}
              />
            </div>
            {settings.enable_semantic_search && (
              <div style={{ marginTop: 8 }}>
                <Input
                  size="small"
                  value={settings.embedding_model}
                  onChange={(e) => updateSettings({ embedding_model: e.target.value })}
                  placeholder="text-embedding-3-small"
                  onBlur={() => save()}
                  style={{ marginBottom: 8 }}
                />
                <Button
                  size="small"
                  loading={computingEmb}
                  onClick={async () => {
                    if (!settings.knowledge_path || !settings.ai.api_key) {
                      setEmbResult("请先配置知识库路径和 API Key");
                      return;
                    }
                    setComputingEmb(true);
                    setEmbResult(null);
                    try {
                      const result = await computeKnowledgeEmbeddings(
                        settings.knowledge_path,
                        settings.ai.base_url,
                        settings.ai.api_key,
                        settings.embedding_model || "text-embedding-3-small",
                        false
                      );
                      setEmbResult(result);
                    } catch (e: any) {
                      setEmbResult(`计算失败: ${e.message || e}`);
                    } finally {
                      setComputingEmb(false);
                      save();
                    }
                  }}
                >
                  计算嵌入向量
                </Button>
                {embResult && (
                  <Alert
                    type={embResult.includes("失败") ? "error" : "success"}
                    message={embResult}
                    showIcon
                    style={{ marginTop: 8, fontSize: 12 }}
                  />
                )}
              </div>
            )}
            <Divider style={{ margin: "4px 0" }} />
            <Form.Item label="最大工具调用轮次（Agent）">
              <Slider
                min={1} max={50} step={1}
                value={settings.max_tool_rounds}
                onChange={(v) => updateSettings({ max_tool_rounds: v })}
                onAfterChange={() => save()}
                style={{ width: 200 }}
              />
            </Form.Item>
          </Space>
        </Card>

        {/* Image Library */}
        <Card
          title={<span><PictureOutlined style={{ marginRight: 8 }} />图片库管理</span>}
          style={{ marginBottom: 16, background: isDark ? "#161b22" : "#ffffff" }}
        >
          <Form layout="vertical">
            <Form.Item label="本地图片库路径">
              <div style={{ display: "flex", gap: 8 }}>
                <Input
                  value={settings.local_image_path}
                  onChange={(e) => updateSettings({ local_image_path: e.target.value })}
                  placeholder="选择包含图片的文件夹"
                  onBlur={() => save()}
                />
                <Button icon={<FolderOpenOutlined />} onClick={async () => {
                  try {
                    const selected = await open({ directory: true, multiple: false });
                    if (selected) { updateSettings({ local_image_path: selected }); save(); }
                  } catch {}
                }}>
                  浏览
                </Button>
              </div>
            </Form.Item>
            <Text style={{ fontSize: 12, color: isDark ? "#888" : "#999", display: "block", marginBottom: 8 }}>
              支持的格式: JPG, PNG, GIF, WebP, BMP, SVG。可在左侧"图片库"面板中浏览和管理。
            </Text>
          </Form>
        </Card>

        {/* MCP Configuration */}
        <Card
          title={<span>MCP 服务器</span>}
          style={{ marginBottom: 16, background: isDark ? "#161b22" : "#ffffff" }}
        >
          {(settings.mcp_servers || []).map((server, idx) => (
            <div key={server.id} style={{
              padding: 12, marginBottom: 8,
              background: isDark ? "#0d1117" : "#f5f7fa",
              borderRadius: 8, border: `1px solid ${isDark ? "#2d2d3d" : "#e8e8e8"}`,
            }}>
              <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 8 }}>
                <Text strong>{server.name}</Text>
                <Button size="small" danger onClick={() => {
                  const updated = (settings.mcp_servers || []).filter((s) => s.id !== server.id);
                  updateSettings({ mcp_servers: updated }); save();
                }}>删除</Button>
              </div>
              <Input size="small" value={server.command}
                onChange={(e) => {
                  const updated = [...(settings.mcp_servers || [])];
                  updated[idx] = { ...updated[idx], command: e.target.value };
                  updateSettings({ mcp_servers: updated });
                }}
                placeholder="启动命令"
                style={{ marginBottom: 4 }} onBlur={() => save()} />
              <Input size="small" value={server.args.join(" ")}
                onChange={(e) => {
                  const updated = [...(settings.mcp_servers || [])];
                  updated[idx] = { ...updated[idx], args: e.target.value.split(/\s+/) };
                  updateSettings({ mcp_servers: updated });
                }}
                placeholder="参数（空格分隔）"
                style={{ marginBottom: 4 }} onBlur={() => save()} />
              <Switch size="small" checked={server.auto_connect}
                onChange={(v) => {
                  const updated = [...(settings.mcp_servers || [])];
                  updated[idx] = { ...updated[idx], auto_connect: v };
                  updateSettings({ mcp_servers: updated }); save();
                }}
              /> <Text style={{ fontSize: 12 }}>启动时自动连接</Text>
            </div>
          ))}
          <Button block onClick={() => {
            const id = "mcp-" + Date.now().toString(36);
            const updated = [...(settings.mcp_servers || []), {
              id, name: "新服务器", command: "", args: [], auto_connect: false,
            }];
            updateSettings({ mcp_servers: updated }); save();
          }}>添加 MCP 服务器</Button>
          <Text style={{ display: "block", fontSize: 11, color: isDark ? "#555" : "#bbb", marginTop: 8 }}>
            MCP 服务器通过 stdio JSON-RPC 协议连接，支持 Godot MCP 等工具
          </Text>
        </Card>

        {/* Theme */}
        <Card
          title={<span>外观</span>}
          style={{ marginBottom: 16, background: isDark ? "#161b22" : "#ffffff" }}
        >
          <Form.Item label="主题模式">
            <Select
              value={settings.theme}
              onChange={(v) => { updateSettings({ theme: v }); save(); }}
              options={[
                { value: "system", label: "跟随系统" },
                { value: "light", label: "亮色" },
                { value: "dark", label: "暗色" },
              ]}
            />
          </Form.Item>
        </Card>

        <Divider />
        <Text style={{ color: isDark ? "#555" : "#bbb", fontSize: 12 }}>
          Godot 知识助手 v1.0.0 | 基于 Tauri 2.x + React 构建
        </Text>
      </div>
    </Layout>
  );
};

export default SettingsPanel;
