import React, { useEffect, useState, useCallback } from "react";
import {
  Layout, Typography, Collapse, List, Tag, Input, Select,
  Spin, Empty, Badge, Button, theme,
} from "antd";
import {
  FolderOpenOutlined, SearchOutlined, BookOutlined,
  ReloadOutlined, FileTextOutlined,
} from "@ant-design/icons";
import { useSettingsStore } from "../../stores/settingsStore";
import {
  loadKnowledgeBase, getFilesByCategory, getFileContent,
} from "../../services/knowledge";
import type { KnowledgeFile, CategoryInfo } from "../../types";

const { Text, Title } = Typography;
const { Search } = Input;

const KnowledgePanel: React.FC = () => {
  const { settings, overview, setOverview } = useSettingsStore();
  const [files, setFiles] = useState<Record<string, KnowledgeFile[]>>({});
  const [loading, setLoading] = useState(false);
  const [selectedFile, setSelectedFile] = useState<KnowledgeFile | null>(null);
  const [fileContent, setFileContent] = useState("");
  const [contentLoading, setContentLoading] = useState(false);
  const [searchTerm, setSearchTerm] = useState("");

  const isDark = settings.theme === "dark" ||
    (settings.theme === "system" && window.matchMedia("(prefers-color-scheme: dark)").matches);

  const loadData = useCallback(async () => {
    if (!settings.knowledge_path) return;
    setLoading(true);
    try {
      const baseDir = settings.knowledge_path;
      const indexPath = `${baseDir}/godot_index.json`;
      const chunksPath = `${baseDir}/godot_chunks.json`;

      const ov = await loadKnowledgeBase(indexPath, chunksPath, baseDir);
      setOverview(ov);

      const fileMap: Record<string, KnowledgeFile[]> = {};
      for (const cat of ov.categories) {
        const catFiles = await getFilesByCategory(cat.name);
        fileMap[cat.name] = catFiles;
      }
      setFiles(fileMap);
    } catch (e) {
      console.error("Failed to load knowledge base:", e);
    } finally {
      setLoading(false);
    }
  }, [settings.knowledge_path]);

  useEffect(() => {
    loadData();
  }, [loadData]);

  const handleFileClick = async (file: KnowledgeFile) => {
    setSelectedFile(file);
    setContentLoading(true);
    try {
      const content = await getFileContent(file.path);
      setFileContent(content);
    } catch {
      setFileContent("无法读取文件内容");
    } finally {
      setContentLoading(false);
    }
  };

  const filteredCategories = (overview?.categories || []).filter((cat) =>
    cat.name.toLowerCase().includes(searchTerm.toLowerCase())
  );

  if (!settings.knowledge_path) {
    return (
      <div style={{
        display: "flex", flexDirection: "column", alignItems: "center",
        justifyContent: "center", height: "100%", gap: 16, padding: 40,
      }}>
        <FolderOpenOutlined style={{ fontSize: 64, color: isDark ? "#555" : "#ccc" }} />
        <Text style={{ fontSize: 16, color: isDark ? "#888" : "#999" }}>
          请先在设置中配置知识库路径
        </Text>
        <Text style={{ color: isDark ? "#666" : "#bbb", textAlign: "center" }}>
          将路径指向包含 godot_index.json 的文件夹
        </Text>
      </div>
    );
  }

  return (
    <Layout style={{ height: "100%", background: isDark ? "#0d1117" : "#f5f7fa" }}>
      {/* Header */}
      <div style={{
        padding: "12px 20px",
        borderBottom: `1px solid ${isDark ? "#2d2d3d" : "#e8e8e8"}`,
        display: "flex", justifyContent: "space-between", alignItems: "center",
        background: isDark ? "#161b22" : "#ffffff",
      }}>
        <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
          <BookOutlined style={{ fontSize: 18, color: "#4A6CF7" }} />
          <Text strong style={{ fontSize: 15 }}>
            知识库浏览器
          </Text>
          {overview && (
            <Badge count={`${overview.total_files} 文件`} style={{ background: "#4A6CF7" }} />
          )}
        </div>
        <Button icon={<ReloadOutlined />} size="small" onClick={loadData} loading={loading}>
          刷新
        </Button>
      </div>

      <Layout style={{ flex: 1, overflow: "hidden", background: "transparent", flexDirection: "row" }}>
        {/* Category List */}
        <div style={{
          width: 340, overflow: "auto", padding: 12,
          borderRight: `1px solid ${isDark ? "#2d2d3d" : "#e8e8e8"}`,
          background: isDark ? "#161b22" : "#ffffff",
        }}>
          <Search
            placeholder="搜索分类..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            style={{ marginBottom: 12 }}
            size="small"
          />

          {loading ? (
            <div style={{ textAlign: "center", padding: 32 }}><Spin /></div>
          ) : (
            <Collapse
              ghost
              defaultActiveKey={filteredCategories.slice(0, 1).map((c) => c.name)}
              items={filteredCategories.map((cat) => ({
                key: cat.name,
                label: (
                  <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                    <Text style={{ fontSize: 13 }}>{cat.name}</Text>
                    <Tag style={{ fontSize: 11 }}>{cat.count}</Tag>
                  </div>
                ),
                children: (
                  <List
                    size="small"
                    dataSource={files[cat.name] || []}
                    renderItem={(file) => (
                      <List.Item
                        onClick={() => handleFileClick(file)}
                        style={{
                          cursor: "pointer",
                          padding: "6px 8px",
                          borderRadius: 6,
                          background: selectedFile?.id === file.id
                            ? (isDark ? "#1a3a6b" : "#e6f0ff")
                            : "transparent",
                          marginBottom: 2,
                        }}
                      >
                        <div style={{ overflow: "hidden" }}>
                          <Text
                            ellipsis
                            style={{ fontSize: 12, display: "block", color: isDark ? "#ccc" : "#555" }}
                          >
                            <FileTextOutlined style={{ marginRight: 4 }} />
                            {file.title}
                          </Text>
                          <div style={{ display: "flex", gap: 4, marginTop: 2 }}>
                            <Tag color="default" style={{ fontSize: 10, lineHeight: "16px", padding: "0 4px" }}>
                              {file.difficulty}
                            </Tag>
                            <Tag style={{ fontSize: 10, lineHeight: "16px", padding: "0 4px" }}>
                              {file.chunk_count} 块
                            </Tag>
                          </div>
                        </div>
                      </List.Item>
                    )}
                  />
                ),
              }))}
            />
          )}

          {!loading && filteredCategories.length === 0 && (
            <Empty description="无匹配分类" />
          )}
        </div>

        {/* Preview */}
        <div style={{
          flex: 1, overflow: "auto", padding: 20,
          background: isDark ? "#0d1117" : "#f5f7fa",
        }}>
          {selectedFile ? (
            <>
              <div style={{ marginBottom: 16 }}>
                <Title level={5} style={{ margin: 0, color: isDark ? "#e0e0e0" : "#333" }}>
                  {selectedFile.title}
                </Title>
                <div style={{ display: "flex", gap: 8, marginTop: 8 }}>
                  {selectedFile.category.map((c) => (
                    <Tag key={c} color="blue">{c}</Tag>
                  ))}
                  <Tag>{selectedFile.difficulty}</Tag>
                </div>
                <Text style={{ fontSize: 13, color: isDark ? "#888" : "#666", display: "block", marginTop: 8 }}>
                  {selectedFile.summary}
                </Text>
              </div>
              <div style={{
                background: isDark ? "#161b22" : "#ffffff",
                borderRadius: 8,
                padding: 16,
                border: `1px solid ${isDark ? "#2d2d3d" : "#e8e8e8"}`,
              }}>
                {contentLoading ? (
                  <div style={{ textAlign: "center", padding: 32 }}><Spin /></div>
                ) : (
                  <pre style={{
                    margin: 0, whiteSpace: "pre-wrap", wordBreak: "break-word",
                    fontFamily: "'JetBrains Mono', 'Consolas', monospace",
                    fontSize: 13, lineHeight: 1.6,
                    color: isDark ? "#e0e0e0" : "#333",
                    maxHeight: 600, overflow: "auto",
                  }}>
                    {fileContent}
                  </pre>
                )}
              </div>
            </>
          ) : (
            <div style={{
              display: "flex", flexDirection: "column", alignItems: "center",
              justifyContent: "center", height: "100%", gap: 8,
            }}>
              <BookOutlined style={{ fontSize: 48, color: isDark ? "#444" : "#ddd" }} />
              <Text style={{ color: isDark ? "#666" : "#aaa" }}>
                从左侧选择一个教程文件查看内容
              </Text>
            </div>
          )}
        </div>
      </Layout>
    </Layout>
  );
};

export default KnowledgePanel;
