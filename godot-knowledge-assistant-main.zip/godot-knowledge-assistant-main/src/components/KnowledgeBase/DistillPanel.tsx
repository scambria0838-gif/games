import React, { useState } from "react";
import {
  Layout, Typography, Button, Card, Alert, Tag, Space,
  Spin, Progress, Divider, Input,
} from "antd";
import {
  ExperimentOutlined, FolderOpenOutlined,
  CheckCircleOutlined, CloseCircleOutlined, DatabaseOutlined,
} from "@ant-design/icons";
import { invoke } from "@tauri-apps/api/core";
import { open } from "@tauri-apps/plugin-dialog";
import { useSettingsStore } from "../../stores/settingsStore";
import { loadKnowledgeBase } from "../../services/knowledge";

const { Text, Title } = Typography;

interface DistillResult {
  total_files: number;
  total_chunks: number;
  index_path: string;
  chunks_path: string;
  categories: string[];
}

const DistillPanel: React.FC = () => {
  const { settings, setOverview } = useSettingsStore();
  const [sourceDir, setSourceDir] = useState("");
  const [targetDir, setTargetDir] = useState("");
  const [distilling, setDistilling] = useState(false);
  const [result, setResult] = useState<DistillResult | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [progress, setProgress] = useState(0);

  const isDark = settings.theme === "dark" ||
    (settings.theme === "system" && window.matchMedia("(prefers-color-scheme: dark)").matches);

  const handleSelectSource = async () => {
    try {
      const selected = await open({ directory: true, multiple: false });
      if (selected) setSourceDir(selected);
    } catch {}
  };

  const handleSelectTarget = async () => {
    try {
      const selected = await open({ directory: true, multiple: false });
      if (selected) setTargetDir(selected);
    } catch {}
  };

  const handleDistill = async () => {
    if (!sourceDir || !targetDir) return;
    setDistilling(true);
    setError(null);
    setResult(null);
    setProgress(0);

    const interval = setInterval(() => {
      setProgress((p) => Math.min(p + 5, 90));
    }, 1000);

    try {
      const res = await invoke<DistillResult>("distill_knowledge", {
        sourceDir,
        targetDir,
      });
      setResult(res);
      setProgress(100);

      if (settings.knowledge_path === targetDir) {
        try {
          const ov = await loadKnowledgeBase(
            `${targetDir}/godot_index.json`,
            `${targetDir}/godot_chunks.json`,
            targetDir,
          );
          setOverview(ov);
        } catch {}
      }
    } catch (e: any) {
      setError(e?.message || String(e) || "蒸馏失败");
    } finally {
      clearInterval(interval);
      setDistilling(false);
    }
  };

  return (
    <Layout style={{ height: "100%", overflow: "auto", background: isDark ? "#0d1117" : "#f5f7fa" }}>
      <div style={{ maxWidth: 700, margin: "0 auto", padding: "24px 32px", width: "100%" }}>
        <div style={{ display: "flex", alignItems: "center", gap: 12, marginBottom: 24 }}>
          <ExperimentOutlined style={{ fontSize: 28, color: "#4A6CF7" }} />
          <Title level={4} style={{ margin: 0, color: isDark ? "#e0e0e0" : "#333" }}>
            知识库蒸馏
          </Title>
        </div>

        <Card style={{ marginBottom: 16, background: isDark ? "#161b22" : "#ffffff" }}>
          <Space direction="vertical" style={{ width: "100%" }} size="middle">
            <div>
              <Text strong>源文件夹</Text>
              <div style={{ display: "flex", gap: 8, marginTop: 4 }}>
                <Input
                  value={sourceDir}
                  onChange={(e) => setSourceDir(e.target.value)}
                  placeholder="包含 .txt 教程文件的文件夹"
                  style={{ flex: 1 }}
                />
                <Button icon={<FolderOpenOutlined />} onClick={handleSelectSource}>浏览</Button>
              </div>
            </div>

            <div>
              <Text strong>输出文件夹</Text>
              <div style={{ display: "flex", gap: 8, marginTop: 4 }}>
                <Input
                  value={targetDir}
                  onChange={(e) => setTargetDir(e.target.value)}
                  placeholder="存放 godot_index.json 和 godot_chunks.json"
                  style={{ flex: 1 }}
                />
                <Button icon={<FolderOpenOutlined />} onClick={handleSelectTarget}>浏览</Button>
              </div>
              {targetDir && settings.knowledge_path === targetDir && (
                <Text style={{ fontSize: 12, color: "#52c41a", marginTop: 4, display: "block" }}>
                  输出到当前知识库路径，蒸馏完成将自动刷新
                </Text>
              )}
            </div>

            <Button
              type="primary"
              block
              size="large"
              icon={<ExperimentOutlined />}
              onClick={handleDistill}
              loading={distilling}
              disabled={!sourceDir || !targetDir}
            >
              {distilling ? "蒸馏中..." : "开始蒸馏"}
            </Button>

            {distilling && (
              <div>
                <Progress percent={progress} status="active" strokeColor="#4A6CF7" />
                <Text style={{ fontSize: 12, color: isDark ? "#888" : "#999", display: "block", textAlign: "center" }}>
                  正在读取文件、生成索引和分块...
                </Text>
              </div>
            )}

            {error && (
              <Alert
                message="蒸馏失败"
                description={error}
                type="error"
                showIcon
                closable
                onClose={() => setError(null)}
              />
            )}

            {result && (
              <div style={{
                padding: 16,
                background: isDark ? "#0d1117" : "#f0f5ff",
                borderRadius: 8,
              }}>
                <Space direction="vertical" size={4}>
                  <Text><CheckCircleOutlined style={{ color: "#52c41a" }} /> 蒸馏完成</Text>
                  <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
                    <Tag color="blue">{result.total_files} 个文件</Tag>
                    <Tag color="green">{result.total_chunks} 个知识块</Tag>
                  </div>
                  {result.categories.length > 0 && (
                    <div>
                      <Text style={{ fontSize: 12 }}>分类: </Text>
                      {result.categories.map((c) => (
                        <Tag key={c}>{c}</Tag>
                      ))}
                    </div>
                  )}
                  <Divider style={{ margin: "4px 0" }} />
                  <Text style={{ fontSize: 11 }}>
                    {result.index_path}
                  </Text>
                  <Text style={{ fontSize: 11 }}>
                    {result.chunks_path}
                  </Text>
                </Space>
              </div>
            )}
          </Space>
        </Card>

        <Card title="说明" style={{ background: isDark ? "#161b22" : "#ffffff" }}>
          <ol style={{ color: isDark ? "#ccc" : "#666", fontSize: 13, margin: 0, paddingLeft: 20 }}>
            <li>选择包含 .txt 教程文件的源文件夹（支持子目录递归扫描）</li>
            <li>选择输出文件夹存储索引文件（JSON 格式）</li>
            <li>蒸馏完成后，索引文件可被加载到知识库中使用</li>
            <li>如果输出路径与当前知识库路径一致，将自动刷新</li>
            <li>支持增量蒸馏：添加新教程文件后重新蒸馏即可合并</li>
          </ol>
        </Card>
      </div>
    </Layout>
  );
};

export default DistillPanel;
