import React, { useState, useEffect } from "react";
import { Layout, Menu, Button, Tooltip, theme, Typography, Spin } from "antd";
import {
  MessageOutlined,
  BookOutlined,
  SettingOutlined,
  PlusOutlined,
  DeleteOutlined,
  SunOutlined,
  MoonOutlined,
  ExperimentOutlined,
  PictureOutlined,
} from "@ant-design/icons";
import ChatPanel from "../Chat/ChatPanel";
import KnowledgePanel from "../KnowledgeBase/KnowledgePanel";
import DistillPanel from "../KnowledgeBase/DistillPanel";
import ImageLibraryPanel from "../ImageLibrary/ImageLibraryPanel";
import SettingsPanel from "../Settings/SettingsPanel";
import { useChatStore } from "../../stores/chatStore";
import { useSettingsStore } from "../../stores/settingsStore";

const { Sider, Content } = Layout;
const { Text } = Typography;

const AppLayout: React.FC = () => {
  const [activePanel, setActivePanel] = useState<"chat" | "knowledge" | "distill" | "images" | "settings">("chat");
  const { conversations, currentId, createConversation, switchConversation, deleteConversation, loaded, loadPersistedConversations } = useChatStore();
  const { settings, updateSettings, initialized } = useSettingsStore();

  useEffect(() => {
    if (!loaded) {
      loadPersistedConversations();
    }
  }, []);

  const isDark = settings.theme === "dark" ||
    (settings.theme === "system" && window.matchMedia("(prefers-color-scheme: dark)").matches);

  const toggleTheme = () => {
    updateSettings({ theme: isDark ? "light" : "dark" });
    useSettingsStore.getState().save();
  };

  return (
    <Layout style={{ height: "100vh", overflow: "hidden" }}>
      <Sider
        width={56}
        style={{
          background: isDark ? "#1a1a2e" : "#f8f9fa",
          borderRight: `1px solid ${isDark ? "#2d2d3d" : "#e8e8e8"}`,
          display: "flex",
          flexDirection: "column",
          alignItems: "center",
          padding: "12px 0",
          gap: 8,
        }}
      >
        <Tooltip title="对话" placement="right">
          <Button
            type={activePanel === "chat" ? "primary" : "text"}
            icon={<MessageOutlined />}
            onClick={() => setActivePanel("chat")}
            size="large"
          />
        </Tooltip>
        <Tooltip title="知识库" placement="right">
          <Button
            type={activePanel === "knowledge" ? "primary" : "text"}
            icon={<BookOutlined />}
            onClick={() => setActivePanel("knowledge")}
            size="large"
          />
        </Tooltip>
        <Tooltip title="蒸馏" placement="right">
          <Button
            type={activePanel === "distill" ? "primary" : "text"}
            icon={<ExperimentOutlined />}
            onClick={() => setActivePanel("distill")}
            size="large"
          />
        </Tooltip>
        <Tooltip title="图片库" placement="right">
          <Button
            type={activePanel === "images" ? "primary" : "text"}
            icon={<PictureOutlined />}
            onClick={() => setActivePanel("images")}
            size="large"
          />
        </Tooltip>
        <Tooltip title="设置" placement="right">
          <Button
            type={activePanel === "settings" ? "primary" : "text"}
            icon={<SettingOutlined />}
            onClick={() => setActivePanel("settings")}
            size="large"
          />
        </Tooltip>
        <div style={{ flex: 1 }} />
        <Tooltip title={isDark ? "亮色模式" : "暗色模式"} placement="right">
          <Button
            type="text"
            icon={isDark ? <SunOutlined /> : <MoonOutlined />}
            onClick={toggleTheme}
            size="large"
          />
        </Tooltip>
      </Sider>

      {activePanel === "chat" && (
        <Sider
          width={260}
          style={{
            background: isDark ? "#16213e" : "#ffffff",
            borderRight: `1px solid ${isDark ? "#2d2d3d" : "#e8e8e8"}`,
            display: "flex",
            flexDirection: "column",
            overflow: "hidden",
          }}
        >
          <div style={{ padding: "16px", borderBottom: `1px solid ${isDark ? "#2d2d3d" : "#e8e8e8"}` }}>
            <Button
              type="primary"
              block
              icon={<PlusOutlined />}
              onClick={createConversation}
            >
              新对话
            </Button>
          </div>
          <div style={{ flex: 1, overflow: "auto", padding: "8px" }}>
            {conversations.map((conv) => (
              <div
                key={conv.id}
                onClick={() => switchConversation(conv.id)}
                style={{
                  padding: "10px 12px",
                  cursor: "pointer",
                  borderRadius: 8,
                  marginBottom: 4,
                  background: conv.id === currentId
                    ? (isDark ? "#1a3a6b" : "#e6f0ff")
                    : "transparent",
                  display: "flex",
                  justifyContent: "space-between",
                  alignItems: "center",
                  transition: "background 0.2s",
                }}
                onMouseEnter={(e) => {
                  if (conv.id !== currentId) {
                    (e.currentTarget as HTMLElement).style.background = isDark ? "#1e2a4a" : "#f5f5f5";
                  }
                }}
                onMouseLeave={(e) => {
                  if (conv.id !== currentId) {
                    (e.currentTarget as HTMLElement).style.background = "transparent";
                  }
                }}
              >
                <div style={{ overflow: "hidden" }}>
                  <Text
                    ellipsis
                    style={{
                      fontSize: 13,
                      color: isDark ? "#e0e0e0" : "#333",
                      display: "block",
                    }}
                  >
                    {conv.title}
                  </Text>
                  <Text style={{ fontSize: 11, color: isDark ? "#888" : "#999" }}>
                    {new Date(conv.updated_at).toLocaleString("zh-CN")}
                  </Text>
                </div>
                <Button
                  type="text"
                  size="small"
                  icon={<DeleteOutlined />}
                  onClick={(e) => { e.stopPropagation(); deleteConversation(conv.id); }}
                  style={{ opacity: 0.4, fontSize: 12 }}
                />
              </div>
            ))}
            {conversations.length === 0 && (
              <div style={{ textAlign: "center", color: isDark ? "#666" : "#bbb", padding: 32, fontSize: 13 }}>
                暂无对话，点击上方按钮创建
              </div>
            )}
          </div>
        </Sider>
      )}

      <Content style={{ overflow: "hidden", display: "flex", flexDirection: "column" }}>
        {activePanel === "chat" && <ChatPanel />}
        {activePanel === "knowledge" && <KnowledgePanel />}
        {activePanel === "distill" && <DistillPanel />}
        {activePanel === "images" && <ImageLibraryPanel />}
        {activePanel === "settings" && <SettingsPanel />}
      </Content>
    </Layout>
  );
};

export default AppLayout;
