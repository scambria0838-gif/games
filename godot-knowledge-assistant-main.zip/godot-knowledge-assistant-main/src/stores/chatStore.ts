import { create } from "zustand";
import type { Message, Conversation, SearchResult, IndexOverview, KnowledgeFile } from "../types";
import { invoke } from "@tauri-apps/api/core";
import { saveConversations, loadConversations } from "../services/persistence";

interface ChatState {
  conversations: Conversation[];
  currentId: string | null;
  isThinking: boolean;
  searchResults: SearchResult[];
  loaded: boolean;

  getCurrent: () => Conversation | undefined;
  createConversation: () => string;
  switchConversation: (id: string) => void;
  deleteConversation: (id: string) => void;
  addMessage: (msg: Message) => void;
  updateLastMessage: (content: string) => void;
  setThinking: (v: boolean) => void;
  searchKnowledgeBase: (query: string, category?: string, difficulty?: string) => Promise<SearchResult[]>;
  clearContext: () => void;
  renameConversation: (id: string, title: string) => void;
  setFeedback: (messageId: string, feedback: "like" | "dislike" | undefined) => void;
  removeMessagesFrom: (messageId: string) => void;
  setDeepThink: (id: string, v: boolean) => void;
  setSearchEnabled: (id: string, v: boolean) => void;
  setMode: (id: string, mode: "qa" | "programming") => void;
  persistConversations: () => Promise<void>;
  forcePersist: () => Promise<void>;
  loadPersistedConversations: () => Promise<void>;
  setToolCalls: (messageId: string, toolCalls: import("../types").ToolCall[]) => void;
  setMessageSources: (messageId: string, sources: import("../types").SourceRef[]) => void;
}

let msgCounter = 0;
let persistTimer: ReturnType<typeof setTimeout> | null = null;

function schedulePersist(get: () => ChatState) {
  if (persistTimer) clearTimeout(persistTimer);
  persistTimer = setTimeout(async () => {
    const { conversations } = get();
    await saveConversations(conversations);
  }, 500);
}

export const useChatStore = create<ChatState>((set, get) => ({
  conversations: [],
  currentId: null,
  isThinking: false,
  searchResults: [],
  loaded: false,

  getCurrent: () => {
    const { conversations, currentId } = get();
    return conversations.find((c) => c.id === currentId);
  },

  loadPersistedConversations: async () => {
    try {
      const saved = await loadConversations();
      if (saved.length > 0) {
        set({ conversations: saved, currentId: saved[0].id, loaded: true });
        // Immediately persist to ensure currentId is saved
        setTimeout(() => saveConversations(get().conversations), 100);
      } else {
        set({ loaded: true });
        const newId = get().createConversation();
        // Immediately persist the default conversation
        setTimeout(() => saveConversations(get().conversations), 100);
      }
    } catch {
      set({ loaded: true });
      get().createConversation();
    }
  },

  persistConversations: async () => {
    await saveConversations(get().conversations);
  },
  forcePersist: async () => {
    if (persistTimer) clearTimeout(persistTimer);
    persistTimer = null;
    await saveConversations(get().conversations);
  },

  createConversation: () => {
    const id = Date.now().toString(36) + Math.random().toString(36).slice(2, 6);
    const conv: Conversation = {
      id,
      title: "新对话",
      messages: [],
      created_at: Date.now(),
      updated_at: Date.now(),
    };
    set((s) => ({ conversations: [conv, ...s.conversations], currentId: id }));
    schedulePersist(get);
    return id;
  },

  switchConversation: (id) => {
    set({ currentId: id, searchResults: [] });
    schedulePersist(get);
  },

  deleteConversation: (id) => {
    set((s) => {
      const filtered = s.conversations.filter((c) => c.id !== id);
      const newCurrent = s.currentId === id
        ? (filtered[0]?.id ?? null)
        : s.currentId;
      return { conversations: filtered, currentId: newCurrent };
    });
    schedulePersist(get);
  },

  addMessage: (msg) => {
    set((s) => ({
      conversations: s.conversations.map((c) =>
        c.id === s.currentId
          ? { ...c, messages: [...c.messages, msg], updated_at: Date.now() }
          : c
      ),
    }));
    // Auto-title on first user message
    const conv = get().getCurrent();
    if (conv && conv.messages.length === 1 && conv.title === "新对话") {
      const title = msg.content.slice(0, 40) + (msg.content.length > 40 ? "..." : "");
      get().renameConversation(conv.id, title);
    }
    schedulePersist(get);
  },

  updateLastMessage: (content) => {
    set((s) => ({
      conversations: s.conversations.map((c) =>
        c.id === s.currentId && c.messages.length > 0
          ? {
              ...c,
              messages: c.messages.map((m, i) =>
                i === c.messages.length - 1 ? { ...m, content } : m
              ),
              updated_at: Date.now(),
            }
          : c
      ),
    }));
    schedulePersist(get);
  },

  setThinking: (v) => set({ isThinking: v }),

  searchKnowledgeBase: async (query, category?, difficulty?) => {
    try {
      const results = await invoke<SearchResult[]>("search_knowledge", {
        query,
        category: category || null,
        difficulty: difficulty || null,
        limit: 10,
      });
      set({ searchResults: results });
      return results;
    } catch (e) {
      console.error("Knowledge search failed:", e);
      return [];
    }
  },

  clearContext: () => {
    const conv = get().getCurrent();
    if (conv) {
      set((s) => ({
        conversations: s.conversations.map((c) =>
          c.id === s.currentId ? { ...c, messages: [] } : c
        ),
      }));
      schedulePersist(get);
    }
  },

  renameConversation: (id, title) => {
    set((s) => ({
      conversations: s.conversations.map((c) =>
        c.id === id ? { ...c, title } : c
      ),
    }));
    schedulePersist(get);
  },

  setFeedback: (messageId, feedback) => {
    set((s) => ({
      conversations: s.conversations.map((c) =>
        c.id === s.currentId
          ? {
              ...c,
              messages: c.messages.map((m) =>
                m.id === messageId ? { ...m, feedback } : m
              ),
              updated_at: Date.now(),
            }
          : c
      ),
    }));
    schedulePersist(get);
  },

  removeMessagesFrom: (messageId) => {
    set((s) => ({
      conversations: s.conversations.map((c) =>
        c.id === s.currentId
          ? {
              ...c,
              messages: c.messages.filter((m) => {
                const idx = c.messages.findIndex((x) => x.id === messageId);
                return idx === -1 || c.messages.indexOf(m) < idx;
              }),
              updated_at: Date.now(),
            }
          : c
      ),
    }));
    schedulePersist(get);
  },

  setDeepThink: (id, v) => {
    set((s) => ({
      conversations: s.conversations.map((c) =>
        c.id === id ? { ...c, deepThink: v } : c
      ),
    }));
    schedulePersist(get);
  },

  setSearchEnabled: (id, v) => {
    set((s) => ({
      conversations: s.conversations.map((c) =>
        c.id === id ? { ...c, searchEnabled: v } : c
      ),
    }));
    schedulePersist(get);
  },

  setMode: (id, mode) => {
    set((s) => ({
      conversations: s.conversations.map((c) =>
        c.id === id ? { ...c, mode } : c
      ),
    }));
    schedulePersist(get);
  },

  setToolCalls: (messageId, toolCalls) => {
    set((s) => ({
      conversations: s.conversations.map((c) =>
        c.id === s.currentId
          ? {
              ...c,
              messages: c.messages.map((m) =>
                m.id === messageId ? { ...m, tool_calls: toolCalls } : m
              ),
              updated_at: Date.now(),
            }
          : c
      ),
    }));
    schedulePersist(get);
  },

  setMessageSources: (messageId, sources) => {
    set((s) => ({
      conversations: s.conversations.map((c) =>
        c.id === s.currentId
          ? {
              ...c,
              messages: c.messages.map((m) =>
                m.id === messageId ? { ...m, sources } : m
              ),
              updated_at: Date.now(),
            }
          : c
      ),
    }));
    schedulePersist(get);
  },
}));
