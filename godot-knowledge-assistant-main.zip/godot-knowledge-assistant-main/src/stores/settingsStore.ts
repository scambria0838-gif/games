import { create } from "zustand";
import type { AppSettings, IndexOverview } from "../types";
import { DEFAULT_SETTINGS } from "../utils/consts";

interface SettingsState {
  settings: AppSettings;
  overview: IndexOverview | null;
  initialized: boolean;

  updateSettings: (partial: Partial<AppSettings>) => void;
  updateAI: (partial: Partial<AppSettings["ai"]> & { provider?: string }) => void;
  setOverview: (o: IndexOverview | null) => void;
  setInitialized: (v: boolean) => void;
  save: () => Promise<void>;
  load: () => Promise<void>;
}

export const useSettingsStore = create<SettingsState>((set, get) => ({
  settings: { ...DEFAULT_SETTINGS, ai: { ...DEFAULT_SETTINGS.ai } },
  overview: null,
  initialized: false,

  updateSettings: (partial) => {
    set((s) => ({ settings: { ...s.settings, ...partial } }));
  },

  updateAI: (partial) => {
    set((s) => ({
      settings: { ...s.settings, ai: { ...s.settings.ai, ...partial } },
    }));
  },

  setOverview: (o) => set({ overview: o }),

  setInitialized: (v) => set({ initialized: v }),

  save: async () => {
    try {
      const { Store } = await import("@tauri-apps/plugin-store");
      const store = await Store.load("settings.json");
      await store.set("settings", get().settings);
      await store.save();
    } catch (e) {
      console.error("Failed to save settings:", e);
    }
  },

  load: async () => {
    try {
      const { Store } = await import("@tauri-apps/plugin-store");
      const store = await Store.load("settings.json");
      const saved = await store.get<AppSettings>("settings");
      if (saved) {
        set({ settings: { ...DEFAULT_SETTINGS, ...saved, ai: { ...DEFAULT_SETTINGS.ai, ...saved.ai } } });
      }
    } catch (e) {
      console.error("Failed to load settings:", e);
    }
    set({ initialized: true });
  },
}));
