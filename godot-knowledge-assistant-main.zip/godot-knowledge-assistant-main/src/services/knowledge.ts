import { invoke } from "@tauri-apps/api/core";
import type { IndexOverview, SearchResult, KnowledgeFile } from "../types";

export async function loadKnowledgeBase(
  indexPath: string,
  chunksPath: string,
  baseDir: string
): Promise<IndexOverview> {
  return await invoke<IndexOverview>("load_knowledge_base", {
    indexPath,
    chunksPath,
    baseDir,
  });
}

export async function searchKnowledge(
  query: string,
  category?: string,
  difficulty?: string,
  limit?: number
): Promise<SearchResult[]> {
  return await invoke<SearchResult[]>("search_knowledge", {
    query,
    category: category || null,
    difficulty: difficulty || null,
    limit: limit || 10,
  });
}

export async function getFileContent(filePath: string): Promise<string> {
  return await invoke<string>("get_file_content", { filePath });
}

export async function getIndexOverview(): Promise<IndexOverview> {
  return await invoke<IndexOverview>("get_index_overview");
}

export async function getFilesByCategory(category: string): Promise<KnowledgeFile[]> {
  return await invoke<KnowledgeFile[]>("get_files_by_category", { category });
}

export async function getRelatedFiles(fileId: string): Promise<KnowledgeFile[]> {
  return await invoke<KnowledgeFile[]>("get_related_files", { fileId });
}

export async function searchKnowledgeHybrid(
  query: string,
  queryVec: number[],
  category?: string,
  difficulty?: string,
  limit?: number
): Promise<SearchResult[]> {
  return await invoke<SearchResult[]>("search_knowledge_hybrid", {
    query,
    queryVec,
    category: category || null,
    difficulty: difficulty || null,
    limit: limit || 10,
  });
}

export async function computeKnowledgeEmbeddings(
  targetDir: string,
  apiBase: string,
  apiKey: string,
  model: string,
  force: boolean
): Promise<string> {
  return await invoke<string>("compute_knowledge_embeddings", {
    targetDir,
    apiBase,
    apiKey,
    model: model || "text-embedding-3-small",
    force,
  });
}
