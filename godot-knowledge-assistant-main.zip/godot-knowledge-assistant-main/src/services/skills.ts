import type { SkillDefinition, ToolDefinition } from "../types";

const SKILL_REGISTRY = new Map<string, SkillDefinition>();

export function registerSkill(skill: SkillDefinition): void {
  SKILL_REGISTRY.set(skill.id, skill);
}

export function getSkill(id: string): SkillDefinition | undefined {
  return SKILL_REGISTRY.get(id);
}

export function listSkills(): SkillDefinition[] {
  return Array.from(SKILL_REGISTRY.values());
}

export function getSkillTools(): ToolDefinition[] {
  const tools: ToolDefinition[] = [];
  for (const skill of SKILL_REGISTRY.values()) {
    for (const t of skill.tools) {
      tools.push({
        name: `skill_${skill.id}_${t.name}`,
        description: `[技能/${skill.name}] ${t.description}`,
        inputSchema: t.inputSchema,
      });
    }
  }
  return tools;
}

export function buildSkillSystemPrompt(): string {
  const parts: string[] = [];
  for (const skill of SKILL_REGISTRY.values()) {
    if (skill.system_prompt) {
      parts.push(`[技能: ${skill.name} v${skill.version}]`);
      parts.push(skill.system_prompt);
    }
  }
  return parts.join("\n\n");
}

export async function loadSkillFromUrl(url: string): Promise<SkillDefinition | null> {
  try {
    const response = await fetch(url);
    const data = await response.json();
    const skill = data as SkillDefinition;
    if (skill.id && skill.name) {
      registerSkill(skill);
      return skill;
    }
    return null;
  } catch (e) {
    console.error(`Failed to load skill from ${url}:`, e);
    return null;
  }
}

export async function loadSkillsFromUrls(urls: string[]): Promise<number> {
  let count = 0;
  for (const url of urls) {
    const skill = await loadSkillFromUrl(url);
    if (skill) count++;
  }
  return count;
}

export function clearSkills(): void {
  SKILL_REGISTRY.clear();
}
