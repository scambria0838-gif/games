import { invoke } from "@tauri-apps/api/core";
import type { LocalImage } from "../types";
import { convertFileSrc } from "@tauri-apps/api/core";

export async function downloadImageAsDataUrl(url: string): Promise<string> {
  try {
    return await invoke<string>("download_image_as_data_url", { url });
  } catch {
    return url;
  }
}

export async function scanLocalImages(dir: string): Promise<LocalImage[]> {
  if (!dir) return [];
  try {
    return await invoke<LocalImage[]>("scan_local_images", { dir });
  } catch (e) {
    console.error("Failed to scan local images:", e);
    return [];
  }
}

let localImageCache: LocalImage[] = [];
let cacheDir = "";

export async function loadLocalImageCache(dir: string): Promise<void> {
  if (dir === cacheDir && localImageCache.length > 0) return;
  localImageCache = await scanLocalImages(dir);
  cacheDir = dir;
}

export async function localImageSearch(query: string, limit = 10): Promise<LocalImage[]> {
  const settings = (await import("../stores/settingsStore")).useSettingsStore.getState().settings;
  if (settings.local_image_path) {
    await loadLocalImageCache(settings.local_image_path);
  }
  if (localImageCache.length === 0) return [];

  const q = query.toLowerCase();
  const results = localImageCache.filter((img) => {
    if (img.name.toLowerCase().includes(q)) return true;
    if (img.tags.some((t) => t.toLowerCase().includes(q))) return true;
    if (img.path.toLowerCase().includes(q)) return true;
    return false;
  });

  return results.slice(0, limit).map((img) => ({
    ...img,
    url: convertFileSrc(img.path),
  }));
}

export async function deleteLocalImage(path: string): Promise<boolean> {
  try {
    await invoke("delete_local_image", { path });
    localImageCache = localImageCache.filter((img) => img.path !== path);
    return true;
  } catch (e) {
    console.error("Failed to delete image:", e);
    return false;
  }
}

export function getLocalImageCache(): LocalImage[] {
  return localImageCache;
}

export function clearImageCache(): void {
  localImageCache = [];
  cacheDir = "";
}
