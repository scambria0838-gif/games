import type { Message, AIConfig, ToolDefinition, APIResponse } from "../types";
import { useChatStore } from "../stores/chatStore";
import { useSettingsStore } from "../stores/settingsStore";
import { webSearch } from "./search";
import { imageSearch } from "./search";
import { localImageSearch } from "./image";
import { mcpManager } from "./mcp";
import { getFileContent, searchKnowledgeHybrid, getIndexOverview, loadKnowledgeBase } from "./knowledge";

let kbSearchDone = false;

function buildSystemPrompt(deepThink?: boolean, mode?: string): string {
  const settings = useSettingsStore.getState().settings;

  if (mode === "programming") {
    let p = `你是一位资深 Godot 游戏开发程序员。帮助用户编写和调试 Godot 项目代码。

## 回答规范
1. 直接给出可运行代码，用 Markdown 代码块
2. 优先使用 MCP 工具操作编辑器或项目
3. 用 knowledge_search 获取知识库示例

## 可用工具
- knowledge_search(query): 检索知识库
- MCP 工具（如已连接）: 操作 Godot 编辑器`;
    if (settings.mcp_servers?.length) p += `\n\n已连接的 MCP 服务器工具也会在响应中提供。`;
    if (deepThink) p += `\n\n【深度思考模式】在最终答案前用分隔符分隔。`;
    return p;
  }

  let prompt = `你是一位精通 Godot 引擎的资深游戏开发专家。你正在帮助用户学习 Godot 游戏开发。

## 知识检索规则

1. 收到问题后，先用 knowledge_search 搜索知识库。

2. **搜索技巧**：
   - 用简短关键词，不要复合短语
   - 搜"信号"而非"信号系统"，搜"碰撞"而非"碰撞检测"
   - 去掉"制作""方法""怎么""如何"等泛词
   - 中文搜不到时换英文（如 tilemap、signal、animation）

3. 如果返回空结果，直接说"知识库中没有找到相关信息"。不要再搜索或编造。

4. 有结果时用 knowledge_read 读完整文件再回答。

5. 不确定搜什么时先用 knowledge_categories 看分类。

## 可用工具
- knowledge_search(query): 检索知识库
- knowledge_read(file_path): 读取文件全文
- knowledge_categories(): 查看知识库分类`;

  if (settings.mcp_servers?.length) {
    prompt += `\n\n已连接的 MCP 服务器工具也会在响应中提供。`;
  }

  if (deepThink) {
    prompt += `\n\n【深度思考模式已启用】
你需要在回答前进行深入的逐步推理。请遵循以下流程：
1. 分析用户问题的核心需求和难点
2. 拆解问题为多个子问题
3. 针对每个子问题，检索相关知识和示例
4. 逐步推理，确保每一步的逻辑严密
5. 最后给出全面、结构化的最终答案

在最终答案前，用 "--- 深度思考过程 ---" 和 "--- 最终答案 ---" 分隔。`;
  }

  return prompt;
}

function buildApiMessages(messages: { role: string; content: string }[], config: AIConfig, deepThink?: boolean) {
  const systemMsg = { role: "system" as const, content: buildSystemPrompt(deepThink) };
  return [systemMsg, ...messages.slice(-config.context_length * 2)].map((m) => ({
    role: m.role === "system" ? "system" as const : m.role === "user" ? "user" as const : "assistant" as const,
    content: m.content,
  }));
}

async function streamApiCall(
  apiMessages: { role: string; content: string }[],
  config: AIConfig,
  tools: ToolDefinition[],
  signal?: AbortSignal,
): Promise<Response> {
  const body: Record<string, any> = {
    model: config.model,
    messages: apiMessages,
    temperature: config.temperature,
    max_tokens: config.max_tokens,
    stream: true,
  };

  if (tools.length > 0) {
    body.tools = tools.map((t) => ({
      type: "function",
      function: {
        name: t.name,
        description: t.description,
        parameters: t.inputSchema,
      },
    }));
  }

  return fetch(`${config.base_url}/chat/completions`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${config.api_key}`,
    },
    body: JSON.stringify(body),
    signal,
  });
}

function getDefaultTools(): ToolDefinition[] {
  return [
    {
      name: "knowledge_search",
      description: "检索 Godot 知识库（先用中文关键词，换英文再试）",
      inputSchema: {
        type: "object",
        properties: {
          query: { type: "string", description: "搜索关键词" },
        },
        required: ["query"],
      },
    },
    {
      name: "web_search",
      description: "搜索网络获取最新信息",
      inputSchema: {
        type: "object",
        properties: {
          query: { type: "string", description: "搜索查询" },
        },
        required: ["query"],
      },
    },
    {
      name: "image_search",
      description: "搜索在线图片",
      inputSchema: {
        type: "object",
        properties: {
          query: { type: "string", description: "图片搜索关键词" },
        },
        required: ["query"],
      },
    },
    {
      name: "local_image_search",
      description: "搜索本地图片库中的图片",
      inputSchema: {
        type: "object",
        properties: {
          query: { type: "string", description: "搜索关键词" },
          limit: { type: "number", description: "返回数量" },
        },
        required: ["query"],
      },
    },
    {
      name: "knowledge_read",
      description: "读取知识库中某个文件的完整内容（需先通过 knowledge_search 获取 file_path）",
      inputSchema: {
        type: "object",
        properties: {
          file_path: { type: "string", description: "文件路径（来自 knowledge_search 返回结果的 path 字段）" },
        },
        required: ["file_path"],
      },
    },
    {
      name: "knowledge_categories",
      description: "查看知识库中有哪些分类和文件数量",
      inputSchema: {
        type: "object",
        properties: {},
      },
    },
  ];
}

async function getMCPTools(): Promise<ToolDefinition[]> {
  const settings = useSettingsStore.getState().settings;
  const mcpConfigs = settings.mcp_servers || [];
  const tools: ToolDefinition[] = [];

  for (const cfg of mcpConfigs) {
    if (!cfg.auto_connect) continue;
    try {
      const serverTools = mcpManager.listTools(cfg.id);
      for (const t of serverTools) {
        tools.push({
          name: `mcp_${cfg.id}_${t.name}`,
          description: `[MCP/${cfg.name}] ${t.description}`,
          inputSchema: t.inputSchema,
        });
      }
    } catch {
      // server not connected, skip
    }
  }

  return tools;
}

async function computeQueryEmbedding(query: string): Promise<number[]> {
  const settings = useSettingsStore.getState().settings;
  if (!settings.enable_semantic_search || !settings.ai.api_key) return [];
  try {
    const resp = await fetch(`${settings.ai.base_url}/embeddings`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${settings.ai.api_key}`,
      },
      body: JSON.stringify({
        input: query,
        model: settings.embedding_model || "text-embedding-3-small",
        encoding_format: "float",
      }),
    });
    if (!resp.ok) return [];
    const data = await resp.json();
    return data.data?.[0]?.embedding || [];
  } catch {
    return [];
  }
}

async function executeToolCall(toolName: string, args: Record<string, any>): Promise<string> {
  if (toolName === "knowledge_search") {
    // Check KB is loaded, auto-load if not
    try {
      const overview = await getIndexOverview();
      if (!overview.loaded) {
        const path = useSettingsStore.getState().settings.knowledge_path;
        if (path) {
          try {
            await loadKnowledgeBase(
              `${path}/godot_index.json`,
              `${path}/godot_chunks.json`,
              path
            );
          } catch {
            return "知识库加载失败，请在设置中检查知识库路径。";
          }
        } else {
          return "知识库未配置，请在设置中选择知识库路径。";
        }
      }
    } catch {
      const path = useSettingsStore.getState().settings.knowledge_path;
      if (path) {
        try {
          await loadKnowledgeBase(
            `${path}/godot_index.json`,
            `${path}/godot_chunks.json`,
            path
          );
        } catch {
          return "知识库加载失败，请在设置中检查知识库路径。";
        }
      } else {
        return "知识库未配置，请在设置中选择知识库路径。";
      }
    }

    // Guard: already searched and found nothing
    if (kbSearchDone) {
      return "【已检索过，知识库中无相关内容】请停止搜索，直接回复用户。";
    }
    const settings = useSettingsStore.getState().settings;
    if (settings.enable_semantic_search) {
      const queryVec = await computeQueryEmbedding(args.query || "");
      if (queryVec.length > 0) {
        const results = await searchKnowledgeHybrid(
          args.query || "", queryVec
        );
        if (results.length === 0) { kbSearchDone = true; return "【检索完成，知识库中无相关内容】请停止搜索，直接回复用户：知识库中没有找到相关信息。"; }
        return formatKnowledgeResults(results);
      }
    }
    const results = await useChatStore.getState().searchKnowledgeBase(
      args.query || ""
    );
    if (results.length === 0) { kbSearchDone = true; return "【检索完成，知识库中无相关内容】请停止搜索，直接回复用户：知识库中没有找到相关信息。"; }
    return formatKnowledgeResults(results);
  }

  if (toolName === "web_search") {
    if (!useSettingsStore.getState().settings.enable_web_search) {
      return "网络搜索已禁用，请在设置中启用。";
    }
    const results = await webSearch(args.query || "");
    return formatWebResults(results);
  }

  if (toolName === "image_search") {
    if (!useSettingsStore.getState().settings.enable_image_search) {
      return "图片搜索已禁用，请在设置中启用。";
    }
    const images = await imageSearch(args.query || "");
    if (images.length === 0) return "未找到相关图片。";
    return images.map((img) => `![${img.description}](${img.url})`).join("\n\n");
  }

  if (toolName === "local_image_search") {
    const images = await localImageSearch(args.query || "", args.limit || 10);
    if (images.length === 0) return "本地图片库中未找到匹配图片。";
    return images.map((img) => `![${img.name}](${img.url})\n- 路径: ${img.path}\n- 标签: ${img.tags.join(", ")}`).join("\n\n");
  }

  if (toolName === "knowledge_read") {
    const filePath = args.file_path || "";
    if (!filePath) return "缺少 file_path 参数。";
    try {
      const content = await getFileContent(filePath);
      const maxLen = 50000;
      return content.length > maxLen
        ? content.slice(0, maxLen) + `\n\n...（文件过长，仅显示前 ${maxLen} 字符）`
        : content;
    } catch (e: any) {
      return `读取文件失败: ${e.message || e}`;
    }
  }

  if (toolName === "knowledge_categories") {
    try {
      const overview = await getIndexOverview();
      let output = "## 知识库分类概览\n\n";
      output += `共 ${overview.total_files} 个文件\n\n`;
      output += "### 分类\n";
      for (const cat of overview.categories) {
        output += `- ${cat.name}: ${cat.count} 个文件\n`;
      }
      output += "\n### 难度分布\n";
      for (const d of overview.difficulties) {
        output += `- ${d.name}: ${d.count} 个文件\n`;
      }
      return output;
    } catch (e: any) {
      return `获取知识库分类失败: ${e.message || e}`;
    }
  }

  if (toolName.startsWith("mcp_")) {
    const parts = toolName.split("_");
    const serverId = parts[1];
    const mcpToolName = parts.slice(2).join("_");
    try {
      return await mcpManager.callTool(serverId, mcpToolName, args);
    } catch (e: any) {
      return `MCP 工具调用失败: ${e.message || e}`;
    }
  }

  return `未知工具: ${toolName}`;
}

function countTokens(text: string): number {
  return Math.ceil(text.length / 4);
}

export interface ToolCallEvent {
  name: string;
  status: "running" | "done" | "error";
  arguments?: Record<string, any>;
  result?: string;
  error?: string;
}

export async function* streamChat(
  messages: { role: string; content: string }[],
  config: AIConfig,
  options?: { onToolCall?: (event: ToolCallEvent) => void; deepThink?: boolean; searchEnabled?: boolean }
): AsyncGenerator<string> {
  kbSearchDone = false; // Reset per-stream
  const maxRounds = useSettingsStore.getState().settings.max_tool_rounds || 10;
  const settings = useSettingsStore.getState().settings;
  const searchEnabled = options?.searchEnabled ?? true;
  const deepThink = options?.deepThink ?? false;

  let defaultTools = getDefaultTools();
  if (!searchEnabled) {
    defaultTools = defaultTools.filter((t) =>
      t.name === "knowledge_search" || t.name.startsWith("mcp_")
    );
  }
  // Also respect global settings
  if (!settings.enable_web_search) {
    defaultTools = defaultTools.filter((t) => t.name !== "web_search" && t.name !== "image_search");
  }
  if (!settings.enable_image_search) {
    defaultTools = defaultTools.filter((t) => t.name !== "image_search");
  }

  const allTools = [...defaultTools, ...(await getMCPTools())];
  let currentMessages = [...messages];
  let round = 0;

  while (round < maxRounds) {
    round++;
    const apiMessages = buildApiMessages(currentMessages, config, deepThink);

    const ac = new AbortController();
    let timeoutId: ReturnType<typeof setTimeout> = setTimeout(() => {}, 0);
    const startTimeout = () => {
      clearTimeout(timeoutId);
      timeoutId = setTimeout(() => ac.abort(), 90000);
    };
    startTimeout();

    let response: Response;
    try {
      response = await streamApiCall(apiMessages, config, allTools, ac.signal);
    } catch (e: any) {
      clearTimeout(timeoutId);
      if (e.name === "AbortError") throw new Error("AI API 请求超时 (90s)");
      throw e;
    }

    if (!response.ok) {
      clearTimeout(timeoutId);
      const err = await response.text();
      throw new Error(`AI API 错误 (${response.status}): ${err}`);
    }

    const reader = response.body?.getReader();
    if (!reader) { clearTimeout(timeoutId); throw new Error("无法读取响应流"); }

    let fullContent = "";
    let toolCalls: { name: string; arguments: Record<string, any>; id?: string }[] = [];
    let currentTool: { name: string; args: string; id: string } | null = null;
    const decoder = new TextDecoder();
    let buffer = "";
    let gotData = false;

    try {
      while (true) {
        const readPromise = reader.read();
        const timeoutPromise = new Promise<never>((_, reject) => {
          setTimeout(() => reject(new Error("流式响应超时 (30s 无数据)")), 30000);
        });
        const result = await Promise.race([readPromise, timeoutPromise]);
        startTimeout();

        const { done, value } = result;
        if (done) break;
        if (!value) continue;

        gotData = true;

        buffer += decoder.decode(value, { stream: true });
        const lines = buffer.split("\n");
        buffer = lines.pop() || "";

        for (const line of lines) {
          const trimmed = line.trim();
          if (!trimmed || trimmed === "data: [DONE]") continue;
          if (!trimmed.startsWith("data: ")) continue;

          try {
            const json = JSON.parse(trimmed.slice(6));
            const delta = json.choices?.[0]?.delta;

            if (delta?.content) {
              fullContent += delta.content;
              yield delta.content;
            }

            if (delta?.tool_calls) {
              for (const tc of delta.tool_calls) {
                if (tc.function?.name) {
                  currentTool = { name: tc.function.name, args: "", id: tc.id };
                  toolCalls.push({ name: tc.function.name, arguments: {}, id: tc.id });
                  options?.onToolCall?.({ name: tc.function.name, status: "running" });
                }
                if (currentTool && tc.function?.arguments) {
                  currentTool.args += tc.function.arguments;
                }
              }
            }

            const finishReason = json.choices?.[0]?.finish_reason;
            if (finishReason === "tool_calls") break;
          } catch { }
        }
      }
    } finally {
      clearTimeout(timeoutId);
    }

    if (!gotData) throw new Error("AI 返回了空响应");

    if (currentTool) {
      for (const tc of toolCalls) {
        try {
          tc.arguments = JSON.parse(currentTool.args);
        } catch {
          tc.arguments = { raw: currentTool.args };
        }
      }
    }

    if (toolCalls.length === 0) {
      return;
    }

    currentMessages.push({ role: "assistant", content: fullContent || "" });

    for (const tc of toolCalls) {
      options?.onToolCall?.({ name: tc.name, status: "running", arguments: tc.arguments });
      try {
        const result = await executeToolCall(tc.name, tc.arguments);
        currentMessages.push({ role: "tool", content: result });
        options?.onToolCall?.({ name: tc.name, status: "done", arguments: tc.arguments, result });
      } catch (e: any) {
        currentMessages.push({ role: "tool", content: `错误: ${e.message}` });
        options?.onToolCall?.({ name: tc.name, status: "error", arguments: tc.arguments, error: e.message });
      }
    }
  }

  if (round >= maxRounds) {
    yield `\n\n> ⚠️ 已达到最大工具调用轮次 (${maxRounds})，已自动终止。`;
  }
}

export { executeToolCall };

function formatKnowledgeResults(results: any[]): string {
  let output = "## 知识库检索结果\n\n";
  for (const r of results.slice(0, 5)) {
    output += `### ${r.title}\n`;
    output += `- 路径: ${r.path}\n`;
    output += `- 文件路径: ${r.path}\n`;
    output += `- 分类: ${r.category.join(", ")} | 难度: ${r.difficulty}\n`;
    output += `- 相似度: ${(r.score * 10).toFixed(1)}%\n`;
    output += `- 摘要: ${r.summary.slice(0, 150)}...\n\n`;
    if (r.chunks.length > 0) {
      for (const chunk of r.chunks.slice(0, 2)) {
        output += `> **块 ${chunk.chunk_id}**: ${chunk.summary}\n`;
        output += `> ${chunk.chunk_text.slice(0, 300)}\n\n`;
      }
    }
  }
  return output;
}

function formatWebResults(results: any[]): string {
  if (results.length === 0) return "网络搜索未找到结果。";
  let output = "## 网络搜索结果\n\n";
  for (const r of results.slice(0, 5)) {
    output += `### [${r.title}](${r.url})\n`;
    if (r.snippet) output += `${r.snippet}\n\n`;
  }
  return output;
}
