import { invoke } from "@tauri-apps/api/core";
import type { MCPServerConfig, MCPTool } from "../types";

interface MCPServerInfo {
  id: string;
  connected: boolean;
  tools: MCPTool[];
}

class MCPManager {
  private servers: Map<string, MCPServerInfo> = new Map();

  getServer(id: string): MCPServerInfo | undefined {
    return this.servers.get(id);
  }

  listTools(serverId: string): MCPTool[] {
    return this.servers.get(serverId)?.tools || [];
  }

  async connect(config: MCPServerConfig): Promise<MCPServerInfo> {
    this.servers.set(config.id, { id: config.id, connected: false, tools: [] });

    const info = await invoke<MCPServerInfo>("connect_mcp", { config });
    this.servers.set(config.id, info);
    return info;
  }

  async disconnect(serverId: string): Promise<void> {
    await invoke("disconnect_mcp", { serverId });
    this.servers.delete(serverId);
  }

  async callTool(serverId: string, toolName: string, args: Record<string, any>): Promise<string> {
    return await invoke<string>("call_mcp_tool", {
      serverId,
      toolName,
      arguments: args,
    });
  }

  async refreshTools(serverId: string): Promise<MCPTool[]> {
    const tools = await invoke<MCPTool[]>("list_mcp_tools", { serverId });
    const existing = this.servers.get(serverId);
    if (existing) {
      this.servers.set(serverId, { ...existing, tools });
    }
    return tools;
  }

  getAllConnectedTools(): { serverId: string; serverName: string; tools: MCPTool[] }[] {
    const result: { serverId: string; serverName: string; tools: MCPTool[] }[] = [];
    for (const [id, info] of this.servers) {
      if (info.connected && info.tools.length > 0) {
        result.push({ serverId: id, serverName: id, tools: info.tools });
      }
    }
    return result;
  }
}

export const mcpManager = new MCPManager();
