import { Store } from "@tauri-apps/plugin-store";
import type { Conversation } from "../types";

const STORE_FILE = "conversations.json";
let store: Store | null = null;

async function getStore(): Promise<Store> {
  if (!store) {
    store = await Store.load(STORE_FILE);
  }
  return store;
}

export async function saveConversations(conversations: Conversation[]): Promise<void> {
  try {
    const s = await getStore();
    await s.set("conversations", conversations);
    await s.save();
  } catch (e) {
    console.error("Failed to save conversations:", e);
  }
}

export async function loadConversations(): Promise<Conversation[]> {
  try {
    const s = await getStore();
    const data = await s.get<Conversation[]>("conversations");
    return data || [];
  } catch (e) {
    console.error("Failed to load conversations:", e);
    return [];
  }
}

export async function clearSavedConversations(): Promise<void> {
  try {
    const s = await getStore();
    await s.set("conversations", []);
    await s.save();
  } catch (e) {
    console.error("Failed to clear conversations:", e);
  }
}
