import { downloadImageAsDataUrl } from "./image";

const DUCKDUCKGO_URL = "https://api.duckduckgo.com/";
const PEXELS_API = "https://api.pexels.com/v1/search";

interface WebResult {
  title: string;
  url: string;
  snippet: string;
}

interface ImageResult {
  url: string;
  description: string;
  dataUrl?: string;
}

export async function webSearch(query: string): Promise<WebResult[]> {
  try {
    const params = new URLSearchParams({
      q: query,
      format: "json",
      no_html: "1",
      skip_disambig: "1",
    });

    const response = await fetch(`${DUCKDUCKGO_URL}?${params}`);
    if (!response.ok) return [];

    const data = await response.json();
    const results: WebResult[] = [];

    if (data.AbstractText) {
      results.push({ title: data.Heading || query, url: data.AbstractURL || "", snippet: data.AbstractText });
    }

    if (data.RelatedTopics) {
      for (const topic of data.RelatedTopics.slice(0, 8)) {
        if (topic.Text) {
          results.push({
            title: topic.Text.split(" - ")[0] || topic.Text,
            url: topic.FirstURL || "",
            snippet: topic.Text,
          });
        }
        if (topic.Topics) {
          for (const sub of topic.Topics.slice(0, 3)) {
            if (sub.Text) {
              results.push({
                title: sub.Text.split(" - ")[0] || sub.Text,
                url: sub.FirstURL || "",
                snippet: sub.Text,
              });
            }
          }
        }
      }
    }

    return results;
  } catch (e) {
    console.error("Web search failed:", e);
    return [];
  }
}

export async function imageSearch(query: string): Promise<ImageResult[]> {
  try {
    const response = await fetch(`${PEXELS_API}?query=${encodeURIComponent(query)}&per_page=5`, {
      headers: {
        Authorization: "H7jTChw3ldrE6l7SBEBh3zAWGBXl8FQXQlZx5aNZpqVGGGJwYJhpXbPc",
      },
    });

    if (!response.ok) return [];

    const data = await response.json();
    const images: ImageResult[] = [];

    for (const p of data.photos || []) {
      const url = p.src?.medium || p.src?.original;
      let dataUrl = "";
      try {
        dataUrl = await downloadImageAsDataUrl(url);
      } catch {
        dataUrl = url;
      }
      images.push({
        url: dataUrl,
        description: p.alt || query,
      });
    }

    return images;
  } catch (e) {
    console.error("Image search failed:", e);
    return [];
  }
}
