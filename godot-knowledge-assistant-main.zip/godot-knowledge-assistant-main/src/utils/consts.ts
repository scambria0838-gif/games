import type { AppSettings } from "../types";

export const DEFAULT_SETTINGS: AppSettings = {
  ai: {
    provider: "openai",
    api_key: "",
    base_url: "https://api.openai.com/v1",
    model: "gpt-4o-mini",
    temperature: 0.7,
    max_tokens: 4096,
    context_length: 10,
  },
  theme: "system",
  knowledge_path: "",
  enable_web_search: true,
  enable_image_search: true,
  local_image_path: "",
  mcp_servers: [],
  skill_paths: [],
  max_tool_rounds: 10,
  enable_semantic_search: false,
  embedding_model: "text-embedding-3-small",
};

export const PROVIDER_CONFIGS = {
  openai: { base_url: "https://api.openai.com/v1", models: ["gpt-4o", "gpt-4o-mini", "gpt-4-turbo"] },
  deepseek: { base_url: "https://api.deepseek.com", models: ["deepseek-chat", "deepseek-coder"] },
  ollama: { base_url: "http://localhost:11434/v1", models: [] },
  custom: { base_url: "", models: [] },
} as const;

export const CATEGORY_OPTIONS = [
  "基础", "脚本", "场景", "动画", "物理", "多人游戏",
  "性能优化", "UI", "输入控制", "资源管理", "调试", "信号",
  "自定义节点", "导出", "插件开发", "3D", "2D", "着色器",
];

export const DIFFICULTY_OPTIONS = ["初级", "中级", "高级"];

export const DB_NAME = "godot_assistant.db";
export const STORE_NAME = "settings.json";
