import React, { useEffect, useState } from "react";
import { ConfigProvider, Layout, theme as antTheme, App as AntApp } from "antd";
import zhCN from "antd/locale/zh_CN";
import AppLayout from "./components/Layout/AppLayout";
import { useSettingsStore } from "./stores/settingsStore";

const App: React.FC = () => {
  const { settings, initialized, load } = useSettingsStore();
  const [ready, setReady] = useState(false);

  useEffect(() => {
    load().finally(() => setReady(true));
  }, []);

  if (!ready) return null;

  const isDark = settings.theme === "dark" ||
    (settings.theme === "system" && window.matchMedia("(prefers-color-scheme: dark)").matches);

  return (
    <ConfigProvider
      locale={zhCN}
      theme={{
        algorithm: isDark ? antTheme.darkAlgorithm : antTheme.defaultAlgorithm,
        token: {
          colorPrimary: "#4A6CF7",
          borderRadius: 8,
          fontFamily: "-apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Noto Sans SC', sans-serif",
        },
      }}
    >
      <AntApp>
        <AppLayout />
      </AntApp>
    </ConfigProvider>
  );
};

export default App;
