const fs = require('fs');
const path = require('path');

const filePath = path.join(__dirname, '..', 'src', 'services', 'ai.ts');
let content = fs.readFileSync(filePath, 'utf-8');

// Replace buildSystemPrompt function
const oldFunc = `function buildSystemPrompt(deepThink?: boolean, mode?: string): string {
  const settings = useSettingsStore.getState().settings;
  let prompt = \`你是一位精通 Godot 引擎的资深游戏开发专家。你正在帮助用户学习 Godot 游戏开发。`;

const newFunc = `function buildSystemPrompt(deepThink?: boolean, mode?: string): string {
  const settings = useSettingsStore.getState().settings;

  if (mode === "programming") {
    let p = \`你是一位资深 Godot 游戏开发程序员。帮助用户编写和调试 Godot 项目代码。

## 回答规范
1. 直接给出可运行代码，用 Markdown 代码块
2. 优先使用 MCP 工具操作编辑器或项目
3. 用 knowledge_search 获取知识库示例

## 可用工具
- knowledge_search(query): 检索知识库
- MCP 工具（如已连接）: 操作 Godot 编辑器\`;
    if (settings.mcp_servers?.length) p += \`\\n\\n已连接的 MCP 服务器工具也会在响应中提供。\`;
    if (deepThink) p += \`\\n\\n【深度思考模式】在最终答案前用分隔符分隔。\`;
    return p;
  }

  let prompt = \`你是一位精通 Godot 引擎的资深游戏开发专家。你正在帮助用户学习 Godot 游戏开发。`;

if (content.includes(oldFunc)) {
  content = content.replace(oldFunc, newFunc);
  fs.writeFileSync(filePath, content, 'utf-8');
  console.log('Replaced successfully');
} else {
  console.log('OLD TEXT NOT FOUND');
  // Print the surrounding context
  const idx = content.indexOf('buildSystemPrompt');
  if (idx >= 0) {
    console.log('Found at', idx);
    console.log(content.substring(idx, idx + 300));
  }
}
