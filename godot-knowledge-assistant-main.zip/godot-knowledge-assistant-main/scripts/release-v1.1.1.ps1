param($Token)
$tag = "v1.1.1"
$bodyStr = '{"tag_name":"v1.1.1","target_commitish":"main","name":"v1.1.1","body":"## 修复内容\n\n### 关键 Bug 修复\n- AI 搜索无效 category 过滤导致知识库无结果的问题\n- AI 传入 category: Godot（该分类不存在），过滤掉所有结果\n- 修复后：无效分类/难度自动忽略，确保搜索结果正常返回\n\n### 改进\n- 工具定义新增有效 category 枚举值列表（20 种分类）\n- AI 搜索前先校验分类是否有效，无效则跳过\n\n### 技术\n- Rust 后端：categories/difficulty 不存在时自动跳过过滤\n- 前端：工具描述标注全部有效分类值，减少 AI 猜测错误"}'

$result = Invoke-RestMethod -Uri "https://api.github.com/repos/qingshanjiluo/godot-knowledge-assistant/releases" -Method Post -Headers @{
    "Authorization" = "Bearer $Token"
    "Accept" = "application/vnd.github+json"
    "User-Agent" = "godot-assistant"
} -Body $bodyStr -ContentType "application/json"

Write-Host "Release: $($result.html_url)"

$installer = "G:\皮皮\godot教师\godot-knowledge-assistant\src-tauri\target\release\bundle\nsis\Godot 知识助手_1.0.0_x64-setup.exe"
$uploadUrl = "https://uploads.github.com/repos/qingshanjiluo/godot-knowledge-assistant/releases/$($result.id)/assets?name=Godot_Knowledge_Assistant_1.1.1_x64-setup.exe"
$fileBytes = [System.IO.File]::ReadAllBytes($installer)
$resp = Invoke-RestMethod -Uri $uploadUrl -Method Post -Headers @{
    "Authorization" = "Bearer $Token"
    "Accept" = "application/vnd.github+json"
    "Content-Type" = "application/x-msdownload"
    "User-Agent" = "godot-assistant"
} -Body $fileBytes

Write-Host "Uploaded: $($resp.name) ($($resp.size) bytes)"
