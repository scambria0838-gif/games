param(
    [string]$OutputDir = "G:\皮皮\godot教师\godot_qa",
    [int]$MaxQuestions = 500
)

Write-Host "Downloading Godot Stack Overflow Q&A..." -ForegroundColor Cyan

New-Item -ItemType Directory -Path $OutputDir -Force | Out-Null
$fileCount = 0

# Use Stack Exchange API to get Godot questions
$apiUrl = "https://api.stackexchange.com/2.3/questions?order=desc&sort=votes&tagged=godot&site=stackoverflow&pagesize=100&filter=withbody"

$page = 1
$totalQuestions = 0

while ($totalQuestions -lt $MaxQuestions) {
    $url = "$apiUrl&page=$page"
    Write-Host "  Fetching page $page..." -ForegroundColor Gray
    
    try {
        $response = Invoke-RestMethod -Uri $url -UseBasicParsing
    } catch {
        Write-Host "  API error on page $page, stopping." -ForegroundColor Yellow
        break
    }
    
    if (-not $response.items -or $response.items.Count -eq 0) {
        Write-Host "  No more questions found." -ForegroundColor Yellow
        break
    }
    
    foreach ($q in $response.items) {
        $title = $q.title
        $body = $q.body -replace '<[^>]+>', ''  # Strip HTML
        $body = $body -replace '&lt;', '<'
        $body = $body -replace '&gt;', '>'
        $body = $body -replace '&amp;', '&'
        $body = $body -replace '&quot;', '"'
        $body = $body -replace '&#39;', "'"
        $score = $q.score
        $answerCount = $q.answer_count
        $tags = ($q.tags -join ', ')
        $link = $q.link
        
        $content = @()
        $content += "# Godot Q&A: $title"
        $content += "# Score: $score | Answers: $answerCount"
        $content += "# Tags: $tags"
        $content += "# Link: $link"
        $content += ""
        $content += $body.Trim()
        
        # Get top answer if available
        if ($q.accepted_answer_id) {
            try {
                $ansUrl = "https://api.stackexchange.com/2.3/questions/$($q.question_id)/answers?order=desc&sort=votes&site=stackoverflow&filter=withbody"
                $ansResp = Invoke-RestMethod -Uri $ansUrl -UseBasicParsing
                if ($ansResp.items -and $ansResp.items.Count -gt 0) {
                    $bestAnswer = $ansResp.items[0]
                    $ansBody = $bestAnswer.body -replace '<[^>]+>', ''
                    $ansBody = $ansBody -replace '&lt;', '<'
                    $ansBody = $ansBody -replace '&gt;', '>'
                    $ansBody = $ansBody -replace '&amp;', '&'
                    $ansBody = $ansBody -replace '&quot;', '"'
                    $ansBody = $ansBody -replace '&#39;', "'"
                    
                    $content += ""
                    $content += "=== 最佳答案 === (Score: $($bestAnswer.score))"
                    $content += ""
                    $content += $ansBody.Trim()
                }
            } catch {
                # Skip if answer fetch fails
            }
        }
        
        # Sanitize filename
        $safeName = ($title -replace '[\\/:*?"<>|]', '_') -replace '\s+', ' '
        if ($safeName.Length -gt 100) { $safeName = $safeName.Substring(0, 100) }
        
        $txtPath = "$OutputDir\qa_$($fileCount)_$safeName.txt"
        $content -join "`n" | Out-File -FilePath $txtPath -Encoding utf8
        $fileCount++
        $totalQuestions++
        
        if ($totalQuestions % 50 -eq 0) {
            Write-Host "  Downloaded $totalQuestions questions..." -ForegroundColor Gray
        }
    }
    
    if ($response.has_more -eq $false) { break }
    $page++
    Start-Sleep -Milliseconds 200  # Rate limit
}

Write-Host "Downloaded $fileCount Q&A entries to $OutputDir" -ForegroundColor Green
