import sharp from 'sharp';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const projectRoot = path.resolve(__dirname, '..');
const iconsDir = path.join(projectRoot, 'src-tauri', 'icons');
const svgPath = path.join(projectRoot, 'icon-master.svg');

const svgBuffer = fs.readFileSync(svgPath);

const sizes = [
  { name: '32x32.png', size: 32 },
  { name: '128x128.png', size: 128 },
  { name: '128x128@2x.png', size: 256 },
];

async function generate() {
  for (const { name, size } of sizes) {
    const outPath = path.join(iconsDir, name);
    await sharp(svgBuffer)
      .resize(size, size)
      .png({ palette: true, colors: 256 })
      .toFile(outPath);
    const stat = fs.statSync(outPath);
    console.log(`${name} -> ${size}x${size} (${(stat.size / 1024).toFixed(1)}KB)`);
  }

  // Generate ICO: use 32x32 PNG wrapped in ICO format
  // Sharp cannot directly produce ICO, so we create a 32x32 PNG and
  // build a minimal ICO manually (Windows accepts PNG-based ICO)
  const png32 = await sharp(svgBuffer)
    .resize(32, 32)
    .png()
    .toBuffer();

  const icoPath = path.join(iconsDir, 'icon.ico');
  // ICO header: reserved(2) + type=1(2) + count=1(2) = 6 bytes
  // Directory entry: w=32(1) + h=32(1) + colors=0(1) + reserved(1) + planes=1(2) + bpp=32(2) + size(4) + offset(4) = 16 bytes
  const header = Buffer.alloc(6);
  header.writeUInt16LE(0, 0);  // reserved
  header.writeUInt16LE(1, 2);  // type: ICO
  header.writeUInt16LE(1, 4);  // count: 1

  const dirEntry = Buffer.alloc(16);
  dirEntry.writeUInt8(32, 0);   // width
  dirEntry.writeUInt8(32, 1);   // height
  dirEntry.writeUInt8(0, 2);    // colors
  dirEntry.writeUInt8(0, 3);    // reserved
  dirEntry.writeUInt16LE(1, 4); // planes
  dirEntry.writeUInt16LE(32, 6);// bpp
  dirEntry.writeUInt32LE(png32.length, 8);  // size
  dirEntry.writeUInt32LE(22, 12);           // offset (6 + 16 = 22)

  const icoBuffer = Buffer.concat([header, dirEntry, png32]);
  fs.writeFileSync(icoPath, icoBuffer);
  const icoStat = fs.statSync(icoPath);
  console.log(`icon.ico (${(icoStat.size / 1024).toFixed(1)}KB)`);

  // Also generate a high-res icon.icns placeholder (just copy PNG for non-macOS)
  const icnsPath = path.join(iconsDir, 'icon.icns');
  const png256 = await sharp(svgBuffer)
    .resize(256, 256)
    .png()
    .toBuffer();
  fs.writeFileSync(icnsPath, png256);
  console.log(`icon.icns (${(png256.length / 1024).toFixed(1)}KB)`);
}

generate().catch(err => { console.error(err); process.exit(1); });
