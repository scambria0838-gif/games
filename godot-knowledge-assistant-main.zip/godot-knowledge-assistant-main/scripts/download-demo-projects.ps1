param(
    [string]$OutputDir = "G:\皮皮\godot教师\godot_demo_projects"
)

Write-Host "Downloading Godot Demo Projects..." -ForegroundColor Cyan

$repoUrl = "https://github.com/godotengine/godot-demo-projects/archive/refs/heads/master.zip"
$zipPath = "$env:TEMP\godot-demos.zip"
$extractPath = "$env:TEMP\godot-demos-extract"

# Clean up any previous extraction
if (Test-Path $extractPath) { Remove-Item -Recurse -Force $extractPath }
if (Test-Path $OutputDir) { Remove-Item -Recurse -Force $OutputDir }

Write-Host "Downloading from $repoUrl ..."
try {
    Invoke-WebRequest -Uri $repoUrl -OutFile $zipPath -UseBasicParsing
} catch {
    # Try git clone as fallback
    Write-Host "Download failed, trying git clone..." -ForegroundColor Yellow
    git clone --depth 1 https://github.com/godotengine/godot-demo-projects.git $extractPath
    if ($LASTEXITCODE -ne 0) {
        Write-Error "Failed to download demo projects"
        exit 1
    }
    $extractPath = "$extractPath/godot-demo-projects"
    goto :extract
}

Write-Host "Extracting..." -ForegroundColor Cyan
Expand-Archive -Path $zipPath -DestinationPath $extractPath -Force
$extractPath = "$extractPath\godot-demo-projects-master"

:extract
New-Item -ItemType Directory -Path $OutputDir -Force | Out-Null

Write-Host "Extracting GDScript comments and structure..." -ForegroundColor Cyan
$fileCount = 0

Get-ChildItem -Path $extractPath -Recurse -Filter "*.gd" | ForEach-Object {
    $gdFile = $_.FullName
    $relativePath = $_.FullName.Substring($extractPath.Length).TrimStart('\')
    
    # Read GDScript file
    $content = Get-Content $gdFile -Raw -ErrorAction SilentlyContinue
    if (-not $content) { return }

    # Extract meaningful content: comments (starting with #) and function signatures
    $lines = $content -split "`n"
    $output = @()
    $output += "# Source: $relativePath"
    $output += "# File: $($_.Name)"
    $output += ""

    $inComment = $false
    foreach ($line in $lines) {
        $trimmed = $line.Trim()
        
        # Docstring comments (## or # with multiple words)
        if ($trimmed.StartsWith('##') -or $trimmed.StartsWith('# =') -or $trimmed.StartsWith('# -')) {
            $output += $trimmed
            $inComment = $true
            continue
        }
        
        # Regular comments (meaningful ones, 3+ words)
        if ($trimmed.StartsWith('#') -and ($trimmed -split '\s').Count -ge 3) {
            $output += $trimmed
            continue
        }
        
        # Function/class/signal definitions
        if ($trimmed -match '^(func |signal |class_name |extends |enum |const |var |static func )') {
            if ($inComment -eq $false -and $output.Count -gt 0 -and $output[-1] -ne '') {
                $output += ""
            }
            $output += $trimmed
            $inComment = $false
            continue
        }
        
        $inComment = $false
    }

    if ($output.Count -gt 2) {
        $txtPath = "$OutputDir\$($_.BaseName)_$($fileCount).txt"
        $output -join "`n" | Out-File -FilePath $txtPath -Encoding utf8
        $fileCount++
    }
}

# Also extract README and documentation files
Get-ChildItem -Path $extractPath -Recurse -Include "README.md", "*.md", "*.txt" | ForEach-Object {
    $relativePath = $_.FullName.Substring($extractPath.Length).TrimStart('\')
    # Skip LICENSE, CONTRIBUTING, etc.
    if ($_.Name -match 'LICENSE|CONTRIBUTING|CODE_OF_CONDUCT') { return }
    
    $content = Get-Content $_.FullName -Raw -ErrorAction SilentlyContinue
    if (-not $content -or $content.Length -lt 50) { return }
    
    $txtContent = @()
    $txtContent += "# Source: $relativePath"
    $txtContent += ""
    $txtContent += $content
    
    $txtPath = "$OutputDir\$($_.BaseName)_doc_$fileCount.txt"
    $txtContent -join "`n" | Out-File -FilePath $txtPath -Encoding utf8
    $fileCount++
}

Write-Host "Extracted $fileCount files from Godot Demo Projects to $OutputDir" -ForegroundColor Green
Write-Host ""
Write-Host "Deleting temporary files..." -ForegroundColor Gray
Remove-Item -Recurse -Force $extractPath -ErrorAction SilentlyContinue
Remove-Item $zipPath -ErrorAction SilentlyContinue
