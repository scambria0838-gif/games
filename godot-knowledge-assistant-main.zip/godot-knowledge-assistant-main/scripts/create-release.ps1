param(
    [string]$Repo = "qingshanjiluo/godot-knowledge-assistant",
    [string]$Tag = "v1.0.1",
    [string]$Token = ""
)

if (-not $Token) {
    # Try to get token from git credential manager
    try {
        $input = "protocol=https`nhost=github.com`n"
        $credOutput = $input | git credential-manager get 2>$null
        if ($credOutput) {
            $lines = $credOutput -split "`n"
            foreach ($line in $lines) {
                if ($line -match "^password=(.+)") {
                    $Token = $matches[1]
                    break
                }
            }
        }
    } catch { }
}

if (-not $Token) {
    Write-Error "No GitHub token available. Set GITHUB_TOKEN env var or pass -Token parameter."
    exit 1
}

$body = @{
    tag_name = $Tag
    target_commitish = "main"
    name = $Tag
    body = "## 更新内容\n\n### 数据质量修复\n- 清理 1572 个官方文档文件中 16806 处 HTML 残留标签\n- 重新蒸馏知识库：1749 文件、6506 知识块\n- 搜索精度显著提升\n\n### 语义搜索\n- 集成 AI Embedding API 计算知识块向量\n- BM25 + Cosine Similarity 混合排序\n- 设置页新增语义搜索开关和计算嵌入向量按钮\n- 嵌入结果缓存到 godot_embeddings.json\n\n### RAG 流程优化\n- AI 严格遵守 search -> read -> answer 三步流程\n\n### 新工具\n- clean-txt CLI: 批量清理 TXT 文件中 HTML 残留\n- download-demo-projects.ps1: 下载 Godot 官方 Demo 项目\n- download-qa.ps1: 从 Stack Overflow 获取 Godot 问答\n\n### 技术改进\n- 蒸馏 pipeline 增加坏文件跳过和容错处理\n- Rust 嵌入向量模块支持 OpenAI 兼容 API\n- 前端类型和默认配置扩展"
} | ConvertTo-Json -Depth 10

$headers = @{
    "Authorization" = "Bearer $Token"
    "Accept" = "application/vnd.github+json"
    "User-Agent" = "godot-knowledge-assistant-release"
}

try {
    $url = "https://api.github.com/repos/$Repo/releases"
    Write-Host "Creating release at $url ..." -ForegroundColor Cyan
    $response = Invoke-RestMethod -Uri $url -Method Post -Headers $headers -Body $body -ContentType "application/json"
    Write-Host "Release created: $($response.html_url)" -ForegroundColor Green

    # Upload the installer asset
    $installerPath = "G:\皮皮\godot教师\godot-knowledge-assistant\src-tauri\target\release\bundle\nsis\Godot 知识助手_1.0.0_x64-setup.exe"
    if (Test-Path $installerPath) {
        Write-Host "Uploading installer..." -ForegroundColor Cyan
        $uploadUrl = "https://uploads.github.com/repos/$Repo/releases/$($response.id)/assets?name=Godot知识助手_1.0.0_x64-setup.exe"
        $fileBytes = [System.IO.File]::ReadAllBytes($installerPath)
        $fileStream = [System.IO.MemoryStream]::new($fileBytes)
        
        $assetHeaders = @{
            "Authorization" = "Bearer $Token"
            "Accept" = "application/vnd.github+json"
            "Content-Type" = "application/x-msdownload"
            "Content-Length" = $fileBytes.Length
            "User-Agent" = "godot-knowledge-assistant-release"
        }
        
        $assetResponse = Invoke-RestMethod -Uri $uploadUrl -Method Post -Headers $assetHeaders -Body $fileStream
        Write-Host "Asset uploaded: $($assetResponse.name) ($($assetResponse.size) bytes)" -ForegroundColor Green
    } else {
        Write-Host "Installer not found at $installerPath" -ForegroundColor Yellow
    }
} catch {
    Write-Host "Error: $_" -ForegroundColor Red
    if ($_.Exception.Response) {
        $stream = $_.Exception.Response.GetResponseStream()
        $reader = New-Object System.IO.StreamReader($stream)
        Write-Host $reader.ReadToEnd()
    }
    exit 1
}
