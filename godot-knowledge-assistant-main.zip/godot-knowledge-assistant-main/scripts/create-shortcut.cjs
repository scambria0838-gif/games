/**
 * Create desktop shortcut for the built Tauri app.
 * Supports: Windows (.lnk), macOS (.app symlink), Linux (.desktop)
 */
const os = require("os");
const path = require("path");
const fs = require("fs");

const APP_NAME = "Godot 知识助手";
const RELEASE_DIR = path.join(__dirname, "..", "src-tauri", "target", "release");
const BUNDLE_DIR = path.join(RELEASE_DIR, "bundle");

function getDesktopPath() {
  return path.join(os.homedir(), "Desktop");
}

function getExePath() {
  const platform = os.platform();
  if (platform === "win32") {
    // Prefer standalone EXE in release dir
    const exePath = path.join(RELEASE_DIR, "godot-knowledge-assistant.exe");
    if (fs.existsSync(exePath)) return exePath;
    // Fallback: NSIS installer
    const nsisDir = path.join(BUNDLE_DIR, "nsis");
    if (fs.existsSync(nsisDir)) {
      const files = fs.readdirSync(nsisDir).filter(f => f.endsWith(".exe"));
      if (files.length > 0) return path.join(nsisDir, files[0]);
    }
    // Fallback: MSI
    const msiDir = path.join(BUNDLE_DIR, "msi");
    if (fs.existsSync(msiDir)) {
      const files = fs.readdirSync(msiDir).filter(f => f.endsWith(".exe"));
      if (files.length > 0) return path.join(msiDir, files[0]);
    }
  }
  if (platform === "darwin") {
    const dmgDir = path.join(BUNDLE_DIR, "dmg");
    if (fs.existsSync(dmgDir)) {
      const files = fs.readdirSync(dmgDir).filter(f => f.endsWith(".app"));
      if (files.length > 0) return path.join(dmgDir, files[0]);
    }
    const macDir = path.join(BUNDLE_DIR, "macos");
    if (fs.existsSync(macDir)) {
      const files = fs.readdirSync(macDir).filter(f => f.endsWith(".app"));
      if (files.length > 0) return path.join(macDir, files[0]);
    }
  }
  if (platform === "linux") {
    const appImageDir = path.join(BUNDLE_DIR, "appimage");
    if (fs.existsSync(appImageDir)) {
      const files = fs.readdirSync(appImageDir).filter(f => f.endsWith(".AppImage"));
      if (files.length > 0) return path.join(appImageDir, files[0]);
    }
    const debDir = path.join(BUNDLE_DIR, "deb");
    if (fs.existsSync(debDir)) {
      const files = fs.readdirSync(debDir).filter(f => f.endsWith(".deb"));
      if (files.length > 0) return path.join(debDir, files[0]);
    }
  }
  return null;
}

async function createShortcut() {
  const exePath = getExePath();
  if (!exePath) {
    console.log("⚠️  未找到打包后的可执行文件，请先运行 npm run tauri build");
    console.log("   查找路径:", BUNDLE_DIR);
    return;
  }

  const desktopPath = getDesktopPath();
  const platform = os.platform();

  console.log(`平台: ${platform}`);
  console.log(`可执行文件: ${exePath}`);
  console.log(`桌面路径: ${desktopPath}`);

  if (platform === "win32") {
    // Windows: create .lnk shortcut using PowerShell (via temp file to avoid quoting issues)
    const { execSync } = require("child_process");
    const fs2 = require("fs");
    const tmpFile = path.join(os.tmpdir(), "create-shortcut-temp.ps1");
    const psLines = [
      "$ws = New-Object -ComObject WScript.Shell",
      '$sc = $ws.CreateShortcut("' + desktopPath.replace(/\\/g, '\\\\') + '\\\\' + APP_NAME + '.lnk")',
      '$sc.TargetPath = "' + exePath.replace(/\\/g, '\\\\') + '"',
      '$sc.WorkingDirectory = "' + path.dirname(exePath).replace(/\\/g, '\\\\') + '"',
      '$sc.Description = "Godot Knowledge Assistant"',
      "$sc.Save()",
      'Write-Host "Shortcut created on desktop: ' + APP_NAME + '.lnk"',
    ];
    fs2.writeFileSync(tmpFile, psLines.join("\r\n"), "utf-8");
    try {
      execSync('powershell -ExecutionPolicy Bypass -File "' + tmpFile + '"', { stdio: "inherit" });
      console.log("  Desktop shortcut created successfully");
    } catch (e) {
      console.error("Failed to create shortcut:", e.message);
    } finally {
      try { fs2.unlinkSync(tmpFile); } catch {}
    }

  } else if (platform === "darwin") {
    // macOS: create a symlink or .command file
    const shortcutPath = path.join(desktopPath, `${APP_NAME}.command`);
    const appPath = exePath.endsWith(".app") ? exePath : exePath;
    try {
      fs.writeFileSync(shortcutPath, `#!/bin/bash\nopen "${appPath}"\n`);
      fs.chmodSync(shortcutPath, "755");
      console.log(`✅ 启动脚本已创建到桌面: ${shortcutPath}`);
    } catch (e) {
      console.error("创建启动脚本失败:", e.message);
    }

  } else if (platform === "linux") {
    // Linux: create .desktop file
    const desktopEntry = `[Desktop Entry]
Name=${APP_NAME}
Comment=Godot 知识助手 - AI 对话与知识库检索
Exec=${exePath}
Type=Application
Terminal=false
Categories=Development;Education;
`;
    const shortcutPath = path.join(desktopPath, `${APP_NAME}.desktop`);
    try {
      fs.writeFileSync(shortcutPath, desktopEntry);
      fs.chmodSync(shortcutPath, "755");
      console.log(`✅ 快捷方式已创建到桌面: ${shortcutPath}`);
    } catch (e) {
      console.error("创建快捷方式失败:", e.message);
    }
  }

  console.log("\n💡 提示: 运行 npm run build:full 即可在构建后自动创建快捷方式");
}

createShortcut();
