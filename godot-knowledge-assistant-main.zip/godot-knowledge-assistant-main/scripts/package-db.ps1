param(
  [Parameter(Mandatory = $false)]
  [string]$Version = "1.0.0"
)

$ProjectRoot = Split-Path -Parent $PSScriptRoot
$DbDir = Join-Path $ProjectRoot "参考数据库"
$OutFile = Join-Path $ProjectRoot "godot-knowledge-database-v$Version.zip"

if (-not (Test-Path $DbDir)) {
  Write-Error "数据库目录不存在: $DbDir"
  exit 1
}

Write-Host "打包数据库: $DbDir → $OutFile"
Compress-Archive -Path "$DbDir\*" -DestinationPath $OutFile -CompressionLevel Optimal -Force
Write-Host "完成: $( (Get-Item $OutFile).Length / 1MB -as [int] ) MB"
