# UE5Pilot — Windows Quickstart

> Get UE5Pilot running on your Windows PC in 3 minutes.

## Requirements
- Windows 10 or 11
- Unreal Engine 5.x installed
- Python 3.10 or newer
- Your UE5Pilot cloud URL (provided by your vendor)

## Setup

### Step 1: Install Python dependencies
Open Command Prompt:
```cmd
pip install requests
```

### Step 2: Set your cloud URL
```cmd
setx UE5PILOT_CLOUD_URL "https://api.yourbrand.com"
```
(Close and reopen Command Prompt for this to take effect.)

### Step 3: Start the bridge and companion
Open **two** Command Prompt windows. In the first one:
```cmd
cd C:\UE5Pilot
python local_bridge.py
```
You should see: `Local bridge listening on 127.0.0.1:8765`

In the second one:
```cmd
cd C:\UE5Pilot
python companion.py
```
You should see: `Connected to cloud at https://api.yourbrand.com`

### Step 4: Connect Unreal Engine
1. Open your UE5 project
2. Enable Python Editor Script Plugin (Edit → Plugins → search "Python")
3. Restart UE5
4. Open the Python console (Window → Developer Tools → Output Log, switch to Python mode)
5. Paste this command:
```python
exec(open(r"C:\UE5Pilot\ue5_client.py", "r", encoding="utf-8-sig").read())
```

You should see: `UE5Pilot client started, polling bridge...`

### Step 5: Test it
Try sending a test command from your web UI / dashboard, or use the CLI:
```cmd
python ue5pilot_cli.py "make the scene cinematic"
```

## Troubleshooting

**"Connection refused" from companion**
→ Your cloud URL is wrong or unreachable. Test with: `curl YOUR-CLOUD-URL/health`

**"Module 'unreal' not found" in UE5 console**
→ Python plugin isn't enabled in UE5. Go to Edit → Plugins → enable "Python Editor Script Plugin"

**Companion shows "401 Unauthorized"**
→ Server requires API key. Set: `setx UE5PILOT_API_KEY "your-key"`

**Commands hang and never complete**
→ Make sure all 3 components are running: cloud server (vendor side), companion + bridge (your PC), ue5_client.py (inside UE5)
