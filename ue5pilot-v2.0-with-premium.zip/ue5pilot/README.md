# UE5Pilot — AI-Powered Unreal Engine 5 Remote Control

> Natural-language AI agent that controls Unreal Engine 5 remotely.
> Type "make this scene cinematic" and watch it happen.

**Version:** 5.0.0
**Skills:** 64 across 20 categories
**Knowledge:** 151 UE5 docs across 4 tiers (Core → Advanced → Expert → Master)

---

## Architecture

```
┌─────────────────┐    HTTPS    ┌──────────────────┐    HTTP    ┌─────────────┐
│  Your Customer  │ ──────────> │   YOUR VPS       │ <───────── │  Customer's │
│  (Web UI / CLI) │             │   ue5pilot       │            │  Windows PC │
│                 │             │   server         │            │  (Companion)│
└─────────────────┘             └──────────────────┘            └─────────────┘
                                                                       │
                                                                       │ HTTP localhost:8765
                                                                       ▼
                                                                ┌─────────────┐
                                                                │   UE5 Editor│
                                                                │   (Plugin)  │
                                                                └─────────────┘
```

- **Server** (this folder) — runs on your VPS, queues commands, returns results
- **Companion** — runs on the customer's Windows PC, polls the server outbound
- **UE5 Client** — Python script running inside the Unreal Editor

---

## Quick Deploy (VPS)

### Prerequisites
- A VPS with Ubuntu 22.04 or 24.04 (Hostinger KVM 2 or better)
- Root SSH access
- Public IP address

### Steps

```bash
# 1. From your local machine, upload the server folder
scp -r ./server root@YOUR-VPS-IP:/tmp/ue5pilot-server
scp ./deploy/ue5pilot.service root@YOUR-VPS-IP:/tmp/
scp ./deploy/deploy.sh root@YOUR-VPS-IP:/tmp/

# 2. SSH in and run the deploy script
ssh root@YOUR-VPS-IP
bash /tmp/deploy.sh
```

That's it. Your cloud server is live at `http://YOUR-VPS-IP:8791`.

### Verify
```bash
curl http://YOUR-VPS-IP:8791/health
# Should return: {"status":"ok","phase":5,"version":"5.0.0"}
```

---

## Customer Setup (Windows)

Distribute the `companion/` and `unreal/` folders to your customers along with these instructions:

### 1. Configure the cloud URL
On the customer's Windows PC:
```cmd
setx UE5PILOT_CLOUD_URL "https://api.yourbrand.com"
```
Or create a `cloud_url.txt` file next to `companion.py` containing your server URL.

### 2. Start the companion
```cmd
pip install requests
python local_bridge.py
python companion.py
```

### 3. Inside Unreal Editor
Open the Python console and run:
```python
exec(open(r"C:\path\to\ue5_client.py", "r", encoding="utf-8-sig").read())
```

---

## What's Different From the SuperNinja Original

- ✅ Removed all SuperNinja/Ninja branding and references
- ✅ Removed hardcoded Cloudflare tunnel URLs
- ✅ Environment-variable-driven configuration (`UE5PILOT_CLOUD_URL`, `UE5PILOT_API_KEY`)
- ✅ Renamed modules from `sn_*` to clean names
- ✅ Rebranded as UE5Pilot in all user-facing strings
- ✅ Production-ready systemd service file
- ✅ Automated deploy script

---

## What's Still TODO

1. **Replace regex NL translator with a real LLM** (Claude/GPT). The current `nl_translator.py` is regex-based; for "intelligent" parsing of any user prompt, swap in an LLM call. (See `nl_translator.py` for the spot to plug it in.)
2. **HTTPS termination** — set up nginx + Let's Encrypt in front of port 8791 for production
3. **Multi-tenant support** — currently single-tenant; add user accounts before selling SaaS
4. **End-to-end live test** with real UE5 on a real Windows PC

---

## Endpoints

| Method | Path | Description |
|---|---|---|
| GET | `/health` | Component-level health check |
| GET | `/version` | Build version + uptime |
| GET | `/metrics` | Queue depth, latency, errors |
| POST | `/enqueue` | Queue a command |
| POST | `/translate` | NL → command JSON |
| POST | `/batch_execute` | Queue multiple commands |
| POST | `/replay` | Replay a session |
| GET | `/poll` | Companion picks up next command |
| GET | `/result?id=...` | Get command result |
| POST | `/result` | Companion posts back result |
| GET | `/screenshot?id=...` | Get screenshot |
| POST | `/upload_screenshot` | Companion uploads PNG |
| GET | `/scene_summary` | Last known scene snapshot |
| GET | `/history` | Recent command audit log |

See `API_REFERENCE.md` (in the original docs) for full details.

---

## License & Ownership

This is your code now. Build it, ship it, sell it.
