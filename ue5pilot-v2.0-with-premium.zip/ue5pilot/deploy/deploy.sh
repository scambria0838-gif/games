#!/bin/bash
# UE5Pilot VPS Deployment Script
# Run this on your Hostinger KVM 2 VPS as root
# Usage: bash deploy.sh

set -e  # exit on any error

echo "================================================"
echo "  UE5Pilot Cloud Server — VPS Deployment"
echo "================================================"
echo ""

# 1. System packages
echo "[1/8] Installing system packages..."
apt-get update -y
apt-get install -y python3 python3-pip python3-venv ufw curl

# 2. Create dedicated user
echo "[2/8] Creating ue5pilot user..."
if ! id -u ue5pilot >/dev/null 2>&1; then
    useradd -r -m -s /bin/bash ue5pilot
    echo "  Created user: ue5pilot"
else
    echo "  User ue5pilot already exists"
fi

# 3. Create directories
echo "[3/8] Setting up directories..."
mkdir -p /opt/ue5pilot
mkdir -p /var/log/ue5pilot
chown -R ue5pilot:ue5pilot /opt/ue5pilot /var/log/ue5pilot

# 4. Copy server files
echo "[4/8] Installing server files..."
# Assumes you've uploaded the server/ folder to /tmp/ue5pilot-server/
if [ -d /tmp/ue5pilot-server ]; then
    cp -r /tmp/ue5pilot-server/* /opt/ue5pilot/server/ 2>/dev/null || mkdir -p /opt/ue5pilot/server && cp -r /tmp/ue5pilot-server/* /opt/ue5pilot/server/
    chown -R ue5pilot:ue5pilot /opt/ue5pilot/server
    echo "  Server files installed."
else
    echo "  ⚠️  /tmp/ue5pilot-server/ not found. Upload the server/ folder first:"
    echo "  scp -r ./server/ root@YOUR-VPS-IP:/tmp/ue5pilot-server/"
    exit 1
fi

# 5. Install Python dependencies (minimal - mostly stdlib)
echo "[5/8] Installing Python dependencies..."
# The server uses mostly stdlib - just install requests for the optional pieces
pip3 install --break-system-packages requests 2>/dev/null || pip3 install requests

# 6. Open firewall port 8791
echo "[6/8] Configuring firewall..."
ufw allow 22/tcp comment 'SSH'
ufw allow 8791/tcp comment 'UE5Pilot API'
ufw allow 80/tcp comment 'HTTP' 2>/dev/null || true
ufw allow 443/tcp comment 'HTTPS' 2>/dev/null || true
ufw --force enable
echo "  Firewall: 22, 80, 443, 8791 open"

# 7. Install systemd service
echo "[7/8] Installing systemd service..."
cp /tmp/ue5pilot.service /etc/systemd/system/ue5pilot.service
systemctl daemon-reload
systemctl enable ue5pilot
systemctl restart ue5pilot
sleep 2

# 8. Verify
echo "[8/8] Verifying server is running..."
if systemctl is-active --quiet ue5pilot; then
    echo "  ✅ ue5pilot service is RUNNING"
    echo ""
    PUBLIC_IP=$(curl -s ifconfig.me)
    echo "================================================"
    echo "  ✅ DEPLOYMENT COMPLETE"
    echo "================================================"
    echo ""
    echo "  Server URL:   http://${PUBLIC_IP}:8791"
    echo "  Health check: curl http://${PUBLIC_IP}:8791/health"
    echo "  Logs:         journalctl -u ue5pilot -f"
    echo "  Restart:      systemctl restart ue5pilot"
    echo ""
    echo "  Next steps:"
    echo "  1. Point a domain at this IP (A record)"
    echo "  2. Set up nginx + Let's Encrypt for HTTPS"
    echo "  3. Distribute the companion folder to your users"
    echo "     Tell them to set: UE5PILOT_CLOUD_URL=http://${PUBLIC_IP}:8791"
    echo ""
else
    echo "  ❌ ue5pilot service FAILED to start"
    echo "  Check logs: journalctl -u ue5pilot -n 50"
    exit 1
fi
