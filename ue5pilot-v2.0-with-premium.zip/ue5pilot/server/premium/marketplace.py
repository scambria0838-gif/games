"""
UE5Pilot Asset Marketplace Integration

Search and import 3D assets from Quixel Megascans, Sketchfab, and Epic's Fab
marketplace. The AI can call search_assets("victorian streetlamp") and
get back ranked matches, then download_asset(id) to bring it into UE5.

Each marketplace requires its own credentials (set via env vars):
  QUIXEL_API_TOKEN       — Quixel Megascans (free w/ Epic account)
  SKETCHFAB_API_TOKEN    — Sketchfab developer token
  FAB_API_TOKEN          — Epic Fab marketplace token

Without credentials, each provider returns a clear "not configured" error
rather than failing silently. Other providers keep working.
"""

from __future__ import annotations

import json
import os
import urllib.request
import urllib.error
import urllib.parse
from typing import Dict, Any, List, Optional


REQUEST_TIMEOUT = 30


# ---------------------------------------------------------------------------
# Provider configuration
# ---------------------------------------------------------------------------

PROVIDERS = {
    "quixel": {
        "name": "Quixel Megascans",
        "search_url": "https://quixel.com/v1/assets",
        "token_env": "QUIXEL_API_TOKEN",
        "auth_header": "Authorization",
        "auth_format": "Bearer {token}",
        "license_note": "Free with Epic Games account; in-engine use",
    },
    "sketchfab": {
        "name": "Sketchfab",
        "search_url": "https://api.sketchfab.com/v3/search",
        "token_env": "SKETCHFAB_API_TOKEN",
        "auth_header": "Authorization",
        "auth_format": "Token {token}",
        "license_note": "Varies per asset; check downloadable + license fields",
    },
    "fab": {
        "name": "Epic Fab",
        "search_url": "https://www.fab.com/i/listings/search",
        "token_env": "FAB_API_TOKEN",
        "auth_header": "Authorization",
        "auth_format": "Bearer {token}",
        "license_note": "Varies per listing; commercial use may require purchase",
    },
}


# ---------------------------------------------------------------------------
# Generic helpers
# ---------------------------------------------------------------------------

def _get_token(provider: str) -> Optional[str]:
    cfg = PROVIDERS.get(provider)
    if not cfg:
        return None
    return os.environ.get(cfg["token_env"], "").strip() or None


def _http_get(url: str, headers: Dict[str, str]) -> Optional[Dict[str, Any]]:
    req = urllib.request.Request(url, headers=headers, method="GET")
    try:
        with urllib.request.urlopen(req, timeout=REQUEST_TIMEOUT) as resp:
            return json.loads(resp.read().decode("utf-8"))
    except (urllib.error.URLError, urllib.error.HTTPError, json.JSONDecodeError):
        return None


def _provider_headers(provider: str) -> Optional[Dict[str, str]]:
    token = _get_token(provider)
    if not token:
        return None
    cfg = PROVIDERS[provider]
    return {cfg["auth_header"]: cfg["auth_format"].format(token=token)}


# ---------------------------------------------------------------------------
# Quixel Megascans
# ---------------------------------------------------------------------------

def search_quixel(query: str, limit: int = 10, asset_type: Optional[str] = None) -> List[Dict[str, Any]]:
    """Search Quixel Megascans. asset_type can be '3d', 'surface', 'plant', etc."""
    headers = _provider_headers("quixel")
    if not headers:
        return []
    params = {"search": query, "page[size]": limit}
    if asset_type:
        params["filter[type]"] = asset_type
    url = PROVIDERS["quixel"]["search_url"] + "?" + urllib.parse.urlencode(params)
    data = _http_get(url, headers)
    if not data:
        return []
    return _normalize_quixel(data)


def _normalize_quixel(data: Dict[str, Any]) -> List[Dict[str, Any]]:
    results = []
    for asset in data.get("data", []) or data.get("assets", []) or []:
        results.append({
            "provider": "quixel",
            "id": asset.get("id"),
            "name": asset.get("name") or asset.get("title"),
            "kind": asset.get("type") or asset.get("semanticType"),
            "preview_url": asset.get("thumbnail") or asset.get("previewImage"),
            "license": "Quixel Megascans (Epic account required)",
            "download_url": asset.get("downloadUrl"),
        })
    return results


# ---------------------------------------------------------------------------
# Sketchfab
# ---------------------------------------------------------------------------

def search_sketchfab(query: str, limit: int = 10, downloadable_only: bool = True) -> List[Dict[str, Any]]:
    """Search Sketchfab. Defaults to downloadable models only."""
    headers = _provider_headers("sketchfab")
    if not headers:
        return []
    params = {"q": query, "type": "models", "count": limit}
    if downloadable_only:
        params["downloadable"] = "true"
    url = PROVIDERS["sketchfab"]["search_url"] + "?" + urllib.parse.urlencode(params)
    data = _http_get(url, headers)
    if not data:
        return []
    return _normalize_sketchfab(data)


def _normalize_sketchfab(data: Dict[str, Any]) -> List[Dict[str, Any]]:
    results = []
    for model in data.get("results", []):
        thumbs = model.get("thumbnails", {}).get("images", [])
        preview = thumbs[0]["url"] if thumbs else None
        results.append({
            "provider": "sketchfab",
            "id": model.get("uid"),
            "name": model.get("name"),
            "kind": "3d_model",
            "preview_url": preview,
            "license": (model.get("license") or {}).get("label", "varies"),
            "download_url": model.get("uri"),
            "author": (model.get("user") or {}).get("displayName"),
        })
    return results


# ---------------------------------------------------------------------------
# Epic Fab
# ---------------------------------------------------------------------------

def search_fab(query: str, limit: int = 10) -> List[Dict[str, Any]]:
    """Search Epic Fab marketplace."""
    headers = _provider_headers("fab")
    if not headers:
        return []
    params = {"q": query, "limit": limit}
    url = PROVIDERS["fab"]["search_url"] + "?" + urllib.parse.urlencode(params)
    data = _http_get(url, headers)
    if not data:
        return []
    return _normalize_fab(data)


def _normalize_fab(data: Dict[str, Any]) -> List[Dict[str, Any]]:
    results = []
    for item in data.get("results", []) or data.get("listings", []) or []:
        results.append({
            "provider": "fab",
            "id": item.get("listingId") or item.get("id"),
            "name": item.get("title") or item.get("name"),
            "kind": item.get("category"),
            "preview_url": item.get("thumbnail"),
            "license": item.get("licenseType", "varies"),
            "price": item.get("price"),
            "download_url": item.get("downloadUrl"),
        })
    return results


# ---------------------------------------------------------------------------
# Unified interface
# ---------------------------------------------------------------------------

def search_assets(query: str, providers: Optional[List[str]] = None, limit_per: int = 5) -> Dict[str, Any]:
    """
    Search across all configured providers and return merged results.

    Args:
      query: text query, e.g. "victorian streetlamp"
      providers: list of provider names to query (default: all configured ones)
      limit_per: max results per provider

    Returns: {"results": [...], "providers_queried": [...], "providers_skipped": [...]}
    """
    target = providers or list(PROVIDERS.keys())
    queried = []
    skipped = []
    all_results = []

    for p in target:
        if p not in PROVIDERS:
            skipped.append({"provider": p, "reason": "unknown provider"})
            continue
        if not _get_token(p):
            skipped.append({"provider": p, "reason": "no API token configured"})
            continue

        if p == "quixel":
            results = search_quixel(query, limit_per)
        elif p == "sketchfab":
            results = search_sketchfab(query, limit_per)
        elif p == "fab":
            results = search_fab(query, limit_per)
        else:
            results = []

        queried.append(p)
        all_results.extend(results)

    return {
        "query": query,
        "results": all_results,
        "providers_queried": queried,
        "providers_skipped": skipped,
    }


def download_asset(provider: str, asset_id: str, target_dir: str) -> Dict[str, Any]:
    """
    Download an asset to the target directory.

    NOTE: This is a stub for the actual download logic. Each provider has its
    own download flow (Quixel uses a bridge, Sketchfab returns a glb/zip,
    Fab uses Epic Game Launcher). Full implementation requires per-provider
    download workflows that we can build out as needed.
    """
    if provider not in PROVIDERS:
        return {"status": "error", "error": f"unknown provider: {provider}"}
    if not _get_token(provider):
        return {"status": "error", "error": f"{provider} not configured"}
    os.makedirs(target_dir, exist_ok=True)
    return {
        "status": "pending_implementation",
        "provider": provider,
        "asset_id": asset_id,
        "target_dir": target_dir,
        "next_step": f"Implement {provider}-specific download flow",
    }


def get_marketplace_info() -> Dict[str, Any]:
    """Diagnostic: which marketplaces are configured?"""
    info = {}
    for p, cfg in PROVIDERS.items():
        info[p] = {
            "name": cfg["name"],
            "configured": bool(_get_token(p)),
            "env_var": cfg["token_env"],
            "license_note": cfg["license_note"],
        }
    return info


if __name__ == "__main__":
    print("UE5Pilot Asset Marketplace")
    print(json.dumps(get_marketplace_info(), indent=2))
