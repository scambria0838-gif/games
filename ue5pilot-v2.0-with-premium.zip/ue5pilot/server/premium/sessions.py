"""
UE5Pilot Multi-User Sessions, Roles, and Presence

Lets multiple users collaborate on the same UE5 project simultaneously.

Architecture:
  - Workspaces: a workspace = one UE5 project + its users
  - Users: identified by user_id (email or UUID), tied to workspace via membership
  - Roles: owner, director, artist, viewer
  - Presence: who's online right now, when they were last active
  - Audit: who ran what command, when

Storage backend: SQLite for now (single file, zero-config).
Auth: stub that accepts a bearer token; replace with real auth (#10) for prod.
"""

from __future__ import annotations

import json
import os
import sqlite3
import threading
import time
import uuid
from contextlib import contextmanager
from typing import Dict, Any, List, Optional


DB_PATH = os.environ.get("UE5PILOT_SESSIONS_DB",
                        os.path.join(os.path.expanduser("~"), ".ue5pilot", "sessions.db"))
PRESENCE_TIMEOUT = 60  # seconds of inactivity = "offline"

ROLES = ("owner", "director", "artist", "viewer")
ROLE_PERMISSIONS = {
    "owner":    {"read", "write", "execute", "admin", "delete_workspace"},
    "director": {"read", "write", "execute", "admin"},
    "artist":   {"read", "write", "execute"},
    "viewer":   {"read"},
}

_db_lock = threading.RLock()


# ---------------------------------------------------------------------------
# Database setup
# ---------------------------------------------------------------------------

def _init_db():
    os.makedirs(os.path.dirname(DB_PATH), exist_ok=True)
    with _connect() as conn:
        conn.executescript("""
            CREATE TABLE IF NOT EXISTS workspaces (
                workspace_id TEXT PRIMARY KEY,
                name TEXT NOT NULL,
                ue5_project_path TEXT,
                created_at REAL NOT NULL,
                created_by TEXT NOT NULL
            );
            CREATE TABLE IF NOT EXISTS users (
                user_id TEXT PRIMARY KEY,
                email TEXT,
                display_name TEXT,
                created_at REAL NOT NULL
            );
            CREATE TABLE IF NOT EXISTS memberships (
                workspace_id TEXT NOT NULL,
                user_id TEXT NOT NULL,
                role TEXT NOT NULL,
                joined_at REAL NOT NULL,
                PRIMARY KEY (workspace_id, user_id)
            );
            CREATE TABLE IF NOT EXISTS sessions (
                token TEXT PRIMARY KEY,
                user_id TEXT NOT NULL,
                workspace_id TEXT NOT NULL,
                last_seen REAL NOT NULL,
                created_at REAL NOT NULL
            );
            CREATE TABLE IF NOT EXISTS audit_log (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                ts REAL NOT NULL,
                workspace_id TEXT NOT NULL,
                user_id TEXT NOT NULL,
                action TEXT NOT NULL,
                details TEXT
            );
            CREATE INDEX IF NOT EXISTS idx_audit_workspace ON audit_log(workspace_id);
            CREATE INDEX IF NOT EXISTS idx_sessions_workspace ON sessions(workspace_id);
        """)


@contextmanager
def _connect():
    conn = sqlite3.connect(DB_PATH, timeout=10, isolation_level=None)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode=WAL")
    try:
        yield conn
    finally:
        conn.close()


_init_db()


# ---------------------------------------------------------------------------
# Workspace management
# ---------------------------------------------------------------------------

def create_workspace(name: str, owner_user_id: str, ue5_project_path: Optional[str] = None) -> Dict[str, Any]:
    """Create a new workspace. Owner is automatically added as 'owner' role."""
    wid = uuid.uuid4().hex[:16]
    now = time.time()
    with _db_lock, _connect() as conn:
        conn.execute("INSERT INTO workspaces (workspace_id, name, ue5_project_path, created_at, created_by) VALUES (?,?,?,?,?)",
                     (wid, name, ue5_project_path, now, owner_user_id))
        conn.execute("INSERT OR IGNORE INTO users (user_id, created_at) VALUES (?,?)", (owner_user_id, now))
        conn.execute("INSERT INTO memberships (workspace_id, user_id, role, joined_at) VALUES (?,?,?,?)",
                     (wid, owner_user_id, "owner", now))
        _audit(conn, wid, owner_user_id, "workspace.created", {"name": name})
    return {"workspace_id": wid, "name": name, "ue5_project_path": ue5_project_path}


def list_workspaces(user_id: str) -> List[Dict[str, Any]]:
    """List all workspaces a user belongs to."""
    with _connect() as conn:
        rows = conn.execute("""
            SELECT w.workspace_id, w.name, w.ue5_project_path, m.role, w.created_at
            FROM workspaces w
            JOIN memberships m ON m.workspace_id = w.workspace_id
            WHERE m.user_id = ?
            ORDER BY w.created_at DESC
        """, (user_id,)).fetchall()
    return [dict(r) for r in rows]


# ---------------------------------------------------------------------------
# Membership / roles
# ---------------------------------------------------------------------------

def add_member(workspace_id: str, user_id: str, role: str, invited_by: str) -> Dict[str, Any]:
    if role not in ROLES:
        raise ValueError(f"invalid role: {role}")
    if not _has_permission(workspace_id, invited_by, "admin"):
        raise PermissionError("only owners/directors can invite")
    now = time.time()
    with _db_lock, _connect() as conn:
        conn.execute("INSERT OR IGNORE INTO users (user_id, created_at) VALUES (?,?)", (user_id, now))
        conn.execute("INSERT OR REPLACE INTO memberships (workspace_id, user_id, role, joined_at) VALUES (?,?,?,?)",
                     (workspace_id, user_id, role, now))
        _audit(conn, workspace_id, invited_by, "member.added",
               {"user_id": user_id, "role": role})
    return {"workspace_id": workspace_id, "user_id": user_id, "role": role}


def change_role(workspace_id: str, user_id: str, new_role: str, changed_by: str) -> Dict[str, Any]:
    if new_role not in ROLES:
        raise ValueError(f"invalid role: {new_role}")
    if not _has_permission(workspace_id, changed_by, "admin"):
        raise PermissionError("only owners/directors can change roles")
    with _db_lock, _connect() as conn:
        conn.execute("UPDATE memberships SET role=? WHERE workspace_id=? AND user_id=?",
                     (new_role, workspace_id, user_id))
        _audit(conn, workspace_id, changed_by, "member.role_changed",
               {"user_id": user_id, "new_role": new_role})
    return {"workspace_id": workspace_id, "user_id": user_id, "role": new_role}


def remove_member(workspace_id: str, user_id: str, removed_by: str) -> None:
    if not _has_permission(workspace_id, removed_by, "admin"):
        raise PermissionError("only owners/directors can remove members")
    with _db_lock, _connect() as conn:
        conn.execute("DELETE FROM memberships WHERE workspace_id=? AND user_id=?", (workspace_id, user_id))
        _audit(conn, workspace_id, removed_by, "member.removed", {"user_id": user_id})


def list_members(workspace_id: str) -> List[Dict[str, Any]]:
    with _connect() as conn:
        rows = conn.execute("""
            SELECT m.user_id, m.role, m.joined_at, u.email, u.display_name
            FROM memberships m
            LEFT JOIN users u ON u.user_id = m.user_id
            WHERE m.workspace_id = ?
        """, (workspace_id,)).fetchall()
    return [dict(r) for r in rows]


# ---------------------------------------------------------------------------
# Sessions (tokens)
# ---------------------------------------------------------------------------

def open_session(user_id: str, workspace_id: str) -> Dict[str, Any]:
    """Create a session token for this user on this workspace."""
    if not _is_member(workspace_id, user_id):
        raise PermissionError("not a member of this workspace")
    token = uuid.uuid4().hex
    now = time.time()
    with _db_lock, _connect() as conn:
        conn.execute("INSERT INTO sessions (token, user_id, workspace_id, last_seen, created_at) VALUES (?,?,?,?,?)",
                     (token, user_id, workspace_id, now, now))
        _audit(conn, workspace_id, user_id, "session.opened", None)
    return {"token": token, "user_id": user_id, "workspace_id": workspace_id}


def heartbeat(token: str) -> bool:
    """Update last_seen for a session. Returns True if session is valid."""
    now = time.time()
    with _db_lock, _connect() as conn:
        cur = conn.execute("UPDATE sessions SET last_seen=? WHERE token=?", (now, token))
        return cur.rowcount > 0


def resolve_session(token: str) -> Optional[Dict[str, Any]]:
    """Look up a session token, return {user_id, workspace_id} or None."""
    with _connect() as conn:
        row = conn.execute("SELECT user_id, workspace_id, last_seen FROM sessions WHERE token=?", (token,)).fetchone()
    if not row:
        return None
    return dict(row)


def close_session(token: str) -> None:
    with _db_lock, _connect() as conn:
        row = conn.execute("SELECT workspace_id, user_id FROM sessions WHERE token=?", (token,)).fetchone()
        if row:
            conn.execute("DELETE FROM sessions WHERE token=?", (token,))
            _audit(conn, row["workspace_id"], row["user_id"], "session.closed", None)


# ---------------------------------------------------------------------------
# Presence
# ---------------------------------------------------------------------------

def get_presence(workspace_id: str) -> List[Dict[str, Any]]:
    """Who's online right now in this workspace?"""
    now = time.time()
    cutoff = now - PRESENCE_TIMEOUT
    with _connect() as conn:
        rows = conn.execute("""
            SELECT s.user_id, MAX(s.last_seen) AS last_seen, u.display_name, m.role
            FROM sessions s
            LEFT JOIN users u ON u.user_id = s.user_id
            LEFT JOIN memberships m ON m.user_id = s.user_id AND m.workspace_id = s.workspace_id
            WHERE s.workspace_id = ?
            GROUP BY s.user_id
        """, (workspace_id,)).fetchall()
    result = []
    for r in rows:
        d = dict(r)
        d["online"] = d["last_seen"] >= cutoff
        d["seconds_since_active"] = round(now - d["last_seen"], 1)
        result.append(d)
    return result


# ---------------------------------------------------------------------------
# Permissions
# ---------------------------------------------------------------------------

def _is_member(workspace_id: str, user_id: str) -> bool:
    with _connect() as conn:
        row = conn.execute("SELECT 1 FROM memberships WHERE workspace_id=? AND user_id=?",
                          (workspace_id, user_id)).fetchone()
    return row is not None


def get_role(workspace_id: str, user_id: str) -> Optional[str]:
    with _connect() as conn:
        row = conn.execute("SELECT role FROM memberships WHERE workspace_id=? AND user_id=?",
                          (workspace_id, user_id)).fetchone()
    return row["role"] if row else None


def _has_permission(workspace_id: str, user_id: str, permission: str) -> bool:
    role = get_role(workspace_id, user_id)
    if not role:
        return False
    return permission in ROLE_PERMISSIONS.get(role, set())


def check_permission(workspace_id: str, user_id: str, permission: str) -> None:
    """Raise PermissionError if user lacks permission. Use as a guard."""
    if not _has_permission(workspace_id, user_id, permission):
        raise PermissionError(f"user {user_id} lacks '{permission}' in workspace {workspace_id}")


# ---------------------------------------------------------------------------
# Audit log
# ---------------------------------------------------------------------------

def _audit(conn, workspace_id: str, user_id: str, action: str, details: Optional[Dict]):
    conn.execute("INSERT INTO audit_log (ts, workspace_id, user_id, action, details) VALUES (?,?,?,?,?)",
                 (time.time(), workspace_id, user_id, action, json.dumps(details) if details else None))


def get_audit_log(workspace_id: str, limit: int = 100) -> List[Dict[str, Any]]:
    with _connect() as conn:
        rows = conn.execute("""
            SELECT ts, user_id, action, details
            FROM audit_log WHERE workspace_id=?
            ORDER BY id DESC LIMIT ?
        """, (workspace_id, limit)).fetchall()
    return [{**dict(r), "details": json.loads(r["details"]) if r["details"] else None} for r in rows]


def log_command(workspace_id: str, user_id: str, command: str, args: Dict[str, Any]):
    """Public helper for the server to log every command run."""
    with _db_lock, _connect() as conn:
        _audit(conn, workspace_id, user_id, f"command.{command}", args)


# ---------------------------------------------------------------------------
# Diagnostic
# ---------------------------------------------------------------------------

def get_sessions_info() -> Dict[str, Any]:
    with _connect() as conn:
        ws = conn.execute("SELECT COUNT(*) AS n FROM workspaces").fetchone()["n"]
        users = conn.execute("SELECT COUNT(*) AS n FROM users").fetchone()["n"]
        active = conn.execute("SELECT COUNT(*) AS n FROM sessions WHERE last_seen > ?",
                             (time.time() - PRESENCE_TIMEOUT,)).fetchone()["n"]
    return {"db_path": DB_PATH, "workspaces": ws, "users": users, "active_sessions": active}


if __name__ == "__main__":
    print("UE5Pilot Multi-User Sessions")
    print("Info:", get_sessions_info())
    # Smoke test
    ws = create_workspace("Test Studio", "user_alice")
    add_member(ws["workspace_id"], "user_bob", "artist", "user_alice")
    s = open_session("user_alice", ws["workspace_id"])
    s2 = open_session("user_bob", ws["workspace_id"])
    print("Members:", list_members(ws["workspace_id"]))
    print("Presence:", get_presence(ws["workspace_id"]))
