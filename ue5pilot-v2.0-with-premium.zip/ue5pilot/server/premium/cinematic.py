"""
UE5Pilot Cinematic Recording & MP4 Rendering

Drives UE5's Movie Render Queue (MRQ) to produce MP4/PNG/EXR output from
Sequencer takes. Wraps the MRQ Python API into a simpler interface that the
AI can call:

  render_cinematic({
    "sequence": "/Game/Cinematics/IntroShot",
    "output_dir": "C:/Renders",
    "format": "mp4",
    "resolution": [1920, 1080],
    "fps": 24,
    "quality": "high"
  })

This module ships TWO halves:
  1. cinematic_cloud.py side (this file) — the server-side API
  2. ue5_render_skill.py side — the actual MRQ commands run inside Unreal

The server queues a render command, the UE5 plugin executes it via MRQ,
results come back with the output file path on disk.

Status: Server-side API + skill spec done. The UE5-side MRQ invocation
needs to be added to skill_executor.py as new skill functions.
"""

from __future__ import annotations

import json
import os
import time
import uuid
from typing import Dict, Any, Optional, List


# ---------------------------------------------------------------------------
# Render configuration
# ---------------------------------------------------------------------------

VALID_FORMATS = {"mp4", "mov", "png_sequence", "exr_sequence", "jpg_sequence"}
VALID_QUALITIES = {"draft", "standard", "high", "production"}
VALID_CAMERA_PATHS = {"dolly", "orbit", "static", "crane", "tracking", "handheld"}

QUALITY_PRESETS = {
    "draft":      {"spp": 1,  "antialias": "none",  "warmup": 0,  "tile_count": 1},
    "standard":   {"spp": 8,  "antialias": "fxaa",  "warmup": 16, "tile_count": 1},
    "high":       {"spp": 16, "antialias": "tsr",   "warmup": 32, "tile_count": 1},
    "production": {"spp": 32, "antialias": "tsr",   "warmup": 64, "tile_count": 2},
}


# ---------------------------------------------------------------------------
# Render job builder
# ---------------------------------------------------------------------------

def build_render_job(
    sequence_path: str,
    output_dir: str,
    format: str = "mp4",
    resolution: tuple = (1920, 1080),
    fps: int = 24,
    quality: str = "standard",
    output_name: Optional[str] = None,
    overrides: Optional[Dict[str, Any]] = None,
) -> Dict[str, Any]:
    """
    Build a render job spec that gets sent to UE5 for execution.

    Returns a dict the server queues and the UE5 plugin consumes.
    """
    if format not in VALID_FORMATS:
        raise ValueError(f"invalid format {format!r}, must be one of {VALID_FORMATS}")
    if quality not in VALID_QUALITIES:
        raise ValueError(f"invalid quality {quality!r}, must be one of {VALID_QUALITIES}")
    if not sequence_path.startswith("/Game/"):
        raise ValueError("sequence_path must be a UE5 content path like /Game/Cinematics/MyShot")

    job_id = "render_" + uuid.uuid4().hex[:12]
    preset = QUALITY_PRESETS[quality].copy()
    if overrides:
        preset.update(overrides)

    return {
        "job_id": job_id,
        "sequence_path": sequence_path,
        "output_dir": output_dir,
        "output_name": output_name or f"{job_id}.{format if format == 'mp4' or format == 'mov' else 'png'}",
        "format": format,
        "resolution": list(resolution),
        "fps": fps,
        "quality": quality,
        "preset": preset,
        "created_at": time.time(),
        "status": "queued",
    }


# ---------------------------------------------------------------------------
# Camera path generator — creates a Sequencer from a simple spec
# ---------------------------------------------------------------------------

def generate_camera_sequence(
    camera_path: str,
    duration: float,
    target_actor: Optional[str] = None,
    starting_location: Optional[tuple] = None,
) -> Dict[str, Any]:
    """
    Spec for a CineCameraActor + LevelSequence with the requested camera move.

    The UE5-side skill executor consumes this to:
      1. Create a new LevelSequence asset
      2. Add a CineCameraActor track
      3. Add transform keyframes based on the camera_path type
      4. Optionally add a "look at" track pointing at target_actor
    """
    if camera_path not in VALID_CAMERA_PATHS:
        raise ValueError(f"invalid camera_path {camera_path!r}, must be one of {VALID_CAMERA_PATHS}")

    spec = {
        "sequence_name": f"AI_Sequence_{uuid.uuid4().hex[:8]}",
        "camera_path": camera_path,
        "duration_seconds": duration,
        "target_actor": target_actor,
        "starting_location": list(starting_location) if starting_location else None,
    }

    # Path-specific defaults
    if camera_path == "orbit":
        spec["orbit_radius"] = 800.0
        spec["orbit_speed_deg_per_sec"] = 360.0 / duration if duration > 0 else 60.0
    elif camera_path == "dolly":
        spec["dolly_distance"] = 1200.0
        spec["dolly_axis"] = "forward"
    elif camera_path == "crane":
        spec["crane_height_start"] = 100.0
        spec["crane_height_end"] = 800.0
    elif camera_path == "tracking":
        spec["track_target"] = target_actor
        spec["track_offset"] = [0, -500, 200]
    elif camera_path == "handheld":
        spec["shake_amplitude"] = 0.3
        spec["shake_frequency"] = 2.0

    return spec


# ---------------------------------------------------------------------------
# Render queue tracking
# ---------------------------------------------------------------------------

_render_queue: Dict[str, Dict[str, Any]] = {}


def queue_render(job: Dict[str, Any]) -> Dict[str, Any]:
    _render_queue[job["job_id"]] = job
    return {"job_id": job["job_id"], "status": "queued"}


def update_render_status(job_id: str, status: str, output_file: Optional[str] = None, error: Optional[str] = None):
    if job_id in _render_queue:
        _render_queue[job_id]["status"] = status
        _render_queue[job_id]["updated_at"] = time.time()
        if output_file:
            _render_queue[job_id]["output_file"] = output_file
        if error:
            _render_queue[job_id]["error"] = error


def get_render_status(job_id: str) -> Optional[Dict[str, Any]]:
    return _render_queue.get(job_id)


def list_render_jobs(status_filter: Optional[str] = None) -> List[Dict[str, Any]]:
    jobs = list(_render_queue.values())
    if status_filter:
        jobs = [j for j in jobs if j.get("status") == status_filter]
    return sorted(jobs, key=lambda j: j.get("created_at", 0), reverse=True)


# ---------------------------------------------------------------------------
# High-level convenience
# ---------------------------------------------------------------------------

def render_cinematic_from_natural_language(
    user_request: str,
    sequence_path: str,
    output_dir: str,
) -> Dict[str, Any]:
    """
    Parse a casual request into a render job. Used when the AI translates
    "render this in 4K, high quality, MP4" into actual job parameters.
    """
    text = user_request.lower()

    # Resolution detection
    if "4k" in text or "uhd" in text:
        resolution = (3840, 2160)
    elif "1080" in text or "fhd" in text:
        resolution = (1920, 1080)
    elif "720" in text:
        resolution = (1280, 720)
    elif "8k" in text:
        resolution = (7680, 4320)
    else:
        resolution = (1920, 1080)

    # FPS detection
    if "60fps" in text or "60 fps" in text:
        fps = 60
    elif "30fps" in text or "30 fps" in text:
        fps = 30
    elif "48fps" in text or "48 fps" in text:
        fps = 48
    else:
        fps = 24

    # Quality
    quality = "high"
    if "draft" in text or "preview" in text:
        quality = "draft"
    elif "production" in text or "final" in text:
        quality = "production"
    elif "standard" in text:
        quality = "standard"

    # Format
    if "mov" in text or "prores" in text:
        format_ = "mov"
    elif "png" in text:
        format_ = "png_sequence"
    elif "exr" in text:
        format_ = "exr_sequence"
    else:
        format_ = "mp4"

    return build_render_job(
        sequence_path=sequence_path,
        output_dir=output_dir,
        format=format_,
        resolution=resolution,
        fps=fps,
        quality=quality,
    )


def get_cinematic_info() -> Dict[str, Any]:
    return {
        "supported_formats": sorted(VALID_FORMATS),
        "quality_presets": sorted(VALID_QUALITIES),
        "camera_paths": sorted(VALID_CAMERA_PATHS),
        "jobs_in_queue": len([j for j in _render_queue.values() if j.get("status") == "queued"]),
        "jobs_total": len(_render_queue),
    }


if __name__ == "__main__":
    print("UE5Pilot Cinematic Rendering")
    print(json.dumps(get_cinematic_info(), indent=2))
    # Smoke test
    cam = generate_camera_sequence("orbit", duration=10.0, target_actor="Hero")
    print("\nGenerated camera spec:")
    print(json.dumps(cam, indent=2))
    job = build_render_job(
        sequence_path="/Game/Cinematics/Intro",
        output_dir="/renders",
        format="mp4",
        resolution=(1920, 1080),
        fps=24,
        quality="high",
    )
    print("\nGenerated render job:")
    print(json.dumps(job, indent=2))
