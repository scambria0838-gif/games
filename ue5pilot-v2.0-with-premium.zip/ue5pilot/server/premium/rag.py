"""
UE5Pilot Project-Aware RAG (Retrieval-Augmented Generation)

Indexes a user's actual UE5 project so the AI knows what assets, Blueprints,
materials, and levels exist. Lets the AI answer questions like:
  - "where did I put that medieval chair Blueprint?"
  - "what's the path to the player character's animation blueprint?"
  - "list all material instances in the dungeon level"

Architecture:
  - Walks the /Content folder of a .uproject
  - Extracts metadata from .uasset / .umap / .uplugin files
  - Embeds descriptions and stores in a local vector DB (Chroma)
  - Provides a query() function that returns relevant assets

Note: Full implementation requires chromadb + sentence-transformers.
This scaffolding can run without them (in 'simple' mode using text matching)
so you can deploy now and upgrade to vector search later.
"""

from __future__ import annotations

import json
import os
import re
from pathlib import Path
from typing import Dict, Any, List, Optional, Tuple

# Optional vector DB — falls back to text matching if not installed
try:
    import chromadb
    CHROMA_AVAILABLE = True
except ImportError:
    CHROMA_AVAILABLE = False


# ---------------------------------------------------------------------------
# Asset metadata extraction
# ---------------------------------------------------------------------------

ASSET_EXTENSIONS = {".uasset", ".umap", ".uplugin", ".uproject"}
TEXT_EXTENSIONS = {".ini", ".cfg", ".json", ".txt", ".md", ".cpp", ".h", ".cs"}


def walk_project(project_root: str) -> List[Dict[str, Any]]:
    """
    Walk a UE5 project directory and return metadata for every asset.

    Returns list of {path, name, kind, folder, size_bytes}.
    """
    project_root = os.path.abspath(project_root)
    if not os.path.isdir(project_root):
        return []
    assets = []
    for dirpath, dirnames, filenames in os.walk(project_root):
        # Skip common noise
        dirnames[:] = [d for d in dirnames if d not in {
            "Binaries", "Intermediate", "DerivedDataCache", "Saved",
            ".git", "__pycache__", "node_modules"
        }]
        for fn in filenames:
            full = os.path.join(dirpath, fn)
            ext = os.path.splitext(fn)[1].lower()
            if ext not in ASSET_EXTENSIONS and ext not in TEXT_EXTENSIONS:
                continue
            try:
                size = os.path.getsize(full)
            except OSError:
                size = 0
            rel = os.path.relpath(full, project_root)
            assets.append({
                "path": rel.replace(os.sep, "/"),
                "name": os.path.splitext(fn)[0],
                "kind": _classify_asset(rel, ext),
                "folder": os.path.dirname(rel).replace(os.sep, "/"),
                "size_bytes": size,
                "ext": ext,
            })
    return assets


def _classify_asset(path: str, ext: str) -> str:
    """Best-effort classification from path and extension."""
    lower = path.lower()
    if ext == ".uproject":
        return "project"
    if ext == ".uplugin":
        return "plugin"
    if ext == ".umap":
        return "level"
    if ext != ".uasset":
        return "config" if ext in {".ini", ".cfg"} else "source"
    # .uasset — use folder hints
    if "/blueprints/" in lower or "/bp_" in lower or "bp_" in os.path.basename(lower):
        return "blueprint"
    if "/materials/" in lower or "/mat_" in lower or "m_" in os.path.basename(lower):
        return "material"
    if "/textures/" in lower or "/t_" in lower:
        return "texture"
    if "/meshes/" in lower or "/sm_" in lower:
        return "static_mesh"
    if "/skeletalmesh/" in lower or "/sk_" in lower:
        return "skeletal_mesh"
    if "/animations/" in lower or "/anim_" in lower:
        return "animation"
    if "/sounds/" in lower or "/audio/" in lower:
        return "audio"
    if "/niagara/" in lower or "/vfx/" in lower:
        return "vfx"
    if "/levels/" in lower:
        return "level_asset"
    return "asset"


def describe_asset(asset: Dict[str, Any]) -> str:
    """Generate a searchable text description for an asset."""
    parts = [
        f"Asset: {asset['name']}",
        f"Kind: {asset['kind']}",
        f"Path: {asset['path']}",
        f"Folder: {asset['folder']}",
    ]
    return " | ".join(parts)


# ---------------------------------------------------------------------------
# Index store
# ---------------------------------------------------------------------------

class ProjectIndex:
    """
    Holds an indexed UE5 project. Supports two backends:
      - 'chroma' (vector search, semantic, requires chromadb)
      - 'simple' (substring + folder matching, no deps)

    Automatically uses chroma if available.
    """

    def __init__(self, project_root: str, persist_dir: Optional[str] = None):
        self.project_root = os.path.abspath(project_root)
        self.persist_dir = persist_dir or os.path.join(
            os.path.expanduser("~"), ".ue5pilot", "indices",
            os.path.basename(self.project_root)
        )
        os.makedirs(self.persist_dir, exist_ok=True)
        self.assets: List[Dict[str, Any]] = []
        self.backend = "chroma" if CHROMA_AVAILABLE else "simple"
        self._chroma_collection = None

    def build(self) -> Dict[str, Any]:
        """Walk the project and build the index. Returns stats."""
        self.assets = walk_project(self.project_root)
        # Save raw asset list to JSON regardless of backend
        json_path = os.path.join(self.persist_dir, "assets.json")
        with open(json_path, "w", encoding="utf-8") as f:
            json.dump(self.assets, f, indent=2)

        if self.backend == "chroma" and CHROMA_AVAILABLE:
            self._build_chroma()

        kind_counts = {}
        for a in self.assets:
            kind_counts[a["kind"]] = kind_counts.get(a["kind"], 0) + 1

        return {
            "project_root": self.project_root,
            "backend": self.backend,
            "total_assets": len(self.assets),
            "by_kind": kind_counts,
            "persist_dir": self.persist_dir,
        }

    def _build_chroma(self):
        """Build a Chroma collection from the assets."""
        client = chromadb.PersistentClient(path=self.persist_dir)
        try:
            client.delete_collection("ue5_project")
        except Exception:
            pass
        coll = client.create_collection(name="ue5_project")
        ids = [f"asset_{i}" for i in range(len(self.assets))]
        documents = [describe_asset(a) for a in self.assets]
        metadatas = self.assets
        # Batch insert to avoid memory blowup
        BATCH = 500
        for i in range(0, len(ids), BATCH):
            coll.add(
                ids=ids[i:i + BATCH],
                documents=documents[i:i + BATCH],
                metadatas=metadatas[i:i + BATCH],
            )
        self._chroma_collection = coll

    def load(self) -> bool:
        """Load a previously built index from disk."""
        json_path = os.path.join(self.persist_dir, "assets.json")
        if not os.path.exists(json_path):
            return False
        with open(json_path, "r", encoding="utf-8") as f:
            self.assets = json.load(f)
        if self.backend == "chroma" and CHROMA_AVAILABLE:
            try:
                client = chromadb.PersistentClient(path=self.persist_dir)
                self._chroma_collection = client.get_collection("ue5_project")
            except Exception:
                self.backend = "simple"  # fallback if collection missing
        return True

    def query(self, q: str, top_k: int = 10, kind: Optional[str] = None) -> List[Dict[str, Any]]:
        """
        Search the index. Returns up to top_k assets, optionally filtered by kind.
        """
        if not q or not self.assets:
            return []

        if self.backend == "chroma" and self._chroma_collection:
            return self._query_chroma(q, top_k, kind)
        return self._query_simple(q, top_k, kind)

    def _query_chroma(self, q: str, top_k: int, kind: Optional[str]) -> List[Dict[str, Any]]:
        where = {"kind": kind} if kind else None
        try:
            res = self._chroma_collection.query(
                query_texts=[q],
                n_results=top_k,
                where=where,
            )
            return res.get("metadatas", [[]])[0] if res else []
        except Exception:
            return self._query_simple(q, top_k, kind)

    def _query_simple(self, q: str, top_k: int, kind: Optional[str]) -> List[Dict[str, Any]]:
        """Substring search across name/path/folder. Scored by where it matches."""
        q_lower = q.lower()
        terms = [t for t in re.split(r"\s+", q_lower) if t]
        scored: List[Tuple[float, Dict[str, Any]]] = []
        for a in self.assets:
            if kind and a["kind"] != kind:
                continue
            score = 0.0
            name = a["name"].lower()
            path = a["path"].lower()
            folder = a["folder"].lower()
            for t in terms:
                if t in name:
                    score += 3.0
                if t in folder:
                    score += 1.5
                if t in path:
                    score += 1.0
            if score > 0:
                scored.append((score, a))
        scored.sort(key=lambda x: -x[0])
        return [a for _, a in scored[:top_k]]

    def stats(self) -> Dict[str, Any]:
        """Summary stats for the index."""
        kind_counts = {}
        for a in self.assets:
            kind_counts[a["kind"]] = kind_counts.get(a["kind"], 0) + 1
        return {
            "project_root": self.project_root,
            "backend": self.backend,
            "total_assets": len(self.assets),
            "by_kind": kind_counts,
        }


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def index_project(project_root: str) -> Dict[str, Any]:
    """Build and persist an index for a UE5 project. Returns stats."""
    idx = ProjectIndex(project_root)
    return idx.build()


def query_project(project_root: str, q: str, top_k: int = 10, kind: Optional[str] = None) -> List[Dict[str, Any]]:
    """Query a previously-indexed project. Auto-loads from disk."""
    idx = ProjectIndex(project_root)
    if not idx.load():
        # Build on the fly if not indexed yet
        idx.build()
    return idx.query(q, top_k=top_k, kind=kind)


def get_rag_info() -> Dict[str, Any]:
    return {
        "chroma_available": CHROMA_AVAILABLE,
        "backend": "chroma" if CHROMA_AVAILABLE else "simple",
        "install_chroma": "pip install chromadb" if not CHROMA_AVAILABLE else None,
    }


if __name__ == "__main__":
    print("UE5Pilot Project RAG")
    print("Config:", get_rag_info())
    # Try indexing the test ue5 project structure if present
    test_root = "./test_ue5_project"
    if os.path.isdir(test_root):
        stats = index_project(test_root)
        print("Indexed:", json.dumps(stats, indent=2))
    else:
        print(f"\nTo test: point at a UE5 project folder.")
        print(f"  Example: python rag.py /path/to/MyGame")
