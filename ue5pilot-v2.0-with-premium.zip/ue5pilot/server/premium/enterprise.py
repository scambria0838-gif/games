"""
UE5Pilot Enterprise Module

The enterprise tier features that unlock $50K-$500K/year contracts:
  - Multi-tenancy: organizations isolate data from each other
  - SSO: SAML 2.0 + OIDC (Okta, Azure AD, Auth0, Google Workspace)
  - RBAC: granular permissions beyond the basic workspace roles
  - Billing: Stripe integration for plans, seats, and usage metering
  - Audit & compliance: SOC2-style event logging

This file gives you:
  - The data model and storage
  - Stripe webhook handling
  - Token validation hooks for SSO providers
  - Usage metering for per-seat / per-command billing

What still needs YOUR configuration (external accounts):
  - Stripe account + API keys
  - SSO provider setup (Okta tenant, Azure AD app registration, etc)
  - JWT signing keys
"""

from __future__ import annotations

import hashlib
import hmac
import json
import os
import secrets
import sqlite3
import threading
import time
import uuid
from contextlib import contextmanager
from typing import Dict, Any, List, Optional


DB_PATH = os.environ.get("UE5PILOT_ENTERPRISE_DB",
                        os.path.join(os.path.expanduser("~"), ".ue5pilot", "enterprise.db"))

_lock = threading.RLock()

os.makedirs(os.path.dirname(DB_PATH), exist_ok=True)


# ---------------------------------------------------------------------------
# Plans & limits
# ---------------------------------------------------------------------------

PLANS = {
    "free": {
        "name": "Free",
        "price_monthly_usd": 0,
        "max_seats": 1,
        "max_workspaces": 1,
        "max_commands_per_month": 500,
        "ai_director": False,
        "vision_loop": False,
        "rag_indexing": False,
        "voice_control": False,
        "sso": False,
        "support": "community",
    },
    "pro": {
        "name": "Pro",
        "price_monthly_usd": 49,
        "max_seats": 5,
        "max_workspaces": 10,
        "max_commands_per_month": 10000,
        "ai_director": True,
        "vision_loop": True,
        "rag_indexing": True,
        "voice_control": False,
        "sso": False,
        "support": "email",
    },
    "studio": {
        "name": "Studio",
        "price_monthly_usd": 299,
        "max_seats": 25,
        "max_workspaces": 100,
        "max_commands_per_month": 100000,
        "ai_director": True,
        "vision_loop": True,
        "rag_indexing": True,
        "voice_control": True,
        "sso": False,
        "support": "priority",
    },
    "enterprise": {
        "name": "Enterprise",
        "price_monthly_usd": None,  # custom pricing
        "max_seats": None,
        "max_workspaces": None,
        "max_commands_per_month": None,
        "ai_director": True,
        "vision_loop": True,
        "rag_indexing": True,
        "voice_control": True,
        "sso": True,
        "support": "dedicated",
    },
}


# ---------------------------------------------------------------------------
# Database
# ---------------------------------------------------------------------------

@contextmanager
def _connect():
    conn = sqlite3.connect(DB_PATH, timeout=10, isolation_level=None)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode=WAL")
    try:
        yield conn
    finally:
        conn.close()


def _init_db():
    with _connect() as conn:
        conn.executescript("""
            CREATE TABLE IF NOT EXISTS organizations (
                org_id TEXT PRIMARY KEY,
                name TEXT NOT NULL,
                plan TEXT NOT NULL DEFAULT 'free',
                stripe_customer_id TEXT,
                stripe_subscription_id TEXT,
                seats_purchased INTEGER DEFAULT 1,
                created_at REAL NOT NULL,
                sso_provider TEXT,
                sso_metadata TEXT
            );
            CREATE TABLE IF NOT EXISTS org_members (
                org_id TEXT NOT NULL,
                user_id TEXT NOT NULL,
                org_role TEXT NOT NULL DEFAULT 'member',
                added_at REAL NOT NULL,
                PRIMARY KEY (org_id, user_id)
            );
            CREATE TABLE IF NOT EXISTS api_keys (
                key_id TEXT PRIMARY KEY,
                key_hash TEXT NOT NULL,
                org_id TEXT NOT NULL,
                created_by TEXT NOT NULL,
                created_at REAL NOT NULL,
                last_used_at REAL,
                revoked INTEGER DEFAULT 0
            );
            CREATE TABLE IF NOT EXISTS usage_events (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                ts REAL NOT NULL,
                org_id TEXT NOT NULL,
                user_id TEXT,
                event_type TEXT NOT NULL,
                quantity REAL DEFAULT 1.0,
                details TEXT
            );
            CREATE INDEX IF NOT EXISTS idx_usage_org_ts ON usage_events(org_id, ts);
            CREATE TABLE IF NOT EXISTS audit_events (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                ts REAL NOT NULL,
                org_id TEXT,
                user_id TEXT,
                event TEXT NOT NULL,
                ip TEXT,
                details TEXT
            );
        """)


_init_db()


# ---------------------------------------------------------------------------
# Organization management
# ---------------------------------------------------------------------------

def create_organization(name: str, owner_user_id: str, plan: str = "free") -> Dict[str, Any]:
    if plan not in PLANS:
        raise ValueError(f"unknown plan: {plan}")
    org_id = "org_" + uuid.uuid4().hex[:12]
    now = time.time()
    with _lock, _connect() as conn:
        conn.execute("INSERT INTO organizations (org_id, name, plan, created_at) VALUES (?,?,?,?)",
                     (org_id, name, plan, now))
        conn.execute("INSERT INTO org_members (org_id, user_id, org_role, added_at) VALUES (?,?,?,?)",
                     (org_id, owner_user_id, "owner", now))
        _audit(conn, org_id, owner_user_id, "org.created", {"name": name, "plan": plan})
    return {"org_id": org_id, "name": name, "plan": plan}


def get_organization(org_id: str) -> Optional[Dict[str, Any]]:
    with _connect() as conn:
        row = conn.execute("SELECT * FROM organizations WHERE org_id=?", (org_id,)).fetchone()
    if not row:
        return None
    org = dict(row)
    org["plan_details"] = PLANS.get(org["plan"], PLANS["free"])
    return org


def upgrade_plan(org_id: str, new_plan: str, stripe_subscription_id: Optional[str] = None) -> Dict[str, Any]:
    if new_plan not in PLANS:
        raise ValueError(f"unknown plan: {new_plan}")
    with _lock, _connect() as conn:
        conn.execute("UPDATE organizations SET plan=?, stripe_subscription_id=? WHERE org_id=?",
                     (new_plan, stripe_subscription_id, org_id))
        _audit(conn, org_id, None, "org.plan_changed", {"new_plan": new_plan})
    return {"org_id": org_id, "plan": new_plan}


# ---------------------------------------------------------------------------
# API keys
# ---------------------------------------------------------------------------

def create_api_key(org_id: str, created_by: str) -> Dict[str, Any]:
    """Generate a new API key. Returns the plaintext key ONCE — store it client-side."""
    key_id = "ak_" + uuid.uuid4().hex[:12]
    plaintext = "ue5p_" + secrets.token_urlsafe(32)
    key_hash = hashlib.sha256(plaintext.encode()).hexdigest()
    now = time.time()
    with _lock, _connect() as conn:
        conn.execute("INSERT INTO api_keys (key_id, key_hash, org_id, created_by, created_at) VALUES (?,?,?,?,?)",
                     (key_id, key_hash, org_id, created_by, now))
        _audit(conn, org_id, created_by, "api_key.created", {"key_id": key_id})
    return {"key_id": key_id, "api_key": plaintext, "warning": "store now — cannot be retrieved later"}


def validate_api_key(plaintext: str) -> Optional[Dict[str, Any]]:
    """Validate an API key. Returns {key_id, org_id} on success, None on failure."""
    if not plaintext or not plaintext.startswith("ue5p_"):
        return None
    key_hash = hashlib.sha256(plaintext.encode()).hexdigest()
    with _lock, _connect() as conn:
        row = conn.execute("""
            SELECT key_id, org_id FROM api_keys
            WHERE key_hash=? AND revoked=0
        """, (key_hash,)).fetchone()
        if row:
            conn.execute("UPDATE api_keys SET last_used_at=? WHERE key_id=?", (time.time(), row["key_id"]))
    return dict(row) if row else None


def revoke_api_key(key_id: str, revoked_by: str) -> None:
    with _lock, _connect() as conn:
        row = conn.execute("SELECT org_id FROM api_keys WHERE key_id=?", (key_id,)).fetchone()
        if row:
            conn.execute("UPDATE api_keys SET revoked=1 WHERE key_id=?", (key_id,))
            _audit(conn, row["org_id"], revoked_by, "api_key.revoked", {"key_id": key_id})


# ---------------------------------------------------------------------------
# Usage metering & quota
# ---------------------------------------------------------------------------

def record_usage(org_id: str, event_type: str, quantity: float = 1.0,
                user_id: Optional[str] = None, details: Optional[Dict] = None) -> None:
    """
    Log a billable usage event. event_type examples:
      - "command.executed"
      - "ai_director.session"
      - "vision.analysis"
      - "tts.character"
      - "stt.minute"
    """
    with _lock, _connect() as conn:
        conn.execute("""
            INSERT INTO usage_events (ts, org_id, user_id, event_type, quantity, details)
            VALUES (?,?,?,?,?,?)
        """, (time.time(), org_id, user_id, event_type, quantity,
              json.dumps(details) if details else None))


def get_usage(org_id: str, since_ts: Optional[float] = None) -> Dict[str, Any]:
    """Return usage totals for an org since the given timestamp (default: this month)."""
    if since_ts is None:
        # Start of current month
        now = time.time()
        t = time.localtime(now)
        since_ts = time.mktime((t.tm_year, t.tm_mon, 1, 0, 0, 0, 0, 0, -1))
    with _connect() as conn:
        rows = conn.execute("""
            SELECT event_type, SUM(quantity) AS total
            FROM usage_events
            WHERE org_id=? AND ts >= ?
            GROUP BY event_type
        """, (org_id, since_ts)).fetchall()
    return {row["event_type"]: row["total"] for row in rows}


def check_quota(org_id: str, event_type: str = "command.executed") -> Dict[str, Any]:
    """
    Check if the org is over its quota for the current billing period.
    Returns {allowed: bool, used: float, limit: float, plan: str}.
    """
    org = get_organization(org_id)
    if not org:
        return {"allowed": False, "error": "org not found"}
    plan = org["plan_details"]
    limit = plan.get("max_commands_per_month")
    if limit is None:
        return {"allowed": True, "used": 0, "limit": None, "plan": org["plan"]}
    usage = get_usage(org_id)
    used = usage.get(event_type, 0)
    return {
        "allowed": used < limit,
        "used": used,
        "limit": limit,
        "plan": org["plan"],
        "remaining": max(0, limit - used),
    }


# ---------------------------------------------------------------------------
# SSO hooks
# ---------------------------------------------------------------------------

def configure_sso(org_id: str, provider: str, metadata: Dict[str, Any]) -> None:
    """
    Store SSO config for an org. provider = 'saml' | 'oidc'.
    metadata holds provider-specific config (entity IDs, cert, JWKS URL, etc).
    """
    with _lock, _connect() as conn:
        conn.execute("UPDATE organizations SET sso_provider=?, sso_metadata=? WHERE org_id=?",
                     (provider, json.dumps(metadata), org_id))
        _audit(conn, org_id, None, "sso.configured", {"provider": provider})


def validate_sso_token(token: str, org_id: str) -> Optional[Dict[str, Any]]:
    """
    Validate an SSO token. STUB — actual implementation depends on provider.
    For SAML: validate signed assertion against IdP cert.
    For OIDC: validate JWT against JWKS endpoint.

    Returns user info dict or None.
    """
    org = get_organization(org_id)
    if not org or not org.get("sso_provider"):
        return None
    # TODO: per-provider validation
    # For SAML: use python3-saml library
    # For OIDC: use PyJWT + JWKS client
    return None


# ---------------------------------------------------------------------------
# Stripe webhook (validation + handlers)
# ---------------------------------------------------------------------------

def verify_stripe_webhook(payload: bytes, signature: str) -> bool:
    """
    Verify Stripe webhook signature.
    Set UE5PILOT_STRIPE_WEBHOOK_SECRET to your endpoint signing secret.
    """
    secret = os.environ.get("UE5PILOT_STRIPE_WEBHOOK_SECRET", "").strip()
    if not secret or not signature:
        return False
    # Stripe signature format: t=timestamp,v1=hash
    parts = dict(p.split("=", 1) for p in signature.split(",") if "=" in p)
    timestamp = parts.get("t", "")
    v1 = parts.get("v1", "")
    signed_payload = f"{timestamp}.{payload.decode('utf-8', errors='ignore')}"
    expected = hmac.new(secret.encode(), signed_payload.encode(), hashlib.sha256).hexdigest()
    return hmac.compare_digest(expected, v1)


def handle_stripe_event(event: Dict[str, Any]) -> Dict[str, Any]:
    """
    Process a verified Stripe event. Returns {handled: bool, action: str}.
    """
    event_type = event.get("type", "")
    obj = event.get("data", {}).get("object", {})

    if event_type == "customer.subscription.created":
        # Map plan name from Stripe price ID to our PLANS
        plan = _stripe_price_to_plan(obj.get("items", {}).get("data", [{}])[0].get("price", {}).get("id"))
        org_id = obj.get("metadata", {}).get("org_id")
        if org_id and plan:
            upgrade_plan(org_id, plan, stripe_subscription_id=obj.get("id"))
            return {"handled": True, "action": f"upgraded {org_id} to {plan}"}
    elif event_type == "customer.subscription.deleted":
        org_id = obj.get("metadata", {}).get("org_id")
        if org_id:
            upgrade_plan(org_id, "free")
            return {"handled": True, "action": f"downgraded {org_id} to free"}
    elif event_type == "invoice.payment_failed":
        return {"handled": True, "action": "TODO: notify org of failed payment"}

    return {"handled": False, "action": f"unhandled event type: {event_type}"}


def _stripe_price_to_plan(price_id: Optional[str]) -> Optional[str]:
    """Map Stripe price IDs to plan names. Configure via env vars."""
    if not price_id:
        return None
    mapping = {
        os.environ.get("UE5PILOT_STRIPE_PRICE_PRO", ""): "pro",
        os.environ.get("UE5PILOT_STRIPE_PRICE_STUDIO", ""): "studio",
        os.environ.get("UE5PILOT_STRIPE_PRICE_ENTERPRISE", ""): "enterprise",
    }
    return mapping.get(price_id)


# ---------------------------------------------------------------------------
# Audit log (SOC2 / compliance)
# ---------------------------------------------------------------------------

def _audit(conn, org_id: Optional[str], user_id: Optional[str],
          event: str, details: Optional[Dict], ip: Optional[str] = None):
    conn.execute("""
        INSERT INTO audit_events (ts, org_id, user_id, event, ip, details)
        VALUES (?,?,?,?,?,?)
    """, (time.time(), org_id, user_id, event, ip, json.dumps(details) if details else None))


def get_audit_events(org_id: Optional[str] = None, limit: int = 200) -> List[Dict[str, Any]]:
    with _connect() as conn:
        if org_id:
            rows = conn.execute("SELECT * FROM audit_events WHERE org_id=? ORDER BY id DESC LIMIT ?",
                               (org_id, limit)).fetchall()
        else:
            rows = conn.execute("SELECT * FROM audit_events ORDER BY id DESC LIMIT ?",
                               (limit,)).fetchall()
    return [{**dict(r), "details": json.loads(r["details"]) if r["details"] else None} for r in rows]


# ---------------------------------------------------------------------------
# Diagnostic
# ---------------------------------------------------------------------------

def get_enterprise_info() -> Dict[str, Any]:
    with _connect() as conn:
        org_count = conn.execute("SELECT COUNT(*) AS n FROM organizations").fetchone()["n"]
        active_keys = conn.execute("SELECT COUNT(*) AS n FROM api_keys WHERE revoked=0").fetchone()["n"]
    return {
        "db_path": DB_PATH,
        "organizations": org_count,
        "active_api_keys": active_keys,
        "stripe_configured": bool(os.environ.get("UE5PILOT_STRIPE_WEBHOOK_SECRET")),
        "available_plans": list(PLANS.keys()),
    }


if __name__ == "__main__":
    print("UE5Pilot Enterprise")
    print(json.dumps(get_enterprise_info(), indent=2))
    # Smoke test
    org = create_organization("Demo Studio", "user_owner", plan="pro")
    print("\nCreated org:", org)
    key = create_api_key(org["org_id"], "user_owner")
    print("Created API key:", key["key_id"])
    record_usage(org["org_id"], "command.executed", 1.0, "user_owner")
    print("Quota check:", check_quota(org["org_id"]))
