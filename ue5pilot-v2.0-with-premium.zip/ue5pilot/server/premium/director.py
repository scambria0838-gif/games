"""
UE5Pilot AI Director

The crown jewel. Takes a high-level creative intent ("make this scene feel like
the protagonist just lost everything") and:

  1. PLANS  — uses LLM to break the intent into a sequence of UE5 commands
  2. EXECUTES — sends each command through the UE5Pilot pipeline
  3. SEES — captures a screenshot after each major step
  4. EVALUATES — uses vision model to judge if the result matches intent
  5. ITERATES — generates corrective commands if gaps are found
  6. STOPS — when match score is high enough, or max iterations reached

Designed to be called from the cloud server's /direct endpoint.
Returns a structured session log of everything it did and why.
"""

from __future__ import annotations

import json
import os
import time
import uuid
from typing import Dict, Any, List, Optional, Callable

# Local imports — these are optional, the Director degrades gracefully
try:
    from premium.llm_translator import translate as llm_translate, _call_anthropic, _call_openai, SKILL_CATALOG
    LLM_AVAILABLE = True
except ImportError:
    LLM_AVAILABLE = False

try:
    from premium.vision import assess_screenshot
    VISION_AVAILABLE = True
except ImportError:
    VISION_AVAILABLE = False


# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------

MAX_ITERATIONS = int(os.environ.get("UE5PILOT_DIRECTOR_MAX_ITER", "5"))
MIN_MATCH_SCORE = float(os.environ.get("UE5PILOT_DIRECTOR_MIN_SCORE", "0.85"))
ITERATION_TIMEOUT = int(os.environ.get("UE5PILOT_DIRECTOR_TIMEOUT", "120"))  # seconds per iteration


# ---------------------------------------------------------------------------
# Planning prompt — different from translator; this asks for a full sequence
# ---------------------------------------------------------------------------

DIRECTOR_PLANNING_PROMPT = """You are the UE5Pilot AI Director.

A user has given you a high-level creative intent for an Unreal Engine 5 scene.
Your job is to plan a complete sequence of commands that will build the scene.

Think like a director planning a shot:
  - What's the lighting mood?
  - What environment elements are needed (fog, sky, landscape)?
  - What actors or props need to be placed?
  - What camera angle or post-process treatment?
  - What VFX or audio would sell the mood?

Plan 5-15 commands total. Order matters — usually:
  1. Set the broad lighting/atmosphere first
  2. Add environmental elements (fog, sky, terrain)
  3. Place actors and props
  4. Add VFX and audio
  5. Final post-processing pass

Available commands (use ONLY these):
""" + SKILL_CATALOG if LLM_AVAILABLE else "" + """

Return a JSON object:
{
  "plan_summary": "1-2 sentence summary of your creative approach",
  "commands": [
    {"command": "...", "args": {}, "reason": "why this command, in 1 sentence"}
  ]
}

Return ONLY the JSON object. No prose, no markdown fences."""


# ---------------------------------------------------------------------------
# Pluggable executor — caller provides the actual command-sending function
# ---------------------------------------------------------------------------

ExecutorFunc = Callable[[str, Dict[str, Any]], Dict[str, Any]]
ScreenshotFunc = Callable[[], Optional[bytes]]


# ---------------------------------------------------------------------------
# Core Director
# ---------------------------------------------------------------------------

class AIDirector:
    """
    Orchestrates a creative session: plan → execute → see → iterate.

    Usage:
        director = AIDirector(executor=my_executor, screenshot=my_screenshot)
        session = director.direct("make this look like a noir alley")
        # session contains the full log of what happened
    """

    def __init__(
        self,
        executor: ExecutorFunc,
        screenshot: Optional[ScreenshotFunc] = None,
        max_iterations: int = MAX_ITERATIONS,
        min_match_score: float = MIN_MATCH_SCORE,
    ):
        self.executor = executor
        self.screenshot = screenshot
        self.max_iterations = max_iterations
        self.min_match_score = min_match_score

    def direct(self, intent: str) -> Dict[str, Any]:
        """
        Run a full direction session for the given creative intent.

        Returns a structured log:
        {
          "session_id": "...",
          "intent": "...",
          "iterations": [
            {
              "iteration": 1,
              "plan_summary": "...",
              "commands_executed": [...],
              "screenshot_taken": bool,
              "assessment": {...} | None
            }
          ],
          "final_status": "complete" | "max_iterations" | "no_plan" | "error",
          "final_score": float,
          "duration_seconds": float
        }
        """
        session_id = uuid.uuid4().hex[:12]
        started_at = time.time()
        session = {
            "session_id": session_id,
            "intent": intent,
            "iterations": [],
            "final_status": "in_progress",
            "final_score": 0.0,
            "duration_seconds": 0.0,
        }

        if not LLM_AVAILABLE:
            session["final_status"] = "error"
            session["error"] = "LLM translator not available"
            return self._finalize(session, started_at)

        current_intent = intent
        for iteration_num in range(1, self.max_iterations + 1):
            iteration = {
                "iteration": iteration_num,
                "plan_summary": "",
                "commands_executed": [],
                "screenshot_taken": False,
                "assessment": None,
            }

            # 1. Plan
            plan = self._plan(current_intent, iteration_num)
            if not plan or not plan.get("commands"):
                iteration["error"] = "could not generate a plan"
                session["iterations"].append(iteration)
                if iteration_num == 1:
                    session["final_status"] = "no_plan"
                    return self._finalize(session, started_at)
                break

            iteration["plan_summary"] = plan.get("plan_summary", "")

            # 2. Execute
            for cmd in plan["commands"]:
                result = self._execute_command(cmd)
                iteration["commands_executed"].append({
                    "command": cmd.get("command"),
                    "args": cmd.get("args", {}),
                    "reason": cmd.get("reason", ""),
                    "result": result,
                })

            # 3. Screenshot + 4. Evaluate
            if self.screenshot and VISION_AVAILABLE:
                img = None
                try:
                    img = self.screenshot()
                except Exception as e:
                    iteration["screenshot_error"] = str(e)
                if img:
                    iteration["screenshot_taken"] = True
                    assessment = assess_screenshot(img, intent)
                    iteration["assessment"] = assessment
                    score = assessment.get("match_score", 0.0)
                    session["final_score"] = score

                    # 5. Decide: stop or iterate?
                    if assessment.get("matches_intent") and score >= self.min_match_score:
                        session["iterations"].append(iteration)
                        session["final_status"] = "complete"
                        return self._finalize(session, started_at)

                    # Build the next iteration's intent from gaps
                    gaps = assessment.get("gaps", [])
                    suggestions = assessment.get("suggestions", [])
                    if gaps or suggestions:
                        current_intent = self._build_correction_intent(intent, gaps, suggestions)

            session["iterations"].append(iteration)

        session["final_status"] = "max_iterations"
        return self._finalize(session, started_at)

    # -- internal helpers ----------------------------------------------------

    def _plan(self, intent: str, iteration_num: int) -> Optional[Dict[str, Any]]:
        """Use the LLM to generate a plan. Returns dict with plan_summary + commands."""
        prompt_user = f"Iteration {iteration_num}. Creative intent:\n\n{intent}"
        provider = os.environ.get("UE5PILOT_LLM_PROVIDER", "anthropic").lower()
        raw = None
        # We use the same low-level calls from llm_translator but with a different prompt
        try:
            if provider == "anthropic":
                raw = self._call_with_system(DIRECTOR_PLANNING_PROMPT, prompt_user, "anthropic")
            elif provider == "openai":
                raw = self._call_with_system(DIRECTOR_PLANNING_PROMPT, prompt_user, "openai")
        except Exception:
            return None

        if not raw:
            return None

        return self._parse_plan(raw)

    def _call_with_system(self, system: str, user: str, provider: str) -> Optional[str]:
        """Low-level LLM call with custom system prompt."""
        import urllib.request, urllib.error
        api_key = os.environ.get("UE5PILOT_LLM_API_KEY", "").strip()
        if not api_key:
            return None
        model = os.environ.get("UE5PILOT_LLM_MODEL", "").strip()
        if provider == "anthropic":
            body = json.dumps({
                "model": model or "claude-opus-4-7",
                "max_tokens": 3000,
                "system": system,
                "messages": [{"role": "user", "content": user}],
            }).encode("utf-8")
            req = urllib.request.Request(
                "https://api.anthropic.com/v1/messages",
                data=body,
                headers={
                    "x-api-key": api_key,
                    "anthropic-version": "2023-06-01",
                    "content-type": "application/json",
                },
                method="POST",
            )
        else:  # openai
            body = json.dumps({
                "model": model or "gpt-4o",
                "max_tokens": 3000,
                "messages": [
                    {"role": "system", "content": system},
                    {"role": "user", "content": user},
                ],
                "response_format": {"type": "json_object"},
            }).encode("utf-8")
            req = urllib.request.Request(
                "https://api.openai.com/v1/chat/completions",
                data=body,
                headers={"Authorization": f"Bearer {api_key}", "Content-Type": "application/json"},
                method="POST",
            )
        try:
            with urllib.request.urlopen(req, timeout=ITERATION_TIMEOUT) as resp:
                data = json.loads(resp.read().decode("utf-8"))
            if provider == "anthropic":
                for block in data.get("content", []):
                    if block.get("type") == "text":
                        return block.get("text", "")
            else:
                return data["choices"][0]["message"]["content"]
        except Exception:
            return None
        return None

    def _parse_plan(self, raw: str) -> Optional[Dict[str, Any]]:
        """Parse LLM plan response into a structured dict."""
        raw = raw.strip()
        if raw.startswith("```"):
            lines = raw.split("\n")
            raw = "\n".join(lines[1:-1]) if len(lines) > 2 else raw
            if raw.startswith("json"):
                raw = raw[4:].strip()
        try:
            parsed = json.loads(raw)
        except json.JSONDecodeError:
            start = raw.find("{")
            end = raw.rfind("}")
            if start != -1 and end != -1 and end > start:
                try:
                    parsed = json.loads(raw[start:end + 1])
                except json.JSONDecodeError:
                    return None
            else:
                return None
        if not isinstance(parsed, dict):
            return None
        commands = parsed.get("commands", [])
        if not isinstance(commands, list):
            return None
        # Validate each command
        clean_commands = []
        for c in commands:
            if isinstance(c, dict) and "command" in c:
                clean_commands.append({
                    "command": str(c["command"]),
                    "args": c.get("args", {}) if isinstance(c.get("args"), dict) else {},
                    "reason": str(c.get("reason", "")),
                })
        return {
            "plan_summary": str(parsed.get("plan_summary", "")),
            "commands": clean_commands,
        }

    def _execute_command(self, cmd: Dict[str, Any]) -> Dict[str, Any]:
        """Call the user-provided executor function safely."""
        try:
            return self.executor(cmd["command"], cmd.get("args", {})) or {"status": "ok"}
        except Exception as e:
            return {"status": "error", "error": str(e)}

    def _build_correction_intent(self, original: str, gaps: List[str], suggestions: List[Dict]) -> str:
        """Construct a refined intent for the next iteration."""
        parts = [f"Continuing work on: {original}"]
        if gaps:
            parts.append("Issues to address:")
            for g in gaps[:5]:
                parts.append(f"  - {g}")
        if suggestions:
            parts.append("Suggested adjustments:")
            for s in suggestions[:5]:
                if isinstance(s, dict):
                    parts.append(f"  - {s.get('reason', s.get('command', ''))}")
        return "\n".join(parts)

    def _finalize(self, session: Dict[str, Any], started_at: float) -> Dict[str, Any]:
        session["duration_seconds"] = round(time.time() - started_at, 2)
        return session


# ---------------------------------------------------------------------------
# Convenience function for the simple case
# ---------------------------------------------------------------------------

def direct_scene(
    intent: str,
    executor: ExecutorFunc,
    screenshot: Optional[ScreenshotFunc] = None,
) -> Dict[str, Any]:
    """One-shot direction. See AIDirector class for full control."""
    return AIDirector(executor=executor, screenshot=screenshot).direct(intent)


if __name__ == "__main__":
    print("UE5Pilot AI Director")
    print(f"  LLM available:    {LLM_AVAILABLE}")
    print(f"  Vision available: {VISION_AVAILABLE}")
    print(f"  Max iterations:   {MAX_ITERATIONS}")
    print(f"  Min match score:  {MIN_MATCH_SCORE}")
    print()
    print("To use: provide an executor function that sends commands to UE5,")
    print("optionally a screenshot function that returns PNG bytes.")
