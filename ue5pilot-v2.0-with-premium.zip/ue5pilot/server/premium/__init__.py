"""
UE5Pilot Premium Features

10 modules that turn the regex tool into a full AI-powered platform:
  1. llm_translator  — LLM-backed NL → command translation
  2. sessions        — Multi-user workspaces, roles, presence
  3. director        — AI Director (plan/execute/see/iterate)
  4. vision          — Screenshot assessment via vision models
  5. marketplace     — Quixel/Sketchfab/Fab asset search & import
  6. cinematic       — Movie Render Queue MP4 production
  7. vcs             — Scene version control with branching
  8. voice           — STT (Whisper) + TTS (ElevenLabs/OpenAI)
  9. rag             — Project-aware retrieval over UE5 assets
 10. enterprise      — Multi-tenancy, SSO, RBAC, Stripe billing

Each module is independently importable. Missing dependencies degrade
gracefully rather than crashing the server.
"""

__version__ = "1.0.0"
