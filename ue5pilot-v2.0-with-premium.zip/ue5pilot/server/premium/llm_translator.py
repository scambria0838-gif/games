"""
UE5Pilot LLM-Backed Natural Language Translator

Replacement for the regex-based nl_translator.py. Uses Claude or OpenAI to
interpret a user's natural-language request and return a list of UE5 commands.

Configuration via environment variables:
  UE5PILOT_LLM_PROVIDER   = "anthropic" | "openai" | "regex"  (default: regex)
  UE5PILOT_LLM_API_KEY    = your API key
  UE5PILOT_LLM_MODEL      = override default model (optional)

Fallback behavior:
  - If LLM provider is unset/unreachable, falls back to regex translator
  - If LLM returns malformed JSON, falls back to regex translator
  - This guarantees the system keeps working even if the LLM is down
"""

from __future__ import annotations

import json
import os
import urllib.request
import urllib.error
from typing import List, Dict, Any, Optional

# Fall back to the regex translator when LLM is unavailable
try:
    from nl_translator import translate as regex_translate
except ImportError:
    def regex_translate(text: str) -> List[Dict[str, Any]]:
        return []


# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------

PROVIDER = os.environ.get("UE5PILOT_LLM_PROVIDER", "regex").strip().lower()
API_KEY = os.environ.get("UE5PILOT_LLM_API_KEY", "").strip()
MODEL_OVERRIDE = os.environ.get("UE5PILOT_LLM_MODEL", "").strip()

DEFAULT_MODELS = {
    "anthropic": "claude-opus-4-7",
    "openai": "gpt-4o",
}

REQUEST_TIMEOUT = 30  # seconds
MAX_TOKENS = 2000


# ---------------------------------------------------------------------------
# Skill catalog — passed to the LLM so it knows what's available
# ---------------------------------------------------------------------------

SKILL_CATALOG = """
Available UE5 commands. Pick one or more to fulfill the user's request.
Each command takes specific arguments. Return a JSON array of command objects.

# LIGHTING
- add_directional_light: {intensity: float, color_temp_kelvin: int, rotation: [pitch,yaw,roll]}
- add_point_light: {location: [x,y,z], intensity: float, color_temp_kelvin: int, attenuation_radius: float}
- add_spot_light: {location: [x,y,z], rotation: [pitch,yaw,roll], inner_cone: float, outer_cone: float, intensity: float}
- add_sky_light: {intensity: float, source_cubemap: string}
- adjust_light: {name: string, intensity: float, color_temp_kelvin: int}
- light_scene: {preset: "cinematic"|"noir"|"daylight"|"night"|"golden_hour"|"horror"|"neon"|"studio_3point"|"overcast"|"blue_hour"}

# PLACEMENT
- spawn_actor: {mesh_path: string, location: [x,y,z], rotation: [pitch,yaw,roll], scale: [x,y,z], name: string}
- move_actor: {name: string, location: [x,y,z]}
- rotate_actor: {name: string, rotation: [pitch,yaw,roll]}
- scale_actor: {name: string, scale: float | [x,y,z]}
- scatter_props: {mesh_path: string, count: int, radius: float}
- delete_actor: {name: string}
- delete_duplicates: {prefix: string}

# ENVIRONMENT
- add_exponential_height_fog: {density: float, falloff: float, color: [r,g,b]}
- add_sky_atmosphere: {}
- add_volumetric_cloud: {coverage: float, density: float}
- add_post_process_volume: {preset: "cinematic"|"horror"|"neon"|"natural"}
- set_skybox: {style: "day"|"night"|"sunset"|"overcast"|"space"}
- add_foliage: {mesh_path: string, density: float, scale_min: float, scale_max: float}
- add_landscape: {preset: "mountain"|"plains"|"desert"|"coastal"}
- add_water_body: {type: "ocean"|"river"|"lake", size: float}

# VFX / NIAGARA
- add_niagara_effect: {effect: "fire"|"smoke"|"water"|"rain"|"explosion", location: [x,y,z], intensity: float}

# AUDIO
- add_audio_ambient: {environment: "outdoor"|"indoor"|"urban"|"forest"|"cave"|"underwater", volume: float}

# AI / CHARACTERS
- setup_ai_character: {name: string, pattern: "basic"|"patrol"|"combat"}
- add_navmesh: {bounds: [x,y,z]}

# CAMERA / VIEW
- frame_viewport: {target: string}
- take_screenshot: {}

# CINEMATICS
- setup_cinematic: {duration: float, camera_path: "dolly"|"orbit"|"static"|"crane", target: string}

# OPTIMIZATION
- optimize_scene: {target_fps: int, platform: "pc"|"console"|"mobile"}

# UTILITY
- save_to_file: {path: string}
- load_from_file: {path: string}
- clear_scene: {confirm: true}
- undo_last_command: {}
- explain_scene: {}

# KNOWLEDGE QUERIES
- query_knowledge: {query: string}
- explain_ue5_concept: {concept: string}
"""


SYSTEM_PROMPT = f"""You are UE5Pilot, an AI that controls Unreal Engine 5 via a remote command API.

A user will describe what they want in plain English. Your job is to translate that into a JSON array of one or more commands.

{SKILL_CATALOG}

RULES:
1. Return ONLY a JSON array. No explanation, no markdown fences, no prose.
2. Each command must be a JSON object with: "command" (string), "args" (object), "confidence" (0.0-1.0).
3. For complex requests, return multiple commands in the order they should execute.
4. Use the lighting preset that best matches mood (cinematic for dramatic, noir for dark/contrasty, golden_hour for warm sunset, horror for eerie, etc).
5. If the user's request is vague, pick reasonable defaults. Confidence reflects how sure you are.
6. If the request cannot be fulfilled with available commands, return an empty array [].

EXAMPLES:

User: "make this scene look like Blade Runner"
Response: [
  {{"command": "light_scene", "args": {{"preset": "neon"}}, "confidence": 0.9}},
  {{"command": "add_exponential_height_fog", "args": {{"density": 0.5, "falloff": 0.2, "color": [0.1, 0.2, 0.4]}}, "confidence": 0.85}},
  {{"command": "add_post_process_volume", "args": {{"preset": "cinematic"}}, "confidence": 0.85}}
]

User: "add a forest with morning light"
Response: [
  {{"command": "scatter_props", "args": {{"mesh_path": "/Game/Foliage/Tree", "count": 50, "radius": 3000}}, "confidence": 0.9}},
  {{"command": "scatter_props", "args": {{"mesh_path": "/Game/Foliage/Rock", "count": 15, "radius": 3000}}, "confidence": 0.85}},
  {{"command": "light_scene", "args": {{"preset": "golden_hour"}}, "confidence": 0.9}}
]

User: "undo that"
Response: [{{"command": "undo_last_command", "args": {{}}, "confidence": 0.98}}]
"""


# ---------------------------------------------------------------------------
# Provider implementations
# ---------------------------------------------------------------------------

def _call_anthropic(user_text: str) -> Optional[str]:
    """Call Anthropic Messages API. Returns the raw text response or None on failure."""
    if not API_KEY:
        return None
    model = MODEL_OVERRIDE or DEFAULT_MODELS["anthropic"]
    body = json.dumps({
        "model": model,
        "max_tokens": MAX_TOKENS,
        "system": SYSTEM_PROMPT,
        "messages": [{"role": "user", "content": user_text}],
    }).encode("utf-8")
    req = urllib.request.Request(
        "https://api.anthropic.com/v1/messages",
        data=body,
        headers={
            "x-api-key": API_KEY,
            "anthropic-version": "2023-06-01",
            "content-type": "application/json",
        },
        method="POST",
    )
    try:
        with urllib.request.urlopen(req, timeout=REQUEST_TIMEOUT) as resp:
            data = json.loads(resp.read().decode("utf-8"))
        # Anthropic returns content as an array of blocks
        for block in data.get("content", []):
            if block.get("type") == "text":
                return block.get("text", "")
        return None
    except (urllib.error.URLError, urllib.error.HTTPError, json.JSONDecodeError, KeyError):
        return None


def _call_openai(user_text: str) -> Optional[str]:
    """Call OpenAI Chat Completions API. Returns the raw text response or None on failure."""
    if not API_KEY:
        return None
    model = MODEL_OVERRIDE or DEFAULT_MODELS["openai"]
    body = json.dumps({
        "model": model,
        "max_tokens": MAX_TOKENS,
        "messages": [
            {"role": "system", "content": SYSTEM_PROMPT},
            {"role": "user", "content": user_text},
        ],
        "response_format": {"type": "json_object"},
    }).encode("utf-8")
    req = urllib.request.Request(
        "https://api.openai.com/v1/chat/completions",
        data=body,
        headers={
            "Authorization": f"Bearer {API_KEY}",
            "Content-Type": "application/json",
        },
        method="POST",
    )
    try:
        with urllib.request.urlopen(req, timeout=REQUEST_TIMEOUT) as resp:
            data = json.loads(resp.read().decode("utf-8"))
        return data["choices"][0]["message"]["content"]
    except (urllib.error.URLError, urllib.error.HTTPError, json.JSONDecodeError, KeyError):
        return None


# ---------------------------------------------------------------------------
# Response parsing
# ---------------------------------------------------------------------------

def _parse_llm_response(raw: str) -> List[Dict[str, Any]]:
    """Parse the LLM's raw text into a list of validated command dicts."""
    if not raw:
        return []
    # Strip markdown code fences if present
    raw = raw.strip()
    if raw.startswith("```"):
        lines = raw.split("\n")
        # remove first and last fence lines
        raw = "\n".join(lines[1:-1]) if len(lines) > 2 else raw
        if raw.startswith("json"):
            raw = raw[4:].strip()
    # OpenAI's json_object mode wraps in an object; extract the array if so
    try:
        parsed = json.loads(raw)
    except json.JSONDecodeError:
        # Try to find a JSON array inside the text
        start = raw.find("[")
        end = raw.rfind("]")
        if start != -1 and end != -1 and end > start:
            try:
                parsed = json.loads(raw[start:end + 1])
            except json.JSONDecodeError:
                return []
        else:
            return []
    # Handle if LLM returned {"commands": [...]} instead of bare array
    if isinstance(parsed, dict):
        for key in ("commands", "result", "actions"):
            if key in parsed and isinstance(parsed[key], list):
                parsed = parsed[key]
                break
        else:
            # Single command object — wrap it
            if "command" in parsed:
                parsed = [parsed]
            else:
                return []
    if not isinstance(parsed, list):
        return []
    # Validate each command has required fields
    cleaned = []
    for item in parsed:
        if not isinstance(item, dict):
            continue
        if "command" not in item:
            continue
        cleaned.append({
            "command": str(item["command"]),
            "args": item.get("args", {}) if isinstance(item.get("args"), dict) else {},
            "confidence": float(item.get("confidence", 0.8)),
        })
    return cleaned


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def translate(text: str) -> List[Dict[str, Any]]:
    """
    Translate a natural-language request into a list of UE5 commands.

    Routes to the configured LLM provider, falling back to the regex translator
    if anything fails. Always returns a list (possibly empty).
    """
    if not isinstance(text, str) or not text.strip():
        return []
    text = text.strip()

    raw = None
    if PROVIDER == "anthropic":
        raw = _call_anthropic(text)
    elif PROVIDER == "openai":
        raw = _call_openai(text)

    if raw:
        commands = _parse_llm_response(raw)
        if commands:
            return commands

    # Fallback to regex
    return regex_translate(text)


def get_provider_info() -> Dict[str, Any]:
    """Diagnostic info — useful for /health and /version endpoints."""
    return {
        "provider": PROVIDER,
        "model": MODEL_OVERRIDE or DEFAULT_MODELS.get(PROVIDER, "n/a"),
        "api_key_configured": bool(API_KEY),
        "regex_fallback_available": True,
    }


# ---------------------------------------------------------------------------
# Demo
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    print("UE5Pilot LLM Translator")
    print("Provider info:", get_provider_info())
    print()
    samples = [
        "make this scene look like Blade Runner 2049",
        "add a forest with morning light",
        "undo that",
        "make it look like a Wes Anderson film",
        "set up an enemy patrol AI on that character",
    ]
    for s in samples:
        result = translate(s)
        print(f"INPUT:  {s}")
        print(f"OUTPUT: {json.dumps(result, indent=2)}")
        print()
