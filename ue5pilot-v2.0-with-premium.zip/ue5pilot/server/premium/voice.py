"""
UE5Pilot Voice Control + TTS

Two halves:
  1. Speech-to-text — converts microphone audio into text commands
     Supports OpenAI Whisper (cloud) or local whisper.cpp
  2. Text-to-speech — speaks the AI's responses back
     Supports ElevenLabs (best quality) or OpenAI TTS

The cloud server doesn't actually capture audio — the customer's Windows
companion does that and posts the WAV/MP3 to /voice/transcribe.
TTS audio is generated server-side and sent back to play on the customer's PC.

Configuration:
  UE5PILOT_STT_PROVIDER       = "openai_whisper" | "local_whisper"
  UE5PILOT_STT_API_KEY        = OpenAI key (if using openai_whisper)
  UE5PILOT_TTS_PROVIDER       = "elevenlabs" | "openai"
  UE5PILOT_TTS_API_KEY        = provider API key
  UE5PILOT_TTS_VOICE          = voice ID (provider-specific)
"""

from __future__ import annotations

import base64
import json
import os
import urllib.request
import urllib.error
from typing import Dict, Any, Optional, Union


REQUEST_TIMEOUT = 60


# ---------------------------------------------------------------------------
# Speech-to-Text
# ---------------------------------------------------------------------------

def transcribe_audio(audio_bytes: bytes, mime_type: str = "audio/wav") -> Dict[str, Any]:
    """
    Transcribe audio to text. Returns:
      {"text": "...", "language": "en", "duration_seconds": float} on success
      {"error": "..."} on failure
    """
    provider = os.environ.get("UE5PILOT_STT_PROVIDER", "openai_whisper").lower()

    if provider == "openai_whisper":
        return _openai_whisper_transcribe(audio_bytes, mime_type)
    elif provider == "local_whisper":
        return _local_whisper_transcribe(audio_bytes, mime_type)
    else:
        return {"error": f"unsupported STT provider: {provider}"}


def _openai_whisper_transcribe(audio_bytes: bytes, mime_type: str) -> Dict[str, Any]:
    api_key = os.environ.get("UE5PILOT_STT_API_KEY", "").strip()
    if not api_key:
        return {"error": "UE5PILOT_STT_API_KEY not configured"}

    # Build multipart/form-data manually (stdlib doesn't have a clean multipart helper)
    boundary = "----UE5PilotBoundary" + os.urandom(8).hex()
    parts = []
    ext = "wav" if "wav" in mime_type else ("mp3" if "mp3" in mime_type or "mpeg" in mime_type else "webm")
    parts.append(f"--{boundary}\r\nContent-Disposition: form-data; name=\"model\"\r\n\r\nwhisper-1".encode())
    parts.append(f"\r\n--{boundary}\r\nContent-Disposition: form-data; name=\"response_format\"\r\n\r\nverbose_json".encode())
    parts.append(f"\r\n--{boundary}\r\nContent-Disposition: form-data; name=\"file\"; filename=\"audio.{ext}\"\r\nContent-Type: {mime_type}\r\n\r\n".encode())
    parts.append(audio_bytes)
    parts.append(f"\r\n--{boundary}--\r\n".encode())
    body = b"".join(parts)

    req = urllib.request.Request(
        "https://api.openai.com/v1/audio/transcriptions",
        data=body,
        headers={
            "Authorization": f"Bearer {api_key}",
            "Content-Type": f"multipart/form-data; boundary={boundary}",
        },
        method="POST",
    )
    try:
        with urllib.request.urlopen(req, timeout=REQUEST_TIMEOUT) as resp:
            data = json.loads(resp.read().decode("utf-8"))
        return {
            "text": data.get("text", ""),
            "language": data.get("language", "en"),
            "duration_seconds": data.get("duration", 0.0),
        }
    except (urllib.error.URLError, urllib.error.HTTPError, json.JSONDecodeError) as e:
        return {"error": f"transcription failed: {e}"}


def _local_whisper_transcribe(audio_bytes: bytes, mime_type: str) -> Dict[str, Any]:
    """Run whisper.cpp locally. Requires whisper.cpp binary in PATH."""
    import subprocess, tempfile
    binary = os.environ.get("UE5PILOT_WHISPER_BIN", "whisper")
    model = os.environ.get("UE5PILOT_WHISPER_MODEL", "")
    try:
        with tempfile.NamedTemporaryFile(suffix=".wav", delete=False) as tmp:
            tmp.write(audio_bytes)
            tmp_path = tmp.name
        cmd = [binary, "-f", tmp_path, "--output-json"]
        if model:
            cmd += ["-m", model]
        result = subprocess.run(cmd, capture_output=True, timeout=REQUEST_TIMEOUT)
        os.unlink(tmp_path)
        if result.returncode != 0:
            return {"error": f"local whisper failed: {result.stderr.decode('utf-8', errors='ignore')[:200]}"}
        # whisper.cpp outputs alongside the input; for simplicity return its stdout
        return {"text": result.stdout.decode("utf-8", errors="ignore").strip(), "language": "en"}
    except FileNotFoundError:
        return {"error": "whisper binary not found in PATH"}
    except Exception as e:
        return {"error": f"local whisper error: {e}"}


# ---------------------------------------------------------------------------
# Text-to-Speech
# ---------------------------------------------------------------------------

def synthesize_speech(text: str, voice: Optional[str] = None) -> Dict[str, Any]:
    """
    Synthesize speech from text. Returns:
      {"audio_base64": "...", "mime_type": "audio/mp3"} on success
      {"error": "..."} on failure
    """
    provider = os.environ.get("UE5PILOT_TTS_PROVIDER", "elevenlabs").lower()
    voice = voice or os.environ.get("UE5PILOT_TTS_VOICE", "")

    if not text or not isinstance(text, str):
        return {"error": "text is required"}

    if provider == "elevenlabs":
        return _elevenlabs_tts(text, voice)
    elif provider == "openai":
        return _openai_tts(text, voice)
    else:
        return {"error": f"unsupported TTS provider: {provider}"}


def _elevenlabs_tts(text: str, voice: str) -> Dict[str, Any]:
    api_key = os.environ.get("UE5PILOT_TTS_API_KEY", "").strip()
    if not api_key:
        return {"error": "UE5PILOT_TTS_API_KEY not configured"}
    # Default to ElevenLabs 'Rachel' voice if none specified
    voice_id = voice or "21m00Tcm4TlvDq8ikWAM"
    url = f"https://api.elevenlabs.io/v1/text-to-speech/{voice_id}"
    body = json.dumps({
        "text": text,
        "model_id": "eleven_turbo_v2_5",
        "voice_settings": {"stability": 0.5, "similarity_boost": 0.75},
    }).encode("utf-8")
    req = urllib.request.Request(
        url,
        data=body,
        headers={
            "xi-api-key": api_key,
            "Content-Type": "application/json",
            "Accept": "audio/mpeg",
        },
        method="POST",
    )
    try:
        with urllib.request.urlopen(req, timeout=REQUEST_TIMEOUT) as resp:
            audio = resp.read()
        return {
            "audio_base64": base64.b64encode(audio).decode("ascii"),
            "mime_type": "audio/mp3",
            "size_bytes": len(audio),
        }
    except (urllib.error.URLError, urllib.error.HTTPError) as e:
        return {"error": f"elevenlabs TTS failed: {e}"}


def _openai_tts(text: str, voice: str) -> Dict[str, Any]:
    api_key = os.environ.get("UE5PILOT_TTS_API_KEY", "").strip()
    if not api_key:
        return {"error": "UE5PILOT_TTS_API_KEY not configured"}
    voice = voice or "alloy"  # alloy, echo, fable, onyx, nova, shimmer
    body = json.dumps({
        "model": "tts-1",
        "input": text,
        "voice": voice,
        "response_format": "mp3",
    }).encode("utf-8")
    req = urllib.request.Request(
        "https://api.openai.com/v1/audio/speech",
        data=body,
        headers={"Authorization": f"Bearer {api_key}", "Content-Type": "application/json"},
        method="POST",
    )
    try:
        with urllib.request.urlopen(req, timeout=REQUEST_TIMEOUT) as resp:
            audio = resp.read()
        return {
            "audio_base64": base64.b64encode(audio).decode("ascii"),
            "mime_type": "audio/mp3",
            "size_bytes": len(audio),
        }
    except (urllib.error.URLError, urllib.error.HTTPError) as e:
        return {"error": f"openai TTS failed: {e}"}


# ---------------------------------------------------------------------------
# Combined voice command flow
# ---------------------------------------------------------------------------

def voice_command(audio_bytes: bytes, mime_type: str = "audio/wav",
                  speak_response: bool = True) -> Dict[str, Any]:
    """
    Full voice flow: transcribe → translate → return text + optional TTS audio.

    The caller (server) takes the transcribed text and runs the LLM translator
    on it. This function just handles audio in / audio out.
    """
    trans = transcribe_audio(audio_bytes, mime_type)
    if "error" in trans:
        return {"status": "stt_failed", **trans}
    return {
        "status": "transcribed",
        "text": trans.get("text", ""),
        "language": trans.get("language", "en"),
        "duration_seconds": trans.get("duration_seconds", 0.0),
        "speak_response_requested": speak_response,
    }


def get_voice_info() -> Dict[str, Any]:
    return {
        "stt_provider": os.environ.get("UE5PILOT_STT_PROVIDER", "openai_whisper"),
        "stt_configured": bool(os.environ.get("UE5PILOT_STT_API_KEY")),
        "tts_provider": os.environ.get("UE5PILOT_TTS_PROVIDER", "elevenlabs"),
        "tts_configured": bool(os.environ.get("UE5PILOT_TTS_API_KEY")),
        "tts_voice": os.environ.get("UE5PILOT_TTS_VOICE", "default"),
    }


if __name__ == "__main__":
    print("UE5Pilot Voice")
    print(json.dumps(get_voice_info(), indent=2))
