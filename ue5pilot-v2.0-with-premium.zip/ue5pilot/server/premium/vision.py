"""
UE5Pilot Vision Feedback Module

Analyzes a screenshot (PNG bytes or base64) using Claude Vision or GPT-4V.
Returns a structured assessment of whether the scene matches the intent,
plus suggested follow-up commands if it doesn't.

Used by the AI Director to close the loop: see what was built, evaluate,
iterate until the result matches the user's creative intent.

Configuration via environment variables:
  UE5PILOT_LLM_PROVIDER   = "anthropic" | "openai"
  UE5PILOT_LLM_API_KEY    = your API key
  UE5PILOT_VISION_MODEL   = override default vision model (optional)
"""

from __future__ import annotations

import base64
import json
import os
import urllib.request
import urllib.error
from typing import Dict, Any, Optional, Union


# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------

PROVIDER = os.environ.get("UE5PILOT_LLM_PROVIDER", "anthropic").strip().lower()
API_KEY = os.environ.get("UE5PILOT_LLM_API_KEY", "").strip()
MODEL_OVERRIDE = os.environ.get("UE5PILOT_VISION_MODEL", "").strip()

DEFAULT_VISION_MODELS = {
    "anthropic": "claude-opus-4-7",     # Claude vision-capable
    "openai": "gpt-4o",                  # GPT-4 vision-capable
}

REQUEST_TIMEOUT = 60  # vision calls are slower
MAX_TOKENS = 1500


# ---------------------------------------------------------------------------
# Prompts
# ---------------------------------------------------------------------------

ASSESSMENT_PROMPT_TEMPLATE = """You are evaluating a screenshot from an Unreal Engine 5 scene.

The user requested: "{intent}"

Look at the screenshot and assess whether the scene matches their intent.

Respond with a JSON object containing:
{{
  "matches_intent": true | false,
  "match_score": 0.0 to 1.0,
  "observations": "What you see in the scene",
  "gaps": ["specific things missing or wrong"],
  "suggestions": [
    {{"command": "...", "args": {{}}, "reason": "why this would help"}}
  ]
}}

Be specific. If lighting is wrong, say HOW it's wrong (too warm, too bright, wrong angle).
If actors are missing, name them. If composition is off, explain.

Return ONLY the JSON object. No prose, no markdown fences.
"""


# ---------------------------------------------------------------------------
# Provider implementations
# ---------------------------------------------------------------------------

def _ensure_base64(image: Union[bytes, str]) -> str:
    """Accept either raw PNG bytes or a base64 string. Return base64 string."""
    if isinstance(image, bytes):
        return base64.b64encode(image).decode("ascii")
    if isinstance(image, str):
        # Strip data URI prefix if present
        if image.startswith("data:"):
            image = image.split(",", 1)[-1]
        return image.strip()
    raise TypeError("image must be bytes or base64 string")


def _call_anthropic_vision(image_b64: str, intent: str) -> Optional[str]:
    """Call Claude with vision. Returns raw text response or None."""
    if not API_KEY:
        return None
    model = MODEL_OVERRIDE or DEFAULT_VISION_MODELS["anthropic"]
    body = json.dumps({
        "model": model,
        "max_tokens": MAX_TOKENS,
        "messages": [{
            "role": "user",
            "content": [
                {
                    "type": "image",
                    "source": {
                        "type": "base64",
                        "media_type": "image/png",
                        "data": image_b64,
                    },
                },
                {
                    "type": "text",
                    "text": ASSESSMENT_PROMPT_TEMPLATE.format(intent=intent),
                },
            ],
        }],
    }).encode("utf-8")
    req = urllib.request.Request(
        "https://api.anthropic.com/v1/messages",
        data=body,
        headers={
            "x-api-key": API_KEY,
            "anthropic-version": "2023-06-01",
            "content-type": "application/json",
        },
        method="POST",
    )
    try:
        with urllib.request.urlopen(req, timeout=REQUEST_TIMEOUT) as resp:
            data = json.loads(resp.read().decode("utf-8"))
        for block in data.get("content", []):
            if block.get("type") == "text":
                return block.get("text", "")
        return None
    except (urllib.error.URLError, urllib.error.HTTPError, json.JSONDecodeError, KeyError):
        return None


def _call_openai_vision(image_b64: str, intent: str) -> Optional[str]:
    """Call GPT-4V. Returns raw text response or None."""
    if not API_KEY:
        return None
    model = MODEL_OVERRIDE or DEFAULT_VISION_MODELS["openai"]
    body = json.dumps({
        "model": model,
        "max_tokens": MAX_TOKENS,
        "messages": [{
            "role": "user",
            "content": [
                {"type": "text", "text": ASSESSMENT_PROMPT_TEMPLATE.format(intent=intent)},
                {
                    "type": "image_url",
                    "image_url": {"url": f"data:image/png;base64,{image_b64}"},
                },
            ],
        }],
        "response_format": {"type": "json_object"},
    }).encode("utf-8")
    req = urllib.request.Request(
        "https://api.openai.com/v1/chat/completions",
        data=body,
        headers={
            "Authorization": f"Bearer {API_KEY}",
            "Content-Type": "application/json",
        },
        method="POST",
    )
    try:
        with urllib.request.urlopen(req, timeout=REQUEST_TIMEOUT) as resp:
            data = json.loads(resp.read().decode("utf-8"))
        return data["choices"][0]["message"]["content"]
    except (urllib.error.URLError, urllib.error.HTTPError, json.JSONDecodeError, KeyError):
        return None


# ---------------------------------------------------------------------------
# Response parsing
# ---------------------------------------------------------------------------

def _parse_assessment(raw: str) -> Dict[str, Any]:
    """Parse the LLM's assessment into a structured dict. Defensive."""
    if not raw:
        return _empty_assessment("no response from vision model")
    raw = raw.strip()
    # Strip markdown fences
    if raw.startswith("```"):
        lines = raw.split("\n")
        raw = "\n".join(lines[1:-1]) if len(lines) > 2 else raw
        if raw.startswith("json"):
            raw = raw[4:].strip()
    # Try to parse
    try:
        parsed = json.loads(raw)
    except json.JSONDecodeError:
        # Try to find a JSON object inside the text
        start = raw.find("{")
        end = raw.rfind("}")
        if start != -1 and end != -1 and end > start:
            try:
                parsed = json.loads(raw[start:end + 1])
            except json.JSONDecodeError:
                return _empty_assessment("malformed JSON in vision response")
        else:
            return _empty_assessment("no JSON object in vision response")
    if not isinstance(parsed, dict):
        return _empty_assessment("vision response was not a dict")
    # Normalize fields
    return {
        "matches_intent": bool(parsed.get("matches_intent", False)),
        "match_score": float(parsed.get("match_score", 0.0)),
        "observations": str(parsed.get("observations", "")),
        "gaps": parsed.get("gaps", []) if isinstance(parsed.get("gaps"), list) else [],
        "suggestions": parsed.get("suggestions", []) if isinstance(parsed.get("suggestions"), list) else [],
        "raw_response": raw,
    }


def _empty_assessment(reason: str) -> Dict[str, Any]:
    return {
        "matches_intent": False,
        "match_score": 0.0,
        "observations": "",
        "gaps": [],
        "suggestions": [],
        "error": reason,
    }


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def assess_screenshot(image: Union[bytes, str], intent: str) -> Dict[str, Any]:
    """
    Analyze a screenshot against a user's creative intent.

    Args:
      image:  PNG bytes or base64 string
      intent: The user's original request, e.g. "make this look like Blade Runner"

    Returns a dict with: matches_intent, match_score, observations, gaps, suggestions.
    Never raises — failures return an empty assessment with an "error" key.
    """
    try:
        image_b64 = _ensure_base64(image)
    except TypeError as e:
        return _empty_assessment(str(e))

    if not intent or not isinstance(intent, str):
        return _empty_assessment("intent is required")

    if not API_KEY:
        return _empty_assessment("no API key configured (UE5PILOT_LLM_API_KEY)")

    raw = None
    if PROVIDER == "anthropic":
        raw = _call_anthropic_vision(image_b64, intent)
    elif PROVIDER == "openai":
        raw = _call_openai_vision(image_b64, intent)
    else:
        return _empty_assessment(f"unsupported provider: {PROVIDER}")

    return _parse_assessment(raw or "")


def get_vision_info() -> Dict[str, Any]:
    """Diagnostic info."""
    return {
        "provider": PROVIDER,
        "model": MODEL_OVERRIDE or DEFAULT_VISION_MODELS.get(PROVIDER, "n/a"),
        "api_key_configured": bool(API_KEY),
    }


if __name__ == "__main__":
    print("UE5Pilot Vision Module")
    print("Config:", get_vision_info())
    print("(Run with a real screenshot + API key to test.)")
