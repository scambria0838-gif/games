"""
UE5Pilot Scene Version Control

Git-style branching for UE5 scenes. Snapshots scene state, lets you branch,
compare, and merge.

The unit of versioning is the *scene JSON export* that already exists in v5
(via /export_scene_json). We diff at the actor + property level, not byte level.

Operations:
  snapshot(workspace, label)        — capture current scene state
  list_snapshots(workspace)         — show all snapshots
  branch(workspace, from_snapshot)  — fork into a new branch
  diff(snap_a, snap_b)              — show what changed between two snapshots
  merge(into_branch, from_branch)   — bring changes from one branch into another
  restore(workspace, snapshot_id)   — load a snapshot back into UE5

Storage: SQLite for metadata, JSON files on disk for snapshot content.
"""

from __future__ import annotations

import hashlib
import json
import os
import sqlite3
import threading
import time
import uuid
from contextlib import contextmanager
from typing import Dict, Any, List, Optional, Tuple


# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------

DB_PATH = os.environ.get("UE5PILOT_VCS_DB",
                        os.path.join(os.path.expanduser("~"), ".ue5pilot", "vcs.db"))
SNAPSHOTS_DIR = os.environ.get("UE5PILOT_VCS_SNAPSHOTS_DIR",
                              os.path.join(os.path.expanduser("~"), ".ue5pilot", "snapshots"))

_lock = threading.RLock()

os.makedirs(os.path.dirname(DB_PATH), exist_ok=True)
os.makedirs(SNAPSHOTS_DIR, exist_ok=True)


# ---------------------------------------------------------------------------
# Database
# ---------------------------------------------------------------------------

def _init_db():
    with _connect() as conn:
        conn.executescript("""
            CREATE TABLE IF NOT EXISTS snapshots (
                snapshot_id TEXT PRIMARY KEY,
                workspace_id TEXT NOT NULL,
                branch TEXT NOT NULL,
                parent_id TEXT,
                label TEXT,
                created_at REAL NOT NULL,
                created_by TEXT,
                content_hash TEXT NOT NULL,
                actor_count INTEGER NOT NULL
            );
            CREATE TABLE IF NOT EXISTS branches (
                workspace_id TEXT NOT NULL,
                branch TEXT NOT NULL,
                head_snapshot_id TEXT NOT NULL,
                created_at REAL NOT NULL,
                PRIMARY KEY (workspace_id, branch)
            );
            CREATE INDEX IF NOT EXISTS idx_snap_workspace ON snapshots(workspace_id, branch);
        """)


@contextmanager
def _connect():
    conn = sqlite3.connect(DB_PATH, timeout=10, isolation_level=None)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode=WAL")
    try:
        yield conn
    finally:
        conn.close()


_init_db()


# ---------------------------------------------------------------------------
# Snapshot operations
# ---------------------------------------------------------------------------

def snapshot(workspace_id: str, scene_json: Dict[str, Any],
             label: str = "", branch: str = "main",
             user_id: Optional[str] = None) -> Dict[str, Any]:
    """
    Capture a scene state as a new snapshot. Returns snapshot metadata.
    """
    snap_id = "snap_" + uuid.uuid4().hex[:12]
    content_str = json.dumps(scene_json, sort_keys=True)
    content_hash = hashlib.sha256(content_str.encode("utf-8")).hexdigest()
    actor_count = len(scene_json.get("actors", []))
    now = time.time()

    parent_id = _get_head(workspace_id, branch)

    # Write snapshot content to disk
    snap_path = _snapshot_path(snap_id)
    with open(snap_path, "w", encoding="utf-8") as f:
        f.write(content_str)

    with _lock, _connect() as conn:
        conn.execute("""
            INSERT INTO snapshots (snapshot_id, workspace_id, branch, parent_id, label, created_at, created_by, content_hash, actor_count)
            VALUES (?,?,?,?,?,?,?,?,?)
        """, (snap_id, workspace_id, branch, parent_id, label, now, user_id, content_hash, actor_count))
        conn.execute("""
            INSERT OR REPLACE INTO branches (workspace_id, branch, head_snapshot_id, created_at)
            VALUES (?,?,?,COALESCE((SELECT created_at FROM branches WHERE workspace_id=? AND branch=?), ?))
        """, (workspace_id, branch, snap_id, workspace_id, branch, now))

    return {
        "snapshot_id": snap_id,
        "workspace_id": workspace_id,
        "branch": branch,
        "parent_id": parent_id,
        "label": label,
        "created_at": now,
        "actor_count": actor_count,
        "content_hash": content_hash,
    }


def _snapshot_path(snapshot_id: str) -> str:
    return os.path.join(SNAPSHOTS_DIR, f"{snapshot_id}.json")


def _get_head(workspace_id: str, branch: str) -> Optional[str]:
    with _connect() as conn:
        row = conn.execute(
            "SELECT head_snapshot_id FROM branches WHERE workspace_id=? AND branch=?",
            (workspace_id, branch)
        ).fetchone()
    return row["head_snapshot_id"] if row else None


def load_snapshot(snapshot_id: str) -> Optional[Dict[str, Any]]:
    """Load a snapshot's content (full scene JSON)."""
    path = _snapshot_path(snapshot_id)
    if not os.path.exists(path):
        return None
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)


def list_snapshots(workspace_id: str, branch: Optional[str] = None,
                   limit: int = 100) -> List[Dict[str, Any]]:
    with _connect() as conn:
        if branch:
            rows = conn.execute("""
                SELECT * FROM snapshots WHERE workspace_id=? AND branch=?
                ORDER BY created_at DESC LIMIT ?
            """, (workspace_id, branch, limit)).fetchall()
        else:
            rows = conn.execute("""
                SELECT * FROM snapshots WHERE workspace_id=?
                ORDER BY created_at DESC LIMIT ?
            """, (workspace_id, limit)).fetchall()
    return [dict(r) for r in rows]


def list_branches(workspace_id: str) -> List[Dict[str, Any]]:
    with _connect() as conn:
        rows = conn.execute("SELECT * FROM branches WHERE workspace_id=?", (workspace_id,)).fetchall()
    return [dict(r) for r in rows]


# ---------------------------------------------------------------------------
# Branching
# ---------------------------------------------------------------------------

def branch_from(workspace_id: str, source_branch: str, new_branch: str,
                user_id: Optional[str] = None) -> Dict[str, Any]:
    """Create a new branch starting from the head of source_branch."""
    head = _get_head(workspace_id, source_branch)
    if not head:
        raise ValueError(f"source branch {source_branch!r} has no snapshots")
    if _get_head(workspace_id, new_branch):
        raise ValueError(f"branch {new_branch!r} already exists")
    now = time.time()
    with _lock, _connect() as conn:
        conn.execute("INSERT INTO branches (workspace_id, branch, head_snapshot_id, created_at) VALUES (?,?,?,?)",
                     (workspace_id, new_branch, head, now))
    return {
        "workspace_id": workspace_id,
        "branch": new_branch,
        "forked_from": source_branch,
        "head_snapshot_id": head,
    }


# ---------------------------------------------------------------------------
# Diffing
# ---------------------------------------------------------------------------

def diff_snapshots(snap_a_id: str, snap_b_id: str) -> Dict[str, Any]:
    """Compare two snapshots at the actor level. Returns added/removed/modified."""
    a = load_snapshot(snap_a_id)
    b = load_snapshot(snap_b_id)
    if not a or not b:
        raise ValueError("one or both snapshots not found")

    a_actors = {act.get("name", f"_actor_{i}"): act for i, act in enumerate(a.get("actors", []))}
    b_actors = {act.get("name", f"_actor_{i}"): act for i, act in enumerate(b.get("actors", []))}

    added = [name for name in b_actors if name not in a_actors]
    removed = [name for name in a_actors if name not in b_actors]
    modified = []

    for name in a_actors:
        if name in b_actors:
            a_a = a_actors[name]
            b_a = b_actors[name]
            if json.dumps(a_a, sort_keys=True) != json.dumps(b_a, sort_keys=True):
                modified.append({
                    "name": name,
                    "changes": _shallow_diff(a_a, b_a),
                })

    return {
        "snapshot_a": snap_a_id,
        "snapshot_b": snap_b_id,
        "added": added,
        "removed": removed,
        "modified": modified,
        "summary": f"+{len(added)} -{len(removed)} ~{len(modified)}",
    }


def _shallow_diff(a: Dict, b: Dict) -> Dict[str, Any]:
    """Compare top-level keys, return changed fields."""
    changes = {}
    all_keys = set(a.keys()) | set(b.keys())
    for k in all_keys:
        if a.get(k) != b.get(k):
            changes[k] = {"from": a.get(k), "to": b.get(k)}
    return changes


# ---------------------------------------------------------------------------
# Merging (basic three-way merge by actor name)
# ---------------------------------------------------------------------------

def merge_branches(workspace_id: str, into_branch: str, from_branch: str,
                   user_id: Optional[str] = None,
                   conflict_strategy: str = "from_wins") -> Dict[str, Any]:
    """
    Three-way merge of from_branch into into_branch.

    conflict_strategy:
      'from_wins'  — incoming changes overwrite local
      'into_wins'  — local changes preserved
      'manual'     — return conflicts list, do not auto-merge
    """
    into_head = _get_head(workspace_id, into_branch)
    from_head = _get_head(workspace_id, from_branch)
    if not into_head or not from_head:
        raise ValueError("both branches must exist")

    into_snap = load_snapshot(into_head)
    from_snap = load_snapshot(from_head)
    if not into_snap or not from_snap:
        raise ValueError("snapshot files missing")

    into_actors = {act.get("name", f"_actor_{i}"): act for i, act in enumerate(into_snap.get("actors", []))}
    from_actors = {act.get("name", f"_actor_{i}"): act for i, act in enumerate(from_snap.get("actors", []))}

    merged_actors = dict(into_actors)
    conflicts = []

    for name, from_actor in from_actors.items():
        if name not in into_actors:
            merged_actors[name] = from_actor
        else:
            into_actor = into_actors[name]
            if json.dumps(into_actor, sort_keys=True) != json.dumps(from_actor, sort_keys=True):
                conflicts.append({"name": name, "into": into_actor, "from": from_actor})
                if conflict_strategy == "from_wins":
                    merged_actors[name] = from_actor
                # into_wins: keep existing
                # manual: keep existing for now, conflicts reported below

    if conflict_strategy == "manual" and conflicts:
        return {
            "status": "conflicts",
            "conflicts": conflicts,
            "into_branch": into_branch,
            "from_branch": from_branch,
        }

    merged_scene = {**into_snap, "actors": list(merged_actors.values())}
    new_snap = snapshot(workspace_id, merged_scene,
                       label=f"merge {from_branch} into {into_branch}",
                       branch=into_branch, user_id=user_id)
    return {
        "status": "merged",
        "new_snapshot": new_snap,
        "conflicts_resolved": len(conflicts),
        "strategy": conflict_strategy,
    }


# ---------------------------------------------------------------------------
# Restore
# ---------------------------------------------------------------------------

def get_restore_payload(snapshot_id: str) -> Optional[Dict[str, Any]]:
    """
    Return the scene JSON for a snapshot, ready to send back to UE5
    via /import_scene_json.
    """
    return load_snapshot(snapshot_id)


# ---------------------------------------------------------------------------
# Diagnostic
# ---------------------------------------------------------------------------

def get_vcs_info() -> Dict[str, Any]:
    with _connect() as conn:
        total_snaps = conn.execute("SELECT COUNT(*) AS n FROM snapshots").fetchone()["n"]
        total_branches = conn.execute("SELECT COUNT(*) AS n FROM branches").fetchone()["n"]
    return {
        "db_path": DB_PATH,
        "snapshots_dir": SNAPSHOTS_DIR,
        "total_snapshots": total_snaps,
        "total_branches": total_branches,
    }


if __name__ == "__main__":
    print("UE5Pilot Scene Version Control")
    print(json.dumps(get_vcs_info(), indent=2))
    # Smoke test
    test_scene = {"actors": [
        {"name": "Hero", "location": [0, 0, 0]},
        {"name": "Tree1", "location": [100, 200, 0]},
    ]}
    s1 = snapshot("ws_demo", test_scene, label="initial scene", branch="main")
    print("\nSnapshot 1:", s1["snapshot_id"])
    test_scene["actors"].append({"name": "Tree2", "location": [300, 200, 0]})
    s2 = snapshot("ws_demo", test_scene, label="added Tree2", branch="main")
    print("Snapshot 2:", s2["snapshot_id"])
    print("\nDiff:")
    print(json.dumps(diff_snapshots(s1["snapshot_id"], s2["snapshot_id"]), indent=2))
