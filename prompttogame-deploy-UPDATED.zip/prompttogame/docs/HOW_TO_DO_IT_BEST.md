# How to Do It and Make It the Best

## Executive summary

When "it" is unspecified, the highest-leverage move is not to start building immediately. It is to classify the work into the right operating pattern, because the methods that make a **research paper** excellent are materially different from the methods that make a **software feature**, **product launch**, **marketing campaign**, **event**, or **process improvement** excellent. Research work is constrained by authorship, disclosure, methods, and publication standards; software work benefits from multidimensional productivity and flow metrics rather than output counts alone; campaign work only improves if key events, conversion rates, and cost metrics are instrumented from day one; and process improvement is strongest when it follows a structured method such as DMAIC with baseline measurement and control plans.

If the goal is **speed to visible results**, a marketing campaign or event is usually the fastest path. If the goal is **durable operational gains**, process improvement usually wins. If the goal is **scalable product value**, choose a software feature or product launch. If the goal is **credibility, publication, or knowledge creation**, choose a research-paper workflow. In ambiguous cases, the best default is a short discovery sprint that defines the target audience, decision-maker, success metrics, scope, and category before committing budget.

A useful project-specific example appears in the uploaded note you provided: it interprets "it" as an AI-assisted Unreal Engine game build and argues for shipping a **vertical slice** before attempting a "full game." That is a good illustration of a broader principle in software and product work: excellence usually comes from proving one complete loop end-to-end before expanding scope.

## Framing the project

The six most plausible interpretations of "it" are shown below. Each has a different object of excellence, different failure modes, and different evidence of success.

| Category | What "best" usually means | Typical first proof of success | Best fit when your main goal is |
|---|---|---|---|
| Product launch | Market fit, coordinated release, measurable adoption | Early activation, pipeline, revenue, retention | Commercial traction |
| Research paper | Strong contribution, method clarity, publishability | Submission-quality manuscript, reproducible package | Credibility and knowledge |
| Software feature | User value, reliability, maintainability, adoption | Feature released safely with telemetry | Product capability |
| Marketing campaign | Efficient reach, response, conversion | Qualified traffic, leads, sales, or awareness lift | Fast demand generation |
| Event | Strong attendance, experience, sponsor/meeting outcomes | Registration-to-attendance and stakeholder satisfaction | Community, pipeline, or convening |
| Process improvement | Lower defects, lower cost, faster cycle time, stable control | Measured baseline improvement sustained over time | Operational excellence |

```mermaid
flowchart TD
    A[Start with the outcome] --> B{What is the primary value?}
    B -->|Commercial traction| C[Product launch]
    B -->|Evidence and publication| D[Research paper]
    B -->|Product capability| E[Software feature]
    B -->|Demand generation| F[Marketing campaign]
    B -->|Convening and experience| G[Event]
    B -->|Operational performance| H[Process improvement]

    C --> I[Define audience, offer, adoption KPI]
    D --> J[Define contribution, method, target journal]
    E --> K[Define user problem, release metric, rollout plan]
    F --> L[Define audience, channel, key event]
    G --> M[Define attendee and sponsor outcomes]
    H --> N[Define process, baseline, defect or cycle metric]
```

A practical discovery sprint for any of these categories should answer five questions in writing: **Who is the user or stakeholder? What outcome matters? How will success be measured? What is explicitly out of scope? What decision will be made at the first milestone?** That is the shortest path to reducing avoidable rework.

## Category playbooks

**Product launch**

A product launch is the controlled market introduction of a new product, service, package, or major release. Its scope usually includes market validation, positioning, pricing, release readiness, enablement, and post-launch optimization. The discipline exists at the intersection of market research, project management, and campaign execution.

| Aspect | Guidance |
|---|---|
| Definition and scope | Launch only when you can state: target segment, job-to-be-done, differentiated promise, offer/package, CTA, and one primary adoption metric. |
| Detailed how-to | **Weeks 1–2:** validate audience, problem, willingness-to-pay assumptions, and launch KPI tree. **Weeks 3–4:** finalize positioning, pricing hypothesis, packaging, and sales/support FAQ. **Weeks 5–7:** build launch assets, landing pages, demos, docs, onboarding, CRM stages, and analytics. **Weeks 8–10:** run beta or soft launch, collect objections, fix friction, train sales/support. **Weeks 11–12:** public launch. **Weeks 13–16:** review cohort behavior, adjust message, onboarding, and pricing. |
| Milestones | Launch brief approved; instrumentation complete; beta cohort active; go/no-go review; public release; thirty-day post-launch review. |
| Best practices | Use a single launch owner; force trade-off decisions early; stage rollout; create sales/support enablement before announcement; instrument adoption from day one; separate vanity awareness from business outcomes. |
| Common pitfalls | Launching without proof the offer matters; too many audience segments; unclear ownership; press before readiness; "all channels at once" without testing; no post-launch review. |
| Mitigation | Use one ICP first; run beta/sandbox; create a go/no-go checklist; time-box scope; staff launch support for week one; define stop/continue rules before spend. |
| Success metrics and KPIs | Activation rate, trial-to-paid or demo-to-close conversion, conversion rate, key-event completion, CAC or cost per qualified pipeline dollar, pipeline created, refund/churn in first cohort, time-to-value. |
| Resources | **Skills:** product marketing, PM, design, analytics, sales enablement, support. **Roles:** launch owner, PMM, designer, web/ops, analyst, sales lead. **Tools:** analytics, CRM, marketing automation, PM tracker, docs/wiki. **Directional budget:** low $15k–$60k, medium $60k–$250k, high $250k+. |

**Research paper**

A research paper project aims to create an evidence-based manuscript suitable for peer review and publication. Its excellence criteria include a clearly framed contribution, method transparency, reproducibility, proper authorship, complete citation practice, and compliance with journal instructions, including AI-use disclosure where applicable. ICMJE's current recommendations were updated in January 2026, and they explicitly require disclosure of AI-assisted technologies and clarify that chatbots should not be listed as authors.

| Aspect | Guidance |
|---|---|
| Definition and scope | Define the paper as a claim backed by evidence for a specific audience and journal, not as "everything we did." |
| Detailed how-to | **Weeks 1–2:** define the message, target journal, authorship, and required ethics/compliance steps. **Weeks 3–5:** literature review, method lock, analysis plan, and data/figure inventory. **Weeks 6–10:** conduct analysis and build tables/figures. **Weeks 11–13:** draft title, abstract, Introduction, Methods, Results, Discussion. **Weeks 14–16:** internal coauthor review and compliance pass. **Weeks 17–20:** submission package, cover letter, and final checks. **Revision phase:** respond point-by-point and update manuscript plus rebuttal matrix. |
| Milestones | Research question frozen; journal selected; figures complete; full draft complete; coauthors signed off; submission sent; reviewer-response package complete. |
| Best practices | Decide the message before writing; choose journal early; draft title/abstract early; keep citations while drafting; align sections to the paper's main claim; define authorship and AI-use policy upfront; keep a reproducibility package. |
| Common pitfalls | Vague contribution; literature review done too late; journal mismatch; weak methods explanation; authorship disputes; sloppy figures; undisclosed AI assistance. |
| Mitigation | Write a one-sentence contribution statement; use a target-journal checklist; assign section owners; maintain citation manager hygiene; keep methods and analysis notebooks versioned; disclose AI use where required. |
| Success metrics and KPIs | Full draft by deadline, internal review turnaround time, percentage of figures/code reproducible, submission-to-decision time, number of major reviewer objections, acceptance or revise-and-resubmit outcome, downloads/citations after publication. |
| Resources | **Skills:** subject-matter expertise, methods/statistics, writing, editing, figure design. **Roles:** lead author, coauthors, statistician/methods reviewer, optional editor. **Tools:** reference manager, manuscript editor, analysis environment, version control, preprint server if appropriate. **Directional budget:** low $2k–$15k, medium $15k–$75k, high $75k+. |

**Software feature**

A software feature project adds new user-facing or operator-facing capability to an existing product. Excellence is not just shipping code; it is solving the right problem with safe rollout, telemetry, maintainability, and measurable user impact. The SPACE framework warns against reducing software productivity to a single output metric, while the DORA flow measures cited by SPACE emphasize deployment frequency, lead time, and incident response.

| Aspect | Guidance |
|---|---|
| Definition and scope | Define the feature in terms of user behavior change, not implementation detail. State the job-to-be-done, the success metric, the rollout guardrails, and the rollback condition. |
| Detailed how-to | **Weeks 1–2:** clarify user problem, KPI, non-goals, data model, and release constraints. **Weeks 3–4:** design spec, UX prototype, telemetry spec, and acceptance criteria. **Weeks 5–8:** implement in small slices behind flags; ship internal builds early. **Weeks 7–9:** QA, integration, documentation, and support readiness. **Weeks 9–10:** beta rollout to a narrow cohort. **Weeks 11–12:** general availability. **Weeks 13–14:** hardening, bug-fix tranche, and adoption review. |
| Milestones | PRD/spec approved; instrumentation ready; beta cohort live; general release; thirty-day quality and adoption review. |
| Best practices | Start with one measurable user outcome; keep observability in scope; release behind flags; monitor adoption and reliability together; use multiple metrics across satisfaction, performance, activity, collaboration, and flow; prefer end-to-end thin slices over large hidden branches. |
| Common pitfalls | Measuring only output; no telemetry; shipping without support docs; large-batch release; missing rollback path; scope expansion after engineering starts. |
| Mitigation | Require a KPI and dashboard before build; use feature flags or staged rollout; record non-goals; set quality guardrails; run a post-launch review by cohort. |
| Success metrics and KPIs | Adoption rate, task completion, retention impact, defect escape rate, crash/error rate, latency, deployment frequency, lead time for changes, MTTR, user satisfaction, support ticket volume. |
| Resources | **Skills:** product, engineering, design, QA, analytics, documentation, optional SRE. **Roles:** product owner, tech lead, 1–5 engineers, designer, QA, analyst. **Tools:** issue tracker, repo/CI, feature flags, analytics, observability stack. **Directional budget:** low $25k–$120k, medium $120k–$500k, high $500k+. |

**Marketing campaign**

A marketing campaign is a bounded program of messaging and channel activity designed to move a defined audience toward a measurable action. Campaign quality depends heavily on measurement design. Google Analytics defines a key event as an event that measures an action important to business success, and Google Ads formally defines CTR, conversion rate, CPC, CPM, and conversion value per cost.

| Aspect | Guidance |
|---|---|
| Definition and scope | Choose one campaign objective first: awareness, demand capture, lead generation, sales, or reactivation. One primary conversion should dominate reporting. |
| Detailed how-to | **Week 1:** objective, audience, offer, budget envelope, KPI tree. **Weeks 2–3:** creative brief, channel strategy, landing flow, and tracking design. **Weeks 4–5:** build assets, QA tags, audience lists, and reporting views. **Weeks 6–7:** launch with controlled spend and test cells. **Weeks 8–10:** optimize based on conversion quality, not just cheap clicks. **Week 10+:** report, learn, and either scale or stop. |
| Milestones | KPI tree approved; key events instrumented; creative live; first optimization checkpoint; scale/stop decision. |
| Best practices | Use one conversion hierarchy; instrument all touchpoints; separate message test from audience test; pace spend; assess quality after click, not just click volume; report leading and lagging indicators. |
| Common pitfalls | Too many goals; poor tagging; optimizing for CTR when revenue is weak; channel sprawl; reporting impressions without business outcome context; no holdout or baseline. |
| Mitigation | Use a measurement plan before launch; define primary and secondary KPIs; set weekly review cadence; freeze two-thirds of variables at first; keep "stop-loss" rules for spend. |
| Success metrics and KPIs | Reach, impressions, CTR, CPC, CPM, conversion rate, cost per key event, conversion value per cost, CAC, qualified pipeline, revenue influenced. |
| Resources | **Skills:** strategy, copy, design, media buying, analytics, marketing ops. **Roles:** campaign owner, performance marketer, creative lead, analyst, web/ops. **Tools:** GA4, ad platforms, CRM, tag manager, dashboards, creative suite. **Directional budget:** low $5k–$30k, medium $30k–$150k, high $150k+. |

**Event**

An event project is the design and delivery of a live, virtual, or hybrid experience. Scope typically includes audience targeting, venue or platform, speakers, registration, agenda, vendor coordination, run-of-show, onsite operations, and post-event follow-up.

| Aspect | Guidance |
|---|---|
| Definition and scope | Define the event as an outcome machine, not a calendar item. Specify whether the primary outcome is community, revenue, meetings, education, pipeline, recruiting, or internal alignment. |
| Detailed how-to | **Weeks 1–2:** objective, audience, date range, budget envelope, venue/platform shortlist. **Weeks 3–5:** venue or vendor lock, registration strategy, agenda architecture, sponsor package, and comms plan. **Weeks 6–9:** speaker confirmations, production plan, attendee journey, and staffing roster. **Weeks 10–12:** final promotion, contingencies, rehearsal, run-of-show, and onsite briefings. **Event week:** execute, monitor, troubleshoot, and capture leads/feedback. **Post-event:** forty-eight-hour follow-up, recap, KPI review, and renewal decisions. |
| Milestones | Objective approved; venue/platform contracted; registration live; agenda and speakers locked; final run-of-show complete; post-event report issued. |
| Best practices | Lock objective first; build a critical path; hold contingency budget; designate one floor owner; rehearse transitions; capture follow-up actions before attendees leave. |
| Common pitfalls | Late venue commitment; overbuilt agenda; weak registration funnel; no contingency for AV/speaker issues; poor badge or lead capture; slow follow-up. |
| Mitigation | Freeze must-have decisions early; maintain risk log and backup vendors; rehearse onboarding and handoffs; send follow-up within forty-eight hours; assign owners for sponsor and attendee recovery actions. |
| Success metrics and KPIs | Registrations, attendance/show rate, sponsor revenue, meetings booked, pipeline influenced, attendee satisfaction, NPS, session fill rate, cost per attendee, renewal rate. |
| Resources | **Skills:** event ops, project coordination, vendor management, promotion, audience support. **Roles:** event lead, ops/producer, marketing owner, venue or platform manager, volunteers or temp staff. **Tools:** registration platform, CRM, budget sheet, run-of-show, floor plan, comms channel. **Directional budget:** low $10k–$75k, medium $75k–$300k, high $300k+. |

**Process improvement**

A process-improvement project improves an existing process that is underperforming against customer needs or performance standards. ASQ defines DMAIC as a structured problem-solving approach for improving existing processes and explains that the method progresses through Define, Measure, Analyze, Improve, and Control; NIST's Baldrige program frames performance excellence as an integrated approach to improving performance, resilience, and long-term success.

| Aspect | Guidance |
|---|---|
| Definition and scope | Use this category when the process already exists and the problem is defects, delay, cost, handoffs, variation, or customer dissatisfaction. |
| Detailed how-to | **Weeks 1–2:** charter the problem, customer requirement, target metric, and owner. **Weeks 3–4:** map the current process and establish a trustworthy baseline. **Weeks 5–7:** identify root causes with data, Pareto, and failure-mode thinking. **Weeks 8–10:** pilot countermeasures and recalculate capability, throughput, or error rates. **Weeks 11–14:** create control plans, SOPs, owner dashboards, and escalation rules. **Weeks 15–18:** stabilize, train, and scale. |
| Milestones | Charter approved; baseline measured; root causes confirmed; pilot completed; control plan live; sustained-gain audit passed. |
| Best practices | Measure before changing; focus on root causes; use pilots; assign process ownership; document control plans and response rules; review gains after the excitement phase ends. |
| Common pitfalls | Jumping to solutions; bad baseline data; trying to fix too broad a process; no frontline involvement; no control step; improvement theater without measurable gain. |
| Mitigation | Narrow scope to one value stream; validate the measurement system; involve frontline SMEs; use FMEA or root cause analysis before redesign; require a control plan and named owner. |
| Success metrics and KPIs | Cycle time, defect rate, rework, first-pass yield, throughput, cost per transaction, service level, customer satisfaction, process capability, stability over time. |
| Resources | **Skills:** facilitation, analysis, process mapping, stakeholder management. **Roles:** process owner, analyst, frontline SMEs, improvement lead, sponsor. **Tools:** process map, Pareto, root cause analysis, FMEA, SPC/control charts, dashboard. **Directional budget:** low $15k–$80k, medium $80k–$250k, high $250k+. |

## Decision matrix and fit recommendations

The matrix below is a synthesis rather than a quoted benchmark. Scores are relative, on a five-point scale, for the typical case with no special constraints.

| Category | Speed to first value | Quality ceiling | Cost efficiency | Innovation potential | Recommended when… |
|---|---:|---:|---:|---:|---|
| Product launch | 3 | 4 | 3 | 4 | You have something sellable and need traction, feedback, and revenue signals |
| Research paper | 1 | 5 | 3 | 3 | You need evidence, credibility, reproducibility, or publication |
| Software feature | 3 | 4 | 2 | 4 | You need durable product capability inside an existing system |
| Marketing campaign | 5 | 3 | 4 | 3 | You need fast testing of message, audience, and demand |
| Event | 4 | 3 | 2 | 3 | You need concentrated attention, relationship-building, or timed convening |
| Process improvement | 2 | 4 | 5 | 2 | You need throughput, quality, cost, or reliability gains in an existing workflow |

A strong default recommendation for an unknown project is: **start with the category that makes the decision risk smallest, not the category that feels most exciting.** If the biggest uncertainty is whether anyone wants the thing, start with launch or campaign logic. If the biggest uncertainty is whether the system can reliably deliver the thing, start with software-feature or process-improvement logic. If the biggest uncertainty is whether the claim is true, start with research-paper logic.

| If your priority is… | Best first category | Why |
|---|---|---|
| Speed | Marketing campaign | Fastest to instrument, test, and iterate with measurable signals |
| Quality and rigor | Research paper | Strongest formal standards for evidence, methods, and review |
| Cost control | Process improvement | Gains compound by removing waste and variation |
| Innovation | Product launch or software feature | Best for testing new value creation and product differentiation |
| Stakeholder alignment | Event or process improvement | Strongest for focused attention and cross-functional coordination |
| Long-term scalability | Software feature | Reusable capability and compounding product value |

## Templates and visuals

### Generic project plan template

| Field | What to write |
|---|---|
| Project name | Clear noun + outcome |
| Category | Product launch, research paper, software feature, marketing campaign, event, or process improvement |
| Problem statement | What is wrong, for whom, and why now |
| Objective | One sentence beginning with "Increase / reduce / deliver / publish / launch…" |
| Primary KPI | One metric that decides success |
| Secondary KPIs | No more than five |
| In scope | Concrete deliverables |
| Out of scope | Explicit exclusions |
| Stakeholders | Sponsor, owner, approvers, contributors, impacted groups |
| Assumptions | Facts you are relying on but have not fully proven |
| Risks | Top five delivery or quality risks |
| Milestones | Decision points, not just activity dates |
| Budget envelope | Low / medium / high planning scenario |
| Definition of done | What must be true for the project to be considered complete |

### Project checklist

| Phase | Checklist |
|---|---|
| Framing | Category chosen; owner named; objective written; KPI tree approved; out-of-scope list documented |
| Planning | Timeline baselined; budget scenario selected; stakeholders mapped; risks logged; communication cadence set |
| Build | Decisions and changes tracked; dependencies visible; quality checks embedded; instrumentation implemented |
| Launch or submission | Go/no-go review completed; support or response plan ready; rollback or contingency path ready |
| Review | KPI results published; lessons learned captured; next-step decision made |

### Risk register template

| Risk ID | Risk description | Probability | Impact | Early warning sign | Owner | Mitigation | Contingency |
|---|---|---|---|---|---|---|---|
| R1 | Scope increases after work starts | M | H | New features/tasks appear weekly | Project owner | Freeze non-goals; change control | Slip date or cut scope |
| R2 | Measurement is missing or wrong | M | H | Conflicting dashboard numbers | Analyst | QA instrumentation early | Reconstruct from logs/manual audit |
| R3 | Decision-maker unavailable | L | H | Delayed approvals | Sponsor | Pre-book milestone reviews | Delegate approval |
| R4 | Critical dependency slips | M | M | Repeated unresolved blockers | PM | Weekly dependency check | Alternative vendor/workaround |
| R5 | Quality issue at release/submission | M | H | High defect count / reviewer pre-comments | QA or lead author | Earlier reviews and pilots | Hold release or revise before submit |

### Communication plan template

| Audience | What they need | Format | Owner | Cadence |
|---|---|---|---|---|
| Sponsor | Status, risks, budget, decisions | Brief memo or dashboard | Project owner | Weekly or biweekly |
| Working team | Tasks, blockers, decisions | Stand-up + workspace | PM or lead | 2–5 times weekly |
| Adjacent teams | Impact, dependencies, dates | Async update | PM | Weekly |
| End users or attendees | What changes, when, what to do | Email, landing page, help doc | Ops/marketing | At milestone moments |
| Leadership | Outcome summary and decision ask | Readout | Sponsor/owner | At milestone reviews |

### Generic Gantt template

```mermaid
gantt
    title Generic 12-week project template
    dateFormat  YYYY-MM-DD
    axisFormat  %b %d

    section Discovery
    Problem framing           :a1, 2026-07-06, 7d
    KPI and scope             :a2, after a1, 7d

    section Planning
    Solution design           :b1, after a2, 14d
    Risk and stakeholder plan :b2, after a2, 10d

    section Build
    Production work           :c1, after b1, 21d
    QA and instrumentation    :c2, after c1, 10d

    section Launch
    Soft launch or review     :d1, after c2, 7d
    Full launch or submission :d2, after d1, 7d

    section Review
    Post-launch analysis      :e1, after d2, 7d
```

### Generic operating flow

```mermaid
flowchart LR
    A[Define outcome] --> B[Choose category]
    B --> C[Set primary KPI]
    C --> D[Plan milestones and budget]
    D --> E[Build with instrumentation]
    E --> F[Review quality]
    F --> G[Launch submit or pilot]
    G --> H[Measure results]
    H --> I[Scale stop or iterate]
```

## Mini-implementations

**Product launch mini-implementation**

Imagine "it" is a new AI note-capture add-on for an existing B2B SaaS tool. The strongest path is a **twelve-week launch** with a narrow ICP, one primary workflow, and a single headline metric: activated accounts in the first thirty days. Weeks one and two validate segment and willingness-to-pay assumptions. Weeks three and four lock message, package, and pricing. Weeks five through seven build onboarding, a demo, a landing page, CRM routing, and sales FAQ. Weeks eight through ten run a beta with success calls and objection logging. Weeks eleven and twelve are public launch plus post-launch cohort analysis. The fastest way to make this "the best" is to treat adoption, not announcement, as the real launch milestone.

A sensible KPI set would be: landing-page conversion, demo-to-trial rate, activated seats, time-to-first-value, pipeline created, and conversion value per cost. The common trap is to celebrate traffic or press while ignoring whether the target user actually reaches the first valuable action.

**Research paper mini-implementation**

Imagine "it" is an applied study on whether AI-assisted code review improves defect detection. The strongest path is a **sixteen- to twenty-week manuscript plan**. The first milestone is not writing; it is freezing the contribution statement, target venue, authorship, and analysis plan. Next comes literature review and figure planning. Then data collection and analysis. Only after the evidence stabilizes should the team draft the manuscript sections. The astronomy writing guide is especially practical here: it recommends defining the message first, drafting the title and abstract early, sketching the paper structure before full drafting, and editing repeatedly rather than trying to write linearly from page one.

To make the paper "the best," use a reproducibility package, define authorship early, keep citations current during drafting, and disclose any AI assistance exactly as required by the target journal or publisher. ICMJE's 2026 recommendations are particularly clear: AI use should be disclosed, chatbots should not be listed as authors, and humans remain responsible for accuracy, integrity, attribution, and final accountability.

**Software feature mini-implementation**

Imagine "it" is an AI-assisted gameplay or creator-tool feature inside a larger product or game. The uploaded note you provided makes a narrow but important software point: complex creative software projects become tractable when they aim first for a **vertical slice** rather than an expansive "full" build. Applied more broadly, that means defining the smallest end-to-end user loop that proves value, releasing that loop with telemetry and rollback controls, and only then expanding scope.

A strong twelve-week implementation would work like this: two weeks of user-problem framing and KPI design; two weeks of architecture, UX, and telemetry planning; four weeks of thin-slice implementation behind flags; two weeks of QA and cohort beta; then a controlled release and hardening cycle. To make it "the best," track both **user outcomes** and **engineering flow**. SPACE argues against one-metric thinking, and its discussion of DORA-style measures highlights deployment frequency and lead time for changes as useful system-level flow indicators, while its incident-management example reinforces MTTR as a reliability lens. A feature that ships quickly but destroys support capacity or reliability is not actually "best."

## Sources and estimation notes

This report prioritized **primary and official guidance** where practical: U.S. Bureau of Labor Statistics for occupational role definitions and median pay; Google Ads and Google Analytics help documentation for campaign metrics; ASQ for DMAIC; NIST Baldrige for performance-excellence framing; and ICMJE for current manuscript and AI-use rules. It also used practical scholarly literature for research-paper planning and software-measurement literature from ACM Queue for the SPACE framework.

The budget ranges in the playbooks are **directional planning envelopes**, not market quotes. They are synthesized from typical role mixes and current U.S. median-pay data for project management specialists, software developers, market research analysts, event planners, and operations research analysts, plus normal tooling or media/venue spend categories.

The single most reliable cross-category principle is this: **define the outcome, define the metric, define the smallest credible scope, and only then start execution.** That principle is visible, in different forms, across project management, campaign measurement, software productivity research, research-writing guidance, and DMAIC.
