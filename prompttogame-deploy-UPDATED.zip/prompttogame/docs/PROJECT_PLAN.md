# prompttogame.ai — Project Plan
### Classified and planned using the "How to Do It and Make It the Best" framework

**Date:** July 2025
**Status:** Code complete, never deployed, never tested end-to-end live

---

## 1. Classification Analysis

### The five discovery-sprint questions

| Question | Answer for prompttogame.ai |
|---|---|
| **Who is the user or stakeholder?** | Indie game developers and solo creators who use Unreal Engine 5 but spend hours on manual editor tasks (lighting, placement, environment, VFX). Secondary: curious non-UE5 users who want to generate simple browser games. |
| **What outcome matters?** | The user types a natural-language instruction ("make this look like a Rembrandt painting at sunset") and gets a real, visible result inside their UE5 project or browser within seconds. Commercial traction matters most — the code is already built; the question is whether anyone wants it enough to pay. |
| **How will success be measured?** | Activated users who complete at least one real command or generate one playable game. Revenue signals from the Pro tier ($49/mo). Waitlist-to-signup conversion. |
| **What is explicitly out of scope?** | Building more features before launch. The MCP pivot, multi-agent factory, Lyra-based full game generation, enterprise SSO — all are future possibilities but are NOT part of getting to first live user. |
| **What decision will be made at the first milestone?** | After 2 weeks live: Is anyone actually using this? Do we have ≥10 activated users and ≥1 paid signup? If yes, continue and optimize. If no, pivot positioning or pause. |

### Scoring the six categories

| Category | Speed to first value | Quality ceiling | Cost efficiency | Innovation potential | Fit score for prompttogame.ai |
|---|---:|---:|---:|---:|---|
| **Product launch** | 3 | 4 | 3 | 4 | ⭐⭐⭐⭐⭐ |
| Research paper | 1 | 5 | 3 | 3 | ⭐ |
| Software feature | 3 | 4 | 2 | 4 | ⭐⭐⭐ |
| Marketing campaign | 5 | 3 | 4 | 3 | ⭐⭐⭐⭐ |
| Event | 4 | 3 | 2 | 3 | ⭐ |
| Process improvement | 2 | 4 | 5 | 2 | ⭐⭐ |

### Verdict: Product Launch is the primary category

The framework says: *"If the biggest uncertainty is whether anyone wants the thing, start with launch or campaign logic."* That is exactly our situation. The code is built. The gap is not engineering — it is validation. Nobody has ever used prompttogame.ai on a real project. The biggest risk is building more features nobody has asked for.

**Secondary category: Marketing Campaign** — because once the product is live, the next challenge is demand generation. But that comes AFTER launch, not before.

**Why not Software Feature?** Because there is no existing product with users to add a feature to. The product does not exist in the market yet. A software-feature approach would keep us in build mode when we need to be in launch mode.

**Why not Process Improvement?** Because there is no existing process to improve. Nothing is running.

---

## 2. Filled-In Project Plan Template

| Field | Content |
|---|---|
| **Project name** | prompttogame.ai Launch — Vertical Slice Live |
| **Category** | Product launch (primary), marketing campaign (secondary, weeks 9+) |
| **Problem statement** | An AI co-pilot for Unreal Engine 5 has been fully coded (~46 files, ~23,000 lines) but has never been deployed or used by any real person. The VPS is paid for, the domain is registered, the deploy script is written — but DNS is not pointed, no API key is configured, and zero users have tested the system end-to-end. The gap between "code exists" and "product is live" is 100% of the remaining work. |
| **Objective** | Launch prompttogame.ai with a working free tier (browser game builder + playground) and a payable Pro tier, achieving at least 10 activated users and 1 paid signup within 30 days of public launch. |
| **Primary KPI** | Activated users (completed ≥1 real command or generated ≥1 playable game) within 30 days of launch |
| **Secondary KPIs** | 1. Waitlist-to-signup conversion rate 2. Trial-to-paid conversion (Pro tier) 3. Time-to-first-value (seconds from landing to first game generated) 4. Builder generation success rate (% of prompts that produce a playable game) 5. 7-day retention of activated users |
| **In scope** | DNS configuration, VPS deployment, API key setup, end-to-end testing of free tier, landing page live, builder live, playground live, Pro tier payment flow, analytics instrumentation, soft launch to 5-10 game-dev friends, demo video recording, post-launch cohort review |
| **Out of scope** | MCP pivot to Epic's UE 5.8 MCP server, multi-agent game factory, Lyra-based full game generation, enterprise SSO/RBAC, new premium modules, Windows companion testing with real UE5 (requires hardware we don't have in this environment), marketing spend beyond organic sharing |
| **Stakeholders** | **Sponsor/owner:** Kris Cambria (product owner, DNS access, API key holder). **Contributors:** AI assistant (deployment, testing, documentation, video script). **Impacted groups:** First users (game devs, indie creators), Hostinger (VPS provider) |
| **Assumptions** | 1. The VPS at 85.31.225.224 is still active and accessible. 2. The domain prompttogame.ai is still registered and DNS can be pointed. 3. An Anthropic or OpenAI API key will be provided. 4. The deploy script (deploy_prompttogame.sh) works on a clean Ubuntu 24.04 VPS. 5. The code that passed import tests in development will also work in production. 6. At least 5 game-dev contacts exist for soft launch. |
| **Risks** | See Risk Register below |
| **Milestones** | See Milestones below |
| **Budget envelope** | Low scenario: ~$25/month (VPS $10 + Anthropic credits $15). Medium: ~$75/month (VPS + heavier API usage). No upfront capital needed — all code and infrastructure already exist. |
| **Definition of done** | prompttogame.ai is publicly accessible at https://prompttogame.ai. The free tier (builder + playground) works end-to-end for a new visitor. At least 10 users have activated. At least 1 has paid for Pro. Post-launch cohort review is complete with a continue/pivot/stop decision documented. |

---

## 3. Milestones (12-Week Launch Plan)

| Week | Milestone | Decision gate |
|---|---|---|
| 1 | **Launch brief approved** — Target segment, offer, CTA, primary metric documented (this document) | Is the ICP narrow enough? |
| 2 | **Infrastructure live** — DNS pointed, VPS deployed, API key configured, health endpoint returning 200 | Can a visitor reach the site? |
| 3 | **Instrumentation complete** — Analytics on landing page, builder, playground; error tracking; conversion funnel visible | Can we measure what matters? |
| 4 | **Free tier verified end-to-end** — Builder generates a playable game from a stranger's prompt; playground translates natural language to UE5 commands | Does the core loop work for a new user? |
| 5 | **Pro tier payment flow working** — Stripe integration tested with a real card; upgrade path from free to Pro is functional | Can money change hands? |
| 6 | **Demo video recorded** — 60-second screen capture of builder + playground | Is there a shareable asset? |
| 7 | **Beta cohort active** — 5-10 game-dev friends have accounts, have tried the builder, and have provided feedback | Are real users completing the loop? |
| 8 | **Go/no-go review** — Based on beta feedback: Is the product ready for wider release? | Green light for public launch? |
| 9-10 | **Public launch** — Share URL + demo video on indie dev communities, Twitter/X, Reddit r/unrealengine, Discord servers | — |
| 11-12 | **Post-launch cohort review** — 30-day data on activation, conversion, retention; continue/pivot/stop decision | What does the data say? |

---

## 4. Risk Register

| Risk ID | Risk description | Probability | Impact | Early warning sign | Owner | Mitigation | Contingency |
|---|---|---|---|---|---|---|---|
| R1 | **Deploy script fails on live VPS** — Code worked in dev but Ubuntu 24.04 VPS has missing deps, port conflicts, or permission issues | H | H | First deploy attempt returns errors | Kris + AI | Test deploy in dry-run mode; keep rollback commands ready | SSH in and fix manually; worst case redeploy from scratch |
| R2 | **No API key provided** — LLM features (builder, director, vision) are non-functional without Anthropic/OpenAI key | M | H | .env file has no key after week 2 | Kris | Document minimum viable config; free tier works without LLM key (regex translator only) | Launch with free tier only; add LLM features when key is available |
| R3 | **Nobody uses it** — Soft launch gets zero activations, or users bounce immediately | M | H | Waitlist has signups but no activations after 7 days | Kris | Narrow ICP; target specific communities; make first-value faster | Pivot positioning; try different audience; pause if no signal after 60 days |
| R4 | **Builder generates broken games** — LLM output quality is inconsistent; users get garbage HTML/game output | M | M | Users report "that didn't work" repeatedly | AI assistant | Prompt engineering on SYSTEM_2D/SYSTEM_3D; add output validation; show retry option | Default to curated example games; disable free-form builder until prompts are reliable |
| R5 | **Scope creep before launch** — Temptation to add MCP pivot, multi-agent factory, or new modules instead of shipping what exists | H | H | New feature ideas appear in planning instead of launch tasks | Kris | This plan explicitly scopes out new features; change control = write it down and defer | Refer back to this document; "ship first, build second" |
| R6 | **VPS or DNS infrastructure problem** — Hostinger VPS down, DNS propagation issues, SSL cert failure | L | M | Health endpoint returns non-200 | Kris | Monitor with uptime checks; keep Hostinger support access | Switch to alternative hosting; use IP address temporarily |
| R7 | **API costs exceed budget** — Anthropic/OpenAI usage spikes with real users | L | L | API bill exceeds $50/month | Kris | Rate limiting already built (30 req/min/IP); monitor daily | Tighten rate limits; add usage caps per tier |

---

## 5. Communication Plan

| Audience | What they need | Format | Owner | Cadence |
|---|---|---|---|---|
| Kris (sponsor + owner) | Status, risks, decisions | This document + async updates | AI assistant | At each milestone |
| Beta testers | What to try, what's new, how to give feedback | Email or Discord message | Kris | At beta start + weekly |
| Public users | What the product does, how to start | Landing page + demo video | Kris + AI | At public launch |
| Community (Reddit, Discord, Twitter) | Why this matters, try it now | Social post + demo video link | Kris | At launch + when milestones hit |

---

## 6. Launch Checklist (from framework)

| Phase | Checklist item | Status |
|---|---|---|
| **Framing** | Category chosen (Product Launch) | ✅ |
| | Owner named (Kris Cambria) | ✅ |
| | Objective written | ✅ |
| | KPI tree approved | ✅ |
| | Out-of-scope list documented | ✅ |
| **Planning** | Timeline baselined (12 weeks) | ✅ |
| | Budget scenario selected (Low: ~$25/mo) | ✅ |
| | Stakeholders mapped | ✅ |
| | Risks logged (7 risks) | ✅ |
| | Communication cadence set | ✅ |
| **Build** | DNS records configured | ❌ Pending |
| | VPS deployed with deploy script | ❌ Pending |
| | API key in .env | ❌ Pending (Kris must provide) |
| | Analytics instrumentation | ❌ Pending |
| | Free tier end-to-end verified | ❌ Pending |
| | Pro tier payment flow tested | ❌ Pending |
| | Demo video recorded | ❌ Pending |
| **Launch** | Go/no-go review completed | ❌ Pending |
| | Support plan ready | ❌ Pending |
| | Rollback path documented | ❌ Pending |
| **Review** | KPI results published | ❌ Pending |
| | Lessons learned captured | ❌ Pending |
| | Next-step decision made | ❌ Pending |

---

## 7. The Vertical-Slice Principle Applied

The AI_GAME_FACTORY_VISION.md and the HOW_TO_DO_IT_BEST framework both converge on the same principle: **prove one complete loop end-to-end before expanding scope.**

For prompttogame.ai, the vertical slice is NOT more code. The vertical slice is:

> **A stranger visits prompttogame.ai, types a game idea, and plays a working HTML5 game they just created — all within 60 seconds, without installing anything.**

That is the one complete loop. If that loop works, the product has value. If it doesn't, no amount of additional premium modules or MCP integrations will matter.

The existing code already supports this loop:
- Landing page → Builder page → Type prompt → LLM generates game → Play in iframe
- The regex translator handles 16 patterns for the playground without any API key
- The builder requires an API key but the flow is fully coded

**What is NOT in the vertical slice (and must not be attempted before launch):**
- UE5 companion + local bridge setup (requires Windows + UE5)
- MCP pivot to Epic's UE 5.8 server
- Multi-agent game factory
- Enterprise tier (SSO, RBAC, Stripe billing)
- Voice, cinematic, VCS, RAG modules
- Full game generation (Lyra, C++ gameplay, packaging)

---

## 8. Immediate Next Actions (Week 1)

These are the concrete steps to move from "code exists" to "product is live":

1. **Kris points DNS** — In Hostinger panel, set A records:
   - `@` → `85.31.225.224`
   - `www` → `85.31.225.224`
   - `api` → `85.31.225.224`

2. **Kris provides API key** — Anthropic key for LLM features (builder, director). Without this, only the regex translator and playground work.

3. **Deploy to VPS** — Upload `prompttogame-deploy.zip` and run `deploy_prompttogame.sh --ssl`

4. **Verify health** — `curl https://prompttogame.ai/api/health` should return `{"status": "ok"}`

5. **Test the vertical slice** — Visit `/builder`, type "a simple platformer with a red square", verify a playable game appears in the iframe.

6. **Add analytics** — Minimal: page views on landing, builder, playground; conversion from landing → builder; builder generation success rate.

---

## 9. Sources and References

- BLUEPRINT.md (May 20-21, 2026) — Product/launch plan with 12-week deployment path
- SUPERNEJIN_COMPLETE_BLUEPRINT.md (May 11, 2025) — Original technical build plan, 16 phases
- AI_GAME_FACTORY_VISION.md — Multi-agent factory architecture, MCP pivot strategy, vertical-slice principle
- HOW_TO_DO_IT_BEST.md — Six-category classification framework, project plan template, risk register template
- SPRINT_75_TASKS.md — 75/75 reliability tasks completed
- README.md — Complete system documentation (24,599 chars)
