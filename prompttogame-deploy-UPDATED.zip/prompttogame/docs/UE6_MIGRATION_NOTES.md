# Unreal Engine 6 — Migration Notes & Readiness Plan

> **Status:** UE6 is **not yet GA**. This doc captures the architectural changes Epic is
> making in UE6, how each one impacts our codebase, a three-track migration plan, and the
> open risks. Hardware numbers and plugin-parity assumptions are **engineering inferences**,
> not quoted Epic system requirements.

---

## 1. The Five UE6 Changes That Matter to Us

| UE6 change | What it is | Our exposure |
|------------|-----------|--------------|
| **DAG task scheduler + ParallelFor** | Single-threaded `GameThread` replaced by a graph-based, multi-threaded simulation. | Our many short editor ops serialized through GameThread in UE5; UE6 lets independent skills batch in parallel. |
| **AutoRTFM** | LLVM/Clang pass that clones C++ functions and instruments writes with an undo stack, enabling transactional rollback. | Lets us express "run this whole Director plan; roll back if any step fails" natively (via Verse). |
| **Verse language + structured concurrency** | Functional-logic language with `sync` / `race` / `rush` / `spawn` and *failable expressions* as control flow. | Scene Graph components are authored in Verse; Director plans can become transactions. |
| **Scene Graph (entities + components)** | Deprecates monolithic `AActor` for lightweight entities + Verse components; one component of each type per entity; `EntityEnteredEvent` for collision; tag components. | **Biggest impact.** Nearly all of `unreal/skill_executor.py` is AActor-based. |
| **ML / LLM gameplay foundation** | In-engine LLM interface for NPC behavior, RL playtesting, neural locomotion. | Clean split: **cloud LLM = build the world; engine LLM = run the world.** |

---

## 2. Impact By File

### `unreal/skill_executor.py` — **HIGH impact**
Built directly on the AActor model UE6 deprecates. Confirmed usages:
- `unreal.EditorLevelLibrary.spawn_actor_from_class(...)`
- `unreal.DirectionalLight`, `unreal.PointLight`, `unreal.SpotLight`
- `unreal.EditorLevelLibrary.get_all_level_actors()`
- `actor.set_actor_location(...)` style transforms

**Migration:** create `skill_executor_scene_graph.py` where skills become
*create entity → attach components → set component data* instead of
*spawn actor → set actor properties*. The **skill catalog (names/intents) stays the same**;
only the implementation underneath changes.

### `server/premium/director.py` — **MEDIUM impact**
Plans multi-step scenes and recovers on step failure with manual logic today.

**Migration:** add an optional Verse adapter exposing
`RunDirectorPlan(plan)<transacts><suspends>` so AutoRTFM rolls back failed plans.
Keep the Python recovery path as the UE5 fallback.

### `server/premium/llm_translator.py` — **LOW impact**
Sits *outside* Unreal, translating text → commands. Stays as-is for **editor-time**
world building. Optionally also feed the UE6 in-engine LLM foundation for **runtime** NPC behavior.

### `server/premium/router.py` — **LOW impact (but key seam)**
Add engine-version detection so `/premium/*` and skill dispatch route to either the
UE5 executor or the Scene Graph executor.

### `server/premium/cinematic.py` — **LOW impact**
Uses Sequencer / Movie Render Queue. UE6 RL playtesting can augment the
screenshot-judging Director later; not required for v1.

---

## 3. Three-Track Migration Plan

**Track A — UE5 (now):** keep `skill_executor.py` + Python plugin path as primary.
This ships v1 and serves ~all customers for the next 12+ months.

**Track B — UE6 readiness (parallel, cheap):** add a `skill_executor_scene_graph.py`
stub + a tiny `.verse` adapter module; wire `router.py` to detect engine version and
route accordingly. No real porting yet — just the seam.

**Track C — UE6 native (when UE6 is GA + stable):** rewrite the 64 skills against
Scene Graph entities/components, port the Director to Verse `transacts` + `sync`/`race`/`rush`,
and integrate the engine LLM foundation for runtime NPC behavior.

---

## 4. Install / Hardware Deltas vs. UE5

UE6's ML inference, Verse runtime, and Scene Graph traversal favor more cores and RAM.

| Spec | UE5 comfortable | **UE6 comfortable (est.)** |
|------|-----------------|----------------------------|
| CPU | 8-core | **12-core (Ryzen 9 / i7-13th gen+)** |
| RAM | 32 GB | **64 GB** (new comfort floor) |
| GPU | RTX 3060/4060 (8–12 GB) | **RTX 4070 (12 GB) / 4070 Ti Super (16 GB)** |
| Storage | 500 GB NVMe | **1 TB NVMe**, ~200 GB free |
| Engine size | ~60–80 GB | **~70–100 GB** (Verse runtime + AutoRTFM artifacts + ML assets) |

**Unchanged:** the VPS and the browser builder still need **zero** Unreal install. UE6
only matters on the customer/dev Windows machine.

---

## 5. Open Risks (things we genuinely don't know yet)

1. **Python Editor Script Plugin survival.** If UE6 makes Verse the only editor-scripting
   path, our entire `unreal/` Python layer needs a Verse port, not just an adapter.
   *This is the single biggest risk to our architecture.*
2. **AActor: deprecated vs. removed.** Our brief says "deprecated in favor of Scene Graph."
   If AActor still works in UE6, migration is smooth; if removed, Track C becomes urgent.
3. **AutoRTFM exposure.** Likely Verse + C++ only (not Python) — which is why the
   transactional Director belongs behind a Verse adapter, not Python.
4. **Official UE6 sysreqs + release timing.** The hardware table above is inference, not
   an Epic-quoted spec.

---

## 6. TL;DR

- Hardware floor rises for UE6: target **64 GB RAM, RTX 4070-class GPU, 1 TB NVMe, 12-core CPU**.
- The real work is **Scene Graph migration of `skill_executor.py`** + an **optional Verse
  adapter for the Director** — not hardware.
- Plan **Track B (the seam) now**; execute **Track C** when UE6 ships and stabilizes.
- VPS and browser builder remain UE-free across UE5 and UE6.
