"""
prompttogame.ai — 2D / 3D HTML5 Game Builder

Free top-of-funnel feature: users type a prompt, get a playable HTML5
game in their browser in 20-60 seconds. Hooks visitors before they
install Unreal Engine.

Two modes:
  2D — Phaser 3 (CDN, no install)
  3D — Three.js + Cannon-es (CDN, no install)

The LLM is prompted with strict templates to generate a single self-contained
HTML file with embedded JavaScript. Output is stored, served, shareable.

Uses the SAME LLM key as the rest of the platform — no new credentials.

Configuration:
  UE5PILOT_LLM_PROVIDER     = "anthropic" | "openai"
  UE5PILOT_LLM_API_KEY      = same key as the rest of the platform
  BUILDER_OUTPUT_DIR        = generated games dir (default ~/.ue5pilot/games)
  BUILDER_MAX_PER_IP_DAY    = rate limit per IP per day (default 5)
  BUILDER_MODEL             = LLM model override
"""

from __future__ import annotations

import hashlib
import html
import json
import os
import re
import sqlite3
import threading
import time
import urllib.request
import urllib.error
import uuid
from contextlib import contextmanager
from typing import Dict, Any, Optional, Tuple


# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------

OUTPUT_DIR = os.environ.get(
    "BUILDER_OUTPUT_DIR",
    os.path.join(os.path.expanduser("~"), ".ue5pilot", "games"),
)
DB_PATH = os.path.join(OUTPUT_DIR, "builder.db")
MAX_PER_IP_DAY = int(os.environ.get("BUILDER_MAX_PER_IP_DAY", "5"))
PROVIDER = os.environ.get("UE5PILOT_LLM_PROVIDER", "anthropic").strip().lower()
API_KEY = os.environ.get("UE5PILOT_LLM_API_KEY", "").strip()
MODEL_OVERRIDE = os.environ.get("BUILDER_MODEL", "").strip()

DEFAULT_MODELS = {
    "anthropic": "claude-opus-4-7",
    "openai": "gpt-4o",
}

REQUEST_TIMEOUT = 90  # game generation takes longer than translation
MAX_TOKENS = 8000     # need room for full game code
MAX_PROMPT_LEN = 600

os.makedirs(OUTPUT_DIR, exist_ok=True)

_db_lock = threading.RLock()


# ---------------------------------------------------------------------------
# Database
# ---------------------------------------------------------------------------

@contextmanager
def _connect():
    conn = sqlite3.connect(DB_PATH, timeout=10, isolation_level=None)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode=WAL")
    try:
        yield conn
    finally:
        conn.close()


def _init_db():
    with _connect() as conn:
        conn.executescript("""
            CREATE TABLE IF NOT EXISTS games (
                game_id TEXT PRIMARY KEY,
                mode TEXT NOT NULL,
                prompt TEXT NOT NULL,
                model TEXT,
                provider TEXT,
                created_at REAL NOT NULL,
                ip TEXT,
                size_bytes INTEGER,
                play_count INTEGER DEFAULT 0,
                last_played REAL
            );
            CREATE INDEX IF NOT EXISTS idx_games_created ON games(created_at);
            CREATE INDEX IF NOT EXISTS idx_games_ip ON games(ip, created_at);
        """)


_init_db()


# ---------------------------------------------------------------------------
# Prompt templates
# ---------------------------------------------------------------------------

SYSTEM_2D = """You are an expert game developer. Generate a complete, playable HTML5 2D game using Phaser 3.

OUTPUT FORMAT — STRICTLY ENFORCED:
- Return ONLY a complete HTML file starting with <!DOCTYPE html> and ending with </html>
- No markdown fences, no commentary, no preamble
- Single file — all CSS in <style>, all JS in <script>
- Use Phaser 3 from CDN: <script src="https://cdn.jsdelivr.net/npm/phaser@3.70.0/dist/phaser.min.js"></script>
- Canvas must be 800x600
- Game must be playable with keyboard or mouse — clearly indicate controls on-screen
- Must include: start state, win/lose conditions, score or progress indicator
- Use Phaser.Game with a Scene class — proper preload/create/update lifecycle
- Generate graphics procedurally with Phaser.Graphics or use simple colored rectangles/circles — do NOT reference external image files
- Generate sounds with Web Audio API (oscillators) — do NOT reference external audio files
- Include a title screen with the game name and "Press SPACE to start"
- Include game-over screen with "Press R to restart"
- Code must run in any modern browser with zero dependencies beyond the Phaser CDN
- No external API calls, no fetch(), no localStorage usage

QUALITY REQUIREMENTS:
- Game must be FUN and PLAYABLE for at least 30 seconds
- Add visual polish: particle effects (built with Phaser), color, motion
- Add basic sound effects using Web Audio
- Difficulty must scale or game must have a clear progression
- Code must be production-quality — no console.log spam, no commented-out code, no TODO comments

If the user prompt is vague, make creative decisions and ship a complete game."""


SYSTEM_3D = """You are an expert game developer. Generate a complete, playable HTML5 3D game using Three.js.

OUTPUT FORMAT — STRICTLY ENFORCED:
- Return ONLY a complete HTML file starting with <!DOCTYPE html> and ending with </html>
- No markdown fences, no commentary, no preamble
- Single file — all CSS in <style>, all JS in <script type="module">
- Use Three.js r160 from CDN via import map:
  <script type="importmap">{"imports":{"three":"https://unpkg.com/three@0.160.0/build/three.module.js","three/addons/":"https://unpkg.com/three@0.160.0/examples/jsm/"}}</script>
- Canvas must fill the window (responsive resize handler)
- Game must be playable with WASD + mouse or arrow keys — clearly indicate controls on-screen with HTML overlay
- Must include: start state, win/lose conditions, score or HUD
- Generate geometry procedurally — BoxGeometry, SphereGeometry, CylinderGeometry, custom BufferGeometry
- Use MeshStandardMaterial or MeshBasicMaterial with solid colors — do NOT reference external texture files
- Include lighting: AmbientLight + DirectionalLight at minimum
- Add a Sky color via scene.background
- Generate sounds with Web Audio API (oscillators) — do NOT reference external audio files
- Include a title overlay with the game name and "Click to start"
- Include game-over overlay with "Press R to restart"
- Code must run in any modern browser with zero dependencies beyond the import map
- No external API calls, no fetch(), no localStorage usage
- Use requestAnimationFrame for the game loop
- Properly handle pointer lock for FPS-style controls if used

QUALITY REQUIREMENTS:
- Game must be FUN and PLAYABLE for at least 30 seconds
- Add visual polish: dynamic lighting, particles, fog, color
- Add sound effects using Web Audio
- Difficulty must scale or game must have a clear progression
- Code must be production-quality — no console.log spam, no commented-out code, no TODO comments
- Camera controls must feel responsive — handle mouse sensitivity

If the user prompt is vague, make creative decisions and ship a complete game."""


def _user_message(prompt: str, mode: str) -> str:
    """The user-message wrapper passed to the LLM."""
    return (
        f"Build me this game (mode: {mode.upper()}): {prompt}\n\n"
        "Return ONLY the complete HTML file. Start with <!DOCTYPE html>. "
        "No prose, no markdown fences."
    )


# ---------------------------------------------------------------------------
# LLM providers
# ---------------------------------------------------------------------------

def _call_anthropic(system: str, user: str) -> Optional[str]:
    if not API_KEY:
        return None
    model = MODEL_OVERRIDE or DEFAULT_MODELS["anthropic"]
    body = json.dumps({
        "model": model,
        "max_tokens": MAX_TOKENS,
        "system": system,
        "messages": [{"role": "user", "content": user}],
    }).encode("utf-8")
    req = urllib.request.Request(
        "https://api.anthropic.com/v1/messages",
        data=body,
        headers={
            "x-api-key": API_KEY,
            "anthropic-version": "2023-06-01",
            "content-type": "application/json",
        },
        method="POST",
    )
    try:
        with urllib.request.urlopen(req, timeout=REQUEST_TIMEOUT) as resp:
            data = json.loads(resp.read().decode("utf-8"))
        for block in data.get("content", []):
            if block.get("type") == "text":
                return block.get("text", "")
        return None
    except urllib.error.HTTPError as e:
        try:
            err_body = e.read().decode("utf-8", errors="ignore")[:200]
        except Exception:
            err_body = ""
        raise BuilderError(f"Anthropic API error {e.code}: {err_body}")
    except (urllib.error.URLError, json.JSONDecodeError, KeyError) as e:
        raise BuilderError(f"Anthropic API call failed: {e}")


def _call_openai(system: str, user: str) -> Optional[str]:
    if not API_KEY:
        return None
    model = MODEL_OVERRIDE or DEFAULT_MODELS["openai"]
    body = json.dumps({
        "model": model,
        "max_tokens": MAX_TOKENS,
        "messages": [
            {"role": "system", "content": system},
            {"role": "user", "content": user},
        ],
    }).encode("utf-8")
    req = urllib.request.Request(
        "https://api.openai.com/v1/chat/completions",
        data=body,
        headers={
            "Authorization": f"Bearer {API_KEY}",
            "Content-Type": "application/json",
        },
        method="POST",
    )
    try:
        with urllib.request.urlopen(req, timeout=REQUEST_TIMEOUT) as resp:
            data = json.loads(resp.read().decode("utf-8"))
        return data["choices"][0]["message"]["content"]
    except urllib.error.HTTPError as e:
        try:
            err_body = e.read().decode("utf-8", errors="ignore")[:200]
        except Exception:
            err_body = ""
        raise BuilderError(f"OpenAI API error {e.code}: {err_body}")
    except (urllib.error.URLError, json.JSONDecodeError, KeyError) as e:
        raise BuilderError(f"OpenAI API call failed: {e}")


# ---------------------------------------------------------------------------
# HTML extraction & sanitization
# ---------------------------------------------------------------------------

class BuilderError(Exception):
    """Raised when game generation fails. Caller turns this into a 4xx/5xx response."""
    pass


def _extract_html(raw: str) -> str:
    """Pull the HTML document out of the LLM response. Strict — no markdown fences."""
    if not raw or not isinstance(raw, str):
        raise BuilderError("LLM returned empty response")

    raw = raw.strip()

    # Strip leading/trailing markdown fences if the LLM disobeyed
    if raw.startswith("```"):
        lines = raw.split("\n")
        # Drop first fence line
        lines = lines[1:]
        # Drop trailing fence
        if lines and lines[-1].strip().startswith("```"):
            lines = lines[:-1]
        raw = "\n".join(lines).strip()

    # Find <!DOCTYPE html> to <\/html>
    lower = raw.lower()
    start = lower.find("<!doctype html")
    if start == -1:
        start = lower.find("<html")
    end_marker = lower.rfind("</html>")
    if start == -1 or end_marker == -1:
        raise BuilderError("LLM response missing valid HTML document structure")

    html_doc = raw[start:end_marker + len("</html>")]
    return html_doc


def _security_check(html_doc: str) -> None:
    """Block dangerous patterns. Generated games must be self-contained."""
    lower = html_doc.lower()

    # Block any external network calls or auth endpoints
    forbidden_patterns = [
        ("fetch(",            "fetch() is not allowed in generated games"),
        ("xmlhttprequest",    "XMLHttpRequest is not allowed"),
        ("websocket",         "WebSocket is not allowed"),
        ("navigator.sendbeacon", "sendBeacon is not allowed"),
        ("eval(",             "eval() is not allowed"),
        ("document.cookie",   "cookie access is not allowed"),
        ("localstorage",      "localStorage is not allowed"),
        ("sessionstorage",    "sessionStorage is not allowed"),
        ("indexeddb",         "indexedDB is not allowed"),
        ("<iframe",           "iframes are not allowed in generated games"),
        ("<object",           "object tags are not allowed"),
        ("<embed",            "embed tags are not allowed"),
    ]
    for pat, msg in forbidden_patterns:
        if pat in lower:
            raise BuilderError(f"Security: {msg}")

    # Allow only the known CDN imports
    allowed_origins = (
        "cdn.jsdelivr.net",
        "unpkg.com",
        "cdnjs.cloudflare.com",
        "fonts.googleapis.com",
        "fonts.gstatic.com",
    )
    # Find all src/href targets
    for match in re.finditer(r'(?:src|href)\s*=\s*[\'"]([^\'"]+)[\'"]', html_doc, re.IGNORECASE):
        url = match.group(1).strip().lower()
        if url.startswith("http://") or url.startswith("https://") or url.startswith("//"):
            if not any(origin in url for origin in allowed_origins):
                raise BuilderError(f"Security: external resource not allowed: {url[:80]}")

    # Block inline event-style URL handlers that try to escape
    if "javascript:" in lower:
        raise BuilderError("Security: javascript: URLs not allowed")


# ---------------------------------------------------------------------------
# Rate limiting (per IP per day)
# ---------------------------------------------------------------------------

def _check_rate_limit(ip: str) -> Tuple[bool, int]:
    """Returns (allowed, count_today). Skip rate limit if ip is empty."""
    if not ip:
        return True, 0
    cutoff = time.time() - 86400
    with _connect() as conn:
        row = conn.execute(
            "SELECT COUNT(*) AS n FROM games WHERE ip=? AND created_at >= ?",
            (ip, cutoff),
        ).fetchone()
    count = row["n"] if row else 0
    return count < MAX_PER_IP_DAY, count


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def generate_game(prompt: str, mode: str = "2d", ip: str = "") -> Dict[str, Any]:
    """
    Generate a playable HTML5 game from a prompt.

    Returns:
      {
        "game_id":   "abc123def456",
        "play_url":  "/builder/play/abc123def456",
        "mode":      "2d" | "3d",
        "model":     "claude-opus-4-7",
        "size_bytes": 12345,
        "generated_in_seconds": 18.4
      }

    Raises BuilderError with a clear message on any failure.
    """
    # Validate input
    if not isinstance(prompt, str) or not prompt.strip():
        raise BuilderError("prompt is required")
    prompt = prompt.strip()[:MAX_PROMPT_LEN]

    if mode not in ("2d", "3d"):
        raise BuilderError("mode must be '2d' or '3d'")

    if not API_KEY:
        raise BuilderError(
            "Game builder requires an LLM API key. "
            "Set UE5PILOT_LLM_API_KEY on the server."
        )

    if PROVIDER not in ("anthropic", "openai"):
        raise BuilderError(f"unsupported LLM provider: {PROVIDER}")

    # Rate limit
    allowed, count = _check_rate_limit(ip)
    if not allowed:
        raise BuilderError(
            f"Daily limit reached ({MAX_PER_IP_DAY} games per day). "
            "Sign up for early access for higher limits."
        )

    # Generate
    system = SYSTEM_2D if mode == "2d" else SYSTEM_3D
    user = _user_message(prompt, mode)

    started = time.time()
    if PROVIDER == "anthropic":
        raw = _call_anthropic(system, user)
    else:
        raw = _call_openai(system, user)
    duration = time.time() - started

    if not raw:
        raise BuilderError("LLM returned empty response")

    # Extract and validate HTML
    html_doc = _extract_html(raw)
    _security_check(html_doc)

    # Sanity check: must contain Phaser (2d) or Three (3d) reference
    if mode == "2d" and "phaser" not in html_doc.lower():
        raise BuilderError("Generated game doesn't include Phaser — try again")
    if mode == "3d" and "three" not in html_doc.lower():
        raise BuilderError("Generated game doesn't include Three.js — try again")

    # Save
    game_id = uuid.uuid4().hex[:16]
    game_path = os.path.join(OUTPUT_DIR, f"{game_id}.html")
    with open(game_path, "w", encoding="utf-8") as f:
        f.write(html_doc)

    model = MODEL_OVERRIDE or DEFAULT_MODELS[PROVIDER]
    size = len(html_doc.encode("utf-8"))

    with _db_lock, _connect() as conn:
        conn.execute("""
            INSERT INTO games (game_id, mode, prompt, model, provider,
                              created_at, ip, size_bytes)
            VALUES (?,?,?,?,?,?,?,?)
        """, (game_id, mode, prompt, model, PROVIDER, time.time(), ip, size))

    return {
        "game_id": game_id,
        "play_url": f"/builder/play/{game_id}",
        "mode": mode,
        "model": model,
        "size_bytes": size,
        "generated_in_seconds": round(duration, 2),
        "remaining_today": MAX_PER_IP_DAY - count - 1,
    }


def get_game_html(game_id: str) -> Optional[str]:
    """Return the raw HTML of a generated game, or None if not found."""
    if not re.match(r"^[a-f0-9]{16}$", game_id or ""):
        return None
    path = os.path.join(OUTPUT_DIR, f"{game_id}.html")
    if not os.path.exists(path):
        return None
    # Update play counter (fire-and-forget on errors)
    try:
        with _db_lock, _connect() as conn:
            conn.execute(
                "UPDATE games SET play_count = play_count + 1, last_played = ? WHERE game_id = ?",
                (time.time(), game_id),
            )
    except Exception:
        pass
    with open(path, "r", encoding="utf-8") as f:
        return f.read()


def get_game_meta(game_id: str) -> Optional[Dict[str, Any]]:
    """Return metadata about a game (for share previews, embeds)."""
    if not re.match(r"^[a-f0-9]{16}$", game_id or ""):
        return None
    with _connect() as conn:
        row = conn.execute(
            "SELECT * FROM games WHERE game_id = ?", (game_id,)
        ).fetchone()
    return dict(row) if row else None


def list_recent_games(limit: int = 20, mode: Optional[str] = None) -> list:
    """For a public 'recently built' showcase."""
    with _connect() as conn:
        if mode in ("2d", "3d"):
            rows = conn.execute("""
                SELECT game_id, mode, prompt, created_at, play_count, size_bytes
                FROM games WHERE mode = ?
                ORDER BY created_at DESC LIMIT ?
            """, (mode, limit)).fetchall()
        else:
            rows = conn.execute("""
                SELECT game_id, mode, prompt, created_at, play_count, size_bytes
                FROM games
                ORDER BY created_at DESC LIMIT ?
            """, (limit,)).fetchall()
    return [dict(r) for r in rows]


def get_builder_info() -> Dict[str, Any]:
    """Diagnostic for /health and /info endpoints."""
    with _connect() as conn:
        total = conn.execute("SELECT COUNT(*) AS n FROM games").fetchone()["n"]
        by_mode = conn.execute(
            "SELECT mode, COUNT(*) AS n FROM games GROUP BY mode"
        ).fetchall()
    return {
        "provider": PROVIDER,
        "model": MODEL_OVERRIDE or DEFAULT_MODELS.get(PROVIDER, "n/a"),
        "api_key_configured": bool(API_KEY),
        "output_dir": OUTPUT_DIR,
        "max_per_ip_day": MAX_PER_IP_DAY,
        "total_games_generated": total,
        "by_mode": {row["mode"]: row["n"] for row in by_mode},
    }


if __name__ == "__main__":
    print("prompttogame.ai — Game Builder")
    print(json.dumps(get_builder_info(), indent=2))
