"""
UE5Pilot Premium Endpoints

Registers HTTP endpoints for the 10 premium modules. The main server
imports `route_premium(path, method, body)` and calls it for paths
starting with /premium/.

Endpoints follow the pattern: /premium/{module}/{action}

All endpoints return JSON. Errors return {"error": "..."} with appropriate
HTTP status codes.
"""

from __future__ import annotations

import json
import base64
from typing import Dict, Any, Optional, Tuple

# Import premium modules — each one optional, server keeps running if any fails
_modules = {}
for name in ("llm_translator", "vision", "director", "rag",
             "sessions", "marketplace", "cinematic", "vcs", "voice",
             "enterprise", "builder"):
    try:
        mod = __import__(f"premium.{name}", fromlist=[name])
        _modules[name] = mod
    except ImportError as e:
        _modules[name] = None
        print(f"[premium] {name} unavailable: {e}")


# ---------------------------------------------------------------------------
# Route dispatcher
# ---------------------------------------------------------------------------

def route_premium(path: str, method: str, body: Optional[Dict[str, Any]] = None) -> Tuple[int, Dict[str, Any]]:
    """
    Main entry point. Returns (status_code, response_body).
    """
    body = body or {}
    parts = path.strip("/").split("/")
    if len(parts) < 2 or parts[0] != "premium":
        return 404, {"error": "not a premium endpoint"}

    module_name = parts[1]
    action = "/".join(parts[2:]) if len(parts) > 2 else ""

    mod = _modules.get(module_name)
    if mod is None:
        return 503, {"error": f"premium module '{module_name}' not available"}

    handler_name = f"_handle_{module_name}"
    handler = globals().get(handler_name)
    if not handler:
        return 404, {"error": f"no handler for module '{module_name}'"}

    try:
        return handler(action, method, body, mod)
    except PermissionError as e:
        return 403, {"error": str(e)}
    except ValueError as e:
        return 400, {"error": str(e)}
    except Exception as e:
        return 500, {"error": f"internal error: {e}"}


# ---------------------------------------------------------------------------
# Per-module handlers
# ---------------------------------------------------------------------------

def _handle_llm_translator(action, method, body, mod):
    if action == "translate" and method == "POST":
        text = body.get("text", "")
        return 200, {"commands": mod.translate(text)}
    if action == "info" and method == "GET":
        return 200, mod.get_provider_info()
    return 404, {"error": "unknown action"}


def _handle_vision(action, method, body, mod):
    if action == "assess" and method == "POST":
        image_b64 = body.get("image_base64", "")
        intent = body.get("intent", "")
        return 200, mod.assess_screenshot(image_b64, intent)
    if action == "info" and method == "GET":
        return 200, mod.get_vision_info()
    return 404, {"error": "unknown action"}


def _handle_director(action, method, body, mod):
    if action == "info" and method == "GET":
        return 200, {
            "llm_available": mod.LLM_AVAILABLE,
            "vision_available": mod.VISION_AVAILABLE,
            "max_iterations": mod.MAX_ITERATIONS,
            "min_match_score": mod.MIN_MATCH_SCORE,
        }
    if action == "direct" and method == "POST":
        # NOTE: Director needs an executor function — this endpoint
        # returns the plan only; execution happens server-side via main loop.
        intent = body.get("intent", "")
        if not intent:
            return 400, {"error": "intent required"}
        return 200, {
            "intent": intent,
            "note": "Use the main server's /direct endpoint for full execution loop",
        }
    return 404, {"error": "unknown action"}


def _handle_rag(action, method, body, mod):
    if action == "index" and method == "POST":
        project_root = body.get("project_root", "")
        return 200, mod.index_project(project_root)
    if action == "query" and method == "POST":
        return 200, {
            "results": mod.query_project(
                body.get("project_root", ""),
                body.get("query", ""),
                top_k=body.get("top_k", 10),
                kind=body.get("kind"),
            )
        }
    if action == "info" and method == "GET":
        return 200, mod.get_rag_info()
    return 404, {"error": "unknown action"}


def _handle_sessions(action, method, body, mod):
    if action == "workspaces/create" and method == "POST":
        return 200, mod.create_workspace(body.get("name", ""), body.get("user_id", ""),
                                        body.get("ue5_project_path"))
    if action == "workspaces/list" and method == "POST":
        return 200, {"workspaces": mod.list_workspaces(body.get("user_id", ""))}
    if action == "members/add" and method == "POST":
        return 200, mod.add_member(body["workspace_id"], body["user_id"],
                                  body["role"], body["invited_by"])
    if action == "members/list" and method == "POST":
        return 200, {"members": mod.list_members(body["workspace_id"])}
    if action == "session/open" and method == "POST":
        return 200, mod.open_session(body["user_id"], body["workspace_id"])
    if action == "session/heartbeat" and method == "POST":
        return 200, {"alive": mod.heartbeat(body["token"])}
    if action == "presence" and method == "POST":
        return 200, {"presence": mod.get_presence(body["workspace_id"])}
    if action == "info" and method == "GET":
        return 200, mod.get_sessions_info()
    return 404, {"error": "unknown action"}


def _handle_marketplace(action, method, body, mod):
    if action == "search" and method == "POST":
        return 200, mod.search_assets(
            body.get("query", ""),
            providers=body.get("providers"),
            limit_per=body.get("limit_per", 5),
        )
    if action == "download" and method == "POST":
        return 200, mod.download_asset(
            body.get("provider", ""), body.get("asset_id", ""),
            body.get("target_dir", "")
        )
    if action == "info" and method == "GET":
        return 200, mod.get_marketplace_info()
    return 404, {"error": "unknown action"}


def _handle_cinematic(action, method, body, mod):
    if action == "render" and method == "POST":
        job = mod.build_render_job(
            sequence_path=body["sequence_path"],
            output_dir=body["output_dir"],
            format=body.get("format", "mp4"),
            resolution=tuple(body.get("resolution", (1920, 1080))),
            fps=body.get("fps", 24),
            quality=body.get("quality", "standard"),
        )
        return 200, mod.queue_render(job) | {"job": job}
    if action == "status" and method == "POST":
        status = mod.get_render_status(body["job_id"])
        if not status:
            return 404, {"error": "job not found"}
        return 200, status
    if action == "list" and method == "POST":
        return 200, {"jobs": mod.list_render_jobs(body.get("status_filter"))}
    if action == "camera_path" and method == "POST":
        return 200, mod.generate_camera_sequence(
            body["camera_path"], body.get("duration", 10.0),
            body.get("target_actor"), body.get("starting_location"),
        )
    if action == "info" and method == "GET":
        return 200, mod.get_cinematic_info()
    return 404, {"error": "unknown action"}


def _handle_vcs(action, method, body, mod):
    if action == "snapshot" and method == "POST":
        return 200, mod.snapshot(
            body["workspace_id"], body["scene_json"],
            label=body.get("label", ""), branch=body.get("branch", "main"),
            user_id=body.get("user_id"),
        )
    if action == "snapshots" and method == "POST":
        return 200, {"snapshots": mod.list_snapshots(
            body["workspace_id"], branch=body.get("branch"),
            limit=body.get("limit", 100),
        )}
    if action == "branches" and method == "POST":
        return 200, {"branches": mod.list_branches(body["workspace_id"])}
    if action == "branch_from" and method == "POST":
        return 200, mod.branch_from(body["workspace_id"], body["source_branch"],
                                   body["new_branch"], user_id=body.get("user_id"))
    if action == "diff" and method == "POST":
        return 200, mod.diff_snapshots(body["snap_a_id"], body["snap_b_id"])
    if action == "merge" and method == "POST":
        return 200, mod.merge_branches(
            body["workspace_id"], body["into_branch"], body["from_branch"],
            user_id=body.get("user_id"),
            conflict_strategy=body.get("conflict_strategy", "from_wins"),
        )
    if action == "restore" and method == "POST":
        payload = mod.get_restore_payload(body["snapshot_id"])
        if not payload:
            return 404, {"error": "snapshot not found"}
        return 200, {"scene_json": payload}
    if action == "info" and method == "GET":
        return 200, mod.get_vcs_info()
    return 404, {"error": "unknown action"}


def _handle_voice(action, method, body, mod):
    if action == "transcribe" and method == "POST":
        audio_b64 = body.get("audio_base64", "")
        if not audio_b64:
            return 400, {"error": "audio_base64 required"}
        try:
            audio_bytes = base64.b64decode(audio_b64)
        except Exception:
            return 400, {"error": "invalid base64 audio"}
        return 200, mod.transcribe_audio(audio_bytes, body.get("mime_type", "audio/wav"))
    if action == "speak" and method == "POST":
        return 200, mod.synthesize_speech(body.get("text", ""), body.get("voice"))
    if action == "info" and method == "GET":
        return 200, mod.get_voice_info()
    return 404, {"error": "unknown action"}


def _handle_builder(action, method, body, mod):
    if action == "generate" and method == "POST":
        try:
            result = mod.generate_game(
                body.get("prompt", ""),
                mode=body.get("mode", "2d"),
                ip=body.get("ip", ""),
            )
            return 200, result
        except mod.BuilderError as e:
            return 400, {"error": str(e)}
    if action == "play" and method == "POST":
        html = mod.get_game_html(body.get("game_id", ""))
        if html is None:
            return 404, {"error": "game not found"}
        return 200, {"html": html}
    if action == "meta" and method == "POST":
        meta = mod.get_game_meta(body.get("game_id", ""))
        if meta is None:
            return 404, {"error": "game not found"}
        return 200, meta
    if action == "recent" and method == "POST":
        return 200, {"games": mod.list_recent_games(
            limit=body.get("limit", 20),
            mode=body.get("mode"),
        )}
    if action == "info" and method == "GET":
        return 200, mod.get_builder_info()
    return 404, {"error": "unknown action"}


def _handle_enterprise(action, method, body, mod):
    if action == "org/create" and method == "POST":
        return 200, mod.create_organization(body["name"], body["owner_user_id"],
                                           plan=body.get("plan", "free"))
    if action == "org/get" and method == "POST":
        org = mod.get_organization(body["org_id"])
        if not org:
            return 404, {"error": "org not found"}
        return 200, org
    if action == "org/upgrade" and method == "POST":
        return 200, mod.upgrade_plan(body["org_id"], body["new_plan"],
                                    stripe_subscription_id=body.get("stripe_subscription_id"))
    if action == "api_key/create" and method == "POST":
        return 200, mod.create_api_key(body["org_id"], body["created_by"])
    if action == "api_key/validate" and method == "POST":
        result = mod.validate_api_key(body.get("api_key", ""))
        return 200, result if result else {"valid": False}
    if action == "api_key/revoke" and method == "POST":
        mod.revoke_api_key(body["key_id"], body["revoked_by"])
        return 200, {"revoked": True}
    if action == "usage" and method == "POST":
        return 200, {"usage": mod.get_usage(body["org_id"], body.get("since_ts"))}
    if action == "quota" and method == "POST":
        return 200, mod.check_quota(body["org_id"], body.get("event_type", "command.executed"))
    if action == "audit" and method == "POST":
        return 200, {"events": mod.get_audit_events(body.get("org_id"), body.get("limit", 200))}
    if action == "info" and method == "GET":
        return 200, mod.get_enterprise_info()
    return 404, {"error": "unknown action"}


# ---------------------------------------------------------------------------
# Module status summary (for /health)
# ---------------------------------------------------------------------------

def get_premium_status() -> Dict[str, Any]:
    return {
        name: (mod is not None) for name, mod in _modules.items()
    }
