#!/bin/bash
# ============================================================
# prompttogame.ai — One-shot VPS Deployment
# ============================================================
# Run this AS ROOT on your Hostinger VPS (85.31.225.224)
#
# What it does:
#   1. Installs system dependencies (Python, nginx, certbot, ufw)
#   2. Creates the ue5pilot system user
#   3. Sets up /opt/prompttogame/ with all code
#   4. Configures nginx as reverse proxy for both
#      prompttogame.ai (landing) and api.prompttogame.ai (UE5Pilot API)
#   5. Opens firewall (22, 80, 443) — closes everything else
#   6. Installs systemd services for both web server + UE5Pilot
#   7. Optionally requests Let's Encrypt SSL (if --ssl passed)
#   8. Verifies everything is running
#
# Prerequisites before running:
#   - DNS A records for prompttogame.ai, www, and api → 85.31.225.224
#   - Upload the deploy package: scp prompttogame-deploy.zip root@VPS:/tmp/
#
# Usage:
#   bash deploy_prompttogame.sh           # HTTP only
#   bash deploy_prompttogame.sh --ssl     # HTTP + auto SSL
# ============================================================

set -e

DOMAIN="prompttogame.ai"
API_DOMAIN="api.prompttogame.ai"
WWW_DOMAIN="www.prompttogame.ai"
EMAIL="hello@prompttogame.ai"
APP_USER="ue5pilot"
APP_DIR="/opt/prompttogame"
DEPLOY_ZIP="${DEPLOY_ZIP:-/tmp/prompttogame-deploy.zip}"
ENABLE_SSL=false

for arg in "$@"; do
    case "$arg" in
        --ssl) ENABLE_SSL=true ;;
        --domain=*) DOMAIN="${arg#*=}" ;;
    esac
done

log()  { echo -e "\033[1;36m[$(date +%H:%M:%S)]\033[0m $*"; }
ok()   { echo -e "\033[1;32m  ✓\033[0m $*"; }
warn() { echo -e "\033[1;33m  ⚠\033[0m $*"; }
err()  { echo -e "\033[1;31m  ✗\033[0m $*" >&2; }

if [ "$EUID" -ne 0 ]; then
    err "Run as root: sudo bash $0"
    exit 1
fi

echo ""
echo "============================================================"
echo "  prompttogame.ai — Production Deployment"
echo "============================================================"
echo "  Domain:        $DOMAIN"
echo "  API:           $API_DOMAIN"
echo "  Deploy zip:    $DEPLOY_ZIP"
echo "  SSL:           $ENABLE_SSL"
echo "  App user:      $APP_USER"
echo "  App dir:       $APP_DIR"
echo "============================================================"
echo ""

# ============================================================
# 1. System packages
# ============================================================
log "Installing system packages…"
apt-get update -qq
apt-get install -y -qq python3 python3-pip python3-venv \
    nginx ufw unzip curl ca-certificates rsync >/dev/null
ok "Packages installed"

if $ENABLE_SSL; then
    apt-get install -y -qq certbot python3-certbot-nginx >/dev/null
    ok "Certbot installed"
fi

# ============================================================
# 2. User & directories
# ============================================================
log "Setting up app user and directories…"
if ! id -u "$APP_USER" >/dev/null 2>&1; then
    useradd -r -m -s /bin/bash "$APP_USER"
    ok "Created user: $APP_USER"
else
    ok "User $APP_USER already exists"
fi

mkdir -p "$APP_DIR"
mkdir -p /var/log/prompttogame
mkdir -p "$APP_DIR/data"
chown -R "$APP_USER:$APP_USER" "$APP_DIR" /var/log/prompttogame

# ============================================================
# 3. Deploy code
# ============================================================
log "Deploying application code…"
if [ ! -f "$DEPLOY_ZIP" ]; then
    err "Deploy zip not found at $DEPLOY_ZIP"
    err "Upload it first: scp prompttogame-deploy.zip root@$(hostname -I | awk '{print $1}'):/tmp/"
    exit 1
fi

TMP_EXTRACT=$(mktemp -d)
unzip -q "$DEPLOY_ZIP" -d "$TMP_EXTRACT"

# The zip contains a 'ue5pilot' folder at top level
if [ -d "$TMP_EXTRACT/ue5pilot" ]; then
    rsync -a --delete "$TMP_EXTRACT/ue5pilot/" "$APP_DIR/"
    ok "Code deployed to $APP_DIR"
else
    err "Expected 'ue5pilot' folder inside zip, not found"
    rm -rf "$TMP_EXTRACT"
    exit 1
fi
rm -rf "$TMP_EXTRACT"
chown -R "$APP_USER:$APP_USER" "$APP_DIR"

# ============================================================
# 4. Python dependencies (minimal - stdlib mostly)
# ============================================================
log "Installing Python dependencies…"
pip3 install --break-system-packages --quiet requests 2>/dev/null \
    || pip3 install --quiet requests 2>/dev/null \
    || true
ok "Python dependencies installed"

# ============================================================
# 5. Environment file
# ============================================================
log "Creating environment file…"
ENV_FILE="$APP_DIR/.env"
if [ ! -f "$ENV_FILE" ]; then
    cat > "$ENV_FILE" <<'ENVEOF'
# ============================================================
# prompttogame.ai — Environment Configuration
# ============================================================
# Edit this file and restart services:
#   nano /opt/prompttogame/.env
#   systemctl restart ue5pilot prompttogame-web
# ============================================================

# --- LLM Translator (Anthropic Claude or OpenAI GPT) ---
# Leave empty to use the regex-based fallback translator
UE5PILOT_LLM_PROVIDER=anthropic
UE5PILOT_LLM_API_KEY=

# --- Server Configuration ---
UE5PILOT_API_KEY=
WEB_PORT=8080
PORT=8791

# --- Optional Premium Features ---
# UE5PILOT_STT_PROVIDER=openai_whisper
# UE5PILOT_STT_API_KEY=
# UE5PILOT_TTS_PROVIDER=elevenlabs
# UE5PILOT_TTS_API_KEY=
# UE5PILOT_TTS_VOICE=

# --- Marketplace Integrations ---
# QUIXEL_API_TOKEN=
# SKETCHFAB_API_TOKEN=
# FAB_API_TOKEN=

# --- Stripe Billing ---
# UE5PILOT_STRIPE_WEBHOOK_SECRET=
# UE5PILOT_STRIPE_PRICE_PRO=
# UE5PILOT_STRIPE_PRICE_STUDIO=
ENVEOF
    chmod 600 "$ENV_FILE"
    chown "$APP_USER:$APP_USER" "$ENV_FILE"
    ok "Created $ENV_FILE (fill in your API keys here)"
else
    ok "Environment file already exists, leaving it alone"
fi

# ============================================================
# 6. Systemd services
# ============================================================
log "Installing systemd services…"

# UE5Pilot API service
cat > /etc/systemd/system/ue5pilot.service <<EOF
[Unit]
Description=UE5Pilot Cloud Command Server
After=network.target

[Service]
Type=simple
User=$APP_USER
Group=$APP_USER
WorkingDirectory=$APP_DIR/server
EnvironmentFile=$APP_DIR/.env
ExecStart=/usr/bin/python3 $APP_DIR/server/ue5pilot_server.py
Restart=on-failure
RestartSec=5
StandardOutput=append:/var/log/prompttogame/ue5pilot.log
StandardError=append:/var/log/prompttogame/ue5pilot.error.log
NoNewPrivileges=true
PrivateTmp=true

[Install]
WantedBy=multi-user.target
EOF

# Web server (landing + playground + waitlist API)
cat > /etc/systemd/system/prompttogame-web.service <<EOF
[Unit]
Description=prompttogame.ai Web Server
After=network.target

[Service]
Type=simple
User=$APP_USER
Group=$APP_USER
WorkingDirectory=$APP_DIR/web/api
EnvironmentFile=$APP_DIR/.env
ExecStart=/usr/bin/python3 $APP_DIR/web/api/web_server.py
Restart=on-failure
RestartSec=5
StandardOutput=append:/var/log/prompttogame/web.log
StandardError=append:/var/log/prompttogame/web.error.log
NoNewPrivileges=true
PrivateTmp=true

[Install]
WantedBy=multi-user.target
EOF

systemctl daemon-reload
ok "Systemd services installed"

# ============================================================
# 7. Nginx reverse proxy
# ============================================================
log "Configuring nginx…"

cat > /etc/nginx/sites-available/prompttogame <<EOF
# Landing page + playground + waitlist
server {
    listen 80;
    listen [::]:80;
    server_name $DOMAIN $WWW_DOMAIN;
    client_max_body_size 5M;

    location / {
        proxy_pass http://127.0.0.1:8080;
        proxy_http_version 1.1;
        proxy_set_header Host \$host;
        proxy_set_header X-Real-IP \$remote_addr;
        proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto \$scheme;
        proxy_read_timeout 60s;
    }
}

# UE5Pilot API
server {
    listen 80;
    listen [::]:80;
    server_name $API_DOMAIN;
    client_max_body_size 20M;

    location / {
        proxy_pass http://127.0.0.1:8791;
        proxy_http_version 1.1;
        proxy_set_header Host \$host;
        proxy_set_header X-Real-IP \$remote_addr;
        proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto \$scheme;
        proxy_read_timeout 120s;
        proxy_send_timeout 120s;
    }
}
EOF

ln -sf /etc/nginx/sites-available/prompttogame /etc/nginx/sites-enabled/prompttogame
rm -f /etc/nginx/sites-enabled/default
nginx -t >/dev/null 2>&1 && ok "Nginx config valid" || { err "Nginx config invalid"; nginx -t; exit 1; }
systemctl reload nginx
ok "Nginx configured and reloaded"

# ============================================================
# 8. Firewall
# ============================================================
log "Configuring firewall…"
ufw --force reset >/dev/null
ufw default deny incoming >/dev/null
ufw default allow outgoing >/dev/null
ufw allow 22/tcp comment 'SSH' >/dev/null
ufw allow 80/tcp comment 'HTTP' >/dev/null
ufw allow 443/tcp comment 'HTTPS' >/dev/null
ufw --force enable >/dev/null
ok "Firewall: 22, 80, 443 open"

# ============================================================
# 9. Start services
# ============================================================
log "Starting services…"
systemctl enable ue5pilot prompttogame-web >/dev/null 2>&1
systemctl restart prompttogame-web
systemctl restart ue5pilot
sleep 3

if systemctl is-active --quiet prompttogame-web; then
    ok "prompttogame-web: RUNNING"
else
    err "prompttogame-web FAILED to start"
    journalctl -u prompttogame-web -n 30 --no-pager
fi

if systemctl is-active --quiet ue5pilot; then
    ok "ue5pilot: RUNNING"
else
    warn "ue5pilot didn't start (this is okay if you haven't deployed the server code yet)"
    journalctl -u ue5pilot -n 10 --no-pager 2>/dev/null | head -20
fi

# ============================================================
# 10. SSL via Let's Encrypt (optional)
# ============================================================
if $ENABLE_SSL; then
    log "Requesting SSL certificates…"
    warn "Make sure DNS is propagated! Test with: dig $DOMAIN +short"
    sleep 2
    certbot --nginx -d "$DOMAIN" -d "$WWW_DOMAIN" -d "$API_DOMAIN" \
        --non-interactive --agree-tos --email "$EMAIL" --redirect || \
        warn "SSL failed — you can retry later with: certbot --nginx -d $DOMAIN -d $WWW_DOMAIN -d $API_DOMAIN"
fi

# ============================================================
# Done
# ============================================================
PUBLIC_IP=$(curl -s --max-time 3 ifconfig.me || hostname -I | awk '{print $1}')

echo ""
echo "============================================================"
echo "  ✓ DEPLOYMENT COMPLETE"
echo "============================================================"
echo ""
echo "  Site:           http://$DOMAIN"
echo "  Playground:     http://$DOMAIN/playground"
echo "  API:            http://$API_DOMAIN"
echo "  Health (web):   curl http://127.0.0.1:8080/api/health"
echo "  Health (API):   curl http://127.0.0.1:8791/health"
echo ""
echo "  Public IP:      $PUBLIC_IP"
echo "  Logs:           journalctl -u prompttogame-web -f"
echo "                  journalctl -u ue5pilot -f"
echo ""
echo "  Config:         nano $APP_DIR/.env"
echo "  Restart all:    systemctl restart prompttogame-web ue5pilot"
echo ""
if ! $ENABLE_SSL; then
    echo "  Next step: enable SSL with:"
    echo "    certbot --nginx -d $DOMAIN -d $WWW_DOMAIN -d $API_DOMAIN"
    echo ""
fi
echo "============================================================"
