// prompttogame.ai — builder.js

(function() {
  'use strict';

  // ---- Element refs ----
  const promptEl = document.getElementById('bd-prompt');
  const charEl = document.getElementById('bd-char');
  const generateBtn = document.getElementById('bd-generate');
  const ctaText = generateBtn.querySelector('.bd-cta-text');
  const modeButtons = document.querySelectorAll('.bd-mode');
  const pills2d = document.getElementById('bd-pills-2d');
  const pills3d = document.getElementById('bd-pills-3d');

  const stageEmpty = document.getElementById('bd-stage-empty');
  const stageLoading = document.getElementById('bd-stage-loading');
  const stageGame = document.getElementById('bd-stage-game');
  const stageError = document.getElementById('bd-stage-error');

  const loaderMsg = document.getElementById('bd-loader-msg');
  const loaderStep = document.getElementById('bd-loader-step');

  const gameIframe = document.getElementById('bd-iframe');
  const gameMode = document.getElementById('bd-game-mode');
  const gameMeta = document.getElementById('bd-game-meta');
  const gamePromptEl = document.getElementById('bd-game-prompt');

  const restartBtn = document.getElementById('bd-restart');
  const fullscreenBtn = document.getElementById('bd-fullscreen');
  const shareBtn = document.getElementById('bd-share');
  const newBtn = document.getElementById('bd-new');
  const retryBtn = document.getElementById('bd-retry');
  const errorMsg = document.getElementById('bd-error-msg');

  // ---- State ----
  let currentMode = '2d';
  let currentGameId = null;
  let isGenerating = false;
  let stepTimer = null;

  // ---- Mode toggle ----
  modeButtons.forEach(btn => {
    btn.addEventListener('click', () => {
      if (isGenerating) return;
      modeButtons.forEach(b => {
        b.classList.remove('active');
        b.setAttribute('aria-checked', 'false');
      });
      btn.classList.add('active');
      btn.setAttribute('aria-checked', 'true');
      currentMode = btn.dataset.mode;
      if (currentMode === '2d') {
        pills2d.classList.remove('hidden');
        pills3d.classList.add('hidden');
        promptEl.placeholder = 'e.g. A space shooter where you dodge asteroids and shoot lasers at alien ships';
      } else {
        pills2d.classList.add('hidden');
        pills3d.classList.remove('hidden');
        promptEl.placeholder = 'e.g. A first-person maze where you find keys and escape before time runs out';
      }
    });
  });

  // ---- Character counter ----
  function updateCharCount() {
    const len = promptEl.value.length;
    charEl.textContent = len;
    const meta = document.querySelector('.bd-char-count');
    if (len > 580) meta.classList.add('over');
    else meta.classList.remove('over');
  }
  promptEl.addEventListener('input', updateCharCount);

  // ---- Example pill clicks ----
  document.querySelectorAll('.pg-pill').forEach(pill => {
    pill.addEventListener('click', () => {
      if (isGenerating) return;
      promptEl.value = pill.dataset.prompt;
      updateCharCount();
      promptEl.focus();
    });
  });

  // ---- Stage state ----
  function showStage(which) {
    [stageEmpty, stageLoading, stageGame, stageError].forEach(el => el.classList.add('hidden'));
    which.classList.remove('hidden');
  }

  // ---- Loading messages ----
  const LOADING_STEPS = [
    '→ Designing mechanics',
    '→ Choosing art style',
    '→ Writing game logic',
    '→ Generating procedural sprites',
    '→ Composing sound effects',
    '→ Wiring controls',
    '→ Tuning difficulty',
    '→ Compiling final build',
    '→ Almost done…',
  ];
  function startStepRotation() {
    let i = 0;
    loaderStep.textContent = LOADING_STEPS[0];
    stepTimer = setInterval(() => {
      i = (i + 1) % LOADING_STEPS.length;
      loaderStep.textContent = LOADING_STEPS[i];
    }, 4500);
  }
  function stopStepRotation() {
    if (stepTimer) { clearInterval(stepTimer); stepTimer = null; }
  }

  // ---- Generation ----
  async function generate() {
    const prompt = promptEl.value.trim();
    if (!prompt) {
      promptEl.focus();
      return;
    }
    if (isGenerating) return;

    isGenerating = true;
    generateBtn.disabled = true;
    ctaText.textContent = 'Generating…';
    showStage(stageLoading);
    loaderMsg.textContent = `Building your ${currentMode.toUpperCase()} game…`;
    startStepRotation();

    try {
      const resp = await fetch('/api/builder/generate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ prompt, mode: currentMode }),
      });
      const data = await resp.json();
      stopStepRotation();

      if (!resp.ok) {
        throw new Error(data.error || `Server returned ${resp.status}`);
      }

      currentGameId = data.game_id;
      gameIframe.src = data.play_url;
      gameMode.textContent = currentMode.toUpperCase();
      gameMeta.textContent = `${(data.size_bytes / 1024).toFixed(1)} KB · ${data.generated_in_seconds}s · ${data.model}`;
      gamePromptEl.textContent = '"' + prompt + '"';
      showStage(stageGame);

      // Update URL so the game is shareable
      try {
        history.pushState(null, '', `/builder?id=${data.game_id}`);
      } catch (e) { /* ignore */ }
    } catch (err) {
      stopStepRotation();
      errorMsg.textContent = err.message || 'Generation failed. Please try again.';
      showStage(stageError);
    } finally {
      isGenerating = false;
      generateBtn.disabled = false;
      ctaText.textContent = 'Generate game';
    }
  }

  generateBtn.addEventListener('click', generate);

  promptEl.addEventListener('keydown', (e) => {
    if ((e.ctrlKey || e.metaKey) && e.key === 'Enter') {
      e.preventDefault();
      generate();
    }
  });

  // ---- Game controls ----
  restartBtn.addEventListener('click', () => {
    if (currentGameId) {
      gameIframe.src = `/builder/play/${currentGameId}?r=${Date.now()}`;
    }
  });

  fullscreenBtn.addEventListener('click', () => {
    if (!gameIframe) return;
    if (!document.fullscreenElement) {
      gameIframe.requestFullscreen?.() || gameIframe.webkitRequestFullscreen?.();
    } else {
      document.exitFullscreen?.();
    }
  });

  shareBtn.addEventListener('click', async () => {
    if (!currentGameId) return;
    const url = `${location.origin}/builder?id=${currentGameId}`;
    try {
      await navigator.clipboard.writeText(url);
      const orig = shareBtn.textContent;
      shareBtn.textContent = '✓';
      setTimeout(() => { shareBtn.textContent = orig; }, 1500);
    } catch (e) {
      window.prompt('Copy this share link:', url);
    }
  });

  newBtn.addEventListener('click', (e) => {
    e.preventDefault();
    promptEl.value = '';
    updateCharCount();
    currentGameId = null;
    gameIframe.src = 'about:blank';
    showStage(stageEmpty);
    try { history.pushState(null, '', '/builder'); } catch (err) {}
    promptEl.focus();
  });

  retryBtn.addEventListener('click', () => {
    showStage(stageEmpty);
    promptEl.focus();
  });

  // ---- Shared game ID in URL ----
  function loadFromUrl() {
    const params = new URLSearchParams(location.search);
    const id = params.get('id');
    if (id && /^[a-f0-9]{16}$/.test(id)) {
      currentGameId = id;
      gameIframe.src = `/builder/play/${id}`;
      gameMode.textContent = '?';
      gameMeta.textContent = 'Shared game';
      gamePromptEl.textContent = 'Loaded from share link';
      showStage(stageGame);
    }
  }
  loadFromUrl();

  updateCharCount();
})();
