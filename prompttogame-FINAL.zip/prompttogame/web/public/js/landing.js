// prompttogame.ai — landing.js

(function() {
  'use strict';

  // ============================================================
  // 1. Typewriter effect on the demo card
  // ============================================================
  const PROMPTS = [
    "make this look like a noir alley at midnight",
    "set up a forest with golden hour light",
    "blade runner street scene, neon and rain",
    "haunted victorian library, dust motes, candle light",
    "ai patrol enemy with behavior tree",
    "render this as 4k mp4, cinematic",
  ];

  const typed = document.getElementById('demo-typed');
  const responseLines = [
    document.getElementById('demo-r1'),
    document.getElementById('demo-r2'),
    document.getElementById('demo-r3'),
    document.getElementById('demo-r4'),
    document.getElementById('demo-r5'),
    document.getElementById('demo-r6'),
  ];

  let promptIdx = 0;

  async function typeText(text, el, speed = 45) {
    for (let i = 0; i <= text.length; i++) {
      el.textContent = text.slice(0, i);
      await wait(speed + Math.random() * 30);
    }
  }
  async function eraseText(el, speed = 20) {
    const text = el.textContent;
    for (let i = text.length; i >= 0; i--) {
      el.textContent = text.slice(0, i);
      await wait(speed);
    }
  }
  function wait(ms) { return new Promise(r => setTimeout(r, ms)); }

  async function runDemoCycle() {
    if (!typed) return;
    while (true) {
      const p = PROMPTS[promptIdx % PROMPTS.length];
      // Type the prompt
      responseLines.forEach(el => el && el.classList.remove('show'));
      await typeText(p, typed);
      await wait(400);
      // Reveal responses one by one
      for (const el of responseLines) {
        if (!el) continue;
        el.classList.add('show');
        await wait(280);
      }
      await wait(3200);
      // Erase and loop
      await eraseText(typed);
      await wait(400);
      promptIdx++;
    }
  }

  // Only run typewriter when hero is visible (saves CPU)
  if (typed && 'IntersectionObserver' in window) {
    const heroObserver = new IntersectionObserver((entries) => {
      entries.forEach(e => {
        if (e.isIntersecting) {
          runDemoCycle();
          heroObserver.disconnect();
        }
      });
    });
    heroObserver.observe(typed);
  } else if (typed) {
    runDemoCycle();
  }

  // ============================================================
  // 2. Waitlist form submission
  // ============================================================
  const form = document.getElementById('waitlist-form');
  const status = document.getElementById('form-status');

  if (form) {
    form.addEventListener('submit', async (e) => {
      e.preventDefault();
      status.classList.remove('error');
      status.textContent = 'Submitting…';

      const data = {
        email:   form.email.value.trim(),
        studio:  form.studio.value.trim(),
        usecase: form.usecase.value,
        tier:    form.tier.value,
        ts:      Date.now(),
        ua:      navigator.userAgent.slice(0, 200),
      };

      if (!data.email || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(data.email)) {
        status.classList.add('error');
        status.textContent = 'Please enter a valid email.';
        return;
      }

      const submitBtn = form.querySelector('.form-submit');
      submitBtn.disabled = true;

      try {
        const resp = await fetch('/api/waitlist', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(data),
        });
        if (resp.ok) {
          status.textContent = "✓ You're on the list. We'll be in touch.";
          form.reset();
        } else {
          const j = await resp.json().catch(() => ({}));
          status.classList.add('error');
          status.textContent = j.error || 'Something went wrong. Try again?';
        }
      } catch (err) {
        status.classList.add('error');
        status.textContent = 'Network error. Try again in a moment.';
      } finally {
        submitBtn.disabled = false;
      }
    });
  }

  // ============================================================
  // 3. Smooth scroll for anchor links (handle nav fixed height)
  // ============================================================
  document.querySelectorAll('a[href^="#"]').forEach(a => {
    a.addEventListener('click', (e) => {
      const id = a.getAttribute('href');
      if (id.length > 1) {
        const target = document.querySelector(id);
        if (target) {
          e.preventDefault();
          const top = target.getBoundingClientRect().top + window.scrollY - 64;
          window.scrollTo({ top, behavior: 'smooth' });
        }
      }
    });
  });

})();
