// prompttogame.ai — playground.js

(function() {
  'use strict';

  const input = document.getElementById('pg-input');
  const runBtn = document.getElementById('pg-run');
  const clearBtn = document.getElementById('pg-clear');
  const output = document.getElementById('pg-output');
  const status = document.getElementById('pg-status');
  const pills = document.querySelectorAll('.pg-pill');

  function setStatus(text, kind) {
    status.textContent = text;
    status.className = 'pg-output-status' + (kind ? ' ' + kind : '');
  }

  function renderJSON(obj) {
    const json = JSON.stringify(obj, null, 2);
    // simple syntax highlighting
    return json
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"([^"]+)":/g, '<span class="key">"$1"</span>:')
      .replace(/: "([^"]*)"/g, ': <span class="str">"$1"</span>')
      .replace(/: ([0-9.]+)/g, ': <span class="num">$1</span>');
  }

  async function runTranslate(prompt) {
    if (!prompt.trim()) {
      setStatus('empty', 'empty');
      output.innerHTML = '<span class="comment">// Please enter a prompt.</span>';
      return;
    }
    setStatus('translating…', 'running');
    output.innerHTML = '<span class="comment">// Calling /api/translate…</span>';

    try {
      const resp = await fetch('/api/translate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ text: prompt }),
      });
      const data = await resp.json();

      if (!resp.ok) {
        setStatus('error', 'empty');
        output.innerHTML = '<span class="comment">// API error</span>\n' + renderJSON(data);
        return;
      }

      const commands = data.commands || [];
      if (commands.length === 0) {
        setStatus('no match', 'empty');
        output.innerHTML = `<span class="comment">// No pattern matched this prompt.
// The regex translator only handles specific patterns.
// With an Anthropic API key configured, the LLM
// translator would understand this prompt.

// Try one of the examples below the input box,
// or rephrase using keywords like:
//   - "make it brighter / darker"
//   - "add a forest / mountain / fog"
//   - "cinematic / noir / golden hour"
//   - "set up enemy patrol AI"
//   - "render as 4k mp4"</span>`;
        return;
      }

      setStatus(`${commands.length} command${commands.length > 1 ? 's' : ''}`, 'ok');
      output.innerHTML = '<span class="comment">// Translated successfully. The companion would now\n// send these commands to your UE5 editor:</span>\n\n' + renderJSON(commands);
    } catch (err) {
      setStatus('network error', 'empty');
      output.innerHTML = '<span class="comment">// Network error: ' + err.message + '</span>';
    }
  }

  runBtn.addEventListener('click', () => runTranslate(input.value));
  clearBtn.addEventListener('click', () => {
    input.value = '';
    output.innerHTML = '<span class="comment">// Cleared. Type a new prompt.</span>';
    setStatus('idle');
    input.focus();
  });

  input.addEventListener('keydown', (e) => {
    if ((e.ctrlKey || e.metaKey) && e.key === 'Enter') {
      e.preventDefault();
      runTranslate(input.value);
    }
  });

  pills.forEach(pill => {
    pill.addEventListener('click', () => {
      input.value = pill.dataset.prompt;
      runTranslate(input.value);
    });
  });

})();
