"""
SuperNinja Windows Companion — Full Pipeline (Auto-Discover)

Runs on the Windows PC. Polls the SuperNinja cloud endpoint outbound,
fetches commands, forwards them to the local bridge (127.0.0.1:8765)
which queues them for the Unreal Python client to pick up.
The Unreal client executes the command and posts the result back to the bridge.
The companion then picks up the result and posts it back to the cloud.

Pipeline: Cloud → Companion → Bridge → Unreal → Bridge → Companion → Cloud

Run: python sn_companion_phase2.py
Requires: pip install requests

The cloud URL is auto-discovered by:
1. Checking the SN_CLOUD_URL environment variable
2. Checking a cloud_url.txt file in the same directory
3. Checking known tunnel URLs
4. Asking the user
"""

import json
import time
import os
import base64
import sys
import requests  # pip install requests

# ---------------------------------------------------------------------------
# Config
# ---------------------------------------------------------------------------
# Cloud endpoint — auto-discovered at startup
CLOUD_URL = None

# Local bridge (runs alongside this on Windows)
BRIDGE_URL = "http://127.0.0.1:8765"

# Screenshot directory (must match Unreal client config)
SCREENSHOT_DIR = os.path.join(
    os.environ.get("USERPROFILE", r"C:\Users\sbcam"),
    "OneDrive", "Desktop", "sn_screenshots"
)

# Polling intervals
CLOUD_POLL_INTERVAL = 1.0   # seconds between cloud polls
BRIDGE_RESULT_POLL = 0.5    # seconds between bridge result checks
RESULT_WAIT_TIMEOUT = 30.0  # max seconds to wait for Unreal to execute

# Max screenshot size to upload (10MB)
MAX_SCREENSHOT_SIZE = 10 * 1024 * 1024

# Known tunnel URLs — the companion will try these at startup
KNOWN_TUNNEL_URLS = [
    "https://refined-tough-museums-florence.trycloudflare.com",
    "https://receivers-brakes-madrid-sunset.trycloudflare.com",
]

# File to persist the discovered URL
CLOUD_URL_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "cloud_url.txt")


def discover_cloud_url():
    """Auto-discover the cloud server URL using multiple methods."""
    
    # Method 1: Environment variable
    env_url = os.environ.get("SN_CLOUD_URL", "").strip()
    if env_url:
        try:
            resp = requests.get(f"{env_url}/status", timeout=5)
            if resp.status_code == 200:
                print(f"[Companion] ✅ Found cloud via env var: {env_url}")
                return env_url
        except:
            print(f"[Companion] ⚠️  SN_CLOUD_URL set but not reachable: {env_url}")
    
    # Method 2: Saved URL file
    if os.path.exists(CLOUD_URL_FILE):
        try:
            with open(CLOUD_URL_FILE, 'r') as f:
                saved_url = f.read().strip()
            if saved_url:
                try:
                    resp = requests.get(f"{saved_url}/status", timeout=5)
                    if resp.status_code == 200:
                        print(f"[Companion] ✅ Found cloud via saved URL: {saved_url}")
                        return saved_url
                except:
                    print(f"[Companion] ⚠️  Saved URL not reachable: {saved_url}")
        except:
            pass
    
    # Method 3: Check the cloud server's /tunnel_url endpoint (if we know the local address)
    # This is useful when the companion runs on the same machine as the cloud server
    for local_port in [8791]:
        try:
            resp = requests.get(f"http://localhost:{local_port}/tunnel_url", timeout=2)
            if resp.status_code == 200:
                data = resp.json()
                tunnel_url = data.get("tunnel_url")
                if tunnel_url:
                    # Verify the tunnel works
                    try:
                        check = requests.get(f"{tunnel_url}/status", timeout=5)
                        if check.status_code == 200:
                            print(f"[Companion] ✅ Found cloud via local server tunnel: {tunnel_url}")
                            return tunnel_url
                    except:
                        pass
        except:
            pass
    
    # Method 4: Try known tunnel URLs
    print("[Companion] 🔍 Searching for active cloud server...")
    for url in KNOWN_TUNNEL_URLS:
        try:
            resp = requests.get(f"{url}/status", timeout=5)
            if resp.status_code == 200:
                data = resp.json()
                print(f"[Companion] ✅ Found cloud server: {url}")
                print(f"[Companion]    Phase: {data.get('phase')}, Commands: {len(data.get('allowed_commands', []))}")
                # Save it for next time
                try:
                    with open(CLOUD_URL_FILE, 'w') as f:
                        f.write(url)
                except:
                    pass
                return url
        except:
            continue
    
    # Method 4: Ask the user
    print("[Companion] ⚠️  Could not auto-discover cloud server")
    print("[Companion]    Set SN_CLOUD_URL env var, create cloud_url.txt, or pass as argument")
    if not sys.stdin.isatty():
        # Running in background (launched by autolaunch) — can't ask
        return None
    url = input("[Companion] Enter cloud URL (or press Enter to exit): ").strip()
    if url:
        try:
            with open(CLOUD_URL_FILE, 'w') as f:
                f.write(url)
        except:
            pass
        return url
    
    return None


def poll_cloud():
    """Poll the cloud for the next command."""
    try:
        resp = requests.get(f"{CLOUD_URL}/poll", timeout=10)
        if resp.status_code == 200:
            data = resp.json()
            return data.get("command")
    except Exception as e:
        print(f"[Companion] Poll error: {e}")
    return None


def forward_to_bridge(cmd_data):
    """Forward a command to the local bridge (queues it for Unreal)."""
    try:
        resp = requests.post(
            f"{BRIDGE_URL}/command",
            json=cmd_data,
            timeout=10
        )
        if resp.status_code == 200:
            return resp.json()
        else:
            print(f"[Companion] Bridge error: {resp.status_code} {resp.text}")
    except Exception as e:
        print(f"[Companion] Bridge connection error: {e}")
    return None


def wait_for_bridge_result(cmd_id, timeout=RESULT_WAIT_TIMEOUT):
    """Wait for Unreal to execute the command and post result to bridge."""
    start = time.time()
    while time.time() - start < timeout:
        try:
            resp = requests.get(
                f"{BRIDGE_URL}/result?id={cmd_id}",
                timeout=5
            )
            if resp.status_code == 200:
                data = resp.json()
                result = data.get("result")
                if result is not None:
                    return result
        except Exception as e:
            pass  # Keep trying
        time.sleep(BRIDGE_RESULT_POLL)
    
    print(f"[Companion] Timeout waiting for result: {cmd_id}")
    return None


def post_result_to_cloud(result_data):
    """Post a result back to the cloud."""
    try:
        resp = requests.post(
            f"{CLOUD_URL}/result",
            json=result_data,
            timeout=15
        )
        if resp.status_code == 200:
            print(f"[Companion] Result posted to cloud: {result_data.get('id')}")
            return True
        else:
            print(f"[Companion] Cloud result error: {resp.status_code}")
    except Exception as e:
        print(f"[Companion] Cloud result post error: {e}")
    return False


def upload_screenshot_to_cloud(cmd_id, filepath):
    """Read a screenshot file, base64-encode it, and upload to cloud."""
    try:
        if not os.path.exists(filepath):
            print(f"[Companion] Screenshot file not found: {filepath}")
            return False

        file_size = os.path.getsize(filepath)
        if file_size > MAX_SCREENSHOT_SIZE:
            print(f"[Companion] Screenshot too large: {file_size} bytes")
            return False

        with open(filepath, "rb") as f:
            png_data = f.read()

        data_b64 = base64.b64encode(png_data).decode()
        filename = os.path.basename(filepath)

        resp = requests.post(
            f"{CLOUD_URL}/upload_screenshot",
            json={
                "id": cmd_id,
                "filename": filename,
                "data_b64": data_b64,
            },
            timeout=30
        )

        if resp.status_code == 200:
            print(f"[Companion] Screenshot uploaded: {filename} ({file_size} bytes)")
            return True
        else:
            print(f"[Companion] Screenshot upload error: {resp.status_code}")

    except Exception as e:
        print(f"[Companion] Screenshot upload error: {e}")

    return False


def wait_for_screenshot(filepath, timeout=15.0):
    """Wait for a screenshot file to appear on disk."""
    start = time.time()
    while time.time() - start < timeout:
        if os.path.exists(filepath):
            size1 = os.path.getsize(filepath)
            time.sleep(0.3)
            size2 = os.path.getsize(filepath)
            if size1 == size2 and size1 > 0:
                return True
        time.sleep(0.5)
    return False


def handle_command(cmd_data):
    """Process a single command from the cloud."""
    cmd = cmd_data.get("command", "")
    cmd_id = cmd_data.get("id", "unknown")
    args = cmd_data.get("args", {})

    print(f"[Companion] Processing: {cmd} (id={cmd_id})")

    # Step 1: Forward command to bridge (queues for Unreal)
    bridge_resp = forward_to_bridge(cmd_data)
    
    if not bridge_resp or bridge_resp.get("status") != "queued":
        print(f"[Companion] Bridge queue failed: {bridge_resp}")
        post_result_to_cloud({
            "id": cmd_id,
            "result": {"error": "bridge_queue_failed", "detail": str(bridge_resp)},
            "is_screenshot": False,
        })
        return

    print(f"[Companion] Command queued in bridge, waiting for Unreal to execute...")

    # Step 2: Wait for Unreal to execute and post result to bridge
    bridge_result = wait_for_bridge_result(cmd_id)
    
    if bridge_result is None:
        print(f"[Companion] No result from Unreal for: {cmd_id}")
        post_result_to_cloud({
            "id": cmd_id,
            "result": {"error": "unreal_timeout", "command": cmd},
            "is_screenshot": False,
        })
        return

    # Step 3: Post result back to cloud
    print(f"[Companion] Got result from Unreal for: {cmd_id}")
    
    # Handle screenshots specially
    if cmd == "screenshot" and bridge_result.get("result", {}).get("save_path"):
        save_path = bridge_result["result"]["save_path"]
        if wait_for_screenshot(save_path):
            upload_ok = upload_screenshot_to_cloud(cmd_id, save_path)
            bridge_result["result"]["upload_status"] = "uploaded" if upload_ok else "captured"
    
    post_result_to_cloud({
        "id": cmd_id,
        "result": bridge_result.get("result", {}),
        "is_screenshot": cmd == "screenshot",
    })


def main():
    global CLOUD_URL
    
    # Auto-discover the cloud URL
    CLOUD_URL = discover_cloud_url()
    
    # Also check command-line argument
    if len(sys.argv) > 1:
        arg_url = sys.argv[1].strip()
        try:
            resp = requests.get(f"{arg_url}/status", timeout=5)
            if resp.status_code == 200:
                CLOUD_URL = arg_url
                print(f"[Companion] ✅ Using command-line URL: {arg_url}")
        except:
            print(f"[Companion] ⚠️  Command-line URL not reachable: {arg_url}")
    
    if not CLOUD_URL:
        print("[Companion] ❌ No cloud server found. Exiting.")
        print("[Companion]    Usage: python sn_companion_phase2.py [CLOUD_URL]")
        print("[Companion]    Or set SN_CLOUD_URL environment variable")
        print("[Companion]    Or create cloud_url.txt in the same directory")
        sys.exit(1)
    
    print("╔══════════════════════════════════════════════════════════════╗")
    print("║  SuperNinja Windows Companion — Full Pipeline               ║")
    print(f"║  Cloud:  {CLOUD_URL[:43]:<43s}  ║")
    print(f"║  Bridge: {BRIDGE_URL[:43]:<43s}  ║")
    print("╚══════════════════════════════════════════════════════════════╝")
    
    # Quick connectivity check
    try:
        resp = requests.get(f"{CLOUD_URL}/status", timeout=10)
        data = resp.json()
        print(f"[Companion] ☁️  Cloud connected: {len(data.get('allowed_commands', []))} commands available")
    except Exception as e:
        print(f"[Companion] ⚠️  Cannot reach cloud: {e}")
    
    try:
        resp = requests.get(f"{BRIDGE_URL}/status", timeout=5)
        print(f"[Companion] 🌉 Bridge connected")
    except Exception as e:
        print(f"[Companion] ⚠️  Cannot reach bridge: {e}")
        print(f"[Companion]   Make sure sn_local_bridge_phase2.py is running first!")

    print(f"[Companion] Polling cloud every {CLOUD_POLL_INTERVAL}s... (Ctrl+C to stop)")
    
    try:
        while True:
            cmd = poll_cloud()
            if cmd:
                handle_command(cmd)
            time.sleep(CLOUD_POLL_INTERVAL)
    except KeyboardInterrupt:
        print("\n[Companion] Stopped.")


if __name__ == "__main__":
    main()
