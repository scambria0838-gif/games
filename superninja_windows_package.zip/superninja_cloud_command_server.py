"""
SuperNinja Cloud Command Server — Phase 2 (Screenshot Support)

HTTP endpoint that SuperNinja cloud uses to enqueue commands
and retrieve results. The Windows companion polls this server
outbound (no inbound ports needed on Windows).

Phase 1 commands: ping, echo, log, safe_log, stop
Phase 2 commands: screenshot (returns image data back to cloud)

Run: python superninja_cloud_command_server.py
Default port: 8791 (override with PORT env var)
"""

import json
import base64
import time
import os
from http.server import HTTPServer, BaseHTTPRequestHandler
from urllib.parse import urlparse, parse_qs
from threading import Lock

# ---------------------------------------------------------------------------
# In-memory command queue & result store
# ---------------------------------------------------------------------------
queue_lock = Lock()
command_queue = []          # list of dicts: {"id", "command", "args", "enqueued_at"}
results_store = {}          # cmd_id -> {"result", "completed_at", ...}
screenshot_store = {}       # cmd_id -> {"filename", "data_b64", "size", "completed_at"}
tunnel_url = None            # Set by the tunnel manager or manually

# Allowed commands — loaded from skills registry
# Phase 1: basic comms
SAFE_COMMANDS = {"ping", "echo", "log", "safe_log", "stop"}
# Phase 2: viewport capture
PHASE2_COMMANDS = {"screenshot"}
# Phase 3: full skill set (loaded dynamically)
SKILL_COMMANDS = {
    # Lighting
    "add_directional_light", "add_point_light", "add_spot_light",
    "add_sky_light", "adjust_light",
    # Placement
    "spawn_actor", "move_actor", "rotate_actor", "scale_actor",
    "scatter_actors", "delete_actor", "delete_duplicates",
    # Analysis (safe/read-only)
    "list_actors", "get_scene_info",
    # Camera
    "frame_viewport",
    # Environment
    "add_exponential_height_fog", "add_sky_atmosphere",
    # Material
    "apply_material",
    # Asset
    "import_asset", "list_content",
    # Utility
    "save_level", "undo", "execute_console_command",
    # Conversational
    "say", "ask_user", "report_progress", "explain_scene", "suggest_improvements", "chat",
    # High-level composite
    "light_scene", "cleanup_duplicates", "scatter_props",
    # Knowledge & Intelligence
    "get_actor_properties", "set_actor_property", "find_actors_advanced",
    "query_knowledge", "explain_ue5_concept", "suggest_blueprint_pattern",
    "run_python_snippet",
    # Advanced Knowledge (Docs 21-60)
    "query_advanced_knowledge", "get_lighting_setup", "get_material_recipe",
    "analyze_rendering",
    # Rendering
    "setup_post_process",
    # Environment (advanced)
    "add_foliage",
    # Expert Knowledge (Docs 61-100)
    "query_expert_knowledge",
    # VFX (Niagara)
    "add_niagara_effect",
    # Audio
    "add_audio_ambient",
    # AI
    "setup_ai_character", "add_navmesh",
    # Optimization
    "optimize_scene", "get_fps_optimization_profile",
    # Cinematics
    "setup_cinematic",
    # Networking
    "get_multiplayer_pattern",
    # Master Knowledge (Docs 101-151)
    "query_master_knowledge",
    # Environment (master)
    "setup_landscape", "add_volumetric_clouds", "add_height_fog", "add_water_body",
    # Rendering (master)
    "setup_reflections", "setup_groom_system", "setup_rvt",
    # Virtual Production
    "setup_virtual_production",
    # Physics (master)
    "setup_physics_constraints", "add_chaos_vehicle",
    # Knowledge (master)
    "query_master_landscape_preset",
    # Pipeline
    "setup_source_control",
}
ALL_ALLOWED = SAFE_COMMANDS | PHASE2_COMMANDS | SKILL_COMMANDS

# Safety classification
DESTRUCTIVE_COMMANDS = {"delete_actor", "delete_duplicates"}
MODIFY_COMMANDS = SKILL_COMMANDS - DESTRUCTIVE_COMMANDS
SAFE_ONLY_COMMANDS = SAFE_COMMANDS | PHASE2_COMMANDS | {"list_actors", "get_scene_info", "list_content", "frame_viewport", "undo"}

MAX_QUEUE_SIZE = 50
MAX_RESULTS = 200
MAX_SCREENSHOTS = 20
RESULT_TTL_SECONDS = 3600  # 1 hour


class CommandHandler(BaseHTTPRequestHandler):
    """Minimal HTTP handler for the command protocol."""

    def log_message(self, fmt, *args):
        # Quieter logging
        print(f"[{self.client_address[0]}] {fmt % args}")

    # ------------------------------------------------------------------
    # GET routes
    # ------------------------------------------------------------------
    def do_GET(self):
        parsed = urlparse(self.path)
        path = parsed.path.rstrip("/") or "/"
        params = parse_qs(parsed.query)

        # Health check — platform proxies probe this
        if path == "" or path == "/":
            self._json_response({"status": "ok", "service": "superninja-command-server", "phase": 4})

        elif path == "/status":
            with queue_lock:
                self._json_response({
                    "queue_length": len(command_queue),
                    "results_available": len(results_store),
                    "screenshots_available": len(screenshot_store),
                    "phase": 4,
                    "allowed_commands": sorted(ALL_ALLOWED),
                })

        elif path == "/poll":
            # Companion picks up the next command
            with queue_lock:
                if command_queue:
                    cmd = command_queue.pop(0)
                    self._json_response({"command": cmd})
                else:
                    self._json_response({"command": None})

        elif path == "/result":
            # Retrieve a specific result by id
            cmd_id = params.get("id", [None])[0]
            if not cmd_id:
                self._json_response({"error": "missing ?id="}, status=400)
                return
            with queue_lock:
                if cmd_id in results_store:
                    self._json_response({"result": results_store[cmd_id]})
                elif cmd_id in screenshot_store:
                    self._json_response({"result": screenshot_store[cmd_id]})
                else:
                    self._json_response({"error": "not found"}, status=404)

        elif path == "/screenshot":
            # Retrieve screenshot image data by command id
            cmd_id = params.get("id", [None])[0]
            if not cmd_id:
                # Return list of available screenshots
                with queue_lock:
                    self._json_response({"screenshots": [
                        {"id": k, "filename": v["filename"], "size": v["size"], "completed_at": v["completed_at"]}
                        for k, v in screenshot_store.items()
                    ]})
                return
            with queue_lock:
                if cmd_id in screenshot_store:
                    shot = screenshot_store[cmd_id]
                    self._json_response({"screenshot": shot})
                else:
                    self._json_response({"error": "screenshot not found"}, status=404)

        elif path == "/tunnel_url":
            # Return the current tunnel URL (for auto-discovery)
            self._json_response({"tunnel_url": tunnel_url, "status": "ok" if tunnel_url else "not_set"})

        elif path == "/screenshot_image":
            # Return raw PNG image data (for direct browser/img tag display)
            cmd_id = params.get("id", [None])[0]
            if not cmd_id:
                self._json_response({"error": "missing ?id="}, status=400)
                return
            with queue_lock:
                if cmd_id in screenshot_store and "data_b64" in screenshot_store[cmd_id]:
                    raw = base64.b64decode(screenshot_store[cmd_id]["data_b64"])
                    self.send_response(200)
                    self.send_header("Content-Type", "image/png")
                    self.send_header("Content-Length", str(len(raw)))
                    self.end_headers()
                    self.wfile.write(raw)
                else:
                    self._json_response({"error": "screenshot not found"}, status=404)

        else:
            self._json_response({"error": "unknown route"}, status=404)

    # ------------------------------------------------------------------
    # POST routes
    # ------------------------------------------------------------------
    def do_POST(self):
        parsed = urlparse(self.path)
        path = parsed.path.rstrip("/")

        if path == "/enqueue":
            body = self._read_body()
            if body is None:
                return
            cmd = body.get("command")
            args = body.get("args", {})
            cmd_id = body.get("id", f"cmd-{int(time.time()*1000)}")

            if cmd not in ALL_ALLOWED:
                self._json_response({"error": f"command '{cmd}' not allowed", "allowed": sorted(ALL_ALLOWED)}, status=403)
                return

            entry = {
                "id": cmd_id,
                "command": cmd,
                "args": args,
                "enqueued_at": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
            }

            with queue_lock:
                if len(command_queue) >= MAX_QUEUE_SIZE:
                    self._json_response({"error": "queue full"}, status=503)
                    return
                command_queue.append(entry)

            print(f"[ENQUEUE] {entry}")
            self._json_response({"status": "enqueued", "id": cmd_id, "command": cmd})

        elif path == "/result":
            # Companion posts a result back
            body = self._read_body()
            if body is None:
                return
            cmd_id = body.get("id")
            result = body.get("result", {})
            is_screenshot = body.get("is_screenshot", False)

            if not cmd_id:
                self._json_response({"error": "missing id"}, status=400)
                return

            with queue_lock:
                # Prune old results
                now = time.time()
                expired = [k for k, v in results_store.items()
                           if now - v.get("_ts", now) > RESULT_TTL_SECONDS]
                for k in expired:
                    del results_store[k]

                entry = {
                    "id": cmd_id,
                    "result": result,
                    "completed_at": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
                    "_ts": time.time(),
                }

                if is_screenshot:
                    # Screenshot results stored separately
                    if len(screenshot_store) >= MAX_SCREENSHOTS:
                        oldest = min(screenshot_store, key=lambda k: screenshot_store[k]["_ts"])
                        del screenshot_store[oldest]
                    screenshot_store[cmd_id] = entry
                    print(f"[SCREENSHOT RESULT] {cmd_id}: {result.get('filename', '?')}")
                else:
                    if len(results_store) >= MAX_RESULTS:
                        oldest = min(results_store, key=lambda k: results_store[k]["_ts"])
                        del results_store[oldest]
                    results_store[cmd_id] = entry
                    print(f"[RESULT] {cmd_id}: {result}")

            self._json_response({"status": "stored", "id": cmd_id})

        elif path == "/set_tunnel_url":
            # Internal endpoint to set the tunnel URL (called by tunnel manager)
            body = self._read_body()
            if body is None:
                return
            global tunnel_url
            tunnel_url = body.get("tunnel_url", "")
            print(f"[TUNNEL] URL set: {tunnel_url}")
            self._json_response({"status": "ok", "tunnel_url": tunnel_url})

        elif path == "/upload_screenshot":
            # Upload screenshot image data (base64 encoded PNG)
            body = self._read_body()
            if body is None:
                return
            cmd_id = body.get("id")
            filename = body.get("filename", "viewport.png")
            data_b64 = body.get("data_b64", "")

            if not cmd_id or not data_b64:
                self._json_response({"error": "missing id or data_b64"}, status=400)
                return

            try:
                raw_size = len(base64.b64decode(data_b64))
            except Exception:
                self._json_response({"error": "invalid base64 data"}, status=400)
                return

            with queue_lock:
                if len(screenshot_store) >= MAX_SCREENSHOTS:
                    oldest = min(screenshot_store, key=lambda k: screenshot_store[k]["_ts"])
                    del screenshot_store[oldest]
                screenshot_store[cmd_id] = {
                    "id": cmd_id,
                    "filename": filename,
                    "data_b64": data_b64,
                    "size": raw_size,
                    "completed_at": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
                    "_ts": time.time(),
                }
                print(f"[SCREENSHOT UPLOAD] {cmd_id}: {filename} ({raw_size} bytes)")

            self._json_response({"status": "uploaded", "id": cmd_id, "size": raw_size})

        else:
            self._json_response({"error": "unknown route"}, status=404)

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------
    def _read_body(self):
        content_length = int(self.headers.get("Content-Length", 0))
        if content_length == 0:
            self._json_response({"error": "empty body"}, status=400)
            return None
        raw = self.rfile.read(content_length)
        try:
            return json.loads(raw)
        except json.JSONDecodeError:
            self._json_response({"error": "invalid JSON"}, status=400)
            return None

    def _json_response(self, data, status=200):
        self.send_response(status)
        self.send_header("Content-Type", "application/json")
        self.send_header("Access-Control-Allow-Origin", "*")
        payload = json.dumps(data).encode()
        self.send_header("Content-Length", str(len(payload)))
        self.end_headers()
        self.wfile.write(payload)


def main():
    port = int(os.environ.get("PORT", 8791))
    server = HTTPServer(("0.0.0.0", port), CommandHandler)
    print(f"╔══════════════════════════════════════════════════╗")
    print(f"║  SuperNinja Cloud Command Server — Phase 2      ║")
    print(f"║  Listening on 0.0.0.0:{port}                      ║")
    print(f"║  Allowed commands: {', '.join(sorted(ALL_ALLOWED))}  ║")
    print(f"╚══════════════════════════════════════════════════╝")
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\n[SHUTDOWN] Server stopped.")
        server.server_close()


if __name__ == "__main__":
    main()