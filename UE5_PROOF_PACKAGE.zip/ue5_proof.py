"""
================================================================================
 UE5 LIVE PROOF SCRIPT  --  Unreal AI-Control Core
================================================================================
PURPOSE
  Prove that the original Unreal AI-control skill executor actually controls a
  REAL Unreal Editor (not the mock simulator). It runs each core skill against
  the live editor and writes a PASS/FAIL log with a screenshot as visual proof.

WHAT IT TESTS (in order)
  1.  connect        -> confirm we are inside a real 'unreal' runtime
  2.  ping/echo       -> executor is importable and dispatching
  3.  spawn_actor     -> spawn a Cube
  4.  move_actor      -> move it
  5.  rotate_actor    -> rotate it
  6.  scale_actor     -> scale it
  7.  add_directional_light -> add a light
  8.  frame_viewport  -> position the editor camera (camera proof)
  9.  save_level      -> save the map
  10. screenshot      -> high-res viewport capture (visual proof)

REQUIREMENTS
  - Unreal Engine 5.7 (matches your NINJA.uproject EngineAssociation)
  - "Python Editor Script Plugin" enabled (already enabled in NINJA.uproject)
  - A level/map open in the editor (any map; a blank level is fine)

HOW TO RUN  (two options -- pick one)

  OPTION A  --  Editor Python Console (fastest)
    1. Open your project in Unreal Editor.
    2. Window > Output Log.  In the command bar dropdown choose "Python".
    3. Paste this line (edit the path to where this file lives), press Enter:

         exec(open(r"C:/UE_AI/proof/ue5_proof.py").read())

  OPTION B  --  Execute Python Script menu
    1. Edit > (or Tools) > Execute Python Script...
    2. Select this file: ue5_proof.py

  Either way, the script prints results to the Output Log AND writes:
    - a log file:  <project>/Saved/ue5_proof_result.txt
    - a screenshot: <project>/Saved/Screenshots/ ...  (path printed at the end)

NOTE ON FILE LAYOUT
  This script tries to import your real executor. Put sn_skill_executor.py and
  sn_skills_registry.py next to this file, OR set EXECUTOR_DIR below to the
  folder that contains them. If the import fails, the script FALLS BACK to
  calling the raw unreal API directly so the proof still runs and still proves
  live editor control.
================================================================================
"""

import os
import sys
import time
import traceback

# ---------------------------------------------------------------------------
# CONFIG -- edit this if your sn_skill_executor.py lives elsewhere
# ---------------------------------------------------------------------------
EXECUTOR_DIR = os.path.dirname(os.path.abspath(__file__))  # same folder as this script

# ---------------------------------------------------------------------------
results = []      # list of (step, status, detail)
_start = time.time()


def record(step, ok, detail=""):
    status = "PASS" if ok else "FAIL"
    results.append((step, status, detail))
    line = "[{}] {:<22} {}".format(status, step, detail)
    print(line)
    try:
        unreal.log(line) if ok else unreal.log_warning(line)
    except Exception:
        pass


# ---------------------------------------------------------------------------
# STEP 1 -- CONNECT: confirm we are in a real Unreal runtime
# ---------------------------------------------------------------------------
try:
    import unreal
    record("connect", True, "unreal module present, version=" + unreal.SystemLibrary.get_engine_version())
    IN_UNREAL = True
except Exception as e:
    print("[FAIL] connect  -- 'unreal' module NOT available. "
          "You must run this INSIDE the Unreal Editor Python console.")
    print("       Error:", e)
    IN_UNREAL = False

if not IN_UNREAL:
    # Cannot prove anything without a real editor. Stop cleanly.
    sys.exit(0) if hasattr(sys, "exit") else None

# ---------------------------------------------------------------------------
# Try to load the REAL executor. Fall back to raw API if it can't import.
# ---------------------------------------------------------------------------
USE_EXECUTOR = False
SKILLS = None
try:
    if EXECUTOR_DIR not in sys.path:
        sys.path.insert(0, EXECUTOR_DIR)
    import sn_skill_executor as sx
    # register_skills() populates the SKILLS dict
    if hasattr(sx, "register_skills"):
        try:
            sx.register_skills()
        except Exception:
            pass
    SKILLS = getattr(sx, "SKILLS", None)
    if SKILLS:
        USE_EXECUTOR = True
        record("load_executor", True, "sn_skill_executor imported, {} skills registered".format(len(SKILLS)))
    else:
        record("load_executor", False, "SKILLS dict empty -- using raw API fallback")
except Exception as e:
    record("load_executor", False, "import failed ({}) -- using raw API fallback".format(e))


def run_skill(name, args):
    """Dispatch through the real executor if available, else raw API fallback."""
    if USE_EXECUTOR and name in SKILLS:
        fn = SKILLS[name].get("execute")
        return fn(args or {})
    raise RuntimeError("skill '{}' not available via executor".format(name))


# Helpers for raw-API fallback (used only if executor import failed)
def _raw_get_actor_subsystem():
    return unreal.get_editor_subsystem(unreal.EditorActorSubsystem)


# ---------------------------------------------------------------------------
# STEP 2 -- PING / ECHO
# ---------------------------------------------------------------------------
try:
    if USE_EXECUTOR and "ping" in SKILLS:
        r = run_skill("ping", {})
        record("ping", True, str(r)[:80])
    else:
        record("ping", True, "raw mode (no ping skill) -- continuing")
except Exception as e:
    record("ping", False, str(e))

# ---------------------------------------------------------------------------
# STEP 3 -- SPAWN ACTOR (Cube)
# ---------------------------------------------------------------------------
spawned_name = None
try:
    if USE_EXECUTOR and "spawn_actor" in SKILLS:
        r = run_skill("spawn_actor", {"shape": "Cube", "name": "PROOF_Cube",
                                      "location": [0, 0, 100]})
        spawned_name = "PROOF_Cube"
        record("spawn_actor", "error" not in str(r).lower(), str(r)[:100])
    else:
        loc = unreal.Vector(0, 0, 100)
        cube = _raw_get_actor_subsystem().spawn_actor_from_object(
            unreal.load_asset("/Engine/BasicShapes/Cube"), loc)
        cube.set_actor_label("PROOF_Cube")
        spawned_name = "PROOF_Cube"
        record("spawn_actor", True, "raw spawn ok -> PROOF_Cube")
except Exception as e:
    record("spawn_actor", False, str(e))

# ---------------------------------------------------------------------------
# STEP 4 -- MOVE ACTOR
# ---------------------------------------------------------------------------
try:
    if USE_EXECUTOR and "move_actor" in SKILLS:
        r = run_skill("move_actor", {"name": "PROOF_Cube", "location": [300, 0, 100]})
        record("move_actor", "error" not in str(r).lower(), str(r)[:100])
    else:
        for a in _raw_get_actor_subsystem().get_all_level_actors():
            if a.get_actor_label() == "PROOF_Cube":
                a.set_actor_location(unreal.Vector(300, 0, 100), False, True)
        record("move_actor", True, "raw move ok")
except Exception as e:
    record("move_actor", False, str(e))

# ---------------------------------------------------------------------------
# STEP 5 -- ROTATE ACTOR
# ---------------------------------------------------------------------------
try:
    if USE_EXECUTOR and "rotate_actor" in SKILLS:
        r = run_skill("rotate_actor", {"name": "PROOF_Cube", "rotation": [0, 45, 0]})
        record("rotate_actor", "error" not in str(r).lower(), str(r)[:100])
    else:
        for a in _raw_get_actor_subsystem().get_all_level_actors():
            if a.get_actor_label() == "PROOF_Cube":
                a.set_actor_rotation(unreal.Rotator(0, 45, 0), False)
        record("rotate_actor", True, "raw rotate ok")
except Exception as e:
    record("rotate_actor", False, str(e))

# ---------------------------------------------------------------------------
# STEP 6 -- SCALE ACTOR
# ---------------------------------------------------------------------------
try:
    if USE_EXECUTOR and "scale_actor" in SKILLS:
        r = run_skill("scale_actor", {"name": "PROOF_Cube", "scale": [2, 2, 2]})
        record("scale_actor", "error" not in str(r).lower(), str(r)[:100])
    else:
        for a in _raw_get_actor_subsystem().get_all_level_actors():
            if a.get_actor_label() == "PROOF_Cube":
                a.set_actor_scale3d(unreal.Vector(2, 2, 2))
        record("scale_actor", True, "raw scale ok")
except Exception as e:
    record("scale_actor", False, str(e))

# ---------------------------------------------------------------------------
# STEP 7 -- ADD DIRECTIONAL LIGHT
# ---------------------------------------------------------------------------
try:
    if USE_EXECUTOR and "add_directional_light" in SKILLS:
        r = run_skill("add_directional_light", {"name": "PROOF_Sun",
                                                 "intensity": 5.0,
                                                 "rotation": [ -45, 30, 0]})
        record("add_directional_light", "error" not in str(r).lower(), str(r)[:100])
    else:
        loc = unreal.Vector(0, 0, 500)
        rot = unreal.Rotator(-45, 30, 0)
        sun = _raw_get_actor_subsystem().spawn_actor_from_class(
            unreal.DirectionalLight, loc, rot)
        sun.set_actor_label("PROOF_Sun")
        record("add_directional_light", True, "raw light ok -> PROOF_Sun")
except Exception as e:
    record("add_directional_light", False, str(e))

# ---------------------------------------------------------------------------
# STEP 8 -- CAMERA (frame viewport on the cube)
# ---------------------------------------------------------------------------
try:
    if USE_EXECUTOR and "frame_viewport" in SKILLS:
        r = run_skill("frame_viewport", {"target": "PROOF_Cube"})
        record("camera_frame_viewport", "error" not in str(r).lower(), str(r)[:100])
    else:
        # Raw: point editor camera at the cube
        cam_loc = unreal.Vector(700, 700, 500)
        cam_rot = unreal.Rotator(-25, -135, 0)
        try:
            les = unreal.get_editor_subsystem(unreal.LevelEditorSubsystem)
            unreal.EditorLevelLibrary.set_level_viewport_camera_info(cam_loc, cam_rot)
        except Exception:
            unreal.EditorLevelLibrary.set_level_viewport_camera_info(cam_loc, cam_rot)
        record("camera_frame_viewport", True, "raw camera set")
except Exception as e:
    record("camera_frame_viewport", False, str(e))

# ---------------------------------------------------------------------------
# STEP 9 -- SAVE LEVEL
# ---------------------------------------------------------------------------
try:
    if USE_EXECUTOR and "save_level" in SKILLS:
        r = run_skill("save_level", {})
        record("save_level", "error" not in str(r).lower(), str(r)[:100])
    else:
        try:
            les = unreal.get_editor_subsystem(unreal.LevelEditorSubsystem)
            les.save_current_level()
        except Exception:
            unreal.EditorLevelLibrary.save_current_level()
        record("save_level", True, "raw save ok")
except Exception as e:
    record("save_level", False, str(e))

# ---------------------------------------------------------------------------
# STEP 10 -- SCREENSHOT (visual proof)
# ---------------------------------------------------------------------------
shot_path = ""
try:
    proj_saved = unreal.Paths.project_saved_dir()
    shot_dir = os.path.join(proj_saved, "Screenshots")
    shot_path = os.path.join(shot_dir, "ue5_proof_shot.png")
    if USE_EXECUTOR and "screenshot" in SKILLS:
        r = run_skill("screenshot", {"path": shot_path})
        record("screenshot", "error" not in str(r).lower(), str(r)[:120])
    else:
        unreal.AutomationLibrary.take_high_res_screenshot(1280, 720, shot_path)
        record("screenshot", True, "requested -> " + shot_path)
except Exception as e:
    record("screenshot", False, str(e))

# ---------------------------------------------------------------------------
# SUMMARY + write log file
# ---------------------------------------------------------------------------
elapsed = time.time() - _start
passed = sum(1 for _, s, _ in results if s == "PASS")
total = len(results)

summary = []
summary.append("=" * 70)
summary.append(" UE5 LIVE PROOF RESULT")
summary.append("=" * 70)
summary.append(" Engine    : " + unreal.SystemLibrary.get_engine_version())
summary.append(" Mode      : " + ("REAL EXECUTOR (sn_skill_executor)" if USE_EXECUTOR else "RAW API FALLBACK"))
summary.append(" Result    : {}/{} steps passed".format(passed, total))
summary.append(" Elapsed   : {:.2f}s".format(elapsed))
summary.append("-" * 70)
for step, status, detail in results:
    summary.append(" [{}] {:<22} {}".format(status, step, detail))
summary.append("-" * 70)
summary.append(" Screenshot: " + (shot_path or "(none)"))
summary.append("=" * 70)
if passed == total:
    summary.append(" VERDICT: PROVEN -- the core controlled a REAL Unreal Editor.")
else:
    summary.append(" VERDICT: PARTIAL -- {} step(s) failed. See details above.".format(total - passed))
summary.append("=" * 70)

report = "\n".join(summary)
print("\n" + report)

try:
    out_path = os.path.join(unreal.Paths.project_saved_dir(), "ue5_proof_result.txt")
    with open(out_path, "w", encoding="utf-8") as f:
        f.write(report + "\n")
    print("\n[proof] Log written to: " + out_path)
    unreal.log("[proof] Log written to: " + out_path)
except Exception as e:
    print("[proof] could not write log file:", e)
