# 🚀 prompttogame.ai — Launch Checklist

> Go/no-go gate. Every box must be checked before charging users. No exceptions.

---

## 🌐 Phase 1 — DNS & Infrastructure

- [ ] DNS A record: `prompttogame.ai` → `85.31.225.224`
- [ ] DNS A record: `www.prompttogame.ai` → `85.31.225.224`
- [ ] DNS A record: `api.prompttogame.ai` → `85.31.225.224`
- [ ] DNS propagation verified — `dig prompttogame.ai +short` returns the IP from at least 3 different resolvers
- [ ] Hostinger VPS (`85.31.225.224`) is reachable via SSH
- [ ] VPS has at least 5 GB free disk space
- [ ] VPS has Ubuntu 22.04 or 24.04

---

## 📦 Phase 2 — Deployment

- [ ] `prompttogame-deploy.zip` uploaded to `/tmp/` on the VPS
- [ ] `deploy_prompttogame.sh --ssl` ran successfully
- [ ] `/opt/prompttogame/.env` exists and is mode 0600
- [ ] All required `.env` variables are filled in (see `.env.example`)
- [ ] `/var/lib/ue5pilot/` exists and is owned by the `ue5pilot` user
- [ ] `systemctl status nginx` shows `active (running)`
- [ ] `systemctl status prompttogame-web` shows `active (running)`
- [ ] `systemctl status ue5pilot` shows `active (running)`
- [ ] `ufw status` shows ports 22, 80, 443 open and everything else denied
- [ ] Let's Encrypt SSL certs issued for all 3 domains
- [ ] `certbot certificates` lists all 3 with > 30 days remaining

---

## ✅ Phase 3 — Functional Verification (browser + curl)

### Landing page
- [ ] `https://prompttogame.ai` loads
- [ ] Hero typewriter demo cycles through prompts
- [ ] All footer links resolve (no 404s)
- [ ] Waitlist form submits successfully
- [ ] Submitting same email twice doesn't crash (idempotent)

### Playground
- [ ] `https://prompttogame.ai/playground` loads
- [ ] At least 5 example pills produce valid command JSON
- [ ] "make it brighter" returns a `light_scene` command
- [ ] Rate limiting kicks in after 30 quick requests

### Builder (requires Anthropic key)
- [ ] `https://prompttogame.ai/builder` loads
- [ ] 2D mode generates a playable HTML5 game in < 90s
- [ ] 3D mode generates a playable WebGL game in < 90s
- [ ] Generated game has no console errors in browser
- [ ] Share link copies to clipboard
- [ ] Daily rate limit (5/IP/day) enforced

### API
- [ ] `https://api.prompttogame.ai/health` returns `200` with valid JSON
- [ ] `health.premium` shows all 11 modules
- [ ] `health.translator.llm_configured` is `true`
- [ ] `POST /translate` with `{"text":"make it brighter"}` returns a command
- [ ] `POST /premium/director/info` returns 200 (info is public)
- [ ] `POST /premium/director/run` without token returns 401 (auth works)

### Admin
- [ ] `https://prompttogame.ai/admin` prompts for Basic Auth
- [ ] Correct credentials show the dashboard
- [ ] Wrong credentials return 401
- [ ] All 4 stat cards display numbers (waitlist, playground, games, uptime)
- [ ] Premium modules list shows green/red status for each module

---

## 🔌 Phase 4 — External Services

### Anthropic API
- [ ] `UE5PILOT_LLM_API_KEY` is set in `.env`
- [ ] Real translation request through the playground works
- [ ] Real game generation through the builder works
- [ ] No 401 errors in the last 24 hours of logs

### Stripe (only if accepting payments)
- [ ] Products created in Stripe Dashboard (Pro, Studio, Enterprise)
- [ ] Price IDs set in `.env`
- [ ] Webhook endpoint registered at `https://api.prompttogame.ai/premium/enterprise/stripe/webhook`
- [ ] Webhook signing secret set in `.env`
- [ ] Test payment via Stripe test card completes end-to-end

### Email (optional but recommended)
- [ ] `RESEND_API_KEY` set if using transactional email
- [ ] Test waitlist signup sends confirmation email

---

## 🎬 Phase 5 — Pre-Charge Gate (real users, real money)

- [ ] At least 1 successful end-to-end test with real UE5 connected
- [ ] Companion app installed and tested on a real Windows machine
- [ ] At least 5 generated games played by humans without crashing
- [ ] 60-second demo video recorded and published
- [ ] Demo video embedded on landing page
- [ ] Terms of Service published at `/terms`
- [ ] Privacy Policy published at `/privacy`
- [ ] Contact email is monitored daily
- [ ] Refund policy documented
- [ ] Daily backups configured for `/var/lib/ue5pilot/`

---

## 📊 Phase 6 — Monitoring & Operations

- [ ] `journalctl -u prompttogame-web` reviewed for errors in last 24h
- [ ] `journalctl -u ue5pilot` reviewed for errors in last 24h
- [ ] Nginx access logs rotating properly
- [ ] Disk usage under 80%
- [ ] Memory usage under 80%
- [ ] CPU usage under 60% average
- [ ] Process restart on failure tested (kill `prompttogame-web`, confirm auto-restart)

---

## 🚨 Rollback Plan

If something breaks after launch:

1. **Quick rollback:**
   ```bash
   systemctl stop prompttogame-web ue5pilot
   cd /opt/prompttogame
   git checkout previous-known-good-tag  # (or restore from backup)
   systemctl start prompttogame-web ue5pilot
   ```

2. **Disable builder if it's burning Anthropic credits:**
   ```bash
   # Comment out UE5PILOT_LLM_API_KEY in .env
   systemctl restart prompttogame-web
   ```

3. **Status page:** point `prompttogame.ai` at a static "down for maintenance" page

---

## ✅ Final Sign-off

When every box above is checked:

- [ ] Founder approval (Kris)
- [ ] Date launched: __________
- [ ] First public announcement made on: __________ (Twitter, HN, Product Hunt, etc.)

**Ship it.** 🚀
