"""
prompttogame.ai — Public Web API Server

Handles:
  - GET /                       → serve landing page
  - GET /playground[/]          → serve playground page
  - GET /css/* /js/* /images/*  → serve static assets
  - POST /api/waitlist          → save waitlist signup (local SQLite)
  - POST /api/translate         → run prompt through regex translator
  - GET  /api/health            → health check
  - GET  /api/stats             → public stats (waitlist count, etc)

Designed to run on port 8080 behind nginx. Pure stdlib — no external deps.
No API keys required. Falls back gracefully when LLM is unavailable.
"""

import json
import os
import re
import sqlite3
import sys
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlparse, parse_qs

# Add UE5Pilot server to path so we can import the translator
SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
UE5PILOT_SERVER = os.environ.get(
    "UE5PILOT_SERVER_PATH",
    os.path.normpath(os.path.join(SCRIPT_DIR, "..", "..", "server"))
)
if os.path.isdir(UE5PILOT_SERVER):
    sys.path.insert(0, UE5PILOT_SERVER)

# Try to import the translators - both regex (always) and LLM (optional)
try:
    import nl_translator  # regex
    REGEX_AVAILABLE = True
except ImportError:
    REGEX_AVAILABLE = False

try:
    from premium import llm_translator  # LLM-backed
    LLM_AVAILABLE = True
except ImportError:
    LLM_AVAILABLE = False

try:
    from premium import builder as game_builder
    BUILDER_AVAILABLE = True
except ImportError:
    BUILDER_AVAILABLE = False


# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------

PORT = int(os.environ.get("WEB_PORT", "8080"))
HOST = os.environ.get("WEB_HOST", "0.0.0.0")
PUBLIC_DIR = os.path.normpath(os.path.join(SCRIPT_DIR, "..", "public"))
DB_PATH = os.environ.get(
    "WEB_DB_PATH",
    os.path.normpath(os.path.join(SCRIPT_DIR, "..", "data", "web.db"))
)

MIME_TYPES = {
    '.html': 'text/html; charset=utf-8',
    '.css': 'text/css; charset=utf-8',
    '.js': 'application/javascript; charset=utf-8',
    '.json': 'application/json; charset=utf-8',
    '.svg': 'image/svg+xml',
    '.png': 'image/png',
    '.jpg': 'image/jpeg',
    '.jpeg': 'image/jpeg',
    '.webp': 'image/webp',
    '.ico': 'image/x-icon',
    '.woff': 'font/woff',
    '.woff2': 'font/woff2',
    '.txt': 'text/plain; charset=utf-8',
}

# Simple in-memory rate limiting per IP
_rate_lock = threading.Lock()
_rate_buckets = {}
RATE_LIMIT_WINDOW = 60   # seconds
RATE_LIMIT_MAX = 30      # requests per window per IP


# ---------------------------------------------------------------------------
# Database
# ---------------------------------------------------------------------------

os.makedirs(os.path.dirname(DB_PATH), exist_ok=True)
_db_lock = threading.Lock()


def init_db():
    conn = sqlite3.connect(DB_PATH)
    try:
        conn.executescript("""
            CREATE TABLE IF NOT EXISTS waitlist (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                email TEXT NOT NULL,
                studio TEXT,
                usecase TEXT,
                tier TEXT,
                ts REAL NOT NULL,
                ua TEXT,
                ip TEXT,
                UNIQUE(email)
            );
            CREATE INDEX IF NOT EXISTS idx_waitlist_ts ON waitlist(ts);
            CREATE TABLE IF NOT EXISTS playground_events (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                ts REAL NOT NULL,
                prompt TEXT,
                command_count INTEGER,
                ip TEXT
            );
        """)
        conn.commit()
    finally:
        conn.close()


init_db()


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def get_db():
    conn = sqlite3.connect(DB_PATH, timeout=10)
    conn.row_factory = sqlite3.Row
    return conn


def check_rate_limit(ip):
    """Return True if request is allowed, False if rate-limited."""
    now = time.time()
    with _rate_lock:
        bucket = _rate_buckets.get(ip, [])
        # Drop expired entries
        bucket = [t for t in bucket if now - t < RATE_LIMIT_WINDOW]
        if len(bucket) >= RATE_LIMIT_MAX:
            _rate_buckets[ip] = bucket
            return False
        bucket.append(now)
        _rate_buckets[ip] = bucket
        # Periodic cleanup (every ~1000 reqs)
        if len(_rate_buckets) > 1000:
            _rate_buckets.clear()
        return True


def is_valid_email(email):
    if not isinstance(email, str) or len(email) > 320:
        return False
    return bool(re.match(r'^[^\s@]+@[^\s@]+\.[^\s@]+$', email))


def sanitize_string(s, max_len=500):
    if not isinstance(s, str):
        return ""
    return s.strip()[:max_len]


# ---------------------------------------------------------------------------
# Request Handler
# ---------------------------------------------------------------------------

class WebHandler(BaseHTTPRequestHandler):

    server_version = "prompttogame/1.0"

    def log_message(self, fmt, *args):
        # Quieter access log
        ts = time.strftime("%Y-%m-%d %H:%M:%S")
        sys.stdout.write(f"[{ts}] {self.address_string()} {fmt % args}\n")
        sys.stdout.flush()

    # -- Response helpers --------------------------------------------------

    def send_json(self, status, body):
        data = json.dumps(body).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(data)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(data)

    def send_file(self, path, status=200):
        try:
            with open(path, 'rb') as f:
                data = f.read()
            ext = os.path.splitext(path)[1].lower()
            mime = MIME_TYPES.get(ext, 'application/octet-stream')
            self.send_response(status)
            self.send_header("Content-Type", mime)
            self.send_header("Content-Length", str(len(data)))
            # Cache static assets aggressively, HTML lightly
            if ext == '.html':
                self.send_header("Cache-Control", "no-cache, must-revalidate")
            else:
                self.send_header("Cache-Control", "public, max-age=3600")
            self.end_headers()
            self.wfile.write(data)
        except FileNotFoundError:
            self.send_json(404, {"error": "not found"})
        except Exception as e:
            self.send_json(500, {"error": str(e)})

    def get_client_ip(self):
        # Trust X-Forwarded-For only if behind nginx (we are)
        xff = self.headers.get('X-Forwarded-For', '')
        if xff:
            return xff.split(',')[0].strip()
        return self.client_address[0]

    def read_json_body(self, max_bytes=10000):
        try:
            length = int(self.headers.get("Content-Length", "0"))
            if length > max_bytes:
                return None
            raw = self.rfile.read(length) if length > 0 else b'{}'
            return json.loads(raw.decode("utf-8"))
        except (json.JSONDecodeError, ValueError, UnicodeDecodeError):
            return None

    # -- Routing -----------------------------------------------------------

    def do_GET(self):
        ip = self.get_client_ip()
        if not check_rate_limit(ip):
            self.send_json(429, {"error": "rate limit exceeded"})
            return

        path = urlparse(self.path).path

        # Static file routing
        if path == '/' or path == '/index.html':
            return self.send_file(os.path.join(PUBLIC_DIR, "index.html"))
        if path == '/playground' or path == '/playground/' or path == '/playground.html':
            return self.send_file(os.path.join(PUBLIC_DIR, "playground.html"))
        if path == '/builder' or path == '/builder/' or path == '/builder.html':
            return self.send_file(os.path.join(PUBLIC_DIR, "builder.html"))
        if path == '/docs' or path == '/docs/' or path == '/docs/index.html':
            return self.send_file(os.path.join(PUBLIC_DIR, "docs", "index.html"))
        if path == '/status' or path == '/status/' or path == '/status/index.html':
            return self.send_file(os.path.join(PUBLIC_DIR, "status", "index.html"))
        if path == '/changelog' or path == '/changelog/' or path == '/changelog/index.html':
            return self.send_file(os.path.join(PUBLIC_DIR, "changelog", "index.html"))

        # Play a generated game
        if path.startswith('/builder/play/'):
            return self.handle_play_game(path)

        # API endpoints
        if path == '/api/health':
            return self.send_json(200, {
                "status": "ok",
                "service": "prompttogame.ai web",
                "version": "1.0",
                "translator_regex": REGEX_AVAILABLE,
                "translator_llm": LLM_AVAILABLE,
                "builder": BUILDER_AVAILABLE,
                "uptime_seconds": int(time.time() - START_TIME),
            })
        if path == '/api/stats':
            return self.handle_stats()
        if path == '/api/builder/info' and BUILDER_AVAILABLE:
            return self.send_json(200, game_builder.get_builder_info())
        if path == '/api/builder/recent' and BUILDER_AVAILABLE:
            try:
                qs = parse_qs(urlparse(self.path).query)
                limit = min(int(qs.get('limit', ['20'])[0]), 50)
                mode = qs.get('mode', [None])[0]
                return self.send_json(200, {
                    "games": game_builder.list_recent_games(limit=limit, mode=mode)
                })
            except (ValueError, TypeError):
                return self.send_json(400, {"error": "invalid query params"})

        # Static file fallback under PUBLIC_DIR
        if path.startswith('/css/') or path.startswith('/js/') or path.startswith('/images/') or path.endswith('.ico'):
            safe = os.path.normpath(path).lstrip('/')
            full = os.path.join(PUBLIC_DIR, safe)
            # Prevent path traversal
            if not full.startswith(PUBLIC_DIR):
                return self.send_json(403, {"error": "forbidden"})
            return self.send_file(full)

        return self.send_json(404, {"error": "not found", "path": path})

    def do_POST(self):
        ip = self.get_client_ip()
        if not check_rate_limit(ip):
            self.send_json(429, {"error": "rate limit exceeded"})
            return

        path = urlparse(self.path).path

        if path == '/api/waitlist':
            return self.handle_waitlist(ip)
        if path == '/api/translate':
            return self.handle_translate(ip)
        if path == '/api/builder/generate':
            return self.handle_builder_generate(ip)

        return self.send_json(404, {"error": "not found"})

    def do_OPTIONS(self):
        self.send_response(204)
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type")
        self.send_header("Access-Control-Max-Age", "86400")
        self.end_headers()

    # -- Endpoint handlers ------------------------------------------------

    def handle_waitlist(self, ip):
        body = self.read_json_body()
        if body is None:
            return self.send_json(400, {"error": "invalid JSON body"})

        email = sanitize_string(body.get("email", ""))
        if not is_valid_email(email):
            return self.send_json(400, {"error": "invalid email"})

        studio = sanitize_string(body.get("studio", ""))
        usecase = sanitize_string(body.get("usecase", ""), 50)
        tier = sanitize_string(body.get("tier", ""), 50)
        ua = sanitize_string(body.get("ua", ""), 200)

        try:
            with _db_lock:
                conn = get_db()
                try:
                    conn.execute("""
                        INSERT INTO waitlist (email, studio, usecase, tier, ts, ua, ip)
                        VALUES (?, ?, ?, ?, ?, ?, ?)
                    """, (email, studio, usecase, tier, time.time(), ua, ip))
                    conn.commit()
                finally:
                    conn.close()
            return self.send_json(200, {"ok": True, "message": "added to waitlist"})
        except sqlite3.IntegrityError:
            # Already in waitlist - treat as success (idempotent)
            return self.send_json(200, {"ok": True, "message": "already on waitlist"})
        except Exception as e:
            return self.send_json(500, {"error": "internal error"})

    def handle_translate(self, ip):
        body = self.read_json_body()
        if body is None:
            return self.send_json(400, {"error": "invalid JSON body"})

        text = sanitize_string(body.get("text", ""), 1000)
        if not text:
            return self.send_json(400, {"error": "text is required"})

        # Use LLM translator if available and configured, otherwise regex
        commands = []
        translator_used = "none"

        if LLM_AVAILABLE and os.environ.get("UE5PILOT_LLM_API_KEY"):
            try:
                commands = llm_translator.translate(text)
                translator_used = "llm"
            except Exception:
                commands = []

        if not commands and REGEX_AVAILABLE:
            try:
                commands = nl_translator.translate(text)
                translator_used = "regex"
            except Exception:
                commands = []

        # Log to analytics (fire and forget)
        try:
            with _db_lock:
                conn = get_db()
                try:
                    conn.execute("""
                        INSERT INTO playground_events (ts, prompt, command_count, ip)
                        VALUES (?, ?, ?, ?)
                    """, (time.time(), text[:500], len(commands), ip))
                    conn.commit()
                finally:
                    conn.close()
        except Exception:
            pass

        return self.send_json(200, {
            "ok": True,
            "translator": translator_used,
            "commands": commands,
            "count": len(commands),
        })

    def handle_stats(self):
        try:
            conn = get_db()
            try:
                waitlist_count = conn.execute("SELECT COUNT(*) FROM waitlist").fetchone()[0]
                playground_count = conn.execute("SELECT COUNT(*) FROM playground_events").fetchone()[0]
                top = conn.execute("""
                    SELECT tier, COUNT(*) as n FROM waitlist
                    WHERE tier != '' GROUP BY tier ORDER BY n DESC
                """).fetchall()
            finally:
                conn.close()
            return self.send_json(200, {
                "waitlist_signups": waitlist_count,
                "playground_runs": playground_count,
                "tier_breakdown": {row["tier"]: row["n"] for row in top},
                "uptime_seconds": int(time.time() - START_TIME),
            })
        except Exception:
            return self.send_json(500, {"error": "internal error"})

    def handle_builder_generate(self, ip):
        if not BUILDER_AVAILABLE:
            return self.send_json(503, {"error": "builder module not available"})
        body = self.read_json_body(max_bytes=4000)
        if body is None:
            return self.send_json(400, {"error": "invalid JSON body"})
        prompt = sanitize_string(body.get("prompt", ""), 600)
        mode = sanitize_string(body.get("mode", "2d"), 4).lower()
        if not prompt:
            return self.send_json(400, {"error": "prompt is required"})
        if mode not in ("2d", "3d"):
            return self.send_json(400, {"error": "mode must be '2d' or '3d'"})
        try:
            result = game_builder.generate_game(prompt, mode=mode, ip=ip)
            return self.send_json(200, result)
        except game_builder.BuilderError as e:
            msg = str(e)
            if "limit reached" in msg.lower():
                return self.send_json(429, {"error": msg})
            if "api key" in msg.lower():
                return self.send_json(503, {"error": msg})
            return self.send_json(400, {"error": msg})
        except Exception as e:
            return self.send_json(500, {"error": f"internal error: {type(e).__name__}"})

    def handle_play_game(self, path):
        if not BUILDER_AVAILABLE:
            return self.send_json(503, {"error": "builder module not available"})
        # /builder/play/{game_id}
        game_id = path.rsplit('/', 1)[-1]
        # Strip query string if any
        game_id = game_id.split('?')[0].split('#')[0]
        html_doc = game_builder.get_game_html(game_id)
        if html_doc is None:
            return self.send_json(404, {"error": "game not found"})
        data = html_doc.encode("utf-8")
        self.send_response(200)
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.send_header("Content-Length", str(len(data)))
        self.send_header("Cache-Control", "public, max-age=3600")
        # Allow iframe embedding from same origin only
        self.send_header("X-Frame-Options", "SAMEORIGIN")
        self.send_header("Content-Security-Policy",
                        "default-src 'self' 'unsafe-inline' 'unsafe-eval' "
                        "https://cdn.jsdelivr.net https://unpkg.com "
                        "https://cdnjs.cloudflare.com https://fonts.googleapis.com "
                        "https://fonts.gstatic.com data: blob:;")
        self.end_headers()
        self.wfile.write(data)


# ---------------------------------------------------------------------------
# Server entry point
# ---------------------------------------------------------------------------

START_TIME = time.time()


def main():
    print(f"=" * 60)
    print(f"  prompttogame.ai — Web Server")
    print(f"=" * 60)
    print(f"  Listening on:    {HOST}:{PORT}")
    print(f"  Public dir:      {PUBLIC_DIR}")
    print(f"  Database:        {DB_PATH}")
    print(f"  Regex translator: {'✓' if REGEX_AVAILABLE else '✗ (UE5Pilot server not found)'}")
    print(f"  LLM translator:   {'✓' if LLM_AVAILABLE else '✗'}")
    print(f"  LLM configured:   {'✓' if os.environ.get('UE5PILOT_LLM_API_KEY') else '✗'}")
    print(f"=" * 60)
    print()

    server = ThreadingHTTPServer((HOST, PORT), WebHandler)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\nShutting down…")
        server.shutdown()


if __name__ == "__main__":
    main()
